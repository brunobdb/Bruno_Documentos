 -- Antes de executar a procedure, crie as tabelas temporárias fora dela:
CREATE LOCAL TEMP TABLE temp_raw_hybris_sales_prepare (
    id INT,
    order_code VARCHAR(255),
    product_code VARCHAR(255),
    trade_in_discount VARCHAR(3000),
    row_id INT
) ON COMMIT PRESERVE ROWS;

CREATE LOCAL TEMP TABLE temp_discounts_details (
    order_id VARCHAR(255),
    sku VARCHAR(255),
    discount_detail_id INT,
    discount_detail VARCHAR(3000)
) ON COMMIT PRESERVE ROWS;



-- CRIANDO PROCEDURE
CREATE OR REPLACE PROCEDURE OW_LAO.PROC_ODS_HYBRIS_SALES_ITEMS_DISCOUNTS()
LANGUAGE PLvSQL AS $$
DECLARE
    loop_end     INT := 0;
    loop_count   INT := 1;
    discountInitial   VARCHAR(255) := '<MDV<';
    discountEnd       VARCHAR(255) := '>VDM>';
    discountDetails   VARCHAR(3000);
    discountSeparator VARCHAR(1) := '|';
    discountInitialSize INT := LENGTH(discountInitial);
    discountEndSize     INT := LENGTH(discountEnd);
    discountDetailCount INT := 1;
    discountDetailEnd   INT := 2;
    order_id            VARCHAR(255);
    sku                 VARCHAR(255);
    discount_detail     VARCHAR(3000);

BEGIN
    -- Limpa e carrega a tabela temporária principal
    PERFORM DELETE FROM temp_raw_hybris_sales_prepare;

    PERFORM INSERT INTO temp_raw_hybris_sales_prepare
    SELECT id,
           order_code,
           product_code,
           trade_in_discount,
           ROW_NUMBER() OVER() AS row_id
      FROM ow_lao.raw_hybris_sales_homolog
     WHERE trade_in_discount != '[]';

    SELECT COALESCE(MAX(row_id), 0) INTO loop_end FROM temp_raw_hybris_sales_prepare;

    WHILE loop_count <= loop_end LOOP
        discountDetailCount := 1;

        SELECT order_code, product_code, trade_in_discount INTO order_id, sku, discountDetails
        FROM temp_raw_hybris_sales_prepare WHERE row_id = loop_count;

        loop_count := loop_count + 1;

        -- Limpa a tabela temporária de detalhes
        PERFORM DELETE FROM temp_discounts_details;
        IF POSITION(discountSeparator IN discountDetails) = 0 THEN
            PERFORM INSERT INTO temp_discounts_details
            SELECT order_id AS order_id,
                   sku AS sku,
                   1 AS discount_detail_id,
                   REPLACE(REPLACE(
                       SUBSTRING(discountDetails FROM discountInitialSize + 2 FOR LENGTH(discountDetails) - (discountInitialSize + discountEndSize + 2)),
                       '[<', '<'),
                       '>]', '>') AS discount_detail;
        ELSE
            PERFORM INSERT INTO temp_discounts_details
            SELECT order_id AS order_id,
                   sku AS sku,
                   a.id AS discount_detail_id,
                   SUBSTRING(a.output_split FROM discountInitialSize + 1 FOR LENGTH(a.output_split) - (discountInitialSize + discountEndSize)) AS discount_detail
              FROM U_R_BOJART.SPLIT_STRING_ID(REPLACE(REPLACE(discountDetails, '[<', '<'), '>]', '>'), discountSeparator) a;
        END IF;

        SELECT COALESCE(MAX(discount_detail_id), 0) INTO discountDetailEnd FROM temp_discounts_details;

        WHILE discountDetailCount <= discountDetailEnd LOOP
            SELECT order_id, sku, discount_detail INTO order_id, sku, discount_detail
            FROM temp_discounts_details WHERE discount_detail_id = discountDetailCount;

            discountDetailCount := discountDetailCount + 1;

            PERFORM INSERT INTO U_R_BOJART.ODS_HYBRIS_SALES_ITEMS_DISCOUNTS(
                order_id,
                sku,
                discount_name,
                discount_value
            )
            SELECT order_id,
                   sku,
                   MAX(CASE WHEN a.id = 6 THEN a.output_split ELSE NULL END) AS discount_name,
                   MAX(CASE WHEN a.id = 3 THEN a.output_split ELSE NULL END) AS discount_value
              FROM U_R_BOJART.SPLIT_STRING_ID(discount_detail, '#') a
             WHERE a.id IN (3, 6);
        END LOOP;
    END LOOP;
END;
$$;