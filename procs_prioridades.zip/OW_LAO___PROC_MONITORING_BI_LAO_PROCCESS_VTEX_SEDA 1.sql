CREATE OR REPLACE PROCEDURE OW_LAO.PROC_MONITORING_BI_LAO_PROCCESS_VTEX_SEDA()
LANGUAGE PLvSQL AS $$
DECLARE 
    synapcomMaxInserted TIMESTAMP := NULL;
BEGIN
 
    SELECT MAX(po_source_insert_date)
      INTO synapcomMaxInserted
      FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE
     WHERE po_plataform_datasource IN ('u_prj_ecom_synapcom.ft_ecom_order', 'u_prj_ecom.ft_ecom_order');    
     
    PERFORM INSERT INTO OW_LAO.MONITORING_BI_LAO_PROCCESS(
                   origem_nome
                 , processo_nome
                 , referencia
                 , quantidade
       )
            SELECT 'u_prj_ecom.ods_feed_vtex_ssg_br_shop_sales_order'  AS dataSource
                 , 'Control Tower'                                     AS proccess
                 , a.order_id                                          AS referencia
                 , COUNT(1)                                            AS quantity
              FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER a
             WHERE 1 = 1
               AND a.creation_timestamp >= TIMESTAMPADD(DAY, -30, CURRENT_DATE)
               AND a.created_at         <= synapcomMaxInserted
               AND NOT EXISTS(                        
                        SELECT 1
                          FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE aa
                         WHERE aa.po_orderid = a.order_id
                           AND aa.country    = 'Brazil'
                   )
               AND NOT EXISTS(                        
                        SELECT 1
                          FROM U_PRJ_ECOM_SYNAPCOM.FT_ECOM_ORDER bb
                         WHERE bb.external_order_id = a.order_id
                   )
               AND NOT EXISTS(
                        SELECT 1
                          FROM OW_LAO.MONITORING_BI_LAO_PROCCESS cc
                         WHERE cc.processo_nome = 'Control Tower'
                           AND cc.origem_nome   = 'u_prj_ecom.ods_feed_vtex_ssg_br_shop_sales_order'
                           AND cc.referencia    = a.order_id
                           AND cc.status_nome   = 'Em analise'
                   )
          GROUP BY a.order_id;        
          
    PERFORM INSERT INTO OW_LAO.MONITORING_BI_LAO_PROCCESS(
                   origem_nome
                 , processo_nome
                 , referencia
                 , quantidade
       )
            SELECT 'u_prj_ecom.raw_vtex_ssg_br_epp2_sales_order'  AS dataSource
                 , 'Control Tower'                                AS proccess
                 , a.seller_order_id                              AS referencia
                 , COUNT(1)                                       AS quantity
              FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_EPP2_SALES_ORDER a
             WHERE 1 = 1
               AND a.seller_order_id IS NOT NULL
               AND a.creation_timestamp >= TIMESTAMPADD(DAY, -30, CURRENT_DATE)
               AND a.created_at         <= synapcomMaxInserted
               AND NOT EXISTS(                        
                        SELECT 1
                          FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE aa
                         WHERE aa.po_orderid = a.seller_order_id
                           AND aa.country    = 'Brazil'
                   ) 
               AND NOT EXISTS(                        
                        SELECT 1
                          FROM U_PRJ_ECOM_SYNAPCOM.FT_ECOM_ORDER bb
                         WHERE bb.external_order_id = a.seller_order_id
                   )
               AND NOT EXISTS(
                        SELECT 1
                          FROM OW_LAO.MONITORING_BI_LAO_PROCCESS cc
                         WHERE cc.processo_nome = 'Control Tower'
                           AND cc.origem_nome   = 'u_prj_ecom.raw_vtex_ssg_br_epp2_sales_order'
                           AND cc.referencia    = a.seller_order_id
                           AND cc.status_nome   = 'Em analise'
                   )    
          GROUP BY a.seller_order_id;    
          
END;
$$;

-- CALL OW_LAO.PROC_MONITORING_BI_LAO_PROCCESS_VTEX_SEDA();
-- ERROR: Severity: ERROR, Message: Relation "U_PRJ_ECOM_SYNAPCOM.FT_ECOM_ORDER" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_MONITORING_BI_LAO_PROCCESS_VTEX_SEDA line 11 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
-- CALL OW_LAO.PROC_MONITORING_BI_LAO_PROCCESS_VTEX_SEDA();
-- ERROR: Severity: ERROR, Message: Relation "U_PRJ_ECOM_SYNAPCOM.FT_ECOM_ORDER" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_MONITORING_BI_LAO_PROCCESS_VTEX_SEDA line 11 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
