CREATE OR REPLACE PROCEDURE ow_lao.proc_monitoring_bi_lao_proccess()
 LANGUAGE PLvSQL AS $$
BEGIN
 
    PERFORM CALL ow_lao.proc_monitoring_bi_lao_proccess_system_reviews();
    PERFORM CALL ow_lao.proc_monitoring_bi_lao_proccess_ft_ecom();
    PERFORM CALL ow_lao.proc_monitoring_bi_lao_proccess_hybris();
    PERFORM CALL ow_lao.proc_monitoring_bi_lao_proccess_sales_order_tracking();
    PERFORM CALL ow_lao.proc_monitoring_bi_lao_proccess_depara();
    PERFORM CALL ow_lao.proc_monitoring_bi_lao_proccess_globalbi();
    PERFORM CALL ow_lao.proc_monitoring_bi_lao_proccess_vtex_seda();
    PERFORM CALL ow_lao.proc_monitoring_bi_lao_proccess_hybris_files_sales_validation();
    
END
$$;

-- CALL ow_lao.proc_monitoring_bi_lao_proccess();
-- ERROR: Severity: ERROR, Message: Relation "u_prj_ecom_synapcom.ft_ecom_order" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_monitoring_bi_lao_proccess_ft_ecom line 16 at static SQL PL/vSQL procedure proc_monitoring_bi_lao_proccess line 5 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
-- CALL ow_lao.proc_monitoring_bi_lao_proccess();
-- ERROR: Severity: ERROR, Message: Relation "u_prj_ecom_synapcom.ft_ecom_order" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_monitoring_bi_lao_proccess_ft_ecom line 16 at static SQL PL/vSQL procedure proc_monitoring_bi_lao_proccess line 5 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
