CREATE OR REPLACE PROCEDURE ow_lao.proc_monitoring_bi_lao_proccess_hybris_files_sales_validation()
LANGUAGE PLvSQL AS $$
DECLARE
    v_plataform   VARCHAR(255) := 'hybris';
    v_version     VARCHAR(255) := 'GPV2';
    v_environment VARCHAR(255) := 'PRD';
    v_type        VARCHAR(255) := 'order_delivery';
    v_extension   VARCHAR(255) := 'txt';
BEGIN

    PERFORM TRUNCATE TABLE ow_lao.temp_monitoring_bi_lao_proccess_hybris_files_sales_validation;

    PERFORM INSERT INTO ow_lao.temp_monitoring_bi_lao_proccess_hybris_files_sales_validation
    (
        id, plataform, "version", country, environment, "type", start_date, final_date, "partition", extension, validated, file_name_short
    )
    SELECT
        id AS id,
        REGEXP_SUBSTR(file_name_short, '[^_]+', 1, 1) AS plataform,
        REGEXP_SUBSTR(file_name_short, '[^_]+', 1, 2) AS "version",
        REGEXP_SUBSTR(file_name_short, '[^_]+', 1, 3) AS country,
        REGEXP_SUBSTR(file_name_short, '[^_]+', 1, 4) AS environment,
        REGEXP_SUBSTR(file_name_short, '[^_]+', 1, 5) || '_' || REGEXP_SUBSTR(file_name_short, '[^_]+', 1, 6) AS "type",
        REGEXP_SUBSTR(file_name_short, '[^_]+', 1, 7) AS start_date,
        REGEXP_SUBSTR(file_name_short, '[^_]+', 1, 8) AS final_date,
        REGEXP_SUBSTR(REGEXP_SUBSTR(file_name_short, '[^_]+', 1, 9), '[^.]+', 1, 1) AS "partition",
        REGEXP_SUBSTR(file_name_short, '[^.]+', 1, 2) AS extension,
        FALSE AS validated,
        file_name_short AS file_name_short
    FROM ow_lao.monitoring_bi_lao_proccess_hybris_files_sales
    WHERE validated IS NULL;

    PERFORM UPDATE ow_lao.temp_monitoring_bi_lao_proccess_hybris_files_sales_validation a
       SET validated = TRUE
     WHERE a.plataform   = v_plataform
       AND a."version"   = v_version
       AND a.environment = v_environment
       AND a."type"      = v_type
       AND a.extension   = v_extension;

    PERFORM UPDATE ow_lao.temp_monitoring_bi_lao_proccess_hybris_files_sales_validation a
       SET validated = FALSE
     WHERE a.start_date <> a.final_date;

    PERFORM UPDATE ow_lao.monitoring_bi_lao_proccess_hybris_files_sales a
       SET validated = b.validated
      FROM ow_lao.temp_monitoring_bi_lao_proccess_hybris_files_sales_validation b
     WHERE b.id = a.id;

    PERFORM INSERT INTO ow_lao.monitoring_bi_lao_proccess
    (
        origem_nome,
        processo_nome,
        referencia,
        quantidade
    )
    SELECT
        'ow_lao.monitoring_bi_lao_proccess_hybris_files_sales' AS origem_nome,
        'Control Tower'                                        AS processo_nome,
        a.file_name_short                                      AS referencia,
        COUNT(1)                                               AS quantidade
    FROM ow_lao.temp_monitoring_bi_lao_proccess_hybris_files_sales_validation a
    WHERE a.validated = FALSE
      AND NOT EXISTS (
            SELECT 1
            FROM ow_lao.monitoring_bi_lao_proccess cc
            WHERE cc.processo_nome = 'Control Tower'
              AND cc.origem_nome   = 'ow_lao.monitoring_bi_lao_proccess_hybris_files_sales'
              AND cc.referencia    = a.file_name_short
              AND cc.status_nome   = 'Em analise'
      )
    GROUP BY a.file_name_short;

END;
$$;

-- CALL ow_lao.proc_monitoring_bi_lao_proccess_hybris_files_sales_validation();
-- ERROR: Severity: ERROR, Message: Cannot set NOT NULL columns (ID, STATUS_NOME) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure proc_monitoring_bi_lao_proccess_hybris_files_sales_validation line 49 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3211, Error Code: 2514, 
-- CALL ow_lao.proc_monitoring_bi_lao_proccess_hybris_files_sales_validation();
-- ERROR: Severity: ERROR, Message: Cannot set NOT NULL columns (ID, STATUS_NOME) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure proc_monitoring_bi_lao_proccess_hybris_files_sales_validation line 49 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3211, Error Code: 2514, 
SELECT column_name, data_type, is_nullable, column_default, ordinal_position
FROM v_catalog.columns
WHERE table_schema='ow_lao' AND table_name='monitoring_bi_lao_proccess'
ORDER BY ordinal_position;
-- column_name | data_type | is_nullable | column_default | ordinal_position
-- ------------+-----------+-------------+----------------+-----------------

SELECT column_name, data_type, is_nullable, column_default, ordinal_position
FROM v_catalog.columns
WHERE table_schema='OW_LAO' AND table_name='MONITORING_BI_LAO_PROCCESS'
ORDER BY ordinal_position;
-- column_name | data_type | is_nullable | column_default | ordinal_position
-- ------------+-----------+-------------+----------------+-----------------
-- ID | int | False |  | 1
-- INSERTED_TIMESTAMP | timestamp | True |  | 2
-- UPDATED_TIMESTAMP | timestamp | True |  | 3
-- PROCESSO_NOME | varchar(255) | True |  | 4
-- ORIGEM_NOME | varchar(255) | True |  | 5
-- QUANTIDADE | int | True |  | 6
-- REFERENCIA | varchar(255) | False |  | 7
-- STATUS_NOME | varchar(255) | False |  | 8
-- ANALISTA_NOME | varchar(255) | True |  | 9
-- OBSERVACAO | varchar(3000) | True |  | 10

SELECT * FROM ow_lao.monitoring_bi_lao_proccess LIMIT 0;
-- ID | INSERTED_TIMESTAMP | UPDATED_TIMESTAMP | PROCESSO_NOME | ORIGEM_NOME | QUANTIDADE | REFERENCIA | STATUS_NOME | ANALISTA_NOME | OBSERVACAO
-- ---+--------------------+-------------------+---------------+-------------+------------+------------+-------------+---------------+-----------

SELECT column_name, data_type, is_nullable, column_default
FROM v_catalog.columns
WHERE table_schema = 'OW_LAO' AND table_name = 'MONITORING_BI_LAO_PROCCESS'
ORDER BY ordinal_position;
-- column_name | data_type | is_nullable | column_default
-- ------------+-----------+-------------+---------------
-- ID | int | False | 
-- INSERTED_TIMESTAMP | timestamp | True | 
-- UPDATED_TIMESTAMP | timestamp | True | 
-- PROCESSO_NOME | varchar(255) | True | 
-- ORIGEM_NOME | varchar(255) | True | 
-- QUANTIDADE | int | True | 
-- REFERENCIA | varchar(255) | False | 
-- STATUS_NOME | varchar(255) | False | 
-- ANALISTA_NOME | varchar(255) | True | 
-- OBSERVACAO | varchar(3000) | True | 

SELECT column_name, data_type, is_nullable, column_default
FROM v_catalog.columns
WHERE table_schema ILIKE 'ow_lao' AND table_name ILIKE 'monitoring_bi_lao_proccess'
ORDER BY ordinal_position;
-- column_name | data_type | is_nullable | column_default
-- ------------+-----------+-------------+---------------
-- ID | int | False | 
-- INSERTED_TIMESTAMP | timestamp | True | 
-- UPDATED_TIMESTAMP | timestamp | True | 
-- PROCESSO_NOME | varchar(255) | True | 
-- ORIGEM_NOME | varchar(255) | True | 
-- QUANTIDADE | int | True | 
-- REFERENCIA | varchar(255) | False | 
-- STATUS_NOME | varchar(255) | False | 
-- ANALISTA_NOME | varchar(255) | True | 
-- OBSERVACAO | varchar(3000) | True | 

SELECT HASH('a')
-- HASH
-- ----
-- 1439324057017381289

CREATE OR REPLACE PROCEDURE ow_lao.proc_monitoring_bi_lao_proccess_hybris_files_sales_validation()
LANGUAGE PLvSQL AS $$
DECLARE
    v_plataform   VARCHAR(255) := 'hybris';
    v_version     VARCHAR(255) := 'GPV2';
    v_environment VARCHAR(255) := 'PRD';
    v_type        VARCHAR(255) := 'order_delivery';
    v_extension   VARCHAR(255) := 'txt';
BEGIN

    PERFORM TRUNCATE TABLE ow_lao.temp_monitoring_bi_lao_proccess_hybris_files_sales_validation;

    PERFORM INSERT INTO ow_lao.temp_monitoring_bi_lao_proccess_hybris_files_sales_validation
    (
        id, plataform, "version", country, environment, "type", start_date, final_date, "partition", extension, validated, file_name_short
    )
    SELECT
        id AS id,
        REGEXP_SUBSTR(file_name_short, '[^_]+', 1, 1) AS plataform,
        REGEXP_SUBSTR(file_name_short, '[^_]+', 1, 2) AS "version",
        REGEXP_SUBSTR(file_name_short, '[^_]+', 1, 3) AS country,
        REGEXP_SUBSTR(file_name_short, '[^_]+', 1, 4) AS environment,
        REGEXP_SUBSTR(file_name_short, '[^_]+', 1, 5) || '_' || REGEXP_SUBSTR(file_name_short, '[^_]+', 1, 6) AS "type",
        REGEXP_SUBSTR(file_name_short, '[^_]+', 1, 7) AS start_date,
        REGEXP_SUBSTR(file_name_short, '[^_]+', 1, 8) AS final_date,
        REGEXP_SUBSTR(REGEXP_SUBSTR(file_name_short, '[^_]+', 1, 9), '[^.]+', 1, 1) AS "partition",
        REGEXP_SUBSTR(file_name_short, '[^.]+', 1, 2) AS extension,
        FALSE AS validated,
        file_name_short AS file_name_short
    FROM ow_lao.monitoring_bi_lao_proccess_hybris_files_sales
    WHERE validated IS NULL;

    PERFORM UPDATE ow_lao.temp_monitoring_bi_lao_proccess_hybris_files_sales_validation a
       SET validated = TRUE
     WHERE a.plataform   = v_plataform
       AND a."version"   = v_version
       AND a.environment = v_environment
       AND a."type"      = v_type
       AND a.extension   = v_extension;

    PERFORM UPDATE ow_lao.temp_monitoring_bi_lao_proccess_hybris_files_sales_validation a
       SET validated = FALSE
     WHERE a.start_date <> a.final_date;

    PERFORM UPDATE ow_lao.monitoring_bi_lao_proccess_hybris_files_sales a
       SET validated = b.validated
      FROM ow_lao.temp_monitoring_bi_lao_proccess_hybris_files_sales_validation b
     WHERE b.id = a.id;

    PERFORM INSERT INTO ow_lao.monitoring_bi_lao_proccess
    (
        id,
        inserted_timestamp,
        updated_timestamp,
        processo_nome,
        origem_nome,
        quantidade,
        referencia,
        status_nome
    )
    SELECT
        CAST(TIMESTAMPDIFF('second', TIMESTAMP '1970-01-01 00:00:00', CURRENT_TIMESTAMP) AS BIGINT) * 1000000
          + ROW_NUMBER() OVER (ORDER BY a.file_name_short) AS id,
        CURRENT_TIMESTAMP AS inserted_timestamp,
        CURRENT_TIMESTAMP AS updated_timestamp,
        'Control Tower' AS processo_nome,
        'ow_lao.monitoring_bi_lao_proccess_hybris_files_sales' AS origem_nome,
        COUNT(1) AS quantidade,
        a.file_name_short AS referencia,
        'Em analise' AS status_nome
    FROM ow_lao.temp_monitoring_bi_lao_proccess_hybris_files_sales_validation a
    WHERE a.validated = FALSE
      AND NOT EXISTS (
            SELECT 1
            FROM ow_lao.monitoring_bi_lao_proccess cc
            WHERE cc.processo_nome = 'Control Tower'
              AND cc.origem_nome   = 'ow_lao.monitoring_bi_lao_proccess_hybris_files_sales'
              AND cc.referencia    = a.file_name_short
              AND cc.status_nome   = 'Em analise'
      )
    GROUP BY a.file_name_short;

END;
$$;

CALL ow_lao.proc_monitoring_bi_lao_proccess_hybris_files_sales_validation();
-- proc_monitoring_bi_lao_proccess_hybris_files_sales_validation
-- -------------------------------------------------------------
-- 0

