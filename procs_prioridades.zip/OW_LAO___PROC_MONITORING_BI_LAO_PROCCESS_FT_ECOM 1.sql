CREATE OR REPLACE PROCEDURE ow_lao.proc_monitoring_bi_lao_proccess_ft_ecom()
LANGUAGE PLvSQL AS $$
DECLARE
    poMaxInserted TIMESTAMP;
    poSynapcomMaxInserted TIMESTAMP;
BEGIN
    SELECT MAX(po_source_insert_date)
      INTO poSynapcomMaxInserted
      FROM ow_lao.ods_sales_control_tower_table
     WHERE po_plataform_datasource IN ('u_prj_ecom_synapcom.ft_ecom_order');  
 
    SELECT MAX(po_source_insert_date)
      INTO poMaxInserted
      FROM ow_lao.ods_sales_control_tower_table
     WHERE po_plataform_datasource IN ('u_prj_ecom.ft_ecom_order');    

    PERFORM INSERT INTO ow_lao.monitoring_bi_lao_proccess(
                   origem_nome
                 , processo_nome
                 , referencia
                 , quantidade
       )
    SELECT 'u_prj_ecom_synapcom.ft_ecom_order'  as dataSource
         , 'Control Tower'                      as proccess
         , a.external_order_id                  as referencia
         , count(1)                             as quantity
      FROM u_prj_ecom_synapcom.ft_ecom_order                       a
      JOIN u_prj_ecom_synapcom.ft_ecom_order_item                  b on b.order_id = a.id
      JOIN u_prj_ecom.dim_subsidiary                               c on c.id       = a.subsidiary_id
     WHERE a.creation_date >= TIMESTAMPADD(DAY, -180, CURRENT_DATE)
       AND a.insert_date   <= poSynapcomMaxInserted
       AND NOT EXISTS(                        
                SELECT 1
                  FROM ow_lao.ods_sales_control_tower_table aa
                 WHERE aa.po_orderid            = a.external_order_id
                   AND aa.po_sku                = b.reference_code
                   AND aa.country               = c.country
           )
       AND NOT EXISTS(
                SELECT 1
                  FROM u_prj_ecom_synapcom.ft_ecom_order_kit_component bb
                 WHERE bb.item_id = b.id
           )
       AND NOT EXISTS(
                SELECT 1
                  FROM ow_lao.monitoring_bi_lao_proccess cc
                 WHERE cc.processo_nome = 'Control Tower'
                   AND cc.origem_nome   = 'u_prj_ecom_synapcom.ft_ecom_order'
                   AND cc.referencia    = a.external_order_id
                   AND cc.status_nome   = 'Em analise'
           )
  GROUP BY a.external_order_id;
        
    PERFORM INSERT INTO ow_lao.monitoring_bi_lao_proccess(
                   origem_nome
                 , processo_nome
                 , referencia
                 , quantidade
       )
    SELECT 'u_prj_ecom_synapcom.ft_ecom_order bundle'   as dataSource
         , 'Control Tower'                              as proccess
         , a.external_order_id                          as referencia
         , count(1)                                     as quantity
      FROM u_prj_ecom_synapcom.ft_ecom_order                       a
      JOIN u_prj_ecom_synapcom.ft_ecom_order_item                  b on b.order_id = a.id
      JOIN u_prj_ecom.dim_subsidiary                               c on c.id       = a.subsidiary_id
      JOIN u_prj_ecom_synapcom.ft_ecom_order_kit_component         d on d.item_id  = b.id
     WHERE a.creation_date >= TIMESTAMPADD(DAY, -180, CURRENT_DATE)
       AND a.insert_date   <= poSynapcomMaxInserted
       AND NOT EXISTS(                        
                SELECT 1
                  FROM ow_lao.ods_sales_control_tower_table aa
                 WHERE aa.po_orderid                  = a.external_order_id
                   AND aa.po_sku                      = d.reference_code
                   AND aa.country                     = c.country
                   AND aa.po_sku_kit                  = b.reference_code
           )
       AND NOT EXISTS(
                SELECT 1
                  FROM ow_lao.monitoring_bi_lao_proccess cc
                 WHERE cc.processo_nome = 'Control Tower'
                   AND cc.origem_nome   = 'u_prj_ecom_synapcom.ft_ecom_order'
                   AND cc.referencia    = a.external_order_id
                   AND cc.status_nome   = 'Em analise'
           )
  GROUP BY a.external_order_id;
          
    PERFORM INSERT INTO ow_lao.monitoring_bi_lao_proccess(
                   origem_nome
                 , processo_nome
                 , referencia
                 , quantidade
       )
    SELECT 'u_prj_ecom.ft_ecom_order'   as dataSource
         , 'Control Tower'              as proccess
         , a.external_order_id          as referencia
         , count(1)                     as quantity
      FROM u_prj_ecom.ft_ecom_order                       a
      JOIN u_prj_ecom.ft_ecom_order_item                  b on b.order_id = a.id
      JOIN u_prj_ecom.dim_subsidiary                      c on c.id       = a.subsidiary_id
     WHERE a.creation_date >= TIMESTAMPADD(DAY, -180, CURRENT_DATE)
       AND a.insert_date   <= poMaxInserted
       AND a.subsidiary_id != 6
       AND NOT EXISTS(                        
                SELECT 1
                  FROM ow_lao.ods_sales_control_tower_table aa
                 WHERE aa.po_orderid            = a.external_order_id
                   AND aa.po_sku                = b.reference_code
                   AND aa.country               = c.country
           )
       AND NOT EXISTS(
                SELECT 1
                  FROM u_prj_ecom_synapcom.ft_ecom_order_kit_component bb
                 WHERE bb.item_id = b.id
           )
       AND NOT EXISTS(
                SELECT 1
                  FROM ow_lao.monitoring_bi_lao_proccess cc
                 WHERE cc.processo_nome = 'Control Tower'
                   AND cc.origem_nome   = 'u_prj_ecom.ft_ecom_order'
                   AND cc.referencia    = a.external_order_id
                   AND cc.status_nome   = 'Em analise'
           )
  GROUP BY a.external_order_id;          
          
END;
$$;

-- CALL ow_lao.proc_monitoring_bi_lao_proccess_ft_ecom();
-- ERROR: Severity: ERROR, Message: Relation "u_prj_ecom_synapcom.ft_ecom_order" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_monitoring_bi_lao_proccess_ft_ecom line 16 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
-- CALL ow_lao.proc_monitoring_bi_lao_proccess_ft_ecom();
-- ERROR: Severity: ERROR, Message: Relation "u_prj_ecom_synapcom.ft_ecom_order" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_monitoring_bi_lao_proccess_ft_ecom line 16 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
