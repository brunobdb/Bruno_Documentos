CREATE OR REPLACE PROCEDURE OW_LAO.PROC_MONITORING_BI_LAO_PROCCESS_VTEX_SEDA()
LANGUAGE PLvSQL
AS $$
DECLARE
    synapcomMaxInserted TIMESTAMP := NULL;
BEGIN
    -- BLOCO 1
    SELECT MAX(po_source_insert_date)
      FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE
     WHERE po_plataform_datasource IN ('u_prj_ecom_synapcom.ft_ecom_order', 'u_prj_ecom.ft_ecom_order')
     INTO synapcomMaxInserted;

    -- BLOCO 2
 PERFORM   INSERT INTO OW_LAO.MONITORING_BI_LAO_PROCCESS (
        ID, ORIGEM_NOME, PROCESSO_NOME, REFERENCIA, QUANTIDADE, STATUS_NOME
    )
    SELECT
        NEXTVAL('OW_LAO.MONITORING_BI_LAO_PROCCESS_SEQ'),
        'u_prj_ecom.ods_feed_vtex_ssg_br_shop_sales_order',
        'Control Tower',
        a.order_id,
        COUNT(1),
        'Em analise'
    FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER a
    WHERE a.creation_timestamp >= TIMESTAMPADD(DAY, -30, CURRENT_DATE)
    --  AND a.created_at <= '2025-11-04 10:48:06.032'
AND a.created_at               <= synapcomMaxInserted
      AND NOT EXISTS (
          SELECT 1
            FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE aa
           WHERE aa.po_orderid = a.order_id
             AND aa.country = 'Brazil'
      )
      AND NOT EXISTS (
          SELECT 1
            FROM OW_LAO.MONITORING_BI_LAO_PROCCESS cc
           WHERE cc.processo_nome = 'Control Tower'
             AND cc.origem_nome = 'u_prj_ecom.ods_feed_vtex_ssg_br_shop_sales_order'
             AND cc.referencia = a.order_id
             AND cc.status_nome = 'Em analise'
      )
    GROUP BY a.order_id;

    -- BLOCO 3
   PERFORM INSERT INTO OW_LAO.MONITORING_BI_LAO_PROCCESS (
        ID, ORIGEM_NOME, PROCESSO_NOME, REFERENCIA, QUANTIDADE, STATUS_NOME
    )
    SELECT
        NEXTVAL('OW_LAO.MONITORING_BI_LAO_PROCCESS_SEQ'),
        'u_prj_ecom.raw_vtex_ssg_br_epp2_sales_order',
        'Control Tower',
        a.seller_order_id,
        COUNT(1),
        'Em analise'
    FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_EPP2_SALES_ORDER a
    WHERE a.seller_order_id IS NOT NULL
      AND a.creation_timestamp >= TIMESTAMPADD(DAY, -30, CURRENT_DATE)
    --  AND a.created_at <= '2025-11-04 10:48:06.032'
AND a.created_at               <= synapcomMaxInserted
      AND NOT EXISTS (
          SELECT 1
            FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE aa
           WHERE aa.po_orderid = a.seller_order_id
             AND aa.country = 'Brazil'
      )
      AND NOT EXISTS (
          SELECT 1
            FROM OW_LAO.MONITORING_BI_LAO_PROCCESS cc
           WHERE cc.processo_nome = 'Control Tower'
             AND cc.origem_nome = 'u_prj_ecom.raw_vtex_ssg_br_epp2_sales_order'
             AND cc.referencia = a.seller_order_id
             AND cc.status_nome = 'Em analise'
      )
    GROUP BY a.seller_order_id;

END;
$$;