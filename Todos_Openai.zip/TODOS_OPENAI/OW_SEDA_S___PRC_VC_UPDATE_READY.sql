-- CREATE OR REPLACE PROCEDURE OW_SEDA_S.PRC_VC_UPDATE_READY(WEEKNUM_REF INT)
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--     -- Staging: TMP_FILTER
--     PERFORM DROP TABLE IF EXISTS TMP_FILTER;
--     PERFORM CREATE LOCAL TEMPORARY TABLE TMP_FILTER ON COMMIT PRESERVE ROWS AS
--         SELECT 
--             WEEKNUM,
--             MAX(SELL_OUT_DATE)::DATE AS LAST_DAY_OF_WEEK
--         FROM OW_SEDA_S.FT_CE_DAILY_PIVOT
--         WHERE WEEKNUM = WEEKNUM_REF
--           AND INVENTORY > 0
--         GROUP BY WEEKNUM;
-- 
--     -- Staging: TMP_AUX
--     PERFORM DROP TABLE IF EXISTS TMP_AUX;
--     PERFORM CREATE LOCAL TEMPORARY TABLE TMP_AUX ON COMMIT PRESERVE ROWS AS
--         SELECT
--             fcdp.*,
--             tf.LAST_DAY_OF_WEEK,
--             CASE 
--                 WHEN tf.LAST_DAY_OF_WEEK = fcdp.SELL_OUT_DATE THEN fcdp.INVENTORY 
--                 ELSE 0
--             END AS LAST_DAY_INVENTORY
--         FROM OW_SEDA_S.FT_CE_DAILY_PIVOT fcdp 
--         INNER JOIN OW_SEDA_S.MAP_CE_STORES mcs ON mcs.SITE_ID = fcdp.SITE_ID 
--         INNER JOIN OW_SEDA_S.MAP_CE_PRODUCTS mcp ON mcp.ITEM = fcdp.ITEM 
--         INNER JOIN TMP_FILTER tf ON fcdp.WEEKNUM = tf.WEEKNUM
--         WHERE mcp.CATEGORY_ITEM = 'VC';
-- 
--     -- Staging: TMP_COMPLETE
--     PERFORM DROP TABLE IF EXISTS TMP_COMPLETE;
--     PERFORM CREATE LOCAL TEMPORARY TABLE TMP_COMPLETE ON COMMIT PRESERVE ROWS AS
--         SELECT
--             'Sell Out' AS "PARAMETER",
--             WEEKNUM,
--             SITE_ID,
--             ITEM,
--             SUM(SELL_OUT) AS "DATA",
--             'FT_CE_DAILY_PIVOT' AS REPORT,
--             CURRENT_DATE AS LOAD_DATE
--         FROM TMP_AUX
--         GROUP BY WEEKNUM, SITE_ID, ITEM
--         HAVING SUM(SELL_OUT) <> 0
--         UNION ALL
--         SELECT
--             'Inventory' AS "PARAMETER",
--             WEEKNUM,
--             SITE_ID,
--             ITEM,
--             SUM(LAST_DAY_INVENTORY) AS "DATA",
--             'FT_CE_DAILY_PIVOT' AS REPORT,
--             CURRENT_DATE AS LOAD_DATE
--         FROM TMP_AUX
--         GROUP BY WEEKNUM, SITE_ID, ITEM
--         HAVING SUM(LAST_DAY_INVENTORY) <> 0;
-- 
--     -- Delete and load into target
--     PERFORM DELETE FROM OW_SEDA_S.FT_CE_READY fcp 
--     WHERE EXISTS (
--             SELECT 1 
--             FROM OW_SEDA_S.MAP_CE_PRODUCTS mcp 
--             WHERE fcp.ITEM = mcp.ITEM 
--               AND mcp.CATEGORY_ITEM = 'VC'
--         )
--       AND fcp.WEEKNUM = WEEKNUM_REF;
-- 
--     PERFORM INSERT INTO OW_SEDA_S.FT_CE_READY
--     SELECT * FROM TMP_COMPLETE;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: Syntax error at or near "fcp", Sqlstate: 42601, Position: 2088, Routine: base_yyerror, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/scan.l, Line: 1056, Error Code: 4856, 
CREATE OR REPLACE PROCEDURE OW_SEDA_S.PRC_VC_UPDATE_READY(WEEKNUM_REF INT)
LANGUAGE PLvSQL AS $$
BEGIN
    -- Staging: TMP_FILTER
    PERFORM DROP TABLE IF EXISTS TMP_FILTER;
    PERFORM CREATE LOCAL TEMPORARY TABLE TMP_FILTER ON COMMIT PRESERVE ROWS AS
        SELECT 
            WEEKNUM,
            MAX(SELL_OUT_DATE)::DATE AS LAST_DAY_OF_WEEK
        FROM OW_SEDA_S.FT_CE_DAILY_PIVOT
        WHERE WEEKNUM = WEEKNUM_REF
          AND INVENTORY > 0
        GROUP BY WEEKNUM;

    -- Staging: TMP_AUX
    PERFORM DROP TABLE IF EXISTS TMP_AUX;
    PERFORM CREATE LOCAL TEMPORARY TABLE TMP_AUX ON COMMIT PRESERVE ROWS AS
        SELECT
            fcdp.*,
            tf.LAST_DAY_OF_WEEK,
            CASE 
                WHEN tf.LAST_DAY_OF_WEEK = fcdp.SELL_OUT_DATE THEN fcdp.INVENTORY 
                ELSE 0
            END AS LAST_DAY_INVENTORY
        FROM OW_SEDA_S.FT_CE_DAILY_PIVOT fcdp 
        INNER JOIN OW_SEDA_S.MAP_CE_STORES mcs ON mcs.SITE_ID = fcdp.SITE_ID 
        INNER JOIN OW_SEDA_S.MAP_CE_PRODUCTS mcp ON mcp.ITEM = fcdp.ITEM 
        INNER JOIN TMP_FILTER tf ON fcdp.WEEKNUM = tf.WEEKNUM
        WHERE mcp.CATEGORY_ITEM = 'VC';

    -- Staging: TMP_COMPLETE
    PERFORM DROP TABLE IF EXISTS TMP_COMPLETE;
    PERFORM CREATE LOCAL TEMPORARY TABLE TMP_COMPLETE ON COMMIT PRESERVE ROWS AS
        SELECT
            'Sell Out' AS "PARAMETER",
            WEEKNUM,
            SITE_ID,
            ITEM,
            SUM(SELL_OUT) AS "DATA",
            'FT_CE_DAILY_PIVOT' AS REPORT,
            CURRENT_DATE AS LOAD_DATE
        FROM TMP_AUX
        GROUP BY WEEKNUM, SITE_ID, ITEM
        HAVING SUM(SELL_OUT) <> 0
        UNION ALL
        SELECT
            'Inventory' AS "PARAMETER",
            WEEKNUM,
            SITE_ID,
            ITEM,
            SUM(LAST_DAY_INVENTORY) AS "DATA",
            'FT_CE_DAILY_PIVOT' AS REPORT,
            CURRENT_DATE AS LOAD_DATE
        FROM TMP_AUX
        GROUP BY WEEKNUM, SITE_ID, ITEM
        HAVING SUM(LAST_DAY_INVENTORY) <> 0;

    -- Delete and load into target
    PERFORM DELETE FROM OW_SEDA_S.FT_CE_READY
    WHERE EXISTS (
            SELECT 1 
            FROM OW_SEDA_S.MAP_CE_PRODUCTS mcp 
            WHERE OW_SEDA_S.FT_CE_READY.ITEM = mcp.ITEM 
              AND mcp.CATEGORY_ITEM = 'VC'
        )
      AND OW_SEDA_S.FT_CE_READY.WEEKNUM = WEEKNUM_REF;

    PERFORM INSERT INTO OW_SEDA_S.FT_CE_READY
    SELECT * FROM TMP_COMPLETE;
END;
$$;

CALL OW_SEDA_S.PRC_VC_UPDATE_READY(202401);
-- PRC_VC_UPDATE_READY
-- -------------------
-- 0

