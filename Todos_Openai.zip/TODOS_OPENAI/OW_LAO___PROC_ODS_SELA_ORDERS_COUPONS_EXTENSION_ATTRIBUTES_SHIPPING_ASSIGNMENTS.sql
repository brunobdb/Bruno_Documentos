CREATE OR REPLACE PROCEDURE ow_lao.proc_ods_sela_orders_coupons_extension_attributes_shipping_assignments()
LANGUAGE PLvSQL AS $$
BEGIN
  PERFORM MERGE INTO ow_lao.ods_sela_orders_coupons_extension_attributes_shipping_assignments a
  USING ow_lao.stg_sela_orders_coupons_extension_attributes_shipping_assignments b
  ON b.store_id = a.store_id
     AND b.subsidiary_id = a.subsidiary_id
     AND b.account = a.account
     AND b.entity_id = a.entity_id
  WHEN MATCHED THEN UPDATE SET
     updated_timestamp = CURRENT_TIMESTAMP
   , shipping_address_type = b.shipping_address_type
   , shipping_city = b.shipping_city
   , shipping_country_id = b.shipping_country_id
   , shipping_email = b.shipping_email
   , shipping_entity_id = b.shipping_entity_id
   , shipping_irstname = b.shipping_irstname
   , shipping_lastname = b.shipping_lastname
   , shipping_parent_id = b.shipping_parent_id
   , shipping_postcode = b.shipping_postcode
   , shipping_region = b.shipping_region
   , shipping_region_code = b.shipping_region_code
   , shipping_region_id = b.shipping_region_id
   , shipping_street = b.shipping_street
   , shipping_telephone = b.shipping_telephone
   , shipping_method = b.shipping_method
  WHEN NOT MATCHED THEN INSERT (
     updated_timestamp
   , shipping_address_type
   , shipping_city
   , shipping_country_id
   , shipping_email
   , shipping_entity_id
   , shipping_irstname
   , shipping_lastname
   , shipping_parent_id
   , shipping_postcode
   , shipping_region
   , shipping_region_code
   , shipping_region_id
   , shipping_street
   , shipping_telephone
   , shipping_method
   , store_id
   , entity_id
   , subsidiary_id
   , account
  ) VALUES (
     CURRENT_TIMESTAMP
   , b.shipping_address_type
   , b.shipping_city
   , b.shipping_country_id
   , b.shipping_email
   , b.shipping_entity_id
   , b.shipping_irstname
   , b.shipping_lastname
   , b.shipping_parent_id
   , b.shipping_postcode
   , b.shipping_region
   , b.shipping_region_code
   , b.shipping_region_id
   , b.shipping_street
   , b.shipping_telephone
   , b.shipping_method
   , b.store_id
   , b.entity_id
   , b.subsidiary_id
   , b.account
  );
END;
$$;

-- CALL ow_lao.proc_ods_sela_orders_coupons_extension_attributes_shipping_assignments();
-- ERROR: Severity: ERROR, Message: Relation "ow_lao.stg_sela_orders_coupons_extension_attributes_shipping_assignments" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ods_sela_orders_coupons_extension_attributes_shipping_assignments line 3 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
-- CALL ow_lao.proc_ods_sela_orders_coupons_extension_attributes_shipping_assignments();
-- ERROR: Severity: ERROR, Message: Relation "ow_lao.stg_sela_orders_coupons_extension_attributes_shipping_assignments" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ods_sela_orders_coupons_extension_attributes_shipping_assignments line 3 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
