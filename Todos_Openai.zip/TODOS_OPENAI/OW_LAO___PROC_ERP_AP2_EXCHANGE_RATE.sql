CREATE OR REPLACE PROCEDURE OW_LAO.PROC_ERP_AP2_EXCHANGE_RATE()
LANGUAGE PLvSQL AS $$
DECLARE
  load_date_newest DATE;
  load_date_not_exists BOOLEAN;
BEGIN

  SELECT MAX(a.load_date)
    INTO load_date_newest
    FROM ow_lao.ods_erp_exchange_rate a
   WHERE "Exchange Rate Type" = 'M';

  SELECT CASE WHEN COUNT(*) > 0 THEN true ELSE false END
    INTO load_date_not_exists
    FROM ow_lao.ft_ap2_exchange_rate b
   WHERE b.load_date = load_date_newest;

  IF NOT load_date_not_exists THEN

    PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_erp_exchange_rate_temp ON COMMIT PRESERVE ROWS AS
      SELECT
        "From currency" AS from_currency,
        "To-currency" AS to_currency,
        CAST(REPLACE("Valid from", '.', '-') AS DATE) AS valid_from,
        CAST(REPLACE("Exchange Rate", ',', '') AS NUMERIC(38,10)) AS exchange_rate,
        load_date,
        CAST(NULL AS VARCHAR(256)) AS process_status,
        CAST(NULL AS VARCHAR(256)) AS comment_status,
        CAST(NULL AS INT) AS dedup
      FROM ow_lao.ods_erp_exchange_rate
      WHERE 1=0;

    PERFORM INSERT INTO tmp_ods_erp_exchange_rate_temp
      SELECT DISTINCT
        "From currency" AS from_currency,
        "To-currency" AS to_currency,
        CAST(REPLACE("Valid from", '.', '-') AS DATE) AS valid_from,
        CAST(REPLACE("Exchange Rate", ',', '') AS NUMERIC(38,10)) AS exchange_rate,
        load_date AS load_date,
        NULL AS process_status,
        NULL AS comment_status,
        ROW_NUMBER() OVER(
          PARTITION BY "From currency", "To-currency", CAST(REPLACE("Valid from", '.', '-') AS DATE)
          ORDER BY load_date DESC
        ) AS dedup
      FROM ow_lao.ods_erp_exchange_rate
      WHERE "Exchange Rate Type" = 'M'
        AND "Exchange Rate" IS NOT NULL
        AND load_date = load_date_newest;

    PERFORM DELETE FROM tmp_ods_erp_exchange_rate_temp WHERE dedup <> 1;

    PERFORM MERGE INTO ow_lao.ft_ap2_exchange_rate a
      USING tmp_ods_erp_exchange_rate_temp b
      ON b.from_currency = a.from_currency
     AND b.to_currency   = a.to_currency
     AND b.valid_from    = a.valid_from
     WHEN MATCHED THEN UPDATE SET
        load_date         = b.load_date,
        exchange_rate     = b.exchange_rate,
        process_status    = b.process_status,
        comment_status    = b.comment_status,
        updated_timestamp = CURRENT_TIMESTAMP
     WHEN NOT MATCHED THEN INSERT
        (from_currency, to_currency, valid_from, load_date, exchange_rate, process_status, comment_status)
        VALUES
        (b.from_currency, b.to_currency, b.valid_from, b.load_date, b.exchange_rate, b.process_status, b.comment_status);

  END IF;

  PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_erp_exchange_rate_default
  ( valid_from DATE,
    from_currency VARCHAR(255),
    to_currency   VARCHAR(255),
    exchange_rate DECIMAL(38,10) DEFAULT 0.00
  ) ON COMMIT PRESERVE ROWS;

  PERFORM INSERT INTO tmp_ods_erp_exchange_rate_default
    SELECT a.YYYYMMDD AS valid_from,
           b."From currency" AS from_currency,
           b."To-currency" AS to_currency,
           CAST(0.00 AS DECIMAL(38,10)) AS exchange_rate
      FROM ow_md.dim_calendar a
      JOIN ow_lao.ods_erp_exchange_rate b ON 1=1
     WHERE a.YYYYMMDD BETWEEN TIMESTAMPADD(DAY, -30, CURRENT_DATE) AND CURRENT_DATE
       AND b."Exchange Rate Type" = 'M'
       AND b."Exchange Rate" IS NOT NULL
       AND NOT EXISTS (
             SELECT 1
               FROM ow_lao.ft_ap2_exchange_rate aa
              WHERE aa.valid_from    = a.YYYYMMDD
                AND aa.from_currency = b."From currency"
                AND aa.to_currency   = b."To-currency"
           )
     GROUP BY a.YYYYMMDD, b."From currency", b."To-currency";

  PERFORM INSERT INTO tmp_ods_erp_exchange_rate_default
    SELECT a.YYYYMMDD AS valid_from,
           b.from_currency,
           b.to_currency,
           CAST(0.00 AS DECIMAL(38,10)) AS exchange_rate
      FROM ow_md.dim_calendar a
      JOIN ow_lao.ft_ap2_exchange_rate b ON 1=1
     WHERE a.YYYYMMDD BETWEEN TIMESTAMPADD(DAY, -30, CURRENT_DATE) AND CURRENT_DATE
       AND NOT EXISTS (
             SELECT 1
               FROM tmp_ods_erp_exchange_rate_default aa
              WHERE aa.valid_from    = a.YYYYMMDD
                AND aa.from_currency = b.from_currency
                AND aa.to_currency   = b.to_currency
           )
       AND NOT EXISTS (
             SELECT 1
               FROM ow_lao.ft_ap2_exchange_rate aa
              WHERE aa.valid_from    = a.YYYYMMDD
                AND aa.from_currency = b.from_currency
                AND aa.to_currency   = b.to_currency
           )
     GROUP BY a.YYYYMMDD, b.from_currency, b.to_currency;

  PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_erp_exchange_rate_last_valid_from_value
  ( valid_from DATE,
    from_currency VARCHAR(255),
    to_currency   VARCHAR(255),
    exchange_rate DECIMAL(38,10) DEFAULT 0.00
  ) ON COMMIT PRESERVE ROWS;

  PERFORM INSERT INTO tmp_ods_erp_exchange_rate_last_valid_from_value
    SELECT MAX(b.valid_from - INTERVAL '1 day') AS valid_from,
           a.from_currency,
           a.to_currency,
           0.00
      FROM tmp_ods_erp_exchange_rate_default a
      JOIN ow_lao.ft_ap2_exchange_rate b
        ON b.from_currency = a.from_currency
       AND b.to_currency   = a.to_currency
     GROUP BY a.from_currency, a.to_currency;

  PERFORM UPDATE tmp_ods_erp_exchange_rate_default a
     SET exchange_rate = c.exchange_rate
    FROM tmp_ods_erp_exchange_rate_last_valid_from_value b
    JOIN ow_lao.ft_ap2_exchange_rate c
      ON c.from_currency = a.from_currency
     AND c.to_currency   = a.to_currency
     AND c.valid_from    = b.valid_from
   WHERE b.from_currency = a.from_currency
     AND b.to_currency   = a.to_currency;

  PERFORM INSERT INTO ow_lao.ft_ap2_exchange_rate
    (from_currency, to_currency, valid_from, exchange_rate, process_status, comment_status)
    SELECT from_currency,
           to_currency,
           valid_from,
           exchange_rate,
           'ADJUSTMENT' AS process_status,
           'Null on GERP' AS comment_status
      FROM tmp_ods_erp_exchange_rate_default;

END;
$$;

-- CALL OW_LAO.PROC_ERP_AP2_EXCHANGE_RATE();
-- ERROR: Severity: ERROR, Message: Operator does not exist: date = varchar, Sqlstate: 42883, Hint: No operator matches the given name and argument type(s). You may need to add explicit type casts, Where: PL/vSQL procedure PROC_ERP_AP2_EXCHANGE_RATE line 52 at static SQL, Routine: op_error, File: parse_oper.c, Line: 608, Error Code: 4286, 
-- CALL OW_LAO.PROC_ERP_AP2_EXCHANGE_RATE();
-- ERROR: Severity: ERROR, Message: Operator does not exist: date = varchar, Sqlstate: 42883, Hint: No operator matches the given name and argument type(s). You may need to add explicit type casts, Where: PL/vSQL procedure PROC_ERP_AP2_EXCHANGE_RATE line 52 at static SQL, Routine: op_error, File: parse_oper.c, Line: 608, Error Code: 4286, 
CREATE OR REPLACE PROCEDURE OW_LAO.PROC_ERP_AP2_EXCHANGE_RATE()
LANGUAGE PLvSQL AS $$
DECLARE
  load_date_newest DATE;
  load_date_not_exists BOOLEAN;
BEGIN

  SELECT MAX(a.load_date)
    INTO load_date_newest
    FROM ow_lao.ods_erp_exchange_rate a
   WHERE "Exchange Rate Type" = 'M';

  SELECT CASE WHEN COUNT(*) > 0 THEN true ELSE false END
    INTO load_date_not_exists
    FROM ow_lao.ft_ap2_exchange_rate b
   WHERE b.load_date = load_date_newest;

  IF NOT load_date_not_exists THEN

    PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_erp_exchange_rate_temp ON COMMIT PRESERVE ROWS AS
      SELECT
        "From currency" AS from_currency,
        "To-currency" AS to_currency,
        -- store as canonical string YYYY-MM-DD
        TO_CHAR(TO_DATE(REPLACE("Valid from", '.', '-'), 'YYYY-MM-DD'), 'YYYY-MM-DD') AS valid_from,
        CAST(REPLACE("Exchange Rate", ',', '') AS NUMERIC(38,10)) AS exchange_rate,
        load_date,
        CAST(NULL AS VARCHAR(256)) AS process_status,
        CAST(NULL AS VARCHAR(256)) AS comment_status,
        CAST(NULL AS INT) AS dedup
      FROM ow_lao.ods_erp_exchange_rate
      WHERE 1=0;

    PERFORM INSERT INTO tmp_ods_erp_exchange_rate_temp
      SELECT DISTINCT
        "From currency" AS from_currency,
        "To-currency" AS to_currency,
        TO_CHAR(TO_DATE(REPLACE("Valid from", '.', '-'), 'YYYY-MM-DD'), 'YYYY-MM-DD') AS valid_from,
        CAST(REPLACE("Exchange Rate", ',', '') AS NUMERIC(38,10)) AS exchange_rate,
        load_date AS load_date,
        NULL AS process_status,
        NULL AS comment_status,
        ROW_NUMBER() OVER(
          PARTITION BY "From currency", "To-currency", TO_CHAR(TO_DATE(REPLACE("Valid from", '.', '-'), 'YYYY-MM-DD'), 'YYYY-MM-DD')
          ORDER BY load_date DESC
        ) AS dedup
      FROM ow_lao.ods_erp_exchange_rate
      WHERE "Exchange Rate Type" = 'M'
        AND "Exchange Rate" IS NOT NULL
        AND load_date = load_date_newest;

    PERFORM DELETE FROM tmp_ods_erp_exchange_rate_temp WHERE dedup <> 1;

    PERFORM MERGE INTO ow_lao.ft_ap2_exchange_rate a
      USING tmp_ods_erp_exchange_rate_temp b
      ON b.from_currency = a.from_currency
     AND b.to_currency   = a.to_currency
     AND b.valid_from    = a.valid_from
     WHEN MATCHED THEN UPDATE SET
        load_date         = b.load_date,
        exchange_rate     = b.exchange_rate,
        process_status    = b.process_status,
        comment_status    = b.comment_status,
        updated_timestamp = CURRENT_TIMESTAMP
     WHEN NOT MATCHED THEN INSERT
        (from_currency, to_currency, valid_from, load_date, exchange_rate, process_status, comment_status)
        VALUES
        (b.from_currency, b.to_currency, b.valid_from, b.load_date, b.exchange_rate, b.process_status, b.comment_status);

  END IF;

  PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_erp_exchange_rate_default
  ( valid_from VARCHAR(10),
    from_currency VARCHAR(255),
    to_currency   VARCHAR(255),
    exchange_rate DECIMAL(38,10) DEFAULT 0.00
  ) ON COMMIT PRESERVE ROWS;

  PERFORM INSERT INTO tmp_ods_erp_exchange_rate_default
    SELECT TO_CHAR(a.YYYYMMDD, 'YYYY-MM-DD') AS valid_from,
           b."From currency" AS from_currency,
           b."To-currency" AS to_currency,
           CAST(0.00 AS DECIMAL(38,10)) AS exchange_rate
      FROM ow_md.dim_calendar a
      JOIN ow_lao.ods_erp_exchange_rate b ON 1=1
     WHERE a.YYYYMMDD BETWEEN TIMESTAMPADD(DAY, -30, CURRENT_DATE) AND CURRENT_DATE
       AND b."Exchange Rate Type" = 'M'
       AND b."Exchange Rate" IS NOT NULL
       AND NOT EXISTS (
             SELECT 1
               FROM ow_lao.ft_ap2_exchange_rate aa
              WHERE aa.valid_from    = TO_CHAR(a.YYYYMMDD, 'YYYY-MM-DD')
                AND aa.from_currency = b."From currency"
                AND aa.to_currency   = b."To-currency"
           )
     GROUP BY a.YYYYMMDD, b."From currency", b."To-currency";

  PERFORM INSERT INTO tmp_ods_erp_exchange_rate_default
    SELECT TO_CHAR(a.YYYYMMDD, 'YYYY-MM-DD') AS valid_from,
           b.from_currency,
           b.to_currency,
           CAST(0.00 AS DECIMAL(38,10)) AS exchange_rate
      FROM ow_md.dim_calendar a
      JOIN ow_lao.ft_ap2_exchange_rate b ON 1=1
     WHERE a.YYYYMMDD BETWEEN TIMESTAMPADD(DAY, -30, CURRENT_DATE) AND CURRENT_DATE
       AND NOT EXISTS (
             SELECT 1
               FROM tmp_ods_erp_exchange_rate_default aa
              WHERE aa.valid_from    = TO_CHAR(a.YYYYMMDD, 'YYYY-MM-DD')
                AND aa.from_currency = b.from_currency
                AND aa.to_currency   = b.to_currency
           )
       AND NOT EXISTS (
             SELECT 1
               FROM ow_lao.ft_ap2_exchange_rate aa
              WHERE aa.valid_from    = TO_CHAR(a.YYYYMMDD, 'YYYY-MM-DD')
                AND aa.from_currency = b.from_currency
                AND aa.to_currency   = b.to_currency
           )
     GROUP BY a.YYYYMMDD, b.from_currency, b.to_currency;

  PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_erp_exchange_rate_last_valid_from_value
  ( valid_from VARCHAR(10),
    from_currency VARCHAR(255),
    to_currency   VARCHAR(255),
    exchange_rate DECIMAL(38,10) DEFAULT 0.00
  ) ON COMMIT PRESERVE ROWS;

  PERFORM INSERT INTO tmp_ods_erp_exchange_rate_last_valid_from_value
    SELECT TO_CHAR(MAX(TO_DATE(b.valid_from, 'YYYY-MM-DD') - INTERVAL '1 day'), 'YYYY-MM-DD') AS valid_from,
           a.from_currency,
           a.to_currency,
           0.00
      FROM tmp_ods_erp_exchange_rate_default a
      JOIN ow_lao.ft_ap2_exchange_rate b
        ON b.from_currency = a.from_currency
       AND b.to_currency   = a.to_currency
     GROUP BY a.from_currency, a.to_currency;

  PERFORM UPDATE tmp_ods_erp_exchange_rate_default a
     SET exchange_rate = c.exchange_rate
    FROM tmp_ods_erp_exchange_rate_last_valid_from_value b
    JOIN ow_lao.ft_ap2_exchange_rate c
      ON c.from_currency = a.from_currency
     AND c.to_currency   = a.to_currency
     AND c.valid_from    = b.valid_from
   WHERE b.from_currency = a.from_currency
     AND b.to_currency   = a.to_currency;

  PERFORM INSERT INTO ow_lao.ft_ap2_exchange_rate
    (from_currency, to_currency, valid_from, exchange_rate, process_status, comment_status)
    SELECT from_currency,
           to_currency,
           valid_from,
           exchange_rate,
           'ADJUSTMENT' AS process_status,
           'Null on GERP' AS comment_status
      FROM tmp_ods_erp_exchange_rate_default;

END;
$$;

-- CALL OW_LAO.PROC_ERP_AP2_EXCHANGE_RATE();
-- ERROR: Severity: ERROR, Message: Relation "ow_md.dim_calendar" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_ERP_AP2_EXCHANGE_RATE line 78 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
-- CALL OW_LAO.PROC_ERP_AP2_EXCHANGE_RATE();
-- ERROR: Severity: ERROR, Message: Relation "ow_md.dim_calendar" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_ERP_AP2_EXCHANGE_RATE line 78 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
