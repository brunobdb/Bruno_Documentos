-- CREATE OR REPLACE PROCEDURE OW_LAO.PROC_RAW_VTEX_SSG_BR_B2B_SALES_ORDER_MONITORING_DATASOURCE()
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--     SELECT
--         CASE
--             WHEN MAX(creation_timestamp) <= TIMESTAMPADD(SECOND, -10800, CURRENT_TIMESTAMP) THEN 3
--             ELSE 2
--         END AS monitoring_execution_result_status,
--         'Last order imported was on : ' || TO_CHAR(MAX(creation_timestamp), 'YYYY-MM-DD HH24:MI:SS') AS value
--     FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_B2B_SALES_ORDER;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 9.52 of source string: syntax error, unexpected ;, expecting INTO, Sqlstate: 42601, Position: 479, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
CREATE OR REPLACE PROCEDURE OW_LAO.PROC_RAW_VTEX_SSG_BR_B2B_SALES_ORDER_MONITORING_DATASOURCE()
LANGUAGE PLvSQL AS $$
DECLARE
  monitoring_execution_result_status INT;
  value VARCHAR(256);
BEGIN
  SELECT CASE WHEN MAX(creation_timestamp) <= TIMESTAMPADD(SECOND, -10800, CURRENT_TIMESTAMP) THEN 3 ELSE 2 END,
         'Last order imported was on : ' || TO_CHAR(MAX(creation_timestamp), 'YYYY-MM-DD HH24:MI:SS')
  INTO monitoring_execution_result_status, value
  FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_B2B_SALES_ORDER;

  PERFORM DROP TABLE IF EXISTS TMP_PROC_RAW_VTEX_MONITOR_RESULT;
  PERFORM CREATE LOCAL TEMP TABLE TMP_PROC_RAW_VTEX_MONITOR_RESULT
    (monitoring_execution_result_status INT, value VARCHAR(256))
    ON COMMIT PRESERVE ROWS;

  PERFORM INSERT INTO TMP_PROC_RAW_VTEX_MONITOR_RESULT
    VALUES (monitoring_execution_result_status, value);

END;
$$;

-- CALL OW_LAO.PROC_RAW_VTEX_SSG_BR_B2B_SALES_ORDER_MONITORING_DATASOURCE();
-- ERROR: Severity: ERROR, Message: Column reference monitoring_execution_result_status is ambiguous, Sqlstate: 42702, Detail: It could refer to either a procedural language variable or a table column, Where: PL/vSQL procedure PROC_RAW_VTEX_SSG_BR_B2B_SALES_ORDER_MONITORING_DATASOURCE line 12 at static SQL, Routine: transformColumnRef, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Optimizer/OptUtil/ExprUtil.cpp, Line: 7480, Error Code: 10341, 
-- CALL OW_LAO.PROC_RAW_VTEX_SSG_BR_B2B_SALES_ORDER_MONITORING_DATASOURCE();
-- ERROR: Severity: ERROR, Message: Column reference monitoring_execution_result_status is ambiguous, Sqlstate: 42702, Detail: It could refer to either a procedural language variable or a table column, Where: PL/vSQL procedure PROC_RAW_VTEX_SSG_BR_B2B_SALES_ORDER_MONITORING_DATASOURCE line 12 at static SQL, Routine: transformColumnRef, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Optimizer/OptUtil/ExprUtil.cpp, Line: 7480, Error Code: 10341, 
CREATE OR REPLACE PROCEDURE OW_LAO.PROC_RAW_VTEX_SSG_BR_B2B_SALES_ORDER_MONITORING_DATASOURCE()
LANGUAGE PLvSQL AS $$
DECLARE
  v_status INT;
  v_value VARCHAR(256);
BEGIN
  SELECT CASE WHEN MAX(creation_timestamp) <= TIMESTAMPADD(SECOND, -10800, CURRENT_TIMESTAMP) THEN 3 ELSE 2 END,
         'Last order imported was on : ' || TO_CHAR(MAX(creation_timestamp), 'YYYY-MM-DD HH24:MI:SS')
  INTO v_status, v_value
  FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_B2B_SALES_ORDER;

  PERFORM DROP TABLE IF EXISTS TMP_PROC_RAW_VTEX_MONITOR_RESULT;
  PERFORM CREATE LOCAL TEMP TABLE TMP_PROC_RAW_VTEX_MONITOR_RESULT
    (monitoring_execution_result_status INT, value VARCHAR(256))
    ON COMMIT PRESERVE ROWS;

  PERFORM INSERT INTO TMP_PROC_RAW_VTEX_MONITOR_RESULT
    VALUES (v_status, v_value);

END;
$$;

CALL OW_LAO.PROC_RAW_VTEX_SSG_BR_B2B_SALES_ORDER_MONITORING_DATASOURCE();
-- PROC_RAW_VTEX_SSG_BR_B2B_SALES_ORDER_MONITORING_DATASOURCE
-- ----------------------------------------------------------
-- 0

