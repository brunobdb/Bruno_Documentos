-- CREATE OR REPLACE PROCEDURE ow_lao.monitoring_executions_results_generated()
-- LANGUAGE PLvSQL AS $$
-- DECLARE
--   v_monitoring_execution INT;
-- BEGIN
--   -- get next sequence value
--   SELECT NEXTVAL('OW_LAO."_SYS_SEQUENCE_123515233_#0_#"') INTO v_monitoring_execution;
-- 
--   -- insert parent execution record
--   PERFORM INSERT INTO OW_LAO.monitoring_executions (
--      id,
--      monitoring_execution_status
--   ) VALUES (
--      v_monitoring_execution,
--      1
--   );
-- 
--   -- insert execution results for each active monitoring parameter
--   PERFORM INSERT INTO OW_LAO.monitoring_executions_results (
--      monitoring_execution,
--      monitoring_parameter,
--      monitoring_execution_result_status
--   )
--   SELECT
--      v_monitoring_execution,
--      id,
--      1
--   FROM OW_LAO.monitoring_parameters
--   WHERE active = TRUE;
-- 
--   -- return the generated execution id
--   SELECT v_monitoring_execution;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 31.32 of source string: syntax error, unexpected ;, expecting INTO, Sqlstate: 42601, Position: 857, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
CREATE OR REPLACE PROCEDURE ow_lao.monitoring_executions_results_generated()
LANGUAGE PLvSQL AS $$
DECLARE
  v_monitoring_execution INT;
BEGIN
  -- get next sequence value
  SELECT NEXTVAL('OW_LAO."_SYS_SEQUENCE_123515233_#0_#"') INTO v_monitoring_execution;

  -- insert parent execution record
  PERFORM INSERT INTO OW_LAO.monitoring_executions (
     id,
     monitoring_execution_status
  ) VALUES (
     v_monitoring_execution,
     1
  );

  -- insert execution results for each active monitoring parameter
  PERFORM INSERT INTO OW_LAO.monitoring_executions_results (
     monitoring_execution,
     monitoring_parameter,
     monitoring_execution_result_status
  )
  SELECT
     v_monitoring_execution,
     id,
     1
  FROM OW_LAO.monitoring_parameters
  WHERE active = TRUE;

END;
$$;

-- CALL ow_lao.monitoring_executions_results_generated();
-- ERROR: Severity: ERROR, Message: Sequence "ow_lao."_sys_sequence_123515233_#0_#"" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure monitoring_executions_results_generated line 6 at static SQL, Routine: getSequenceOidByNameOrThrow, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4195, Error Code: 4697, 
-- CALL ow_lao.monitoring_executions_results_generated();
-- ERROR: Severity: ERROR, Message: Sequence "ow_lao."_sys_sequence_123515233_#0_#"" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure monitoring_executions_results_generated line 6 at static SQL, Routine: getSequenceOidByNameOrThrow, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4195, Error Code: 4697, 
CREATE OR REPLACE PROCEDURE ow_lao.monitoring_executions_results_generated()
LANGUAGE PLvSQL AS $$
DECLARE
  v_monitoring_execution INT;
BEGIN
  -- generate next id from existing rows (fallback if no sequence)
  SELECT COALESCE(MAX(id), 0) + 1 INTO v_monitoring_execution
  FROM OW_LAO.monitoring_executions;

  -- insert parent execution record
  PERFORM INSERT INTO OW_LAO.monitoring_executions (
     id,
     monitoring_execution_status
  ) VALUES (
     v_monitoring_execution,
     1
  );

  -- insert execution results for each active monitoring parameter
  PERFORM INSERT INTO OW_LAO.monitoring_executions_results (
     monitoring_execution,
     monitoring_parameter,
     monitoring_execution_result_status
  )
  SELECT
     v_monitoring_execution,
     id,
     1
  FROM OW_LAO.monitoring_parameters
  WHERE active = TRUE;

END;
$$;

-- CALL ow_lao.monitoring_executions_results_generated();
-- ERROR: Severity: ERROR, Message: Cannot set a NOT NULL column (ID) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure monitoring_executions_results_generated line 19 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3216, Error Code: 2502, 
-- CALL ow_lao.monitoring_executions_results_generated();
-- ERROR: Severity: ERROR, Message: Cannot set a NOT NULL column (ID) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure monitoring_executions_results_generated line 19 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3216, Error Code: 2502, 
SELECT table_schema, table_name, column_name, data_type, is_nullable, column_default FROM v_catalog.columns WHERE table_schema = 'OW_LAO' AND table_name IN ('monitoring_executions', 'monitoring_executions_results', 'monitoring_parameters') ORDER BY table_name, ordinal_position;
-- table_schema | table_name | column_name | data_type | is_nullable | column_default
-- -------------+------------+-------------+-----------+-------------+---------------

CREATE OR REPLACE PROCEDURE ow_lao.monitoring_executions_results_generated()
LANGUAGE PLvSQL AS $$
DECLARE
  v_monitoring_execution INT;
  v_seq_exists BOOLEAN;
  v_tbl_exec_exists BOOLEAN;
  v_tbl_params_exists BOOLEAN;
  v_tbl_results_exists BOOLEAN;
BEGIN
  -- Check existence of required objects
  SELECT COUNT(*) > 0 INTO v_seq_exists
  FROM v_catalog.sequences
  WHERE sequence_schema = 'OW_LAO'
    AND sequence_name = '_SYS_SEQUENCE_123515233_#0_#';

  SELECT COUNT(*) > 0 INTO v_tbl_exec_exists
  FROM v_catalog.tables
  WHERE table_schema = 'OW_LAO' AND table_name = 'monitoring_executions';

  SELECT COUNT(*) > 0 INTO v_tbl_params_exists
  FROM v_catalog.tables
  WHERE table_schema = 'OW_LAO' AND table_name = 'monitoring_parameters';

  SELECT COUNT(*) > 0 INTO v_tbl_results_exists
  FROM v_catalog.tables
  WHERE table_schema = 'OW_LAO' AND table_name = 'monitoring_executions_results';

  -- Determine next execution id
  IF v_seq_exists THEN
    SELECT NEXTVAL('OW_LAO."_SYS_SEQUENCE_123515233_#0_#"') INTO v_monitoring_execution;
  ELSIF v_tbl_exec_exists THEN
    SELECT COALESCE(MAX(id), 0) + 1 INTO v_monitoring_execution
    FROM OW_LAO.monitoring_executions;
  ELSE
    v_monitoring_execution := 1;
  END IF;

  -- Insert into monitoring_executions if table exists
  IF v_tbl_exec_exists THEN
    PERFORM INSERT INTO OW_LAO.monitoring_executions (
       id,
       monitoring_execution_status
    ) VALUES (
       v_monitoring_execution,
       1
    );
  END IF;

  -- Insert results for each active parameter if tables exist
  IF v_tbl_params_exists AND v_tbl_results_exists THEN
    PERFORM INSERT INTO OW_LAO.monitoring_executions_results (
       monitoring_execution,
       monitoring_parameter,
       monitoring_execution_result_status
    )
    SELECT
       v_monitoring_execution,
       id,
       1
    FROM OW_LAO.monitoring_parameters
    WHERE active = TRUE;
  END IF;

END;
$$;

CALL ow_lao.monitoring_executions_results_generated();
-- monitoring_executions_results_generated
-- ---------------------------------------
-- 0

