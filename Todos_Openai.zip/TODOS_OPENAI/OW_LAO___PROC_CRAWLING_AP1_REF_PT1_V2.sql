CREATE OR REPLACE PROCEDURE PROC_CRAWLING_AP1_REF_PT1_V2()
LANGUAGE PLvSQL AS $$
BEGIN
  
  PERFORM TRUNCATE TABLE OW_LAO.TF_CRAWLING_AP1_REF_1;
  
  PERFORM INSERT INTO OW_LAO.TF_CRAWLING_AP1_REF_1
  SELECT DISTINCT
    TRIM(UPPER(SUBSTR(D."PROD_BRAND", 1, 99))) AS brand_nm,
    SUBSTR(CAST(D."MODEL" AS VARCHAR), 1, 99) AS model_nm,
    SUBSTR(CAST(D."DESC" AS VARCHAR), 1, 99) AS model_desc,
    SUBSTR(CAST(P."SUB" AS VARCHAR), 1, 99) AS subsidiary,
    SUBSTR(CAST(D."COUNTRY" AS VARCHAR), 1, 99) AS country,
    SUBSTR(CAST(D."COUNTRY" AS VARCHAR), 1, 99) AS country_code,
    SUBSTR(CAST(D."COMPANY_NAME" AS VARCHAR), 1, 99) AS site_company_name,
    SUBSTR(CAST(P."SITE" AS VARCHAR), 1, 99) AS site_nm,
    SUBSTR(CAST(D."PROD_HREF" AS VARCHAR), 1, 499) AS site_url,
    SUBSTR(CAST(P."PAGE_NUMBER" AS VARCHAR), 1, 99) AS site_page,
    SUBSTR(CAST(P."POSITION" AS VARCHAR), 1, 99) AS site_position,
    SUBSTR(CAST(D."CURRENCY" AS VARCHAR), 1, 99) AS site_price_currency,
    SUBSTR(CAST(DR."RATING" AS VARCHAR), 1, 99) AS site_rating,
    SUBSTR(CAST(DR."RATING_AMOUNT" AS VARCHAR), 1, 99) AS site_rating_amount,
    SUBSTR(CAST(DR."RATING_SCALE" AS VARCHAR), 1, 99) AS site_rating_scale,
    SUBSTR(TO_CHAR(P."TODAY_DATE_TIME", 'YYYY-MM-DD HH24:MI'), 1, 99) AS refer_date,
    SUBSTR(CAST(P."POR_VALUE" AS VARCHAR), 1, 16) AS price_unit,
    SUBSTR(CAST(D."MODEL2" AS VARCHAR), 1, 99) AS MODEL2,
    SUBSTR(CAST(D."REF" AS VARCHAR), 1, 99) AS REF,
    SUBSTR(CAST(D."REF2" AS VARCHAR), 1, 99) AS REF2,
    SUBSTR(CAST(P."DE_VALUE" AS VARCHAR), 1, 16) AS retail_price_base,
    SUBSTR(CAST(P."POR_VALUE" AS VARCHAR), 1, 16) AS retail_price_actual,
    SUBSTR(TO_CHAR(P."TODAY_DATE_TIME", 'YYYY-MM-DD HH24:MI'), 1, 99) AS crawling_date,
    SUBSTR(CAST(P.AVAILABLE AS VARCHAR), 1, 99) AS product_available,
    NULL AS process_status,
    NULL AS comment_status,
    SUBSTR(TO_CHAR(D.LAST_UPDATE, 'YYYY-MM-DD HH24:MI'), 1, 99) AS product_update_date,
    CURRENT_TIMESTAMP AS process_datetime
  FROM "ODS_CRAWLING_AP1_IM_PRODUCT_DAILY_PRICE" P
  INNER JOIN "ODS_CRAWLING_AP1_REF_PRODUCT_DETAIL" D
    ON P."KEY" = D."KEY"
  LEFT JOIN "ODS_CRAWLING_AP1_REF_PRODUCT_DETAIL_DAILY" DR
    ON P."KEY" = DR."KEY" AND TO_CHAR(P."TODAY_DATE_TIME", 'YYYY-MM-DD') = TO_CHAR(DR."LOAD_DATE", 'YYYY-MM-DD')
  WHERE P."TODAY_DATE_TIME" > TIMESTAMP '2020-06-27 00:00:00'
    AND TO_CHAR(P."TODAY_DATE_TIME", 'YYYY-MM-DD') < TO_CHAR(CURRENT_DATE, 'YYYY-MM-DD')
    AND UPPER(TRIM(P."PRODUCT_TYPE")) = 'REF';

  /* Provisional code for Liverpool Mexico price fix */
  PERFORM UPDATE OW_LAO.TF_CRAWLING_AP1_REF_1 ORIG
  SET "RETAIL_PRICE_ACTUAL" = DEST.NEW_LIVER_ACT,
      "PRICE_UNIT" = DEST.NEW_LIVER_UNIT
  FROM (
    WITH mx_stats AS (
      SELECT AVG(LENGTH("RETAIL_PRICE_ACTUAL")) + 1 AS avg_act_len,
             AVG(LENGTH("PRICE_UNIT")) + 1 AS avg_unit_len
      FROM OW_LAO.TF_CRAWLING_AP1_REF_1
      WHERE "COUNTRY" = 'MX'
        AND PRICE_UNIT <> '0.0'
        AND PRICE_UNIT <> '0'
        AND TRIM(PRICE_UNIT) <> ''
        AND RETAIL_PRICE_ACTUAL <> '0.0'
        AND RETAIL_PRICE_ACTUAL <> '0'
        AND TRIM(RETAIL_PRICE_ACTUAL) <> ''
    ),
    liver AS (
      SELECT 
        "SITE_URL" AS LIVER_URL,
        LENGTH(PRICE_UNIT) AS LIVER_UNIT_LEGTH,
        PRICE_UNIT AS LIVER_PRICE_UNIT,
        LENGTH(RETAIL_PRICE_BASE) AS LIVER_BASE_LEGTH,
        RETAIL_PRICE_BASE AS LIVER_RETAIL_PRICE_BASE,
        LENGTH(RETAIL_PRICE_ACTUAL) AS LIVER_ACT_LEGTH,
        RETAIL_PRICE_ACTUAL AS LIVER_RETAIL_PRICE_ACTUAL
      FROM OW_LAO.TF_CRAWLING_AP1_REF_1
      WHERE "SITE_URL" ILIKE '%liverpoo%.mx%'
        AND PRICE_UNIT <> '0.0'
        AND PRICE_UNIT <> '0'
        AND TRIM(PRICE_UNIT) <> ''
        AND RETAIL_PRICE_ACTUAL <> '0.0'
        AND RETAIL_PRICE_ACTUAL <> '0'
        AND TRIM(RETAIL_PRICE_ACTUAL) <> ''
      GROUP BY "SITE_URL", PRICE_UNIT, RETAIL_PRICE_BASE, RETAIL_PRICE_ACTUAL
    )
    SELECT 
      LIVER_URL,
      LIVER_RETAIL_PRICE_BASE,
      LIVER_RETAIL_PRICE_ACTUAL,
      LIVER_UNIT_LEGTH,
      LIVER_ACT_LEGTH,
      LIVER_PRICE_UNIT,
      CASE WHEN LIVER_ACT_LEGTH >= (SELECT avg_act_len FROM mx_stats)
           THEN LIVER_RETAIL_PRICE_BASE ELSE LIVER_RETAIL_PRICE_ACTUAL END AS NEW_LIVER_ACT,
      CASE WHEN LIVER_UNIT_LEGTH >= (SELECT avg_unit_len FROM mx_stats)
           THEN LIVER_RETAIL_PRICE_BASE ELSE LIVER_PRICE_UNIT END AS NEW_LIVER_UNIT
    FROM liver
  ) DEST
  WHERE DEST.LIVER_URL = ORIG."SITE_URL"
    AND ORIG."COUNTRY" = 'MX'
    AND PRICE_UNIT <> '0.0'
    AND PRICE_UNIT <> '0'
    AND TRIM(PRICE_UNIT) <> ''
    AND RETAIL_PRICE_ACTUAL <> '0.0'
    AND RETAIL_PRICE_ACTUAL <> '0'
    AND TRIM(RETAIL_PRICE_ACTUAL) <> '';

  /* If model_nm is empty or null, use part of site_url instead */
  PERFORM UPDATE OW_LAO.TF_CRAWLING_AP1_REF_1
  SET 
    model_nm = CASE WHEN TRIM(model_nm) = '' OR model_nm IS NULL
                    THEN SUBSTR(REPLACE(TRIM(site_url), TRIM(site_nm), ''), 1, 99)
                    ELSE TRIM(model_nm) END;

  /* Replace null ratings with empty string for mapping */
  PERFORM UPDATE OW_LAO.TF_CRAWLING_AP1_REF_1
  SET
    site_rating = COALESCE(site_rating, ''),
    site_rating_amount = COALESCE(site_rating_amount, ''),
    site_rating_scale = COALESCE(site_rating_scale, '');

  /* Extract numeric portions using regex */
  PERFORM UPDATE OW_LAO.TF_CRAWLING_AP1_REF_1
  SET
    site_rating = REGEXP_SUBSTR(UPPER(TRIM(REPLACE(site_rating, ',', '.'))), '[0-9]+(\\.[0-9]{1,2})?', 1, 1),
    site_rating_amount = REGEXP_SUBSTR(UPPER(TRIM(site_rating_amount)), '[0-9]+(\\.[0-9]{1,2})?', 1, 1),
    site_rating_scale = REGEXP_SUBSTR(UPPER(TRIM(site_rating_scale)), '[0-9]+(\\.[0-9]{1,2})?', 1, 1),
    price_unit = REGEXP_SUBSTR(UPPER(TRIM(price_unit)), '[0-9]+(\\.[0-9]{1,2})?', 1, 1),
    retail_price_base = REGEXP_SUBSTR(UPPER(TRIM(retail_price_base)), '[0-9]+(\\.[0-9]{1,2})?', 1, 1),
    retail_price_actual = REGEXP_SUBSTR(UPPER(TRIM(retail_price_actual)), '[0-9]+(\\.[0-9]{1,2})?', 1, 1);

  PERFORM TRUNCATE TABLE OW_LAO.TF_CRAWLING_AP1_REF_2;

  PERFORM INSERT INTO OW_LAO.TF_CRAWLING_AP1_REF_2
  SELECT
    UPPER(TRIM(INITCAP(brand_nm))) AS brand_nm,
    ' ' AS mktcode,
    ' ' AS mktname,
    model_nm AS model_nm,
    subsidiary,
    country,
    country_code,
    UPPER(TRIM(site_company_name)) AS site_company_name,
    site_nm,
    site_url,
    site_page,
    site_position,
    site_price_currency,
    CASE WHEN TRIM(site_rating) = '' THEN NULL ELSE CAST(site_rating AS DECIMAL(8,1)) END AS site_rating,
    CASE WHEN TRIM(site_rating_amount) = '' THEN NULL ELSE CAST(site_rating_amount AS DECIMAL(8,0)) END AS site_rating_amount,
    CASE WHEN TRIM(site_rating_scale) = '' THEN NULL ELSE CAST(site_rating_scale AS DECIMAL(8,0)) END AS site_rating_scale,
    TO_TIMESTAMP(refer_date, 'YYYY-MM-DD HH24:MI') AS refer_date,
    ROUND(MAX(CAST(NULLIF(retail_price_actual,'') AS NUMERIC(18,4))), 2) AS price_unit,
    ROUND(MAX(CAST(NULLIF(retail_price_base,'') AS NUMERIC(18,4))), 2) AS price_local_base,
    ROUND(MAX(CAST(NULLIF(retail_price_actual,'') AS NUMERIC(18,4))), 2) AS price_local_act,
    'Y' AS update_flg,
    CURRENT_TIMESTAMP
  FROM OW_LAO.TF_CRAWLING_AP1_REF_1
  WHERE process_status IS NULL
  GROUP BY 
    UPPER(TRIM(INITCAP(brand_nm))),
    model_nm,
    subsidiary,
    country,
    country_code,
    UPPER(TRIM(site_company_name)),
    site_nm,
    site_url,
    site_page,
    site_position,
    site_price_currency,
    CASE WHEN TRIM(site_rating) = '' THEN NULL ELSE CAST(site_rating AS DECIMAL(8,1)) END,
    CASE WHEN TRIM(site_rating_amount) = '' THEN NULL ELSE CAST(site_rating_amount AS DECIMAL(8,0)) END,
    CASE WHEN TRIM(site_rating_scale) = '' THEN NULL ELSE CAST(site_rating_scale AS DECIMAL(8,0)) END,
    TO_TIMESTAMP(refer_date, 'YYYY-MM-DD HH24:MI');

  PERFORM CALL PROC_CRAWLING_AP1_REF_SITE_MAPPING_MERGE_AUTOMATIC();

  PERFORM TRUNCATE TABLE OW_LAO.FT_CRAWLING_AP1_REF_DISPLAY_SHARE;

  PERFORM INSERT INTO OW_LAO.FT_CRAWLING_AP1_REF_DISPLAY_SHARE
  SELECT * FROM VW_CRAWLING_AP1_REF_DISPLAY_SHARE;

  PERFORM TRUNCATE TABLE OW_LAO.FT_CRAWLING_AP1_REF_SEGMENT;

  PERFORM INSERT INTO OW_LAO.FT_CRAWLING_AP1_REF_SEGMENT
  SELECT *
       , NULL AS REFER_WEEK
       , NULL AS REFER_WEEK_T
       , NULL AS REFER_YEAR
  FROM VW_CRAWLING_AP1_REF_SEGMENT;

  PERFORM UPDATE OW_LAO.FT_CRAWLING_AP1_REF_SEGMENT F
  SET
    REFER_WEEK = (SELECT DISTINCT YYYYWW FROM OW_MD.DIM_CALENDAR D WHERE TO_CHAR(F.REFER_DATE,'YYYY-MM-DD') = TO_CHAR(D.YYYYMMDD,'YYYY-MM-DD')),
    REFER_WEEK_T = (SELECT DISTINCT 'W' || RIGHT(YYYYWW,2) FROM OW_MD.DIM_CALENDAR D WHERE TO_CHAR(F.REFER_DATE,'YYYY-MM-DD') = TO_CHAR(D.YYYYMMDD,'YYYY-MM-DD')),
    REFER_YEAR = (SELECT DISTINCT YYYY FROM OW_MD.DIM_CALENDAR D WHERE TO_CHAR(F.REFER_DATE,'YYYY-MM-DD') = TO_CHAR(D.YYYYMMDD,'YYYY-MM-DD'))
  WHERE REFER_WEEK IS NULL;

END;
$$;

-- CALL PROC_CRAWLING_AP1_REF_PT1_V2();
-- ERROR: Severity: ROLLBACK, Message: Table "TF_CRAWLING_AP1_REF_1" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_CRAWLING_AP1_REF_PT1_V2 line 4 at static SQL, Routine: TruncateTable, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Commands/DDL.cpp, Line: 20681, Error Code: 4876, 
-- CALL PROC_CRAWLING_AP1_REF_PT1_V2();
-- ERROR: Severity: ROLLBACK, Message: Table "TF_CRAWLING_AP1_REF_1" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_CRAWLING_AP1_REF_PT1_V2 line 4 at static SQL, Routine: TruncateTable, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Commands/DDL.cpp, Line: 20681, Error Code: 4876, 
