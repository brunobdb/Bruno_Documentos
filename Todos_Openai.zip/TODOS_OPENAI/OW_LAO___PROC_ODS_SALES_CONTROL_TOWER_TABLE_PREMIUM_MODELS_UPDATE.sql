CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_sales_control_tower_table_premium_models_update()
LANGUAGE PLvSQL AS $$
BEGIN
    
    PERFORM UPDATE ow_lao.ods_sales_control_tower_table a
           SET premiumproduct = 1
    FROM OW_MD.DIM_CALENDAR b
    JOIN OW_LAO.ODS_LAO_PRODUCT_PREMIUM_ITEMS c ON c.PLAN = b.YYYYWW_NORMAL_CALENDAR
    WHERE 
        b.YYYYMMDD = CAST(a.PO_DATE AS DATE)
        AND c.ITEM = a.PO_SKU 
        AND a.SUBSIDIARY = c.AP2
        AND a.premiumproduct IS NULL
        AND CAST(a.PO_DATE AS DATE) >= DATE '2023-06-12';
                
    PERFORM UPDATE ow_lao.ods_sales_control_tower_table a
           SET premiumproduct = 1
    FROM OW_MD.DIM_CALENDAR b
    JOIN OW_LAO.ODS_LAO_PRODUCT_PREMIUM_ITEMS c ON c.PLAN = b.YYYYWW_NORMAL_CALENDAR
    WHERE 
        b.YYYYMMDD = CAST(a.PO_DATE AS DATE)
        AND c.ITEM = a.PO_SKU 
        AND c.AP2 IN ('SELA-M','SELA-P')
        AND a.premiumproduct IS NULL
        AND a.client_subsidiary_id IN (7, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19)
        AND CAST(a.PO_DATE AS DATE) >= DATE '2023-06-12';

    PERFORM UPDATE ow_lao.ods_sales_control_tower_table a
    SET premiumproduct = 0
    WHERE premiumproduct IS NULL
      AND CAST(a.PO_DATE AS DATE) >= DATE '2023-06-12';

END
$$;

-- CALL OW_LAO.proc_ods_sales_control_tower_table_premium_models_update();
-- ERROR: Severity: ERROR, Message: Relation "OW_MD.DIM_CALENDAR" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ods_sales_control_tower_table_premium_models_update line 4 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
-- CALL OW_LAO.proc_ods_sales_control_tower_table_premium_models_update();
-- ERROR: Severity: ERROR, Message: Relation "OW_MD.DIM_CALENDAR" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ods_sales_control_tower_table_premium_models_update line 4 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
