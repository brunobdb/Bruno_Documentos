CREATE OR REPLACE PROCEDURE OW_SEDA_S.PRC_CE_UPDATE_STORE_NAME(SITE_ID_REF VARCHAR(50))
LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM UPDATE OW_SEDA_S.MAP_CE_STORES mcs
    SET 
        STORE_COMPLETE_NAME = 
            CASE WHEN mcs.ACCOUNT = mcs.CHANNEL THEN mcs.ACCOUNT ELSE mcs.ACCOUNT || ' - ' || mcs.CHANNEL END
            || COALESCE(' - ' || LPAD(CAST(mcs.BRANCH_NUMBER AS VARCHAR), 4, '0'), '')
            || COALESCE(' - ' || mcs.SHOPPING_CENTER_STORE, '')
            || ' - ' || mcs.NOME_DO_MUNICIPIO_STORE
            || ' - ' ||
            TRIM(BOTH ' ' FROM SUBSTR(
                mcs.COMPLETE_OFFICIAL_ADDRESS_STORE,
                INSTR(mcs.COMPLETE_OFFICIAL_ADDRESS_STORE, ',', 1, 2) + 1,
                INSTR(mcs.COMPLETE_OFFICIAL_ADDRESS_STORE, ',', 1, 3) - INSTR(mcs.COMPLETE_OFFICIAL_ADDRESS_STORE, ',', 1, 2) - 1
            ))
            || ' - ' ||
            mcs.SIGLA_DA_UF_STORE,
        STORE_SHORT_NAME =
            CASE WHEN mcs.ACCOUNT = mcs.CHANNEL THEN '' ELSE mcs.CHANNEL || ' - ' END
            || COALESCE(LPAD(CAST(mcs.BRANCH_NUMBER AS VARCHAR), 4, '0') || ' - ', '')
            || COALESCE(mcs.SHOPPING_CENTER_STORE || ' - ', '')
            || mcs.NOME_DO_MUNICIPIO_STORE
            || ' - ' ||
            TRIM(BOTH ' ' FROM SUBSTR(
                mcs.COMPLETE_OFFICIAL_ADDRESS_STORE,
                INSTR(mcs.COMPLETE_OFFICIAL_ADDRESS_STORE, ',', 1, 2) + 1,
                INSTR(mcs.COMPLETE_OFFICIAL_ADDRESS_STORE, ',', 1, 3) - INSTR(mcs.COMPLETE_OFFICIAL_ADDRESS_STORE, ',', 1, 2) - 1
            ))
            || ' - ' ||
            mcs.SIGLA_DA_UF_STORE
    WHERE mcs.SITE_ID = SITE_ID_REF;
END
$$;

CALL OW_SEDA_S.PRC_CE_UPDATE_STORE_NAME('12345');
-- PRC_CE_UPDATE_STORE_NAME
-- ------------------------
-- 0

