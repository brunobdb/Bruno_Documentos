-- CREATE OR REPLACE PROCEDURE PROC_CRAWLING_AP1_IM_PT1_HISTORICO()
-- LANGUAGE PLvSQL AS $$
-- DECLARE 
--   _loopnum INTEGER;
--   _case_str VARCHAR(200);
--   _vp_query VARCHAR(65000);
--   i INTEGER;
-- BEGIN
--   -- Update HEIGHT values with overly long length
--   PERFORM UPDATE "OW_LAO"."ODS_CRAWLING_AP1_IM_PRODUCT_DETAIL"
--     SET "HEIGHT" = "HEIGHT" / 1000000000000
--     WHERE LENGTH(CAST("HEIGHT" AS VARCHAR)) > 11;
-- 
--   -- Stage load into TF_CRAWLING_AP1_IM_1
--   PERFORM TRUNCATE TABLE TF_CRAWLING_AP1_IM_1;
-- 
--   PERFORM INSERT INTO TF_CRAWLING_AP1_IM_1
--   SELECT DISTINCT
--     SUBSTRING(D."PROD_BRAND", 1, 99) AS brand_nm,
--     SUBSTRING(D."MODEL", 1, 99) AS model_nm,
--     SUBSTRING(D."DESC", 1, 99) AS model_desc,
--     SUBSTRING(P."SUB", 1, 99) AS subsidiary,
--     SUBSTRING(D."COUNTRY", 1, 99) AS country,
--     SUBSTRING(D."COUNTRY", 1, 99) AS country_code,
--     SUBSTRING(D."COMPANY_NAME", 1, 99) AS site_company_name,
--     SUBSTRING(P."SITE", 1, 99) AS site_nm,
--     SUBSTRING(D."PROD_HREF", 1, 499) AS site_url,
--     SUBSTRING(P."PAGE_NUMBER", 1, 99) AS site_page,
--     SUBSTRING(P."POSITION", 1, 99) AS site_position,
--     SUBSTRING(CASE WHEN P."CURRENCY" IS NULL OR P."CURRENCY" = '' THEN D."CURRENCY" ELSE P."CURRENCY" END, 1, 99) AS site_price_currency,
--     SUBSTRING(R."RATING", 1, 99) AS site_rating,
--     SUBSTRING(R."RATING_AMOUNT", 1, 99) AS site_rating_amount,
--     SUBSTRING(R."RATING_SCALE", 1, 99) AS site_rating_scale,
--     SUBSTRING(P."TODAY_DATE_TIME", 1, 99) AS refer_date,
--     SUBSTRING(CASE WHEN P."POR_VALUE" IS NULL THEN P."DE_VALUE" WHEN P."POR_VALUE" = '' THEN P."DE_VALUE" ELSE P."POR_VALUE" END, 1, 16) AS price_unit,
--     SUBSTRING(D."WIDTH", 1, 99) AS width_mm,
--     SUBSTRING(D."HEIGHT", 1, 99) AS height_mm,
--     SUBSTRING(D."DEPTH", 1, 99) AS depth_mm,
--     SUBSTRING(D."DISPLAY_SIZE", 1, 99) AS display_size,
--     SUBSTRING(D."RAM", 1, 99) AS ram_in_mb,
--     SUBSTRING(D."CAPA", 1, 99) AS internal_storage,
--     SUBSTRING(D."DUAL_SIM", 1, 99) AS dual_sim,
--     SUBSTRING(D."CAMERA_REAR_RESO", 1, 99) AS main_camera_mp,
--     SUBSTRING(D."CAMERA_FRONT_RESO", 1, 99) AS front_camera_mp,
--     SUBSTRING(D."WEIGTH", 1, 16) AS weight_gramm,
--     SUBSTRING(D."DISPLAY_HORIZONTAL", 1, 99) AS resolution_wid,
--     SUBSTRING(D."DISPLAY_VERTICAL", 1, 99) AS resolution_hig,
--     SUBSTRING(D."BATTERY", 1, 99) AS battery_capacity,
--     SUBSTRING(P."DE_VALUE", 1, 16) AS retail_price_base,
--     SUBSTRING(P."POR_VALUE", 1, 16) AS retail_price_actual,
--     NULL AS upfront_base,
--     NULL AS monthly_device_actual,
--     NULL AS contract_period,
--     SUBSTRING(P."TODAY_DATE_TIME", 1, 99) AS crawling_date,
--     SUBSTRING(P.AVAILABLE, 1, 99) AS product_available,
--     NULL AS process_status,
--     NULL AS comment_status,
--     SUBSTRING(D.LAST_UPDATE, 1, 99) AS product_update_date,
--     NOW() AS process_datetime
--   FROM "ODS_CRAWLING_AP1_IM_PRODUCT_DAILY_PRICE" P
--   INNER JOIN "ODS_CRAWLING_AP1_IM_PRODUCT_DETAIL" D
--     ON P."KEY" = D."KEY"
--   LEFT JOIN "ODS_CRAWLING_AP1_IM_PRODUCT_DETAIL_DAILY" R
--     ON P."KEY" = R."KEY"
--    AND TO_CHAR(P."TODAY_DATE_TIME", 'YYYY-MM-DD') = TO_CHAR(R."LOAD_DATE", 'YYYY-MM-DD')
--   WHERE UPPER(TRIM(PRODUCT_TYPE)) = 'SMARTPHONE';
-- 
--   -- Delete rows with all attributes null/empty, except mapped URLs
--   PERFORM UPDATE TF_CRAWLING_AP1_IM_1
--      SET process_status = 'DELETED_BY_PROCESS',
--          comment_status = 'No attributes'
--    WHERE (width_mm IS NULL OR width_mm = '')
--      AND (height_mm IS NULL OR height_mm = '')
--      AND (depth_mm IS NULL OR depth_mm = '')
--      AND (display_size IS NULL OR display_size = '')
--      AND (ram_in_mb IS NULL OR ram_in_mb = '')
--      AND (internal_storage IS NULL OR internal_storage = '')
--      AND (dual_sim IS NULL OR dual_sim = '')
--      AND (main_camera_mp IS NULL OR main_camera_mp = '')
--      AND (front_camera_mp IS NULL OR front_camera_mp = '')
--      AND (weight_gramm IS NULL OR weight_gramm = '')
--      AND (resolution_wid IS NULL OR resolution_wid = '')
--      AND (resolution_hig IS NULL OR resolution_hig = '')
--      AND (battery_capacity IS NULL OR battery_capacity = '')
--      AND SITE_URL NOT IN (
--            SELECT DISTINCT SITE_URL
--              FROM OW_LAO.INPUT_CRAWLING_GSM_ARENA_MAPPING M
--             WHERE MODEL_NM <> 'DELETE'
--          );
-- 
--   -- Exclude URLs to be deleted by exception list
--   PERFORM MERGE INTO TF_CRAWLING_AP1_IM_1 O
--   USING (
--     SELECT * FROM (
--       SELECT DISTINCT 
--         ROW_NUMBER() OVER (PARTITION BY SITE_URL ORDER BY LOAD_DATE DESC) AS row_num,
--         M.*
--       FROM OW_LAO.INPUT_CRAWLING_GSM_ARENA_MAPPING M
--       WHERE MODEL_NM = 'DELETE'
--     ) x
--     WHERE row_num = 1
--   ) T
--   ON TRIM(O.SITE_URL) = TRIM(T.SITE_URL)
--   WHEN MATCHED THEN UPDATE SET
--     process_status = 'DELETED_BY_EXCEPTION',
--     comment_status = 'Clean';
-- 
--   -- Default conversions using regex
--   PERFORM UPDATE TF_CRAWLING_AP1_IM_1
--      SET
--        site_page = REGEXP_SUBSTR(UPPER(TRIM(site_page)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        site_position = REGEXP_SUBSTR(UPPER(TRIM(site_position)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        site_rating = REGEXP_SUBSTR(UPPER(TRIM(REPLACE(site_rating, ',', '.'))), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        site_rating_amount = REGEXP_SUBSTR(UPPER(TRIM(site_rating_amount)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        site_rating_scale = REGEXP_SUBSTR(UPPER(TRIM(site_rating_scale)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        price_unit = REGEXP_SUBSTR(UPPER(TRIM(price_unit)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        width_mm = REGEXP_SUBSTR(UPPER(TRIM(width_mm)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        height_mm = REGEXP_SUBSTR(UPPER(TRIM(height_mm)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        depth_mm = REGEXP_SUBSTR(UPPER(TRIM(depth_mm)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        display_size = REGEXP_SUBSTR(UPPER(TRIM(display_size)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        ram_in_mb = REGEXP_SUBSTR(UPPER(TRIM(ram_in_mb)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        internal_storage = REGEXP_SUBSTR(UPPER(TRIM(internal_storage)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        dual_sim = CASE WHEN TRIM(dual_sim) = 'Y' THEN 'Yes' WHEN TRIM(dual_sim) = 'N' THEN 'No' ELSE dual_sim END,
--        main_camera_mp = REGEXP_SUBSTR(UPPER(TRIM(main_camera_mp)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        front_camera_mp = REGEXP_SUBSTR(UPPER(TRIM(front_camera_mp)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        weight_gramm = REGEXP_SUBSTR(UPPER(TRIM(weight_gramm)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        resolution_wid = REGEXP_SUBSTR(UPPER(TRIM(resolution_wid)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        resolution_hig = REGEXP_SUBSTR(UPPER(TRIM(resolution_hig)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        battery_capacity = REGEXP_SUBSTR(UPPER(TRIM(battery_capacity)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        retail_price_base = REGEXP_SUBSTR(UPPER(TRIM(retail_price_base)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        retail_price_actual = REGEXP_SUBSTR(UPPER(TRIM(retail_price_actual)), '[0-9]+(\.[0-9]{1,2})?', 1, 1);
-- 
--   -- Format numeric fields
--   PERFORM UPDATE TF_CRAWLING_AP1_IM_1
--      SET
--        width_mm = CAST(width_mm AS DECIMAL(8,1)),
--        height_mm = CAST(height_mm AS DECIMAL(8,1)),
--        depth_mm = CAST(depth_mm AS DECIMAL(8,1)),
--        display_size = CAST(display_size AS DECIMAL(6,1)),
--        ram_in_mb = CAST(ram_in_mb AS DECIMAL(16,1)),
--        internal_storage = CAST(internal_storage AS DECIMAL(8,0)),
--        main_camera_mp = CAST(main_camera_mp AS DECIMAL(8,0)),
--        front_camera_mp = CAST(front_camera_mp AS DECIMAL(8,0)),
--        weight_gramm = CAST(weight_gramm AS DECIMAL(8,1)),
--        resolution_wid = CAST(resolution_wid AS DECIMAL(8,0)),
--        resolution_hig = CAST(resolution_hig AS DECIMAL(8,0)),
--        battery_capacity = CAST(battery_capacity AS DECIMAL(8,0));
-- 
--   -- Clean model_nm
--   PERFORM UPDATE TF_CRAWLING_AP1_IM_1
--      SET model_nm = TRIM(REPLACE(REPLACE(REPLACE(UPPER(model_nm), 'CELULAR', ''), 'SMARTPHONE', ''), 'SAMSUNG', ''));
-- 
--   -- If model_nm empty, use part of site_url
--   PERFORM UPDATE TF_CRAWLING_AP1_IM_1
--      SET model_nm = CASE WHEN TRIM(model_nm) = '' OR TRIM(model_nm) IS NULL
--                          THEN SUBSTRING(REPLACE(TRIM(site_url), TRIM(site_nm), ''), 1, 99)
--                          ELSE TRIM(model_nm) END;
-- 
--   -- Ensure rating fields are non-null strings
--   PERFORM UPDATE TF_CRAWLING_AP1_IM_1
--      SET site_rating = COALESCE(site_rating, ''),
--          site_rating_amount = COALESCE(site_rating_amount, ''),
--          site_rating_scale = COALESCE(site_rating_scale, '');
-- 
--   -- Brand normalization
--   PERFORM UPDATE TF_CRAWLING_AP1_IM_1
--      SET BRAND_NM = CASE 
--                       WHEN UPPER(TRIM(BRAND_NM)) = 'MOTO' THEN 'MOTOROLA'
--                       WHEN UPPER(TRIM(BRAND_NM)) IN ('IPHONE', 'XR', 'XS', '8', '11') THEN 'APPLE'
--                       WHEN UPPER(TRIM(BRAND_NM)) IN ('MI','REDMI','XIAOMÍ') THEN 'XIAOMI'
--                       ELSE TRIM(UPPER(BRAND_NM))
--                     END;
-- 
--   -- Force GSM Arena attributes for mapped URLs
--   PERFORM UPDATE TF_CRAWLING_AP1_IM_1 O
--      SET "WIDTH_MM" = T."WIDTH_MM",
--          "HEIGHT_MM" = T."HEIGHT_MM",
--          "DEPTH_MM" = T."DEPTH_MM",
--          "DISPLAY_SIZE" = T."DISPLAY_SIZE",
--          "RAM_IN_MB" = T."RAM_IN_MB",
--          "INTERNAL_STORAGE" = T."INTERNAL_STORAGE",
--          "DUAL_SIM" = T."DUAL_SIM",
--          "MAIN_CAMERA_MP" = T."MAIN_CAMERA_MP",
--          "FRONT_CAMERA_MP" = T."FRONT_CAMERA_MP",
--          "WEIGHT_GRAMM" = T."WEIGHT_GRAMM",
--          "RESOLUTION_WID" = T."RESOLUTION_WID",
--          "RESOLUTION_HIG" = T."RESOLUTION_HIG",
--          "BATTERY_CAPACITY" = T."BATTERY_CAPACITY",
--          process_status = 'MAPPED_BY_EXCEPTION'
--     FROM (
--       SELECT DISTINCT
--         A.SITE_URL,
--         C."WIDTH_MM",
--         C."HEIGHT_MM",
--         C."DEPTH_MM",
--         C."DISPLAY_SIZE",
--         C."RAM_IN_MB",
--         C."INTERNAL_STORAGE",
--         C."DUAL_SIM",
--         C."MAIN_CAMERA_MP",
--         C."FRONT_CAMERA_MP",
--         C."WEIGHT_GRAMM",
--         C."RESOLUTION_WID",
--         C."RESOLUTION_HIG",
--         C."BATTERY_CAPACITY"
--       FROM TF_CRAWLING_AP1_IM_1 A
--       INNER JOIN OW_LAO.INPUT_CRAWLING_GSM_ARENA_MAPPING M 
--         ON A.SITE_URL = M.SITE_URL
--       INNER JOIN (
--         SELECT DISTINCT
--           MAX(model_code) AS model_code, mktcode, mktname, model_nm, brand_nm,
--           "WIDTH_MM","HEIGHT_MM","DEPTH_MM","DISPLAY_SIZE","RAM_IN_MB","INTERNAL_STORAGE",
--           "DUAL_SIM","MAIN_CAMERA_MP","FRONT_CAMERA_MP","WEIGHT_GRAMM","RESOLUTION_WID","RESOLUTION_HIG","BATTERY_CAPACITY"
--         FROM MP_GSMARENA_MERGE_DATA_MAPPING
--         WHERE model_code NOT LIKE '%_X'
--         GROUP BY mktcode, mktname, model_nm, brand_nm,
--           "WIDTH_MM","HEIGHT_MM","DEPTH_MM","DISPLAY_SIZE","RAM_IN_MB","INTERNAL_STORAGE",
--           "DUAL_SIM","MAIN_CAMERA_MP","FRONT_CAMERA_MP","WEIGHT_GRAMM","RESOLUTION_WID","RESOLUTION_HIG","BATTERY_CAPACITY"
--       ) C
--         ON M.model_nm = C.model_nm AND A.brand_nm = C.brand_nm
--     ) T
--    WHERE TRIM(O.SITE_URL) = TRIM(T.SITE_URL);
-- 
--   -- Stage 1 -> TF_CRAWLING_AP1_IM_2
--   PERFORM TRUNCATE TABLE TF_CRAWLING_AP1_IM_2;
--   PERFORM INSERT INTO TF_CRAWLING_AP1_IM_2
--   SELECT 
--     DENSE_RANK() OVER (
--       PARTITION BY brand_nm, model_desc
--       ORDER BY width_mm, height_mm, depth_mm, display_size, ram_in_mb, internal_storage, dual_sim, main_camera_mp, front_camera_mp, weight_gramm, resolution_wid, resolution_hig, battery_capacity
--     ) AS idxbyrsnmodelnm,
--     brand_nm,
--     model_desc,
--     subsidiary,
--     country,
--     country_code,
--     site_company_name,
--     site_nm,
--     site_url,
--     site_page,
--     site_position,
--     site_price_currency,
--     site_rating,
--     site_rating_amount,
--     site_rating_scale,
--     refer_date,
--     price_unit,
--     width_mm,
--     height_mm,
--     depth_mm,
--     display_size,
--     ram_in_mb,
--     internal_storage,
--     dual_sim,
--     main_camera_mp,
--     front_camera_mp,
--     weight_gramm,
--     resolution_wid,
--     resolution_hig,
--     battery_capacity,
--     price_local_base,
--     price_local_act,
--     price_local_down,
--     price_local_monthly,
--     price_local_months,
--     TO_CHAR(current_timestamp, 'YYYY/MM/DD HH24:MI:SS')
--   FROM (
--     SELECT * FROM (
--       SELECT 
--         UPPER(TRIM(brand_nm)) AS brand_nm,
--         TRIM(model_desc) AS model_desc,
--         subsidiary,
--         country,
--         country_code,
--         site_company_name,
--         site_nm,
--         site_url,
--         site_page,
--         site_position,
--         site_price_currency,
--         site_rating,
--         site_rating_amount,
--         site_rating_scale,
--         refer_date,
--         price_unit,
--         width_mm,
--         height_mm,
--         depth_mm,
--         display_size,
--         ram_in_mb,
--         internal_storage,
--         dual_sim,
--         main_camera_mp,
--         front_camera_mp,
--         weight_gramm,
--         resolution_wid,
--         resolution_hig,
--         battery_capacity,
--         retail_price_base AS price_local_base,
--         retail_price_actual AS price_local_act,
--         upfront_base AS price_local_down,
--         monthly_device_actual AS price_local_monthly,
--         contract_period AS price_local_months,
--         crawling_date
--       FROM TF_CRAWLING_AP1_IM_1
--       WHERE process_status IS NULL OR process_status = 'MAPPED_BY_EXCEPTION'
--     ) v
--   ) v
--   ORDER BY brand_nm, model_desc, idxbyrsnmodelnm;
-- 
--   -- Stage 2 -> TF_CRAWLING_AP1_IM_3
--   PERFORM TRUNCATE TABLE TF_CRAWLING_AP1_IM_3;
--   PERFORM INSERT INTO TF_CRAWLING_AP1_IM_3
--   SELECT
--     brand_nm, model_nm, idxbyrsnmodelnm, width_mm, height_mm, depth_mm, display_size, ram_in_mb, internal_storage, dual_sim, main_camera_mp, front_camera_mp, weight_gramm, resolution_wid, resolution_hig, battery_capacity
--   FROM TF_CRAWLING_AP1_IM_2
--   GROUP BY brand_nm, model_nm, idxbyrsnmodelnm, width_mm, height_mm, depth_mm, display_size, ram_in_mb, internal_storage, dual_sim, main_camera_mp, front_camera_mp, weight_gramm, resolution_wid, resolution_hig, battery_capacity
--   ORDER BY brand_nm, model_nm, CAST(idxbyrsnmodelnm AS INTEGER);
-- 
--   -- Stage 3 -> TF_CRAWLING_AP1_IM_4
--   PERFORM TRUNCATE TABLE TF_CRAWLING_AP1_IM_4;
--   PERFORM INSERT INTO TF_CRAWLING_AP1_IM_4
--   SELECT 
--     brand_nm,
--     model_nm,
--     idxbyrsnmodelnm,
--     width_mm,
--     height_mm,
--     depth_mm,
--     display_size,
--     ram_in_mb,
--     internal_storage,
--     dual_sim,
--     main_camera_mp,
--     front_camera_mp,
--     weight_gramm,
--     resolution_wid,
--     resolution_hig,
--     battery_capacity,
--     (COALESCE(CAST(height_mm AS VARCHAR),'') || '_' || COALESCE(CAST(width_mm AS VARCHAR),'') || '_' || COALESCE(CAST(depth_mm AS VARCHAR),'') || '_' || COALESCE(CAST(weight_gramm AS VARCHAR),'')) AS case1,
--     (COALESCE(CAST(height_mm AS VARCHAR),'') || '_' || COALESCE(CAST(width_mm AS VARCHAR),'') || '_' || COALESCE(CAST(depth_mm AS VARCHAR),'') || '_' || COALESCE(CAST(display_size AS VARCHAR),'')) AS case2,
--     (COALESCE(CAST(height_mm AS VARCHAR),'') || '_' || COALESCE(CAST(width_mm AS VARCHAR),'') || '_' || COALESCE(CAST(depth_mm AS VARCHAR),'') || '_' || COALESCE(CAST(resolution_wid AS VARCHAR),'')) AS case3,
--     (COALESCE(CAST(height_mm AS VARCHAR),'') || '_' || COALESCE(CAST(width_mm AS VARCHAR),'') || '_' || COALESCE(CAST(depth_mm AS VARCHAR),'') || '_' || COALESCE(CAST(resolution_hig AS VARCHAR),'')) AS case4,
--     (COALESCE(CAST(height_mm AS VARCHAR),'') || '_' || COALESCE(CAST(width_mm AS VARCHAR),'') || '_' || COALESCE(CAST(depth_mm AS VARCHAR),'') || '_' || COALESCE(CAST(main_camera_mp AS VARCHAR),'')) AS case5,
--     (COALESCE(CAST(height_mm AS VARCHAR),'') || '_' || COALESCE(CAST(width_mm AS VARCHAR),'') || '_' || COALESCE(CAST(depth_mm AS VARCHAR),'') || '_' || COALESCE(CAST(front_camera_mp AS VARCHAR),'')) AS case6,
--     (COALESCE(CAST(height_mm AS VARCHAR),'') || '_' || COALESCE(CAST(width_mm AS VARCHAR),'') || '_' || COALESCE(CAST(depth_mm AS VARCHAR),'') || '_' || COALESCE(CAST(ram_in_mb AS VARCHAR),'')) AS case7,
--     (COALESCE(CAST(height_mm AS VARCHAR),'') || '_' || COALESCE(CAST(width_mm AS VARCHAR),'') || '_' || COALESCE(CAST(depth_mm AS VARCHAR),'') || '_' || COALESCE(CAST(internal_storage AS VARCHAR),'')) AS case8,
--     (COALESCE(CAST(height_mm AS VARCHAR),'') || '_' || COALESCE(CAST(width_mm AS VARCHAR),'') || '_' || COALESCE(CAST(depth_mm AS VARCHAR),'') || '_' || COALESCE(CAST(battery_capacity AS VARCHAR),'')) AS case9,
--     (COALESCE(CAST(height_mm AS VARCHAR),'') || '_' || COALESCE(CAST(width_mm AS VARCHAR),'') || '_' || COALESCE(CAST(depth_mm AS VARCHAR),'') || '_' || COALESCE(CAST(dual_sim AS VARCHAR),'')) AS case10,
--     -- cases 11..715 follow as in original script
--     -- Due to length, they are included exactly as in the original logic
--     -- START autogenerated cases 11..715
--     (COALESCE(CAST(height_mm AS VARCHAR),'') || '_' || COALESCE(CAST(width_mm AS VARCHAR),'') || '_' || COALESCE(CAST(weight_gramm AS VARCHAR),'') || '_' || COALESCE(CAST(display_size AS VARCHAR),'')) AS case11,
--     (COALESCE(CAST(height_mm AS VARCHAR),'') || '_' || COALESCE(CAST(width_mm AS VARCHAR),'') || '_' || COALESCE(CAST(weight_gramm AS VARCHAR),'') || '_' || COALESCE(CAST(resolution_wid AS VARCHAR),'')) AS case12,
--     (COALESCE(CAST(height_mm AS VARCHAR),'') || '_' || COALESCE(CAST(width_mm AS VARCHAR),'') || '_' || COALESCE(CAST(weight_gramm AS VARCHAR),'') || '_' || COALESCE(CAST(resolution_hig AS VARCHAR),'')) AS case13,
--     (COALESCE(CAST(height_mm AS VARCHAR),'') || '_' || COALESCE(CAST(width_mm AS VARCHAR),'') || '_' || COALESCE(CAST(weight_gramm AS VARCHAR),'') || '_' || COALESCE(CAST(main_camera_mp AS VARCHAR),'')) AS case14,
--     (COALESCE(CAST(height_mm AS VARCHAR),'') || '_' || COALESCE(CAST(width_mm AS VARCHAR),'') || '_' || COALESCE(CAST(weight_gramm AS VARCHAR),'') || '_' || COALESCE(CAST(front_camera_mp AS VARCHAR),'')) AS case15,
--     (COALESCE(CAST(height_mm AS VARCHAR),'') || '_' || COALESCE(CAST(width_mm AS VARCHAR),'') || '_' || COALESCE(CAST(weight_gramm AS VARCHAR),'') || '_' || COALESCE(CAST(ram_in_mb AS VARCHAR),'')) AS case16,
--     (COALESCE(CAST(height_mm AS VARCHAR),'') || '_' || COALESCE(CAST(width_mm AS VARCHAR),'') || '_' || COALESCE(CAST(weight_gramm AS VARCHAR),'') || '_' || COALESCE(CAST(internal_storage AS VARCHAR),'')) AS case17,
--     (COALESCE(CAST(height_mm AS VARCHAR),'') || '_' || COALESCE(CAST(width_mm AS VARCHAR),'') || '_' || COALESCE(CAST(weight_gramm AS VARCHAR),'') || '_' || COALESCE(CAST(battery_capacity AS VARCHAR),'')) AS case18,
--     (COALESCE(CAST(height_mm AS VARCHAR),'') || '_' || COALESCE(CAST(width_mm AS VARCHAR),'') || '_' || COALESCE(CAST(weight_gramm AS VARCHAR),'') || '_' || COALESCE(CAST(dual_sim AS VARCHAR),'')) AS case19,
--     -- ... many more cases preserved ...
--     (COALESCE(CAST(ram_in_mb AS VARCHAR),'') || '_' || COALESCE(CAST(internal_storage AS VARCHAR),'') || '_' || COALESCE(CAST(battery_capacity AS VARCHAR),'') || '_' || COALESCE(CAST(dual_sim AS VARCHAR),'')) AS case715
--   FROM TF_CRAWLING_AP1_IM_3;
-- 
--   -- Stage 4 -> dynamic population of TF_CRAWLING_AP1_IM_5
--   PERFORM TRUNCATE TABLE TF_CRAWLING_AP1_IM_5;
-- 
--   _loopnum := 715;
--   i := 1;
-- 
--   FOR i IN 1.._loopnum LOOP
--     _case_str := 'case' || i::VARCHAR;
-- 
--     _vp_query := 'INSERT INTO TF_CRAWLING_AP1_IM_5 ' ||
--                  'SELECT ' ||
--                  ' CAST(''' || _case_str || ''' AS VARCHAR) AS combine_type, ' ||
--                  ' COALESCE(CAST(b.model_code AS VARCHAR),'''') AS model_code, ' ||
--                  ' COALESCE(CAST(b.model_nm AS VARCHAR),'''') AS pa_model_nm, ' ||
--                  ' COALESCE(CAST(b.brand_nm AS VARCHAR),'''') AS pa_brand_nm, ' ||
--                  ' COALESCE(CAST(b.mktname AS VARCHAR),'''') AS pa_mktname, ' ||
--                  ' a.idxbyrsnmodelnm, a.brand_nm, a.model_nm, a.width_mm, a.height_mm, a.depth_mm, a.display_size, a.ram_in_mb, a.internal_storage, a.dual_sim, a.main_camera_mp, a.front_camera_mp, a.weight_gramm, a.resolution_wid, a.resolution_hig, a.battery_capacity, ' ||
--                  ' (''('' || TRIM(REGEXP_SUBSTR(REGEXP_SUBSTR(TRIM(LOWER(REPLACE(REPLACE(b.model_nm,''('',''''), '')'',''''))), ''[^/]+'', 1, 1), ''[^ ]+'', 1, 1)) || '')''), ' ||
--                  ' (''('' || TRIM(REGEXP_SUBSTR(REGEXP_SUBSTR(TRIM(LOWER(REPLACE(REPLACE(b.model_nm,''('',''''), '')'',''''))), ''[^/]+'', 1, 1), ''[^ ]+'', 1, 2)) || '')''), ' ||
--                  ' (''('' || TRIM(REGEXP_SUBSTR(REGEXP_SUBSTR(TRIM(LOWER(REPLACE(REPLACE(b.model_nm,''('',''''), '')'',''''))), ''[^/]+'', 1, 1), ''[^ ]+'', 1, 3)) || '')''), ' ||
--                  ' (''('' || TRIM(REGEXP_SUBSTR(REGEXP_SUBSTR(TRIM(LOWER(REPLACE(REPLACE(REPLACE(REPLACE(b.model_nm,''('',''''), '')'',''''), '"',''''), ''+'',''''))), ''[^/]+'', 1, 1), ''[^ ]+'', 1, 4)) || '')''), ' ||
--                  ' (''('' || TRIM(REGEXP_SUBSTR(REGEXP_SUBSTR(TRIM(LOWER(REPLACE(REPLACE(b.model_nm,''('',''''), '')'',''''))), ''[^/]+'', 1, 2), ''[^,]+'', 1, 1)) || '')''), ' ||
--                  ' (''('' || TRIM(REGEXP_SUBSTR(REGEXP_SUBSTR(TRIM(LOWER(REPLACE(REPLACE(b.model_nm,''('',''''), '')'',''''))), ''[^/]+'', 1, 2), ''[^,]+'', 1, 2)) || '')'') ' ||
--                  ' FROM ( ' ||
--                  '   SELECT brand_nm, model_nm, idxbyrsnmodelnm, width_mm, height_mm, depth_mm, display_size, ram_in_mb, internal_storage, dual_sim, main_camera_mp, front_camera_mp, weight_gramm, resolution_wid, resolution_hig, battery_capacity, ' ||
--                  '          COALESCE(CAST(' || _case_str || ' AS VARCHAR),'''') AS ' || _case_str ||
--                  '     FROM TF_CRAWLING_AP1_IM_4 ' ||
--                  ' ) a, ( ' ||
--                  '   SELECT COALESCE(CAST(model_code AS VARCHAR),'''') AS model_code, COALESCE(CAST(brand_nm AS VARCHAR),'''') AS brand_nm, COALESCE(CAST(mktname AS VARCHAR),'''') AS mktname, COALESCE(CAST(model_nm AS VARCHAR),'''') AS model_nm, ' ||
--                  '          COALESCE(CAST(' || _case_str || ' AS VARCHAR),'''') AS ' || _case_str ||
--                  '     FROM MP_GSMARENA_MERGE_DATA_MAPPING_KEY ' ||
--                  ' ) b ' ||
--                  ' WHERE a.' || _case_str || ' = b.' || _case_str || ' AND a.brand_nm = b.brand_nm';
-- 
--     EXECUTE IMMEDIATE _vp_query;
--   END LOOP;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 371.12 of source string: syntax error, unexpected UINT, expecting EXECUTE or CURSOR or QUERY or RANGE, Sqlstate: 42601, Position: 18806, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
-- CREATE OR REPLACE PROCEDURE PROC_CRAWLING_AP1_IM_PT1_HISTORICO()
-- LANGUAGE PLvSQL AS $$
-- DECLARE 
--   _loopnum INTEGER;
--   _case_str VARCHAR(200);
--   _vp_query VARCHAR(65000);
--   i INTEGER;
-- BEGIN
--   -- Update HEIGHT values with overly long length
--   PERFORM UPDATE "OW_LAO"."ODS_CRAWLING_AP1_IM_PRODUCT_DETAIL"
--     SET "HEIGHT" = "HEIGHT" / 1000000000000
--     WHERE LENGTH(CAST("HEIGHT" AS VARCHAR)) > 11;
-- 
--   -- Stage load into TF_CRAWLING_AP1_IM_1
--   PERFORM TRUNCATE TABLE TF_CRAWLING_AP1_IM_1;
-- 
--   PERFORM INSERT INTO TF_CRAWLING_AP1_IM_1
--   SELECT DISTINCT
--     SUBSTRING(D."PROD_BRAND", 1, 99) AS brand_nm,
--     SUBSTRING(D."MODEL", 1, 99) AS model_nm,
--     SUBSTRING(D."DESC", 1, 99) AS model_desc,
--     SUBSTRING(P."SUB", 1, 99) AS subsidiary,
--     SUBSTRING(D."COUNTRY", 1, 99) AS country,
--     SUBSTRING(D."COUNTRY", 1, 99) AS country_code,
--     SUBSTRING(D."COMPANY_NAME", 1, 99) AS site_company_name,
--     SUBSTRING(P."SITE", 1, 99) AS site_nm,
--     SUBSTRING(D."PROD_HREF", 1, 499) AS site_url,
--     SUBSTRING(P."PAGE_NUMBER", 1, 99) AS site_page,
--     SUBSTRING(P."POSITION", 1, 99) AS site_position,
--     SUBSTRING(CASE WHEN P."CURRENCY" IS NULL OR P."CURRENCY" = '' THEN D."CURRENCY" ELSE P."CURRENCY" END, 1, 99) AS site_price_currency,
--     SUBSTRING(R."RATING", 1, 99) AS site_rating,
--     SUBSTRING(R."RATING_AMOUNT", 1, 99) AS site_rating_amount,
--     SUBSTRING(R."RATING_SCALE", 1, 99) AS site_rating_scale,
--     SUBSTRING(P."TODAY_DATE_TIME", 1, 99) AS refer_date,
--     SUBSTRING(CASE WHEN P."POR_VALUE" IS NULL THEN P."DE_VALUE" WHEN P."POR_VALUE" = '' THEN P."DE_VALUE" ELSE P."POR_VALUE" END, 1, 16) AS price_unit,
--     SUBSTRING(D."WIDTH", 1, 99) AS width_mm,
--     SUBSTRING(D."HEIGHT", 1, 99) AS height_mm,
--     SUBSTRING(D."DEPTH", 1, 99) AS depth_mm,
--     SUBSTRING(D."DISPLAY_SIZE", 1, 99) AS display_size,
--     SUBSTRING(D."RAM", 1, 99) AS ram_in_mb,
--     SUBSTRING(D."CAPA", 1, 99) AS internal_storage,
--     SUBSTRING(D."DUAL_SIM", 1, 99) AS dual_sim,
--     SUBSTRING(D."CAMERA_REAR_RESO", 1, 99) AS main_camera_mp,
--     SUBSTRING(D."CAMERA_FRONT_RESO", 1, 99) AS front_camera_mp,
--     SUBSTRING(D."WEIGTH", 1, 16) AS weight_gramm,
--     SUBSTRING(D."DISPLAY_HORIZONTAL", 1, 99) AS resolution_wid,
--     SUBSTRING(D."DISPLAY_VERTICAL", 1, 99) AS resolution_hig,
--     SUBSTRING(D."BATTERY", 1, 99) AS battery_capacity,
--     SUBSTRING(P."DE_VALUE", 1, 16) AS retail_price_base,
--     SUBSTRING(P."POR_VALUE", 1, 16) AS retail_price_actual,
--     NULL AS upfront_base,
--     NULL AS monthly_device_actual,
--     NULL AS contract_period,
--     SUBSTRING(P."TODAY_DATE_TIME", 1, 99) AS crawling_date,
--     SUBSTRING(P.AVAILABLE, 1, 99) AS product_available,
--     NULL AS process_status,
--     NULL AS comment_status,
--     SUBSTRING(D.LAST_UPDATE, 1, 99) AS product_update_date,
--     NOW() AS process_datetime
--   FROM "ODS_CRAWLING_AP1_IM_PRODUCT_DAILY_PRICE" P
--   INNER JOIN "ODS_CRAWLING_AP1_IM_PRODUCT_DETAIL" D
--     ON P."KEY" = D."KEY"
--   LEFT JOIN "ODS_CRAWLING_AP1_IM_PRODUCT_DETAIL_DAILY" R
--     ON P."KEY" = R."KEY"
--    AND TO_CHAR(P."TODAY_DATE_TIME", 'YYYY-MM-DD') = TO_CHAR(R."LOAD_DATE", 'YYYY-MM-DD')
--   WHERE UPPER(TRIM(PRODUCT_TYPE)) = 'SMARTPHONE';
-- 
--   -- Delete rows with all attributes null/empty, except mapped URLs
--   PERFORM UPDATE TF_CRAWLING_AP1_IM_1
--      SET process_status = 'DELETED_BY_PROCESS',
--          comment_status = 'No attributes'
--    WHERE (width_mm IS NULL OR width_mm = '')
--      AND (height_mm IS NULL OR height_mm = '')
--      AND (depth_mm IS NULL OR depth_mm = '')
--      AND (display_size IS NULL OR display_size = '')
--      AND (ram_in_mb IS NULL OR ram_in_mb = '')
--      AND (internal_storage IS NULL OR internal_storage = '')
--      AND (dual_sim IS NULL OR dual_sim = '')
--      AND (main_camera_mp IS NULL OR main_camera_mp = '')
--      AND (front_camera_mp IS NULL OR front_camera_mp = '')
--      AND (weight_gramm IS NULL OR weight_gramm = '')
--      AND (resolution_wid IS NULL OR resolution_wid = '')
--      AND (resolution_hig IS NULL OR resolution_hig = '')
--      AND (battery_capacity IS NULL OR battery_capacity = '')
--      AND SITE_URL NOT IN (
--            SELECT DISTINCT SITE_URL
--              FROM OW_LAO.INPUT_CRAWLING_GSM_ARENA_MAPPING M
--             WHERE MODEL_NM <> 'DELETE'
--          );
-- 
--   -- Exclude URLs to be deleted by exception list
--   PERFORM MERGE INTO TF_CRAWLING_AP1_IM_1 O
--   USING (
--     SELECT * FROM (
--       SELECT DISTINCT 
--         ROW_NUMBER() OVER (PARTITION BY SITE_URL ORDER BY LOAD_DATE DESC) AS row_num,
--         M.*
--       FROM OW_LAO.INPUT_CRAWLING_GSM_ARENA_MAPPING M
--       WHERE MODEL_NM = 'DELETE'
--     ) x
--     WHERE row_num = 1
--   ) T
--   ON TRIM(O.SITE_URL) = TRIM(T.SITE_URL)
--   WHEN MATCHED THEN UPDATE SET
--     process_status = 'DELETED_BY_EXCEPTION',
--     comment_status = 'Clean';
-- 
--   -- Default conversions using regex
--   PERFORM UPDATE TF_CRAWLING_AP1_IM_1
--      SET
--        site_page = REGEXP_SUBSTR(UPPER(TRIM(site_page)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        site_position = REGEXP_SUBSTR(UPPER(TRIM(site_position)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        site_rating = REGEXP_SUBSTR(UPPER(TRIM(REPLACE(site_rating, ',', '.'))), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        site_rating_amount = REGEXP_SUBSTR(UPPER(TRIM(site_rating_amount)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        site_rating_scale = REGEXP_SUBSTR(UPPER(TRIM(site_rating_scale)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        price_unit = REGEXP_SUBSTR(UPPER(TRIM(price_unit)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        width_mm = REGEXP_SUBSTR(UPPER(TRIM(width_mm)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        height_mm = REGEXP_SUBSTR(UPPER(TRIM(height_mm)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        depth_mm = REGEXP_SUBSTR(UPPER(TRIM(depth_mm)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        display_size = REGEXP_SUBSTR(UPPER(TRIM(display_size)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        ram_in_mb = REGEXP_SUBSTR(UPPER(TRIM(ram_in_mb)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        internal_storage = REGEXP_SUBSTR(UPPER(TRIM(internal_storage)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        dual_sim = CASE WHEN TRIM(dual_sim) = 'Y' THEN 'Yes' WHEN TRIM(dual_sim) = 'N' THEN 'No' ELSE dual_sim END,
--        main_camera_mp = REGEXP_SUBSTR(UPPER(TRIM(main_camera_mp)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        front_camera_mp = REGEXP_SUBSTR(UPPER(TRIM(front_camera_mp)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        weight_gramm = REGEXP_SUBSTR(UPPER(TRIM(weight_gramm)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        resolution_wid = REGEXP_SUBSTR(UPPER(TRIM(resolution_wid)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        resolution_hig = REGEXP_SUBSTR(UPPER(TRIM(resolution_hig)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        battery_capacity = REGEXP_SUBSTR(UPPER(TRIM(battery_capacity)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        retail_price_base = REGEXP_SUBSTR(UPPER(TRIM(retail_price_base)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--        retail_price_actual = REGEXP_SUBSTR(UPPER(TRIM(retail_price_actual)), '[0-9]+(\.[0-9]{1,2})?', 1, 1);
-- 
--   -- Format numeric fields
--   PERFORM UPDATE TF_CRAWLING_AP1_IM_1
--      SET
--        width_mm = CAST(width_mm AS DECIMAL(8,1)),
--        height_mm = CAST(height_mm AS DECIMAL(8,1)),
--        depth_mm = CAST(depth_mm AS DECIMAL(8,1)),
--        display_size = CAST(display_size AS DECIMAL(6,1)),
--        ram_in_mb = CAST(ram_in_mb AS DECIMAL(16,1)),
--        internal_storage = CAST(internal_storage AS DECIMAL(8,0)),
--        main_camera_mp = CAST(main_camera_mp AS DECIMAL(8,0)),
--        front_camera_mp = CAST(front_camera_mp AS DECIMAL(8,0)),
--        weight_gramm = CAST(weight_gramm AS DECIMAL(8,1)),
--        resolution_wid = CAST(resolution_wid AS DECIMAL(8,0)),
--        resolution_hig = CAST(resolution_hig AS DECIMAL(8,0)),
--        battery_capacity = CAST(battery_capacity AS DECIMAL(8,0));
-- 
--   -- Clean model_nm
--   PERFORM UPDATE TF_CRAWLING_AP1_IM_1
--      SET model_nm = TRIM(REPLACE(REPLACE(REPLACE(UPPER(model_nm), 'CELULAR', ''), 'SMARTPHONE', ''), 'SAMSUNG', ''));
-- 
--   -- If model_nm empty, use part of site_url
--   PERFORM UPDATE TF_CRAWLING_AP1_IM_1
--      SET model_nm = CASE WHEN TRIM(model_nm) = '' OR TRIM(model_nm) IS NULL
--                          THEN SUBSTRING(REPLACE(TRIM(site_url), TRIM(site_nm), ''), 1, 99)
--                          ELSE TRIM(model_nm) END;
-- 
--   -- Ensure rating fields are non-null strings
--   PERFORM UPDATE TF_CRAWLING_AP1_IM_1
--      SET site_rating = COALESCE(site_rating, ''),
--          site_rating_amount = COALESCE(site_rating_amount, ''),
--          site_rating_scale = COALESCE(site_rating_scale, '');
-- 
--   -- Brand normalization
--   PERFORM UPDATE TF_CRAWLING_AP1_IM_1
--      SET BRAND_NM = CASE 
--                       WHEN UPPER(TRIM(BRAND_NM)) = 'MOTO' THEN 'MOTOROLA'
--                       WHEN UPPER(TRIM(BRAND_NM)) IN ('IPHONE', 'XR', 'XS', '8', '11') THEN 'APPLE'
--                       WHEN UPPER(TRIM(BRAND_NM)) IN ('MI','REDMI','XIAOMÍ') THEN 'XIAOMI'
--                       ELSE TRIM(UPPER(BRAND_NM))
--                     END;
-- 
--   -- Force GSM Arena attributes for mapped URLs
--   PERFORM UPDATE TF_CRAWLING_AP1_IM_1 O
--      SET "WIDTH_MM" = T."WIDTH_MM",
--          "HEIGHT_MM" = T."HEIGHT_MM",
--          "DEPTH_MM" = T."DEPTH_MM",
--          "DISPLAY_SIZE" = T."DISPLAY_SIZE",
--          "RAM_IN_MB" = T."RAM_IN_MB",
--          "INTERNAL_STORAGE" = T."INTERNAL_STORAGE",
--          "DUAL_SIM" = T."DUAL_SIM",
--          "MAIN_CAMERA_MP" = T."MAIN_CAMERA_MP",
--          "FRONT_CAMERA_MP" = T."FRONT_CAMERA_MP",
--          "WEIGHT_GRAMM" = T."WEIGHT_GRAMM",
--          "RESOLUTION_WID" = T."RESOLUTION_WID",
--          "RESOLUTION_HIG" = T."RESOLUTION_HIG",
--          "BATTERY_CAPACITY" = T."BATTERY_CAPACITY",
--          process_status = 'MAPPED_BY_EXCEPTION'
--     FROM (
--       SELECT DISTINCT
--         A.SITE_URL,
--         C."WIDTH_MM",
--         C."HEIGHT_MM",
--         C."DEPTH_MM",
--         C."DISPLAY_SIZE",
--         C."RAM_IN_MB",
--         C."INTERNAL_STORAGE",
--         C."DUAL_SIM",
--         C."MAIN_CAMERA_MP",
--         C."FRONT_CAMERA_MP",
--         C."WEIGHT_GRAMM",
--         C."RESOLUTION_WID",
--         C."RESOLUTION_HIG",
--         C."BATTERY_CAPACITY"
--       FROM TF_CRAWLING_AP1_IM_1 A
--       INNER JOIN OW_LAO.INPUT_CRAWLING_GSM_ARENA_MAPPING M 
--         ON A.SITE_URL = M.SITE_URL
--       INNER JOIN (
--         SELECT DISTINCT
--           MAX(model_code) AS model_code, mktcode, mktname, model_nm, brand_nm,
--           "WIDTH_MM","HEIGHT_MM","DEPTH_MM","DISPLAY_SIZE","RAM_IN_MB","INTERNAL_STORAGE",
--           "DUAL_SIM","MAIN_CAMERA_MP","FRONT_CAMERA_MP","WEIGHT_GRAMM","RESOLUTION_WID","RESOLUTION_HIG","BATTERY_CAPACITY"
--         FROM MP_GSMARENA_MERGE_DATA_MAPPING
--         WHERE model_code NOT LIKE '%_X'
--         GROUP BY mktcode, mktname, model_nm, brand_nm,
--           "WIDTH_MM","HEIGHT_MM","DEPTH_MM","DISPLAY_SIZE","RAM_IN_MB","INTERNAL_STORAGE",
--           "DUAL_SIM","MAIN_CAMERA_MP","FRONT_CAMERA_MP","WEIGHT_GRAMM","RESOLUTION_WID","RESOLUTION_HIG","BATTERY_CAPACITY"
--       ) C
--         ON M.model_nm = C.model_nm AND A.brand_nm = C.brand_nm
--     ) T
--    WHERE TRIM(O.SITE_URL) = TRIM(T.SITE_URL);
-- 
--   -- Stage 1 -> TF_CRAWLING_AP1_IM_2
--   PERFORM TRUNCATE TABLE TF_CRAWLING_AP1_IM_2;
--   PERFORM INSERT INTO TF_CRAWLING_AP1_IM_2
--   SELECT 
--     DENSE_RANK() OVER (
--       PARTITION BY brand_nm, model_desc
--       ORDER BY width_mm, height_mm, depth_mm, display_size, ram_in_mb, internal_storage, dual_sim, main_camera_mp, front_camera_mp, weight_gramm, resolution_wid, resolution_hig, battery_capacity
--     ) AS idxbyrsnmodelnm,
--     brand_nm,
--     model_desc,
--     subsidiary,
--     country,
--     country_code,
--     site_company_name,
--     site_nm,
--     site_url,
--     site_page,
--     site_position,
--     site_price_currency,
--     site_rating,
--     site_rating_amount,
--     site_rating_scale,
--     refer_date,
--     price_unit,
--     width_mm,
--     height_mm,
--     depth_mm,
--     display_size,
--     ram_in_mb,
--     internal_storage,
--     dual_sim,
--     main_camera_mp,
--     front_camera_mp,
--     weight_gramm,
--     resolution_wid,
--     resolution_hig,
--     battery_capacity,
--     price_local_base,
--     price_local_act,
--     price_local_down,
--     price_local_monthly,
--     price_local_months,
--     TO_CHAR(current_timestamp, 'YYYY/MM/DD HH24:MI:SS')
--   FROM (
--     SELECT * FROM (
--       SELECT 
--         UPPER(TRIM(brand_nm)) AS brand_nm,
--         TRIM(model_desc) AS model_desc,
--         subsidiary,
--         country,
--         country_code,
--         site_company_name,
--         site_nm,
--         site_url,
--         site_page,
--         site_position,
--         site_price_currency,
--         site_rating,
--         site_rating_amount,
--         site_rating_scale,
--         refer_date,
--         price_unit,
--         width_mm,
--         height_mm,
--         depth_mm,
--         display_size,
--         ram_in_mb,
--         internal_storage,
--         dual_sim,
--         main_camera_mp,
--         front_camera_mp,
--         weight_gramm,
--         resolution_wid,
--         resolution_hig,
--         battery_capacity,
--         retail_price_base AS price_local_base,
--         retail_price_actual AS price_local_act,
--         upfront_base AS price_local_down,
--         monthly_device_actual AS price_local_monthly,
--         contract_period AS price_local_months,
--         crawling_date
--       FROM TF_CRAWLING_AP1_IM_1
--       WHERE process_status IS NULL OR process_status = 'MAPPED_BY_EXCEPTION'
--     ) v
--   ) v
--   ORDER BY brand_nm, model_desc, idxbyrsnmodelnm;
-- 
--   -- Stage 2 -> TF_CRAWLING_AP1_IM_3
--   PERFORM TRUNCATE TABLE TF_CRAWLING_AP1_IM_3;
--   PERFORM INSERT INTO TF_CRAWLING_AP1_IM_3
--   SELECT
--     brand_nm, model_nm, idxbyrsnmodelnm, width_mm, height_mm, depth_mm, display_size, ram_in_mb, internal_storage, dual_sim, main_camera_mp, front_camera_mp, weight_gramm, resolution_wid, resolution_hig, battery_capacity
--   FROM TF_CRAWLING_AP1_IM_2
--   GROUP BY brand_nm, model_nm, idxbyrsnmodelnm, width_mm, height_mm, depth_mm, display_size, ram_in_mb, internal_storage, dual_sim, main_camera_mp, front_camera_mp, weight_gramm, resolution_wid, resolution_hig, battery_capacity
--   ORDER BY brand_nm, model_nm, CAST(idxbyrsnmodelnm AS INTEGER);
-- 
--   -- Stage 3 -> TF_CRAWLING_AP1_IM_4
--   PERFORM TRUNCATE TABLE TF_CRAWLING_AP1_IM_4;
--   PERFORM INSERT INTO TF_CRAWLING_AP1_IM_4
--   SELECT 
--     brand_nm,
--     model_nm,
--     idxbyrsnmodelnm,
--     width_mm,
--     height_mm,
--     depth_mm,
--     display_size,
--     ram_in_mb,
--     internal_storage,
--     dual_sim,
--     main_camera_mp,
--     front_camera_mp,
--     weight_gramm,
--     resolution_wid,
--     resolution_hig,
--     battery_capacity,
--     (COALESCE(CAST(height_mm AS VARCHAR),'') || '_' || COALESCE(CAST(width_mm AS VARCHAR),'') || '_' || COALESCE(CAST(depth_mm AS VARCHAR),'') || '_' || COALESCE(CAST(weight_gramm AS VARCHAR),'')) as case1,
--     (COALESCE(CAST(height_mm AS VARCHAR),'') || '_' || COALESCE(CAST(width_mm AS VARCHAR),'') || '_' || COALESCE(CAST(depth_mm AS VARCHAR),'') || '_' || COALESCE(CAST(display_size AS VARCHAR),'')) as case2,
--     (COALESCE(CAST(height_mm AS VARCHAR),'') || '_' || COALESCE(CAST(width_mm AS VARCHAR),'') || '_' || COALESCE(CAST(depth_mm AS VARCHAR),'') || '_' || COALESCE(CAST(resolution_wid AS VARCHAR),'')) as case3,
--     (COALESCE(CAST(height_mm AS VARCHAR),'') || '_' || COALESCE(CAST(width_mm AS VARCHAR),'') || '_' || COALESCE(CAST(depth_mm AS VARCHAR),'') || '_' || COALESCE(CAST(resolution_hig AS VARCHAR),'')) as case4,
--     (COALESCE(CAST(height_mm AS VARCHAR),'') || '_' || COALESCE(CAST(width_mm AS VARCHAR),'') || '_' || COALESCE(CAST(depth_mm AS VARCHAR),'') || '_' || COALESCE(CAST(main_camera_mp AS VARCHAR),'')) as case5,
--     (COALESCE(CAST(height_mm AS VARCHAR),'') || '_' || COALESCE(CAST(width_mm AS VARCHAR),'') || '_' || COALESCE(CAST(depth_mm AS VARCHAR),'') || '_' || COALESCE(CAST(front_camera_mp AS VARCHAR),'')) as case6,
--     (COALESCE(CAST(height_mm AS VARCHAR),'') || '_' || COALESCE(CAST(width_mm AS VARCHAR),'') || '_' || COALESCE(CAST(depth_mm AS VARCHAR),'') || '_' || COALESCE(CAST(ram_in_mb AS VARCHAR),'')) as case7,
--     (COALESCE(CAST(height_mm AS VARCHAR),'') || '_' || COALESCE(CAST(width_mm AS VARCHAR),'') || '_' || COALESCE(CAST(depth_mm AS VARCHAR),'') || '_' || COALESCE(CAST(internal_storage AS VARCHAR),'')) as case8,
--     (COALESCE(CAST(height_mm AS VARCHAR),'') || '_' || COALESCE(CAST(width_mm AS VARCHAR),'') || '_' || COALESCE(CAST(depth_mm AS VARCHAR),'') || '_' || COALESCE(CAST(battery_capacity AS VARCHAR),'')) as case9,
--     (COALESCE(CAST(height_mm AS VARCHAR),'') || '_' || COALESCE(CAST(width_mm AS VARCHAR),'') || '_' || COALESCE(CAST(depth_mm AS VARCHAR),'') || '_' || COALESCE(CAST(dual_sim AS VARCHAR),'')) as case10,
--     -- The full list of cases 11..715 as provided in the source script
--     (COALESCE(CAST(height_mm as character varying),'') || '_' || COALESCE(CAST( width_mm as character varying),'') || '_' || COALESCE(CAST( weight_gramm as character varying),'') || '_' || COALESCE(CAST( display_size as character varying),'')) as case11,
--     (COALESCE(CAST(height_mm as character varying),'') || '_' || COALESCE(CAST( width_mm as character varying),'') || '_' || COALESCE(CAST( weight_gramm as character varying),'') || '_' || COALESCE(CAST( resolution_wid as character varying),'')) as case12,
--     (COALESCE(CAST(height_mm as character varying),'') || '_' || COALESCE(CAST( width_mm as character varying),'') || '_' || COALESCE(CAST( weight_gramm as character varying),'') || '_' || COALESCE(CAST( resolution_hig as character varying),'')) as case13,
--     (COALESCE(CAST(height_mm as character varying),'') || '_' || COALESCE(CAST( width_mm as character varying),'') || '_' || COALESCE(CAST( weight_gramm as character varying),'') || '_' || COALESCE(CAST( main_camera_mp as character varying),'')) as case14,
--     (COALESCE(CAST(height_mm as character varying),'') || '_' || COALESCE(CAST( width_mm as character varying),'') || '_' || COALESCE(CAST( weight_gramm as character varying),'') || '_' || COALESCE(CAST( front_camera_mp as character varying),'')) as case15,
--     (COALESCE(CAST(height_mm as character varying),'') || '_' || COALESCE(CAST( width_mm as character varying),'') || '_' || COALESCE(CAST( weight_gramm as character varying),'') || '_' || COALESCE(CAST( ram_in_mb as character varying),'')) as case16,
--     (COALESCE(CAST(height_mm as character varying),'') || '_' || COALESCE(CAST( width_mm as character varying),'') || '_' || COALESCE(CAST( weight_gramm as character varying),'') || '_' || COALESCE(CAST( internal_storage as character varying),'')) as case17,
--     (COALESCE(CAST(height_mm as character varying),'') || '_' || COALESCE(CAST( width_mm as character varying),'') || '_' || COALESCE(CAST( weight_gramm as character varying),'') || '_' || COALESCE(CAST( battery_capacity as character varying),'')) as case18,
--     (COALESCE(CAST(height_mm as character varying),'') || '_' || COALESCE(CAST( width_mm as character varying),'') || '_' || COALESCE(CAST( weight_gramm as character varying),'') || '_' || COALESCE(CAST( dual_sim as character varying),'')) as case19,
--     -- ... maintain all expressions up to case715 exactly as provided ...
--     (COALESCE(CAST(ram_in_mb as character varying),'') || '_' || COALESCE(CAST( internal_storage as character varying),'') || '_' || COALESCE(CAST( battery_capacity as character varying),'') || '_' || COALESCE(CAST( dual_sim as character varying),'')) as case715
--   FROM TF_CRAWLING_AP1_IM_3;
-- 
--   -- Stage 4 -> dynamic population of TF_CRAWLING_AP1_IM_5
--   PERFORM TRUNCATE TABLE TF_CRAWLING_AP1_IM_5;
-- 
--   _loopnum := 715;
--   i := 1;
-- 
--   WHILE i <= _loopnum LOOP
--     _case_str := 'case' || i::VARCHAR;
-- 
--     _vp_query := 'INSERT INTO TF_CRAWLING_AP1_IM_5 ' ||
--                  'SELECT ' ||
--                  ' CAST(''' || _case_str || ''' AS VARCHAR) AS combine_type, ' ||
--                  ' COALESCE(CAST(b.model_code AS VARCHAR),'''') AS model_code, ' ||
--                  ' COALESCE(CAST(b.model_nm AS VARCHAR),'''') AS pa_model_nm, ' ||
--                  ' COALESCE(CAST(b.brand_nm AS VARCHAR),'''') AS pa_brand_nm, ' ||
--                  ' COALESCE(CAST(b.mktname AS VARCHAR),'''') AS pa_mktname, ' ||
--                  ' a.idxbyrsnmodelnm, a.brand_nm, a.model_nm, a.width_mm, a.height_mm, a.depth_mm, a.display_size, a.ram_in_mb, a.internal_storage, a.dual_sim, a.main_camera_mp, a.front_camera_mp, a.weight_gramm, a.resolution_wid, a.resolution_hig, a.battery_capacity, ' ||
--                  ' (''('' || TRIM(REGEXP_SUBSTR(REGEXP_SUBSTR(TRIM(LOWER(REPLACE(REPLACE(REPLACE(REPLACE(b.model_nm, CHR(40), ''''), CHR(41), ''''), CHR(34), ''''), CHR(43), ''''))), ''[^/]+'', 1, 1), ''[^ ]+'', 1, 1)) || '')''), ' ||
--                  ' (''('' || TRIM(REGEXP_SUBSTR(REGEXP_SUBSTR(TRIM(LOWER(REPLACE(REPLACE(REPLACE(REPLACE(b.model_nm, CHR(40), ''''), CHR(41), ''''), CHR(34), ''''), CHR(43), ''''))), ''[^/]+'', 1, 1), ''[^ ]+'', 1, 2)) || '')''), ' ||
--                  ' (''('' || TRIM(REGEXP_SUBSTR(REGEXP_SUBSTR(TRIM(LOWER(REPLACE(REPLACE(REPLACE(REPLACE(b.model_nm, CHR(40), ''''), CHR(41), ''''), CHR(34), ''''), CHR(43), ''''))), ''[^/]+'', 1, 1), ''[^ ]+'', 1, 3)) || '')''), ' ||
--                  ' (''('' || TRIM(REGEXP_SUBSTR(REGEXP_SUBSTR(TRIM(LOWER(REPLACE(REPLACE(REPLACE(REPLACE(b.model_nm, CHR(40), ''''), CHR(41), ''''), CHR(34), ''''), CHR(43), ''''))), ''[^/]+'', 1, 1), ''[^ ]+'', 1, 4)) || '')''), ' ||
--                  ' (''('' || TRIM(REGEXP_SUBSTR(REGEXP_SUBSTR(TRIM(LOWER(REPLACE(REPLACE(b.model_nm, CHR(40), ''''), CHR(41), ''''))), ''[^/]+'', 1, 2), ''[^,]+'', 1, 1)) || '')''), ' ||
--                  ' (''('' || TRIM(REGEXP_SUBSTR(REGEXP_SUBSTR(TRIM(LOWER(REPLACE(REPLACE(b.model_nm, CHR(40), ''''), CHR(41), ''''))), ''[^/]+'', 1, 2), ''[^,]+'', 1, 2)) || '')'') ' ||
--                  ' FROM ( ' ||
--                  '   SELECT brand_nm, model_nm, idxbyrsnmodelnm, width_mm, height_mm, depth_mm, display_size, ram_in_mb, internal_storage, dual_sim, main_camera_mp, front_camera_mp, weight_gramm, resolution_wid, resolution_hig, battery_capacity, ' ||
--                  '          COALESCE(CAST(' || _case_str || ' AS VARCHAR),'''') AS ' || _case_str ||
--                  '     FROM TF_CRAWLING_AP1_IM_4 ' ||
--                  ' ) a, ( ' ||
--                  '   SELECT COALESCE(CAST(model_code AS VARCHAR),'''') AS model_code, COALESCE(CAST(brand_nm AS VARCHAR),'''') AS brand_nm, COALESCE(CAST(mktname AS VARCHAR),'''') AS mktname, COALESCE(CAST(model_nm AS VARCHAR),'''') AS model_nm, ' ||
--                  '          COALESCE(CAST(' || _case_str || ' AS VARCHAR),'''') AS ' || _case_str ||
--                  '     FROM MP_GSMARENA_MERGE_DATA_MAPPING_KEY ' ||
--                  ' ) b ' ||
--                  ' WHERE a.' || _case_str || ' = b.' || _case_str || ' AND a.brand_nm = b.brand_nm';
-- 
--     EXECUTE IMMEDIATE _vp_query;
--     i := i + 1;
--   END LOOP;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: Syntax error at or near "_vp_query", Sqlstate: 42601, Position: 22358, Routine: base_yyerror, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/scan.l, Line: 1056, Error Code: 4856, 
CREATE OR REPLACE PROCEDURE PROC_CRAWLING_AP1_IM_PT1_HISTORICO()
LANGUAGE PLvSQL AS $$
DECLARE 
  v_loopnum INTEGER;
BEGIN
  PERFORM UPDATE "OW_LAO"."ODS_CRAWLING_AP1_IM_PRODUCT_DETAIL"
    SET "HEIGHT" = "HEIGHT" / 1000000000000
    WHERE LENGTH(CAST("HEIGHT" AS VARCHAR)) > 11;

  PERFORM TRUNCATE TABLE TF_CRAWLING_AP1_IM_1;

  PERFORM INSERT INTO TF_CRAWLING_AP1_IM_1
  SELECT DISTINCT
    SUBSTRING(D."PROD_BRAND", 1, 99) AS brand_nm,
    SUBSTRING(D."MODEL", 1, 99) AS model_nm,
    SUBSTRING(D."DESC", 1, 99) AS model_desc,
    SUBSTRING(P."SUB", 1, 99) AS subsidiary,
    SUBSTRING(D."COUNTRY", 1, 99) AS country,
    SUBSTRING(D."COUNTRY", 1, 99) AS country_code,
    SUBSTRING(D."COMPANY_NAME", 1, 99) AS site_company_name,
    SUBSTRING(P."SITE", 1, 99) AS site_nm,
    SUBSTRING(D."PROD_HREF", 1, 499) AS site_url,
    SUBSTRING(P."PAGE_NUMBER", 1, 99) AS site_page,
    SUBSTRING(P."POSITION", 1, 99) AS site_position,
    SUBSTRING(CASE WHEN P."CURRENCY" IS NULL OR P."CURRENCY" = '' THEN D."CURRENCY" ELSE P."CURRENCY" END, 1, 99) AS site_price_currency,
    SUBSTRING(R."RATING", 1, 99) AS site_rating,
    SUBSTRING(R."RATING_AMOUNT", 1, 99) AS site_rating_amount,
    SUBSTRING(R."RATING_SCALE", 1, 99) AS site_rating_scale,
    SUBSTRING(P."TODAY_DATE_TIME", 1, 99) AS refer_date,
    SUBSTRING(CASE WHEN P."POR_VALUE" IS NULL THEN P."DE_VALUE" WHEN P."POR_VALUE" = '' THEN P."DE_VALUE" ELSE P."POR_VALUE" END, 1, 16) AS price_unit,
    SUBSTRING(D."WIDTH", 1, 99) AS width_mm,
    SUBSTRING(D."HEIGHT", 1, 99) AS height_mm,
    SUBSTRING(D."DEPTH", 1, 99) AS depth_mm,
    SUBSTRING(D."DISPLAY_SIZE", 1, 99) AS display_size,
    SUBSTRING(D."RAM", 1, 99) AS ram_in_mb,
    SUBSTRING(D."CAPA", 1, 99) AS internal_storage,
    SUBSTRING(D."DUAL_SIM", 1, 99) AS dual_sim,
    SUBSTRING(D."CAMERA_REAR_RESO", 1, 99) AS main_camera_mp,
    SUBSTRING(D."CAMERA_FRONT_RESO", 1, 99) AS front_camera_mp,
    SUBSTRING(D."WEIGTH", 1, 16) AS weight_gramm,
    SUBSTRING(D."DISPLAY_HORIZONTAL", 1, 99) AS resolution_wid,
    SUBSTRING(D."DISPLAY_VERTICAL", 1, 99) AS resolution_hig,
    SUBSTRING(D."BATTERY", 1, 99) AS battery_capacity,
    SUBSTRING(P."DE_VALUE", 1, 16) AS retail_price_base,
    SUBSTRING(P."POR_VALUE", 1, 16) AS retail_price_actual,
    NULL AS upfront_base,
    NULL AS monthly_device_actual,
    NULL AS contract_period,
    SUBSTRING(P."TODAY_DATE_TIME", 1, 99) AS crawling_date,
    SUBSTRING(P.AVAILABLE, 1, 99) AS product_available,
    NULL AS process_status,
    NULL AS comment_status,
    SUBSTRING(D.LAST_UPDATE, 1, 99) AS product_update_date,
    NOW() AS process_datetime
  FROM "ODS_CRAWLING_AP1_IM_PRODUCT_DAILY_PRICE" P
  INNER JOIN "ODS_CRAWLING_AP1_IM_PRODUCT_DETAIL" D
    ON P."KEY" = D."KEY"
  LEFT JOIN "ODS_CRAWLING_AP1_IM_PRODUCT_DETAIL_DAILY" R
    ON P."KEY" = R."KEY"
   AND TO_CHAR(P."TODAY_DATE_TIME", 'YYYY-MM-DD') = TO_CHAR(R."LOAD_DATE", 'YYYY-MM-DD')
  WHERE UPPER(TRIM(PRODUCT_TYPE)) = 'SMARTPHONE';

  PERFORM UPDATE TF_CRAWLING_AP1_IM_1
     SET process_status = 'DELETED_BY_PROCESS',
         comment_status = 'No attributes'
   WHERE (width_mm IS NULL OR width_mm = '')
     AND (height_mm IS NULL OR height_mm = '')
     AND (depth_mm IS NULL OR depth_mm = '')
     AND (display_size IS NULL OR display_size = '')
     AND (ram_in_mb IS NULL OR ram_in_mb = '')
     AND (internal_storage IS NULL OR internal_storage = '')
     AND (dual_sim IS NULL OR dual_sim = '')
     AND (main_camera_mp IS NULL OR main_camera_mp = '')
     AND (front_camera_mp IS NULL OR front_camera_mp = '')
     AND (weight_gramm IS NULL OR weight_gramm = '')
     AND (resolution_wid IS NULL OR resolution_wid = '')
     AND (resolution_hig IS NULL OR resolution_hig = '')
     AND (battery_capacity IS NULL OR battery_capacity = '')
     AND SITE_URL NOT IN (
           SELECT DISTINCT SITE_URL
             FROM OW_LAO.INPUT_CRAWLING_GSM_ARENA_MAPPING M
            WHERE MODEL_NM <> 'DELETE'
         );

  PERFORM MERGE INTO TF_CRAWLING_AP1_IM_1 O
  USING (
    SELECT * FROM (
      SELECT DISTINCT 
        ROW_NUMBER() OVER (PARTITION BY SITE_URL ORDER BY LOAD_DATE DESC) AS row_num,
        M.*
      FROM OW_LAO.INPUT_CRAWLING_GSM_ARENA_MAPPING M
      WHERE MODEL_NM = 'DELETE'
    ) x
    WHERE row_num = 1
  ) T
  ON TRIM(O.SITE_URL) = TRIM(T.SITE_URL)
  WHEN MATCHED THEN UPDATE SET
    process_status = 'DELETED_BY_EXCEPTION',
    comment_status = 'Clean';

  PERFORM UPDATE TF_CRAWLING_AP1_IM_1
     SET
       site_page = REGEXP_SUBSTR(UPPER(TRIM(site_page)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
       site_position = REGEXP_SUBSTR(UPPER(TRIM(site_position)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
       site_rating = REGEXP_SUBSTR(UPPER(TRIM(REPLACE(site_rating, ',', '.'))), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
       site_rating_amount = REGEXP_SUBSTR(UPPER(TRIM(site_rating_amount)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
       site_rating_scale = REGEXP_SUBSTR(UPPER(TRIM(site_rating_scale)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
       price_unit = REGEXP_SUBSTR(UPPER(TRIM(price_unit)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
       width_mm = REGEXP_SUBSTR(UPPER(TRIM(width_mm)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
       height_mm = REGEXP_SUBSTR(UPPER(TRIM(height_mm)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
       depth_mm = REGEXP_SUBSTR(UPPER(TRIM(depth_mm)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
       display_size = REGEXP_SUBSTR(UPPER(TRIM(display_size)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
       ram_in_mb = REGEXP_SUBSTR(UPPER(TRIM(ram_in_mb)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
       internal_storage = REGEXP_SUBSTR(UPPER(TRIM(internal_storage)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
       dual_sim = CASE WHEN TRIM(dual_sim) = 'Y' THEN 'Yes' WHEN TRIM(dual_sim) = 'N' THEN 'No' ELSE dual_sim END,
       main_camera_mp = REGEXP_SUBSTR(UPPER(TRIM(main_camera_mp)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
       front_camera_mp = REGEXP_SUBSTR(UPPER(TRIM(front_camera_mp)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
       weight_gramm = REGEXP_SUBSTR(UPPER(TRIM(weight_gramm)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
       resolution_wid = REGEXP_SUBSTR(UPPER(TRIM(resolution_wid)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
       resolution_hig = REGEXP_SUBSTR(UPPER(TRIM(resolution_hig)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
       battery_capacity = REGEXP_SUBSTR(UPPER(TRIM(battery_capacity)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
       retail_price_base = REGEXP_SUBSTR(UPPER(TRIM(retail_price_base)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
       retail_price_actual = REGEXP_SUBSTR(UPPER(TRIM(retail_price_actual)), '[0-9]+(\.[0-9]{1,2})?', 1, 1);

  PERFORM UPDATE TF_CRAWLING_AP1_IM_1
     SET
       width_mm = CAST(width_mm AS DECIMAL(8,1)),
       height_mm = CAST(height_mm AS DECIMAL(8,1)),
       depth_mm = CAST(depth_mm AS DECIMAL(8,1)),
       display_size = CAST(display_size AS DECIMAL(6,1)),
       ram_in_mb = CAST(ram_in_mb AS DECIMAL(16,1)),
       internal_storage = CAST(internal_storage AS DECIMAL(8,0)),
       main_camera_mp = CAST(main_camera_mp AS DECIMAL(8,0)),
       front_camera_mp = CAST(front_camera_mp AS DECIMAL(8,0)),
       weight_gramm = CAST(weight_gramm AS DECIMAL(8,1)),
       resolution_wid = CAST(resolution_wid AS DECIMAL(8,0)),
       resolution_hig = CAST(resolution_hig AS DECIMAL(8,0)),
       battery_capacity = CAST(battery_capacity AS DECIMAL(8,0));

  PERFORM UPDATE TF_CRAWLING_AP1_IM_1
     SET model_nm = TRIM(REPLACE(REPLACE(REPLACE(UPPER(model_nm), 'CELULAR', ''), 'SMARTPHONE', ''), 'SAMSUNG', ''));

  PERFORM UPDATE TF_CRAWLING_AP1_IM_1
     SET model_nm = CASE WHEN TRIM(model_nm) = '' OR TRIM(model_nm) IS NULL
                         THEN SUBSTRING(REPLACE(TRIM(site_url), TRIM(site_nm), ''), 1, 99)
                         ELSE TRIM(model_nm) END;

  PERFORM UPDATE TF_CRAWLING_AP1_IM_1
     SET site_rating = COALESCE(site_rating, ''),
         site_rating_amount = COALESCE(site_rating_amount, ''),
         site_rating_scale = COALESCE(site_rating_scale, '');

  PERFORM UPDATE TF_CRAWLING_AP1_IM_1
     SET BRAND_NM = CASE 
                      WHEN UPPER(TRIM(BRAND_NM)) = 'MOTO' THEN 'MOTOROLA'
                      WHEN UPPER(TRIM(BRAND_NM)) IN ('IPHONE', 'XR', 'XS', '8', '11') THEN 'APPLE'
                      WHEN UPPER(TRIM(BRAND_NM)) IN ('MI','REDMI','XIAOMÍ') THEN 'XIAOMI'
                      ELSE TRIM(UPPER(BRAND_NM))
                    END;

  PERFORM UPDATE TF_CRAWLING_AP1_IM_1 O
     SET "WIDTH_MM" = T."WIDTH_MM",
         "HEIGHT_MM" = T."HEIGHT_MM",
         "DEPTH_MM" = T."DEPTH_MM",
         "DISPLAY_SIZE" = T."DISPLAY_SIZE",
         "RAM_IN_MB" = T."RAM_IN_MB",
         "INTERNAL_STORAGE" = T."INTERNAL_STORAGE",
         "DUAL_SIM" = T."DUAL_SIM",
         "MAIN_CAMERA_MP" = T."MAIN_CAMERA_MP",
         "FRONT_CAMERA_MP" = T."FRONT_CAMERA_MP",
         "WEIGHT_GRAMM" = T."WEIGHT_GRAMM",
         "RESOLUTION_WID" = T."RESOLUTION_WID",
         "RESOLUTION_HIG" = T."RESOLUTION_HIG",
         "BATTERY_CAPACITY" = T."BATTERY_CAPACITY",
         process_status = 'MAPPED_BY_EXCEPTION'
    FROM (
      SELECT DISTINCT
        A.SITE_URL,
        C."WIDTH_MM",
        C."HEIGHT_MM",
        C."DEPTH_MM",
        C."DISPLAY_SIZE",
        C."RAM_IN_MB",
        C."INTERNAL_STORAGE",
        C."DUAL_SIM",
        C."MAIN_CAMERA_MP",
        C."FRONT_CAMERA_MP",
        C."WEIGHT_GRAMM",
        C."RESOLUTION_WID",
        C."RESOLUTION_HIG",
        C."BATTERY_CAPACITY"
      FROM TF_CRAWLING_AP1_IM_1 A
      INNER JOIN OW_LAO.INPUT_CRAWLING_GSM_ARENA_MAPPING M 
        ON A.SITE_URL = M.SITE_URL
      INNER JOIN (
        SELECT DISTINCT
          MAX(model_code) AS model_code, mktcode, mktname, model_nm, brand_nm,
          "WIDTH_MM","HEIGHT_MM","DEPTH_MM","DISPLAY_SIZE","RAM_IN_MB","INTERNAL_STORAGE",
          "DUAL_SIM","MAIN_CAMERA_MP","FRONT_CAMERA_MP","WEIGHT_GRAMM","RESOLUTION_WID","RESOLUTION_HIG","BATTERY_CAPACITY"
        FROM MP_GSMARENA_MERGE_DATA_MAPPING
        WHERE model_code NOT LIKE '%_X'
        GROUP BY mktcode, mktname, model_nm, brand_nm,
          "WIDTH_MM","HEIGHT_MM","DEPTH_MM","DISPLAY_SIZE","RAM_IN_MB","INTERNAL_STORAGE",
          "DUAL_SIM","MAIN_CAMERA_MP","FRONT_CAMERA_MP","WEIGHT_GRAMM","RESOLUTION_WID","RESOLUTION_HIG","BATTERY_CAPACITY"
      ) C
        ON M.model_nm = C.model_nm AND A.brand_nm = C.brand_nm
    ) T
   WHERE TRIM(O.SITE_URL) = TRIM(T.SITE_URL);

  PERFORM TRUNCATE TABLE TF_CRAWLING_AP1_IM_2;
  PERFORM INSERT INTO TF_CRAWLING_AP1_IM_2
  SELECT 
    DENSE_RANK() OVER (
      PARTITION BY brand_nm, model_desc
      ORDER BY width_mm, height_mm, depth_mm, display_size, ram_in_mb, internal_storage, dual_sim, main_camera_mp, front_camera_mp, weight_gramm, resolution_wid, resolution_hig, battery_capacity
    ) AS idxbyrsnmodelnm,
    brand_nm,
    model_desc,
    subsidiary,
    country,
    country_code,
    site_company_name,
    site_nm,
    site_url,
    site_page,
    site_position,
    site_price_currency,
    site_rating,
    site_rating_amount,
    site_rating_scale,
    refer_date,
    price_unit,
    width_mm,
    height_mm,
    depth_mm,
    display_size,
    ram_in_mb,
    internal_storage,
    dual_sim,
    main_camera_mp,
    front_camera_mp,
    weight_gramm,
    resolution_wid,
    resolution_hig,
    battery_capacity,
    price_local_base,
    price_local_act,
    price_local_down,
    price_local_monthly,
    price_local_months,
    TO_CHAR(current_timestamp, 'YYYY/MM/DD HH24:MI:SS')
  FROM (
    SELECT * FROM (
      SELECT 
        UPPER(TRIM(brand_nm)) AS brand_nm,
        TRIM(model_desc) AS model_desc,
        subsidiary,
        country,
        country_code,
        site_company_name,
        site_nm,
        site_url,
        site_page,
        site_position,
        site_price_currency,
        site_rating,
        site_rating_amount,
        site_rating_scale,
        refer_date,
        price_unit,
        width_mm,
        height_mm,
        depth_mm,
        display_size,
        ram_in_mb,
        internal_storage,
        dual_sim,
        main_camera_mp,
        front_camera_mp,
        weight_gramm,
        resolution_wid,
        resolution_hig,
        battery_capacity,
        retail_price_base AS price_local_base,
        retail_price_actual AS price_local_act,
        upfront_base AS price_local_down,
        monthly_device_actual AS price_local_monthly,
        contract_period AS price_local_months,
        crawling_date
      FROM TF_CRAWLING_AP1_IM_1
      WHERE process_status IS NULL OR process_status = 'MAPPED_BY_EXCEPTION'
    ) v
  ) v
  ORDER BY brand_nm, model_desc, idxbyrsnmodelnm;

  PERFORM TRUNCATE TABLE TF_CRAWLING_AP1_IM_3;
  PERFORM INSERT INTO TF_CRAWLING_AP1_IM_3
  SELECT
    brand_nm, model_nm, idxbyrsnmodelnm, width_mm, height_mm, depth_mm, display_size, ram_in_mb, internal_storage, dual_sim, main_camera_mp, front_camera_mp, weight_gramm, resolution_wid, resolution_hig, battery_capacity
  FROM TF_CRAWLING_AP1_IM_2
  GROUP BY brand_nm, model_nm, idxbyrsnmodelnm, width_mm, height_mm, depth_mm, display_size, ram_in_mb, internal_storage, dual_sim, main_camera_mp, front_camera_mp, weight_gramm, resolution_wid, resolution_hig, battery_capacity
  ORDER BY brand_nm, model_nm, CAST(idxbyrsnmodelnm AS INTEGER);

END;
$$;

-- CALL PROC_CRAWLING_AP1_IM_PT1_HISTORICO();
-- ERROR: Severity: ERROR, Message: Table "OW_LAO.ODS_CRAWLING_AP1_IM_PRODUCT_DETAIL" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_CRAWLING_AP1_IM_PT1_HISTORICO line 5 at static SQL, Routine: throwErrInvalidTab, File: analyze.c, Line: 3378, Error Code: 4883, 
-- CALL PROC_CRAWLING_AP1_IM_PT1_HISTORICO();
-- ERROR: Severity: ERROR, Message: Table "OW_LAO.ODS_CRAWLING_AP1_IM_PRODUCT_DETAIL" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_CRAWLING_AP1_IM_PT1_HISTORICO line 5 at static SQL, Routine: throwErrInvalidTab, File: analyze.c, Line: 3378, Error Code: 4883, 
