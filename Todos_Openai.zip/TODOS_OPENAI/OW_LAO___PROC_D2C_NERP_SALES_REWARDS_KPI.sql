CREATE OR REPLACE PROCEDURE OW_LAO.PROC_D2C_NERP_SALES_REWARDS_KPI()
LANGUAGE PLvSQL AS $$
BEGIN
    
    PERFORM TRUNCATE TABLE OW_LAO.TF_D2C_NERP_SALES_REWARDS_KPI;

    PERFORM INSERT INTO OW_LAO.TF_D2C_NERP_SALES_REWARDS_KPI(
         "SOURCE"
        ,DATE_REF
        ,YYYYWW
        ,YYYYMM
        ,YYYYQQ
        ,SUBSIDIARY
        ,CHANNEL_TYPE
        ,SKU
        ,PDROD_DIVISION
        ,PDROD_PRODUCT_GROUP
        ,PDROD_PRODUCT
        ,PROD_ATTB_1
        ,SEDA_BU_ESTORE
        ,SEDA_CATEGORY_ESTORE
        ,SEDA_DESC_ESTORE
        ,SEDA_DIVISION_ESTORE
        ,SEDA_FAMILY_ESTORE
        ,STATUS_PO
        ,AFFILIATE_CHANNEL
        ,AFFILIATE_SUB_CHANNEL
        ,AFFILIATE_PARTNER_LEVEL
        ,GLOBAL_CHANNEL
        ,AUDIENCE_TYPE
        ,COUNTRY
        ,CURRENCY
        ,MODEL_TYPE
        ,COUPON
        ,"COUPON_FILTER"
        ,QTY
        ,AMOUNT_LOCAL
        ,AMOUNT_USD
        ,KPI_LAST_UPDATE
    )
    SELECT
         "SOURCE"
        ,DATE_REF
        ,YYYYWW
        ,YYYYMM
        ,YYYYQQ
        ,SUBSIDIARY
        ,CHANNEL_TYPE
        ,SKU
        ,PDROD_DIVISION
        ,PDROD_PRODUCT_GROUP
        ,PDROD_PRODUCT
        ,PROD_ATTB_1
        ,SEDA_BU_ESTORE
        ,SEDA_CATEGORY_ESTORE
        ,SEDA_DESC_ESTORE
        ,SEDA_DIVISION_ESTORE
        ,SEDA_FAMILY_ESTORE
        ,STATUS_PO
        ,AFFILIATE_CHANNEL
        ,AFFILIATE_SUB_CHANNEL
        ,AFFILIATE_PARTNER_LEVEL
        ,GLOBAL_CHANNEL
        ,AUDIENCE_TYPE
        ,COUNTRY
        ,CURRENCY
        ,MODEL_TYPE
        ,LOWER(COUPON) AS COUPON
        ,LOWER(CASE
            WHEN 
                UPPER(COUPON) LIKE '%REW%'
                OR UPPER(COUPON) LIKE '%RWD%'
            THEN 'REWARDS'                    
            WHEN 
                UPPER(COUPON) LIKE '%LIVE%'
            THEN 'LIVE'
            WHEN 
                UPPER(COUPON) LIKE '%BLUE%'
            THEN 'BLUE'
            WHEN 
                UPPER(COUPON) LIKE '%GALAXYWATCH%'
                OR UPPER(COUPON) LIKE '%GALAXYBUDS%'
                OR UPPER(COUPON) LIKE '%GALAXYTAB%'
                OR UPPER(COUPON) LIKE '%GALAXYBOOK%'
                OR UPPER(COUPON) LIKE '%LPREWARDS%'
            THEN 'REWARDS'
        ELSE 'OTHERS' END) AS "COUPON_FILTER"
        ,SUM(QTY) AS QTY
        ,SUM(AMOUNT_LOCAL) AS AMOUNT_LOCAL
        ,SUM(AMOUNT_USD) AS AMOUNT_USD
        ,CURRENT_TIMESTAMP AS KPI_LAST_UPDATE
    FROM OW_LAO.TF_D2C_NERP_SALES
    WHERE STATUS_PO IS NULL 
        OR STATUS_PO NOT IN('cancel','canceled')
    GROUP BY
         "SOURCE"
        ,DATE_REF
        ,YYYYWW
        ,YYYYMM
        ,YYYYQQ
        ,SUBSIDIARY
        ,CHANNEL_TYPE
        ,SKU
        ,PDROD_DIVISION
        ,PDROD_PRODUCT_GROUP
        ,PDROD_PRODUCT
        ,PROD_ATTB_1
        ,SEDA_BU_ESTORE
        ,SEDA_CATEGORY_ESTORE
        ,SEDA_DESC_ESTORE
        ,SEDA_DIVISION_ESTORE
        ,SEDA_FAMILY_ESTORE
        ,STATUS_PO
        ,AFFILIATE_CHANNEL
        ,AFFILIATE_SUB_CHANNEL
        ,AFFILIATE_PARTNER_LEVEL
        ,GLOBAL_CHANNEL
        ,AUDIENCE_TYPE
        ,COUNTRY
        ,CURRENCY
        ,MODEL_TYPE
        ,LOWER(COUPON)
        ,LOWER(CASE
            WHEN 
                UPPER(COUPON) LIKE '%REW%'
                OR UPPER(COUPON) LIKE '%RWD%'
            THEN 'REWARDS'                    
            WHEN 
                UPPER(COUPON) LIKE '%LIVE%'
            THEN 'LIVE'
            WHEN 
                UPPER(COUPON) LIKE '%BLUE%'
            THEN 'BLUE'
            WHEN 
                UPPER(COUPON) LIKE '%GALAXYWATCH%'
                OR UPPER(COUPON) LIKE '%GALAXYBUDS%'
                OR UPPER(COUPON) LIKE '%GALAXYTAB%'
                OR UPPER(COUPON) LIKE '%GALAXYBOOK%'
                OR UPPER(COUPON) LIKE '%LPREWARDS%'
            THEN 'REWARDS'
        ELSE 'OTHERS' END);

    PERFORM UPDATE OW_LAO.TF_D2C_NERP_SALES_REWARDS_KPI SET
        KPI_LAST_UPDATE = (
                SELECT MAX(PO_CREATION_DATE)
                FROM OW_LAO.TF_D2C_NERP_SALES
                WHERE "SOURCE" = 'PO'
                    AND SUBSIDIARY = 'SEDA'
              );
    
END
$$;

CALL OW_LAO.PROC_D2C_NERP_SALES_REWARDS_KPI();
-- PROC_D2C_NERP_SALES_REWARDS_KPI
-- -------------------------------
-- 0

