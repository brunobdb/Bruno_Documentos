CREATE OR REPLACE PROCEDURE ow_lao.homolog_proc_ods_sales_payments_grafana_details()
LANGUAGE PLvSQL AS $$
BEGIN
	-- Truncate staging table
	PERFORM TRUNCATE TABLE ow_lao.tmp_sales_payments_grafana_details_homolog;

	-- Load staging
	PERFORM INSERT INTO ow_lao.tmp_sales_payments_grafana_details_homolog
	       SELECT a.inserted_timestamp                                                                                     AS insert_timestamp
			    , CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_created_date)) AS DATE)               AS po_date
			    , MONTH(CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_created_date)) AS DATE))        AS po_month
			    , YEAR(CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_created_date)) AS DATE))         AS po_year
			    , HOUR(CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_created_date)) AS TIMESTAMP))   AS po_hour
			    , a.tenant                                                                                                    AS pay_subsidiary
			    , a.pe_code                                                                                                   AS pay_code
			    , a.paymentid                                                                                                AS pay_id
			    , CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.pe_time)) AS DATE)                          AS pay_date
			    , MONTH(CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.pe_time)) AS DATE))                   AS pay_month
			    , YEAR(CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.pe_time)) AS DATE))                    AS pay_year
			    , HOUR(CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.pe_time)) AS TIMESTAMP))               AS pay_hour
			    , COALESCE(a.pe_status, '')                                                                                   AS pay_status
			    , a.pe_status_detail                                                                                          AS pay_detail
			    , a.payment_code                                                                                              AS pay_gateway_code
			    , a.payment_mode                                                                                              AS payment_type
			    , a.payment_provider                                                                                          AS pay_gateway
			    , a.pe_amount                                                                                                 AS revenue_local
			    , SUBSTR(a.orderid,1,17)                                                                                      AS pay_orderid
			    , c.site                                                                                                      AS pay_storename
			    , a.isbasestore                                                                                               AS postoretype
			    , a.sales_application                                                                                         AS po_devicetype
			    , COALESCE(a.order_status, '')                                                                                AS po_status
			    , a.order_type                                                                                                AS order_status_type
			    , a.order_currency                                                                                            AS currency
			    , CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_modified_date)) AS TIMESTAMP)        AS po_order_lastmodifydate
			    , d.affiliate_id                                                                                              AS postorename
			    , d.global_channel                                                                                            AS channel
			    , d.biz_type                                                                                                  AS biz_type
			    , d.audience_type                                                                                             AS audience_type
			    , d.sales_org                                                                                                 AS subsidiary
			    , a.pe_amount                                                                                                 AS pe_amount
			    , CAST(NULL AS NUMERIC(18,6))                                                                                 AS revenu_usd
			    , CAST('' AS VARCHAR(255))                                                                                    AS po_orderid
			    , CAST('' AS VARCHAR(255))                                                                                    AS pay_action
			    , CAST('' AS VARCHAR(255))                                                                                    AS pay_result
			    , CAST('' AS VARCHAR(1000))                                                                                   AS pay_description
			    , CAST('' AS VARCHAR(255))                                                                                    AS pay_message
			    , CAST('' AS VARCHAR(255))                                                                                    AS po_internal_status
			    , CAST('' AS VARCHAR(255))                                                                                    AS po_payment_type
			    , CAST('' AS VARCHAR(255))                                                                                    AS po_paymentprovider
			    , CAST('' AS VARCHAR(255))                                                                                    AS payment_card_brand
			    , CAST('' AS VARCHAR(255))                                                                                    AS po_status_ct
			    , CAST(NULL AS VARCHAR(255))                                                                                  AS funnel_status
			    , CAST(NULL AS VARCHAR(255))                                                                                  AS pay_gateway_status
			    , CAST(NULL AS VARCHAR(255))                                                                                  AS po_payment_type_status
			    , 'GRAFANA_HYBRIS'                                                                                            AS po_plataform_datasource
			    , SUBSTR(a.orderid,1,17)                                                                                      AS orderid_log
			    , ROW_NUMBER() OVER(
			        PARTITION BY a.tenant, c.site, SUBSTR(a.orderid,1,17)
			        ORDER BY CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_modified_date)) AS TIMESTAMP) DESC
			      )                                                                                                          AS dedup
			    , CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_modified_date)) AS TIMESTAMP)         AS datasource_origin_timestamp
	       FROM ow_lao.raw_grafana_document_payments_details a
	       JOIN u_prj_ecom.dim_subsidiary                  b ON LOWER(b.country_code) = LOWER(a.tenant)
	       JOIN ow_lao.ods_hybris_sales                    c ON SUBSTR(c.order_code,1,17) = SUBSTR(a.orderid,1,17)
	       JOIN ow_md.sales_channel                        d ON LOWER(d.country) = LOWER(b.country)
	                                                      AND LOWER(d.identifier) = LOWER(c.site)
	      WHERE NOT EXISTS (
	                SELECT 1
						FROM ow_lao.ods_payment_funnel_homolog aa
	               WHERE SUBSTR(a.orderid,1,17) = SUBSTR(aa.pay_orderid,1,17)
	                 AND a.tenant = aa.pay_subsidiary
	                 AND CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_modified_date)) AS TIMESTAMP) <= aa.datasource_origin_timestamp
	            )
	        AND b.order_apply_timezone = 1
	        AND CAST(a.inserted_timestamp AS DATE) >= '2025-04-13'
	      ORDER BY CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_created_date)) AS DATE);

	-- Keep only one per partition
	PERFORM DELETE FROM ow_lao.tmp_sales_payments_grafana_details_homolog WHERE dedup != 1;

	-- Enrich from hybris sales
	PERFORM UPDATE ow_lao.tmp_sales_payments_grafana_details_homolog a
	   SET po_internal_status = b.order_status,
	       po_payment_type    = b.payment_mode,
	       po_paymentprovider = b.payment_provider,
	       payment_card_brand = b.payment_mode_creditcardtype
	  FROM ow_lao.ods_hybris_sales b
	 WHERE SUBSTR(b.order_code,1,17) = SUBSTR(a.pay_orderid,1,17);

	-- Enrich from payments log
	PERFORM UPDATE ow_lao.tmp_sales_payments_grafana_details_homolog a
	   SET po_orderid      = b.orderid,
	       pay_action      = b.action,
	       pay_description = b.description,
	       pay_message     = b.message
	  FROM ow_lao.raw_grafana_document_log_payments_details b
	 WHERE SUBSTR(b.orderid,1,17) = a.orderid_log;

	-- Calculate USD revenue
	PERFORM UPDATE ow_lao.tmp_sales_payments_grafana_details_homolog a
	   SET revenu_usd = a.pe_amount / CAST(b.exchange_rate AS NUMERIC(18,6))
	  FROM ow_lao.ft_ap2_exchange_rate b
	 WHERE b.valid_from = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE))
	   AND LOWER(b.to_currency) = LOWER(a.currency);

	-- Map status to control tower
	PERFORM UPDATE ow_lao.tmp_sales_payments_grafana_details_homolog a
	   SET po_status_ct = b.status
	  FROM ow_lao.dim_ods_sales_control_tower_table_status_mapping b
	 WHERE b.status_origin = a.po_internal_status;

	-- Map funnel status
	PERFORM UPDATE ow_lao.tmp_sales_payments_grafana_details_homolog a
	   SET funnel_status = b.status
	  FROM ow_lao.dim_payment_payment_status_mapping_homolog b
	 WHERE b.pay_status = a.pay_status
	   AND b.po_status = a.po_status
	   AND b.pay_description = a.pay_description
	   AND a.po_plataform_datasource = b.data_source
	   AND b.active = TRUE;

	-- Merge into target
	PERFORM MERGE INTO ow_lao.ods_payment_funnel_homolog a
	     USING ow_lao.tmp_sales_payments_grafana_details_homolog b
	        ON SUBSTR(b.pay_orderid,1,17) = SUBSTR(a.pay_orderid,1,17)
	       AND b.pay_subsidiary = a.pay_subsidiary
	WHEN MATCHED THEN UPDATE SET
	       po_date = b.po_date,
	       po_month = b.po_month,
	       po_year = b.po_year,
	       po_hour = b.po_hour,
	       pay_subsidiary = b.pay_subsidiary,
	       pay_code = b.pay_code,
	       pay_id = b.pay_id,
	       pay_date = b.pay_date,
	       pay_month = b.pay_month,
	       pay_year = b.pay_year,
	       pay_hour = b.pay_hour,
	       pay_status = b.pay_status,
	       pay_detail = b.pay_detail,
	       pay_gateway_code = b.pay_gateway_code,
	       payment_type = b.payment_type,
	       pay_gateway = b.pay_gateway,
	       revenue_local = b.revenue_local,
	       pay_orderid = b.pay_orderid,
	       pay_storename = b.pay_storename,
	       postoretype = b.postoretype,
	       po_devicetype = b.po_devicetype,
	       po_status = b.po_status,
	       order_status_type = b.order_status_type,
	       currency = b.currency,
	       po_order_lastmodifydate = b.po_order_lastmodifydate,
	       postorename = b.postorename,
	       channel = b.channel,
	       biz_type = b.biz_type,
	       audience_type = b.audience_type,
	       subsidiary = b.subsidiary,
	       pe_amount = b.pe_amount,
	       revenu_usd = b.revenu_usd,
	       po_orderid = b.po_orderid,
	       pay_action = b.pay_action,
	       pay_result = b.pay_result,
	       pay_description = b.pay_description,
	       pay_message = b.pay_message,
	       po_internal_status = b.po_internal_status,
	       po_payment_type = b.po_payment_type,
	       po_paymentprovider = b.po_paymentprovider,
	       payment_card_brand = b.payment_card_brand,
	       po_status_ct = b.po_status_ct,
	       funnel_status = b.funnel_status,
	       updated_timestamp = CURRENT_TIMESTAMP,
	       pay_gateway_status = b.pay_gateway_status,
	       po_payment_type_status = b.po_payment_type_status,
	       po_plataform_datasource = b.po_plataform_datasource,
	       datasource_origin_timestamp = b.datasource_origin_timestamp
	WHEN NOT MATCHED THEN INSERT (
	       po_date,
	       po_month,
	       po_year,
	       po_hour,
	       pay_subsidiary,
	       pay_code,
	       pay_id,
	       pay_date,
	       pay_month,
	       pay_year,
	       pay_hour,
	       pay_status,
	       pay_detail,
	       pay_gateway_code,
	       payment_type,
	       pay_gateway,
	       revenue_local,
	       pay_orderid,
	       pay_storename,
	       postoretype,
	       po_devicetype,
	       po_status,
	       order_status_type,
	       currency,
	       po_order_lastmodifydate,
	       postorename,
	       channel,
	       biz_type,
	       audience_type,
	       subsidiary,
	       pe_amount,
	       revenu_usd,
	       po_orderid,
	       pay_action,
	       pay_result,
	       pay_description,
	       pay_message,
	       po_internal_status,
	       po_payment_type,
	       po_paymentprovider,
	       payment_card_brand,
	       po_status_ct,
	       funnel_status,
	       pay_gateway_status,
	       po_payment_type_status,
	       po_plataform_datasource,
	       datasource_origin_timestamp
	) VALUES (
	       b.po_date,
	       b.po_month,
	       b.po_year,
	       b.po_hour,
	       b.pay_subsidiary,
	       b.pay_code,
	       b.pay_id,
	       b.pay_date,
	       b.pay_month,
	       b.pay_year,
	       b.pay_hour,
	       b.pay_status,
	       b.pay_detail,
	       b.pay_gateway_code,
	       b.payment_type,
	       b.pay_gateway,
	       b.revenue_local,
	       b.pay_orderid,
	       b.pay_storename,
	       b.postoretype,
	       b.po_devicetype,
	       b.po_status,
	       b.order_status_type,
	       b.currency,
	       b.po_order_lastmodifydate,
	       b.postorename,
	       b.channel,
	       b.biz_type,
	       b.audience_type,
	       b.subsidiary,
	       b.pe_amount,
	       b.revenu_usd,
	       b.po_orderid,
	       b.pay_action,
	       b.pay_result,
	       b.pay_description,
	       b.pay_message,
	       b.po_internal_status,
	       b.po_payment_type,
	       b.po_paymentprovider,
	       b.payment_card_brand,
	       b.po_status_ct,
	       b.funnel_status,
	       b.pay_gateway_status,
	       b.po_payment_type_status,
	       b.po_plataform_datasource,
	       b.datasource_origin_timestamp
	);

END;
$$;

-- CALL ow_lao.homolog_proc_ods_sales_payments_grafana_details();
-- ERROR: Severity: ROLLBACK, Message: Table "tmp_sales_payments_grafana_details_homolog" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure homolog_proc_ods_sales_payments_grafana_details line 4 at static SQL, Routine: TruncateTable, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Commands/DDL.cpp, Line: 20681, Error Code: 4876, 
-- CALL ow_lao.homolog_proc_ods_sales_payments_grafana_details();
-- ERROR: Severity: ROLLBACK, Message: Table "tmp_sales_payments_grafana_details_homolog" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure homolog_proc_ods_sales_payments_grafana_details line 4 at static SQL, Routine: TruncateTable, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Commands/DDL.cpp, Line: 20681, Error Code: 4876, 
