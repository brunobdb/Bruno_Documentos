CREATE OR REPLACE PROCEDURE OW_LAO.proc_stg_table_ods_premium_items(input_text VARCHAR(250))
LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM TRUNCATE TABLE OW_LAO.STG_LAO_PRODUCT_PREMIUM_ITEMS;

    PERFORM INSERT INTO OW_LAO.STG_LAO_PRODUCT_PREMIUM_ITEMS
    SELECT DISTINCT *
    FROM OW_LAO.RAW_LAO_PRODUCT_PREMIUM_ITEMS m
    WHERE m.FILE_NAME = input_text;

    PERFORM MERGE INTO OW_LAO.ODS_LAO_PRODUCT_PREMIUM_ITEMS O
         USING OW_LAO.STG_LAO_PRODUCT_PREMIUM_ITEMS M
         ON O.ITEM = M.ITEM_PREMIUM
            AND O.AP2 = M.SUBSIDIARY
            AND O.PLAN >= M.PLAN
         WHEN NOT MATCHED THEN INSERT (
             AP2, PRODUCT_GRP, PRODUCT, ITEM, PLAN, MONTH, VALUE, FILE_NAME, INSERTED_TIMESTAMP, FILE_ROW_NUMBER
         )
         VALUES (
             M.SUBSIDIARY, '-', '-', M.ITEM_PREMIUM, M.PLAN, M.MONTH, M.VALUE, M.FILE_NAME, M.INSERTED_TIMESTAMP, '1'
         );
END;
$$;

-- CALL OW_LAO.proc_stg_table_ods_premium_items('example_file.txt');
-- ERROR: Severity: ERROR, Message: Column "VALUE" is of type int but expression is of type varchar, Sqlstate: 42804, Hint: You will need to rewrite or cast the expression, Where: PL/vSQL procedure proc_stg_table_ods_premium_items line 10 at static SQL, Routine: updateTargetListEntry, File: parse_target.c, Line: 853, Error Code: 2631, 
CREATE OR REPLACE PROCEDURE OW_LAO.proc_stg_table_ods_premium_items(input_text VARCHAR(250))
LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM TRUNCATE TABLE OW_LAO.STG_LAO_PRODUCT_PREMIUM_ITEMS;

    PERFORM INSERT INTO OW_LAO.STG_LAO_PRODUCT_PREMIUM_ITEMS
    SELECT DISTINCT *
    FROM OW_LAO.RAW_LAO_PRODUCT_PREMIUM_ITEMS m
    WHERE m.FILE_NAME = input_text;

    PERFORM MERGE INTO OW_LAO.ODS_LAO_PRODUCT_PREMIUM_ITEMS O
         USING OW_LAO.STG_LAO_PRODUCT_PREMIUM_ITEMS M
         ON O.ITEM = M.ITEM_PREMIUM
            AND O.AP2 = M.SUBSIDIARY
            AND O.PLAN >= M.PLAN
         WHEN NOT MATCHED THEN INSERT (
             AP2, PRODUCT_GRP, PRODUCT, ITEM, PLAN, MONTH, VALUE, FILE_NAME, INSERTED_TIMESTAMP, FILE_ROW_NUMBER
         )
         VALUES (
             M.SUBSIDIARY, '-', '-', M.ITEM_PREMIUM, M.PLAN, M.MONTH, CAST(M.VALUE AS INT), M.FILE_NAME, M.INSERTED_TIMESTAMP, 1
         );
END;
$$;

CALL OW_LAO.proc_stg_table_ods_premium_items('example_file.txt');
-- proc_stg_table_ods_premium_items
-- --------------------------------
-- 0

