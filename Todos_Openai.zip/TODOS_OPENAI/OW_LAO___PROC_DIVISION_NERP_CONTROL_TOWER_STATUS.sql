CREATE OR REPLACE PROCEDURE ow_lao.proc_division_nerp_control_tower_status()
 LANGUAGE PLvSQL AS $$
BEGIN
 
 -- order: 'payment rejected'
 PERFORM CREATE TABLE ow_lao.temp_division_nerp_control_tower_status AS
 (
    SELECT DISTINCT 
        po_orderid,
        division,
        po_status,
        CASE 
            WHEN po_status = 'Cancelled' THEN 'payment rejected'
            ELSE po_internal_status
        END AS po_internal_status,
        so_date
    FROM ow_lao.ods_sales_control_tower_table 
    WHERE po_status = 'Cancelled'
      AND client_subsidiary_id = 6   
      AND CAST(po_date AS DATE) BETWEEN CAST(TIMESTAMPADD(DAY, -180, NOW()) AS DATE)
                                    AND CAST(TIMESTAMPADD(DAY, 0, NOW()) AS DATE)
 );
 
 PERFORM UPDATE ow_lao.ods_sales_control_tower_table a
    SET po_internal_status = b.po_internal_status
  FROM ow_lao.temp_division_nerp_control_tower_status b
  WHERE b.po_orderid = a.po_orderid
    AND a.client_subsidiary_id = 6;
 
 PERFORM DROP TABLE ow_lao.temp_division_nerp_control_tower_status;
 
 -- order localizadas no nerp: 'so_date localizados'
 PERFORM CREATE TABLE ow_lao.temp_division_nerp_control_tower_status AS
 (
    SELECT DISTINCT 
        po_orderid,
        division,
        po_status,
        CASE 
            WHEN po_status = 'Cancelled' THEN 'canceled'
            ELSE po_internal_status 
        END AS po_internal_status,
        so_date
    FROM ow_lao.ods_sales_control_tower_table 
    WHERE so_date IS NOT NULL 
      AND po_status = 'Cancelled'  
      AND client_subsidiary_id = 6 
      AND po_orderid NOT IN (
            SELECT DISTINCT a.po_orderid 
            FROM ow_lao.ods_sales_control_tower_table a 
            WHERE a.division IN ('Bundle','SC+','SERVICE')
      )
      AND CAST(po_date AS DATE) BETWEEN CAST(TIMESTAMPADD(DAY, -180, NOW()) AS DATE)
                                    AND CAST(TIMESTAMPADD(DAY, 0, NOW()) AS DATE)
 );
 
 PERFORM UPDATE ow_lao.ods_sales_control_tower_table a
    SET po_internal_status = b.po_internal_status
  FROM ow_lao.temp_division_nerp_control_tower_status b
  WHERE b.po_orderid = a.po_orderid
    AND a.client_subsidiary_id = 6;
 
 PERFORM DROP TABLE ow_lao.temp_division_nerp_control_tower_status;
 
 -- order division sc+, bundles, services
 PERFORM CREATE TABLE ow_lao.temp_division_nerp_control_tower_status AS
 (
    SELECT DISTINCT 
        po_orderid,
        division,
        po_status,
        CASE 
            WHEN po_internal_status = 'payment rejected' THEN 'canceled' 
            WHEN po_internal_status = 'canceled' THEN 'canceled'
            ELSE po_internal_status  
        END AS po_internal_status,
        so_date
    FROM ow_lao.ods_sales_control_tower_table  
    WHERE division IN ('Bundle','SC+','SERVICE')
      AND po_status = 'Cancelled'
      AND client_subsidiary_id = 6 
      AND CAST(po_date AS DATE) BETWEEN CAST(TIMESTAMPADD(DAY, -180, NOW()) AS DATE)
                                    AND CAST(TIMESTAMPADD(DAY, 0, NOW()) AS DATE)
 );
 
 PERFORM UPDATE ow_lao.ods_sales_control_tower_table a
    SET po_internal_status = b.po_internal_status
  FROM ow_lao.temp_division_nerp_control_tower_status b
  WHERE b.po_orderid = a.po_orderid
    AND a.client_subsidiary_id = 6;
 
 PERFORM DROP TABLE ow_lao.temp_division_nerp_control_tower_status;
 
END;
$$;

-- CALL ow_lao.proc_division_nerp_control_tower_status();
-- ERROR: Severity: ROLLBACK, Message: Object "temp_division_nerp_control_tower_status" already exists, Sqlstate: 42710, Where: PL/vSQL procedure proc_division_nerp_control_tower_status line 5 at static SQL, Routine: outputAlreadyExistsEreport, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Commands/DDL.cpp, Line: 28430, Error Code: 4213, 
-- CALL ow_lao.proc_division_nerp_control_tower_status();
-- ERROR: Severity: ROLLBACK, Message: Object "temp_division_nerp_control_tower_status" already exists, Sqlstate: 42710, Where: PL/vSQL procedure proc_division_nerp_control_tower_status line 5 at static SQL, Routine: outputAlreadyExistsEreport, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Commands/DDL.cpp, Line: 28430, Error Code: 4213, 
CREATE OR REPLACE PROCEDURE ow_lao.proc_division_nerp_control_tower_status()
 LANGUAGE PLvSQL AS $$
BEGIN
 
 -- Block 1: payment rejected
 PERFORM DROP TABLE IF EXISTS temp_division_nerp_control_tower_status;
 PERFORM CREATE LOCAL TEMP TABLE temp_division_nerp_control_tower_status ON COMMIT PRESERVE ROWS AS
 (
    SELECT DISTINCT 
        po_orderid,
        division,
        po_status,
        CASE 
            WHEN po_status = 'Cancelled' THEN 'payment rejected'
            ELSE po_internal_status
        END AS po_internal_status,
        so_date
    FROM ow_lao.ods_sales_control_tower_table 
    WHERE po_status = 'Cancelled'
      AND client_subsidiary_id = 6   
      AND CAST(po_date AS DATE) BETWEEN CAST(TIMESTAMPADD(DAY, -180, NOW()) AS DATE)
                                    AND CAST(TIMESTAMPADD(DAY, 0, NOW()) AS DATE)
 );
 
 PERFORM UPDATE ow_lao.ods_sales_control_tower_table a
    SET po_internal_status = b.po_internal_status
  FROM temp_division_nerp_control_tower_status b
  WHERE b.po_orderid = a.po_orderid
    AND a.client_subsidiary_id = 6;
 
 PERFORM DROP TABLE IF EXISTS temp_division_nerp_control_tower_status;
 
 -- Block 2: so_date located and not in specific divisions
 PERFORM DROP TABLE IF EXISTS temp_division_nerp_control_tower_status;
 PERFORM CREATE LOCAL TEMP TABLE temp_division_nerp_control_tower_status ON COMMIT PRESERVE ROWS AS
 (
    SELECT DISTINCT 
        po_orderid,
        division,
        po_status,
        CASE 
            WHEN po_status = 'Cancelled' THEN 'canceled'
            ELSE po_internal_status 
        END AS po_internal_status,
        so_date
    FROM ow_lao.ods_sales_control_tower_table 
    WHERE so_date IS NOT NULL 
      AND po_status = 'Cancelled'  
      AND client_subsidiary_id = 6 
      AND po_orderid NOT IN (
            SELECT DISTINCT a.po_orderid 
            FROM ow_lao.ods_sales_control_tower_table a 
            WHERE a.division IN ('Bundle','SC+','SERVICE')
      )
      AND CAST(po_date AS DATE) BETWEEN CAST(TIMESTAMPADD(DAY, -180, NOW()) AS DATE)
                                    AND CAST(TIMESTAMPADD(DAY, 0, NOW()) AS DATE)
 );
 
 PERFORM UPDATE ow_lao.ods_sales_control_tower_table a
    SET po_internal_status = b.po_internal_status
  FROM temp_division_nerp_control_tower_status b
  WHERE b.po_orderid = a.po_orderid
    AND a.client_subsidiary_id = 6;
 
 PERFORM DROP TABLE IF EXISTS temp_division_nerp_control_tower_status;
 
 -- Block 3: specific divisions
 PERFORM DROP TABLE IF EXISTS temp_division_nerp_control_tower_status;
 PERFORM CREATE LOCAL TEMP TABLE temp_division_nerp_control_tower_status ON COMMIT PRESERVE ROWS AS
 (
    SELECT DISTINCT 
        po_orderid,
        division,
        po_status,
        CASE 
            WHEN po_internal_status = 'payment rejected' THEN 'canceled' 
            WHEN po_internal_status = 'canceled' THEN 'canceled'
            ELSE po_internal_status  
        END AS po_internal_status,
        so_date
    FROM ow_lao.ods_sales_control_tower_table  
    WHERE division IN ('Bundle','SC+','SERVICE')
      AND po_status = 'Cancelled'
      AND client_subsidiary_id = 6 
      AND CAST(po_date AS DATE) BETWEEN CAST(TIMESTAMPADD(DAY, -180, NOW()) AS DATE)
                                    AND CAST(TIMESTAMPADD(DAY, 0, NOW()) AS DATE)
 );
 
 PERFORM UPDATE ow_lao.ods_sales_control_tower_table a
    SET po_internal_status = b.po_internal_status
  FROM temp_division_nerp_control_tower_status b
  WHERE b.po_orderid = a.po_orderid
    AND a.client_subsidiary_id = 6;
 
 PERFORM DROP TABLE IF EXISTS temp_division_nerp_control_tower_status;
 
END;
$$;

CALL ow_lao.proc_division_nerp_control_tower_status();
-- proc_division_nerp_control_tower_status
-- ---------------------------------------
-- 0

