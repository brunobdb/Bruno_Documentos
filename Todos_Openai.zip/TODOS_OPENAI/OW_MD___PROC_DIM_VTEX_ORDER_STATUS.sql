CREATE OR REPLACE PROCEDURE PROC_DIM_VTEX_ORDER_STATUS()
LANGUAGE PLvSQL AS $$
BEGIN
  PERFORM TRUNCATE TABLE OW_MD.TF_VTEX_ORDER_STATUS_01;

  PERFORM INSERT INTO OW_MD.TF_VTEX_ORDER_STATUS_01 
  ("STATUS",
  "STATUS_DESCRIPTION", "CREATE_DATE","UPDATE_DATE")
  SELECT DISTINCT 
  STATUS,
  STATUS_DESCRIPTION,
   CURRENT_TIMESTAMP AS CREATE_DATE,
   CURRENT_TIMESTAMP AS UPDATE_DATE
  FROM  U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER
  WHERE STATUS IS NOT NULL;

  PERFORM MERGE INTO OW_MD.DIM_VTEX_ORDER_STATUS O
  USING OW_MD.TF_VTEX_ORDER_STATUS_01 M
  ON O."STATUS" = M."STATUS"
  AND O."STATUS_DESCRIPTION" = M."STATUS_DESCRIPTION"
   WHEN MATCHED THEN UPDATE 
   SET "STATUS" = M."STATUS",
       "STATUS_DESCRIPTION" = M."STATUS_DESCRIPTION",
       "CREATE_DATE" = M."CREATE_DATE",
       "UPDATE_DATE" = M."UPDATE_DATE"
   WHEN NOT MATCHED THEN INSERT ("STATUS","STATUS_DESCRIPTION","CREATE_DATE","UPDATE_DATE")
   VALUES(M."STATUS",M."STATUS_DESCRIPTION",M."CREATE_DATE", M."UPDATE_DATE");
END;
$$;

-- CALL PROC_DIM_VTEX_ORDER_STATUS();
-- ERROR: Severity: ERROR, Message: Cannot set a NOT NULL column (SUR_KEY) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure PROC_DIM_VTEX_ORDER_STATUS line 5 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3216, Error Code: 2502, 
-- CALL PROC_DIM_VTEX_ORDER_STATUS();
-- ERROR: Severity: ERROR, Message: Cannot set a NOT NULL column (SUR_KEY) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure PROC_DIM_VTEX_ORDER_STATUS line 5 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3216, Error Code: 2502, 
CREATE OR REPLACE PROCEDURE PROC_DIM_VTEX_ORDER_STATUS()
LANGUAGE PLvSQL AS $$
DECLARE
  v_max_sur_key BIGINT := 0;
BEGIN
  PERFORM TRUNCATE TABLE OW_MD.TF_VTEX_ORDER_STATUS_01;

  PERFORM INSERT INTO OW_MD.TF_VTEX_ORDER_STATUS_01 
    ("STATUS", "STATUS_DESCRIPTION", "CREATE_DATE", "UPDATE_DATE")
  SELECT DISTINCT 
    STATUS,
    STATUS_DESCRIPTION,
    CURRENT_TIMESTAMP AS CREATE_DATE,
    CURRENT_TIMESTAMP AS UPDATE_DATE
  FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER
  WHERE STATUS IS NOT NULL;

  -- Update existing rows
  PERFORM UPDATE OW_MD.DIM_VTEX_ORDER_STATUS O
     SET "STATUS" = M."STATUS",
         "STATUS_DESCRIPTION" = M."STATUS_DESCRIPTION",
         "CREATE_DATE" = M."CREATE_DATE",
         "UPDATE_DATE" = M."UPDATE_DATE"
    FROM OW_MD.TF_VTEX_ORDER_STATUS_01 M
   WHERE O."STATUS" = M."STATUS"
     AND O."STATUS_DESCRIPTION" = M."STATUS_DESCRIPTION";

  -- Determine current max surrogate key
  SELECT COALESCE(MAX(SUR_KEY), 0) INTO v_max_sur_key
    FROM OW_MD.DIM_VTEX_ORDER_STATUS;

  -- Insert new rows with generated surrogate keys
  PERFORM INSERT INTO OW_MD.DIM_VTEX_ORDER_STATUS
    (SUR_KEY, "STATUS", "STATUS_DESCRIPTION", "CREATE_DATE", "UPDATE_DATE")
  SELECT v_max_sur_key + ROW_NUMBER() OVER (ORDER BY M."STATUS", M."STATUS_DESCRIPTION") AS SUR_KEY,
         M."STATUS",
         M."STATUS_DESCRIPTION",
         M."CREATE_DATE",
         M."UPDATE_DATE"
    FROM OW_MD.TF_VTEX_ORDER_STATUS_01 M
    LEFT JOIN OW_MD.DIM_VTEX_ORDER_STATUS O
      ON O."STATUS" = M."STATUS"
     AND O."STATUS_DESCRIPTION" = M."STATUS_DESCRIPTION"
   WHERE O.SUR_KEY IS NULL;
END;
$$;

-- CALL PROC_DIM_VTEX_ORDER_STATUS();
-- ERROR: Severity: ERROR, Message: Cannot set a NOT NULL column (SUR_KEY) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure PROC_DIM_VTEX_ORDER_STATUS line 7 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3216, Error Code: 2502, 
-- CALL PROC_DIM_VTEX_ORDER_STATUS();
-- ERROR: Severity: ERROR, Message: Cannot set a NOT NULL column (SUR_KEY) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure PROC_DIM_VTEX_ORDER_STATUS line 7 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3216, Error Code: 2502, 
TRUNCATE TABLE OW_MD.TF_VTEX_ORDER_STATUS_01;

SELECT column_name, data_type, is_nullable, is_identity FROM columns WHERE table_schema='OW_MD' AND table_name='DIM_VTEX_ORDER_STATUS' ORDER BY ordinal_position;
-- column_name | data_type | is_nullable | is_identity
-- ------------+-----------+-------------+------------
-- SUR_KEY | int | False | False
-- STATUS | varchar(155) | True | False
-- STATUS_DESCRIPTION | varchar(255) | True | False
-- CREATE_DATE | timestamp | True | False
-- UPDATE_DATE | timestamp | True | False
-- LOAD_DATE | timestamp | True | False

SELECT table_schema, table_name, column_name, data_type, is_nullable, is_identity, column_default
FROM v_catalog.columns
WHERE table_schema='OW_MD' AND table_name IN ('DIM_VTEX_ORDER_STATUS','TF_VTEX_ORDER_STATUS_01')
ORDER BY table_name, ordinal_position;
-- table_schema | table_name | column_name | data_type | is_nullable | is_identity | column_default
-- -------------+------------+-------------+-----------+-------------+-------------+---------------
-- OW_MD | DIM_VTEX_ORDER_STATUS | SUR_KEY | int | False | False | 
-- OW_MD | DIM_VTEX_ORDER_STATUS | STATUS | varchar(155) | True | False | 
-- OW_MD | DIM_VTEX_ORDER_STATUS | STATUS_DESCRIPTION | varchar(255) | True | False | 
-- OW_MD | DIM_VTEX_ORDER_STATUS | CREATE_DATE | timestamp | True | False | 
-- OW_MD | DIM_VTEX_ORDER_STATUS | UPDATE_DATE | timestamp | True | False | 
-- OW_MD | DIM_VTEX_ORDER_STATUS | LOAD_DATE | timestamp | True | False | 
-- OW_MD | TF_VTEX_ORDER_STATUS_01 | SUR_KEY | int | False | False | 
-- OW_MD | TF_VTEX_ORDER_STATUS_01 | STATUS | varchar(100) | True | False | 
-- OW_MD | TF_VTEX_ORDER_STATUS_01 | STATUS_DESCRIPTION | varchar(100) | True | False | 
-- OW_MD | TF_VTEX_ORDER_STATUS_01 | CREATE_DATE | timestamp | True | False | 
-- OW_MD | TF_VTEX_ORDER_STATUS_01 | UPDATE_DATE | timestamp | True | False | 
-- OW_MD | TF_VTEX_ORDER_STATUS_01 | LOAD_DATE | timestamp | True | False | 

CREATE OR REPLACE PROCEDURE PROC_DIM_VTEX_ORDER_STATUS()
LANGUAGE PLvSQL AS $$
BEGIN
  PERFORM TRUNCATE TABLE OW_MD.TF_VTEX_ORDER_STATUS_01;

  PERFORM INSERT INTO OW_MD.TF_VTEX_ORDER_STATUS_01 
    (SUR_KEY, "STATUS", "STATUS_DESCRIPTION", "CREATE_DATE", "UPDATE_DATE")
  SELECT ROW_NUMBER() OVER (ORDER BY STATUS, STATUS_DESCRIPTION) AS SUR_KEY,
         STATUS,
         STATUS_DESCRIPTION,
         CURRENT_TIMESTAMP AS CREATE_DATE,
         CURRENT_TIMESTAMP AS UPDATE_DATE
    FROM (
      SELECT DISTINCT STATUS, STATUS_DESCRIPTION
      FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER
      WHERE STATUS IS NOT NULL
    ) src;

  PERFORM MERGE INTO OW_MD.DIM_VTEX_ORDER_STATUS O
  USING OW_MD.TF_VTEX_ORDER_STATUS_01 M
  ON O."STATUS" = M."STATUS"
   AND O."STATUS_DESCRIPTION" = M."STATUS_DESCRIPTION"
  WHEN MATCHED THEN UPDATE 
    SET "STATUS" = M."STATUS",
        "STATUS_DESCRIPTION" = M."STATUS_DESCRIPTION",
        "CREATE_DATE" = M."CREATE_DATE",
        "UPDATE_DATE" = M."UPDATE_DATE"
  WHEN NOT MATCHED THEN INSERT ("STATUS","STATUS_DESCRIPTION","CREATE_DATE","UPDATE_DATE")
    VALUES (M."STATUS", M."STATUS_DESCRIPTION", M."CREATE_DATE", M."UPDATE_DATE");
END;
$$;

-- CALL PROC_DIM_VTEX_ORDER_STATUS();
-- ERROR: Severity: ERROR, Message: Cannot set a NOT NULL column (SUR_KEY) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure PROC_DIM_VTEX_ORDER_STATUS line 18 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3216, Error Code: 2502, 
-- CALL PROC_DIM_VTEX_ORDER_STATUS();
-- ERROR: Severity: ERROR, Message: Cannot set a NOT NULL column (SUR_KEY) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure PROC_DIM_VTEX_ORDER_STATUS line 18 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3216, Error Code: 2502, 
SELECT column_name, data_type, is_nullable, is_identity, column_default, ordinal_position
FROM v_catalog.columns
WHERE LOWER(table_schema)='ow_md' AND LOWER(table_name)='tf_vtex_order_status_01'
ORDER BY ordinal_position;
-- column_name | data_type | is_nullable | is_identity | column_default | ordinal_position
-- ------------+-----------+-------------+-------------+----------------+-----------------
-- SUR_KEY | int | False | False |  | 1
-- STATUS | varchar(100) | True | False |  | 2
-- STATUS_DESCRIPTION | varchar(100) | True | False |  | 3
-- CREATE_DATE | timestamp | True | False |  | 4
-- UPDATE_DATE | timestamp | True | False |  | 5
-- LOAD_DATE | timestamp | True | False |  | 6

CREATE OR REPLACE PROCEDURE PROC_DIM_VTEX_ORDER_STATUS()
LANGUAGE PLvSQL AS $$
BEGIN
  PERFORM TRUNCATE TABLE OW_MD.TF_VTEX_ORDER_STATUS_01;

  PERFORM INSERT INTO OW_MD.TF_VTEX_ORDER_STATUS_01 
    ("SUR_KEY", "STATUS", "STATUS_DESCRIPTION", "CREATE_DATE", "UPDATE_DATE")
  SELECT ROW_NUMBER() OVER (ORDER BY STATUS, STATUS_DESCRIPTION) AS SUR_KEY,
         STATUS,
         STATUS_DESCRIPTION,
         CURRENT_TIMESTAMP AS CREATE_DATE,
         CURRENT_TIMESTAMP AS UPDATE_DATE
    FROM (
      SELECT DISTINCT STATUS, STATUS_DESCRIPTION
      FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER
      WHERE STATUS IS NOT NULL
    ) s;

  PERFORM UPDATE OW_MD.DIM_VTEX_ORDER_STATUS O
     SET "STATUS" = M."STATUS",
         "STATUS_DESCRIPTION" = M."STATUS_DESCRIPTION",
         "CREATE_DATE" = M."CREATE_DATE",
         "UPDATE_DATE" = M."UPDATE_DATE"
    FROM OW_MD.TF_VTEX_ORDER_STATUS_01 M
   WHERE O."STATUS" = M."STATUS"
     AND O."STATUS_DESCRIPTION" = M."STATUS_DESCRIPTION";

  PERFORM INSERT INTO OW_MD.DIM_VTEX_ORDER_STATUS
    ("SUR_KEY", "STATUS", "STATUS_DESCRIPTION", "CREATE_DATE", "UPDATE_DATE")
  WITH max_sur AS (
    SELECT COALESCE(MAX("SUR_KEY"), 0) AS max_sur FROM OW_MD.DIM_VTEX_ORDER_STATUS
  )
  SELECT max_sur + ROW_NUMBER() OVER (ORDER BY M."STATUS", M."STATUS_DESCRIPTION") AS SUR_KEY,
         M."STATUS",
         M."STATUS_DESCRIPTION",
         M."CREATE_DATE",
         M."UPDATE_DATE"
    FROM OW_MD.TF_VTEX_ORDER_STATUS_01 M
    LEFT JOIN OW_MD.DIM_VTEX_ORDER_STATUS O
      ON O."STATUS" = M."STATUS"
     AND O."STATUS_DESCRIPTION" = M."STATUS_DESCRIPTION"
    CROSS JOIN max_sur
   WHERE O."SUR_KEY" IS NULL;
END;
$$;

CALL PROC_DIM_VTEX_ORDER_STATUS();
-- PROC_DIM_VTEX_ORDER_STATUS
-- --------------------------
-- 0

