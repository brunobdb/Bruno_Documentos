-- CREATE OR REPLACE PROCEDURE ow_lao.proc_monitoring_bi_lao_proccess_system_reviews_nerp()
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--     -- Ensure staging table exists, then refresh it
--     PERFORM CREATE TABLE IF NOT EXISTS OW_LAO.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_2 AS
--         SELECT 
--             ROW_NUMBER() OVER() AS id,
--             CAST(NULL AS VARCHAR(200)) AS CUSTOMER_PO,
--             CAST(NULL AS VARCHAR(200)) AS SALES_DOCUMENT
--         WHERE 1=0;
-- 
--     PERFORM TRUNCATE TABLE OW_LAO.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_2;
-- 
--     PERFORM INSERT INTO OW_LAO.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_2 (id, CUSTOMER_PO, SALES_DOCUMENT)
--     SELECT 
--         ROW_NUMBER() OVER() AS id,
--         SUBSTR(
--             SUBSTR(REFERENCIA, CASE WHEN POSITION(': ' IN REFERENCIA) > 0 THEN POSITION(': ' IN REFERENCIA) + 2 ELSE 1 END, 20),
--             1,
--             CASE 
--                 WHEN POSITION('sa' IN SUBSTR(REFERENCIA, CASE WHEN POSITION(': ' IN REFERENCIA) > 0 THEN POSITION(': ' IN REFERENCIA) + 2 ELSE 1 END, 20)) > 0 
--                      THEN POSITION('sa' IN SUBSTR(REFERENCIA, CASE WHEN POSITION(': ' IN REFERENCIA) > 0 THEN POSITION(': ' IN REFERENCIA) + 2 ELSE 1 END, 20)) - 1
--                 ELSE LENGTH(SUBSTR(REFERENCIA, CASE WHEN POSITION(': ' IN REFERENCIA) > 0 THEN POSITION(': ' IN REFERENCIA) + 2 ELSE 1 END, 20))
--             END
--         ) AS CUSTOMER_PO,
--         SUBSTR(REFERENCIA, CASE WHEN POSITION('sales_document: ' IN REFERENCIA) > 0 THEN POSITION('sales_document: ' IN REFERENCIA) + 16 ELSE 1 END, 10) AS SALES_DOCUMENT
--     FROM OW_LAO.MONITORING_BI_LAO_PROCCESS
--     WHERE ORIGEM_NOME = 'ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking';
-- 
--     -- Ensure delete-filter table exists, then refresh it
--     PERFORM CREATE TABLE IF NOT EXISTS OW_LAO.TEMP_ODS_SALES_CONTROL_TOWER_TABLE_NERP_UPDATE_MONITORING_FILTER_DELETE_2 AS
--         SELECT id, CUSTOMER_PO, SALES_DOCUMENT
--         FROM OW_LAO.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_2
--         WHERE 1=0;
-- 
--     PERFORM TRUNCATE TABLE OW_LAO.TEMP_ODS_SALES_CONTROL_TOWER_TABLE_NERP_UPDATE_MONITORING_FILTER_DELETE_2;
-- 
--     PERFORM INSERT INTO OW_LAO.TEMP_ODS_SALES_CONTROL_TOWER_TABLE_NERP_UPDATE_MONITORING_FILTER_DELETE_2 (id, CUSTOMER_PO, SALES_DOCUMENT)
--     SELECT C.id, C.CUSTOMER_PO, C.SALES_DOCUMENT
--       FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A 
--       JOIN OW_MD.DIM_SUBSIDIARY B ON LOWER(B.COUNTRY) = LOWER(A.COUNTRY)
--       JOIN OW_LAO.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_2 C ON C.CUSTOMER_PO = A.PO_SEQUENCE_ORDERID
--                                                                                        AND '8201' = B.SALES_ORG
--     UNION ALL
--     SELECT C.id, C.CUSTOMER_PO, C.SALES_DOCUMENT
--       FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A 
--       JOIN OW_MD.DIM_SUBSIDIARY B ON LOWER(B.COUNTRY) = LOWER(A.COUNTRY)
--       JOIN OW_LAO.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_2 C ON C.SALES_DOCUMENT = A.PO_ORDERSID
--                                                                                        AND '8201' = B.SALES_ORG
--     UNION ALL
--     SELECT C.id, C.CUSTOMER_PO, C.SALES_DOCUMENT
--       FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A 
--       JOIN OW_MD.DIM_SUBSIDIARY B ON LOWER(B.COUNTRY) = LOWER(A.COUNTRY)
--       JOIN OW_LAO.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_2 C ON C.CUSTOMER_PO = A.PO_ORDERID
--                                                                                        AND '8201' = B.SALES_ORG;
-- 
--     -- Remove non-matching rows from the main temp table
--     PERFORM DELETE FROM OW_LAO.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_2 A
--     WHERE A.ID NOT IN (
--         SELECT DISTINCT ID FROM OW_LAO.TEMP_ODS_SALES_CONTROL_TOWER_TABLE_NERP_UPDATE_MONITORING_FILTER_DELETE_2
--     );
-- 
--     -- Update monitoring table for corrected entries
--     PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS A
--        SET STATUS_NOME = 'Corrigido pelo sistema',
--            OBSERVACAO = 'Pedido foi importado posteriormente',
--            UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
--       FROM OW_LAO.TEMP_ODS_SALES_CONTROL_TOWER_TABLE_NERP_UPDATE_MONITORING_FILTER_2 B 
--      WHERE A.ORIGEM_NOME = 'ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking'
--        AND A.STATUS_NOME = 'Em analise'
--        AND ('customer_po: ' || B.CUSTOMER_PO || 'sales_document: ' || B.SALES_DOCUMENT) = A.REFERENCIA;
-- 
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: Syntax error at or near "A", Sqlstate: 42601, Position: 3728, Routine: base_yyerror, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/scan.l, Line: 1056, Error Code: 4856, 
-- CREATE OR REPLACE PROCEDURE ow_lao.proc_monitoring_bi_lao_proccess_system_reviews_nerp()
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--     -- Ensure main staging table exists, then refresh it
--     PERFORM CREATE TABLE IF NOT EXISTS OW_LAO.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_2 (
--         id INT,
--         customer_po VARCHAR(200),
--         sales_document VARCHAR(200)
--     );
-- 
--     PERFORM TRUNCATE TABLE OW_LAO.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_2;
-- 
--     PERFORM INSERT INTO OW_LAO.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_2 (id, customer_po, sales_document)
--     SELECT 
--         ROW_NUMBER() OVER (ORDER BY REFERENCIA) AS id,
--         SUBSTR(
--             SUBSTR(REFERENCIA, CASE WHEN POSITION(': ' IN REFERENCIA) > 0 THEN POSITION(': ' IN REFERENCIA) + 2 ELSE 1 END, 20),
--             1,
--             CASE 
--                 WHEN POSITION('sa' IN SUBSTR(REFERENCIA, CASE WHEN POSITION(': ' IN REFERENCIA) > 0 THEN POSITION(': ' IN REFERENCIA) + 2 ELSE 1 END, 20)) > 0 
--                 THEN POSITION('sa' IN SUBSTR(REFERENCIA, CASE WHEN POSITION(': ' IN REFERENCIA) > 0 THEN POSITION(': ' IN REFERENCIA) + 2 ELSE 1 END, 20)) - 1
--                 ELSE LENGTH(SUBSTR(REFERENCIA, CASE WHEN POSITION(': ' IN REFERENCIA) > 0 THEN POSITION(': ' IN REFERENCIA) + 2 ELSE 1 END, 20))
--             END
--         ) AS CUSTOMER_PO,
--         SUBSTR(REFERENCIA, CASE WHEN POSITION('sales_document: ' IN REFERENCIA) > 0 THEN POSITION('sales_document: ' IN REFERENCIA) + 16 ELSE 1 END, 10) AS SALES_DOCUMENT
--     FROM OW_LAO.MONITORING_BI_LAO_PROCCESS
--     WHERE ORIGEM_NOME = 'ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking';
-- 
--     -- Ensure delete-filter table exists, then refresh it
--     PERFORM CREATE TABLE IF NOT EXISTS OW_LAO.TEMP_ODS_SALES_CONTROL_TOWER_TABLE_NERP_UPDATE_MONITORING_FILTER_DELETE_2 (
--         id INT,
--         customer_po VARCHAR(200),
--         sales_document VARCHAR(200)
--     );
-- 
--     PERFORM TRUNCATE TABLE OW_LAO.TEMP_ODS_SALES_CONTROL_TOWER_TABLE_NERP_UPDATE_MONITORING_FILTER_DELETE_2;
-- 
--     PERFORM INSERT INTO OW_LAO.TEMP_ODS_SALES_CONTROL_TOWER_TABLE_NERP_UPDATE_MONITORING_FILTER_DELETE_2 (id, customer_po, sales_document)
--     SELECT C.id, C.CUSTOMER_PO, C.SALES_DOCUMENT
--       FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A 
--       JOIN OW_MD.DIM_SUBSIDIARY B ON LOWER(B.COUNTRY) = LOWER(A.COUNTRY)
--       JOIN OW_LAO.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_2 C ON C.CUSTOMER_PO = A.PO_SEQUENCE_ORDERID
--                                                                                        AND '8201' = B.SALES_ORG
--     UNION ALL
--     SELECT C.id, C.CUSTOMER_PO, C.SALES_DOCUMENT
--       FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A 
--       JOIN OW_MD.DIM_SUBSIDIARY B ON LOWER(B.COUNTRY) = LOWER(A.COUNTRY)
--       JOIN OW_LAO.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_2 C ON C.SALES_DOCUMENT = A.PO_ORDERSID
--                                                                                        AND '8201' = B.SALES_ORG
--     UNION ALL
--     SELECT C.id, C.CUSTOMER_PO, C.SALES_DOCUMENT
--       FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A 
--       JOIN OW_MD.DIM_SUBSIDIARY B ON LOWER(B.COUNTRY) = LOWER(A.COUNTRY)
--       JOIN OW_LAO.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_2 C ON C.CUSTOMER_PO = A.PO_ORDERID
--                                                                                        AND '8201' = B.SALES_ORG;
-- 
--     -- Remove non-matching rows from the main temp table
--     PERFORM DELETE FROM OW_LAO.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_2 A
--     WHERE A.ID NOT IN (
--         SELECT DISTINCT ID FROM OW_LAO.TEMP_ODS_SALES_CONTROL_TOWER_TABLE_NERP_UPDATE_MONITORING_FILTER_DELETE_2
--     );
-- 
--     -- Update monitoring table for corrected entries
--     PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS
--        SET STATUS_NOME = 'Corrigido pelo sistema',
--            OBSERVACAO = 'Pedido foi importado posteriormente',
--            UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
--      WHERE ORIGEM_NOME = 'ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking'
--        AND STATUS_NOME = 'Em analise'
--        AND REFERENCIA IN (
--            SELECT 'customer_po: ' || CUSTOMER_PO || 'sales_document: ' || SALES_DOCUMENT
--              FROM OW_LAO.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_2
--        );
-- 
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: Syntax error at or near "A", Sqlstate: 42601, Position: 3593, Routine: base_yyerror, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/scan.l, Line: 1056, Error Code: 4856, 
-- CREATE OR REPLACE PROCEDURE ow_lao.proc_monitoring_bi_lao_proccess_system_reviews_nerp()
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--     -- Refresh staging tables (assumed to exist)
--     PERFORM TRUNCATE TABLE OW_LAO.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_2;
--     PERFORM TRUNCATE TABLE OW_LAO.TEMP_ODS_SALES_CONTROL_TOWER_TABLE_NERP_UPDATE_MONITORING_FILTER_DELETE_2;
-- 
--     -- Populate main staging table with parsed values
--     PERFORM INSERT INTO OW_LAO.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_2 (id, CUSTOMER_PO, SALES_DOCUMENT)
--     SELECT 
--         ROW_NUMBER() OVER (ORDER BY REFERENCIA) AS id,
--         SUBSTR(
--             SUBSTR(REFERENCIA, COALESCE(NULLIF(POSITION(': ' IN REFERENCIA),0), 0) + 2, 20),
--             1,
--             CASE 
--                 WHEN POSITION('sa' IN SUBSTR(REFERENCIA, COALESCE(NULLIF(POSITION(': ' IN REFERENCIA),0), 0) + 2, 20)) > 0
--                      THEN POSITION('sa' IN SUBSTR(REFERENCIA, COALESCE(NULLIF(POSITION(': ' IN REFERENCIA),0), 0) + 2, 20)) - 1
--                 ELSE LENGTH(SUBSTR(REFERENCIA, COALESCE(NULLIF(POSITION(': ' IN REFERENCIA),0), 0) + 2, 20))
--             END
--         ) AS CUSTOMER_PO,
--         SUBSTR(REFERENCIA, COALESCE(NULLIF(POSITION('sales_document: ' IN REFERENCIA),0), 0) + 16, 10) AS SALES_DOCUMENT
--     FROM OW_LAO.MONITORING_BI_LAO_PROCCESS
--     WHERE ORIGEM_NOME = 'ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking';
-- 
--     -- Build delete-filter table via 3 matching strategies
--     PERFORM INSERT INTO OW_LAO.TEMP_ODS_SALES_CONTROL_TOWER_TABLE_NERP_UPDATE_MONITORING_FILTER_DELETE_2 (id, CUSTOMER_PO, SALES_DOCUMENT)
--     SELECT C.id, C.CUSTOMER_PO, C.SALES_DOCUMENT
--       FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A
--       JOIN OW_MD.DIM_SUBSIDIARY B ON LOWER(B.COUNTRY) = LOWER(A.COUNTRY)
--       JOIN OW_LAO.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_2 C ON C.CUSTOMER_PO = A.PO_SEQUENCE_ORDERID
--                                                                                        AND '8201' = B.SALES_ORG
--     UNION ALL
--     SELECT C.id, C.CUSTOMER_PO, C.SALES_DOCUMENT
--       FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A
--       JOIN OW_MD.DIM_SUBSIDIARY B ON LOWER(B.COUNTRY) = LOWER(A.COUNTRY)
--       JOIN OW_LAO.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_2 C ON C.SALES_DOCUMENT = A.PO_ORDERSID
--                                                                                        AND '8201' = B.SALES_ORG
--     UNION ALL
--     SELECT C.id, C.CUSTOMER_PO, C.SALES_DOCUMENT
--       FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A
--       JOIN OW_MD.DIM_SUBSIDIARY B ON LOWER(B.COUNTRY) = LOWER(A.COUNTRY)
--       JOIN OW_LAO.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_2 C ON C.CUSTOMER_PO = A.PO_ORDERID
--                                                                                        AND '8201' = B.SALES_ORG;
-- 
--     -- Remove non-matching rows
--     PERFORM DELETE FROM OW_LAO.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_2 A
--      WHERE A.ID NOT IN (
--          SELECT DISTINCT ID FROM OW_LAO.TEMP_ODS_SALES_CONTROL_TOWER_TABLE_NERP_UPDATE_MONITORING_FILTER_DELETE_2
--      );
-- 
--     -- Update monitoring table for corrected entries
--     PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS
--        SET STATUS_NOME = 'Corrigido pelo sistema',
--            OBSERVACAO = 'Pedido foi importado posteriormente',
--            UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
--      WHERE ORIGEM_NOME = 'ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking'
--        AND STATUS_NOME = 'Em analise'
--        AND REFERENCIA IN (
--            SELECT 'customer_po: ' || CUSTOMER_PO || 'sales_document: ' || SALES_DOCUMENT
--              FROM OW_LAO.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_2
--        );
-- 
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: Syntax error at or near "A", Sqlstate: 42601, Position: 2996, Routine: base_yyerror, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/scan.l, Line: 1056, Error Code: 4856, 
CREATE OR REPLACE PROCEDURE ow_lao.proc_monitoring_bi_lao_proccess_system_reviews_nerp()
LANGUAGE PLvSQL AS $$
BEGIN
    -- Refresh staging tables
    PERFORM TRUNCATE TABLE OW_LAO.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_2;
    PERFORM TRUNCATE TABLE OW_LAO.TEMP_ODS_SALES_CONTROL_TOWER_TABLE_NERP_UPDATE_MONITORING_FILTER_DELETE_2;

    -- Populate main staging table with parsed values
    PERFORM INSERT INTO OW_LAO.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_2 (id, CUSTOMER_PO, SALES_DOCUMENT)
    SELECT 
        ROW_NUMBER() OVER (ORDER BY REFERENCIA) AS id,
        SUBSTR(
            SUBSTR(REFERENCIA, CASE WHEN POSITION(': ' IN REFERENCIA) > 0 THEN POSITION(': ' IN REFERENCIA) + 2 ELSE 1 END, 20),
            1,
            CASE 
                WHEN POSITION('sa' IN SUBSTR(REFERENCIA, CASE WHEN POSITION(': ' IN REFERENCIA) > 0 THEN POSITION(': ' IN REFERENCIA) + 2 ELSE 1 END, 20)) > 0
                     THEN POSITION('sa' IN SUBSTR(REFERENCIA, CASE WHEN POSITION(': ' IN REFERENCIA) > 0 THEN POSITION(': ' IN REFERENCIA) + 2 ELSE 1 END, 20)) - 1
                ELSE LENGTH(SUBSTR(REFERENCIA, CASE WHEN POSITION(': ' IN REFERENCIA) > 0 THEN POSITION(': ' IN REFERENCIA) + 2 ELSE 1 END, 20))
            END
        ) AS CUSTOMER_PO,
        SUBSTR(REFERENCIA, CASE WHEN POSITION('sales_document: ' IN REFERENCIA) > 0 THEN POSITION('sales_document: ' IN REFERENCIA) + 16 ELSE 1 END, 10) AS SALES_DOCUMENT
    FROM OW_LAO.MONITORING_BI_LAO_PROCCESS
    WHERE ORIGEM_NOME = 'ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking';

    -- Build delete-filter table via 3 matching strategies
    PERFORM INSERT INTO OW_LAO.TEMP_ODS_SALES_CONTROL_TOWER_TABLE_NERP_UPDATE_MONITORING_FILTER_DELETE_2 (id, CUSTOMER_PO, SALES_DOCUMENT)
    SELECT C.id, C.CUSTOMER_PO, C.SALES_DOCUMENT
      FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A
      JOIN OW_MD.DIM_SUBSIDIARY B ON LOWER(B.COUNTRY) = LOWER(A.COUNTRY)
      JOIN OW_LAO.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_2 C ON C.CUSTOMER_PO = A.PO_SEQUENCE_ORDERID
                                                                                       AND '8201' = B.SALES_ORG
    UNION ALL
    SELECT C.id, C.CUSTOMER_PO, C.SALES_DOCUMENT
      FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A
      JOIN OW_MD.DIM_SUBSIDIARY B ON LOWER(B.COUNTRY) = LOWER(A.COUNTRY)
      JOIN OW_LAO.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_2 C ON C.SALES_DOCUMENT = A.PO_ORDERSID
                                                                                       AND '8201' = B.SALES_ORG
    UNION ALL
    SELECT C.id, C.CUSTOMER_PO, C.SALES_DOCUMENT
      FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A
      JOIN OW_MD.DIM_SUBSIDIARY B ON LOWER(B.COUNTRY) = LOWER(A.COUNTRY)
      JOIN OW_LAO.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_2 C ON C.CUSTOMER_PO = A.PO_ORDERID
                                                                                       AND '8201' = B.SALES_ORG;

    -- Remove non-matching rows
    PERFORM DELETE FROM OW_LAO.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_2
     WHERE ID NOT IN (
         SELECT DISTINCT ID FROM OW_LAO.TEMP_ODS_SALES_CONTROL_TOWER_TABLE_NERP_UPDATE_MONITORING_FILTER_DELETE_2
     );

    -- Update monitoring table for corrected entries
    PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS
       SET STATUS_NOME = 'Corrigido pelo sistema',
           OBSERVACAO = 'Pedido foi importado posteriormente',
           UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
     WHERE ORIGEM_NOME = 'ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking'
       AND STATUS_NOME = 'Em analise'
       AND REFERENCIA IN (
           SELECT 'customer_po: ' || CUSTOMER_PO || 'sales_document: ' || SALES_DOCUMENT
             FROM OW_LAO.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_2
       );

END;
$$;

CALL ow_lao.proc_monitoring_bi_lao_proccess_system_reviews_nerp();
-- proc_monitoring_bi_lao_proccess_system_reviews_nerp
-- ---------------------------------------------------
-- 0

