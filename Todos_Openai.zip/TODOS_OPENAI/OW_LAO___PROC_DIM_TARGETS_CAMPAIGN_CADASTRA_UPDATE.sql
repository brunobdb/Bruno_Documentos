CREATE OR REPLACE PROCEDURE OW_LAO.PROC_DIM_TARGETS_CAMPAIGN_CADASTRA_UPDATE()
LANGUAGE PLvSQL AS $$
BEGIN
  PERFORM TRUNCATE TABLE OW_LAO.DIM_LAO_TARGETS_CAMPAIGN_CADASTRA;

  PERFORM INSERT INTO OW_LAO.DIM_LAO_TARGETS_CAMPAIGN_CADASTRA
  WITH campaign_target AS (
      SELECT
          CAMPAIGN_NAME AS CAMPAIGN_TAG,
          CAST(SUB AS VARCHAR(256)) AS SUB,
          "DAY",
          CASE
              WHEN division IS NULL OR division = '' THEN 'all'
              ELSE UPPER(division)
          END AS DIVISION,
          CASE
              WHEN BIZ_TYPE IS NULL OR BIZ_TYPE = '' THEN 'all'
              ELSE UPPER(BIZ_TYPE)
          END AS BIZ_TYPE,
          CASE
              WHEN DEVICE_TYPE IS NULL OR DEVICE_TYPE = '' THEN 'all'
              ELSE LOWER(DEVICE_TYPE)
          END AS DEVICETYPE,
          CEJ_KPIS,
          VALUE
      FROM OW_LAO.ODS_TARGETS_CAMPAIGN AS targets
     ),
  expanded_campaign AS (
      SELECT
          CAMPAIGN_TAG,
          "DAY",
          CAST(SUB AS VARCHAR(256)) AS SUB,
          'SMB' AS BIZ_TYPE,
          'app' AS DEVICETYPE,
          'MX' AS division,
          CEJ_KPIS,
          VALUE
      FROM campaign_target
      WHERE BIZ_TYPE = 'all' AND DEVICETYPE = 'all' AND division = 'all'
      UNION ALL
      SELECT
          CAMPAIGN_TAG,
          "DAY",
          CAST(SUB AS VARCHAR(256)) AS SUB,
          'SMB' AS BIZ_TYPE,
          'app' AS DEVICETYPE,
          'VD' AS division,
          CEJ_KPIS,
          VALUE
      FROM campaign_target
      WHERE BIZ_TYPE = 'all' AND DEVICETYPE = 'all' AND division = 'all'
      UNION ALL
      SELECT
          CAMPAIGN_TAG,
          "DAY",
          CAST(SUB AS VARCHAR(256)) AS SUB,
          'SMB' AS BIZ_TYPE,
          'app' AS DEVICETYPE,
          'DA' AS division,
          CEJ_KPIS,
          VALUE
      FROM campaign_target
      WHERE BIZ_TYPE = 'all' AND DEVICETYPE = 'all' AND division = 'all'
  ),
  division_only_expansion AS (
      SELECT
          CAMPAIGN_TAG,
          CAST(SUB AS VARCHAR(256)) AS SUB,
          "DAY",
          BIZ_TYPE,
          DEVICETYPE,
          'MX' AS division,
          CEJ_KPIS,
          VALUE
      FROM campaign_target
      WHERE division = 'all' AND BIZ_TYPE != 'all' AND DEVICETYPE != 'all'
      UNION ALL
      SELECT
          CAMPAIGN_TAG,
          CAST(SUB AS VARCHAR(256)) AS SUB,
          "DAY",
          BIZ_TYPE,
          DEVICETYPE,
          'VD' AS division,
          CEJ_KPIS,
          VALUE
      FROM campaign_target
      WHERE division = 'all' AND BIZ_TYPE != 'all' AND DEVICETYPE != 'all'
      UNION ALL
      SELECT
          CAMPAIGN_TAG,
          CAST(SUB AS VARCHAR(256)) AS SUB,
          "DAY",
          BIZ_TYPE,
          DEVICETYPE,
          'DA' AS division,
          CEJ_KPIS,
          VALUE
      FROM campaign_target
      WHERE division = 'all' AND BIZ_TYPE != 'all' AND DEVICETYPE != 'all'
  ),
  business_division_expansion AS (
      SELECT
          CAMPAIGN_TAG,
          CAST(SUB AS VARCHAR(256)) AS SUB,
          "DAY",
          'SMB' AS BIZ_TYPE,
          DEVICETYPE,
          'MX' AS division,
          CEJ_KPIS,
          VALUE
      FROM campaign_target
      WHERE BIZ_TYPE = 'all' AND DEVICETYPE != 'all' AND division = 'all'
      UNION ALL
      SELECT
          CAMPAIGN_TAG,
          CAST(SUB AS VARCHAR(256)) AS SUB,
          "DAY",
          'SMB' AS BIZ_TYPE,
          DEVICETYPE,
          'VD' AS division,
          CEJ_KPIS,
          VALUE
      FROM campaign_target
      WHERE BIZ_TYPE = 'all' AND DEVICETYPE != 'all' AND division = 'all'
      UNION ALL
      SELECT
          CAMPAIGN_TAG,
          CAST(SUB AS VARCHAR(256)) AS SUB,
          "DAY",
          'SMB' AS BIZ_TYPE,
          DEVICETYPE,
          'DA' AS division,
          CEJ_KPIS,
          VALUE
      FROM campaign_target
      WHERE BIZ_TYPE = 'all' AND DEVICETYPE != 'all' AND division = 'all'
  ),
  final_expansion AS (
      SELECT CAMPAIGN_TAG, SUB, "DAY", BIZ_TYPE, DEVICETYPE, DIVISION, CEJ_KPIS, VALUE
      FROM campaign_target
      WHERE BIZ_TYPE != 'all' AND DEVICETYPE != 'all' AND DIVISION != 'all'
      UNION ALL
      SELECT DISTINCT CAMPAIGN_TAG, SUB, "DAY", BIZ_TYPE, DEVICETYPE, DIVISION, CEJ_KPIS, VALUE
      FROM expanded_campaign
      UNION ALL
      SELECT DISTINCT CAMPAIGN_TAG, SUB, "DAY", BIZ_TYPE, DEVICETYPE, DIVISION, CEJ_KPIS, VALUE
      FROM division_only_expansion
      UNION ALL
      SELECT DISTINCT CAMPAIGN_TAG, SUB, "DAY", BIZ_TYPE, DEVICETYPE, DIVISION, CEJ_KPIS, VALUE
      FROM business_division_expansion
  )
  SELECT *
  FROM final_expansion;
END
$$;

CALL OW_LAO.PROC_DIM_TARGETS_CAMPAIGN_CADASTRA_UPDATE();
-- PROC_DIM_TARGETS_CAMPAIGN_CADASTRA_UPDATE
-- -----------------------------------------
-- 0

