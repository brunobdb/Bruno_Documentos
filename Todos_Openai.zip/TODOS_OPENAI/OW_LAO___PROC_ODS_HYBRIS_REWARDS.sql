CREATE OR REPLACE PROCEDURE OW_LAO.PROC_ODS_HYBRIS_REWARDS()
 LANGUAGE PLvSQL AS $$
BEGIN
  PERFORM CREATE LOCAL TEMP TABLE TMP_HYBRIS_REWARDS_DEDUP ON COMMIT PRESERVE ROWS AS
  SELECT
      ROW_NUMBER() OVER (PARTITION BY Country_Cd, Order_Code, Product_Code, Site ORDER BY file_generated_at DESC) AS dedup,
      a.*,
      CASE Rewards_Amount
          WHEN 'null' THEN 0
          ELSE CAST(Rewards_Amount AS NUMERIC(15))
      END AS Rewards_Amount_Fix
  FROM OW_LAO.RAW_HYBRIS_REWARDS a
  WHERE NOT EXISTS (
      SELECT 1 FROM OW_LAO.ODS_HYBRIS_REWARDS aa
      WHERE aa.Country_Cd = a.Country_Cd
        AND aa.Order_Code = a.Order_Code
        AND aa.Product_Code = a.Product_Code
        AND aa.Site = a.Site
        AND aa.file_generated_at >= a.file_generated_at
  );
 
  PERFORM DELETE FROM TMP_HYBRIS_REWARDS_DEDUP WHERE dedup <> 1;

  PERFORM MERGE INTO OW_LAO.ODS_HYBRIS_REWARDS a
  USING TMP_HYBRIS_REWARDS_DEDUP b
  ON b.Country_Cd = a.Country_Cd
     AND b.Order_Code = a.Order_Code
     AND b.Product_Code = a.Product_Code
     AND b.Site = a.Site
     AND b.file_generated_at > a.file_generated_at
  WHEN MATCHED THEN UPDATE SET
     Order_Status = b.Order_Status,
     Estimated_Accrued_Amount = b.Estimated_Accrued_Amount,
     Rewards_Amount = b.Rewards_Amount_Fix,
     Spend_Points = b.Spend_Points,
     LOAD_DATE = b.LOAD_DATE,
     UPDATED_DATE = CURRENT_TIMESTAMP,
     FILE_NAME = b.FILE_NAME,
     FILE_LAST_MODIFIED_TIME = b.FILE_LAST_MODIFIED_TIME,
     FILE_NAME_SHORT = b.FILE_NAME_SHORT,
     file_generated_at = b.file_generated_at
  WHEN NOT MATCHED THEN INSERT VALUES (
     b.Country_Cd,
     b.Order_Code,
     b.Order_Creation_Date_Local,
     b.Product_Code,
     b.Customer_Type,
     b.Store_Type,
     b.Site,
     b.Sales_Application,
     b.Order_Status,
     b.Estimated_Accrued_Amount,
     b.Rewards_Amount_Fix,
     b.Spend_Points,
     b.LOAD_DATE,
     NULL,
     b.FILE_NAME,
     b.FILE_LAST_MODIFIED_TIME,
     b.FILE_NAME_SHORT,
     b.file_generated_at
  );

END;
$$;

-- CALL OW_LAO.PROC_ODS_HYBRIS_REWARDS();
-- ERROR: Severity: ERROR, Message: Column "ID" is of type int but expression is of type varchar, Sqlstate: 42804, Hint: You will need to rewrite or cast the expression, Where: PL/vSQL procedure PROC_ODS_HYBRIS_REWARDS line 23 at static SQL, Routine: updateTargetListEntry, File: parse_target.c, Line: 853, Error Code: 2631, 
-- CALL OW_LAO.PROC_ODS_HYBRIS_REWARDS();
-- ERROR: Severity: ERROR, Message: Column "ID" is of type int but expression is of type varchar, Sqlstate: 42804, Hint: You will need to rewrite or cast the expression, Where: PL/vSQL procedure PROC_ODS_HYBRIS_REWARDS line 23 at static SQL, Routine: updateTargetListEntry, File: parse_target.c, Line: 853, Error Code: 2631, 
SELECT column_name, data_type, ordinal_position
FROM v_catalog.columns
WHERE table_schema = 'OW_LAO' AND table_name = 'ODS_HYBRIS_REWARDS'
ORDER BY ordinal_position;
-- column_name | data_type | ordinal_position
-- ------------+-----------+-----------------
-- ID | int | 1
-- COUNTRY_CD | varchar(255) | 2
-- ORDER_CODE | varchar(255) | 3
-- ORDER_CREATION_DATE_LOCAL | timestamp | 4
-- PRODUCT_CODE | varchar(255) | 5
-- CUSTOMER_TYPE | varchar(255) | 6
-- STORE_TYPE | varchar(255) | 7
-- SITE | varchar(255) | 8
-- SALES_APPLICATION | varchar(255) | 9
-- ORDER_STATUS | varchar(255) | 10
-- ESTIMATED_ACCRUED_AMOUNT | numeric(34,0) | 11
-- REWARDS_AMOUNT | int | 12
-- SPEND_POINTS | int | 13
-- LOAD_DATE | timestamp | 14
-- UPDATED_DATE | timestamp | 15
-- FILE_NAME | varchar(2000) | 16
-- FILE_LAST_MODIFIED_TIME | varchar(255) | 17
-- FILE_NAME_SHORT | varchar(255) | 18
-- FILE_GENERATED_AT | timestamp | 19

CREATE OR REPLACE PROCEDURE OW_LAO.PROC_ODS_HYBRIS_REWARDS()
 LANGUAGE PLvSQL AS $$
BEGIN
  PERFORM CREATE LOCAL TEMP TABLE TMP_HYBRIS_REWARDS_DEDUP ON COMMIT PRESERVE ROWS AS
  SELECT
      ROW_NUMBER() OVER (PARTITION BY Country_Cd, Order_Code, Product_Code, Site ORDER BY file_generated_at DESC) AS dedup,
      a.*,
      CASE Rewards_Amount
          WHEN 'null' THEN 0
          ELSE CAST(Rewards_Amount AS NUMERIC(15))
      END AS Rewards_Amount_Fix
  FROM OW_LAO.RAW_HYBRIS_REWARDS a
  WHERE NOT EXISTS (
      SELECT 1 FROM OW_LAO.ODS_HYBRIS_REWARDS aa
      WHERE aa.Country_Cd = a.Country_Cd
        AND aa.Order_Code = a.Order_Code
        AND aa.Product_Code = a.Product_Code
        AND aa.Site = a.Site
        AND aa.file_generated_at >= a.file_generated_at
  );
 
  PERFORM DELETE FROM TMP_HYBRIS_REWARDS_DEDUP WHERE dedup <> 1;

  PERFORM MERGE INTO OW_LAO.ODS_HYBRIS_REWARDS a
  USING TMP_HYBRIS_REWARDS_DEDUP b
  ON b.Country_Cd = a.Country_Cd
     AND b.Order_Code = a.Order_Code
     AND b.Product_Code = a.Product_Code
     AND b.Site = a.Site
     AND b.file_generated_at > a.file_generated_at
  WHEN MATCHED THEN UPDATE SET
     Order_Status = b.Order_Status,
     Estimated_Accrued_Amount = b.Estimated_Accrued_Amount,
     Rewards_Amount = b.Rewards_Amount_Fix,
     Spend_Points = b.Spend_Points,
     LOAD_DATE = b.LOAD_DATE,
     UPDATED_DATE = CURRENT_TIMESTAMP,
     FILE_NAME = b.FILE_NAME,
     FILE_LAST_MODIFIED_TIME = b.FILE_LAST_MODIFIED_TIME,
     FILE_NAME_SHORT = b.FILE_NAME_SHORT,
     file_generated_at = b.file_generated_at
  WHEN NOT MATCHED THEN INSERT (
     Country_Cd,
     Order_Code,
     Order_Creation_Date_Local,
     Product_Code,
     Customer_Type,
     Store_Type,
     Site,
     Sales_Application,
     Order_Status,
     Estimated_Accrued_Amount,
     Rewards_Amount,
     Spend_Points,
     LOAD_DATE,
     UPDATED_DATE,
     FILE_NAME,
     FILE_LAST_MODIFIED_TIME,
     FILE_NAME_SHORT,
     file_generated_at
  ) VALUES (
     b.Country_Cd,
     b.Order_Code,
     b.Order_Creation_Date_Local,
     b.Product_Code,
     b.Customer_Type,
     b.Store_Type,
     b.Site,
     b.Sales_Application,
     b.Order_Status,
     b.Estimated_Accrued_Amount,
     b.Rewards_Amount_Fix,
     b.Spend_Points,
     b.LOAD_DATE,
     NULL,
     b.FILE_NAME,
     b.FILE_LAST_MODIFIED_TIME,
     b.FILE_NAME_SHORT,
     b.file_generated_at
  );

END;
$$;

CALL OW_LAO.PROC_ODS_HYBRIS_REWARDS();
-- PROC_ODS_HYBRIS_REWARDS
-- -----------------------
-- 0

