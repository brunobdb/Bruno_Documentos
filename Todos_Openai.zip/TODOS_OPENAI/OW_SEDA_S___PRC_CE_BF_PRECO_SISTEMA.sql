-- SELECT TIME_SLICE(CURRENT_TIMESTAMP, '10 minute') AS ts;
-- ERROR: Severity: ERROR, Message: Invalid input syntax for integer: "10 minute", Sqlstate: 22V02, Routine: scanint8, File: int8.c, Line: 121, Error Code: 3681, 
-- CREATE OR REPLACE PROCEDURE OW_SEDA_S.PRC_CE_BF_PRECO_SISTEMA(NUMBER_OF_DAYS INT)
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--     
--     PERFORM CREATE LOCAL TEMPORARY TABLE TMP_AUX ON COMMIT PRESERVE ROWS AS
--     SELECT *
--     FROM OW_SEDA_S.ODS_CE_WEBPRICE_API
--     WHERE INPUT_DATE BETWEEN TIMESTAMPADD(DAY, -1 * NUMBER_OF_DAYS, CURRENT_DATE)
--                           AND TIMESTAMPADD(DAY, 1, CURRENT_DATE);
--     
--     PERFORM TRUNCATE TABLE OW_SEDA_S.TMP_CE_BF_PRICE_AGGREGATIONS;
--     PERFORM INSERT INTO OW_SEDA_S.TMP_CE_BF_PRICE_AGGREGATIONS
--     SELECT
--         mcs.CHANNEL,
--         fcps."EXECUTION DATE" AS DATE_COLLECTED,
--         fcps.ITEM,
--         MIN(COALESCE(fcps."SPOT PRICE", 0.0)) AS MIN_PRICE,
--         MAX(COALESCE(fcps."SPOT PRICE", 0.0)) AS MAX_PRICE,
--         MAX(mode.PRICE_MODE) AS MODE_PRICE,
--         MAX(mode.COUNT_MODE_PRICES) AS COUNT_MODE_PRICES, 
--         COUNT(fcps."SITE ID") AS STORES_VISITED,
--         COUNT(DISTINCT (fcps."SITE ID" || '|' || fcps.ITEM)) AS COLLECTED_PRICES,
--         'Preço Tag' AS REPORT_TYPE
--     FROM OW_SEDA_S.FT_CE_PRICE_STORE fcps 
--     INNER JOIN OW_SEDA_S.MAP_CE_STORES mcs ON mcs.SITE_ID = fcps."SITE ID" 
--     INNER JOIN (
--     	SELECT CHANNEL, ITEM, DATE_COLLECTED, PRICE_MODE, COUNT_MODE_PRICES FROM (
--     		SELECT
--     			mcs.CHANNEL,
--     			fcps.ITEM,
--     			fcps."EXECUTION DATE" AS DATE_COLLECTED,
--     			COALESCE(fcps."SPOT PRICE",0.0) AS PRICE_MODE,
--     			COUNT(*) AS COUNT_MODE_PRICES,
--     			ROW_NUMBER() OVER (
--                     PARTITION BY mcs.CHANNEL, fcps.ITEM, fcps."EXECUTION DATE" 
--                     ORDER BY COUNT(*) DESC, COALESCE(fcps."SPOT PRICE",0.0) ASC
--                 ) AS ROW_NUM
--     		FROM OW_SEDA_S.FT_CE_PRICE_STORE fcps 
--     		INNER JOIN OW_SEDA_S.MAP_CE_STORES mcs ON mcs.SITE_ID = fcps."SITE ID" 
--     		WHERE 1=1
--     			AND COALESCE(fcps."SPOT PRICE",0.0) > 0
--     			AND CATEGORY = 'CTV'
--     		GROUP BY 
--     			mcs.CHANNEL,
--     			fcps.ITEM,
--     			fcps."EXECUTION DATE",
--     			fcps."SPOT PRICE"
--     	)
--         WHERE ROW_NUM = 1
--     ) mode 
--     	ON 1=1
--     		AND mode.CHANNEL = mcs.CHANNEL
--     		AND mode.ITEM = fcps.ITEM 
--     		AND mode.DATE_COLLECTED = fcps."EXECUTION DATE" 
--     WHERE 1=1
--     	AND fcps."EXECUTION DATE" BETWEEN TIMESTAMPADD(DAY, -1 * NUMBER_OF_DAYS, CURRENT_DATE) AND CURRENT_DATE 
--     	AND CATEGORY = 'CTV'
--     	AND fcps."SPOT PRICE" NOT LIKE '%ETIQUETA%'
--     GROUP BY 
--     	mcs.CHANNEL,
--     	fcps."EXECUTION DATE",
--     	fcps.ITEM
--     UNION ALL 
--     
--     SELECT
--         UPPER(wb.STORE_NAME) AS CHANNEL,
--         CAST(wb.INPUT_DATE AS DATE) AS DATE_COLLECTED,
--         wb.ITEM,
--         MIN(wb.PRECO_A_VISTA) AS MIN_PRICE_COLLECTED,
--         MAX(wb.PRECO_A_VISTA) AS MAX_PRICE_COLLECTED,
--         MAX(moda.MODA_PRECO_A_VISTA) AS MODE_PRICE_COLLECTED,
--         MAX(moda.COUNT_MODE_PRICES) AS COUNT_MODE_PRICES,
--         1 AS STORES_VISITED,
--         COUNT(DISTINCT (COALESCE(wb.ITEM,'') || '|' || COALESCE(wb.STORE_NAME,'') || '|' || TO_CHAR(CAST(wb.INPUT_DATE AS DATE), 'YYYY-MM-DD'))) AS COLLECTED_PRICES,
--         'Preço Online' AS REPORT_TYPE
--     FROM TMP_AUX wb
--     INNER JOIN OW_SEDA_S.MAP_CE_PRODUCTS mcp ON mcp.ITEM = wb.ITEM 
--     LEFT JOIN 
--     (
--     SELECT ITEM, STORE_NAME, MARKETPLACE_NAME, INPUT_DATE, AVG(PRECO_A_VISTA) AS MODA_PRECO_A_VISTA, MAX(COUNT_MODE_PRICES) AS COUNT_MODE_PRICES FROM (
--     	SELECT 
--     		ITEM, 
--     		STORE_NAME AS STORE_NAME, 
--     		MARKETPLACE_NAME AS MARKETPLACE_NAME, 
--     		CAST(INPUT_DATE AS DATE) AS INPUT_DATE, 
--     		PRECO_A_VISTA, 
--     		COUNT(*) AS COUNT_MODE_PRICES, 
--     		ROW_NUMBER() OVER (PARTITION BY ITEM, STORE_NAME, MARKETPLACE_NAME, CAST(INPUT_DATE AS DATE) ORDER BY COUNT(*) DESC) AS ROW_NUM
--     	FROM TMP_AUX ocwa 
--     	GROUP BY ITEM, STORE_NAME, MARKETPLACE_NAME, CAST(INPUT_DATE AS DATE), PRECO_A_VISTA)
--     WHERE ROW_NUM = 1
--     GROUP BY ITEM, STORE_NAME, MARKETPLACE_NAME, INPUT_DATE
--     ) moda
--     ON 1=1
--     	AND wb.ITEM = moda.ITEM
--     	AND wb.STORE_NAME = moda.STORE_NAME
--     	AND COALESCE(wb.MARKETPLACE_NAME,'-') = COALESCE(moda.MARKETPLACE_NAME,'-')
--     	AND CAST(wb.INPUT_DATE AS DATE) = moda.INPUT_DATE
--     LEFT JOIN 
--     (
--     	SELECT 
--     		ITEM, 
--     		STORE_NAME AS STORE_NAME, 
--     		MARKETPLACE_NAME AS MARKETPLACE_NAME, 
--     		CAST(INPUT_DATE AS DATE) AS INPUT_DATE, 
--     		PRECO_A_VISTA,
--     		INPUT_DATE AS LOAD_DATE
--     	FROM TMP_AUX ocwa 
--     	WHERE TIME_SLICE(INPUT_DATE, 10, 'minute') IN (
--     					SELECT MAX_INPUT_DATE FROM (
--     						SELECT 
--     							CAST(INPUT_DATE AS DATE) AS d, 
--     							TIME_SLICE(MAX(INPUT_DATE), 10, 'minute') AS MAX_INPUT_DATE
--     						FROM TMP_AUX
--     						GROUP BY
--     							CAST(INPUT_DATE AS DATE)
--     						)
--     					)
--     ) recent
--     ON 1=1
--     	AND wb.ITEM = recent.ITEM
--     	AND wb.STORE_NAME = recent.STORE_NAME
--     	AND COALESCE(wb.MARKETPLACE_NAME,'-') = COALESCE(recent.MARKETPLACE_NAME,'-')
--     	AND CAST(wb.INPUT_DATE AS DATE) = recent.INPUT_DATE
--     WHERE 1=1
--     	AND wb.MARKETPLACE_NAME IS NULL 
--     	AND mcp.CATEGORY_ITEM = 'TV'
--     GROUP BY mcp.BRAND_ITEM, wb.STORE_NAME, wb.MARKETPLACE_NAME, wb.ITEM, CAST(wb.INPUT_DATE AS DATE);
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: Subquery in FROM must have an alias, Sqlstate: 42601, Hint: For example, FROM (SELECT ...) [AS] foo, Position: 476, Routine: base_yyparse, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/gram.y, Line: 15782, Error Code: 4833, 
CREATE OR REPLACE PROCEDURE OW_SEDA_S.PRC_CE_BF_PRECO_SISTEMA(NUMBER_OF_DAYS INT)
LANGUAGE PLvSQL AS $$
BEGIN
    
    PERFORM CREATE LOCAL TEMPORARY TABLE TMP_AUX ON COMMIT PRESERVE ROWS AS
    SELECT *
    FROM OW_SEDA_S.ODS_CE_WEBPRICE_API
    WHERE INPUT_DATE BETWEEN TIMESTAMPADD(DAY, -1 * NUMBER_OF_DAYS, CURRENT_DATE)
                          AND TIMESTAMPADD(DAY, 1, CURRENT_DATE);
    
    PERFORM TRUNCATE TABLE OW_SEDA_S.TMP_CE_BF_PRICE_AGGREGATIONS;
    PERFORM INSERT INTO OW_SEDA_S.TMP_CE_BF_PRICE_AGGREGATIONS
    SELECT
        mcs.CHANNEL,
        fcps."EXECUTION DATE" AS DATE_COLLECTED,
        fcps.ITEM,
        MIN(COALESCE(fcps."SPOT PRICE", 0.0)) AS MIN_PRICE,
        MAX(COALESCE(fcps."SPOT PRICE", 0.0)) AS MAX_PRICE,
        MAX(mode.PRICE_MODE) AS MODE_PRICE,
        MAX(mode.COUNT_MODE_PRICES) AS COUNT_MODE_PRICES, 
        COUNT(fcps."SITE ID") AS STORES_VISITED,
        COUNT(DISTINCT (fcps."SITE ID" || '|' || fcps.ITEM)) AS COLLECTED_PRICES,
        'Preço Tag' AS REPORT_TYPE
    FROM OW_SEDA_S.FT_CE_PRICE_STORE fcps 
    INNER JOIN OW_SEDA_S.MAP_CE_STORES mcs ON mcs.SITE_ID = fcps."SITE ID" 
    INNER JOIN (
        SELECT CHANNEL, ITEM, DATE_COLLECTED, PRICE_MODE, COUNT_MODE_PRICES FROM (
            SELECT
                mcs.CHANNEL,
                fcps.ITEM,
                fcps."EXECUTION DATE" AS DATE_COLLECTED,
                COALESCE(fcps."SPOT PRICE",0.0) AS PRICE_MODE,
                COUNT(*) AS COUNT_MODE_PRICES,
                ROW_NUMBER() OVER (
                    PARTITION BY mcs.CHANNEL, fcps.ITEM, fcps."EXECUTION DATE" 
                    ORDER BY COUNT(*) DESC, COALESCE(fcps."SPOT PRICE",0.0) ASC
                ) AS ROW_NUM
            FROM OW_SEDA_S.FT_CE_PRICE_STORE fcps 
            INNER JOIN OW_SEDA_S.MAP_CE_STORES mcs ON mcs.SITE_ID = fcps."SITE ID" 
            WHERE 1=1
                AND COALESCE(fcps."SPOT PRICE",0.0) > 0
                AND CATEGORY = 'CTV'
            GROUP BY 
                mcs.CHANNEL,
                fcps.ITEM,
                fcps."EXECUTION DATE",
                fcps."SPOT PRICE"
        ) t_mode
        WHERE ROW_NUM = 1
    ) mode 
        ON 1=1
            AND mode.CHANNEL = mcs.CHANNEL
            AND mode.ITEM = fcps.ITEM 
            AND mode.DATE_COLLECTED = fcps."EXECUTION DATE" 
    WHERE 1=1
        AND fcps."EXECUTION DATE" BETWEEN TIMESTAMPADD(DAY, -1 * NUMBER_OF_DAYS, CURRENT_DATE) AND CURRENT_DATE 
        AND CATEGORY = 'CTV'
        AND fcps."SPOT PRICE" NOT LIKE '%ETIQUETA%'
    GROUP BY 
        mcs.CHANNEL,
        fcps."EXECUTION DATE",
        fcps.ITEM
    UNION ALL 
    
    SELECT
        UPPER(wb.STORE_NAME) AS CHANNEL,
        CAST(wb.INPUT_DATE AS DATE) AS DATE_COLLECTED,
        wb.ITEM,
        MIN(wb.PRECO_A_VISTA) AS MIN_PRICE_COLLECTED,
        MAX(wb.PRECO_A_VISTA) AS MAX_PRICE_COLLECTED,
        MAX(moda.MODA_PRECO_A_VISTA) AS MODE_PRICE_COLLECTED,
        MAX(moda.COUNT_MODE_PRICES) AS COUNT_MODE_PRICES,
        1 AS STORES_VISITED,
        COUNT(DISTINCT (COALESCE(wb.ITEM,'') || '|' || COALESCE(wb.STORE_NAME,'') || '|' || TO_CHAR(CAST(wb.INPUT_DATE AS DATE), 'YYYY-MM-DD'))) AS COLLECTED_PRICES,
        'Preço Online' AS REPORT_TYPE
    FROM TMP_AUX wb
    INNER JOIN OW_SEDA_S.MAP_CE_PRODUCTS mcp ON mcp.ITEM = wb.ITEM 
    LEFT JOIN 
    (
        SELECT ITEM, STORE_NAME, MARKETPLACE_NAME, INPUT_DATE, AVG(PRECO_A_VISTA) AS MODA_PRECO_A_VISTA, MAX(COUNT_MODE_PRICES) AS COUNT_MODE_PRICES FROM (
            SELECT 
                ITEM, 
                STORE_NAME AS STORE_NAME, 
                MARKETPLACE_NAME AS MARKETPLACE_NAME, 
                CAST(INPUT_DATE AS DATE) AS INPUT_DATE, 
                PRECO_A_VISTA, 
                COUNT(*) AS COUNT_MODE_PRICES, 
                ROW_NUMBER() OVER (PARTITION BY ITEM, STORE_NAME, MARKETPLACE_NAME, CAST(INPUT_DATE AS DATE) ORDER BY COUNT(*) DESC) AS ROW_NUM
            FROM TMP_AUX ocwa 
            GROUP BY ITEM, STORE_NAME, MARKETPLACE_NAME, CAST(INPUT_DATE AS DATE), PRECO_A_VISTA
        ) t_moda
        WHERE ROW_NUM = 1
        GROUP BY ITEM, STORE_NAME, MARKETPLACE_NAME, INPUT_DATE
    ) moda
    ON 1=1
        AND wb.ITEM = moda.ITEM
        AND wb.STORE_NAME = moda.STORE_NAME
        AND COALESCE(wb.MARKETPLACE_NAME,'-') = COALESCE(moda.MARKETPLACE_NAME,'-')
        AND CAST(wb.INPUT_DATE AS DATE) = moda.INPUT_DATE
    LEFT JOIN 
    (
        SELECT 
            ITEM, 
            STORE_NAME AS STORE_NAME, 
            MARKETPLACE_NAME AS MARKETPLACE_NAME, 
            CAST(INPUT_DATE AS DATE) AS INPUT_DATE, 
            PRECO_A_VISTA,
            INPUT_DATE AS LOAD_DATE
        FROM TMP_AUX ocwa 
        WHERE TIME_SLICE(INPUT_DATE, 10, 'minute') IN (
            SELECT MAX_INPUT_DATE FROM (
                SELECT 
                    CAST(INPUT_DATE AS DATE) AS d, 
                    TIME_SLICE(MAX(INPUT_DATE), 10, 'minute') AS MAX_INPUT_DATE
                FROM TMP_AUX
                GROUP BY
                    CAST(INPUT_DATE AS DATE)
            ) mx
        )
    ) recent
    ON 1=1
        AND wb.ITEM = recent.ITEM
        AND wb.STORE_NAME = recent.STORE_NAME
        AND COALESCE(wb.MARKETPLACE_NAME,'-') = COALESCE(recent.MARKETPLACE_NAME,'-')
        AND CAST(wb.INPUT_DATE AS DATE) = recent.INPUT_DATE
    WHERE 1=1
        AND wb.MARKETPLACE_NAME IS NULL 
        AND mcp.CATEGORY_ITEM = 'TV'
    GROUP BY mcp.BRAND_ITEM, wb.STORE_NAME, wb.MARKETPLACE_NAME, wb.ITEM, CAST(wb.INPUT_DATE AS DATE);
END;
$$;

-- CALL OW_SEDA_S.PRC_CE_BF_PRECO_SISTEMA(7);
-- ERROR: Severity: ROLLBACK, Message: Table "TMP_CE_BF_PRICE_AGGREGATIONS" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PRC_CE_BF_PRECO_SISTEMA line 10 at static SQL, Routine: TruncateTable, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Commands/DDL.cpp, Line: 20681, Error Code: 4876, 
