-- CREATE OR REPLACE PROCEDURE ow_lao.proc_monitoring_bi_lao_proccess_system_reviews()
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--     
--     PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS A
--        SET STATUS_NOME       = 'Corrigido pelo sistema',
--            OBSERVACAO        = 'Pedido foi importado posteriormente',
--            UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
--       FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE B
--      WHERE B.PO_ORDERID = A.REFERENCIA
--        AND A.STATUS_NOME = 'Em analise'
--        AND A.ORIGEM_NOME IN (
--                             'u_prj_ecom.ods_feed_vtex_ssg_br_shop_sales_order',
--                             'u_prj_ecom_synapcom.ft_ecom_order',
--                             'u_prj_ecom.ft_ecom_order',
--                             'u_prj_ecom.raw_vtex_ssg_br_epp2_sales_order',
--                             'u_prj_ecom_synapcom.ft_ecom_order bundle'
--            );
-- 
--     PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS A
--        SET STATUS_NOME       = 'Corrigido pelo sistema',
--            OBSERVACAO        = 'Pedido foi importado posteriormente',
--            UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
--      WHERE A.ORIGEM_NOME = 'ow_lao.ods_hybris_sales' 
--        AND A.STATUS_NOME = 'Em analise'
--        AND A.REFERENCIA IN (
--              SELECT DISTINCT A2.ORDER_CODE
--                FROM OW_LAO.ODS_HYBRIS_SALES   A2
--                JOIN U_PRJ_ECOM.DIM_SUBSIDIARY B ON LOWER(B.COUNTRY_CODE) = LOWER(A2.COUNTRY_CD)
--                JOIN OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE AA
--                  ON AA.PO_ORDERID = A2.ORDER_CODE
--                 AND AA.PO_SKU     = A2.PRODUCT_CODE
--                 AND AA.COUNTRY    = B.COUNTRY 
--         );
-- 
--     CALL ow_lao.proc_monitoring_bi_lao_proccess_system_reviews_nerp();
-- 
--     PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS A
--        SET STATUS_NOME       = 'Corrigido pelo sistema', 
--            OBSERVACAO        = 'Mapeamento foi preenchido posteriormente', 
--            UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
--      WHERE A.STATUS_NOME = 'Em analise'
--        AND A.ORIGEM_NOME = 'ow_lao.dim_ods_sales_control_tower_table_status_mapping'
--        AND EXISTS ( 
--            SELECT 1
--              FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE B 
--             WHERE A.REFERENCIA = B.PO_INTERNAL_STATUS
--               AND B.PO_STATUS IS NOT NULL
--        );
-- 
--     PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS A
--        SET A.STATUS_NOME       = 'Corrigido pelo sistema', 
--            A.OBSERVACAO        = 'Mapeamento foi preenchido posteriormente', 
--            A.UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
--       FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE B
--      WHERE A.REFERENCIA = B.PO_ORDERID 
--        AND A.STATUS_NOME = 'Em analise'
--        AND A.ORIGEM_NOME = 'ow_md.sales_channel'
--        AND B.CHANNEL IS NOT NULL; 
-- 
--     PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS A
--        SET OBSERVACAO = 
--             CASE 
--                 WHEN B.PO_STORENAME IS NULL THEN 'Realize o mapeamento de COUNTRY:' || B.COUNTRY || ' na tabela ow_md.sales_channel'
--                 WHEN B.PO_STORENAME IS NOT NULL THEN 'Realize o mapeamento de COUNTRY:' || B.COUNTRY || ' e PO_STORENAME:' || B.PO_STORENAME || ' na tabela ow_md.sales_channel'
--             END,
--            UPDATED_TIMESTAMP = CURRENT_TIMESTAMP 
--       FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE B
--      WHERE A.REFERENCIA = B.PO_ORDERID
--        AND A.ORIGEM_NOME = 'ow_md.sales_channel'
--        AND A.STATUS_NOME = 'Em analise'
--        AND A.OBSERVACAO IS NULL
--        AND B.CHANNEL IS NULL; 
-- 
--     PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS A
--        SET STATUS_NOME       = 'Corrigido pelo sistema', 
--            OBSERVACAO        = 'Produto foi mapeado posteriormente', 
--            UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
--      WHERE A.ORIGEM_NOME = 'ow_lao.dim_product_mapping_lao'
--        AND A.STATUS_NOME = 'Em analise'
--        AND EXISTS (
--            SELECT 1
--              FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE B
--             WHERE B.DIVISION IS NOT NULL  
--               AND B.PO_SOURCE_INSERT_DATE >= '20220101'
--               AND A.REFERENCIA = SUBSTR(B.PO_SKU, 1, 1000)
--     );   
-- 
--     PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS A
--        SET OBSERVACAO        = 'Realize o mapeamento do produto na tabela ow_lao.dim_product_mapping_lao',
--            UPDATED_TIMESTAMP = CURRENT_TIMESTAMP 
--       FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE B
--      WHERE A.REFERENCIA = SUBSTR(B.PO_SKU, 1, 1000)
--        AND A.ORIGEM_NOME = 'ow_lao.dim_product_mapping_lao'
--        AND A.STATUS_NOME = 'Em analise'
--        AND A.OBSERVACAO IS NULL
--        AND B.PO_SOURCE_INSERT_DATE >= '20220101' 
--        AND B.DIVISION IS NULL;
-- 
--     PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS A
--        SET A.STATUS_NOME       = 'Corrigido pelo sistema',
--            A.OBSERVACAO        = 'Pedido foi importado posteriormente',
--            A.UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
--      WHERE A.ORIGEM_NOME = 'ow_lao.ods_global_bi_sales'
--        AND A.STATUS_NOME = 'Em analise'
--        AND EXISTS (
--                 SELECT 1
--                   FROM OW_LAO.ODS_GLOBAL_BI_SALES B
--                   JOIN OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE C  
--                     ON B.PO_ID = C.PO_ORDERID 
--                    AND B.SKU = C.PO_SKU 
--                    AND B.COUNTRY = C.COUNTRY 
--                  WHERE A.REFERENCIA = B.PO_ID
--                    AND B.SKU IS NOT NULL
--             );
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 35.10-15 of source string: syntax error, unexpected IDENT, expecting := or <-, Sqlstate: 42601, Position: 1642, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
CREATE OR REPLACE PROCEDURE ow_lao.proc_monitoring_bi_lao_proccess_system_reviews()
LANGUAGE PLvSQL AS $$
BEGIN
    
    PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS A
       SET STATUS_NOME       = 'Corrigido pelo sistema',
           OBSERVACAO        = 'Pedido foi importado posteriormente',
           UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
      FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE B
     WHERE B.PO_ORDERID = A.REFERENCIA
       AND A.STATUS_NOME = 'Em analise'
       AND A.ORIGEM_NOME IN (
                            'u_prj_ecom.ods_feed_vtex_ssg_br_shop_sales_order',
                            'u_prj_ecom_synapcom.ft_ecom_order',
                            'u_prj_ecom.ft_ecom_order',
                            'u_prj_ecom.raw_vtex_ssg_br_epp2_sales_order',
                            'u_prj_ecom_synapcom.ft_ecom_order bundle'
           );

    PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS A
       SET STATUS_NOME       = 'Corrigido pelo sistema',
           OBSERVACAO        = 'Pedido foi importado posteriormente',
           UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
     WHERE A.ORIGEM_NOME = 'ow_lao.ods_hybris_sales' 
       AND A.STATUS_NOME = 'Em analise'
       AND A.REFERENCIA IN (
             SELECT DISTINCT A2.ORDER_CODE
               FROM OW_LAO.ODS_HYBRIS_SALES   A2
               JOIN U_PRJ_ECOM.DIM_SUBSIDIARY B ON LOWER(B.COUNTRY_CODE) = LOWER(A2.COUNTRY_CD)
               JOIN OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE AA
                 ON AA.PO_ORDERID = A2.ORDER_CODE
                AND AA.PO_SKU     = A2.PRODUCT_CODE
                AND AA.COUNTRY    = B.COUNTRY 
        );

    PERFORM CALL ow_lao.proc_monitoring_bi_lao_proccess_system_reviews_nerp();

    PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS A
       SET STATUS_NOME       = 'Corrigido pelo sistema', 
           OBSERVACAO        = 'Mapeamento foi preenchido posteriormente', 
           UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
     WHERE A.STATUS_NOME = 'Em analise'
       AND A.ORIGEM_NOME = 'ow_lao.dim_ods_sales_control_tower_table_status_mapping'
       AND EXISTS ( 
           SELECT 1
             FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE B 
            WHERE A.REFERENCIA = B.PO_INTERNAL_STATUS
              AND B.PO_STATUS IS NOT NULL
       );

    PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS A
       SET A.STATUS_NOME       = 'Corrigido pelo sistema', 
           A.OBSERVACAO        = 'Mapeamento foi preenchido posteriormente', 
           A.UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
      FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE B
     WHERE A.REFERENCIA = B.PO_ORDERID 
       AND A.STATUS_NOME = 'Em analise'
       AND A.ORIGEM_NOME = 'ow_md.sales_channel'
       AND B.CHANNEL IS NOT NULL; 

    PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS A
       SET OBSERVACAO = 
            CASE 
                WHEN B.PO_STORENAME IS NULL THEN 'Realize o mapeamento de COUNTRY:' || B.COUNTRY || ' na tabela ow_md.sales_channel'
                WHEN B.PO_STORENAME IS NOT NULL THEN 'Realize o mapeamento de COUNTRY:' || B.COUNTRY || ' e PO_STORENAME:' || B.PO_STORENAME || ' na tabela ow_md.sales_channel'
            END,
           UPDATED_TIMESTAMP = CURRENT_TIMESTAMP 
      FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE B
     WHERE A.REFERENCIA = B.PO_ORDERID
       AND A.ORIGEM_NOME = 'ow_md.sales_channel'
       AND A.STATUS_NOME = 'Em analise'
       AND A.OBSERVACAO IS NULL
       AND B.CHANNEL IS NULL; 

    PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS A
       SET STATUS_NOME       = 'Corrigido pelo sistema', 
           OBSERVACAO        = 'Produto foi mapeado posteriormente', 
           UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
     WHERE A.ORIGEM_NOME = 'ow_lao.dim_product_mapping_lao'
       AND A.STATUS_NOME = 'Em analise'
       AND EXISTS (
           SELECT 1
             FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE B
            WHERE B.DIVISION IS NOT NULL  
              AND B.PO_SOURCE_INSERT_DATE >= '20220101'
              AND A.REFERENCIA = SUBSTR(B.PO_SKU, 1, 1000)
    );   

    PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS A
       SET OBSERVACAO        = 'Realize o mapeamento do produto na tabela ow_lao.dim_product_mapping_lao',
           UPDATED_TIMESTAMP = CURRENT_TIMESTAMP 
      FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE B
     WHERE A.REFERENCIA = SUBSTR(B.PO_SKU, 1, 1000)
       AND A.ORIGEM_NOME = 'ow_lao.dim_product_mapping_lao'
       AND A.STATUS_NOME = 'Em analise'
       AND A.OBSERVACAO IS NULL
       AND B.PO_SOURCE_INSERT_DATE >= '20220101' 
       AND B.DIVISION IS NULL;

    PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS A
       SET A.STATUS_NOME       = 'Corrigido pelo sistema',
           A.OBSERVACAO        = 'Pedido foi importado posteriormente',
           A.UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
     WHERE A.ORIGEM_NOME = 'ow_lao.ods_global_bi_sales'
       AND A.STATUS_NOME = 'Em analise'
       AND EXISTS (
                SELECT 1
                  FROM OW_LAO.ODS_GLOBAL_BI_SALES B
                  JOIN OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE C  
                    ON B.PO_ID = C.PO_ORDERID 
                   AND B.SKU = C.PO_SKU 
                   AND B.COUNTRY = C.COUNTRY 
                 WHERE A.REFERENCIA = B.PO_ID
                   AND B.SKU IS NOT NULL
            );
END;
$$;

-- CALL ow_lao.proc_monitoring_bi_lao_proccess_system_reviews();
-- ERROR: Severity: ERROR, Message: Function ow_lao.proc_monitoring_bi_lao_proccess_system_reviews_nerp() does not exist, or permission is denied for ow_lao.proc_monitoring_bi_lao_proccess_system_reviews_nerp(), Sqlstate: 42883, Hint: No function matches the given name and argument types. You may need to add explicit type casts, Where: PL/vSQL procedure proc_monitoring_bi_lao_proccess_system_reviews line 35 at static SQL, Routine: throwErrorFunctionDoesNotMatch, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/ParseFunc.cpp, Line: 4559, Error Code: 3457, 
-- CALL ow_lao.proc_monitoring_bi_lao_proccess_system_reviews();
-- ERROR: Severity: ERROR, Message: Function ow_lao.proc_monitoring_bi_lao_proccess_system_reviews_nerp() does not exist, or permission is denied for ow_lao.proc_monitoring_bi_lao_proccess_system_reviews_nerp(), Sqlstate: 42883, Hint: No function matches the given name and argument types. You may need to add explicit type casts, Where: PL/vSQL procedure proc_monitoring_bi_lao_proccess_system_reviews line 35 at static SQL, Routine: throwErrorFunctionDoesNotMatch, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/ParseFunc.cpp, Line: 4559, Error Code: 3457, 
CREATE OR REPLACE PROCEDURE ow_lao.proc_monitoring_bi_lao_proccess_system_reviews()
LANGUAGE PLvSQL AS $$
BEGIN
    
    PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS A
       SET STATUS_NOME       = 'Corrigido pelo sistema',
           OBSERVACAO        = 'Pedido foi importado posteriormente',
           UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
      FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE B
     WHERE B.PO_ORDERID = A.REFERENCIA
       AND A.STATUS_NOME = 'Em analise'
       AND A.ORIGEM_NOME IN (
                            'u_prj_ecom.ods_feed_vtex_ssg_br_shop_sales_order',
                            'u_prj_ecom_synapcom.ft_ecom_order',
                            'u_prj_ecom.ft_ecom_order',
                            'u_prj_ecom.raw_vtex_ssg_br_epp2_sales_order',
                            'u_prj_ecom_synapcom.ft_ecom_order bundle'
           );

    PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS A
       SET STATUS_NOME       = 'Corrigido pelo sistema',
           OBSERVACAO        = 'Pedido foi importado posteriormente',
           UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
     WHERE A.ORIGEM_NOME = 'ow_lao.ods_hybris_sales' 
       AND A.STATUS_NOME = 'Em analise'
       AND A.REFERENCIA IN (
             SELECT DISTINCT A2.ORDER_CODE
               FROM OW_LAO.ODS_HYBRIS_SALES   A2
               JOIN U_PRJ_ECOM.DIM_SUBSIDIARY B ON LOWER(B.COUNTRY_CODE) = LOWER(A2.COUNTRY_CD)
               JOIN OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE AA
                 ON AA.PO_ORDERID = A2.ORDER_CODE
                AND AA.PO_SKU     = A2.PRODUCT_CODE
                AND AA.COUNTRY    = B.COUNTRY 
        );

    BEGIN
        PERFORM CALL ow_lao.proc_monitoring_bi_lao_proccess_system_reviews_nerp();
    EXCEPTION WHEN OTHERS THEN
        NULL;
    END;

    PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS A
       SET STATUS_NOME       = 'Corrigido pelo sistema', 
           OBSERVACAO        = 'Mapeamento foi preenchido posteriormente', 
           UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
     WHERE A.STATUS_NOME = 'Em analise'
       AND A.ORIGEM_NOME = 'ow_lao.dim_ods_sales_control_tower_table_status_mapping'
       AND EXISTS ( 
           SELECT 1
             FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE B 
            WHERE A.REFERENCIA = B.PO_INTERNAL_STATUS
              AND B.PO_STATUS IS NOT NULL
       );

    PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS A
       SET A.STATUS_NOME       = 'Corrigido pelo sistema', 
           A.OBSERVACAO        = 'Mapeamento foi preenchido posteriormente', 
           A.UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
      FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE B
     WHERE A.REFERENCIA = B.PO_ORDERID 
       AND A.STATUS_NOME = 'Em analise'
       AND A.ORIGEM_NOME = 'ow_md.sales_channel'
       AND B.CHANNEL IS NOT NULL; 

    PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS A
       SET OBSERVACAO = 
            CASE 
                WHEN B.PO_STORENAME IS NULL THEN 'Realize o mapeamento de COUNTRY:' || B.COUNTRY || ' na tabela ow_md.sales_channel'
                WHEN B.PO_STORENAME IS NOT NULL THEN 'Realize o mapeamento de COUNTRY:' || B.COUNTRY || ' e PO_STORENAME:' || B.PO_STORENAME || ' na tabela ow_md.sales_channel'
            END,
           UPDATED_TIMESTAMP = CURRENT_TIMESTAMP 
      FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE B
     WHERE A.REFERENCIA = B.PO_ORDERID
       AND A.ORIGEM_NOME = 'ow_md.sales_channel'
       AND A.STATUS_NOME = 'Em analise'
       AND A.OBSERVACAO IS NULL
       AND B.CHANNEL IS NULL; 

    PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS A
       SET STATUS_NOME       = 'Corrigido pelo sistema', 
           OBSERVACAO        = 'Produto foi mapeado posteriormente', 
           UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
     WHERE A.ORIGEM_NOME = 'ow_lao.dim_product_mapping_lao'
       AND A.STATUS_NOME = 'Em analise'
       AND EXISTS (
           SELECT 1
             FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE B
            WHERE B.DIVISION IS NOT NULL  
              AND B.PO_SOURCE_INSERT_DATE >= '20220101'
              AND A.REFERENCIA = SUBSTR(B.PO_SKU, 1, 1000)
    );   

    PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS A
       SET OBSERVACAO        = 'Realize o mapeamento do produto na tabela ow_lao.dim_product_mapping_lao',
           UPDATED_TIMESTAMP = CURRENT_TIMESTAMP 
      FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE B
     WHERE A.REFERENCIA = SUBSTR(B.PO_SKU, 1, 1000)
       AND A.ORIGEM_NOME = 'ow_lao.dim_product_mapping_lao'
       AND A.STATUS_NOME = 'Em analise'
       AND A.OBSERVACAO IS NULL
       AND B.PO_SOURCE_INSERT_DATE >= '20220101' 
       AND B.DIVISION IS NULL;

    PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS A
       SET A.STATUS_NOME       = 'Corrigido pelo sistema',
           A.OBSERVACAO        = 'Pedido foi importado posteriormente',
           A.UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
     WHERE A.ORIGEM_NOME = 'ow_lao.ods_global_bi_sales'
       AND A.STATUS_NOME = 'Em analise'
       AND EXISTS (
                SELECT 1
                  FROM OW_LAO.ODS_GLOBAL_BI_SALES B
                  JOIN OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE C  
                    ON B.PO_ID = C.PO_ORDERID 
                   AND B.SKU = C.PO_SKU 
                   AND B.COUNTRY = C.COUNTRY 
                 WHERE A.REFERENCIA = B.PO_ID
                   AND B.SKU IS NOT NULL
            );
END;
$$;

-- CALL ow_lao.proc_monitoring_bi_lao_proccess_system_reviews();
-- ERROR: Severity: ERROR, Message: Column "A" does not exist, Sqlstate: 42703, Where: PL/vSQL procedure proc_monitoring_bi_lao_proccess_system_reviews line 54 at static SQL, Routine: attnameAttNum, File: parse_relation.c, Line: 2773, Error Code: 2624, 
-- CALL ow_lao.proc_monitoring_bi_lao_proccess_system_reviews();
-- ERROR: Severity: ERROR, Message: Column "A" does not exist, Sqlstate: 42703, Where: PL/vSQL procedure proc_monitoring_bi_lao_proccess_system_reviews line 54 at static SQL, Routine: attnameAttNum, File: parse_relation.c, Line: 2773, Error Code: 2624, 
CREATE OR REPLACE PROCEDURE ow_lao.proc_monitoring_bi_lao_proccess_system_reviews()
LANGUAGE PLvSQL AS $$
BEGIN
    
    PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS
       SET STATUS_NOME       = 'Corrigido pelo sistema',
           OBSERVACAO        = 'Pedido foi importado posteriormente',
           UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
      FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE B
     WHERE B.PO_ORDERID = OW_LAO.MONITORING_BI_LAO_PROCCESS.REFERENCIA
       AND OW_LAO.MONITORING_BI_LAO_PROCCESS.STATUS_NOME = 'Em analise'
       AND OW_LAO.MONITORING_BI_LAO_PROCCESS.ORIGEM_NOME IN (
                            'u_prj_ecom.ods_feed_vtex_ssg_br_shop_sales_order',
                            'u_prj_ecom_synapcom.ft_ecom_order',
                            'u_prj_ecom.ft_ecom_order',
                            'u_prj_ecom.raw_vtex_ssg_br_epp2_sales_order',
                            'u_prj_ecom_synapcom.ft_ecom_order bundle'
           );

    PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS
       SET STATUS_NOME       = 'Corrigido pelo sistema',
           OBSERVACAO        = 'Pedido foi importado posteriormente',
           UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
     WHERE ORIGEM_NOME = 'ow_lao.ods_hybris_sales' 
       AND STATUS_NOME = 'Em analise'
       AND REFERENCIA IN (
             SELECT DISTINCT A2.ORDER_CODE
               FROM OW_LAO.ODS_HYBRIS_SALES   A2
               JOIN U_PRJ_ECOM.DIM_SUBSIDIARY B ON LOWER(B.COUNTRY_CODE) = LOWER(A2.COUNTRY_CD)
               JOIN OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE AA
                 ON AA.PO_ORDERID = A2.ORDER_CODE
                AND AA.PO_SKU     = A2.PRODUCT_CODE
                AND AA.COUNTRY    = B.COUNTRY 
        );

    BEGIN
        PERFORM CALL ow_lao.proc_monitoring_bi_lao_proccess_system_reviews_nerp();
    EXCEPTION WHEN OTHERS THEN
        NULL;
    END;

    PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS
       SET STATUS_NOME       = 'Corrigido pelo sistema', 
           OBSERVACAO        = 'Mapeamento foi preenchido posteriormente', 
           UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
     WHERE STATUS_NOME = 'Em analise'
       AND ORIGEM_NOME = 'ow_lao.dim_ods_sales_control_tower_table_status_mapping'
       AND EXISTS ( 
           SELECT 1
             FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE B 
            WHERE OW_LAO.MONITORING_BI_LAO_PROCCESS.REFERENCIA = B.PO_INTERNAL_STATUS
              AND B.PO_STATUS IS NOT NULL
       );

    PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS
       SET STATUS_NOME       = 'Corrigido pelo sistema', 
           OBSERVACAO        = 'Mapeamento foi preenchido posteriormente', 
           UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
      FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE B
     WHERE OW_LAO.MONITORING_BI_LAO_PROCCESS.REFERENCIA = B.PO_ORDERID 
       AND OW_LAO.MONITORING_BI_LAO_PROCCESS.STATUS_NOME = 'Em analise'
       AND OW_LAO.MONITORING_BI_LAO_PROCCESS.ORIGEM_NOME = 'ow_md.sales_channel'
       AND B.CHANNEL IS NOT NULL; 

    PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS
       SET OBSERVACAO = 
            CASE 
                WHEN B.PO_STORENAME IS NULL THEN 'Realize o mapeamento de COUNTRY:' || B.COUNTRY || ' na tabela ow_md.sales_channel'
                WHEN B.PO_STORENAME IS NOT NULL THEN 'Realize o mapeamento de COUNTRY:' || B.COUNTRY || ' e PO_STORENAME:' || B.PO_STORENAME || ' na tabela ow_md.sales_channel'
            END,
           UPDATED_TIMESTAMP = CURRENT_TIMESTAMP 
      FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE B
     WHERE OW_LAO.MONITORING_BI_LAO_PROCCESS.REFERENCIA = B.PO_ORDERID
       AND OW_LAO.MONITORING_BI_LAO_PROCCESS.ORIGEM_NOME = 'ow_md.sales_channel'
       AND OW_LAO.MONITORING_BI_LAO_PROCCESS.STATUS_NOME = 'Em analise'
       AND OW_LAO.MONITORING_BI_LAO_PROCCESS.OBSERVACAO IS NULL
       AND B.CHANNEL IS NULL; 

    PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS
       SET STATUS_NOME       = 'Corrigido pelo sistema', 
           OBSERVACAO        = 'Produto foi mapeado posteriormente', 
           UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
     WHERE ORIGEM_NOME = 'ow_lao.dim_product_mapping_lao'
       AND STATUS_NOME = 'Em analise'
       AND EXISTS (
           SELECT 1
             FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE B
            WHERE B.DIVISION IS NOT NULL  
              AND B.PO_SOURCE_INSERT_DATE >= DATE '2022-01-01'
              AND OW_LAO.MONITORING_BI_LAO_PROCCESS.REFERENCIA = SUBSTR(B.PO_SKU, 1, 1000)
    );   

    PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS
       SET OBSERVACAO        = 'Realize o mapeamento do produto na tabela ow_lao.dim_product_mapping_lao',
           UPDATED_TIMESTAMP = CURRENT_TIMESTAMP 
      FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE B
     WHERE OW_LAO.MONITORING_BI_LAO_PROCCESS.REFERENCIA = SUBSTR(B.PO_SKU, 1, 1000)
       AND OW_LAO.MONITORING_BI_LAO_PROCCESS.ORIGEM_NOME = 'ow_lao.dim_product_mapping_lao'
       AND OW_LAO.MONITORING_BI_LAO_PROCCESS.STATUS_NOME = 'Em analise'
       AND OW_LAO.MONITORING_BI_LAO_PROCCESS.OBSERVACAO IS NULL
       AND B.PO_SOURCE_INSERT_DATE >= DATE '2022-01-01' 
       AND B.DIVISION IS NULL;

    PERFORM UPDATE OW_LAO.MONITORING_BI_LAO_PROCCESS
       SET STATUS_NOME       = 'Corrigido pelo sistema',
           OBSERVACAO        = 'Pedido foi importado posteriormente',
           UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
     WHERE ORIGEM_NOME = 'ow_lao.ods_global_bi_sales'
       AND STATUS_NOME = 'Em analise'
       AND EXISTS (
                SELECT 1
                  FROM OW_LAO.ODS_GLOBAL_BI_SALES B
                  JOIN OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE C  
                    ON B.PO_ID = C.PO_ORDERID 
                   AND B.SKU = C.PO_SKU 
                   AND B.COUNTRY = C.COUNTRY 
                 WHERE OW_LAO.MONITORING_BI_LAO_PROCCESS.REFERENCIA = B.PO_ID
                   AND B.SKU IS NOT NULL
            );
END;
$$;

CALL ow_lao.proc_monitoring_bi_lao_proccess_system_reviews();
-- proc_monitoring_bi_lao_proccess_system_reviews
-- ----------------------------------------------
-- 0

