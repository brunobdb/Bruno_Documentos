CREATE OR REPLACE PROCEDURE OW_LAO.MONITORING_EXECUTIONS_RESULTS_UPDATE_DEFAULT(
       _execution_result_status   INT
     , _filter_execution_status   INT
     , _monitoring_parameter      INT
     , _execution_result_value    VARCHAR(4000)
)
LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM UPDATE OW_LAO.MONITORING_EXECUTIONS_RESULTS
       SET MONITORING_EXECUTION_RESULT_STATUS = _execution_result_status
         , VALUE                              = _execution_result_value
         , IS_OK                              = CASE _execution_result_status
                                                     WHEN 2 THEN TRUE
                                                     ELSE FALSE
                                                 END
         , ENDED_AT                           = CURRENT_TIMESTAMP
     WHERE STARTED_AT                         <= CURRENT_TIMESTAMP
       AND MONITORING_EXECUTION_RESULT_STATUS  = _filter_execution_status 
       AND MONITORING_PARAMETER                = _monitoring_parameter;
END;
$$;

CALL OW_LAO.MONITORING_EXECUTIONS_RESULTS_UPDATE_DEFAULT(2,1,100,'OK');
-- MONITORING_EXECUTIONS_RESULTS_UPDATE_DEFAULT
-- --------------------------------------------
-- 0

