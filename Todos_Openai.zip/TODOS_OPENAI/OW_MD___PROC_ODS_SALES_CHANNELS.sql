CREATE OR REPLACE PROCEDURE ow_md.proc_ods_sales_channels()
 LANGUAGE PLvSQL AS $$
BEGIN
  
  PERFORM DROP TABLE IF EXISTS temp_input_sales_channels_dedup;
  
  PERFORM CREATE LOCAL TEMPORARY TABLE temp_input_sales_channels_dedup ON COMMIT PRESERVE ROWS AS (
      SELECT a.plataform_type
           , COALESCE(a.plataform_account, '')  AS plataform_account
           , COALESCE(a.identifier       , '')  AS identifier       
           , COALESCE(a.has_store_id     , '')  AS has_store_id     
           , COALESCE(a.sales_channel    , '')  AS sales_channel    
           , COALESCE(a.affiliate_id     , '')  AS affiliate_id     
           , a.channel
           , a.sub_channel
           , a.partner_level
           , a.global_channel
           , a.global_channel_ebi
           , a.biz_type
           , a.biz_type_ebi
           , a.audience_type
           , a.audience_type_ebi
           , a.sales_org
           , a.business_area
           , a.company_code
           , a.country
           , a.country_code
           , a.currency
           , a.file_name
           , a.last_modification_file
           , a.load_timestamp
           , ROW_NUMBER() OVER (
                PARTITION BY a.plataform_type
                           , a.plataform_account
                           , a.identifier    
                           , a.has_store_id   
                           , a.sales_channel    
                           , a.affiliate_id     
                ORDER BY a.load_timestamp DESC
             ) AS dedup
        FROM ow_md.input_sales_channels a
       WHERE a.load_timestamp > (
               SELECT COALESCE(MAX(load_timestamp), TIMESTAMP '1900-01-01')
                 FROM ow_md.ods_sales_channels
             )
  );
  
  PERFORM DELETE FROM temp_input_sales_channels_dedup WHERE dedup <> 1;
  
  PERFORM MERGE INTO ow_md.ods_sales_channels a
        USING temp_input_sales_channels_dedup b
           ON a.plataform_type    = b.plataform_type
          AND a.plataform_account = b.plataform_account
          AND a.identifier        = b.identifier       
          AND a.has_store_id      = b.has_store_id     
          AND a.sales_channel     = b.sales_channel    
          AND a.affiliate_id      = b.affiliate_id     
  WHEN MATCHED THEN UPDATE SET
             channel                = b.channel
           , sub_channel            = b.sub_channel
           , partner_level          = b.partner_level
           , global_channel         = b.global_channel
           , global_channel_ebi     = b.global_channel_ebi
           , biz_type               = b.biz_type
           , biz_type_ebi           = b.biz_type_ebi
           , audience_type          = b.audience_type
           , audience_type_ebi      = b.audience_type_ebi
           , sales_org              = b.sales_org
           , business_area          = b.business_area
           , company_code           = b.company_code
           , country                = b.country
           , country_code           = b.country_code
           , currency               = b.currency
           , file_name              = b.file_name
           , last_modification_file = b.last_modification_file
           , load_timestamp         = b.load_timestamp
           , updated_date           = CURRENT_TIMESTAMP
  WHEN NOT MATCHED THEN INSERT (
             plataform_type 
           , plataform_account 
           , identifier 
           , has_store_id 
           , sales_channel 
           , affiliate_id 
           , channel 
           , sub_channel 
           , partner_level 
           , global_channel 
           , global_channel_ebi 
           , biz_type 
           , biz_type_ebi 
           , audience_type 
           , audience_type_ebi 
           , sales_org 
           , business_area 
           , company_code 
           , country 
           , country_code 
           , currency 
           , file_name 
           , last_modification_file 
           , load_timestamp 
        )  
        VALUES (      
             b.plataform_type
           , b.plataform_account
           , b.identifier       
           , b.has_store_id     
           , b.sales_channel    
           , b.affiliate_id     
           , b.channel
           , b.sub_channel
           , b.partner_level
           , b.global_channel
           , b.global_channel_ebi
           , b.biz_type
           , b.biz_type_ebi
           , b.audience_type
           , b.audience_type_ebi
           , b.sales_org
           , b.business_area
           , b.company_code
           , b.country
           , b.country_code
           , b.currency
           , b.file_name
           , b.last_modification_file
           , b.load_timestamp
        );  
                                      
END
$$;

-- CALL ow_md.proc_ods_sales_channels();
-- ERROR: Severity: ERROR, Message: Cannot set a NOT NULL column (ID) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure proc_ods_sales_channels line 49 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3216, Error Code: 2502, 
-- CALL ow_md.proc_ods_sales_channels();
-- ERROR: Severity: ERROR, Message: Cannot set a NOT NULL column (ID) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure proc_ods_sales_channels line 49 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3216, Error Code: 2502, 
SELECT MD5('abc');
-- MD5
-- ---
-- 900150983cd24fb0d6963f7d28e17f72

CREATE OR REPLACE PROCEDURE ow_md.proc_ods_sales_channels()
 LANGUAGE PLvSQL AS $$
BEGIN
  
  PERFORM DROP TABLE IF EXISTS temp_input_sales_channels_dedup;
  
  PERFORM CREATE LOCAL TEMPORARY TABLE temp_input_sales_channels_dedup ON COMMIT PRESERVE ROWS AS (
      SELECT 
             MD5(
               COALESCE(a.plataform_type,'') || '|' ||
               COALESCE(a.plataform_account,'') || '|' ||
               COALESCE(a.identifier,'') || '|' ||
               COALESCE(a.has_store_id,'') || '|' ||
               COALESCE(a.sales_channel,'') || '|' ||
               COALESCE(a.affiliate_id,'')
             ) AS id
           , a.plataform_type
           , COALESCE(a.plataform_account, '')  AS plataform_account
           , COALESCE(a.identifier       , '')  AS identifier       
           , COALESCE(a.has_store_id     , '')  AS has_store_id     
           , COALESCE(a.sales_channel    , '')  AS sales_channel    
           , COALESCE(a.affiliate_id     , '')  AS affiliate_id     
           , a.channel
           , a.sub_channel
           , a.partner_level
           , a.global_channel
           , a.global_channel_ebi
           , a.biz_type
           , a.biz_type_ebi
           , a.audience_type
           , a.audience_type_ebi
           , a.sales_org
           , a.business_area
           , a.company_code
           , a.country
           , a.country_code
           , a.currency
           , a.file_name
           , a.last_modification_file
           , a.load_timestamp
           , ROW_NUMBER() OVER (
                PARTITION BY a.plataform_type
                           , a.plataform_account
                           , a.identifier    
                           , a.has_store_id   
                           , a.sales_channel    
                           , a.affiliate_id     
                ORDER BY a.load_timestamp DESC
             ) AS dedup
        FROM ow_md.input_sales_channels a
       WHERE a.load_timestamp > (
               SELECT COALESCE(MAX(load_timestamp), TIMESTAMP '1900-01-01')
                 FROM ow_md.ods_sales_channels
             )
  );
  
  PERFORM DELETE FROM temp_input_sales_channels_dedup WHERE dedup <> 1;
  
  PERFORM MERGE INTO ow_md.ods_sales_channels a
        USING temp_input_sales_channels_dedup b
           ON a.plataform_type    = b.plataform_type
          AND a.plataform_account = b.plataform_account
          AND a.identifier        = b.identifier       
          AND a.has_store_id      = b.has_store_id     
          AND a.sales_channel     = b.sales_channel    
          AND a.affiliate_id      = b.affiliate_id     
  WHEN MATCHED THEN UPDATE SET
             channel                = b.channel
           , sub_channel            = b.sub_channel
           , partner_level          = b.partner_level
           , global_channel         = b.global_channel
           , global_channel_ebi     = b.global_channel_ebi
           , biz_type               = b.biz_type
           , biz_type_ebi           = b.biz_type_ebi
           , audience_type          = b.audience_type
           , audience_type_ebi      = b.audience_type_ebi
           , sales_org              = b.sales_org
           , business_area          = b.business_area
           , company_code           = b.company_code
           , country                = b.country
           , country_code           = b.country_code
           , currency               = b.currency
           , file_name              = b.file_name
           , last_modification_file = b.last_modification_file
           , load_timestamp         = b.load_timestamp
           , updated_date           = CURRENT_TIMESTAMP
  WHEN NOT MATCHED THEN INSERT (
             id
           , plataform_type 
           , plataform_account 
           , identifier 
           , has_store_id 
           , sales_channel 
           , affiliate_id 
           , channel 
           , sub_channel 
           , partner_level 
           , global_channel 
           , global_channel_ebi 
           , biz_type 
           , biz_type_ebi 
           , audience_type 
           , audience_type_ebi 
           , sales_org 
           , business_area 
           , company_code 
           , country 
           , country_code 
           , currency 
           , file_name 
           , last_modification_file 
           , load_timestamp 
           , updated_date
        )  
        VALUES (
             b.id
           , b.plataform_type
           , b.plataform_account
           , b.identifier       
           , b.has_store_id     
           , b.sales_channel    
           , b.affiliate_id     
           , b.channel
           , b.sub_channel
           , b.partner_level
           , b.global_channel
           , b.global_channel_ebi
           , b.biz_type
           , b.biz_type_ebi
           , b.audience_type
           , b.audience_type_ebi
           , b.sales_org
           , b.business_area
           , b.company_code
           , b.country
           , b.country_code
           , b.currency
           , b.file_name
           , b.last_modification_file
           , b.load_timestamp
           , CURRENT_TIMESTAMP
        );  
                                      
END
$$;

-- CALL ow_md.proc_ods_sales_channels();
-- ERROR: Severity: ERROR, Message: Column "id" is of type int but expression is of type varchar, Sqlstate: 42804, Hint: You will need to rewrite or cast the expression, Where: PL/vSQL procedure proc_ods_sales_channels line 58 at static SQL, Routine: updateTargetListEntry, File: parse_target.c, Line: 853, Error Code: 2631, 
-- CALL ow_md.proc_ods_sales_channels();
-- ERROR: Severity: ERROR, Message: Column "id" is of type int but expression is of type varchar, Sqlstate: 42804, Hint: You will need to rewrite or cast the expression, Where: PL/vSQL procedure proc_ods_sales_channels line 58 at static SQL, Routine: updateTargetListEntry, File: parse_target.c, Line: 853, Error Code: 2631, 
CREATE OR REPLACE PROCEDURE ow_md.proc_ods_sales_channels()
 LANGUAGE PLvSQL AS $$
DECLARE
  v_max_id INT;
BEGIN
  
  SELECT COALESCE(MAX(id), 0) INTO v_max_id FROM ow_md.ods_sales_channels;
  
  PERFORM DROP TABLE IF EXISTS temp_input_sales_channels_dedup;
  
  PERFORM CREATE LOCAL TEMPORARY TABLE temp_input_sales_channels_dedup ON COMMIT PRESERVE ROWS AS (
      SELECT 
             (v_max_id + ROW_NUMBER() OVER (ORDER BY a.load_timestamp, a.plataform_type, a.plataform_account, a.identifier, a.has_store_id, a.sales_channel, a.affiliate_id))::INT AS id
           , a.plataform_type
           , COALESCE(a.plataform_account, '')  AS plataform_account
           , COALESCE(a.identifier       , '')  AS identifier       
           , COALESCE(a.has_store_id     , '')  AS has_store_id     
           , COALESCE(a.sales_channel    , '')  AS sales_channel    
           , COALESCE(a.affiliate_id     , '')  AS affiliate_id     
           , a.channel
           , a.sub_channel
           , a.partner_level
           , a.global_channel
           , a.global_channel_ebi
           , a.biz_type
           , a.biz_type_ebi
           , a.audience_type
           , a.audience_type_ebi
           , a.sales_org
           , a.business_area
           , a.company_code
           , a.country
           , a.country_code
           , a.currency
           , a.file_name
           , a.last_modification_file
           , a.load_timestamp
           , ROW_NUMBER() OVER (
                PARTITION BY a.plataform_type
                           , a.plataform_account
                           , a.identifier    
                           , a.has_store_id   
                           , a.sales_channel    
                           , a.affiliate_id     
                ORDER BY a.load_timestamp DESC
             ) AS dedup
        FROM ow_md.input_sales_channels a
       WHERE a.load_timestamp > (
               SELECT COALESCE(MAX(load_timestamp), TIMESTAMP '1900-01-01')
                 FROM ow_md.ods_sales_channels
             )
  );
  
  PERFORM DELETE FROM temp_input_sales_channels_dedup WHERE dedup <> 1;
  
  PERFORM MERGE INTO ow_md.ods_sales_channels a
        USING temp_input_sales_channels_dedup b
           ON a.plataform_type    = b.plataform_type
          AND a.plataform_account = b.plataform_account
          AND a.identifier        = b.identifier       
          AND a.has_store_id      = b.has_store_id     
          AND a.sales_channel     = b.sales_channel    
          AND a.affiliate_id      = b.affiliate_id     
  WHEN MATCHED THEN UPDATE SET
             channel                = b.channel
           , sub_channel            = b.sub_channel
           , partner_level          = b.partner_level
           , global_channel         = b.global_channel
           , global_channel_ebi     = b.global_channel_ebi
           , biz_type               = b.biz_type
           , biz_type_ebi           = b.biz_type_ebi
           , audience_type          = b.audience_type
           , audience_type_ebi      = b.audience_type_ebi
           , sales_org              = b.sales_org
           , business_area          = b.business_area
           , company_code           = b.company_code
           , country                = b.country
           , country_code           = b.country_code
           , currency               = b.currency
           , file_name              = b.file_name
           , last_modification_file = b.last_modification_file
           , load_timestamp         = b.load_timestamp
           , updated_date           = CURRENT_TIMESTAMP
  WHEN NOT MATCHED THEN INSERT (
             id
           , plataform_type 
           , plataform_account 
           , identifier 
           , has_store_id 
           , sales_channel 
           , affiliate_id 
           , channel 
           , sub_channel 
           , partner_level 
           , global_channel 
           , global_channel_ebi 
           , biz_type 
           , biz_type_ebi 
           , audience_type 
           , audience_type_ebi 
           , sales_org 
           , business_area 
           , company_code 
           , country 
           , country_code 
           , currency 
           , file_name 
           , last_modification_file 
           , load_timestamp 
           , updated_date
        )  
        VALUES (
             b.id
           , b.plataform_type
           , b.plataform_account
           , b.identifier       
           , b.has_store_id     
           , b.sales_channel    
           , b.affiliate_id     
           , b.channel
           , b.sub_channel
           , b.partner_level
           , b.global_channel
           , b.global_channel_ebi
           , b.biz_type
           , b.biz_type_ebi
           , b.audience_type
           , b.audience_type_ebi
           , b.sales_org
           , b.business_area
           , b.company_code
           , b.country
           , b.country_code
           , b.currency
           , b.file_name
           , b.last_modification_file
           , b.load_timestamp
           , CURRENT_TIMESTAMP
        );  
                                      
END
$$;

CALL ow_md.proc_ods_sales_channels();
-- proc_ods_sales_channels
-- -----------------------
-- 0

