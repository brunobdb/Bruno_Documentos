CREATE OR REPLACE PROCEDURE OW_LAO.PROC_MONITORING_BI_LAO_PROCCESS_DEPARA()
LANGUAGE PLvSQL AS $$
BEGIN

  PERFORM INSERT INTO OW_LAO.MONITORING_BI_LAO_PROCCESS(
                   ORIGEM_NOME
                 , PROCESSO_NOME
                 , REFERENCIA
                 , QUANTIDADE
       )
        SELECT 'ow_md.sales_channel'          AS dataSource
             , 'Control Tower'                AS proccess
             , a.po_orderid                   AS referencia
             , COUNT(1)                       AS quantity
          FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE a
         WHERE a.channel IS NULL
           AND a.po_source_insert_date > TO_DATE('20240501','YYYYMMDD')
           AND NOT EXISTS(
                     SELECT 1
                       FROM OW_LAO.MONITORING_BI_LAO_PROCCESS cc
                      WHERE cc.processo_nome = 'Control Tower'
                        AND cc.origem_nome   = 'ow_md.sales_channel'
                        AND cc.referencia    = a.po_orderid
                        AND cc.status_nome   = 'Em analise'
               )
      GROUP BY a.po_orderid;

  PERFORM INSERT INTO OW_LAO.MONITORING_BI_LAO_PROCCESS(
                   ORIGEM_NOME
                 , PROCESSO_NOME
                 , REFERENCIA
                 , OBSERVACAO 
                 , QUANTIDADE
       )
        SELECT 'ow_lao.dim_ods_sales_control_tower_table_status_mapping' AS dataSource
             , 'Control Tower'                                           AS proccess
             , a.po_internal_status                                      AS referencia
             , 'Realize o mapeamento de STATUS_ORIGIN: "' || a.po_internal_status || '" na tabela ow_lao.dim_ods_sales_control_tower_table_status_mapping' AS observacao
             , COUNT(1)                                                  AS quantity
          FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE a
         WHERE a.po_status IS NULL 
           AND a.po_internal_status IS NOT NULL
           AND NOT EXISTS(
                     SELECT 1
                       FROM OW_LAO.MONITORING_BI_LAO_PROCCESS cc
                      WHERE cc.processo_nome = 'Control Tower'
                        AND cc.origem_nome   = 'ow_lao.dim_ods_sales_control_tower_table_status_mapping'
                        AND cc.referencia    = a.po_internal_status
                        AND cc.status_nome   = 'Em analise'
               )
      GROUP BY a.po_internal_status;

  PERFORM INSERT INTO OW_LAO.MONITORING_BI_LAO_PROCCESS(
                   ORIGEM_NOME
                 , PROCESSO_NOME
                 , REFERENCIA
                 , QUANTIDADE
       )
        SELECT 'ow_lao.ft_ap2_exchange_rate'  AS dataSource
             , 'Control Tower'                AS proccess
             , a.po_orderid                   AS referencia
             , COUNT(1)                       AS quantity
          FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE a
         WHERE a.po_totalprice_usd IS NULL
           AND a.po_totalprice_local IS NOT NULL
           AND NOT EXISTS(
                     SELECT 1
                       FROM OW_LAO.MONITORING_BI_LAO_PROCCESS cc
                      WHERE cc.processo_nome = 'Control Tower'
                        AND cc.origem_nome   = 'ow_lao.ft_ap2_exchange_rate'
                        AND cc.referencia    = a.po_orderid
                        AND cc.status_nome   = 'Em analise'
               )
      GROUP BY a.po_orderid;

  PERFORM INSERT INTO OW_LAO.MONITORING_BI_LAO_PROCCESS(
                   ORIGEM_NOME
                 , PROCESSO_NOME
                 , REFERENCIA
                 , QUANTIDADE
       )
        SELECT 'ow_lao.dim_product_mapping_lao'  AS dataSource
             , 'Control Tower'                   AS proccess
             , LEFT(a.po_sku, 1000)              AS referencia
             , COUNT(1)                          AS quantity
          FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE a
         WHERE division IS NULL   
           AND a.po_source_insert_date >= TO_DATE('20220101','YYYYMMDD') 
           AND NOT EXISTS(
                     SELECT 1
                       FROM OW_LAO.MONITORING_BI_LAO_PROCCESS cc
                      WHERE cc.processo_nome = 'Control Tower'
                        AND cc.origem_nome   = 'ow_lao.dim_product_mapping_lao'
                        AND cc.referencia    = LEFT(a.po_sku, 1000)
                        AND cc.status_nome   = 'Em analise'
               )
      GROUP BY a.po_sku;

END;
$$;

-- CALL OW_LAO.PROC_MONITORING_BI_LAO_PROCCESS_DEPARA();
-- ERROR: Severity: ERROR, Message: Cannot set NOT NULL columns (ID, STATUS_NOME) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure PROC_MONITORING_BI_LAO_PROCCESS_DEPARA line 4 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3211, Error Code: 2514, 
-- CALL OW_LAO.PROC_MONITORING_BI_LAO_PROCCESS_DEPARA();
-- ERROR: Severity: ERROR, Message: Cannot set NOT NULL columns (ID, STATUS_NOME) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure PROC_MONITORING_BI_LAO_PROCCESS_DEPARA line 4 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3211, Error Code: 2514, 
SELECT column_name, data_type, is_nullable, column_default FROM v_catalog.columns WHERE table_schema = 'OW_LAO' AND table_name = 'MONITORING_BI_LAO_PROCCESS' ORDER BY ordinal_position;
-- column_name | data_type | is_nullable | column_default
-- ------------+-----------+-------------+---------------
-- ID | int | False | 
-- INSERTED_TIMESTAMP | timestamp | True | 
-- UPDATED_TIMESTAMP | timestamp | True | 
-- PROCESSO_NOME | varchar(255) | True | 
-- ORIGEM_NOME | varchar(255) | True | 
-- QUANTIDADE | int | True | 
-- REFERENCIA | varchar(255) | False | 
-- STATUS_NOME | varchar(255) | False | 
-- ANALISTA_NOME | varchar(255) | True | 
-- OBSERVACAO | varchar(3000) | True | 

SELECT table_schema, table_name FROM v_catalog.tables WHERE table_schema ILIKE 'ow_lao' AND table_name ILIKE 'monitoring_bi_lao_proccess';
-- table_schema | table_name
-- -------------+-----------
-- OW_LAO | MONITORING_BI_LAO_PROCCESS

SELECT column_name, data_type, is_nullable, column_default FROM v_catalog.columns WHERE table_schema = 'ow_lao' AND table_name = 'monitoring_bi_lao_proccess' ORDER BY ordinal_position;
-- column_name | data_type | is_nullable | column_default
-- ------------+-----------+-------------+---------------

CREATE OR REPLACE PROCEDURE ow_lao.proc_monitoring_bi_lao_proccess_depara()
LANGUAGE PLvSQL AS $$
BEGIN
  
  -- 1) Missing sales_channel
  PERFORM INSERT INTO ow_lao.monitoring_bi_lao_proccess(
      id, origem_nome, processo_nome, referencia, quantidade, status_nome
  )
  WITH base AS (
    SELECT COALESCE(MAX(id),0) AS base FROM ow_lao.monitoring_bi_lao_proccess
  ), grp AS (
    SELECT a.po_orderid AS referencia, COUNT(1) AS quantity
      FROM ow_lao.ods_sales_control_tower_table a
     WHERE a.channel IS NULL
       AND a.po_source_insert_date > TO_DATE('20240501','YYYYMMDD')
       AND NOT EXISTS (
           SELECT 1
             FROM ow_lao.monitoring_bi_lao_proccess cc
            WHERE cc.processo_nome = 'Control Tower'
              AND cc.origem_nome   = 'ow_md.sales_channel'
              AND cc.referencia    = a.po_orderid
              AND cc.status_nome   = 'Em analise'
       )
     GROUP BY a.po_orderid
  ), num AS (
    SELECT ROW_NUMBER() OVER (ORDER BY referencia) AS rn, referencia, quantity FROM grp
  )
  SELECT base.base + rn AS id,
         'ow_md.sales_channel' AS origem_nome,
         'Control Tower'       AS processo_nome,
         referencia,
         quantity              AS quantidade,
         'Em analise'          AS status_nome
    FROM num
    CROSS JOIN base;

  -- 2) Missing status mapping
  PERFORM INSERT INTO ow_lao.monitoring_bi_lao_proccess(
      id, origem_nome, processo_nome, referencia, observacao, quantidade, status_nome
  )
  WITH base AS (
    SELECT COALESCE(MAX(id),0) AS base FROM ow_lao.monitoring_bi_lao_proccess
  ), grp AS (
    SELECT a.po_internal_status AS referencia,
           'Realize o mapeamento de STATUS_ORIGIN: "' || a.po_internal_status || '" na tabela ow_lao.dim_ods_sales_control_tower_table_status_mapping' AS observacao,
           COUNT(1) AS quantity
      FROM ow_lao.ods_sales_control_tower_table a
     WHERE a.po_status IS NULL
       AND a.po_internal_status IS NOT NULL
       AND NOT EXISTS (
           SELECT 1
             FROM ow_lao.monitoring_bi_lao_proccess cc
            WHERE cc.processo_nome = 'Control Tower'
              AND cc.origem_nome   = 'ow_lao.dim_ods_sales_control_tower_table_status_mapping'
              AND cc.referencia    = a.po_internal_status
              AND cc.status_nome   = 'Em analise'
       )
     GROUP BY a.po_internal_status
  ), num AS (
    SELECT ROW_NUMBER() OVER (ORDER BY referencia) AS rn, referencia, observacao, quantity FROM grp
  )
  SELECT base.base + rn AS id,
         'ow_lao.dim_ods_sales_control_tower_table_status_mapping' AS origem_nome,
         'Control Tower'       AS processo_nome,
         referencia,
         observacao,
         quantity              AS quantidade,
         'Em analise'          AS status_nome
    FROM num
    CROSS JOIN base;

  -- 3) Missing exchange rate
  PERFORM INSERT INTO ow_lao.monitoring_bi_lao_proccess(
      id, origem_nome, processo_nome, referencia, quantidade, status_nome
  )
  WITH base AS (
    SELECT COALESCE(MAX(id),0) AS base FROM ow_lao.monitoring_bi_lao_proccess
  ), grp AS (
    SELECT a.po_orderid AS referencia, COUNT(1) AS quantity
      FROM ow_lao.ods_sales_control_tower_table a
     WHERE a.po_totalprice_usd IS NULL
       AND a.po_totalprice_local IS NOT NULL
       AND NOT EXISTS (
           SELECT 1
             FROM ow_lao.monitoring_bi_lao_proccess cc
            WHERE cc.processo_nome = 'Control Tower'
              AND cc.origem_nome   = 'ow_lao.ft_ap2_exchange_rate'
              AND cc.referencia    = a.po_orderid
              AND cc.status_nome   = 'Em analise'
       )
     GROUP BY a.po_orderid
  ), num AS (
    SELECT ROW_NUMBER() OVER (ORDER BY referencia) AS rn, referencia, quantity FROM grp
  )
  SELECT base.base + rn AS id,
         'ow_lao.ft_ap2_exchange_rate' AS origem_nome,
         'Control Tower'       AS processo_nome,
         referencia,
         quantity              AS quantidade,
         'Em analise'          AS status_nome
    FROM num
    CROSS JOIN base;

  -- 4) Missing product mapping
  PERFORM INSERT INTO ow_lao.monitoring_bi_lao_proccess(
      id, origem_nome, processo_nome, referencia, quantidade, status_nome
  )
  WITH base AS (
    SELECT COALESCE(MAX(id),0) AS base FROM ow_lao.monitoring_bi_lao_proccess
  ), grp AS (
    SELECT LEFT(a.po_sku, 1000) AS referencia, COUNT(1) AS quantity
      FROM ow_lao.ods_sales_control_tower_table a
     WHERE division IS NULL
       AND a.po_source_insert_date >= TO_DATE('20220101','YYYYMMDD')
       AND NOT EXISTS (
           SELECT 1
             FROM ow_lao.monitoring_bi_lao_proccess cc
            WHERE cc.processo_nome = 'Control Tower'
              AND cc.origem_nome   = 'ow_lao.dim_product_mapping_lao'
              AND cc.referencia    = LEFT(a.po_sku, 1000)
              AND cc.status_nome   = 'Em analise'
       )
     GROUP BY a.po_sku
  ), num AS (
    SELECT ROW_NUMBER() OVER (ORDER BY referencia) AS rn, referencia, quantity FROM grp
  )
  SELECT base.base + rn AS id,
         'ow_lao.dim_product_mapping_lao' AS origem_nome,
         'Control Tower'       AS processo_nome,
         referencia,
         quantity              AS quantidade,
         'Em analise'          AS status_nome
    FROM num
    CROSS JOIN base;

END;
$$;

CALL ow_lao.proc_monitoring_bi_lao_proccess_depara();
-- proc_monitoring_bi_lao_proccess_depara
-- --------------------------------------
-- 0

