-- CREATE OR REPLACE PROCEDURE OW_LAO.HOMOLOG_PROC_FUNNEL_PAYMENTS_MAP(
--     IN CONSULTA VARCHAR(40)
-- ) LANGUAGE PLvSQL AS $$
-- BEGIN
--     IF CONSULTA = 'UPDATE DIM' THEN
--         PERFORM MERGE INTO OW_LAO.DIM_PAYMENT_STATUS_MAPPING AS A
--         USING OW_LAO.TMP_PAYMENT_STATUS_MAPPING_MINIO AS B
--         ON (
--             A.PAY_STATUS = B.PAY_STATUS
--             AND A.PO_STATUS = B.PO_STATUS
--             AND A.PAY_DESCRIPTION = B.PAY_DESCRIPTION
--         )
--         WHEN MATCHED THEN UPDATE SET
--             STATUS = B.STATUS,
--             UPDATED_TIMESTAMP = CURRENT_TIMESTAMP,
--             ACTIVE = TRUE,
--             REPROCESSING = TRUE
--         WHERE (A.STATUS <> B.STATUS OR COALESCE(A.ACTIVE, FALSE) = FALSE)
--         WHEN NOT MATCHED THEN INSERT (
--             PAY_STATUS,
--             PO_STATUS,
--             PAY_DESCRIPTION,
--             STATUS,
--             ACTIVE,
--             REPROCESSING
--         ) VALUES (
--             B.PAY_STATUS,
--             B.PO_STATUS,
--             B.PAY_DESCRIPTION,
--             B.STATUS,
--             TRUE,
--             TRUE
--         );
-- 
--         PERFORM UPDATE OW_LAO.DIM_PAYMENT_STATUS_MAPPING A
--         SET
--             ACTIVE = FALSE,
--             REPROCESSING = FALSE,
--             UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
--         WHERE
--             NOT EXISTS (
--                 SELECT 1
--                 FROM OW_LAO.TMP_PAYMENT_STATUS_MAPPING_MINIO B
--                 WHERE A.PAY_STATUS = B.PAY_STATUS
--                   AND A.PO_STATUS = B.PO_STATUS
--                   AND A.PAY_DESCRIPTION = B.PAY_DESCRIPTION
--                   AND A.STATUS = B.STATUS
--             )
--           AND ACTIVE = TRUE;
-- 
--         PERFORM UPDATE OW_LAO.ODS_PAYMENT_FUNNEL A
--         SET
--             FUNNEL_STATUS = B.STATUS,
--             UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
--         FROM OW_LAO.DIM_PAYMENT_STATUS_MAPPING B
--         WHERE B.PAY_STATUS = A.PAY_STATUS
--           AND B.PO_STATUS = A.PO_STATUS
--           AND B.PAY_DESCRIPTION = A.PAY_DESCRIPTION
--           AND B.ACTIVE = TRUE
--           AND B.REPROCESSING = TRUE;
-- 
--         PERFORM UPDATE OW_LAO.DIM_PAYMENT_STATUS_MAPPING
--         SET REPROCESSING = FALSE
--         WHERE REPROCESSING = TRUE;
-- 
--     ELSIF CONSULTA = 'F_FUNNEL_PAYMENTS' THEN
--         PERFORM DROP TABLE IF EXISTS aux_taxes;
--         PERFORM CREATE LOCAL TEMPORARY TABLE aux_taxes ON COMMIT PRESERVE ROWS AS
--             SELECT 
--                 SUBSIDIARY,
--                 CURRENCY,
--                 TAX_VALUE
--             FROM 
--                 OW_LAO.AUX_SALES_CONTROL_TOWER_TABLE_TAXES A
--             JOIN
--                 U_PRJ_ECOM.DIM_SUBSIDIARY B
--             ON A.ID = B.ID;
-- 
--         RETURN QUERY
--         SELECT  
--             A.PO_DATE,
--             EXTRACT(WEEK FROM A.PO_DATE) AS PO_WEEK,
--             A.PO_MONTH,
--             A.PO_YEAR,
--             A.SUBSIDIARY,
--             CASE 
--                 WHEN UPPER(PO_DEVICETYPE) IN ('WEBMOBILE', 'WEB') THEN 'Website'
--                 WHEN UPPER(PO_DEVICETYPE) IN ('MOBILEAPP') THEN 'App'
--                 ELSE 'Website'
--             END AS PO_DEVICETYPE,
--             A.CHANNEL,
--             CASE 
--                 WHEN BIZ_TYPE = 'B2C' THEN 'SHOP' 
--                 ELSE BIZ_TYPE
--             END AS BIZ_TYPE,
--             A.AUDIENCE_TYPE,
--             A.FUNNEL_STATUS,
--             A.PAY_GATEWAY,
--             A.PAY_STORENAME AS PO_STORENAME,
--             A.PAY_ORDERID,
--             A.PAY_STATUS,
--             A.PAY_DETAIL,
--             A.PAY_GATEWAY_CODE,
--             A.PAYMENT_TYPE,
--             A.CURRENCY,
--             A.POSTORENAME,
--             B.GATEWAY,
--             C.PAYMENT_MODE,
--             D.GATEWAY_CODE,
--             CAST(A.PE_AMOUNT AS DECIMAL) AS PE_AMOUNT,
--             CAST(A.REVENUE_LOCAL AS DECIMAL) AS REVENUE_LOCAL,
--             A.REVENUE_LOCAL - (A.REVENUE_LOCAL * E.TAX_VALUE) AS NET_REVENUE_LOCAL,
--             A.REVENU_USD - (A.REVENU_USD * E.TAX_VALUE) AS NET_REVENUE_USD,
--             CAST(A.REVENU_USD AS DECIMAL) AS REVENU_USD,
--             CAST(F.EXCHANGE_RATE AS DECIMAL) AS EXCHANGE_RATE,
--             COALESCE(A.UPDATED_TIMESTAMP, A.INSERT_TIMESTAMP) AS DT_RANGE
--         FROM 
--             OW_LAO.ODS_PAYMENT_FUNNEL A
--         JOIN
--             OW_LAO.DIM_PAYMENT_PAY_GATEWAY B ON UPPER(A.PAY_GATEWAY) = UPPER(B.PAY_GATEWAY)
--         JOIN 
--             OW_LAO.DIM_PAYMENT_PAYMENT_TYPE C ON UPPER(A.PAYMENT_TYPE) = UPPER(C.PAYMENT_TYPE)
--         JOIN 
--             OW_LAO.DIM_PAYMENT_GATEWAY_CODE D ON UPPER(A.PAY_GATEWAY_CODE) = UPPER(D.PAY_GATEWAY_CODE)
--         JOIN
--             aux_taxes E ON A.SUBSIDIARY = E.SUBSIDIARY AND A.CURRENCY = E.CURRENCY
--         JOIN
--             OW_LAO.FT_AP2_EXCHANGE_RATE F ON TIMESTAMPADD(DAY, -1, CAST(A.PO_DATE AS DATE)) = F.VALID_FROM AND LOWER(A.CURRENCY) = LOWER(F.TO_CURRENCY)
--         WHERE 
--             A.FUNNEL_STATUS IS NOT NULL
--         ORDER BY 
--             COALESCE(A.UPDATED_TIMESTAMP, A.INSERT_TIMESTAMP) DESC
--         LIMIT 100000;
-- 
--         PERFORM DROP TABLE IF EXISTS aux_taxes;
-- 
--     ELSIF CONSULTA = 'D_CALENDARIO' THEN
--         RETURN QUERY
--         SELECT DISTINCT 
--             PO_DATE,
--             CAST(TO_CHAR(PO_DATE, 'IW') AS INTEGER) AS "Semana"
--         FROM 
--             OW_LAO.ODS_PAYMENT_FUNNEL A
--         WHERE 
--             A.FUNNEL_STATUS IS NOT NULL;
-- 
--     ELSE
--         RETURN QUERY SELECT 'Procedimento não declaro' AS CONSULTA;
--     END IF;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 77.16-20 of source string: syntax error, unexpected QUERY, expecting := or <-, Sqlstate: 42601, Position: 2592, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
-- CREATE OR REPLACE PROCEDURE OW_LAO.HOMOLOG_PROC_FUNNEL_PAYMENTS_MAP(
--     IN CONSULTA VARCHAR(40)
-- ) LANGUAGE PLvSQL AS $$
-- BEGIN
--     IF CONSULTA = 'UPDATE DIM' THEN    
--         PERFORM MERGE INTO OW_LAO.DIM_PAYMENT_STATUS_MAPPING AS A
--         USING OW_LAO.TMP_PAYMENT_STATUS_MAPPING_MINIO AS B 
--         ON 
--             A.PAY_STATUS = B.PAY_STATUS
--             AND A.PO_STATUS = B.PO_STATUS
--             AND A.PAY_DESCRIPTION = B.PAY_DESCRIPTION
--         WHEN MATCHED AND (A.STATUS <> B.STATUS OR COALESCE(A.ACTIVE, FALSE) = FALSE) THEN UPDATE SET 
--             STATUS = B.STATUS,
--             UPDATED_TIMESTAMP = CURRENT_TIMESTAMP,
--             ACTIVE = TRUE,
--             REPROCESSING = TRUE
--         WHEN NOT MATCHED THEN INSERT(
--             PAY_STATUS,
--             PO_STATUS,
--             PAY_DESCRIPTION,
--             STATUS,
--             ACTIVE,
--             REPROCESSING
--         )
--         VALUES (
--             B.PAY_STATUS,
--             B.PO_STATUS,
--             B.PAY_DESCRIPTION,
--             B.STATUS,
--             TRUE,
--             TRUE
--         );
-- 
--         PERFORM UPDATE OW_LAO.DIM_PAYMENT_STATUS_MAPPING A 
--         SET
--             ACTIVE = FALSE,
--             REPROCESSING = FALSE,
--             UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
--         WHERE
--             NOT EXISTS (
--                 SELECT 1
--                 FROM OW_LAO.TMP_PAYMENT_STATUS_MAPPING_MINIO B
--                 WHERE A.PAY_STATUS = B.PAY_STATUS
--                   AND A.PO_STATUS = B.PO_STATUS
--                   AND A.PAY_DESCRIPTION = B.PAY_DESCRIPTION
--                   AND A.STATUS = B.STATUS
--             )
--           AND ACTIVE = TRUE;
--     
--         PERFORM UPDATE OW_LAO.ODS_PAYMENT_FUNNEL A
--         SET
--             FUNNEL_STATUS = B.STATUS,
--             UPDATED_TIMESTAMP = CURRENT_TIMESTAMP 
--         FROM OW_LAO.DIM_PAYMENT_STATUS_MAPPING B 
--         WHERE 
--             B.PAY_STATUS = A.PAY_STATUS 
--             AND B.PO_STATUS = A.PO_STATUS 
--             AND B.PAY_DESCRIPTION = A.PAY_DESCRIPTION
--             AND B.ACTIVE = TRUE
--             AND B.REPROCESSING = TRUE; 
--     
--         PERFORM UPDATE OW_LAO.DIM_PAYMENT_STATUS_MAPPING     
--         SET 
--             REPROCESSING = FALSE
--         WHERE 
--             REPROCESSING = TRUE;
-- 
--     ELSIF CONSULTA = 'F_FUNNEL_PAYMENTS' THEN    
--         PERFORM DROP TABLE IF EXISTS aux_taxes;
--         PERFORM CREATE LOCAL TEMPORARY TABLE aux_taxes ON COMMIT PRESERVE ROWS AS            
--             SELECT 
--                 SUBSIDIARY,
--                 CURRENCY,
--                 TAX_VALUE
--             FROM 
--                 OW_LAO.AUX_SALES_CONTROL_TOWER_TABLE_TAXES A
--             JOIN
--                 U_PRJ_ECOM.DIM_SUBSIDIARY B
--             ON 
--                 A.ID = B.ID;       
--         
--         SELECT  
--             A.PO_DATE,
--             EXTRACT(WEEK FROM A.PO_DATE)                 AS PO_WEEK, 
--             A.PO_MONTH,
--             A.PO_YEAR,
--             A.SUBSIDIARY,
--             CASE 
--                 WHEN UPPER(PO_DEVICETYPE) IN ('WEBMOBILE', 'WEB')     THEN 'Website'
--                 WHEN UPPER(PO_DEVICETYPE) IN ('MOBILEAPP')            THEN 'App'
--                 ELSE 'Website'
--             END AS PO_DEVICETYPE,
--             A.CHANNEL,
--             CASE 
--                 WHEN BIZ_TYPE =  'B2C' THEN 'SHOP' 
--                 ELSE BIZ_TYPE
--             END                             AS BIZ_TYPE,
--             A.AUDIENCE_TYPE,
--             A.FUNNEL_STATUS,
--             A.PAY_GATEWAY,
--             A.PAY_STORENAME                 AS PO_STORENAME,
--             A.PAY_ORDERID,
--             A.PAY_STATUS,
--             A.PAY_DETAIL,
--             A.PAY_GATEWAY_CODE,
--             A.PAYMENT_TYPE,
--             A.CURRENCY,
--             A.POSTORENAME,
--             B.GATEWAY,
--             C.PAYMENT_MODE,
--             D.GATEWAY_CODE,
--             CAST(A.PE_AMOUNT      AS DECIMAL)                        AS PE_AMOUNT,
--             CAST(A.REVENUE_LOCAL  AS DECIMAL)                        AS REVENUE_LOCAL,
--             A.REVENUE_LOCAL - (A.REVENUE_LOCAL  * E.TAX_VALUE)       AS NET_REVENUE_LOCAL,
--             A.REVENU_USD   - (A.REVENU_USD     * E.TAX_VALUE)        AS NET_REVENUE_USD,            
--             CAST(A.REVENU_USD      AS DECIMAL)                        AS REVENU_USD,
--             CAST(F.EXCHANGE_RATE   AS DECIMAL)                        AS EXCHANGE_RATE,
--             COALESCE(A.UPDATED_TIMESTAMP,A.INSERT_TIMESTAMP) DT_RANGE
--         FROM 
--             OW_LAO.ODS_PAYMENT_FUNNEL        A
--         JOIN
--             OW_LAO.DIM_PAYMENT_PAY_GATEWAY   B ON UPPER(A.PAY_GATEWAY) = UPPER(B.PAY_GATEWAY)
--         JOIN 
--             OW_LAO.DIM_PAYMENT_PAYMENT_TYPE  C ON UPPER(A.PAYMENT_TYPE) = UPPER(C.PAYMENT_TYPE) 
--         JOIN 
--             OW_LAO.DIM_PAYMENT_GATEWAY_CODE  D ON UPPER(A.PAY_GATEWAY_CODE) = UPPER(D.PAY_GATEWAY_CODE) 
--         JOIN
--             aux_taxes                        E ON A.SUBSIDIARY = E.SUBSIDIARY AND A.CURRENCY = E.CURRENCY
--         JOIN
--             OW_LAO.FT_AP2_EXCHANGE_RATE      F ON TIMESTAMPADD(DAY,-1,CAST(A.PO_DATE AS DATE)) = F.VALID_FROM AND LOWER(A.CURRENCY) = LOWER(F.TO_CURRENCY)
--         WHERE 
--             A.FUNNEL_STATUS IS NOT NULL
--         ORDER BY 
--             COALESCE(A.UPDATED_TIMESTAMP,A.INSERT_TIMESTAMP) DESC
--         LIMIT 100000;
--         
--         PERFORM DROP TABLE IF EXISTS aux_taxes;
-- 
--     ELSIF CONSULTA = 'D_CALENDARIO' THEN   
--         SELECT DISTINCT 
--             PO_DATE,
--             CAST(TO_CHAR(PO_DATE, 'IW') AS INTEGER) AS "Semana"
--         FROM 
--             OW_LAO.ODS_PAYMENT_FUNNEL A 
--         WHERE 
--             A.FUNNEL_STATUS IS NOT NULL;
-- 
--     ELSE
--         SELECT 'Procedimento não declaro' AS CONSULTA;
--     END IF;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 133.21 of source string: syntax error, unexpected ;, expecting INTO, Sqlstate: 42601, Position: 5159, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
CREATE OR REPLACE PROCEDURE OW_LAO.HOMOLOG_PROC_FUNNEL_PAYMENTS_MAP(
    IN CONSULTA VARCHAR(40)
) LANGUAGE PLvSQL AS $$
BEGIN
    IF CONSULTA = 'UPDATE DIM' THEN    
        PERFORM MERGE INTO OW_LAO.DIM_PAYMENT_STATUS_MAPPING A
        USING OW_LAO.TMP_PAYMENT_STATUS_MAPPING_MINIO B
        ON A.PAY_STATUS = B.PAY_STATUS
           AND A.PO_STATUS = B.PO_STATUS
           AND A.PAY_DESCRIPTION = B.PAY_DESCRIPTION
        WHEN MATCHED THEN UPDATE SET 
            STATUS = B.STATUS,
            UPDATED_TIMESTAMP = CURRENT_TIMESTAMP,
            ACTIVE = TRUE,
            REPROCESSING = TRUE
        WHERE (A.STATUS <> B.STATUS OR COALESCE(A.ACTIVE, FALSE) = FALSE)
        WHEN NOT MATCHED THEN INSERT (
            PAY_STATUS,
            PO_STATUS,
            PAY_DESCRIPTION,
            STATUS,
            ACTIVE,
            REPROCESSING
        ) VALUES (
            B.PAY_STATUS,
            B.PO_STATUS,
            B.PAY_DESCRIPTION,
            B.STATUS,
            TRUE,
            TRUE
        );

        PERFORM UPDATE OW_LAO.DIM_PAYMENT_STATUS_MAPPING A
        SET
            ACTIVE = FALSE,
            REPROCESSING = FALSE,
            UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
        WHERE
            NOT EXISTS (
                SELECT 1
                FROM OW_LAO.TMP_PAYMENT_STATUS_MAPPING_MINIO B
                WHERE A.PAY_STATUS = B.PAY_STATUS
                  AND A.PO_STATUS = B.PO_STATUS
                  AND A.PAY_DESCRIPTION = B.PAY_DESCRIPTION
                  AND A.STATUS = B.STATUS
            )
          AND A.ACTIVE = TRUE;
    
        PERFORM UPDATE OW_LAO.ODS_PAYMENT_FUNNEL A
        SET
            FUNNEL_STATUS = B.STATUS,
            UPDATED_TIMESTAMP = CURRENT_TIMESTAMP 
        FROM OW_LAO.DIM_PAYMENT_STATUS_MAPPING B 
        WHERE 
            B.PAY_STATUS = A.PAY_STATUS 
            AND B.PO_STATUS = A.PO_STATUS 
            AND B.PAY_DESCRIPTION = A.PAY_DESCRIPTION
            AND B.ACTIVE = TRUE
            AND B.REPROCESSING = TRUE; 
    
        PERFORM UPDATE OW_LAO.DIM_PAYMENT_STATUS_MAPPING     
        SET 
            REPROCESSING = FALSE
        WHERE 
            REPROCESSING = TRUE;

    ELSIF CONSULTA = 'F_FUNNEL_PAYMENTS' THEN    
        PERFORM DROP TABLE IF EXISTS aux_taxes;
        PERFORM CREATE LOCAL TEMPORARY TABLE aux_taxes ON COMMIT PRESERVE ROWS AS
            SELECT 
                B.SUBSIDIARY,
                A.CURRENCY,
                A.TAX_VALUE
            FROM 
                OW_LAO.AUX_SALES_CONTROL_TOWER_TABLE_TAXES A
            JOIN
                U_PRJ_ECOM.DIM_SUBSIDIARY B
            ON 
                A.ID = B.ID;

        PERFORM DROP TABLE IF EXISTS tmp_homolog_proc_funnel_payments_map_rs;
        PERFORM CREATE LOCAL TEMPORARY TABLE tmp_homolog_proc_funnel_payments_map_rs ON COMMIT PRESERVE ROWS AS
        SELECT  
            A.PO_DATE,
            EXTRACT(WEEK FROM A.PO_DATE)                 AS PO_WEEK, 
            A.PO_MONTH,
            A.PO_YEAR,
            A.SUBSIDIARY,
            CASE 
                WHEN UPPER(A.PO_DEVICETYPE) IN ('WEBMOBILE', 'WEB')     THEN 'Website'
                WHEN UPPER(A.PO_DEVICETYPE) IN ('MOBILEAPP')            THEN 'App'
                ELSE 'Website'
            END AS PO_DEVICETYPE,
            A.CHANNEL,
            CASE 
                WHEN A.BIZ_TYPE =  'B2C' THEN 'SHOP' 
                ELSE A.BIZ_TYPE
            END                             AS BIZ_TYPE,
            A.AUDIENCE_TYPE,
            A.FUNNEL_STATUS,
            A.PAY_GATEWAY,
            A.PAY_STORENAME                 AS PO_STORENAME,
            A.PAY_ORDERID,
            A.PAY_STATUS,
            A.PAY_DETAIL,
            A.PAY_GATEWAY_CODE,
            A.PAYMENT_TYPE,
            A.CURRENCY,
            A.POSTORENAME,
            B.GATEWAY,
            C.PAYMENT_MODE,
            D.GATEWAY_CODE,
            CAST(A.PE_AMOUNT      AS NUMERIC(18,6))                        AS PE_AMOUNT,
            CAST(A.REVENUE_LOCAL  AS NUMERIC(18,6))                        AS REVENUE_LOCAL,
            A.REVENUE_LOCAL - (A.REVENUE_LOCAL  * E.TAX_VALUE)       AS NET_REVENUE_LOCAL,
            A.REVENU_USD   - (A.REVENU_USD     * E.TAX_VALUE)        AS NET_REVENUE_USD,            
            CAST(A.REVENU_USD      AS NUMERIC(18,6))                        AS REVENU_USD,
            CAST(F.EXCHANGE_RATE   AS NUMERIC(18,6))                        AS EXCHANGE_RATE,
            COALESCE(A.UPDATED_TIMESTAMP,A.INSERT_TIMESTAMP) DT_RANGE
        FROM 
            OW_LAO.ODS_PAYMENT_FUNNEL        A
        JOIN
            OW_LAO.DIM_PAYMENT_PAY_GATEWAY   B ON UPPER(A.PAY_GATEWAY) = UPPER(B.PAY_GATEWAY)
        JOIN 
            OW_LAO.DIM_PAYMENT_PAYMENT_TYPE  C ON UPPER(A.PAYMENT_TYPE) = UPPER(C.PAYMENT_TYPE) 
        JOIN 
            OW_LAO.DIM_PAYMENT_GATEWAY_CODE  D ON UPPER(A.PAY_GATEWAY_CODE) = UPPER(D.PAY_GATEWAY_CODE) 
        JOIN
            aux_taxes                        E ON A.SUBSIDIARY = E.SUBSIDIARY AND A.CURRENCY = E.CURRENCY
        JOIN
            OW_LAO.FT_AP2_EXCHANGE_RATE      F ON TIMESTAMPADD(DAY,-1,CAST(A.PO_DATE AS DATE)) = F.VALID_FROM AND LOWER(A.CURRENCY) = LOWER(F.TO_CURRENCY)
        WHERE 
            A.FUNNEL_STATUS IS NOT NULL
        ORDER BY 
            COALESCE(A.UPDATED_TIMESTAMP,A.INSERT_TIMESTAMP) DESC
        LIMIT 100000;
        
        PERFORM DROP TABLE IF EXISTS aux_taxes;

    ELSIF CONSULTA = 'D_CALENDARIO' THEN   
        PERFORM DROP TABLE IF EXISTS tmp_homolog_proc_funnel_payments_map_rs;
        PERFORM CREATE LOCAL TEMPORARY TABLE tmp_homolog_proc_funnel_payments_map_rs ON COMMIT PRESERVE ROWS AS
        SELECT DISTINCT 
            PO_DATE,
            CAST(TO_CHAR(PO_DATE, 'IW') AS INTEGER) AS "Semana"
        FROM 
            OW_LAO.ODS_PAYMENT_FUNNEL A 
        WHERE 
            A.FUNNEL_STATUS IS NOT NULL;

    ELSE
        PERFORM DROP TABLE IF EXISTS tmp_homolog_proc_funnel_payments_map_rs;
        PERFORM CREATE LOCAL TEMPORARY TABLE tmp_homolog_proc_funnel_payments_map_rs ON COMMIT PRESERVE ROWS AS
        SELECT 'Procedimento não declaro' AS CONSULTA;
    END IF;
END;
$$;

-- CALL OW_LAO.HOMOLOG_PROC_FUNNEL_PAYMENTS_MAP('UPDATE DIM');
-- ERROR: Severity: ERROR, Message: Table "OW_LAO.DIM_PAYMENT_STATUS_MAPPING" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure HOMOLOG_PROC_FUNNEL_PAYMENTS_MAP line 4 at static SQL, Routine: throwErrInvalidTab, File: analyze.c, Line: 3378, Error Code: 4883, 
