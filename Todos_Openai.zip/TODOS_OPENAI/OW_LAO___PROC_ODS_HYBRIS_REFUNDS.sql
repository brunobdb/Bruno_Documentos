-- CREATE OR REPLACE PROCEDURE OW_LAO.PROC_ODS_HYBRIS_REFUNDS()
--  LANGUAGE PLvSQL AS $$
-- BEGIN
--      
--      PERFORM CREATE LOCAL TEMPORARY TABLE TMP_HYBRIS_REFUNDS_DEDUP ON COMMIT PRESERVE ROWS AS (
--             SELECT a.*
--             FROM OW_LAO.RAW_HYBRIS_REFUNDS a
--             WHERE NOT EXISTS (
--                 SELECT 1
--                 FROM OW_LAO.ODS_HYBRIS_REFUNDS aa
--                 WHERE aa."COUNTRY_CD" = a."COUNTRY_CD"
--                   AND aa."CART_ID" = a."CART_ID"
--                   AND aa."ORDER_ID" = a."ORDER_ID"
--                   AND aa."FILE_GENERATED_AT" >= a."FILE_GENERATED_AT"
--             )
--             QUALIFY ROW_NUMBER() OVER (
--                 PARTITION BY a."COUNTRY_CD", a."CART_ID", a."ORDER_ID"
--                 ORDER BY a."FILE_GENERATED_AT" DESC
--             ) = 1
--      );
-- 
--      PERFORM MERGE INTO OW_LAO.ODS_HYBRIS_REFUNDS       a
--           USING TMP_HYBRIS_REFUNDS_DEDUP b ON b."COUNTRY_CD" = a."COUNTRY_CD"
--                                           AND b."CART_ID"    = a."CART_ID"
--                                           AND b."ORDER_ID"   = a."ORDER_ID"
--            WHEN MATCHED THEN UPDATE SET
--                                      a."REFUND_STATUS" = b."REFUND_STATUS"
--                                    , a."ORDER_DATE" = b."ORDER_DATE"
--                                    , a."PO_ID" = b."PO_ID"
--                                    , a."ORDER_TYPE" = b."ORDER_TYPE"
--                                    , a."TRANSACTION_ID" = b."TRANSACTION_ID"
--                                    , a."PAYMENT_METHOD_NAME" = b."PAYMENT_METHOD_NAME"
--                                    , a."PAYMENT_GATEWAY" = b."PAYMENT_GATEWAY"
--                                    , a."PAYMENT_OPTION_NAME" = b."PAYMENT_OPTION_NAME"
--                                    , a."PAYMENT_CODE" = b."PAYMENT_CODE"
--                                    , a."PLAN_ID" = b."PLAN_ID"
--                                    , a."PROGRAM_TYPE" = b."PROGRAM_TYPE"
--                                    , a."EMI_CALCULATED_ON" = b."EMI_CALCULATED_ON"
--                                    , a."INSTALLMENT_AMOUNT" = b."INSTALLMENT_AMOUNT"
--                                    , a."TENURE_UNIT" = b."TENURE_UNIT"
--                                    , a."TENURE_VALUE" = b."TENURE_VALUE"
--                                    , a."TOTAL_AMOUNT" = b."TOTAL_AMOUNT"
--                                    , a."PG_MESSAGE" = b."PG_MESSAGE"
--                                    , a."TRANSACTION_AMOUNT" = b."TRANSACTION_AMOUNT"
--                                    , a."TRANSACTION_CURRENCY" = b."TRANSACTION_CURRENCY"
--                                    , a."IS_FINANCING" = b."IS_FINANCING"
--                                    , a."PLATFORM" = b."PLATFORM"
--                                    , a."ORDER_PROGRAM_TYPE" = b."ORDER_PROGRAM_TYPE"
--                                    , a."ORDER_CHANNEL_CODE" = b."ORDER_CHANNEL_CODE"
--                                    , a."STORE_ID" = b."STORE_ID"
--                                    , a."STORE_NAME" = b."STORE_NAME"
--                                    , a."STORE_TYPE" = b."STORE_TYPE"
--                                    , a."CREATED_TIME_UTC" = b."CREATED_TIME_UTC"
--                                    , a."CREATED_TIME_LOCAL" = b."CREATED_TIME_LOCAL"
--                                    , a."CREATED_DATE_LOCAL_KEY" = b."CREATED_DATE_LOCAL_KEY"
--                                    , a."IS_UPGRADE" = b."IS_UPGRADE"
--                                    , a."IS_TRADE_IN" = b."IS_TRADE_IN"
--                                    , a."PAYMENT_MODE" = b."PAYMENT_MODE"
--                                    , a."REFUND_TYPE" = b."REFUND_TYPE"
--                                    , a."FILE_NAME_FROM_FILE" = b."FILE_NAME_FROM_FILE"
--                                    , a."LOAD_DATE" = b."LOAD_DATE"
--                                    , a."FILE_NAME" = b."FILE_NAME"
--                                    , a."FILE_LAST_MODIFIED_TIME" = b."FILE_LAST_MODIFIED_TIME"
--                                    , a."FILE_NAME_SHORT" = b."FILE_NAME_SHORT"
--                                    , a."INSERTED_DATE" = CURRENT_TIMESTAMP
--                                    , a."FILE_GENERATED_AT" = b."FILE_GENERATED_AT"
--                                    , a."UPDATED_DATETIME" = CURRENT_TIMESTAMP
--            WHEN NOT MATCHED THEN INSERT (
--                                      "COUNTRY_CD"
--                                    , "CART_ID"
--                                    , "REFUND_STATUS"
--                                    , "ORDER_DATE"
--                                    , "ORDER_ID"
--                                    , "PO_ID"
--                                    , "ORDER_TYPE"
--                                    , "TRANSACTION_ID"
--                                    , "PAYMENT_METHOD_NAME"
--                                    , "PAYMENT_GATEWAY"
--                                    , "PAYMENT_OPTION_NAME"
--                                    , "PAYMENT_CODE"
--                                    , "PLAN_ID"
--                                    , "PROGRAM_TYPE"
--                                    , "EMI_CALCULATED_ON"
--                                    , "INSTALLMENT_AMOUNT"
--                                    , "TENURE_UNIT"
--                                    , "TENURE_VALUE"
--                                    , "TOTAL_AMOUNT"
--                                    , "PG_MESSAGE"
--                                    , "TRANSACTION_AMOUNT"
--                                    , "TRANSACTION_CURRENCY"
--                                    , "IS_FINANCING"
--                                    , "PLATFORM"
--                                    , "ORDER_PROGRAM_TYPE"
--                                    , "ORDER_CHANNEL_CODE"
--                                    , "STORE_ID"
--                                    , "STORE_NAME"
--                                    , "STORE_TYPE"
--                                    , "CREATED_TIME_UTC"
--                                    , "CREATED_TIME_LOCAL"
--                                    , "CREATED_DATE_LOCAL_KEY"
--                                    , "IS_UPGRADE"
--                                    , "IS_TRADE_IN"
--                                    , "PAYMENT_MODE"
--                                    , "REFUND_TYPE"
--                                    , "FILE_NAME_FROM_FILE"
--                                    , "LOAD_DATE"
--                                    , "FILE_NAME"
--                                    , "FILE_LAST_MODIFIED_TIME"
--                                    , "FILE_NAME_SHORT"
--                                    , "INSERTED_DATE"
--                                    , "FILE_GENERATED_AT"
--                                    , "UPDATED_DATETIME"
--                                    ) VALUES (
--                                      b."COUNTRY_CD"
--                                    , b."CART_ID"
--                                    , b."REFUND_STATUS"
--                                    , b."ORDER_DATE"
--                                    , b."ORDER_ID"
--                                    , b."PO_ID"
--                                    , b."ORDER_TYPE"
--                                    , b."TRANSACTION_ID"
--                                    , b."PAYMENT_METHOD_NAME"
--                                    , b."PAYMENT_GATEWAY"
--                                    , b."PAYMENT_OPTION_NAME"
--                                    , b."PAYMENT_CODE"
--                                    , b."PLAN_ID"
--                                    , b."PROGRAM_TYPE"
--                                    , b."EMI_CALCULATED_ON"
--                                    , b."INSTALLMENT_AMOUNT"
--                                    , b."TENURE_UNIT"
--                                    , b."TENURE_VALUE"
--                                    , b."TOTAL_AMOUNT"
--                                    , b."PG_MESSAGE"
--                                    , b."TRANSACTION_AMOUNT"
--                                    , b."TRANSACTION_CURRENCY"
--                                    , b."IS_FINANCING"
--                                    , b."PLATFORM"
--                                    , b."ORDER_PROGRAM_TYPE"
--                                    , b."ORDER_CHANNEL_CODE"
--                                    , b."STORE_ID"
--                                    , b."STORE_NAME"
--                                    , b."STORE_TYPE"
--                                    , b."CREATED_TIME_UTC"
--                                    , b."CREATED_TIME_LOCAL"
--                                    , b."CREATED_DATE_LOCAL_KEY"
--                                    , b."IS_UPGRADE"
--                                    , b."IS_TRADE_IN"
--                                    , b."PAYMENT_MODE"
--                                    , b."REFUND_TYPE"
--                                    , b."FILE_NAME_FROM_FILE"
--                                    , b."LOAD_DATE"
--                                    , b."FILE_NAME"
--                                    , b."FILE_LAST_MODIFIED_TIME"
--                                    , b."FILE_NAME_SHORT"
--                                    , CURRENT_TIMESTAMP
--                                    , b."FILE_GENERATED_AT"
--                                    , NULL
--                                    );
-- 
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: Syntax error at or near "QUALIFY", Sqlstate: 42601, Position: 618, Routine: base_yyerror, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/scan.l, Line: 1056, Error Code: 4856, 
CREATE OR REPLACE PROCEDURE OW_LAO.PROC_ODS_HYBRIS_REFUNDS()
 LANGUAGE PLvSQL AS $$
BEGIN
     
     PERFORM CREATE LOCAL TEMPORARY TABLE TMP_HYBRIS_REFUNDS_DEDUP ON COMMIT PRESERVE ROWS AS 
            SELECT *
            FROM (
                SELECT a.*,
                       ROW_NUMBER() OVER (
                           PARTITION BY a."COUNTRY_CD", a."CART_ID", a."ORDER_ID"
                           ORDER BY a."FILE_GENERATED_AT" DESC
                       ) AS rn
                FROM OW_LAO.RAW_HYBRIS_REFUNDS a
                WHERE NOT EXISTS (
                    SELECT 1
                    FROM OW_LAO.ODS_HYBRIS_REFUNDS aa
                    WHERE aa."COUNTRY_CD" = a."COUNTRY_CD"
                      AND aa."CART_ID" = a."CART_ID"
                      AND aa."ORDER_ID" = a."ORDER_ID"
                      AND aa."FILE_GENERATED_AT" >= a."FILE_GENERATED_AT"
                )
            ) s
            WHERE rn = 1;

     PERFORM MERGE INTO OW_LAO.ODS_HYBRIS_REFUNDS       a
          USING TMP_HYBRIS_REFUNDS_DEDUP b ON b."COUNTRY_CD" = a."COUNTRY_CD"
                                          AND b."CART_ID"    = a."CART_ID"
                                          AND b."ORDER_ID"   = a."ORDER_ID"
           WHEN MATCHED THEN UPDATE SET
                                     a."REFUND_STATUS" = b."REFUND_STATUS"
                                   , a."ORDER_DATE" = b."ORDER_DATE"
                                   , a."PO_ID" = b."PO_ID"
                                   , a."ORDER_TYPE" = b."ORDER_TYPE"
                                   , a."TRANSACTION_ID" = b."TRANSACTION_ID"
                                   , a."PAYMENT_METHOD_NAME" = b."PAYMENT_METHOD_NAME"
                                   , a."PAYMENT_GATEWAY" = b."PAYMENT_GATEWAY"
                                   , a."PAYMENT_OPTION_NAME" = b."PAYMENT_OPTION_NAME"
                                   , a."PAYMENT_CODE" = b."PAYMENT_CODE"
                                   , a."PLAN_ID" = b."PLAN_ID"
                                   , a."PROGRAM_TYPE" = b."PROGRAM_TYPE"
                                   , a."EMI_CALCULATED_ON" = b."EMI_CALCULATED_ON"
                                   , a."INSTALLMENT_AMOUNT" = b."INSTALLMENT_AMOUNT"
                                   , a."TENURE_UNIT" = b."TENURE_UNIT"
                                   , a."TENURE_VALUE" = b."TENURE_VALUE"
                                   , a."TOTAL_AMOUNT" = b."TOTAL_AMOUNT"
                                   , a."PG_MESSAGE" = b."PG_MESSAGE"
                                   , a."TRANSACTION_AMOUNT" = b."TRANSACTION_AMOUNT"
                                   , a."TRANSACTION_CURRENCY" = b."TRANSACTION_CURRENCY"
                                   , a."IS_FINANCING" = b."IS_FINANCING"
                                   , a."PLATFORM" = b."PLATFORM"
                                   , a."ORDER_PROGRAM_TYPE" = b."ORDER_PROGRAM_TYPE"
                                   , a."ORDER_CHANNEL_CODE" = b."ORDER_CHANNEL_CODE"
                                   , a."STORE_ID" = b."STORE_ID"
                                   , a."STORE_NAME" = b."STORE_NAME"
                                   , a."STORE_TYPE" = b."STORE_TYPE"
                                   , a."CREATED_TIME_UTC" = b."CREATED_TIME_UTC"
                                   , a."CREATED_TIME_LOCAL" = b."CREATED_TIME_LOCAL"
                                   , a."CREATED_DATE_LOCAL_KEY" = b."CREATED_DATE_LOCAL_KEY"
                                   , a."IS_UPGRADE" = b."IS_UPGRADE"
                                   , a."IS_TRADE_IN" = b."IS_TRADE_IN"
                                   , a."PAYMENT_MODE" = b."PAYMENT_MODE"
                                   , a."REFUND_TYPE" = b."REFUND_TYPE"
                                   , a."FILE_NAME_FROM_FILE" = b."FILE_NAME_FROM_FILE"
                                   , a."LOAD_DATE" = b."LOAD_DATE"
                                   , a."FILE_NAME" = b."FILE_NAME"
                                   , a."FILE_LAST_MODIFIED_TIME" = b."FILE_LAST_MODIFIED_TIME"
                                   , a."FILE_NAME_SHORT" = b."FILE_NAME_SHORT"
                                   , a."INSERTED_DATE" = CURRENT_TIMESTAMP
                                   , a."FILE_GENERATED_AT" = b."FILE_GENERATED_AT"
                                   , a."UPDATED_DATETIME" = CURRENT_TIMESTAMP
           WHEN NOT MATCHED THEN INSERT (
                                     "COUNTRY_CD"
                                   , "CART_ID"
                                   , "REFUND_STATUS"
                                   , "ORDER_DATE"
                                   , "ORDER_ID"
                                   , "PO_ID"
                                   , "ORDER_TYPE"
                                   , "TRANSACTION_ID"
                                   , "PAYMENT_METHOD_NAME"
                                   , "PAYMENT_GATEWAY"
                                   , "PAYMENT_OPTION_NAME"
                                   , "PAYMENT_CODE"
                                   , "PLAN_ID"
                                   , "PROGRAM_TYPE"
                                   , "EMI_CALCULATED_ON"
                                   , "INSTALLMENT_AMOUNT"
                                   , "TENURE_UNIT"
                                   , "TENURE_VALUE"
                                   , "TOTAL_AMOUNT"
                                   , "PG_MESSAGE"
                                   , "TRANSACTION_AMOUNT"
                                   , "TRANSACTION_CURRENCY"
                                   , "IS_FINANCING"
                                   , "PLATFORM"
                                   , "ORDER_PROGRAM_TYPE"
                                   , "ORDER_CHANNEL_CODE"
                                   , "STORE_ID"
                                   , "STORE_NAME"
                                   , "STORE_TYPE"
                                   , "CREATED_TIME_UTC"
                                   , "CREATED_TIME_LOCAL"
                                   , "CREATED_DATE_LOCAL_KEY"
                                   , "IS_UPGRADE"
                                   , "IS_TRADE_IN"
                                   , "PAYMENT_MODE"
                                   , "REFUND_TYPE"
                                   , "FILE_NAME_FROM_FILE"
                                   , "LOAD_DATE"
                                   , "FILE_NAME"
                                   , "FILE_LAST_MODIFIED_TIME"
                                   , "FILE_NAME_SHORT"
                                   , "INSERTED_DATE"
                                   , "FILE_GENERATED_AT"
                                   , "UPDATED_DATETIME"
                                   ) VALUES (
                                     b."COUNTRY_CD"
                                   , b."CART_ID"
                                   , b."REFUND_STATUS"
                                   , b."ORDER_DATE"
                                   , b."ORDER_ID"
                                   , b."PO_ID"
                                   , b."ORDER_TYPE"
                                   , b."TRANSACTION_ID"
                                   , b."PAYMENT_METHOD_NAME"
                                   , b."PAYMENT_GATEWAY"
                                   , b."PAYMENT_OPTION_NAME"
                                   , b."PAYMENT_CODE"
                                   , b."PLAN_ID"
                                   , b."PROGRAM_TYPE"
                                   , b."EMI_CALCULATED_ON"
                                   , b."INSTALLMENT_AMOUNT"
                                   , b."TENURE_UNIT"
                                   , b."TENURE_VALUE"
                                   , b."TOTAL_AMOUNT"
                                   , b."PG_MESSAGE"
                                   , b."TRANSACTION_AMOUNT"
                                   , b."TRANSACTION_CURRENCY"
                                   , b."IS_FINANCING"
                                   , b."PLATFORM"
                                   , b."ORDER_PROGRAM_TYPE"
                                   , b."ORDER_CHANNEL_CODE"
                                   , b."STORE_ID"
                                   , b."STORE_NAME"
                                   , b."STORE_TYPE"
                                   , b."CREATED_TIME_UTC"
                                   , b."CREATED_TIME_LOCAL"
                                   , b."CREATED_DATE_LOCAL_KEY"
                                   , b."IS_UPGRADE"
                                   , b."IS_TRADE_IN"
                                   , b."PAYMENT_MODE"
                                   , b."REFUND_TYPE"
                                   , b."FILE_NAME_FROM_FILE"
                                   , b."LOAD_DATE"
                                   , b."FILE_NAME"
                                   , b."FILE_LAST_MODIFIED_TIME"
                                   , b."FILE_NAME_SHORT"
                                   , CURRENT_TIMESTAMP
                                   , b."FILE_GENERATED_AT"
                                   , NULL
                                   );

END;
$$;

-- CALL OW_LAO.PROC_ODS_HYBRIS_REFUNDS();
-- ERROR: Severity: ERROR, Message: Either column "a" does not exist or table alias "a" is not allowed in "WHEN MATCHED THEN UPDATE SET", Sqlstate: 42602, Hint: Either fix the column name "a" or remove table alias "a" from all column names in "WHEN MATCHED THEN UPDATE SET", Where: PL/vSQL procedure PROC_ODS_HYBRIS_REFUNDS line 24 at static SQL, Routine: transformVMergeStmt, File: analyze.c, Line: 3541, Error Code: 5569, 
-- CALL OW_LAO.PROC_ODS_HYBRIS_REFUNDS();
-- ERROR: Severity: ERROR, Message: Either column "a" does not exist or table alias "a" is not allowed in "WHEN MATCHED THEN UPDATE SET", Sqlstate: 42602, Hint: Either fix the column name "a" or remove table alias "a" from all column names in "WHEN MATCHED THEN UPDATE SET", Where: PL/vSQL procedure PROC_ODS_HYBRIS_REFUNDS line 24 at static SQL, Routine: transformVMergeStmt, File: analyze.c, Line: 3541, Error Code: 5569, 
CREATE OR REPLACE PROCEDURE OW_LAO.PROC_ODS_HYBRIS_REFUNDS()
 LANGUAGE PLvSQL AS $$
BEGIN
     
     PERFORM CREATE LOCAL TEMPORARY TABLE TMP_HYBRIS_REFUNDS_DEDUP ON COMMIT PRESERVE ROWS AS 
            SELECT *
            FROM (
                SELECT a.*,
                       ROW_NUMBER() OVER (
                           PARTITION BY a."COUNTRY_CD", a."CART_ID", a."ORDER_ID"
                           ORDER BY a."FILE_GENERATED_AT" DESC
                       ) AS rn
                FROM OW_LAO.RAW_HYBRIS_REFUNDS a
                WHERE NOT EXISTS (
                    SELECT 1
                    FROM OW_LAO.ODS_HYBRIS_REFUNDS aa
                    WHERE aa."COUNTRY_CD" = a."COUNTRY_CD"
                      AND aa."CART_ID" = a."CART_ID"
                      AND aa."ORDER_ID" = a."ORDER_ID"
                      AND aa."FILE_GENERATED_AT" >= a."FILE_GENERATED_AT"
                )
            ) s
            WHERE rn = 1;

     PERFORM MERGE INTO OW_LAO.ODS_HYBRIS_REFUNDS a
          USING TMP_HYBRIS_REFUNDS_DEDUP b ON b."COUNTRY_CD" = a."COUNTRY_CD"
                                          AND b."CART_ID"    = a."CART_ID"
                                          AND b."ORDER_ID"   = a."ORDER_ID"
           WHEN MATCHED THEN UPDATE SET
                                     "REFUND_STATUS" = b."REFUND_STATUS"
                                   , "ORDER_DATE" = b."ORDER_DATE"
                                   , "PO_ID" = b."PO_ID"
                                   , "ORDER_TYPE" = b."ORDER_TYPE"
                                   , "TRANSACTION_ID" = b."TRANSACTION_ID"
                                   , "PAYMENT_METHOD_NAME" = b."PAYMENT_METHOD_NAME"
                                   , "PAYMENT_GATEWAY" = b."PAYMENT_GATEWAY"
                                   , "PAYMENT_OPTION_NAME" = b."PAYMENT_OPTION_NAME"
                                   , "PAYMENT_CODE" = b."PAYMENT_CODE"
                                   , "PLAN_ID" = b."PLAN_ID"
                                   , "PROGRAM_TYPE" = b."PROGRAM_TYPE"
                                   , "EMI_CALCULATED_ON" = b."EMI_CALCULATED_ON"
                                   , "INSTALLMENT_AMOUNT" = b."INSTALLMENT_AMOUNT"
                                   , "TENURE_UNIT" = b."TENURE_UNIT"
                                   , "TENURE_VALUE" = b."TENURE_VALUE"
                                   , "TOTAL_AMOUNT" = b."TOTAL_AMOUNT"
                                   , "PG_MESSAGE" = b."PG_MESSAGE"
                                   , "TRANSACTION_AMOUNT" = b."TRANSACTION_AMOUNT"
                                   , "TRANSACTION_CURRENCY" = b."TRANSACTION_CURRENCY"
                                   , "IS_FINANCING" = b."IS_FINANCING"
                                   , "PLATFORM" = b."PLATFORM"
                                   , "ORDER_PROGRAM_TYPE" = b."ORDER_PROGRAM_TYPE"
                                   , "ORDER_CHANNEL_CODE" = b."ORDER_CHANNEL_CODE"
                                   , "STORE_ID" = b."STORE_ID"
                                   , "STORE_NAME" = b."STORE_NAME"
                                   , "STORE_TYPE" = b."STORE_TYPE"
                                   , "CREATED_TIME_UTC" = b."CREATED_TIME_UTC"
                                   , "CREATED_TIME_LOCAL" = b."CREATED_TIME_LOCAL"
                                   , "CREATED_DATE_LOCAL_KEY" = b."CREATED_DATE_LOCAL_KEY"
                                   , "IS_UPGRADE" = b."IS_UPGRADE"
                                   , "IS_TRADE_IN" = b."IS_TRADE_IN"
                                   , "PAYMENT_MODE" = b."PAYMENT_MODE"
                                   , "REFUND_TYPE" = b."REFUND_TYPE"
                                   , "FILE_NAME_FROM_FILE" = b."FILE_NAME_FROM_FILE"
                                   , "LOAD_DATE" = b."LOAD_DATE"
                                   , "FILE_NAME" = b."FILE_NAME"
                                   , "FILE_LAST_MODIFIED_TIME" = b."FILE_LAST_MODIFIED_TIME"
                                   , "FILE_NAME_SHORT" = b."FILE_NAME_SHORT"
                                   , "INSERTED_DATE" = CURRENT_TIMESTAMP
                                   , "FILE_GENERATED_AT" = b."FILE_GENERATED_AT"
                                   , "UPDATED_DATETIME" = CURRENT_TIMESTAMP
           WHEN NOT MATCHED THEN INSERT (
                                     "COUNTRY_CD"
                                   , "CART_ID"
                                   , "REFUND_STATUS"
                                   , "ORDER_DATE"
                                   , "ORDER_ID"
                                   , "PO_ID"
                                   , "ORDER_TYPE"
                                   , "TRANSACTION_ID"
                                   , "PAYMENT_METHOD_NAME"
                                   , "PAYMENT_GATEWAY"
                                   , "PAYMENT_OPTION_NAME"
                                   , "PAYMENT_CODE"
                                   , "PLAN_ID"
                                   , "PROGRAM_TYPE"
                                   , "EMI_CALCULATED_ON"
                                   , "INSTALLMENT_AMOUNT"
                                   , "TENURE_UNIT"
                                   , "TENURE_VALUE"
                                   , "TOTAL_AMOUNT"
                                   , "PG_MESSAGE"
                                   , "TRANSACTION_AMOUNT"
                                   , "TRANSACTION_CURRENCY"
                                   , "IS_FINANCING"
                                   , "PLATFORM"
                                   , "ORDER_PROGRAM_TYPE"
                                   , "ORDER_CHANNEL_CODE"
                                   , "STORE_ID"
                                   , "STORE_NAME"
                                   , "STORE_TYPE"
                                   , "CREATED_TIME_UTC"
                                   , "CREATED_TIME_LOCAL"
                                   , "CREATED_DATE_LOCAL_KEY"
                                   , "IS_UPGRADE"
                                   , "IS_TRADE_IN"
                                   , "PAYMENT_MODE"
                                   , "REFUND_TYPE"
                                   , "FILE_NAME_FROM_FILE"
                                   , "LOAD_DATE"
                                   , "FILE_NAME"
                                   , "FILE_LAST_MODIFIED_TIME"
                                   , "FILE_NAME_SHORT"
                                   , "INSERTED_DATE"
                                   , "FILE_GENERATED_AT"
                                   , "UPDATED_DATETIME"
                                   ) VALUES (
                                     b."COUNTRY_CD"
                                   , b."CART_ID"
                                   , b."REFUND_STATUS"
                                   , b."ORDER_DATE"
                                   , b."ORDER_ID"
                                   , b."PO_ID"
                                   , b."ORDER_TYPE"
                                   , b."TRANSACTION_ID"
                                   , b."PAYMENT_METHOD_NAME"
                                   , b."PAYMENT_GATEWAY"
                                   , b."PAYMENT_OPTION_NAME"
                                   , b."PAYMENT_CODE"
                                   , b."PLAN_ID"
                                   , b."PROGRAM_TYPE"
                                   , b."EMI_CALCULATED_ON"
                                   , b."INSTALLMENT_AMOUNT"
                                   , b."TENURE_UNIT"
                                   , b."TENURE_VALUE"
                                   , b."TOTAL_AMOUNT"
                                   , b."PG_MESSAGE"
                                   , b."TRANSACTION_AMOUNT"
                                   , b."TRANSACTION_CURRENCY"
                                   , b."IS_FINANCING"
                                   , b."PLATFORM"
                                   , b."ORDER_PROGRAM_TYPE"
                                   , b."ORDER_CHANNEL_CODE"
                                   , b."STORE_ID"
                                   , b."STORE_NAME"
                                   , b."STORE_TYPE"
                                   , b."CREATED_TIME_UTC"
                                   , b."CREATED_TIME_LOCAL"
                                   , b."CREATED_DATE_LOCAL_KEY"
                                   , b."IS_UPGRADE"
                                   , b."IS_TRADE_IN"
                                   , b."PAYMENT_MODE"
                                   , b."REFUND_TYPE"
                                   , b."FILE_NAME_FROM_FILE"
                                   , b."LOAD_DATE"
                                   , b."FILE_NAME"
                                   , b."FILE_LAST_MODIFIED_TIME"
                                   , b."FILE_NAME_SHORT"
                                   , CURRENT_TIMESTAMP
                                   , b."FILE_GENERATED_AT"
                                   , NULL
                                   );

END;
$$;

CALL OW_LAO.PROC_ODS_HYBRIS_REFUNDS();
-- PROC_ODS_HYBRIS_REFUNDS
-- -----------------------
-- 0

