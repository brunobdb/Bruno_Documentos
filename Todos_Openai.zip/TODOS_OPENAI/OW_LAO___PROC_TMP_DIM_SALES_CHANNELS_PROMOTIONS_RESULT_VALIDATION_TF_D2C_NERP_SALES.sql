CREATE OR REPLACE PROCEDURE OW_LAO.proc_tmp_dim_sales_channels_promotions_result_validation_tf_d2c_nerp_sales()
LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM DROP TABLE IF EXISTS ow_lao.tmp_ft_d2c_vtex_promotion_prom_name_reference;
    PERFORM CREATE TABLE ow_lao.tmp_ft_d2c_vtex_promotion_prom_name_reference AS
        SELECT a.environment
             , a.sales_channel
             , a.order_id
             , a.marketplace_order_id
             , a.reference_code
             , a.item_name
             , a.prom_name
             , SUBSTR(a.prom_name,
                      INSTR(a.prom_name, '[') + 1,
                      INSTR(a.prom_name, ']') - INSTR(a.prom_name, '[') - 1
               ) AS prom_name_reference
          FROM ow_lao.ft_d2c_vtex_promotion a
         WHERE a.po_creation_date BETWEEN DATE '2024-05-01' AND DATE '2024-05-31';

    PERFORM DROP TABLE IF EXISTS ow_lao.tmp_ft_d2c_vtex_promotion_prom_name_reference_fix_null;
    PERFORM CREATE TABLE ow_lao.tmp_ft_d2c_vtex_promotion_prom_name_reference_fix_null AS
        SELECT DISTINCT
               a.environment
             , a.sales_channel
             , a.order_id
             , a.marketplace_order_id
             , a.reference_code
             , a.item_name
             , a.prom_name
             , COALESCE(a.prom_name_reference, '') AS prom_name_reference
          FROM ow_lao.tmp_ft_d2c_vtex_promotion_prom_name_reference a;

    PERFORM DROP TABLE IF EXISTS ow_lao.tmp_dim_sales_channels_promotions_result_ordering;
    PERFORM CREATE TABLE ow_lao.tmp_dim_sales_channels_promotions_result_ordering AS
        SELECT a.environment
             , a.order_id
             , a.marketplace_order_id
             , a.reference_code
             , COALESCE(b.campaign_name_type, c.Tipo_Promo) AS campaign_name_type
          FROM ow_lao.tmp_ft_d2c_vtex_promotion_prom_name_reference_fix_null a
     LEFT JOIN ow_md.dim_sales_channels_promotions b
            ON COALESCE(b.campaign_reference, '') = a.prom_name_reference
     LEFT JOIN ow_md.input_sales_channels_promotions_statics c
            ON LOWER(c.prom_name) = LOWER(a.prom_name)
      GROUP BY a.environment
             , a.order_id
             , a.marketplace_order_id
             , a.reference_code
             , COALESCE(b.campaign_name_type, c.Tipo_Promo);

    PERFORM DROP TABLE IF EXISTS ow_lao.tmp_dim_sales_channels_promotions_result_validation;
    PERFORM CREATE TABLE ow_lao.tmp_dim_sales_channels_promotions_result_validation AS
        SELECT a.environment
             , a.order_id
             , a.marketplace_order_id
             , a.reference_code
             , LISTAGG(a.campaign_name_type USING PARAMETERS separator=' + ') AS campaign_name_type
          FROM ow_lao.tmp_dim_sales_channels_promotions_result_ordering a
      GROUP BY a.environment
             , a.order_id
             , a.marketplace_order_id
             , a.reference_code;

    PERFORM DROP TABLE IF EXISTS ow_lao.tmp_dim_sales_channels_promotions_result_validation_tf_d2c_nerp_sales;
    PERFORM CREATE TABLE ow_lao.tmp_dim_sales_channels_promotions_result_validation_tf_d2c_nerp_sales AS
        SELECT a.*
             , b.environment          AS promo_environment
             , b.order_id             AS promo_order_id
             , b.marketplace_order_id AS promo_marketplace_order_id
             , b.reference_code       AS promo_reference_code
             , b.campaign_name_type   AS promo_campaign_name_type
          FROM OW_LAO.TF_D2C_NERP_SALES a
          JOIN ow_lao.tmp_dim_sales_channels_promotions_result_validation b
            ON b.order_id = a.order_id
           AND b.reference_code = a.sku
         WHERE LOWER(a.status_po) NOT LIKE '%cancel%';
END;
$$;

-- CALL OW_LAO.proc_tmp_dim_sales_channels_promotions_result_validation_tf_d2c_nerp_sales();
-- ERROR: Severity: ERROR, Message: Relation "ow_md.dim_sales_channels_promotions" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_tmp_dim_sales_channels_promotions_result_validation_tf_d2c_nerp_sales line 33 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
-- CALL OW_LAO.proc_tmp_dim_sales_channels_promotions_result_validation_tf_d2c_nerp_sales();
-- ERROR: Severity: ERROR, Message: Relation "ow_md.dim_sales_channels_promotions" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_tmp_dim_sales_channels_promotions_result_validation_tf_d2c_nerp_sales line 33 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
