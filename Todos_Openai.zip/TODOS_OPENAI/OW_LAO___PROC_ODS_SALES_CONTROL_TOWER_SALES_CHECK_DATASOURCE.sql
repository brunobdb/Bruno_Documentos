-- CREATE OR REPLACE PROCEDURE OW_LAO.PROC_ODS_SALES_CONTROL_TOWER_SALES_CHECK_DATASOURCE()
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--     WITH ecommerce_orders AS (
--         SELECT 
--             MAX(COALESCE(po_source_last_update_date, po_source_insert_date)) AS last_data,
--             'ods_sales_control_tower_table' AS origin,
--             CASE 
--                 WHEN subsidiary LIKE 'SELA%' THEN 'SELA' 
--                 ELSE subsidiary 
--             END AS subsidiary,
--             CASE 
--                 WHEN CAST(po_source_last_update_date AS DATE) = CURRENT_DATE THEN 'OK'
--                 WHEN subsidiary LIKE 'SELA%'
--                      AND CAST(po_source_last_update_date AS DATE) >= TIMESTAMPADD(DAY, -1, CURRENT_DATE) THEN 'OK'
--                 WHEN country = 'Uruguay'
--                      AND CAST(po_source_last_update_date AS DATE) >= TIMESTAMPADD(DAY, -10, CURRENT_DATE) THEN 'OK'
--                 ELSE 'NOT OK'
--             END AS status,
--             country
--         FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE t
--         WHERE po_plataform_datasource NOT IN ('ow_lao.ods_global_bi_sales', 'u_prj_ecom_synapcom.ft_ecom_order')
--           AND EXISTS (
--               SELECT 1
--               FROM (
--                   SELECT 
--                       subsidiary, 
--                       country,
--                       MAX(po_source_last_update_date) AS po_source_last_update_date
--                   FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE
--                   WHERE CAST(po_source_last_update_date AS DATE) BETWEEN TIMESTAMPADD(DAY, -10, CURRENT_DATE) AND CURRENT_DATE
--                   GROUP BY subsidiary, country
--               ) m
--               WHERE m.subsidiary = t.subsidiary
--                 AND m.country = t.country
--                 AND m.po_source_last_update_date = t.po_source_last_update_date
--           )
--         GROUP BY po_source_last_update_date, subsidiary, country
--     ), 
--     complementary_data AS (
--         SELECT 
--             MAX(nerp_last_update_date) AS sales_order_tracking_timestamp,
--             CASE
--                 WHEN TIMESTAMPDIFF(second, MAX(nerp_last_update_date), CURRENT_TIMESTAMP) / 60 <= 60 THEN 'OK'
--                 ELSE 'NOT OK'
--             END AS sales_order_tracking_status,
--             MAX(nerp_outbound_last_update_date) AS outbound_timestamp,
--             CASE
--                 WHEN TIMESTAMPDIFF(second, MAX(nerp_outbound_last_update_date), CURRENT_TIMESTAMP) / 60 <= 60 THEN 'OK'
--                 ELSE 'NOT OK'
--             END AS outbound_status,
--             MAX(ebi_last_update_date) AS global_bi_timestamp,
--             CASE
--                 WHEN TIMESTAMPDIFF(second, MAX(ebi_last_update_date), CURRENT_TIMESTAMP) / 60 <= 1440 THEN 'OK'
--                 ELSE 'NOT OK'
--             END AS global_bi_status,
--             MAX(po_source_payment_last_update_date) AS payment_timestamp,
--             CASE
--                 WHEN TIMESTAMPDIFF(second, MAX(po_source_payment_last_update_date), CURRENT_TIMESTAMP) / 60 <= 60 THEN 'OK'
--                 ELSE 'NOT OK'
--             END AS payment_status,
--             NULL::VARCHAR AS country,
--             NULL::VARCHAR AS subsidiary
--         FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE
--     )   
--     SELECT 
--         CASE s.seq
--             WHEN 1 THEN 'sales order tracking'
--             WHEN 2 THEN 'outbound'
--             WHEN 3 THEN 'global bi files'
--             WHEN 4 THEN 'payments'
--         END AS origin,
--         CASE s.seq
--             WHEN 1 THEN sales_order_tracking_status
--             WHEN 2 THEN outbound_status
--             WHEN 3 THEN global_bi_status
--             WHEN 4 THEN payment_status
--         END AS status,
--         CASE s.seq
--             WHEN 1 THEN sales_order_tracking_timestamp
--             WHEN 2 THEN outbound_timestamp
--             WHEN 3 THEN global_bi_timestamp
--             WHEN 4 THEN payment_timestamp
--         END AS last_data,
--         cd.country,
--         cd.subsidiary
--     FROM complementary_data cd
--     CROSS JOIN (
--         SELECT 1 AS seq UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4
--     ) s
--     UNION ALL
--     SELECT 
--         origin,
--         status,
--         last_data,
--         country,
--         subsidiary
--     FROM ecommerce_orders;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 3.10-25 of source string: syntax error, unexpected IDENT, expecting := or <-, Sqlstate: 42601, Position: 127, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
CREATE OR REPLACE PROCEDURE OW_LAO.PROC_ODS_SALES_CONTROL_TOWER_SALES_CHECK_DATASOURCE()
LANGUAGE PLvSQL AS $$
BEGIN
    -- staging result table for this session
    PERFORM CREATE LOCAL TEMPORARY TABLE IF NOT EXISTS TMP_ODS_SALES_CHECK_DS (
        origin VARCHAR(64),
        status VARCHAR(16),
        last_data TIMESTAMP,
        country VARCHAR(256),
        subsidiary VARCHAR(256)
    ) ON COMMIT PRESERVE ROWS;

    PERFORM TRUNCATE TABLE TMP_ODS_SALES_CHECK_DS;

    PERFORM INSERT INTO TMP_ODS_SALES_CHECK_DS(origin, status, last_data, country, subsidiary)
    WITH ecommerce_orders AS (
        SELECT 
            MAX(COALESCE(t.po_source_last_update_date, t.po_source_insert_date)) AS last_data,
            'ods_sales_control_tower_table' AS origin,
            CASE 
                WHEN t.subsidiary LIKE 'SELA%' THEN 'SELA' 
                ELSE t.subsidiary 
            END AS subsidiary,
            CASE 
                WHEN CAST(t.po_source_last_update_date AS DATE) = CURRENT_DATE THEN 'OK'
                WHEN t.subsidiary LIKE 'SELA%'
                     AND CAST(t.po_source_last_update_date AS DATE) >= TIMESTAMPADD(DAY, -1, CURRENT_DATE) THEN 'OK'
                WHEN t.country = 'Uruguay'
                     AND CAST(t.po_source_last_update_date AS DATE) >= TIMESTAMPADD(DAY, -10, CURRENT_DATE) THEN 'OK'
                ELSE 'NOT OK'
            END AS status,
            t.country
        FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE t
        WHERE t.po_plataform_datasource NOT IN ('ow_lao.ods_global_bi_sales', 'u_prj_ecom_synapcom.ft_ecom_order')
          AND EXISTS (
              SELECT 1
              FROM (
                  SELECT 
                      subsidiary, 
                      country,
                      MAX(po_source_last_update_date) AS po_source_last_update_date
                  FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE
                  WHERE CAST(po_source_last_update_date AS DATE) BETWEEN TIMESTAMPADD(DAY, -10, CURRENT_DATE) AND CURRENT_DATE
                  GROUP BY subsidiary, country
              ) m
              WHERE m.subsidiary = t.subsidiary
                AND m.country = t.country
                AND m.po_source_last_update_date = t.po_source_last_update_date
          )
        GROUP BY t.po_source_last_update_date, t.subsidiary, t.country
    ), 
    complementary_data AS (
        SELECT 
            MAX(nerp_last_update_date) AS sales_order_tracking_timestamp,
            CASE
                WHEN TIMESTAMPDIFF(second, MAX(nerp_last_update_date), CURRENT_TIMESTAMP) / 60 <= 60 THEN 'OK'
                ELSE 'NOT OK'
            END AS sales_order_tracking_status,
            MAX(nerp_outbound_last_update_date) AS outbound_timestamp,
            CASE
                WHEN TIMESTAMPDIFF(second, MAX(nerp_outbound_last_update_date), CURRENT_TIMESTAMP) / 60 <= 60 THEN 'OK'
                ELSE 'NOT OK'
            END AS outbound_status,
            MAX(ebi_last_update_date) AS global_bi_timestamp,
            CASE
                WHEN TIMESTAMPDIFF(second, MAX(ebi_last_update_date), CURRENT_TIMESTAMP) / 60 <= 1440 THEN 'OK'
                ELSE 'NOT OK'
            END AS global_bi_status,
            MAX(po_source_payment_last_update_date) AS payment_timestamp,
            CASE
                WHEN TIMESTAMPDIFF(second, MAX(po_source_payment_last_update_date), CURRENT_TIMESTAMP) / 60 <= 60 THEN 'OK'
                ELSE 'NOT OK'
            END AS payment_status,
            NULL::VARCHAR AS country,
            NULL::VARCHAR AS subsidiary
        FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE
    )
    SELECT 
        CASE s.seq
            WHEN 1 THEN 'sales order tracking'
            WHEN 2 THEN 'outbound'
            WHEN 3 THEN 'global bi files'
            WHEN 4 THEN 'payments'
        END AS origin,
        CASE s.seq
            WHEN 1 THEN cd.sales_order_tracking_status
            WHEN 2 THEN cd.outbound_status
            WHEN 3 THEN cd.global_bi_status
            WHEN 4 THEN cd.payment_status
        END AS status,
        CASE s.seq
            WHEN 1 THEN cd.sales_order_tracking_timestamp
            WHEN 2 THEN cd.outbound_timestamp
            WHEN 3 THEN cd.global_bi_timestamp
            WHEN 4 THEN cd.payment_timestamp
        END AS last_data,
        cd.country,
        cd.subsidiary
    FROM complementary_data cd
    CROSS JOIN (
        SELECT 1 AS seq UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4
    ) s
    UNION ALL
    SELECT 
        origin,
        status,
        last_data,
        country,
        subsidiary
    FROM ecommerce_orders;

END;
$$;

CALL OW_LAO.PROC_ODS_SALES_CONTROL_TOWER_SALES_CHECK_DATASOURCE();
-- PROC_ODS_SALES_CONTROL_TOWER_SALES_CHECK_DATASOURCE
-- ---------------------------------------------------
-- 0

