CREATE OR REPLACE PROCEDURE OW_LAO.PROC_TF_YAMI_PRODUCT_DETAIL_SEDA_UNIFIED_AND_AUX_CELLO_DELIVERY_INBOUND_YAMI_PRODUCT_DETAIL_RELATIONSHIP_KEYS()
LANGUAGE PLvSQL AS $$
BEGIN  
    PERFORM TRUNCATE TABLE "OW_LAO"."AUX_CELLO_DELIVERY_INBOUND_YAMI_PRODUCT_DETAIL_RELATIONSHIP_KEYS";
    
    PERFORM INSERT INTO "OW_LAO"."AUX_CELLO_DELIVERY_INBOUND_YAMI_PRODUCT_DETAIL_RELATIONSHIP_KEYS" 
    SELECT po_number
         , LENGTH(po_number)                    AS po_number_lenght
         , CASE 
                WHEN LENGTH(po_number) = 6
                THEN po_number
                WHEN LENGTH(po_number) = 20
                THEN SUBSTR(po_number, LENGTH(po_number) - 15)
                ELSE po_number
           END                                  AS po_number_fix
         , CASE LENGTH(po_number)
                WHEN 15 THEN 'order_id'
                WHEN 20 THEN 'order_id'
                ELSE 'sequence'
           END                                  AS po_number_fix_key
      FROM "OW_SEDA_S".CELLO_DELIVERY_INBOUND                 a
      JOIN "OW_LAO".AUX_CELLO_DELIVERY_INBOUND_ORDER_TYPE d ON d.order_type = a.order_type  
     WHERE a.ship_type_cd IN ('P3', 'P4')
       AND a.po_number IS NOT NULL;
    
    PERFORM TRUNCATE TABLE "OW_LAO"."TF_YAMI_PRODUCT_DETAIL_SEDA_UNIFIED";
    
    PERFORM INSERT INTO "OW_LAO"."TF_YAMI_PRODUCT_DETAIL_SEDA_UNIFIED"(
           "ACCOUNT"
         , "MKT_ACCOUNT"
         , "CUSTOMER_ID"
         , "PROTOCOL_VALUE"
         , "ORDER_ID"
         , "ORDER_SEQUENCE"
         , "MKT_PLACE_ORDER_ID"
         , "STATUS"
         , "TYPE"
         , "NAME"
         , "PROCESSED_TIME"
         , "ORDER_INVOICE_NUMBER"
         , "ORDER_ORIGIN_DATE"
         , "ORDER_GIFT_CARD"
         , "ORDER_TRACK_NUMBER"
         , "ORDER_SELLER"
         , "ORDER_TRANSACTION_ID"
         , "CREATED_DATE"
         , "PAYMENT_METHOD"
         , "ID"
         , "ITEM_CODE"
         , "ITEM_MOTIVE"
         , "ITEM_NAME"
         , "ITEM_QUANTITY_IN_ORDER"
         , "ITEM_QUANTITY_IN_REQUEST"
         , "ITEM_VALUE"
         , "ITEM_VALUE_PAID"
         , "ITEM_REF_CODE"
         , "ITEM_FREIGHT"
         , "PRODUCT_ID"
         , "LOAD_DATE")
    SELECT "ACCOUNT"
         , "MKT_ACCOUNT"
         , "CUSTOMER_ID"
         , "PROTOCOL_VALUE"
         , "ORDER_ID"
         , "ORDER_SEQUENCE"
         , "MKT_PLACE_ORDER_ID"
         , "STATUS"
         , "TYPE"
         , "NAME"
         , "PROCESSED_TIME"
         , "ORDER_INVOICE_NUMBER"
         , "ORDER_ORIGIN_DATE"
         , "ORDER_GIFT_CARD"
         , "ORDER_TRACK_NUMBER"
         , "ORDER_SELLER"
         , "ORDER_TRANSACTION_ID"
         , "CREATED_DATE"
         , "PAYMENT_METHOD"
         , "ID"
         , "ITEM_CODE"
         , "ITEM_MOTIVE"
         , "ITEM_NAME"
         , "ITEM_QUANTITY_IN_ORDER"
         , "ITEM_QUANTITY_IN_REQUEST"
         , "ITEM_VALUE"
         , "ITEM_VALUE_PAID"
         , "ITEM_REF_CODE"
         , "ITEM_FREIGHT"
         , "PRODUCT_ID"
         , "LOAD_DATE"
      FROM (
         SELECT ROW_NUMBER() OVER(PARTITION BY account, mkt_account, order_id, item_ref_code ORDER BY b.order_flow) AS dedup
              , a.*
           FROM "OW_SEDA_S".ODS_YAMI_PRODUCT_DETAIL_SAMSUNGBR a
           JOIN "OW_LAO".AUX_YAMI_PRODUCT_DETAIL_STATUS   b ON b.status_name = a.status
          WHERE b."IMPORT" = TRUE
      ) a
     WHERE dedup = 1;
         
    PERFORM INSERT INTO "OW_LAO"."TF_YAMI_PRODUCT_DETAIL_SEDA_UNIFIED"(
           "ACCOUNT"
         , "MKT_ACCOUNT"
         , "CUSTOMER_ID"
         , "PROTOCOL_VALUE"
         , "ORDER_ID"
         , "ORDER_SEQUENCE"
         , "MKT_PLACE_ORDER_ID"
         , "STATUS"
         , "TYPE"
         , "NAME"
         , "PROCESSED_TIME"
         , "ORDER_INVOICE_NUMBER"
         , "ORDER_ORIGIN_DATE"
         , "ORDER_GIFT_CARD"
         , "ORDER_TRACK_NUMBER"
         , "ORDER_SELLER"
         , "ORDER_TRANSACTION_ID"
         , "CREATED_DATE"
         , "PAYMENT_METHOD"
         , "ID"
         , "ITEM_CODE"
         , "ITEM_MOTIVE"
         , "ITEM_NAME"
         , "ITEM_QUANTITY_IN_ORDER"
         , "ITEM_QUANTITY_IN_REQUEST"
         , "ITEM_VALUE"
         , "ITEM_VALUE_PAID"
         , "ITEM_REF_CODE"
         , "ITEM_FREIGHT"
         , "PRODUCT_ID"
         , "LOAD_DATE")
    SELECT "ACCOUNT"
         , "MKT_ACCOUNT"
         , "CUSTOMER_ID"
         , "PROTOCOL_VALUE"
         , "ORDER_ID"
         , "ORDER_SEQUENCE"
         , "MKT_PLACE_ORDER_ID"
         , "STATUS"
         , "TYPE"
         , "NAME"
         , "PROCESSED_TIME"
         , "ORDER_INVOICE_NUMBER"
         , "ORDER_ORIGIN_DATE"
         , "ORDER_GIFT_CARD"
         , "ORDER_TRACK_NUMBER"
         , "ORDER_SELLER"
         , "ORDER_TRANSACTION_ID"
         , "CREATED_DATE"
         , "PAYMENT_METHOD"
         , "ID"
         , "ITEM_CODE"
         , "ITEM_MOTIVE"
         , "ITEM_NAME"
         , "ITEM_QUANTITY_IN_ORDER"
         , "ITEM_QUANTITY_IN_REQUEST"
         , "ITEM_VALUE"
         , "ITEM_VALUE_PAID"
         , "ITEM_REF_CODE"
         , "ITEM_FREIGHT"
         , "PRODUCT_ID"
         , "LOAD_DATE"
      FROM (
         SELECT ROW_NUMBER() OVER(PARTITION BY account, mkt_account, order_id, item_ref_code ORDER BY b.order_flow) AS dedup
              , a.*
           FROM "OW_SEDA_S".ODS_YAMI_PRODUCT_DETAIL_SAMSUNGBRB2B a
           JOIN "OW_LAO".AUX_YAMI_PRODUCT_DETAIL_STATUS   b ON b.status_name = a.status
          WHERE b."IMPORT" = TRUE
      ) a
     WHERE dedup = 1;
         
    PERFORM INSERT INTO "OW_LAO"."TF_YAMI_PRODUCT_DETAIL_SEDA_UNIFIED"(
           "ACCOUNT"
         , "MKT_ACCOUNT"
         , "CUSTOMER_ID"
         , "PROTOCOL_VALUE"
         , "ORDER_ID"
         , "ORDER_SEQUENCE"
         , "MKT_PLACE_ORDER_ID"
         , "STATUS"
         , "TYPE"
         , "NAME"
         , "PROCESSED_TIME"
         , "ORDER_INVOICE_NUMBER"
         , "ORDER_ORIGIN_DATE"
         , "ORDER_GIFT_CARD"
         , "ORDER_TRACK_NUMBER"
         , "ORDER_SELLER"
         , "ORDER_TRANSACTION_ID"
         , "CREATED_DATE"
         , "PAYMENT_METHOD"
         , "ID"
         , "ITEM_CODE"
         , "ITEM_MOTIVE"
         , "ITEM_NAME"
         , "ITEM_QUANTITY_IN_ORDER"
         , "ITEM_QUANTITY_IN_REQUEST"
         , "ITEM_VALUE"
         , "ITEM_VALUE_PAID"
         , "ITEM_REF_CODE"
         , "ITEM_FREIGHT"
         , "PRODUCT_ID"
         , "LOAD_DATE")
    SELECT "ACCOUNT"
         , "MKT_ACCOUNT"
         , "CUSTOMER_ID"
         , "PROTOCOL_VALUE"
         , "ORDER_ID"
         , "ORDER_SEQUENCE"
         , "MKT_PLACE_ORDER_ID"
         , "STATUS"
         , "TYPE"
         , "NAME"
         , "PROCESSED_TIME"
         , "ORDER_INVOICE_NUMBER"
         , "ORDER_ORIGIN_DATE"
         , "ORDER_GIFT_CARD"
         , "ORDER_TRACK_NUMBER"
         , "ORDER_SELLER"
         , "ORDER_TRANSACTION_ID"
         , "CREATED_DATE"
         , "PAYMENT_METHOD"
         , "ID"
         , "ITEM_CODE"
         , "ITEM_MOTIVE"
         , "ITEM_NAME"
         , "ITEM_QUANTITY_IN_ORDER"
         , "ITEM_QUANTITY_IN_REQUEST"
         , "ITEM_VALUE"
         , "ITEM_VALUE_PAID"
         , "ITEM_REF_CODE"
         , "ITEM_FREIGHT"
         , "PRODUCT_ID"
         , "LOAD_DATE"
      FROM (
         SELECT ROW_NUMBER() OVER(PARTITION BY account, mkt_account, order_id, item_ref_code ORDER BY b.order_flow) AS dedup
              , a.*
           FROM "OW_SEDA_S".ODS_YAMI_PRODUCT_DETAIL_SAMSUNGBREPP2 a
           JOIN "OW_LAO".AUX_YAMI_PRODUCT_DETAIL_STATUS   b ON b.status_name = a.status
          WHERE b."IMPORT" = TRUE
      ) a
     WHERE dedup = 1;     
     
END
$$;

-- CALL OW_LAO.PROC_TF_YAMI_PRODUCT_DETAIL_SEDA_UNIFIED_AND_AUX_CELLO_DELIVERY_INBOUND_YAMI_PRODUCT_DETAIL_RELATIONSHIP_KEYS();
-- ERROR: Severity: ROLLBACK, Message: Table "TF_YAMI_PRODUCT_DETAIL_SEDA_UNIFIED" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_TF_YAMI_PRODUCT_DETAIL_SEDA_UNIFIED_AND_AUX_CELLO_DELIVERY_INBOUND_YAMI_PRODUCT_DETAIL_RELATIONSHIP_KEYS line 25 at static SQL, Routine: TruncateTable, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Commands/DDL.cpp, Line: 20681, Error Code: 4876, 
-- CALL OW_LAO.PROC_TF_YAMI_PRODUCT_DETAIL_SEDA_UNIFIED_AND_AUX_CELLO_DELIVERY_INBOUND_YAMI_PRODUCT_DETAIL_RELATIONSHIP_KEYS();
-- ERROR: Severity: ROLLBACK, Message: Table "TF_YAMI_PRODUCT_DETAIL_SEDA_UNIFIED" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_TF_YAMI_PRODUCT_DETAIL_SEDA_UNIFIED_AND_AUX_CELLO_DELIVERY_INBOUND_YAMI_PRODUCT_DETAIL_RELATIONSHIP_KEYS line 25 at static SQL, Routine: TruncateTable, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Commands/DDL.cpp, Line: 20681, Error Code: 4876, 
