CREATE OR REPLACE PROCEDURE OW_LAO.PROC_SALES_DEDUCTION_MONITORING_STATUS()
LANGUAGE PLvSQL AS $$
DECLARE 
    DAY_OF_WEEK VARCHAR(20); 
    LOAD_DATE_CHECK DATE;
    V_COUNT_040 INT;
    VALIDATION_DATE DATE;
BEGIN
    DAY_OF_WEEK := TRIM(TO_CHAR(CURRENT_DATE,'DAY'));
    LOAD_DATE_CHECK := CURRENT_DATE;

    IF DAY_OF_WEEK = 'TUESDAY' THEN
        -- VALIDATION 040 IF RPA WORKS TODAY.
        PERFORM UPDATE OW_LAO.FT_LAO_SALES_DEDUCTION_WEEKLY_MONITORING 
        SET MON = CASE 
                    WHEN EXISTS (
                        SELECT 1
                        FROM OW_LAO.ODS_NERP_ZLMKC00040_CONDITION_PROGRESS_REPORT
                        WHERE CAST(LOAD_DATE AS DATE) = CURRENT_DATE
                    ) THEN 'OK'
                    ELSE 'NOK'
                  END, 
                  "390A" = 'OK',
                  "810A" = 'OK',
                  "810C" = 'OK',
                  "810D" = 'OK',
                  "810F" = 'OK',
                  "810J" = 'OK',
                  "810M" = 'OK',
                  "850A" = 'OK',
                  "813A" = 'OK',
                  "860A" = 'OK',
                  UPDATE_DATE_390A = NOW(),
                  UPDATE_DATE_810A = NOW(),
                  UPDATE_DATE_810C = NOW(),
                  UPDATE_DATE_810D = NOW(),
                  UPDATE_DATE_810F = NOW(),
                  UPDATE_DATE_810J = NOW(),
                  UPDATE_DATE_810M = NOW(),
                  UPDATE_DATE_850A = NOW(),
                  UPDATE_DATE_813A = NOW(),
                  UPDATE_DATE_860A = NOW()
        WHERE PROCESS = 'Condition DB Extraction' 
          AND SUB_PROCESS = 'RPA ZLMKC00040 (Condition Progress Report)';

        -- VALIDATION 040 BI TEAM.
        SELECT COUNT(*) INTO V_COUNT_040
        FROM (
            SELECT DISTINCT 
                T2.COMPANY_CODE,
                T2.BUSINESS_AREA,
                CAST(T1.LOAD_DATE AS DATE)
            FROM OW_LAO.ODS_NERP_ZLMKC00040_CONDITION_PROGRESS_REPORT T1
            INNER JOIN OW_LAO.INPUT_MAPPING_BIZ_AREA_SALES_DEDUCTION T2
                ON SUBSTR(T1.SALES_ORG, 1, 2) = SUBSTR(T2.BUSINESS_AREA, 1, 2)
            WHERE CAST(T1.LOAD_DATE AS DATE) = CURRENT_DATE
                  AND T2.BUSINESS_AREA != '850C'
        ) VALIDATION_040;

        PERFORM UPDATE OW_LAO.FT_LAO_SALES_DEDUCTION_WEEKLY_MONITORING 
        SET MON = CASE 
                    WHEN V_COUNT_040 = 10 THEN 'OK'
                    ELSE 'NOK'
                  END, 
                  "390A" = 'OK',
                  "810A" = 'OK',
                  "810C" = 'OK',
                  "810D" = 'OK',
                  "810F" = 'OK',
                  "810J" = 'OK',
                  "810M" = 'OK',
                  "850A" = 'OK',
                  "813A" = 'OK',
                  "860A" = 'OK',
                  UPDATE_DATE_390A = NOW(),
                  UPDATE_DATE_810A = NOW(),
                  UPDATE_DATE_810C = NOW(),
                  UPDATE_DATE_810D = NOW(),
                  UPDATE_DATE_810F = NOW(),
                  UPDATE_DATE_810J = NOW(),
                  UPDATE_DATE_810M = NOW(),
                  UPDATE_DATE_850A = NOW(),
                  UPDATE_DATE_813A = NOW(),
                  UPDATE_DATE_860A = NOW()
        WHERE PROCESS = 'Condition DB Extraction' 
          AND SUB_PROCESS = 'Data ingestion to SAP Hana - ZLMKC00040';
    END IF;
END;
$$;

CALL OW_LAO.PROC_SALES_DEDUCTION_MONITORING_STATUS();
-- PROC_SALES_DEDUCTION_MONITORING_STATUS
-- --------------------------------------
-- 0

