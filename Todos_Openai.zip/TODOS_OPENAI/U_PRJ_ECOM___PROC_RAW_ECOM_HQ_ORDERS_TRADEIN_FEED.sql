-- CREATE OR REPLACE PROCEDURE U_PRJ_ECOM.PROC_RAW_ECOM_HQ_ORDERS_TRADEIN_FEED()
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--   
--   -- Ensure staging table exists, then truncate
--   PERFORM CREATE TABLE IF NOT EXISTS U_PRJ_ECOM.TMP_ECOM_HQ_ORDERS_TRADEIN_FEED AS
--   SELECT 
--     a.COUNTRY_CD AS "country_cd",
--     a.PO_ORDERID AS "order_id",
--     a.PO_SKU  AS "line_item_id",
--     b.BRAND AS "exchange_brand",
--     b.CATEGORY_NAME AS "exchange_category",
--     b.MODEL AS "exchange_device_name",
--     '' AS "exchange_grade",
--     '' AS "exchange_id",
--     '' AS "exchange_type",
--     '' AS "is_accessory",
--     '' AS "is_financed_order",
--     CASE WHEN a.INSTALLMENT > 1 THEN 'TRUE' ELSE 'FALSE' END AS  "is_financing",
--     '' AS "is_financing_eligible",
--     CASE  WHEN  a.SAMSUNG_CARE =  1 THEN 'TRUE'  ELSE 'FALSE' END AS "is_samsung_care_order",          
--     'TRUE' AS "is_traded_in",
--     '' AS "is_under_extended_warranty",
--     CAST (a.PO_DATE AS date) || ' ' || a.PO_HOUR AS "order_date",
--     CAST (a.PO_DATE AS date) || ' ' || a.PO_HOUR AS "order_time_utc",
--     a.PO_ORDERID  AS "po_id",
--     a.PO_INTERNAL_STATUS  AS "po_status",
--     a.PO_SKU  AS "sku",
--     '' AS "tradein_ext_memory",
--     '' AS "tradein_ext_product_family_name",
--     '' AS "tradein_ext_product_identifier",
--     '' AS "upgrade_id",                   
--     '' AS "upgrade_loan_number",            
--     '' AS "upgrade_root_order_date",      
--     '' AS "upgrade_status",               
--     '' AS "ex_est_exch_discount_amount",
--     '' AS "ex_est_exch_value_amount",    
--     '' AS "ex_est_total_amount",            
--     '' AS "ex_identity_id",               
--     '' AS "ex_sku",                         
--     '' AS "ex_status",
--     'FALSE' as "is_upgrade",
--     'FALSE' AS "is_tariff_order",
--     SUM (b.TRADE_IN_DISCOUNT) AS "discount_amount"
--   FROM  OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE    a
--   JOIN   U_PRJ_ECOM.ODS_ECOM_HQ_ORDERS_PRODUCTS_TRADEIN b 
--        ON a.PO_ORDERID           = b."Order_Id" 
--       AND a.po_sku               = b."Reference_Code" 
--       AND a.CLIENT_SUBSIDIARY_ID = b.SUBSIDIARY_ID
--   WHERE a.CLIENT_SUBSIDIARY_ID  IN  (6,1)
--     AND NOT EXISTS (
--         SELECT 1
--         FROM  U_PRJ_ECOM.RAW_ECOM_HQ_ORDERS_TRADEIN_FEED aa
--         WHERE aa."order_id"     = a.PO_ORDERID 
--           AND aa."line_item_id" = a.PO_SKU 
--     )
--     AND b.IS_TRADE_IN = 'TRUE'  
--     AND a.PO_DATE >= DATE '2023-01-01'
--   GROUP BY 
--     a.COUNTRY_CD ,
--     a.PO_ORDERID ,
--     a.PO_SKU ,
--     b.BRAND ,
--     b.CATEGORY_NAME ,
--     b.MODEL ,
--     '',
--     '',
--     '',
--     '',
--     '',
--     CASE WHEN a.INSTALLMENT > 1 THEN 'TRUE' ELSE 'FALSE' END,
--     '',
--     CASE  WHEN  a.SAMSUNG_CARE =  1 THEN 'TRUE'  ELSE 'FALSE' END,          
--     'TRUE',
--     '',
--     CAST (a.PO_DATE AS date),
--     a.PO_HOUR,
--     a.PO_ORDERID,
--     a.PO_INTERNAL_STATUS,
--     a.PO_SKU,
--     '',
--     '',
--     '',
--     '',                   
--     '',            
--     '',      
--     '',               
--     '',
--     '',    
--     '',            
--     '',               
--     '',                         
--     '',
--     'FALSE',
--     'FALSE'
--   WHERE 1=0;
-- 
--   PERFORM TRUNCATE TABLE U_PRJ_ECOM.TMP_ECOM_HQ_ORDERS_TRADEIN_FEED;
-- 
--   PERFORM INSERT INTO U_PRJ_ECOM.TMP_ECOM_HQ_ORDERS_TRADEIN_FEED
--   SELECT DISTINCT 
--     a.COUNTRY_CD AS "country_cd",
--     a.PO_ORDERID AS "order_id",
--     a.PO_SKU  AS "line_item_id",
--     b.BRAND AS "exchange_brand",
--     b.CATEGORY_NAME AS "exchange_category",
--     b.MODEL AS "exchange_device_name",
--     '' AS "exchange_grade",
--     '' AS "exchange_id",
--     '' AS "exchange_type",
--     '' AS "is_accessory",
--     '' AS "is_financed_order",
--     CASE WHEN a.INSTALLMENT > 1 THEN 'TRUE' ELSE 'FALSE' END   AS  "is_financing",
--     '' AS "is_financing_eligible",
--     CASE  WHEN  a.SAMSUNG_CARE =  1 THEN 'TRUE'  ELSE 'FALSE' END   AS "is_samsung_care_order",          
--     'TRUE' AS "is_traded_in",
--     '' AS "is_under_extended_warranty",
--     CAST (a.PO_DATE AS date) || ' ' || a.PO_HOUR AS "order_date",
--     CAST (a.PO_DATE AS date) || ' ' || a.PO_HOUR AS "order_time_utc",
--     a.PO_ORDERID  AS "po_id",
--     a.PO_INTERNAL_STATUS  AS "po_status",
--     a.PO_SKU  AS "sku",
--     '' AS "tradein_ext_memory",
--     '' AS "tradein_ext_product_family_name",
--     '' AS "tradein_ext_product_identifier",
--     '' AS "upgrade_id",                   
--     '' AS "upgrade_loan_number",            
--     '' AS "upgrade_root_order_date",      
--     '' AS "upgrade_status",               
--     '' AS "ex_est_exch_discount_amount",
--     '' AS "ex_est_exch_value_amount",    
--     '' AS "ex_est_total_amount",            
--     '' AS "ex_identity_id",               
--     '' AS "ex_sku",                         
--     '' AS "ex_status",
--     'FALSE' as "is_upgrade",
--     'FALSE' AS "is_tariff_order",
--     SUM (b.TRADE_IN_DISCOUNT) AS "discount_amount"
--   FROM  OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE    a
--   JOIN   U_PRJ_ECOM.ODS_ECOM_HQ_ORDERS_PRODUCTS_TRADEIN b ON a.PO_ORDERID           = b."Order_Id" 
--                                                            AND a.po_sku               = b."Reference_Code" 
--                                                            AND a.CLIENT_SUBSIDIARY_ID = b.SUBSIDIARY_ID
--   WHERE a.CLIENT_SUBSIDIARY_ID  IN  (6,1)
--     AND NOT EXISTS (
--         SELECT 1
--         FROM  U_PRJ_ECOM.RAW_ECOM_HQ_ORDERS_TRADEIN_FEED aa
--         WHERE aa."order_id"     = a.PO_ORDERID 
--           AND aa."line_item_id" = a.PO_SKU 
--     )
--     AND b.IS_TRADE_IN = 'TRUE'  
--     AND a.PO_DATE >= DATE '2023-01-01'                
--   GROUP BY 
--     a.COUNTRY_CD ,
--     a.PO_ORDERID ,
--     a.PO_SKU ,
--     b.BRAND ,
--     b.CATEGORY_NAME ,
--     b.MODEL ,
--     '' ,
--     '' ,
--     '' ,
--     '' ,
--     '' ,
--     CASE WHEN a.INSTALLMENT > 1 THEN 'TRUE' ELSE 'FALSE' END,
--     '' ,
--     CASE  WHEN  a.SAMSUNG_CARE =  1 THEN 'TRUE'  ELSE 'FALSE' END ,          
--     'TRUE' ,
--     '' ,
--     CAST (a.PO_DATE AS date) ,
--     a.PO_HOUR  ,
--     a.PO_ORDERID  ,
--     a.PO_INTERNAL_STATUS  ,
--     a.PO_SKU ,
--     '' ,
--     '' ,
--     '' ,
--     '' ,                   
--     '' ,            
--     '' ,      
--     '' ,               
--     '' ,
--     '' ,    
--     '' ,            
--     '' ,               
--     '' ,                         
--     '' ,
--     'FALSE' ,
--     'FALSE'
--   ;
-- 
--   -- Ensure second staging table exists, then truncate
--   PERFORM CREATE TABLE IF NOT EXISTS U_PRJ_ECOM.TMP_ECOM_HQ_ORDERS_TRADEIN_FEED_SEND AS
--   SELECT 
--     A."country_cd",
--     A."order_id",
--     A."line_item_id",
--     A."discount_amount",
--     A."exchange_brand",
--     A."exchange_category",
--     A."exchange_device_name",
--     A."exchange_grade",
--     A."exchange_id",
--     A."exchange_type",
--     A."is_accessory",
--     A."is_financed_order",
--     A."is_financing",
--     A."is_financing_eligible",
--     A."is_samsung_care_order",
--     A."is_traded_in",
--     A."is_under_extended_warranty",
--     A."order_date",
--     TO_CHAR(TIMESTAMPADD(SECOND, -3 * 3600, CAST(A."order_time_utc" AS TIMESTAMP)), 'YYYY-MM-DD HH24:MI:SS') AS "order_time_utc",
--     A."po_id",
--     A."po_status",
--     A."sku",
--     A."tradein_ext_memory",
--     A."tradein_ext_product_family_name",
--     A."tradein_ext_product_identifier",
--     A."upgrade_id",
--     A."upgrade_loan_number",
--     A."upgrade_root_order_date",
--     A."upgrade_status",
--     A."ex_est_exch_discount_amount",
--     A."ex_est_exch_value_amount",
--     A."ex_est_total_amount",
--     A."ex_identity_id",
--     A."ex_sku",
--     A."ex_status",
--     "is_upgrade",
--     "is_tariff_order"
--   FROM  U_PRJ_ECOM.TMP_ECOM_HQ_ORDERS_TRADEIN_FEED  A
--   WHERE NOT EXISTS (
--     SELECT 1
--     FROM  U_PRJ_ECOM.RAW_ECOM_HQ_ORDERS_TRADEIN_FEED aa
--     WHERE aa."order_id"     = A."order_id"
--       AND aa."line_item_id" = A."line_item_id"
--   )
--   WHERE 1=0;
-- 
--   PERFORM TRUNCATE TABLE U_PRJ_ECOM.TMP_ECOM_HQ_ORDERS_TRADEIN_FEED_SEND;
-- 
--   PERFORM INSERT INTO U_PRJ_ECOM.TMP_ECOM_HQ_ORDERS_TRADEIN_FEED_SEND
--   SELECT DISTINCT 
--     A."country_cd",
--     A."order_id",
--     A."line_item_id",
--     A."discount_amount",
--     A."exchange_brand",
--     A."exchange_category",
--     A."exchange_device_name",
--     A."exchange_grade",
--     A."exchange_id",
--     A."exchange_type",
--     A."is_accessory",
--     A."is_financed_order",
--     A."is_financing",
--     A."is_financing_eligible",
--     A."is_samsung_care_order",
--     A."is_traded_in",
--     A."is_under_extended_warranty",
--     A."order_date",
--     TO_CHAR(TIMESTAMPADD(SECOND, -3 * 3600, CAST(A."order_time_utc" AS TIMESTAMP)), 'YYYY-MM-DD HH24:MI:SS') AS "order_time_utc",
--     A."po_id",
--     A."po_status",
--     A."sku",
--     A."tradein_ext_memory",
--     A."tradein_ext_product_family_name",
--     A."tradein_ext_product_identifier",
--     A."upgrade_id",
--     A."upgrade_loan_number",
--     A."upgrade_root_order_date",
--     A."upgrade_status",
--     A."ex_est_exch_discount_amount",
--     A."ex_est_exch_value_amount",
--     A."ex_est_total_amount",
--     A."ex_identity_id",
--     A."ex_sku",
--     A."ex_status",
--     "is_upgrade",
--     "is_tariff_order"
--   FROM  U_PRJ_ECOM.TMP_ECOM_HQ_ORDERS_TRADEIN_FEED  A
--   WHERE NOT EXISTS (
--     SELECT 1
--     FROM  U_PRJ_ECOM.RAW_ECOM_HQ_ORDERS_TRADEIN_FEED aa
--     WHERE aa."order_id"     = A."order_id"
--       AND aa."line_item_id" = A."line_item_id"
--   );
-- 
--   -- Final insert into target table
--   PERFORM INSERT INTO U_PRJ_ECOM.RAW_ECOM_HQ_ORDERS_TRADEIN_FEED (
--     "country_cd",
--     "order_id",
--     "line_item_id",
--     "discount_amount",
--     "exchange_brand",
--     "exchange_category",
--     "exchange_device_name",
--     "exchange_grade",
--     "exchange_id",
--     "exchange_type",
--     "is_accessory",
--     "is_financed_order",
--     "is_financing",
--     "is_financing_eligible",
--     "is_samsung_care_order",
--     "is_traded_in",
--     "is_under_extended_warranty",
--     "order_date",
--     "order_time_utc",
--     "po_id",
--     "po_status",
--     "sku",
--     "tradein_ext_memory",
--     "tradein_ext_product_family_name",
--     "tradein_ext_product_identifier",
--     "upgrade_id",
--     "upgrade_loan_number",
--     "upgrade_root_order_date",
--     "upgrade_status",
--     "ex_est_exch_discount_amount",
--     "ex_est_exch_value_amount",
--     "ex_est_total_amount",
--     "ex_identity_id",
--     "ex_sku",
--     "ex_status",
--     "is_upgrade",
--     "is_tariff_order",
--     LOAD_DATE,
--     LAST_UPDATE_DATE
--   )
--   SELECT DISTINCT 
--     "country_cd",
--     "order_id",
--     "line_item_id",
--     "discount_amount",
--     "exchange_brand",
--     "exchange_category",
--     "exchange_device_name",
--     "exchange_grade",
--     "exchange_id",
--     "exchange_type",
--     "is_accessory",
--     "is_financed_order",
--     "is_financing",
--     "is_financing_eligible",
--     "is_samsung_care_order",
--     "is_traded_in",
--     "is_under_extended_warranty",
--     "order_date",
--     "order_time_utc",
--     "po_id",
--     "po_status",
--     "sku",
--     "tradein_ext_memory",
--     "tradein_ext_product_family_name",
--     "tradein_ext_product_identifier",
--     "upgrade_id",
--     "upgrade_loan_number",
--     "upgrade_root_order_date",
--     "upgrade_status",
--     "ex_est_exch_discount_amount",
--     "ex_est_exch_value_amount",
--     "ex_est_total_amount",
--     "ex_identity_id",
--     "ex_sku",
--     "ex_status",
--     "is_upgrade",
--     "is_tariff_order",
--     CURRENT_TIMESTAMP AS LOAD_DATE,
--     CURRENT_TIMESTAMP AS LAST_UPDATE_DATE
--   FROM U_PRJ_ECOM.TMP_ECOM_HQ_ORDERS_TRADEIN_FEED_SEND;
-- 
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: Syntax error at or near "WHERE", Sqlstate: 42601, Position: 3011, Routine: base_yyerror, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/scan.l, Line: 1056, Error Code: 4856, 
CREATE OR REPLACE PROCEDURE U_PRJ_ECOM.PROC_RAW_ECOM_HQ_ORDERS_TRADEIN_FEED()
LANGUAGE PLvSQL AS $$
BEGIN
  
  PERFORM TRUNCATE TABLE U_PRJ_ECOM.TMP_ECOM_HQ_ORDERS_TRADEIN_FEED;
  PERFORM TRUNCATE TABLE U_PRJ_ECOM.TMP_ECOM_HQ_ORDERS_TRADEIN_FEED_SEND;

  PERFORM INSERT INTO U_PRJ_ECOM.TMP_ECOM_HQ_ORDERS_TRADEIN_FEED (
    "country_cd",
    "order_id",
    "line_item_id",
    "exchange_brand",
    "exchange_category",
    "exchange_device_name",
    "exchange_grade",
    "exchange_id",
    "exchange_type",
    "is_accessory",
    "is_financed_order",
    "is_financing",
    "is_financing_eligible",
    "is_samsung_care_order",
    "is_traded_in",
    "is_under_extended_warranty",
    "order_date",
    "order_time_utc",
    "po_id",
    "po_status",
    "sku",
    "tradein_ext_memory",
    "tradein_ext_product_family_name",
    "tradein_ext_product_identifier",
    "upgrade_id",
    "upgrade_loan_number",
    "upgrade_root_order_date",
    "upgrade_status",
    "ex_est_exch_discount_amount",
    "ex_est_value_amount",
    "ex_est_total_amount",
    "ex_identity_id",
    "ex_sku",
    "ex_status",
    "is_upgrade",
    "is_tariff_order",
    "discount_amount"
  )
  SELECT 
    a.COUNTRY_CD AS "country_cd",
    a.PO_ORDERID AS "order_id",
    a.PO_SKU  AS "line_item_id",
    b.BRAND AS "exchange_brand",
    b.CATEGORY_NAME AS "exchange_category",
    b.MODEL AS "exchange_device_name",
    '' AS "exchange_grade",
    '' AS "exchange_id",
    '' AS "exchange_type",
    '' AS "is_accessory",
    '' AS "is_financed_order",
    CASE WHEN a.INSTALLMENT > 1 THEN 'TRUE' ELSE 'FALSE' END AS  "is_financing",
    '' AS "is_financing_eligible",
    CASE  WHEN  a.SAMSUNG_CARE =  1 THEN 'TRUE'  ELSE 'FALSE' END AS "is_samsung_care_order",
    'TRUE' AS "is_traded_in",
    '' AS "is_under_extended_warranty",
    CAST (a.PO_DATE AS date) || ' ' || a.PO_HOUR AS "order_date",
    CAST (a.PO_DATE AS date) || ' ' || a.PO_HOUR AS "order_time_utc",
    a.PO_ORDERID  AS "po_id",
    a.PO_INTERNAL_STATUS  AS "po_status",
    a.PO_SKU  AS "sku",
    '' AS "tradein_ext_memory",
    '' AS "tradein_ext_product_family_name",
    '' AS "tradein_ext_product_identifier",
    '' AS "upgrade_id",                   
    '' AS "upgrade_loan_number",            
    '' AS "upgrade_root_order_date",      
    '' AS "upgrade_status",               
    '' AS "ex_est_exch_discount_amount",
    '' AS "ex_est_value_amount",    
    '' AS "ex_est_total_amount",            
    '' AS "ex_identity_id",               
    '' AS "ex_sku",                         
    '' AS "ex_status",
    'FALSE' as "is_upgrade",
    'FALSE' AS "is_tariff_order",
    SUM (b.TRADE_IN_DISCOUNT) AS "discount_amount"
  FROM  OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE    a
  JOIN   U_PRJ_ECOM.ODS_ECOM_HQ_ORDERS_PRODUCTS_TRADEIN b 
       ON a.PO_ORDERID           = b."Order_Id" 
      AND a.po_sku               = b."Reference_Code" 
      AND a.CLIENT_SUBSIDIARY_ID = b.SUBSIDIARY_ID
  WHERE a.CLIENT_SUBSIDIARY_ID  IN  (6,1)
    AND NOT EXISTS (
        SELECT 1
        FROM  U_PRJ_ECOM.RAW_ECOM_HQ_ORDERS_TRADEIN_FEED aa
        WHERE aa."order_id"     = a.PO_ORDERID 
          AND aa."line_item_id" = a.PO_SKU 
    )
    AND b.IS_TRADE_IN = 'TRUE'  
    AND a.PO_DATE >= DATE '2023-01-01'
  GROUP BY 
    a.COUNTRY_CD,
    a.PO_ORDERID,
    a.PO_SKU,
    b.BRAND,
    b.CATEGORY_NAME,
    b.MODEL,
    CASE WHEN a.INSTALLMENT > 1 THEN 'TRUE' ELSE 'FALSE' END,
    CASE WHEN a.SAMSUNG_CARE = 1 THEN 'TRUE' ELSE 'FALSE' END,
    CAST(a.PO_DATE AS date),
    a.PO_HOUR,
    a.PO_INTERNAL_STATUS;

  PERFORM INSERT INTO U_PRJ_ECOM.TMP_ECOM_HQ_ORDERS_TRADEIN_FEED_SEND (
    "country_cd",
    "order_id",
    "line_item_id",
    "discount_amount",
    "exchange_brand",
    "exchange_category",
    "exchange_device_name",
    "exchange_grade",
    "exchange_id",
    "exchange_type",
    "is_accessory",
    "is_financed_order",
    "is_financing",
    "is_financing_eligible",
    "is_samsung_care_order",
    "is_traded_in",
    "is_under_extended_warranty",
    "order_date",
    "order_time_utc",
    "po_id",
    "po_status",
    "sku",
    "tradein_ext_memory",
    "tradein_ext_product_family_name",
    "tradein_ext_product_identifier",
    "upgrade_id",
    "upgrade_loan_number",
    "upgrade_root_order_date",
    "upgrade_status",
    "ex_est_exch_discount_amount",
    "ex_est_exch_value_amount",
    "ex_est_total_amount",
    "ex_identity_id",
    "ex_sku",
    "ex_status",
    "is_upgrade",
    "is_tariff_order"
  )
  SELECT DISTINCT 
    A."country_cd",
    A."order_id",
    A."line_item_id",
    A."discount_amount",
    A."exchange_brand",
    A."exchange_category",
    A."exchange_device_name",
    A."exchange_grade",
    A."exchange_id",
    A."exchange_type",
    A."is_accessory",
    A."is_financed_order",
    A."is_financing",
    A."is_financing_eligible",
    A."is_samsung_care_order",
    A."is_traded_in",
    A."is_under_extended_warranty",
    A."order_date",
    TO_CHAR(TIMESTAMPADD(SECOND, -3 * 3600, CAST(A."order_time_utc" AS TIMESTAMP)), 'YYYY-MM-DD HH24:MI:SS') AS "order_time_utc",
    A."po_id",
    A."po_status",
    A."sku",
    A."tradein_ext_memory",
    A."tradein_ext_product_family_name",
    A."tradein_ext_product_identifier",
    A."upgrade_id",
    A."upgrade_loan_number",
    A."upgrade_root_order_date",
    A."upgrade_status",
    A."ex_est_exch_discount_amount",
    A."ex_est_exch_value_amount",
    A."ex_est_total_amount",
    A."ex_identity_id",
    A."ex_sku",
    A."ex_status",
    "is_upgrade",
    "is_tariff_order"
  FROM  U_PRJ_ECOM.TMP_ECOM_HQ_ORDERS_TRADEIN_FEED  A
  WHERE NOT EXISTS (
    SELECT 1
    FROM  U_PRJ_ECOM.RAW_ECOM_HQ_ORDERS_TRADEIN_FEED aa
    WHERE aa."order_id"     = A."order_id"
      AND aa."line_item_id" = A."line_item_id"
  );

  PERFORM INSERT INTO U_PRJ_ECOM.RAW_ECOM_HQ_ORDERS_TRADEIN_FEED (
    "country_cd",
    "order_id",
    "line_item_id",
    "discount_amount",
    "exchange_brand",
    "exchange_category",
    "exchange_device_name",
    "exchange_grade",
    "exchange_id",
    "exchange_type",
    "is_accessory",
    "is_financed_order",
    "is_financing",
    "is_financing_eligible",
    "is_samsung_care_order",
    "is_traded_in",
    "is_under_extended_warranty",
    "order_date",
    "order_time_utc",
    "po_id",
    "po_status",
    "sku",
    "tradein_ext_memory",
    "tradein_ext_product_family_name",
    "tradein_ext_product_identifier",
    "upgrade_id",
    "upgrade_loan_number",
    "upgrade_root_order_date",
    "upgrade_status",
    "ex_est_exch_discount_amount",
    "ex_est_exch_value_amount",
    "ex_est_total_amount",
    "ex_identity_id",
    "ex_sku",
    "ex_status",
    "is_upgrade",
    "is_tariff_order",
    LOAD_DATE,
    LAST_UPDATE_DATE
  )
  SELECT DISTINCT 
    "country_cd",
    "order_id",
    "line_item_id",
    "discount_amount",
    "exchange_brand",
    "exchange_category",
    "exchange_device_name",
    "exchange_grade",
    "exchange_id",
    "exchange_type",
    "is_accessory",
    "is_financed_order",
    "is_financing",
    "is_financing_eligible",
    "is_samsung_care_order",
    "is_traded_in",
    "is_under_extended_warranty",
    "order_date",
    "order_time_utc",
    "po_id",
    "po_status",
    "sku",
    "tradein_ext_memory",
    "tradein_ext_product_family_name",
    "tradein_ext_product_identifier",
    "upgrade_id",
    "upgrade_loan_number",
    "upgrade_root_order_date",
    "upgrade_status",
    "ex_est_exch_discount_amount",
    "ex_est_exch_value_amount",
    "ex_est_total_amount",
    "ex_identity_id",
    "ex_sku",
    "ex_status",
    "is_upgrade",
    "is_tariff_order",
    CURRENT_TIMESTAMP AS LOAD_DATE,
    CURRENT_TIMESTAMP AS LAST_UPDATE_DATE
  FROM U_PRJ_ECOM.TMP_ECOM_HQ_ORDERS_TRADEIN_FEED_SEND;

END;
$$;

-- CALL U_PRJ_ECOM.PROC_RAW_ECOM_HQ_ORDERS_TRADEIN_FEED();
-- ERROR: Severity: ERROR, Message: Relation "U_PRJ_ECOM.ODS_ECOM_HQ_ORDERS_PRODUCTS_TRADEIN" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_RAW_ECOM_HQ_ORDERS_TRADEIN_FEED line 7 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
-- CALL U_PRJ_ECOM.PROC_RAW_ECOM_HQ_ORDERS_TRADEIN_FEED();
-- ERROR: Severity: ERROR, Message: Relation "U_PRJ_ECOM.ODS_ECOM_HQ_ORDERS_PRODUCTS_TRADEIN" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_RAW_ECOM_HQ_ORDERS_TRADEIN_FEED line 7 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
