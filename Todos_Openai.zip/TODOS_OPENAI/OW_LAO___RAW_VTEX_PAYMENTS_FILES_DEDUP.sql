CREATE OR REPLACE PROCEDURE "OW_LAO"."RAW_VTEX_PAYMENTS_FILES_DEDUP"()
LANGUAGE PLvSQL AS $$
BEGIN
    
    PERFORM CREATE LOCAL TEMP TABLE TMP_VTX_PAYMENTS_FILES_DEDUP ON COMMIT PRESERVE ROWS AS
        SELECT id,
               file_path,
               file_name,
               ROW_NUMBER() OVER (PARTITION BY file_path ORDER BY id DESC) AS dedup
          FROM "OW_LAO"."RAW_VTEX_PAYMENTS_FILES"
         WHERE processed = false;
         
    PERFORM UPDATE "OW_LAO"."RAW_VTEX_PAYMENTS_FILES" a
       SET processed = true
      FROM TMP_VTX_PAYMENTS_FILES_DEDUP b
     WHERE b.id = a.id
       AND b.dedup != 1
       AND a.processed = false;

END;
$$;

CALL "OW_LAO"."RAW_VTEX_PAYMENTS_FILES_DEDUP"();
-- RAW_VTEX_PAYMENTS_FILES_DEDUP
-- -----------------------------
-- 0

