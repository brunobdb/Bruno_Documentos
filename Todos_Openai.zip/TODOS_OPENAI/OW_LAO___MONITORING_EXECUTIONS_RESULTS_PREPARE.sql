-- CREATE OR REPLACE PROCEDURE OW_LAO.MONITORING_EXECUTIONS_RESULTS_PREPARE(_monitoring_execution_result_status INT)
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--     SELECT a.monitoring_parameter
--          , b.monitoring_protocol_type
--          , b.value
--       FROM OW_LAO.monitoring_executions_results a
--       JOIN OW_LAO.monitoring_parameters b ON b.id = a.monitoring_parameter
--      WHERE a.monitoring_execution_result_status = _monitoring_execution_result_status
--      GROUP BY a.monitoring_parameter, b.monitoring_protocol_type, b.value;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 9.74 of source string: syntax error, unexpected ;, expecting INTO, Sqlstate: 42601, Position: 518, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
-- CREATE OR REPLACE PROCEDURE OW_LAO.MONITORING_EXECUTIONS_RESULTS_PREPARE(_monitoring_execution_result_status INT)
-- LANGUAGE PLvSQL
-- RESULT SETS 1
-- AS $$
-- BEGIN
--     SELECT a.monitoring_parameter
--          , b.monitoring_protocol_type
--          , b.value
--       FROM OW_LAO.monitoring_executions_results a
--       JOIN OW_LAO.monitoring_parameters b ON b.id = a.monitoring_parameter
--      WHERE a.monitoring_execution_result_status = _monitoring_execution_result_status
--      GROUP BY a.monitoring_parameter, b.monitoring_protocol_type, b.value;
-- END;
-- $$;
-- ERROR: Severity: ERROR, Message: Syntax error at or near "RESULT", Sqlstate: 42601, Position: 131, Routine: base_yyerror, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/scan.l, Line: 1056, Error Code: 4856, 
CREATE OR REPLACE PROCEDURE OW_LAO.MONITORING_EXECUTIONS_RESULTS_PREPARE(_monitoring_execution_result_status INT)
LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM DROP TABLE IF EXISTS TMP_MON_EXEC_RESULTS_PREPARE;

    PERFORM CREATE LOCAL TEMP TABLE TMP_MON_EXEC_RESULTS_PREPARE ON COMMIT PRESERVE ROWS AS
        SELECT a.monitoring_parameter
             , b.monitoring_protocol_type
             , b.value
          FROM OW_LAO.monitoring_executions_results a
          JOIN OW_LAO.monitoring_parameters b ON b.id = a.monitoring_parameter
         WHERE 1=0;

    PERFORM INSERT INTO TMP_MON_EXEC_RESULTS_PREPARE
        SELECT a.monitoring_parameter
             , b.monitoring_protocol_type
             , b.value
          FROM OW_LAO.monitoring_executions_results a
          JOIN OW_LAO.monitoring_parameters b ON b.id = a.monitoring_parameter
         WHERE a.monitoring_execution_result_status = _monitoring_execution_result_status
         GROUP BY a.monitoring_parameter, b.monitoring_protocol_type, b.value;
END;
$$;

CALL OW_LAO.MONITORING_EXECUTIONS_RESULTS_PREPARE(1);
-- MONITORING_EXECUTIONS_RESULTS_PREPARE
-- -------------------------------------
-- 0

