CREATE OR REPLACE PROCEDURE OW_SEDA_S.PRC_STOCK_OUT_CALCULATION(
    weeknum_ref INT,
    category_ref VARCHAR(10),
    account_ref VARCHAR(30)
)
LANGUAGE PLvSQL AS $$
BEGIN
  
  PERFORM DELETE FROM OW_SEDA_S.FT_CE_READY
  WHERE EXISTS (
    SELECT 1 FROM (
      SELECT fr.*
      FROM OW_SEDA_S.FT_CE_READY fr
      INNER JOIN OW_SEDA_S.MAP_CE_STORES ml ON ml.SITE_ID = fr.SITE_ID
      INNER JOIN OW_SEDA_S.MAP_CE_PRODUCTS mcp ON mcp.ITEM = fr.ITEM
      WHERE fr.WEEKNUM = weeknum_ref
        AND fr."PARAMETER" = 'Stock Out'
        AND mcp.CATEGORY_ITEM = category_ref
        AND ml.ACCOUNT = account_ref
    ) s
    WHERE OW_SEDA_S.FT_CE_READY.SITE_ID = s.SITE_ID
      AND OW_SEDA_S.FT_CE_READY.ITEM = s.ITEM
      AND OW_SEDA_S.FT_CE_READY.WEEKNUM = s.WEEKNUM
      AND OW_SEDA_S.FT_CE_READY."PARAMETER" = s."PARAMETER"
  );

  PERFORM MERGE INTO OW_SEDA_S."FT_CE_READY" target
  USING 
  (
    SELECT DISTINCT
      stock_out_0 AS "PARAMETER",
      "WEEKNUM",
      "SITE_ID",
      "ITEM",
      1 AS "DATA",
      'Stock Out Manual' AS "REPORT",
      current_date AS "INPUT_DATE"
    FROM
    (
      SELECT
        tb1."SITE_ID",
        tb1."ITEM",
        tb1."WEEKNUM",
        tb1."DATA",
        CASE 
          WHEN COALESCE(tb1."DATA",0) = 0 AND COALESCE(minus_one_max_week,0) = 0 THEN 'Stock Out'
          WHEN COALESCE(tb1."DATA",0) = 1 AND COALESCE(minus_one_max_week,0) = 1 
               AND (COALESCE(minus_two_max_week,0) > 1 OR COALESCE(minus_three_max_week,0) > 1 OR COALESCE(minus_four_max_week,0) > 1 OR COALESCE(minus_five_max_week,0) > 1) THEN 'Stock Out'
          ELSE ''
        END AS stock_out_0,
        CASE 
          WHEN COALESCE(minus_one_max_week,0) = 0 AND COALESCE(minus_two_max_week,0) = 0 THEN 1
          WHEN COALESCE(minus_one_max_week,0) = 1 AND COALESCE(minus_two_max_week,0) = 1 
               AND (COALESCE(minus_three_max_week,0) > 1 OR COALESCE(minus_four_max_week,0) > 1 OR COALESCE(minus_five_max_week,0) > 1 OR COALESCE(minus_six_max_week,0) > 1) THEN 1
          ELSE 0
        END +
        CASE 
          WHEN COALESCE(minus_two_max_week,0) = 0 AND COALESCE(minus_three_max_week,0) = 0 THEN 1
          WHEN COALESCE(minus_two_max_week,0) = 1 AND COALESCE(minus_three_max_week,0) = 1 
               AND (COALESCE(minus_four_max_week,0) > 1 OR COALESCE(minus_five_max_week,0) > 1 OR COALESCE(minus_six_max_week,0) > 1 OR COALESCE(minus_seven_max_week,0) > 1) THEN 1
          ELSE 0
        END +
        CASE 
          WHEN COALESCE(minus_three_max_week,0) = 0 AND COALESCE(minus_four_max_week,0) = 0 THEN 1
          WHEN COALESCE(minus_three_max_week,0) = 1 AND COALESCE(minus_four_max_week,0) = 1 
               AND (COALESCE(minus_five_max_week,0) > 1 OR COALESCE(minus_six_max_week,0) > 1 OR COALESCE(minus_seven_max_week,0) > 1 OR COALESCE(minus_eight_max_week,0) > 1) THEN 1
          ELSE 0
        END +
        CASE 
          WHEN COALESCE(minus_four_max_week,0) = 0 AND COALESCE(minus_five_max_week,0) = 0 THEN 1
          WHEN COALESCE(minus_four_max_week,0) = 1 AND COALESCE(minus_five_max_week,0) = 1 
               AND (COALESCE(minus_six_max_week,0) > 1 OR COALESCE(minus_seven_max_week,0) > 1 OR COALESCE(minus_eight_max_week,0) > 1) THEN 1
          ELSE 0
        END AS stock_out_count
      FROM 
      (
        SELECT 
          "PARAMETER",
          weeknum_ref AS WEEKNUM,
          SITE_ID,
          ITEM,
          SUM(CASE WHEN WEEKNUM = weeknum_ref THEN "DATA" ELSE 0 END) AS "DATA",
          MIN(REPORT) AS REPORT
        FROM OW_SEDA_S.FT_CE_READY fr 
        INNER JOIN 
          (
            SELECT
              LAG(YEARWEEK, 1) OVER (ORDER BY YEARWEEK) AS weeknum_lag_1,
              LAG(YEARWEEK, 2) OVER (ORDER BY YEARWEEK) AS weeknum_lag_2,
              LAG(YEARWEEK, 3) OVER (ORDER BY YEARWEEK) AS weeknum_lag_3,
              LAG(YEARWEEK, 4) OVER (ORDER BY YEARWEEK) AS weeknum_lag_4,
              LAG(YEARWEEK, 5) OVER (ORDER BY YEARWEEK) AS weeknum_lag_5,
              LAG(YEARWEEK, 6) OVER (ORDER BY YEARWEEK) AS weeknum_lag_6,
              LAG(YEARWEEK, 7) OVER (ORDER BY YEARWEEK) AS weeknum_lag_7,
              LAG(YEARWEEK, 8) OVER (ORDER BY YEARWEEK) AS weeknum_lag_8,
              YEARWEEK
            FROM OW_SEDA_S."MAP_CE_CALENDAR" mc 
            WHERE "YEAR" BETWEEN 2024 AND 2025
          ) tb2 ON weeknum_ref = tb2."YEARWEEK"
        WHERE 
          fr."PARAMETER" = 'Inventory'
          AND fr.WEEKNUM BETWEEN weeknum_lag_4 AND weeknum_ref
        GROUP BY 
          "PARAMETER",
          SITE_ID,
          ITEM
      ) tb1
      INNER JOIN 
        (
          SELECT
            LAG(YEARWEEK, 1) OVER (ORDER BY YEARWEEK) AS weeknum_lag_1,
            LAG(YEARWEEK, 2) OVER (ORDER BY YEARWEEK) AS weeknum_lag_2,
            LAG(YEARWEEK, 3) OVER (ORDER BY YEARWEEK) AS weeknum_lag_3,
            LAG(YEARWEEK, 4) OVER (ORDER BY YEARWEEK) AS weeknum_lag_4,
            LAG(YEARWEEK, 5) OVER (ORDER BY YEARWEEK) AS weeknum_lag_5,
            LAG(YEARWEEK, 6) OVER (ORDER BY YEARWEEK) AS weeknum_lag_6,
            LAG(YEARWEEK, 7) OVER (ORDER BY YEARWEEK) AS weeknum_lag_7,
            LAG(YEARWEEK, 8) OVER (ORDER BY YEARWEEK) AS weeknum_lag_8,
            YEARWEEK
          FROM OW_SEDA_S."MAP_CE_CALENDAR" mc 
          WHERE "YEAR" BETWEEN 2024 AND 2025
        ) tb2 ON weeknum_ref = tb2."YEARWEEK"
      INNER JOIN OW_SEDA_S."MAP_CE_STORES" tb3 ON tb1."SITE_ID" = tb3."SITE_ID"
      INNER JOIN OW_SEDA_S."MAP_CE_PRODUCTS" tb4 ON tb1."ITEM" = tb4."ITEM"
      LEFT JOIN (
        SELECT "SITE_ID", "ITEM", "WEEKNUM" AS minus_one_week_inventory, "DATA" AS minus_one_max_week 
        FROM OW_SEDA_S."FT_CE_READY"
        WHERE "PARAMETER" = 'Inventory'
      ) tb_minus_one
        ON tb1."SITE_ID" = tb_minus_one."SITE_ID"
       AND tb1."ITEM" = tb_minus_one."ITEM"
       AND tb2.weeknum_lag_1 = tb_minus_one.minus_one_week_inventory
      LEFT JOIN (
        SELECT "SITE_ID", "ITEM", "WEEKNUM" AS minus_two_week_inventory, "DATA" AS minus_two_max_week 
        FROM OW_SEDA_S."FT_CE_READY"
        WHERE "PARAMETER" = 'Inventory'
      ) tb_minus_two
        ON tb1."SITE_ID" = tb_minus_two."SITE_ID"
       AND tb1."ITEM" = tb_minus_two."ITEM"
       AND tb2.weeknum_lag_2 = tb_minus_two.minus_two_week_inventory
      LEFT JOIN (
        SELECT "SITE_ID", "ITEM", "WEEKNUM" AS minus_three_week_inventory, "DATA" AS minus_three_max_week 
        FROM OW_SEDA_S."FT_CE_READY"
        WHERE "PARAMETER" = 'Inventory'
      ) tb_minus_three
        ON tb1."SITE_ID" = tb_minus_three."SITE_ID"
       AND tb1."ITEM" = tb_minus_three."ITEM"
       AND tb2.weeknum_lag_3 = tb_minus_three.minus_three_week_inventory
      LEFT JOIN (
        SELECT "SITE_ID", "ITEM", "WEEKNUM" AS minus_four_week_inventory, "DATA" AS minus_four_max_week 
        FROM OW_SEDA_S."FT_CE_READY"
        WHERE "PARAMETER" = 'Inventory'
      ) tb_minus_four
        ON tb1."SITE_ID" = tb_minus_four."SITE_ID"
       AND tb1."ITEM" = tb_minus_four."ITEM"
       AND tb2.weeknum_lag_4 = tb_minus_four.minus_four_week_inventory
      LEFT JOIN (
        SELECT "SITE_ID", "ITEM", "WEEKNUM" AS minus_five_week_inventory, "DATA" AS minus_five_max_week 
        FROM OW_SEDA_S."FT_CE_READY"
        WHERE "PARAMETER" = 'Inventory'
      ) tb_minus_five
        ON tb1."SITE_ID" = tb_minus_five."SITE_ID"
       AND tb1."ITEM" = tb_minus_five."ITEM"
       AND tb2.weeknum_lag_5 = tb_minus_five.minus_five_week_inventory
      LEFT JOIN (
        SELECT "SITE_ID", "ITEM", "WEEKNUM" AS minus_six_week_inventory, "DATA" AS minus_six_max_week 
        FROM OW_SEDA_S."FT_CE_READY"
        WHERE "PARAMETER" = 'Inventory'
      ) tb_minus_six
        ON tb1."SITE_ID" = tb_minus_six."SITE_ID"
       AND tb1."ITEM" = tb_minus_six."ITEM"
       AND tb2.weeknum_lag_6 = tb_minus_six.minus_six_week_inventory
      LEFT JOIN (
        SELECT "SITE_ID", "ITEM", "WEEKNUM" AS minus_seven_week_inventory, "DATA" AS minus_seven_max_week 
        FROM OW_SEDA_S."FT_CE_READY"
        WHERE "PARAMETER" = 'Inventory'
      ) tb_minus_seven
        ON tb1."SITE_ID" = tb_minus_seven."SITE_ID"
       AND tb1."ITEM" = tb_minus_seven."ITEM"
       AND tb2.weeknum_lag_7 = tb_minus_seven.minus_seven_week_inventory
      LEFT JOIN (
        SELECT "SITE_ID", "ITEM", "WEEKNUM" AS minus_eight_week_inventory, "DATA" AS minus_eight_max_week 
        FROM OW_SEDA_S."FT_CE_READY"
        WHERE "PARAMETER" = 'Inventory'
      ) tb_minus_eight
        ON tb1."SITE_ID" = tb_minus_eight."SITE_ID"
       AND tb1."ITEM" = tb_minus_eight."ITEM"
       AND tb2.weeknum_lag_8 = tb_minus_eight.minus_eight_week_inventory
      WHERE 
        tb1."WEEKNUM" = weeknum_ref AND
        tb1."PARAMETER" = 'Inventory' AND
        tb3."STORE_TYPE" = 'Reg. Stores' AND 
        tb1."DATA" IN (0, 1) AND
        tb3."ACCOUNT" = account_ref AND
        tb4."CATEGORY_ITEM" = category_ref
    ) tb_stock_out
    WHERE stock_out_0 = 'Stock Out' 
      AND stock_out_count <= 4
  ) source
  ON
    source."PARAMETER" = target."PARAMETER" AND
    source."WEEKNUM"   = target."WEEKNUM"   AND
    source."SITE_ID"   = target."SITE_ID"   AND
    source."ITEM"      = target."ITEM" 
  WHEN MATCHED THEN UPDATE SET target."DATA" = source."DATA", target."REPORT" = source."REPORT", target."INPUT_DATE" = source."INPUT_DATE"
  WHEN NOT MATCHED THEN INSERT VALUES(source."PARAMETER", source."WEEKNUM", source."SITE_ID", source."ITEM", source."DATA", source."REPORT", source."INPUT_DATE");

END;
$$;

-- CALL OW_SEDA_S.PRC_STOCK_OUT_CALCULATION(202401, 'TV', 'MAGAZINE LUIZA');
-- ERROR: Severity: ERROR, Message: Either column "target" does not exist or table alias "target" is not allowed in "WHEN MATCHED THEN UPDATE SET", Sqlstate: 42602, Hint: Either fix the column name "target" or remove table alias "target" from all column names in "WHEN MATCHED THEN UPDATE SET", Where: PL/vSQL procedure PRC_STOCK_OUT_CALCULATION line 22 at static SQL, Routine: transformVMergeStmt, File: analyze.c, Line: 3541, Error Code: 5569, 
CREATE OR REPLACE PROCEDURE OW_SEDA_S.PRC_STOCK_OUT_CALCULATION(
    weeknum_ref INT,
    category_ref VARCHAR(10),
    account_ref VARCHAR(30)
)
LANGUAGE PLvSQL AS $$
BEGIN
  
  PERFORM DELETE FROM OW_SEDA_S.FT_CE_READY
  WHERE EXISTS (
    SELECT 1 FROM (
      SELECT fr.*
      FROM OW_SEDA_S.FT_CE_READY fr
      INNER JOIN OW_SEDA_S.MAP_CE_STORES ml ON ml.SITE_ID = fr.SITE_ID
      INNER JOIN OW_SEDA_S.MAP_CE_PRODUCTS mcp ON mcp.ITEM = fr.ITEM
      WHERE fr.WEEKNUM = weeknum_ref
        AND fr."PARAMETER" = 'Stock Out'
        AND mcp.CATEGORY_ITEM = category_ref
        AND ml.ACCOUNT = account_ref
    ) s
    WHERE OW_SEDA_S.FT_CE_READY.SITE_ID = s.SITE_ID
      AND OW_SEDA_S.FT_CE_READY.ITEM = s.ITEM
      AND OW_SEDA_S.FT_CE_READY.WEEKNUM = s.WEEKNUM
      AND OW_SEDA_S.FT_CE_READY."PARAMETER" = s."PARAMETER"
  );

  PERFORM MERGE INTO OW_SEDA_S."FT_CE_READY" target
  USING 
  (
    SELECT DISTINCT
      stock_out_0 AS "PARAMETER",
      "WEEKNUM",
      "SITE_ID",
      "ITEM",
      1 AS "DATA",
      'Stock Out Manual' AS "REPORT",
      CURRENT_DATE AS "INPUT_DATE"
    FROM
    (
      SELECT
        tb1."SITE_ID",
        tb1."ITEM",
        tb1."WEEKNUM",
        tb1."DATA",
        CASE 
          WHEN COALESCE(tb1."DATA",0) = 0 AND COALESCE(minus_one_max_week,0) = 0 THEN 'Stock Out'
          WHEN COALESCE(tb1."DATA",0) = 1 AND COALESCE(minus_one_max_week,0) = 1 
               AND (COALESCE(minus_two_max_week,0) > 1 OR COALESCE(minus_three_max_week,0) > 1 OR COALESCE(minus_four_max_week,0) > 1 OR COALESCE(minus_five_max_week,0) > 1) THEN 'Stock Out'
          ELSE ''
        END AS stock_out_0,
        CASE 
          WHEN COALESCE(minus_one_max_week,0) = 0 AND COALESCE(minus_two_max_week,0) = 0 THEN 1
          WHEN COALESCE(minus_one_max_week,0) = 1 AND COALESCE(minus_two_max_week,0) = 1 
               AND (COALESCE(minus_three_max_week,0) > 1 OR COALESCE(minus_four_max_week,0) > 1 OR COALESCE(minus_five_max_week,0) > 1 OR COALESCE(minus_six_max_week,0) > 1) THEN 1
          ELSE 0
        END +
        CASE 
          WHEN COALESCE(minus_two_max_week,0) = 0 AND COALESCE(minus_three_max_week,0) = 0 THEN 1
          WHEN COALESCE(minus_two_max_week,0) = 1 AND COALESCE(minus_three_max_week,0) = 1 
               AND (COALESCE(minus_four_max_week,0) > 1 OR COALESCE(minus_five_max_week,0) > 1 OR COALESCE(minus_six_max_week,0) > 1 OR COALESCE(minus_seven_max_week,0) > 1) THEN 1
          ELSE 0
        END +
        CASE 
          WHEN COALESCE(minus_three_max_week,0) = 0 AND COALESCE(minus_four_max_week,0) = 0 THEN 1
          WHEN COALESCE(minus_three_max_week,0) = 1 AND COALESCE(minus_four_max_week,0) = 1 
               AND (COALESCE(minus_five_max_week,0) > 1 OR COALESCE(minus_six_max_week,0) > 1 OR COALESCE(minus_seven_max_week,0) > 1 OR COALESCE(minus_eight_max_week,0) > 1) THEN 1
          ELSE 0
        END +
        CASE 
          WHEN COALESCE(minus_four_max_week,0) = 0 AND COALESCE(minus_five_max_week,0) = 0 THEN 1
          WHEN COALESCE(minus_four_max_week,0) = 1 AND COALESCE(minus_five_max_week,0) = 1 
               AND (COALESCE(minus_six_max_week,0) > 1 OR COALESCE(minus_seven_max_week,0) > 1 OR COALESCE(minus_eight_max_week,0) > 1) THEN 1
          ELSE 0
        END AS stock_out_count
      FROM 
      (
        SELECT 
          "PARAMETER",
          weeknum_ref AS WEEKNUM,
          SITE_ID,
          ITEM,
          SUM(CASE WHEN WEEKNUM = weeknum_ref THEN "DATA" ELSE 0 END) AS "DATA",
          MIN(REPORT) AS REPORT
        FROM OW_SEDA_S.FT_CE_READY fr 
        INNER JOIN 
          (
            SELECT
              LAG(YEARWEEK, 1) OVER (ORDER BY YEARWEEK) AS weeknum_lag_1,
              LAG(YEARWEEK, 2) OVER (ORDER BY YEARWEEK) AS weeknum_lag_2,
              LAG(YEARWEEK, 3) OVER (ORDER BY YEARWEEK) AS weeknum_lag_3,
              LAG(YEARWEEK, 4) OVER (ORDER BY YEARWEEK) AS weeknum_lag_4,
              LAG(YEARWEEK, 5) OVER (ORDER BY YEARWEEK) AS weeknum_lag_5,
              LAG(YEARWEEK, 6) OVER (ORDER BY YEARWEEK) AS weeknum_lag_6,
              LAG(YEARWEEK, 7) OVER (ORDER BY YEARWEEK) AS weeknum_lag_7,
              LAG(YEARWEEK, 8) OVER (ORDER BY YEARWEEK) AS weeknum_lag_8,
              YEARWEEK
            FROM OW_SEDA_S."MAP_CE_CALENDAR" mc 
            WHERE "YEAR" BETWEEN 2024 AND 2025
          ) tb2 ON weeknum_ref = tb2."YEARWEEK"
        WHERE 
          fr."PARAMETER" = 'Inventory'
          AND fr.WEEKNUM BETWEEN weeknum_lag_4 AND weeknum_ref
        GROUP BY 
          "PARAMETER",
          SITE_ID,
          ITEM
      ) tb1
      INNER JOIN 
        (
          SELECT
            LAG(YEARWEEK, 1) OVER (ORDER BY YEARWEEK) AS weeknum_lag_1,
            LAG(YEARWEEK, 2) OVER (ORDER BY YEARWEEK) AS weeknum_lag_2,
            LAG(YEARWEEK, 3) OVER (ORDER BY YEARWEEK) AS weeknum_lag_3,
            LAG(YEARWEEK, 4) OVER (ORDER BY YEARWEEK) AS weeknum_lag_4,
            LAG(YEARWEEK, 5) OVER (ORDER BY YEARWEEK) AS weeknum_lag_5,
            LAG(YEARWEEK, 6) OVER (ORDER BY YEARWEEK) AS weeknum_lag_6,
            LAG(YEARWEEK, 7) OVER (ORDER BY YEARWEEK) AS weeknum_lag_7,
            LAG(YEARWEEK, 8) OVER (ORDER BY YEARWEEK) AS weeknum_lag_8,
            YEARWEEK
          FROM OW_SEDA_S."MAP_CE_CALENDAR" mc 
          WHERE "YEAR" BETWEEN 2024 AND 2025
        ) tb2 ON weeknum_ref = tb2."YEARWEEK"
      INNER JOIN OW_SEDA_S."MAP_CE_STORES" tb3 ON tb1."SITE_ID" = tb3."SITE_ID"
      INNER JOIN OW_SEDA_S."MAP_CE_PRODUCTS" tb4 ON tb1."ITEM" = tb4."ITEM"
      LEFT JOIN (
        SELECT "SITE_ID", "ITEM", "WEEKNUM" AS minus_one_week_inventory, "DATA" AS minus_one_max_week 
        FROM OW_SEDA_S."FT_CE_READY"
        WHERE "PARAMETER" = 'Inventory'
      ) tb_minus_one
        ON tb1."SITE_ID" = tb_minus_one."SITE_ID"
       AND tb1."ITEM" = tb_minus_one."ITEM"
       AND tb2.weeknum_lag_1 = tb_minus_one.minus_one_week_inventory
      LEFT JOIN (
        SELECT "SITE_ID", "ITEM", "WEEKNUM" AS minus_two_week_inventory, "DATA" AS minus_two_max_week 
        FROM OW_SEDA_S."FT_CE_READY"
        WHERE "PARAMETER" = 'Inventory'
      ) tb_minus_two
        ON tb1."SITE_ID" = tb_minus_two."SITE_ID"
       AND tb1."ITEM" = tb_minus_two."ITEM"
       AND tb2.weeknum_lag_2 = tb_minus_two.minus_two_week_inventory
      LEFT JOIN (
        SELECT "SITE_ID", "ITEM", "WEEKNUM" AS minus_three_week_inventory, "DATA" AS minus_three_max_week 
        FROM OW_SEDA_S."FT_CE_READY"
        WHERE "PARAMETER" = 'Inventory'
      ) tb_minus_three
        ON tb1."SITE_ID" = tb_minus_three."SITE_ID"
       AND tb1."ITEM" = tb_minus_three."ITEM"
       AND tb2.weeknum_lag_3 = tb_minus_three.minus_three_week_inventory
      LEFT JOIN (
        SELECT "SITE_ID", "ITEM", "WEEKNUM" AS minus_four_week_inventory, "DATA" AS minus_four_max_week 
        FROM OW_SEDA_S."FT_CE_READY"
        WHERE "PARAMETER" = 'Inventory'
      ) tb_minus_four
        ON tb1."SITE_ID" = tb_minus_four."SITE_ID"
       AND tb1."ITEM" = tb_minus_four."ITEM"
       AND tb2.weeknum_lag_4 = tb_minus_four.minus_four_week_inventory
      LEFT JOIN (
        SELECT "SITE_ID", "ITEM", "WEEKNUM" AS minus_five_week_inventory, "DATA" AS minus_five_max_week 
        FROM OW_SEDA_S."FT_CE_READY"
        WHERE "PARAMETER" = 'Inventory'
      ) tb_minus_five
        ON tb1."SITE_ID" = tb_minus_five."SITE_ID"
       AND tb1."ITEM" = tb_minus_five."ITEM"
       AND tb2.weeknum_lag_5 = tb_minus_five.minus_five_week_inventory
      LEFT JOIN (
        SELECT "SITE_ID", "ITEM", "WEEKNUM" AS minus_six_week_inventory, "DATA" AS minus_six_max_week 
        FROM OW_SEDA_S."FT_CE_READY"
        WHERE "PARAMETER" = 'Inventory'
      ) tb_minus_six
        ON tb1."SITE_ID" = tb_minus_six."SITE_ID"
       AND tb1."ITEM" = tb_minus_six."ITEM"
       AND tb2.weeknum_lag_6 = tb_minus_six.minus_six_week_inventory
      LEFT JOIN (
        SELECT "SITE_ID", "ITEM", "WEEKNUM" AS minus_seven_week_inventory, "DATA" AS minus_seven_max_week 
        FROM OW_SEDA_S."FT_CE_READY"
        WHERE "PARAMETER" = 'Inventory'
      ) tb_minus_seven
        ON tb1."SITE_ID" = tb_minus_seven."SITE_ID"
       AND tb1."ITEM" = tb_minus_seven."ITEM"
       AND tb2.weeknum_lag_7 = tb_minus_seven.minus_seven_week_inventory
      LEFT JOIN (
        SELECT "SITE_ID", "ITEM", "WEEKNUM" AS minus_eight_week_inventory, "DATA" AS minus_eight_max_week 
        FROM OW_SEDA_S."FT_CE_READY"
        WHERE "PARAMETER" = 'Inventory'
      ) tb_minus_eight
        ON tb1."SITE_ID" = tb_minus_eight."SITE_ID"
       AND tb1."ITEM" = tb_minus_eight."ITEM"
       AND tb2.weeknum_lag_8 = tb_minus_eight.minus_eight_week_inventory
      WHERE 
        tb1."WEEKNUM" = weeknum_ref AND
        tb1."PARAMETER" = 'Inventory' AND
        tb3."STORE_TYPE" = 'Reg. Stores' AND 
        tb1."DATA" IN (0, 1) AND
        tb3."ACCOUNT" = account_ref AND
        tb4."CATEGORY_ITEM" = category_ref
    ) tb_stock_out
    WHERE stock_out_0 = 'Stock Out' 
      AND stock_out_count <= 4
  ) source
  ON
    source."PARAMETER" = target."PARAMETER" AND
    source."WEEKNUM"   = target."WEEKNUM"   AND
    source."SITE_ID"   = target."SITE_ID"   AND
    source."ITEM"      = target."ITEM" 
  WHEN MATCHED THEN UPDATE SET "DATA" = source."DATA", "REPORT" = source."REPORT", "INPUT_DATE" = source."INPUT_DATE"
  WHEN NOT MATCHED THEN INSERT ("PARAMETER","WEEKNUM","SITE_ID","ITEM","DATA","REPORT","INPUT_DATE")
    VALUES(source."PARAMETER", source."WEEKNUM", source."SITE_ID", source."ITEM", source."DATA", source."REPORT", source."INPUT_DATE");

END;
$$;

CALL OW_SEDA_S.PRC_STOCK_OUT_CALCULATION(202401, 'TV', 'MAGAZINE LUIZA');
-- PRC_STOCK_OUT_CALCULATION
-- -------------------------
-- 0

