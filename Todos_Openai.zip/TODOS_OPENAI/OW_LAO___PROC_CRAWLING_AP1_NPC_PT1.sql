CREATE OR REPLACE PROCEDURE PROC_CRAWLING_AP1_NPC_PT1()
LANGUAGE PLvSQL AS $$
BEGIN
  -- TRUNCA A TABELA FATO TF_CRAWLING_AP1_NPC_1
  PERFORM TRUNCATE TABLE TF_CRAWLING_AP1_NPC_1;

  PERFORM INSERT INTO TF_CRAWLING_AP1_NPC_1
  SELECT DISTINCT
    TRIM(UPPER(SUBSTR(D."PROD_BRAND",1,99))) AS "brand_nm",
    SUBSTR(D."MODEL",1,99) AS "model_nm",
    SUBSTR(D."DESC",1,99) AS "model_desc",
    SUBSTR(P."SUB",1,99) AS "subsidiary",
    SUBSTR(D."COUNTRY",1,99) AS "country",
    SUBSTR(D."COUNTRY",1,99) AS "country_code",
    SUBSTR(D."COMPANY_NAME",1,99) AS "site_company_name",
    D."VENDOR" AS "vendor",
    SUBSTR(P."SITE",1,99) AS "site_nm",
    SUBSTR(D."PROD_HREF",1,499) AS "site_url",
    SUBSTR(P."PAGE_NUMBER",1,99) AS "site_page",
    SUBSTR(P."POSITION",1,99) AS "site_position",
    SUBSTR(D."CURRENCY",1,99) AS "site_price_currency",
    SUBSTR(DT."RATING",1,99) AS "site_rating",
    SUBSTR(DT."RATING_AMOUNT",1,99) AS "site_rating_amount",
    SUBSTR(DT."RATING_SCALE",1,99) AS "site_rating_scale",
    SUBSTR(P."TODAY_DATE_TIME",1,99) AS "refer_date",
    SUBSTR(P."POR_VALUE",1,16) AS "price_unit",
    SUBSTR(D."MODEL2",1,99) AS MODEL2,
    SUBSTR(D."REF",1,99) AS REF,
    SUBSTR(D."REF2",1,99) AS REF2,
    SUBSTR(P."DE_VALUE",1,16) AS "retail_price_base",
    SUBSTR(P."POR_VALUE",1,16) AS "retail_price_actual",
    SUBSTR(P."TODAY_DATE_TIME",1,99) AS "crawling_date",
    SUBSTR(P.AVAILABLE,1,99) AS "product_available",
    NULL AS "process_status",
    NULL AS "comment_status",
    SUBSTR(D.LAST_UPDATE,1,99) AS "product_update_date",
    CURRENT_TIMESTAMP AS process_datetime,
    P.INITIAL_URL AS "initial_url"
  FROM OW_LAO."ODS_CRAWLING_AP1_IM_PRODUCT_DAILY_PRICE" P		
  INNER JOIN OW_LAO.ODS_CRAWLING_AP1_NPC_PRODUCT_DETAIL D
    ON P."KEY" = D."KEY"
  INNER JOIN "ODS_CRAWLING_AP1_NPC_PRODUCT_DETAIL_DAILY" DT
    ON P."KEY" = DT."KEY" AND TO_CHAR(P."TODAY_DATE_TIME", 'YYYY-MM-DD') = TO_CHAR(DT."LOAD_DATE", 'YYYY-MM-DD')
  WHERE 1=1
    AND P."TODAY_DATE_TIME" > '2020-06-27 00:00'
    AND TO_CHAR(P."TODAY_DATE_TIME", 'YYYY-MM-DD')  < TO_CHAR(CURRENT_DATE, 'YYYY-MM-DD')
    AND UPPER(TRIM(PRODUCT_TYPE)) = 'NPC';

  -- se model_nm está vazio ou nulo, inclui parte do site_url no lugar.
  PERFORM UPDATE TF_CRAWLING_AP1_NPC_1
  SET 
    "model_nm" = CASE WHEN TRIM("model_nm") = '' OR TRIM("model_nm") IS NULL 
              THEN SUBSTR(REPLACE(TRIM("site_url"), TRIM("site_nm"), ''), 1, 99)
              ELSE TRIM("model_nm") END;

  -- caso os campos de rating estão nulos colocamos vazio para mapear na query final da pt2
  PERFORM UPDATE TF_CRAWLING_AP1_NPC_1
  SET
    "site_rating" = COALESCE("site_rating", ''),
    "site_rating_amount" = COALESCE("site_rating_amount", ''),
    "site_rating_scale" = COALESCE("site_rating_scale", '');

  PERFORM UPDATE TF_CRAWLING_AP1_NPC_1
  SET
    "site_rating" = REGEXP_SUBSTR(UPPER(TRIM(REPLACE("site_rating", ',', '.'))), '[0-9]+([.][0-9]{1,2})?', 1, 1),
    "site_rating_amount" = REGEXP_SUBSTR(UPPER(TRIM("site_rating_amount")), '[0-9]+([.][0-9]{1,2})?', 1, 1), 
    "site_rating_scale" = REGEXP_SUBSTR(UPPER(TRIM("site_rating_scale")), '[0-9]+([.][0-9]{1,2})?', 1, 1), 
    "price_unit" = REGEXP_SUBSTR(UPPER(TRIM("price_unit")), '[0-9]+([.][0-9]{1,2})?', 1, 1), 
    "retail_price_base" = REGEXP_SUBSTR(UPPER(TRIM("retail_price_base")), '[0-9]+([.][0-9]{1,2})?', 1, 1), 
    "retail_price_actual" = REGEXP_SUBSTR(UPPER(TRIM("retail_price_actual")), '[0-9]+([.][0-9]{1,2})?', 1, 1);

  -- TRUNCA A TABELA FATO TF_CRAWLING_AP1_NPC_2
  PERFORM TRUNCATE TABLE TF_CRAWLING_AP1_NPC_2;

  PERFORM INSERT INTO TF_CRAWLING_AP1_NPC_2
  SELECT
    UPPER(TRIM(INITCAP("brand_nm"))) AS "brand_nm",
    ' ' as "mktcode",
    ' ' as "mktname",
    "model_nm" as "model_nm",
    "subsidiary",
    "country",
    "country_code",
    UPPER(TRIM("site_company_name")) AS "site_company_name",
    "vendor",
    "site_nm",
    "site_url",
    "site_page",
    "site_position",
    "site_price_currency",
    CASE WHEN TRIM("site_rating") = '' THEN NULL ELSE TO_DECIMAL("site_rating", 8, 1) END AS "site_rating", 
    CASE WHEN TRIM("site_rating_amount") = '' THEN NULL ELSE TO_DECIMAL("site_rating_amount", 8, 0) END AS "site_rating_amount", 
    CASE WHEN TRIM("site_rating_scale") = '' THEN NULL ELSE TO_DECIMAL("site_rating_scale", 8, 0) END AS "site_rating_scale",
    TO_TIMESTAMP("refer_date", 'YYYY-MM-DD HH24:MI') AS "refer_date",
    ROUND(MAX("retail_price_actual"), 2) AS "price_unit",
    ROUND(MAX("retail_price_base"), 2) AS "price_local_base",
    ROUND(MAX("retail_price_actual"), 2) AS "price_local_act",
    'Y' AS "update_flg",
    CURRENT_TIMESTAMP,
    "initial_url"
  FROM TF_CRAWLING_AP1_NPC_1
  WHERE "process_status" IS NULL
  GROUP BY 
    UPPER(TRIM(INITCAP("brand_nm"))),
    "model_nm",
    "subsidiary",
    "country",
    "country_code",
    UPPER(TRIM("site_company_name")),
    "vendor",
    "site_nm",
    "site_url",
    "site_page",
    "site_position",
    "site_price_currency",
    CASE WHEN TRIM("site_rating") = '' THEN NULL ELSE TO_DECIMAL("site_rating", 8, 1) END, 
    CASE WHEN TRIM("site_rating_amount") = '' THEN NULL ELSE TO_DECIMAL("site_rating_amount", 8, 0) END, 
    CASE WHEN TRIM("site_rating_scale") = '' THEN NULL ELSE TO_DECIMAL("site_rating_scale", 8, 0) END,
    TO_TIMESTAMP("refer_date", 'YYYY-MM-DD HH24:MI'),
    "initial_url";

  --POPULAR A TABELA DE INPUT E REALIZAR O MAPEAMENTO AUTOMÁTICO
  PERFORM CALL PROC_CRAWLING_AP1_NPC_SITE_MAPPING_MERGE_AUTOMATIC();

  -- Trunca a Tabela fato FT_CRAWLING_AP1_NPC_SEGMENT
  PERFORM TRUNCATE TABLE FT_CRAWLING_AP1_NPC_SEGMENT;

  -- Insere dados na tabela fato FT_CRAWLING_AP1_NPC_SEGMENT a partir da View VW_CRAWLING_AP1_NPC_SEGMENT
  PERFORM INSERT INTO FT_CRAWLING_AP1_NPC_SEGMENT
  SELECT *, NULL AS REFER_WEEK,
         NULL AS REFER_WEEK_T,
         NULL AS REFER_YEAR,
         NULL AS MODEL_DESC
  FROM VW_CRAWLING_AP1_NPC_SEGMENT;

  -- Update da Base Segment para carregar o Model Desc
  PERFORM UPDATE OW_LAO.FT_CRAWLING_AP1_NPC_SEGMENT O
  SET "MODEL_DESC" = T."DESC"
  FROM OW_LAO.ODS_CRAWLING_AP1_NPC_PRODUCT_DETAIL T
  WHERE TRIM(O.SITE_URL) = TRIM(T.PROD_HREF);

  PERFORM UPDATE OW_LAO.FT_CRAWLING_AP1_NPC_SEGMENT F
  SET
    REFER_WEEK   = (SELECT YYYYWW FROM OW_MD.DIM_CALENDAR D WHERE TO_CHAR(F.REFER_DATE,'YYYY-MM-DD') = TO_CHAR(D.YYYYMMDD,'YYYY-MM-DD') LIMIT 1),
    REFER_WEEK_T = (SELECT 'W' || RIGHT(YYYYWW,2) FROM OW_MD.DIM_CALENDAR D WHERE TO_CHAR(F.REFER_DATE,'YYYY-MM-DD') = TO_CHAR(D.YYYYMMDD,'YYYY-MM-DD') LIMIT 1),
    REFER_YEAR   = (SELECT YYYY FROM OW_MD.DIM_CALENDAR D WHERE TO_CHAR(F.REFER_DATE,'YYYY-MM-DD') = TO_CHAR(D.YYYYMMDD,'YYYY-MM-DD') LIMIT 1)
  WHERE REFER_WEEK IS NULL;
END;
$$;

-- CALL PROC_CRAWLING_AP1_NPC_PT1();
-- ERROR: Severity: ROLLBACK, Message: Table "TF_CRAWLING_AP1_NPC_1" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_CRAWLING_AP1_NPC_PT1 line 4 at static SQL, Routine: TruncateTable, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Commands/DDL.cpp, Line: 20681, Error Code: 4876, 
-- CALL PROC_CRAWLING_AP1_NPC_PT1();
-- ERROR: Severity: ROLLBACK, Message: Table "TF_CRAWLING_AP1_NPC_1" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_CRAWLING_AP1_NPC_PT1 line 4 at static SQL, Routine: TruncateTable, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Commands/DDL.cpp, Line: 20681, Error Code: 4876, 
