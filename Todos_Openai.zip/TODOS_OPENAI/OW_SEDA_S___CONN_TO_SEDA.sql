CREATE OR REPLACE PROCEDURE OW_SEDA_S.CONN_TO_SEDA(WEEKNUM INT)
LANGUAGE PLvSQL AS $$
BEGIN
  PERFORM DELETE FROM OW_SEDA_S.EDI_DATA_RAW 
  WHERE WEEK = WEEKNUM;

  PERFORM INSERT INTO OW_SEDA_S.EDI_DATA_RAW
  SELECT * FROM CONN_SEDA_S_CE.EDI_DATA_RAW_TESTE edrt 
  WHERE WEEK = WEEKNUM;
END;
$$;

-- CALL OW_SEDA_S.CONN_TO_SEDA(42);
-- ERROR: Severity: ERROR, Message: Relation "CONN_SEDA_S_CE.EDI_DATA_RAW_TESTE" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure CONN_TO_SEDA line 6 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
