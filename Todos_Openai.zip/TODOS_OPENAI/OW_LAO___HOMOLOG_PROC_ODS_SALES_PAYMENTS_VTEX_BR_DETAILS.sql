CREATE OR REPLACE PROCEDURE OW_LAO.HOMOLOG_PROC_ODS_SALES_PAYMENTS_VTEX_BR_DETAILS()
LANGUAGE PLvSQL AS $$
BEGIN
  PERFORM TRUNCATE TABLE OW_LAO.TMP_SALES_PAYMENTS_VTEX_BR_DETAILS_HOMOLOG;

  PERFORM INSERT INTO OW_LAO.TMP_SALES_PAYMENTS_VTEX_BR_DETAILS_HOMOLOG
  SELECT
    NULL AS ID,
    CURRENT_TIMESTAMP AS INSERT_TIMESTAMP,
    CURRENT_TIMESTAMP AS UPDATED_TIMESTAMP,
    CAST(A.PO_DATE AS DATE) AS PO_DATE,
    A.PODATE_MONTH AS PO_MONTH,
    A.PODATE_YEAR AS PO_YEAR,
    CAST(SUBSTR(A.PO_HOUR,1,2) AS INTEGER) AS PO_HOUR,
    A.SUBSIDIARY AS PAY_SUBSIDIARY,
    C.KEY_TRANSACTION_ID AS PAY_CODE,
    C.PAYMENT_ID AS PAY_ID,
    CAST(A.PO_DATE AS DATE) AS PAY_DATE,
    A.PODATE_MONTH AS PAY_MONTH,
    A.PODATE_YEAR AS PAY_YEAR,
    CAST(SUBSTR(A.PO_HOUR,1,2) AS INTEGER) AS PAY_HOUR,
    C.STATUS AS PAY_STATUS,
    A.PO_PAYMENT_REMARK AS PAY_DETAIL,
    C."SOURCE" AS PAY_GATEWAY_CODE,
    A.PAYMENT_TYPE,
    C."SOURCE" AS PAY_GATEWAY,
    CAST(NULL AS DECIMAL) AS REVENUE_LOCAL,
    A.PO_ORDERID AS PAY_ORDERID,
    LOWER(A.PO_STORENAME) AS PAY_STORENAME,
    CAST(NULL AS VARCHAR(255)) AS POSTORETYPE,
    A.PO_DEVICETYPE,
    COALESCE(A.PO_INTERNAL_STATUS, 'incomplete') AS PO_STATUS,
    CAST(NULL AS VARCHAR(255)) AS ORDER_STATUS_TYPE,
    A.CURRENCY,
    C."DATE" AS PO_ORDER_LASTMODIFYDATE,
    A.PO_STORENAME AS POSTORENAME,
    A.CHANNEL,
    A.BIZ_TYPE,
    A.AUDIENCE_TYPE,
    A.SUBSIDIARY,
    CAST(NULL AS DECIMAL) AS PE_AMOUNT,
    CAST(NULL AS DECIMAL) AS REVENU_USD,
    A.PO_ORDERID,
    CAST(NULL AS VARCHAR(255)) AS PAY_ACTION,
    CAST(NULL AS VARCHAR(255)) AS PAY_RESULT,
    CAST(NULL AS VARCHAR(255)) AS PAY_DESCRIPTION,
    C.MESSAGE AS PAY_MESSAGE,
    COALESCE(A.PO_INTERNAL_STATUS, 'incomplete') AS PO_INTERNAL_STATUS,
    A.PAYMENT_TYPE AS PO_PAYMENT_TYPE,
    C."SOURCE" AS PO_PAYMENTPROVIDER,
    A.PAYMENT_CARD_BRAND AS PAYMENT_CARD_BRAND,
    A.PO_STATUS AS PO_STATUS_CT,
    CAST(NULL AS VARCHAR(255)) AS FUNNEL_STATUS,
    CAST(NULL AS VARCHAR(255)) AS PAY_GATEWAY_STATUS,
    CAST(NULL AS VARCHAR(255)) AS PO_PAYMENT_TYPE_STATUS,
    'VTEX_BR' AS PO_PLATAFORM_DATASOURCE,
    C."DATE" AS DATASOURCE_ORIGIN_TIMESTAMP,
    ROW_NUMBER() OVER (
      PARTITION BY C.KEY_TRANSACTION_ID, B.ORDER_ID
      ORDER BY C."DATE" DESC, B.VALUE DESC
    ) AS DEDUP
  FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A
  JOIN U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER_PAYMENT B ON B.ORDER_ID = A.PO_ORDERID
  JOIN OW_LAO.RAW_VTEX_PAYMENTS C ON C.KEY_TRANSACTION_ID = B.TRANSACTION_ID
                                 AND C.PAYMENT_ID = B.PAYMENT_ID
  WHERE A.CLIENT_SUBSIDIARY_ID = 6
    AND A.PO_PLATAFORM_DATASOURCE = 'u_prj_ecom.raw_vtex_ssg_br_shop_sales_order'
    AND CAST(A.PO_DATE AS DATE) >= DATE '2025-04-13'
    AND NOT EXISTS (
      SELECT 1
      FROM OW_LAO.ODS_PAYMENT_FUNNEL_HOMOLOG AA
      WHERE A.PO_ORDERID = AA.PO_ORDERID
        AND A.SUBSIDIARY = AA.SUBSIDIARY
        AND COALESCE(A.PO_INTERNAL_STATUS, 'incomplete') = COALESCE(AA.PO_INTERNAL_STATUS, 'incomplete')
    );

  PERFORM DELETE
    FROM OW_LAO.TMP_SALES_PAYMENTS_VTEX_BR_DETAILS_HOMOLOG
   WHERE DEDUP <> 1;

  PERFORM UPDATE OW_LAO.TMP_SALES_PAYMENTS_VTEX_BR_DETAILS_HOMOLOG A
     SET REVENUE_LOCAL = B.VALUE / 100.0,
         PE_AMOUNT     = B.VALUE / 100.0
    FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER_PAYMENT B
   WHERE B.ORDER_ID = A.PAY_ORDERID;

  PERFORM UPDATE OW_LAO.TMP_SALES_PAYMENTS_VTEX_BR_DETAILS_HOMOLOG A
     SET REVENU_USD = A.PE_AMOUNT / CAST(B.EXCHANGE_RATE AS DECIMAL(18,6))
    FROM OW_LAO.FT_AP2_EXCHANGE_RATE B
   WHERE B.VALID_FROM = TIMESTAMPADD(DAY, -1, CAST(A.PO_DATE AS DATE))
     AND LOWER(B.TO_CURRENCY) = LOWER(A.CURRENCY);

  PERFORM UPDATE OW_LAO.TMP_SALES_PAYMENTS_VTEX_BR_DETAILS_HOMOLOG A
     SET FUNNEL_STATUS = B.STATUS
    FROM OW_LAO.DIM_PAYMENT_PAYMENT_STATUS_MAPPING_HOMOLOG B
   WHERE A.PO_INTERNAL_STATUS = B.PO_STATUS
     AND A.PAY_STATUS = B.STATUS
     AND A.PO_PLATAFORM_DATASOURCE = B.DATA_SOURCE;

  PERFORM MERGE INTO OW_LAO.ODS_PAYMENT_FUNNEL_HOMOLOG a
  USING OW_LAO.TMP_SALES_PAYMENTS_VTEX_BR_DETAILS_HOMOLOG b
     ON b.pay_orderid = a.pay_orderid
    AND b.pay_subsidiary = a.pay_subsidiary
  WHEN MATCHED THEN UPDATE SET
        po_date = b.po_date,
        po_month = b.po_month,
        po_year = b.po_year,
        po_hour = b.po_hour,
        pay_subsidiary = b.pay_subsidiary,
        pay_code = b.pay_code,
        pay_id = b.pay_id,
        pay_date = b.pay_date,
        pay_month = b.pay_month,
        pay_year = b.pay_year,
        pay_hour = b.pay_hour,
        pay_status = b.pay_status,
        pay_detail = b.pay_detail,
        pay_gateway_code = b.pay_gateway_code,
        payment_type = b.payment_type,
        pay_gateway = b.pay_gateway,
        revenue_local = b.revenue_local,
        pay_orderid = b.pay_orderid,
        pay_storename = b.pay_storename,
        postoretype = b.postoretype,
        po_devicetype = b.po_devicetype,
        po_status = b.po_status,
        order_status_type = b.order_status_type,
        currency = b.currency,
        po_order_lastmodifydate = b.po_order_lastmodifydate,
        postorename = b.postorename,
        channel = b.channel,
        biz_type = b.biz_type,
        audience_type = b.audience_type,
        subsidiary = b.subsidiary,
        pe_amount = b.pe_amount,
        revenu_usd = b.revenu_usd,
        po_orderid = b.po_orderid,
        pay_action = b.pay_action,
        pay_result = b.pay_result,
        pay_description = b.pay_description,
        pay_message = b.pay_message,
        po_internal_status = b.po_internal_status,
        po_payment_type = b.po_payment_type,
        po_paymentprovider = b.po_paymentprovider,
        payment_card_brand = b.payment_card_brand,
        po_status_ct = b.po_status_ct,
        funnel_status = b.funnel_status,
        PAY_GATEWAY_STATUS = b.PAY_GATEWAY_STATUS,
        PO_PAYMENT_TYPE_STATUS = b.PO_PAYMENT_TYPE_STATUS,
        PO_PLATAFORM_DATASOURCE = b.PO_PLATAFORM_DATASOURCE,
        updated_timestamp = CURRENT_TIMESTAMP,
        datasource_origin_timestamp = b.datasource_origin_timestamp
  WHEN NOT MATCHED THEN INSERT (
        po_date,
        po_month,
        po_year,
        po_hour,
        pay_subsidiary,
        pay_code,
        pay_id,
        pay_date,
        pay_month,
        pay_year,
        pay_hour,
        pay_status,
        pay_detail,
        pay_gateway_code,
        payment_type,
        pay_gateway,
        revenue_local,
        pay_orderid,
        pay_storename,
        postoretype,
        po_devicetype,
        po_status,
        order_status_type,
        currency,
        po_order_lastmodifydate,
        postorename,
        channel,
        biz_type,
        audience_type,
        subsidiary,
        pe_amount,
        revenu_usd,
        po_orderid,
        pay_action,
        pay_result,
        pay_description,
        pay_message,
        po_internal_status,
        po_payment_type,
        po_paymentprovider,
        payment_card_brand,
        po_status_ct,
        funnel_status,
        PAY_GATEWAY_STATUS,
        PO_PAYMENT_TYPE_STATUS,
        PO_PLATAFORM_DATASOURCE,
        datasource_origin_timestamp
  )
  VALUES (
        b.po_date,
        b.po_month,
        b.po_year,
        b.po_hour,
        b.pay_subsidiary,
        b.pay_code,
        b.pay_id,
        b.pay_date,
        b.pay_month,
        b.pay_year,
        b.pay_hour,
        b.pay_status,
        b.pay_detail,
        b.pay_gateway_code,
        b.payment_type,
        b.pay_gateway,
        b.revenue_local,
        b.pay_orderid,
        b.pay_storename,
        b.postoretype,
        b.po_devicetype,
        b.po_status,
        b.order_status_type,
        b.currency,
        b.po_order_lastmodifydate,
        b.postorename,
        b.channel,
        b.biz_type,
        b.audience_type,
        b.subsidiary,
        b.pe_amount,
        b.revenu_usd,
        b.po_orderid,
        b.pay_action,
        b.pay_result,
        b.pay_description,
        b.pay_message,
        b.po_internal_status,
        b.po_payment_type,
        b.po_paymentprovider,
        b.payment_card_brand,
        b.po_status_ct,
        b.funnel_status,
        b.PAY_GATEWAY_STATUS,
        b.PO_PAYMENT_TYPE_STATUS,
        b.PO_PLATAFORM_DATASOURCE,
        b.datasource_origin_timestamp
  );

END;
$$;

-- CALL OW_LAO.HOMOLOG_PROC_ODS_SALES_PAYMENTS_VTEX_BR_DETAILS();
-- ERROR: Severity: ERROR, Message: Function SUBSTR(time, int, int) does not exist, or permission is denied for SUBSTR(time, int, int), Sqlstate: 42883, Hint: No function matches the given name and argument types. Candidates are: SUBSTR(string::varchar, position::numeric) SUBSTR(string::varchar, position::numeric, extent::numeric) SUBSTR(string::varchar, position::float) SUBSTR(string::varchar, position::float, extent::float) SUBSTR(string::long varbinary, position::int, extent::int) SUBSTR(string::varbinary, position::int, extent::int) SUBSTR(string::varchar, position::int, extent::int) SUBSTR(string::long varchar, position::int, extent::int), Where: PL/vSQL procedure HOMOLOG_PROC_ODS_SALES_PAYMENTS_VTEX_BR_DETAILS line 5 at static SQL, Routine: throwErrorFunctionDoesNotMatchCandidates, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/ParseFunc.cpp, Line: 4569, Error Code: 3457, 
-- CALL OW_LAO.HOMOLOG_PROC_ODS_SALES_PAYMENTS_VTEX_BR_DETAILS();
-- ERROR: Severity: ERROR, Message: Function SUBSTR(time, int, int) does not exist, or permission is denied for SUBSTR(time, int, int), Sqlstate: 42883, Hint: No function matches the given name and argument types. Candidates are: SUBSTR(string::varchar, position::numeric) SUBSTR(string::varchar, position::numeric, extent::numeric) SUBSTR(string::varchar, position::float) SUBSTR(string::varchar, position::float, extent::float) SUBSTR(string::long varbinary, position::int, extent::int) SUBSTR(string::varbinary, position::int, extent::int) SUBSTR(string::varchar, position::int, extent::int) SUBSTR(string::long varchar, position::int, extent::int), Where: PL/vSQL procedure HOMOLOG_PROC_ODS_SALES_PAYMENTS_VTEX_BR_DETAILS line 5 at static SQL, Routine: throwErrorFunctionDoesNotMatchCandidates, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/ParseFunc.cpp, Line: 4569, Error Code: 3457, 
CREATE OR REPLACE PROCEDURE OW_LAO.HOMOLOG_PROC_ODS_SALES_PAYMENTS_VTEX_BR_DETAILS()
LANGUAGE PLvSQL AS $$
BEGIN
  PERFORM TRUNCATE TABLE OW_LAO.TMP_SALES_PAYMENTS_VTEX_BR_DETAILS_HOMOLOG;

  PERFORM INSERT INTO OW_LAO.TMP_SALES_PAYMENTS_VTEX_BR_DETAILS_HOMOLOG
  SELECT
    NULL AS ID,
    CURRENT_TIMESTAMP AS INSERT_TIMESTAMP,
    CURRENT_TIMESTAMP AS UPDATED_TIMESTAMP,
    CAST(A.PO_DATE AS DATE) AS PO_DATE,
    A.PODATE_MONTH AS PO_MONTH,
    A.PODATE_YEAR AS PO_YEAR,
    CAST(SUBSTR(CAST(A.PO_HOUR AS VARCHAR),1,2) AS INTEGER) AS PO_HOUR,
    A.SUBSIDIARY AS PAY_SUBSIDIARY,
    C.KEY_TRANSACTION_ID AS PAY_CODE,
    C.PAYMENT_ID AS PAY_ID,
    CAST(A.PO_DATE AS DATE) AS PAY_DATE,
    A.PODATE_MONTH AS PAY_MONTH,
    A.PODATE_YEAR AS PAY_YEAR,
    CAST(SUBSTR(CAST(A.PO_HOUR AS VARCHAR),1,2) AS INTEGER) AS PAY_HOUR,
    C.STATUS AS PAY_STATUS,
    A.PO_PAYMENT_REMARK AS PAY_DETAIL,
    C."SOURCE" AS PAY_GATEWAY_CODE,
    A.PAYMENT_TYPE,
    C."SOURCE" AS PAY_GATEWAY,
    CAST(NULL AS DECIMAL) AS REVENUE_LOCAL,
    A.PO_ORDERID AS PAY_ORDERID,
    LOWER(A.PO_STORENAME) AS PAY_STORENAME,
    CAST(NULL AS VARCHAR(255)) AS POSTORETYPE,
    A.PO_DEVICETYPE,
    COALESCE(A.PO_INTERNAL_STATUS, 'incomplete') AS PO_STATUS,
    CAST(NULL AS VARCHAR(255)) AS ORDER_STATUS_TYPE,
    A.CURRENCY,
    C."DATE" AS PO_ORDER_LASTMODIFYDATE,
    A.PO_STORENAME AS POSTORENAME,
    A.CHANNEL,
    A.BIZ_TYPE,
    A.AUDIENCE_TYPE,
    A.SUBSIDIARY,
    CAST(NULL AS DECIMAL) AS PE_AMOUNT,
    CAST(NULL AS DECIMAL) AS REVENU_USD,
    A.PO_ORDERID,
    CAST(NULL AS VARCHAR(255)) AS PAY_ACTION,
    CAST(NULL AS VARCHAR(255)) AS PAY_RESULT,
    CAST(NULL AS VARCHAR(255)) AS PAY_DESCRIPTION,
    C.MESSAGE AS PAY_MESSAGE,
    COALESCE(A.PO_INTERNAL_STATUS, 'incomplete') AS PO_INTERNAL_STATUS,
    A.PAYMENT_TYPE AS PO_PAYMENT_TYPE,
    C."SOURCE" AS PO_PAYMENTPROVIDER,
    A.PAYMENT_CARD_BRAND AS PAYMENT_CARD_BRAND,
    A.PO_STATUS AS PO_STATUS_CT,
    CAST(NULL AS VARCHAR(255)) AS FUNNEL_STATUS,
    CAST(NULL AS VARCHAR(255)) AS PAY_GATEWAY_STATUS,
    CAST(NULL AS VARCHAR(255)) AS PO_PAYMENT_TYPE_STATUS,
    'VTEX_BR' AS PO_PLATAFORM_DATASOURCE,
    C."DATE" AS DATASOURCE_ORIGIN_TIMESTAMP,
    ROW_NUMBER() OVER (
      PARTITION BY C.KEY_TRANSACTION_ID, B.ORDER_ID
      ORDER BY C."DATE" DESC, B.VALUE DESC
    ) AS DEDUP
  FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A
  JOIN U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER_PAYMENT B ON B.ORDER_ID = A.PO_ORDERID
  JOIN OW_LAO.RAW_VTEX_PAYMENTS C ON C.KEY_TRANSACTION_ID = B.TRANSACTION_ID
                                 AND C.PAYMENT_ID = B.PAYMENT_ID
  WHERE A.CLIENT_SUBSIDIARY_ID = 6
    AND A.PO_PLATAFORM_DATASOURCE = 'u_prj_ecom.raw_vtex_ssg_br_shop_sales_order'
    AND CAST(A.PO_DATE AS DATE) >= DATE '2025-04-13'
    AND NOT EXISTS (
      SELECT 1
      FROM OW_LAO.ODS_PAYMENT_FUNNEL_HOMOLOG AA
      WHERE A.PO_ORDERID = AA.PO_ORDERID
        AND A.SUBSIDIARY = AA.SUBSIDIARY
        AND COALESCE(A.PO_INTERNAL_STATUS, 'incomplete') = COALESCE(AA.PO_INTERNAL_STATUS, 'incomplete')
    );

  PERFORM DELETE
    FROM OW_LAO.TMP_SALES_PAYMENTS_VTEX_BR_DETAILS_HOMOLOG
   WHERE DEDUP <> 1;

  PERFORM UPDATE OW_LAO.TMP_SALES_PAYMENTS_VTEX_BR_DETAILS_HOMOLOG A
     SET REVENUE_LOCAL = B.VALUE / 100.0,
         PE_AMOUNT     = B.VALUE / 100.0
    FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER_PAYMENT B
   WHERE B.ORDER_ID = A.PAY_ORDERID;

  PERFORM UPDATE OW_LAO.TMP_SALES_PAYMENTS_VTEX_BR_DETAILS_HOMOLOG A
     SET REVENU_USD = A.PE_AMOUNT / CAST(B.EXCHANGE_RATE AS DECIMAL(18,6))
    FROM OW_LAO.FT_AP2_EXCHANGE_RATE B
   WHERE B.VALID_FROM = TIMESTAMPADD(DAY, -1, CAST(A.PO_DATE AS DATE))
     AND LOWER(B.TO_CURRENCY) = LOWER(A.CURRENCY);

  PERFORM UPDATE OW_LAO.TMP_SALES_PAYMENTS_VTEX_BR_DETAILS_HOMOLOG A
     SET FUNNEL_STATUS = B.STATUS
    FROM OW_LAO.DIM_PAYMENT_PAYMENT_STATUS_MAPPING_HOMOLOG B
   WHERE A.PO_INTERNAL_STATUS = B.PO_STATUS
     AND A.PAY_STATUS = B.STATUS
     AND A.PO_PLATAFORM_DATASOURCE = B.DATA_SOURCE;

  PERFORM MERGE INTO OW_LAO.ODS_PAYMENT_FUNNEL_HOMOLOG a
  USING OW_LAO.TMP_SALES_PAYMENTS_VTEX_BR_DETAILS_HOMOLOG b
     ON b.pay_orderid = a.pay_orderid
    AND b.pay_subsidiary = a.pay_subsidiary
  WHEN MATCHED THEN UPDATE SET
        po_date = b.po_date,
        po_month = b.po_month,
        po_year = b.po_year,
        po_hour = b.po_hour,
        pay_subsidiary = b.pay_subsidiary,
        pay_code = b.pay_code,
        pay_id = b.pay_id,
        pay_date = b.pay_date,
        pay_month = b.pay_month,
        pay_year = b.pay_year,
        pay_hour = b.pay_hour,
        pay_status = b.pay_status,
        pay_detail = b.pay_detail,
        pay_gateway_code = b.pay_gateway_code,
        payment_type = b.payment_type,
        pay_gateway = b.pay_gateway,
        revenue_local = b.revenue_local,
        pay_orderid = b.pay_orderid,
        pay_storename = b.pay_storename,
        postoretype = b.postoretype,
        po_devicetype = b.po_devicetype,
        po_status = b.po_status,
        order_status_type = b.order_status_type,
        currency = b.currency,
        po_order_lastmodifydate = b.po_order_lastmodifydate,
        postorename = b.postorename,
        channel = b.channel,
        biz_type = b.biz_type,
        audience_type = b.audience_type,
        subsidiary = b.subsidiary,
        pe_amount = b.pe_amount,
        revenu_usd = b.revenu_usd,
        po_orderid = b.po_orderid,
        pay_action = b.pay_action,
        pay_result = b.pay_result,
        pay_description = b.pay_description,
        pay_message = b.pay_message,
        po_internal_status = b.po_internal_status,
        po_payment_type = b.po_payment_type,
        po_paymentprovider = b.po_paymentprovider,
        payment_card_brand = b.payment_card_brand,
        po_status_ct = b.po_status_ct,
        funnel_status = b.funnel_status,
        PAY_GATEWAY_STATUS = b.PAY_GATEWAY_STATUS,
        PO_PAYMENT_TYPE_STATUS = b.PO_PAYMENT_TYPE_STATUS,
        PO_PLATAFORM_DATASOURCE = b.PO_PLATAFORM_DATASOURCE,
        updated_timestamp = CURRENT_TIMESTAMP,
        datasource_origin_timestamp = b.datasource_origin_timestamp
  WHEN NOT MATCHED THEN INSERT (
        po_date,
        po_month,
        po_year,
        po_hour,
        pay_subsidiary,
        pay_code,
        pay_id,
        pay_date,
        pay_month,
        pay_year,
        pay_hour,
        pay_status,
        pay_detail,
        pay_gateway_code,
        payment_type,
        pay_gateway,
        revenue_local,
        pay_orderid,
        pay_storename,
        postoretype,
        po_devicetype,
        po_status,
        order_status_type,
        currency,
        po_order_lastmodifydate,
        postorename,
        channel,
        biz_type,
        audience_type,
        subsidiary,
        pe_amount,
        revenu_usd,
        po_orderid,
        pay_action,
        pay_result,
        pay_description,
        pay_message,
        po_internal_status,
        po_payment_type,
        po_paymentprovider,
        payment_card_brand,
        po_status_ct,
        funnel_status,
        PAY_GATEWAY_STATUS,
        PO_PAYMENT_TYPE_STATUS,
        PO_PLATAFORM_DATASOURCE,
        datasource_origin_timestamp
  )
  VALUES (
        b.po_date,
        b.po_month,
        b.po_year,
        b.po_hour,
        b.pay_subsidiary,
        b.pay_code,
        b.pay_id,
        b.pay_date,
        b.pay_month,
        b.pay_year,
        b.pay_hour,
        b.pay_status,
        b.pay_detail,
        b.pay_gateway_code,
        b.payment_type,
        b.pay_gateway,
        b.revenue_local,
        b.pay_orderid,
        b.pay_storename,
        b.postoretype,
        b.po_devicetype,
        b.po_status,
        b.order_status_type,
        b.currency,
        b.po_order_lastmodifydate,
        b.postorename,
        b.channel,
        b.biz_type,
        b.audience_type,
        b.subsidiary,
        b.pe_amount,
        b.revenu_usd,
        b.po_orderid,
        b.pay_action,
        b.pay_result,
        b.pay_description,
        b.pay_message,
        b.po_internal_status,
        b.po_payment_type,
        b.po_paymentprovider,
        b.payment_card_brand,
        b.po_status_ct,
        b.funnel_status,
        b.PAY_GATEWAY_STATUS,
        b.PO_PAYMENT_TYPE_STATUS,
        b.PO_PLATAFORM_DATASOURCE,
        b.datasource_origin_timestamp
  );

END;
$$;

-- CALL OW_LAO.HOMOLOG_PROC_ODS_SALES_PAYMENTS_VTEX_BR_DETAILS();
-- ERROR: Severity: ERROR, Message: Relation "OW_LAO.ODS_PAYMENT_FUNNEL_HOMOLOG" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure HOMOLOG_PROC_ODS_SALES_PAYMENTS_VTEX_BR_DETAILS line 5 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
-- CALL OW_LAO.HOMOLOG_PROC_ODS_SALES_PAYMENTS_VTEX_BR_DETAILS();
-- ERROR: Severity: ERROR, Message: Relation "OW_LAO.ODS_PAYMENT_FUNNEL_HOMOLOG" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure HOMOLOG_PROC_ODS_SALES_PAYMENTS_VTEX_BR_DETAILS line 5 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
