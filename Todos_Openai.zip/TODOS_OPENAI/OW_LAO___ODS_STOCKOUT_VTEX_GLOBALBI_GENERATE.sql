CREATE OR REPLACE PROCEDURE ow_lao.ods_stockout_vtex_globalbi_generate()
LANGUAGE PLvSQL AS $$
BEGIN
     PERFORM MERGE INTO ow_lao.ods_stockout_vtex_globalbi       a
          USING ow_lao.stg_stockout_vtex_globalbi_seasa b ON b.country_cd        = a.country_cd
                                                         AND b.wrehouse_operator = a.wrehouse_operator
                                                         AND b.warehouse         = a.warehouse
                                                         AND b.product_code      = a.product_code
           WHEN MATCHED THEN UPDATE  
                                   SET a.updated_timestamp                      = CURRENT_TIMESTAMP
                                     , a.country_cd                             = b.country_cd
                                     , a.store_type                             = b.store_type
                                     , a.store_name                             = b.store_name
                                     , a.warehouse                              = b.warehouse
                                     , a.product_code                           = b.product_code
                                     , a.in_stock_status                        = b.in_stock_status
                                     , a.available_amount                       = b.available_amount
                                     , a.reserved_amount                        = b.reserved_amount
                                     , a.overselling_amount                     = b.overselling_amount
                                     , a.pre_order                              = b.pre_order
                                     , a.max_preorder                           = b.max_preorder
                                     , a.safety_stock                           = b.safety_stock
                                     , a.sales_status                           = b.sales_status
                                     , a.approval_status                        = b.approval_status
                                     , a.net_quantity                           = b.net_quantity
                                     , a.is_status                              = b.is_status
                                     , a.is_allow_back_order                    = b.is_allow_back_order
                                     , a.catalog                                = b.catalog
                                     , a.time_created                           = b.time_created
                                     , a.time_modified                          = b.time_modified
                                     , a.overselling_shippingdate               = b.overselling_shippingdate
                                     , a.number_of_customer_email_registrations = b.number_of_customer_email_registrations
                                     , a.wrehouse_operator                      = b.wrehouse_operator
                                     , a.file_name_generated_timestamp          = CAST(CAST(b.file_name_generated_date AS DATE) 
                                                                                    || ' ' || 
                                                                                        CAST(b.file_name_generated_time  AS TIME) AS TIMESTAMP)
           WHEN NOT MATCHED THEN INSERT(
                                        country_cd
                                      , store_type
                                      , store_name
                                      , warehouse
                                      , product_code
                                      , in_stock_status
                                      , available_amount
                                      , reserved_amount
                                      , overselling_amount
                                      , pre_order
                                      , max_preorder
                                      , safety_stock
                                      , sales_status
                                      , approval_status
                                      , net_quantity
                                      , is_status
                                      , is_allow_back_order
                                      , catalog
                                      , time_created
                                      , time_modified
                                      , overselling_shippingdate
                                      , number_of_customer_email_registrations
                                      , wrehouse_operator
                                      , file_name_generated_timestamp
                                 )
                                 VALUES(
                                        b.country_cd
                                      , b.store_type
                                      , b.store_name
                                      , b.warehouse
                                      , b.product_code
                                      , b.in_stock_status
                                      , b.available_amount
                                      , b.reserved_amount
                                      , b.overselling_amount
                                      , b.pre_order
                                      , b.max_preorder
                                      , b.safety_stock
                                      , b.sales_status
                                      , b.approval_status
                                      , b.net_quantity
                                      , b.is_status
                                      , b.is_allow_back_order
                                      , b.catalog
                                      , b.time_created
                                      , b.time_modified
                                      , b.overselling_shippingdate
                                      , b.number_of_customer_email_registrations
                                      , b.wrehouse_operator
                                      , CAST(CAST(b.file_name_generated_date AS DATE) 
                                           || ' ' || 
                                               CAST(b.file_name_generated_time  AS TIME) AS TIMESTAMP)
                                 );     
END
$$;

-- CALL ow_lao.ods_stockout_vtex_globalbi_generate();
-- ERROR: Severity: ERROR, Message: Relation "ow_lao.stg_stockout_vtex_globalbi_seasa" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure ods_stockout_vtex_globalbi_generate line 3 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
-- CALL ow_lao.ods_stockout_vtex_globalbi_generate();
-- ERROR: Severity: ERROR, Message: Relation "ow_lao.stg_stockout_vtex_globalbi_seasa" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure ods_stockout_vtex_globalbi_generate line 3 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
