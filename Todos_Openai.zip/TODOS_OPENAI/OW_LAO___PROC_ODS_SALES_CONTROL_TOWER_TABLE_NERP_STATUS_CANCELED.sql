CREATE OR REPLACE PROCEDURE ow_lao.proc_ods_sales_control_tower_table_nerp_status_canceled()
LANGUAGE PLvSQL AS $$
BEGIN
 
 -- Step 1: Mark payment rejected for cancelled orders in last 180 days
 PERFORM UPDATE ow_lao.ods_sales_control_tower_table a
    SET po_internal_status = CASE WHEN a.po_status = 'Cancelled' THEN 'payment rejected' ELSE a.po_internal_status END
  WHERE a.po_status = 'Cancelled'
    AND a.client_subsidiary_id = 6
    AND CAST(a.po_date AS DATE) BETWEEN CAST(TIMESTAMPADD(DAY, -180, NOW()) AS DATE)
                                     AND CAST(TIMESTAMPADD(DAY, 0, NOW()) AS DATE);

 -- Step 2: For orders with so_date and not in specific divisions, set canceled
 PERFORM UPDATE ow_lao.ods_sales_control_tower_table a
    SET po_internal_status = CASE WHEN a.po_status = 'Cancelled' THEN 'canceled' ELSE a.po_internal_status END
  WHERE a.so_date IS NOT NULL
    AND a.po_status = 'Cancelled'
    AND a.client_subsidiary_id = 6
    AND a.po_orderid NOT IN (
        SELECT DISTINCT a2.po_orderid
        FROM ow_lao.ods_sales_control_tower_table a2
        WHERE a2.division IN ('Bundle','SC+','SERVICE')
    )
    AND CAST(a.po_date AS DATE) BETWEEN CAST(TIMESTAMPADD(DAY, -180, NOW()) AS DATE)
                                     AND CAST(TIMESTAMPADD(DAY, 0, NOW()) AS DATE);

 -- Step 3: For specific divisions, normalize to canceled
 PERFORM UPDATE ow_lao.ods_sales_control_tower_table a
    SET po_internal_status = CASE 
                                WHEN a.po_internal_status IN ('payment rejected','canceled') THEN 'canceled'
                                ELSE a.po_internal_status
                             END
  WHERE a.division IN ('Bundle','SC+','SERVICE')
    AND a.po_status = 'Cancelled'
    AND a.client_subsidiary_id = 6
    AND CAST(a.po_date AS DATE) BETWEEN CAST(TIMESTAMPADD(DAY, -180, NOW()) AS DATE)
                                     AND CAST(TIMESTAMPADD(DAY, 0, NOW()) AS DATE);

END
$$;

CALL ow_lao.proc_ods_sales_control_tower_table_nerp_status_canceled();
-- proc_ods_sales_control_tower_table_nerp_status_canceled
-- -------------------------------------------------------
-- 0

