-- SELECT * FROM SERIES_GENERATE_INTEGER(1, 1, 3) LIMIT 1;
-- ERROR: Severity: ERROR, Message: Function SERIES_GENERATE_INTEGER(int, int, int) does not exist, or permission is denied for SERIES_GENERATE_INTEGER(int, int, int), Sqlstate: 42883, Hint: No function matches the given name and argument types. You may need to add explicit type casts, Routine: throwErrorFunctionDoesNotMatch, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/ParseFunc.cpp, Line: 4559, Error Code: 3457, 
CREATE OR REPLACE PROCEDURE OW_SEDA_S.PRC_WEBPRICE_UPDT_RECENT_PRICE(IN DATE_REF VARCHAR(10))
LANGUAGE PLvSQL AS $$
BEGIN 
    
    PERFORM UPDATE ow_seda_s.ods_webprice_tracking_daily_tv owtd SET
        RECENT_PRICE_COLLECTED = t.RECENT_PRICE_COLLECTED
    FROM (
        SELECT 
            ITEM,
            STORE_NAME,
            MARKETPLACE_NAME,
            DATE_COLLECTED,
            PRICE_TYPE,
            AVG(RECENT_PRICE_COLLECTED) AS RECENT_PRICE_COLLECTED
        FROM (
            SELECT DISTINCT
                ITEM,
                STORE_NAME,
                MARKETPLACE_NAME,
                DATE_COLLECTED,
                CASE 
                    WHEN ELEMENT_NUMBER = 1 THEN 'Preco a Vista'
                    WHEN ELEMENT_NUMBER = 2 THEN 'Preco a Prazo'
                END AS PRICE_TYPE,
                CASE 
                    WHEN ELEMENT_NUMBER = 1 THEN PRECO_A_VISTA
                    WHEN ELEMENT_NUMBER = 2 THEN PRECO_A_PRAZO
                END AS RECENT_PRICE_COLLECTED
            FROM (
                SELECT 
                    ITEM,
                    UPPER(STORE_NAME) AS STORE_NAME,
                    COALESCE(UPPER(MARKETPLACE_NAME), '-') AS MARKETPLACE_NAME,
                    TO_DATE(INPUT_DATE) AS DATE_COLLECTED,
                    PRECO_A_VISTA,
                    PRECO_A_PRAZO,
                    DENSE_RANK() OVER (
                        PARTITION BY ITEM, UPPER(STORE_NAME), COALESCE(UPPER(MARKETPLACE_NAME), '-') 
                        ORDER BY INPUT_DATE
                    ) AS recent_index,
                    e.element_number AS ELEMENT_NUMBER
                FROM OW_SEDA_S.ODS_CE_WEBPRICE_API ocwa
                CROSS JOIN (SELECT 1 AS element_number UNION ALL SELECT 2 AS element_number) e
                WHERE TO_DATE(INPUT_DATE) = TO_DATE(DATE_REF)
            ) s
            WHERE recent_index = 1
        ) x
        GROUP BY 
            ITEM,
            STORE_NAME,
            MARKETPLACE_NAME,
            DATE_COLLECTED,
            PRICE_TYPE
    ) t
    WHERE 1=1
        AND owtd.ITEM = t.ITEM
        AND owtd.STORE = t.STORE_NAME
        AND owtd.MARKET_PLACE = t.MARKETPLACE_NAME
        AND owtd.DATE_COLLECTED = t.DATE_COLLECTED
        AND owtd.PRICE_TYPE = t.PRICE_TYPE
        AND owtd.RECENT_PRICE_COLLECTED IS NULL;
END;
$$;

-- CALL OW_SEDA_S.PRC_WEBPRICE_UPDT_RECENT_PRICE('2025-09-20');
-- ERROR: Severity: ERROR, Message: Function TO_DATE(timestamp) does not exist, or permission is denied for TO_DATE(timestamp), Sqlstate: 42883, Hint: No function matches the given name and argument types. Candidates are: TO_DATE(expression::varchar, pattern::varchar), Where: PL/vSQL procedure PRC_WEBPRICE_UPDT_RECENT_PRICE line 4 at static SQL, Routine: throwErrorFunctionDoesNotMatchCandidates, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/ParseFunc.cpp, Line: 4569, Error Code: 3457, 
CREATE OR REPLACE PROCEDURE OW_SEDA_S.PRC_WEBPRICE_UPDT_RECENT_PRICE(IN DATE_REF VARCHAR(10))
LANGUAGE PLvSQL AS $$
BEGIN 
    PERFORM UPDATE ow_seda_s.ods_webprice_tracking_daily_tv owtd SET
        RECENT_PRICE_COLLECTED = t.RECENT_PRICE_COLLECTED
    FROM (
        SELECT 
            ITEM,
            STORE_NAME,
            MARKETPLACE_NAME,
            DATE_COLLECTED,
            PRICE_TYPE,
            AVG(RECENT_PRICE_COLLECTED) AS RECENT_PRICE_COLLECTED
        FROM (
            SELECT DISTINCT
                ITEM,
                STORE_NAME,
                MARKETPLACE_NAME,
                DATE_COLLECTED,
                CASE 
                    WHEN ELEMENT_NUMBER = 1 THEN 'Preco a Vista'
                    WHEN ELEMENT_NUMBER = 2 THEN 'Preco a Prazo'
                END AS PRICE_TYPE,
                CASE 
                    WHEN ELEMENT_NUMBER = 1 THEN PRECO_A_VISTA
                    WHEN ELEMENT_NUMBER = 2 THEN PRECO_A_PRAZO
                END AS RECENT_PRICE_COLLECTED
            FROM (
                SELECT 
                    ITEM,
                    UPPER(STORE_NAME) AS STORE_NAME,
                    COALESCE(UPPER(MARKETPLACE_NAME), '-') AS MARKETPLACE_NAME,
                    CAST(INPUT_DATE AS DATE) AS DATE_COLLECTED,
                    PRECO_A_VISTA,
                    PRECO_A_PRAZO,
                    DENSE_RANK() OVER (
                        PARTITION BY ITEM, UPPER(STORE_NAME), COALESCE(UPPER(MARKETPLACE_NAME), '-') 
                        ORDER BY INPUT_DATE
                    ) AS recent_index,
                    e.element_number AS ELEMENT_NUMBER
                FROM OW_SEDA_S.ODS_CE_WEBPRICE_API ocwa
                CROSS JOIN (SELECT 1 AS element_number UNION ALL SELECT 2 AS element_number) e
                WHERE CAST(INPUT_DATE AS DATE) = TO_DATE(DATE_REF, 'YYYY-MM-DD')
            ) s
            WHERE recent_index = 1
        ) x
        GROUP BY 
            ITEM,
            STORE_NAME,
            MARKETPLACE_NAME,
            DATE_COLLECTED,
            PRICE_TYPE
    ) t
    WHERE 1=1
        AND owtd.ITEM = t.ITEM
        AND owtd.STORE = t.STORE_NAME
        AND owtd.MARKET_PLACE = t.MARKETPLACE_NAME
        AND owtd.DATE_COLLECTED = t.DATE_COLLECTED
        AND owtd.PRICE_TYPE = t.PRICE_TYPE
        AND owtd.RECENT_PRICE_COLLECTED IS NULL;
END;
$$;

CALL OW_SEDA_S.PRC_WEBPRICE_UPDT_RECENT_PRICE('2025-09-20');
-- PRC_WEBPRICE_UPDT_RECENT_PRICE
-- ------------------------------
-- 0

