CREATE OR REPLACE PROCEDURE u_prj_ecom.proc_ods_diggit_ecom_orders_hist_homolg()
LANGUAGE PLvSQL AS $$
DECLARE
  order_creation_min DATE;
  order_creation_max DATE;
BEGIN
  SELECT MIN(order_creation_date), MAX(order_creation_date)
  INTO order_creation_min, order_creation_max
  FROM u_prj_ecom.tmp_diggit_ecom_orders;

  PERFORM DROP TABLE IF EXISTS u_prj_ecom.tmp_diggit_ecom_orders_ods_hist_homolg;

  PERFORM CREATE TABLE u_prj_ecom.tmp_diggit_ecom_orders_ods_hist_homolg AS
  SELECT order_code,
         order_creation_date,
         order_creation_hour,
         country,
         sku,
         order_status,
         channel,
         store_name,
         currency,
         qty,
         product_price,
         revenue
  FROM (
     SELECT a.order_code,
            a.order_creation_date,
            a.order_creation_hour,
            a.country,
            a.sku,
            a.order_status,
            a.channel,
            a.store_name,
            a.currency,
            SUM(CASE WHEN a.qty IS NULL THEN 0 ELSE CAST(a.qty AS INTEGER) END) AS qty,
            a.product_price,
            SUM(CASE WHEN a.revenue IS NULL THEN 0 ELSE CAST(a.revenue AS NUMERIC(38,10)) END) AS revenue,
            ROW_NUMBER() OVER (PARTITION BY order_code ORDER BY order_creation_date DESC, order_creation_hour DESC) AS rn
       FROM u_prj_ecom.tmp_diggit_ecom_orders a
       GROUP BY a.order_code, a.country, a.sku, a.order_status, a.channel, a.store_name, a.currency, a.product_price, a.order_creation_date, a.order_creation_hour
  ) s
  WHERE rn = 1;

  PERFORM CREATE LOCAL TEMPORARY TABLE orders_codes_cancelleds ON COMMIT PRESERVE ROWS AS
  SELECT DISTINCT a.order_code, a.sku
  FROM u_prj_ecom.tmp_diggit_ecom_orders_ods_hist_homolg a
  WHERE a.order_creation_date BETWEEN order_creation_min AND order_creation_max
    AND NOT EXISTS (
      SELECT 1 FROM u_prj_ecom.tmp_diggit_ecom_orders_ods_hist_homolg aa
      WHERE aa.order_code = a.order_code
        AND aa.sku = a.sku
        AND aa.store_name = a.store_name
    );

  PERFORM UPDATE u_prj_ecom.ods_diggit_ecom_orders_hist_homolog AS a
  SET order_status = 'Cancelled',
      updated_timestamp = CURRENT_TIMESTAMP
  FROM orders_codes_cancelleds b
  WHERE b.order_code = a.order_code
    AND b.sku = a.sku
    AND a.order_status <> 'Cancelled';

  PERFORM MERGE INTO u_prj_ecom.ods_diggit_ecom_orders_hist_homolog AS a
  USING u_prj_ecom.tmp_diggit_ecom_orders_ods_hist_homolg AS b
  ON b.order_code = a.order_code AND b.sku = a.sku
  WHEN MATCHED THEN UPDATE SET
    channel = b.channel,
    store_name = b.store_name,
    currency = b.currency,
    qty = b.qty,
    product_price = b.product_price,
    revenue = b.revenue,
    order_status = b.order_status,
    order_creation_date = b.order_creation_date,
    order_creation_hour = b.order_creation_hour,
    updated_timestamp = CURRENT_TIMESTAMP
  WHEN NOT MATCHED THEN INSERT (
    order_code,
    order_creation_date,
    order_creation_hour,
    country,
    sku,
    order_status,
    channel,
    store_name,
    currency,
    qty,
    product_price,
    revenue
  ) VALUES (
    b.order_code,
    b.order_creation_date,
    b.order_creation_hour,
    b.country,
    b.sku,
    b.order_status,
    b.channel,
    b.store_name,
    b.currency,
    b.qty,
    b.product_price,
    b.revenue
  );
END;
$$;

-- CALL u_prj_ecom.proc_ods_diggit_ecom_orders_hist_homolg();
-- ERROR: Severity: ERROR, Message: Operator does not exist: varchar >= date, Sqlstate: 42883, Hint: No operator matches the given name and argument type(s). You may need to add explicit type casts, Where: PL/vSQL procedure proc_ods_diggit_ecom_orders_hist_homolg line 44 at static SQL, Routine: op_error, File: parse_oper.c, Line: 608, Error Code: 4286, 
-- CALL u_prj_ecom.proc_ods_diggit_ecom_orders_hist_homolg();
-- ERROR: Severity: ERROR, Message: Operator does not exist: varchar >= date, Sqlstate: 42883, Hint: No operator matches the given name and argument type(s). You may need to add explicit type casts, Where: PL/vSQL procedure proc_ods_diggit_ecom_orders_hist_homolg line 44 at static SQL, Routine: op_error, File: parse_oper.c, Line: 608, Error Code: 4286, 
CREATE OR REPLACE PROCEDURE u_prj_ecom.proc_ods_diggit_ecom_orders_hist_homolg()
LANGUAGE PLvSQL AS $$
DECLARE
  order_creation_min DATE;
  order_creation_max DATE;
BEGIN
  SELECT MIN(CAST(order_creation_date AS DATE)), MAX(CAST(order_creation_date AS DATE))
  INTO order_creation_min, order_creation_max
  FROM u_prj_ecom.tmp_diggit_ecom_orders;

  PERFORM DROP TABLE IF EXISTS u_prj_ecom.tmp_diggit_ecom_orders_ods_hist_homolg;

  PERFORM CREATE TABLE u_prj_ecom.tmp_diggit_ecom_orders_ods_hist_homolg AS
  SELECT order_code,
         CAST(order_creation_date AS DATE) AS order_creation_date,
         order_creation_hour,
         country,
         sku,
         order_status,
         channel,
         store_name,
         currency,
         qty,
         product_price,
         revenue
  FROM (
     SELECT a.order_code,
            CAST(a.order_creation_date AS DATE) AS order_creation_date,
            a.order_creation_hour,
            a.country,
            a.sku,
            a.order_status,
            a.channel,
            a.store_name,
            a.currency,
            SUM(CASE WHEN a.qty IS NULL THEN 0 ELSE CAST(a.qty AS INTEGER) END) AS qty,
            a.product_price,
            SUM(CASE WHEN a.revenue IS NULL THEN 0 ELSE CAST(a.revenue AS DECIMAL(38,10)) END) AS revenue,
            ROW_NUMBER() OVER (PARTITION BY a.order_code ORDER BY CAST(a.order_creation_date AS DATE) DESC, a.order_creation_hour DESC) AS rn
       FROM u_prj_ecom.tmp_diggit_ecom_orders a
       GROUP BY a.order_code, a.country, a.sku, a.order_status, a.channel, a.store_name, a.currency, a.product_price, a.order_creation_date, a.order_creation_hour
  ) s
  WHERE rn = 1;

  PERFORM CREATE LOCAL TEMPORARY TABLE orders_codes_cancelleds ON COMMIT PRESERVE ROWS AS
  SELECT DISTINCT a.order_code, a.sku
  FROM u_prj_ecom.tmp_diggit_ecom_orders_ods_hist_homolg a
  WHERE CAST(a.order_creation_date AS DATE) BETWEEN order_creation_min AND order_creation_max
    AND NOT EXISTS (
      SELECT 1 FROM u_prj_ecom.tmp_diggit_ecom_orders_ods_hist_homolg aa
      WHERE aa.order_code = a.order_code
        AND aa.sku = a.sku
        AND aa.store_name = a.store_name
    );

  PERFORM UPDATE u_prj_ecom.ods_diggit_ecom_orders_hist_homolog AS a
  SET order_status = 'Cancelled',
      updated_timestamp = CURRENT_TIMESTAMP
  FROM orders_codes_cancelleds b
  WHERE b.order_code = a.order_code
    AND b.sku = a.sku
    AND a.order_status <> 'Cancelled';

  PERFORM MERGE INTO u_prj_ecom.ods_diggit_ecom_orders_hist_homolog AS a
  USING u_prj_ecom.tmp_diggit_ecom_orders_ods_hist_homolg AS b
  ON b.order_code = a.order_code AND b.sku = a.sku
  WHEN MATCHED THEN UPDATE SET
    channel = b.channel,
    store_name = b.store_name,
    currency = b.currency,
    qty = b.qty,
    product_price = b.product_price,
    revenue = b.revenue,
    order_status = b.order_status,
    order_creation_date = b.order_creation_date,
    order_creation_hour = b.order_creation_hour,
    updated_timestamp = CURRENT_TIMESTAMP
  WHEN NOT MATCHED THEN INSERT (
    order_code,
    order_creation_date,
    order_creation_hour,
    country,
    sku,
    order_status,
    channel,
    store_name,
    currency,
    qty,
    product_price,
    revenue
  ) VALUES (
    b.order_code,
    b.order_creation_date,
    b.order_creation_hour,
    b.country,
    b.sku,
    b.order_status,
    b.channel,
    b.store_name,
    b.currency,
    b.qty,
    b.product_price,
    b.revenue
  );
END;
$$;

-- CALL u_prj_ecom.proc_ods_diggit_ecom_orders_hist_homolg();
-- ERROR: Severity: ERROR, Message: Table "u_prj_ecom.ods_diggit_ecom_orders_hist_homolog" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ods_diggit_ecom_orders_hist_homolg line 55 at static SQL, Routine: throwErrInvalidTab, File: analyze.c, Line: 3378, Error Code: 4883, 
-- CALL u_prj_ecom.proc_ods_diggit_ecom_orders_hist_homolg();
-- ERROR: Severity: ERROR, Message: Table "u_prj_ecom.ods_diggit_ecom_orders_hist_homolog" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ods_diggit_ecom_orders_hist_homolg line 55 at static SQL, Routine: throwErrInvalidTab, File: analyze.c, Line: 3378, Error Code: 4883, 
