-- CREATE OR REPLACE PROCEDURE OW_MD.PROC_DIM_SALES_CHANNEL()
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--     
--     PERFORM MERGE INTO OW_MD.SALES_CHANNEL O
--         USING OW_MD.TMP_SALES_CHANNEL_SEDA M
--         ON    COALESCE(O.AFFILIATE_ID,'') = COALESCE(M.AFFILIATE_ID,'')
--         AND   COALESCE(O.SALES_CHANNEL,'') = COALESCE(M.SALES_CHANNEL,'')
--         AND   COALESCE(O.HAS_STORE_ID,'') = COALESCE(M.HAS_STORE_ID,'')
--         AND   COALESCE(O.SKU_MAPPING,'') = COALESCE(M.SKU_MAPPING,'')
--         AND   O.SALES_ORG = 'SEDA'
--         WHEN MATCHED 
--             THEN
--             UPDATE SET
--                 PLATAFORM_TYPE = M.PLATAFORM_TYPE,            
--                 PLATAFORM_ACCOUNT = M.PLATAFORM_ACCOUNT,
--                 IDENTIFIER = M.IDENTIFIER,
--                 RELATIONSHIP_TYPES = M.RELATIONSHIP_TYPES,
--                 CHANNEL = M.CHANNEL,
--                 SUB_CHANNEL = M.SUB_CHANNEL,
--                 PARTNER_LEVEL = M.PARTNER_LEVEL,
--                 GLOBAL_CHANNEL = M.GLOBAL_CHANNEL,
--                 BIZ_TYPE = M.BIZ_TYPE,
--                 AUDIENCE_TYPE = M.AUDIENCE_TYPE,
--                 SALES_ORG = M.SALES_ORG,
--                 BUSINESS_AREA = M.BUSINESS_AREA,
--                 COMPANY_CODE = M.COMPANY_CODE,
--                 COUNTRY = M.COUNTRY,
--                 COUNTRY_CODE = M.COUNTRY_CODE,
--                 CURRENCY = M.CURRENCY,
--                 CUSTOMER_TYPE = M.CUSTOMER_TYPE,
--                 PO_MOBILE_OS = M.PO_MOBILE_OS,
--                 SKU_MAPPING = M.SKU_MAPPING,
--                 FILE_NAME = M.FILE_NAME,
--                 UPDATE_DATE = M.LOAD_DATE,
--                 PROCESS_DATE = CURRENT_TIMESTAMP 
--         WHEN NOT MATCHED 
--             THEN
--             INSERT
--                 (PLATAFORM_TYPE,            
--                 PLATAFORM_ACCOUNT,
--                 IDENTIFIER,
--                 HAS_STORE_ID,
--                 SALES_CHANNEL,
--                 AFFILIATE_ID,
--                 RELATIONSHIP_TYPES,
--                 CHANNEL,
--                 SUB_CHANNEL,
--                 PARTNER_LEVEL,
--                 GLOBAL_CHANNEL,
--                 GLOBAL_CHANNEL_EBI,
--                 BIZ_TYPE,
--                 BIZ_TYPE_EBI,
--                 AUDIENCE_TYPE,
--                 AUDIENCE_TYPE_EBI,
--                 SALES_ORG,
--                 BUSINESS_AREA,
--                 COMPANY_CODE,
--                 COUNTRY,
--                 COUNTRY_CODE,
--                 CURRENCY,
--                 CUSTOMER_TYPE,
--                 PO_MOBILE_OS,
--                 SKU_MAPPING,
--                 FILE_NAME,
--                 UPDATE_DATE,
--                 LOAD_DATE,
--                 PROCESS_DATE)
--             VALUES
--                 (M.PLATAFORM_TYPE,          
--                 M.PLATAFORM_ACCOUNT,
--                 M.IDENTIFIER,
--                 M.HAS_STORE_ID,
--                 M.SALES_CHANNEL,
--                 M.AFFILIATE_ID,
--                 M.RELATIONSHIP_TYPES,
--                 M.CHANNEL,
--                 M.SUB_CHANNEL,
--                 M.PARTNER_LEVEL,
--                 M.GLOBAL_CHANNEL,
--                 M.GLOBAL_CHANNEL_EBI,
--                 M.BIZ_TYPE,
--                 M.BIZ_TYPE_EBI,
--                 M.AUDIENCE_TYPE,
--                 M.AUDIENCE_TYPE_EBI,
--                 M.SALES_ORG,
--                 M.BUSINESS_AREA,
--                 M.COMPANY_CODE,
--                 M.COUNTRY,
--                 M.COUNTRY_CODE,
--                 M.CURRENCY,
--                 M.CUSTOMER_TYPE,
--                 M.PO_MOBILE_OS,
--                 M.SKU_MAPPING,
--                 M.FILE_NAME,
--                 M.LOAD_DATE,
--                 M.LOAD_DATE,
--                 CURRENT_TIMESTAMP);
-- 
--     PERFORM MERGE INTO OW_MD.SALES_CHANNEL O
--         USING OW_MD.TMP_SALES_CHANNEL_LAO M 
--         ON  COALESCE(O.PLATAFORM_TYPE,'') = COALESCE(M.PLATAFORM_TYPE,'')
--         AND COALESCE(O.PLATAFORM_ACCOUNT,'') = COALESCE(M.PLATAFORM_ACCOUNT,'')
--         AND COALESCE(O.IDENTIFIER,'') = COALESCE(M.IDENTIFIER,'')
--         AND COALESCE(O.HAS_STORE_ID,'') = COALESCE(M.HAS_STORE_ID,'')
--         AND COALESCE(O.SALES_CHANNEL,'') = COALESCE(M.SALES_CHANNEL,'')
--         AND COALESCE(O.AFFILIATE_ID,'') = COALESCE(M.AFFILIATE_ID,'')
--         AND COALESCE(O.SKU_MAPPING,'') = COALESCE(M.SKU_MAPPING,'')
--         AND COALESCE(O.COUNTRY,'') = COALESCE(M.COUNTRY,'')
--         AND M.SALES_ORG <> 'SEDA'
--             
--         WHEN MATCHED 
--             THEN
--             UPDATE SET
--                 RELATIONSHIP_TYPES = M.RELATIONSHIP_TYPES,
--                 CHANNEL = M.CHANNEL,
--                 SUB_CHANNEL = M.SUB_CHANNEL,
--                 PARTNER_LEVEL = M.PARTNER_LEVEL,
--                 GLOBAL_CHANNEL = M.GLOBAL_CHANNEL,
--                 GLOBAL_CHANNEL_EBI = M.GLOBAL_CHANNEL_EBI,
--                 BIZ_TYPE = M.BIZ_TYPE,
--                 BIZ_TYPE_EBI = M.BIZ_TYPE_EBI,
--                 AUDIENCE_TYPE = M.AUDIENCE_TYPE,
--                 AUDIENCE_TYPE_EBI = M.AUDIENCE_TYPE_EBI,
--                 SALES_ORG = M.SALES_ORG,
--                 BUSINESS_AREA = M.BUSINESS_AREA,
--                 COMPANY_CODE = M.COMPANY_CODE,
--                 COUNTRY_CODE = M.COUNTRY_CODE,
--                 CURRENCY = M.CURRENCY,
--                 CUSTOMER_TYPE = M.CUSTOMER_TYPE,
--                 PO_MOBILE_OS = M.PO_MOBILE_OS,
--                 SKU_MAPPING = M.SKU_MAPPING,
--                 FILE_NAME = M.FILE_NAME,
--                 UPDATE_DATE = M.LOAD_DATE,
--                 PROCESS_DATE = CURRENT_TIMESTAMP 
--         WHEN NOT MATCHED 
--             THEN
--             INSERT
--                 (PLATAFORM_TYPE,            
--                 PLATAFORM_ACCOUNT,
--                 IDENTIFIER,
--                 HAS_STORE_ID,
--                 SALES_CHANNEL,
--                 AFFILIATE_ID,
--                 RELATIONSHIP_TYPES,
--                 CHANNEL,
--                 SUB_CHANNEL,
--                 PARTNER_LEVEL,
--                 GLOBAL_CHANNEL,
--                 GLOBAL_CHANNEL_EBI,
--                 BIZ_TYPE,
--                 BIZ_TYPE_EBI,
--                 AUDIENCE_TYPE,
--                 AUDIENCE_TYPE_EBI,
--                 SALES_ORG,
--                 BUSINESS_AREA,
--                 COMPANY_CODE,
--                 COUNTRY,
--                 COUNTRY_CODE,
--                 CURRENCY,
--                 CUSTOMER_TYPE,
--                 PO_MOBILE_OS,
--                 SKU_MAPPING,
--                 FILE_NAME,
--                 UPDATE_DATE,
--                 LOAD_DATE,
--                 PROCESS_DATE)
--             VALUES
--                 (M.PLATAFORM_TYPE,          
--                 M.PLATAFORM_ACCOUNT,
--                 M.IDENTIFIER,
--                 M.HAS_STORE_ID,
--                 M.SALES_CHANNEL,
--                 M.AFFILIATE_ID,
--                 M.RELATIONSHIP_TYPES,
--                 M.CHANNEL,
--                 M.SUB_CHANNEL,
--                 M.PARTNER_LEVEL,
--                 M.GLOBAL_CHANNEL,
--                 M.GLOBAL_CHANNEL_EBI,
--                 M.BIZ_TYPE,
--                 M.BIZ_TYPE_EBI,
--                 M.AUDIENCE_TYPE,
--                 M.AUDIENCE_TYPE_EBI,
--                 M.SALES_ORG,
--                 M.BUSINESS_AREA,
--                 M.COMPANY_CODE,
--                 M.COUNTRY,
--                 M.COUNTRY_CODE,
--                 M.CURRENCY,
--                 M.CUSTOMER_TYPE,
--                 M.PO_MOBILE_OS,
--                 M.SKU_MAPPING,
--                 M.FILE_NAME,
--                 M.LOAD_DATE,
--                 M.LOAD_DATE,
--                 CURRENT_TIMESTAMP);
--  
--     PERFORM UPDATE OW_MD.SALES_CHANNEL O
--         SET GLOBAL_CHANNEL_EBI = M.GLOBAL_CHANNEL_EBI,
--             BIZ_TYPE_EBI = M.BIZ_TYPE_EBI,
--             AUDIENCE_TYPE_EBI = M.AUDIENCE_TYPE_EBI,
--             FILE_NAME = M.FILE_NAME,
--             UPDATE_DATE = M.LOAD_DATE,
--             PROCESS_DATE = CURRENT_TIMESTAMP
--         FROM OW_MD.TMP_SALES_CHANNEL_LAO M 
--         WHERE    COALESCE(O.PLATAFORM_TYPE,'') = COALESCE(M.PLATAFORM_TYPE,'')
--         AND COALESCE(O.PLATAFORM_ACCOUNT,'') = COALESCE(M.PLATAFORM_ACCOUNT,'')
--         AND COALESCE(O.IDENTIFIER,'') = COALESCE(M.IDENTIFIER,'')
--         AND COALESCE(O.HAS_STORE_ID,'') = COALESCE(M.HAS_STORE_ID,'')
--         AND COALESCE(O.SALES_CHANNEL,'') = COALESCE(M.SALES_CHANNEL,'')
--         AND COALESCE(O.AFFILIATE_ID,'') = COALESCE(M.AFFILIATE_ID,'')
--         AND M.SALES_ORG = 'SEDA';
-- 
--     PERFORM DELETE FROM OW_MD.SALES_CHANNEL O 
--         WHERE O.SALES_ORG <> 'SEDA'
--         AND (COALESCE(O.PLATAFORM_TYPE,'')||COALESCE(O.PLATAFORM_ACCOUNT,'')||COALESCE(O.IDENTIFIER,'')||
--              COALESCE(O.HAS_STORE_ID,'')||COALESCE(O.SALES_CHANNEL,'')||COALESCE(O.AFFILIATE_ID,'')) 
--              NOT IN 
--             (SELECT (COALESCE(M.PLATAFORM_TYPE,'')||COALESCE(M.PLATAFORM_ACCOUNT,'')||COALESCE(M.IDENTIFIER,'')||
--                      COALESCE(M.HAS_STORE_ID,'')||COALESCE(M.SALES_CHANNEL,'')||COALESCE(M.AFFILIATE_ID,''))
--                  FROM OW_MD.TMP_SALES_CHANNEL_SEDA M
--                  WHERE M.SALES_ORG <> 'SEDA'
--                  UNION
--                  SELECT (COALESCE(N.PLATAFORM_TYPE,'')||COALESCE(N.PLATAFORM_ACCOUNT,'')||COALESCE(N.IDENTIFIER,'')||
--                      COALESCE(N.HAS_STORE_ID,'')||COALESCE(N.SALES_CHANNEL,'')||COALESCE(N.AFFILIATE_ID,''))
--                  FROM OW_MD.TMP_SALES_CHANNEL_LAO N
--                  WHERE N.SALES_ORG <> 'SEDA');
-- 
--     PERFORM DELETE FROM OW_MD.SALES_CHANNEL O 
--         WHERE O.SALES_ORG = 'SEDA'
--         AND (COALESCE(O.AFFILIATE_ID,'')||COALESCE(O.SALES_CHANNEL,'')||COALESCE(O.HAS_STORE_ID,'')) 
--              NOT IN 
--             (SELECT (COALESCE(M.AFFILIATE_ID,'')||COALESCE(M.SALES_CHANNEL,'')||COALESCE(M.HAS_STORE_ID,''))
--                  FROM OW_MD.TMP_SALES_CHANNEL_SEDA M
--                  WHERE M.SALES_ORG = 'SEDA'
--                  UNION
--                  SELECT (COALESCE(N.AFFILIATE_ID,'')||COALESCE(N.SALES_CHANNEL,'')||COALESCE(N.HAS_STORE_ID,''))
--                  FROM OW_MD.TMP_SALES_CHANNEL_LAO N
--                  WHERE N.SALES_ORG = 'SEDA');
-- 
-- END
-- $$;
-- ERROR: Severity: ROLLBACK, Message: Syntax error at or near "O", Sqlstate: 42601, Position: 8026, Routine: base_yyerror, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/scan.l, Line: 1056, Error Code: 4856, 
CREATE OR REPLACE PROCEDURE OW_MD.PROC_DIM_SALES_CHANNEL()
LANGUAGE PLvSQL AS $$
BEGIN
    
    PERFORM MERGE INTO OW_MD.SALES_CHANNEL
        USING OW_MD.TMP_SALES_CHANNEL_SEDA M
        ON    COALESCE(OW_MD.SALES_CHANNEL.AFFILIATE_ID,'') = COALESCE(M.AFFILIATE_ID,'')
        AND   COALESCE(OW_MD.SALES_CHANNEL.SALES_CHANNEL,'') = COALESCE(M.SALES_CHANNEL,'')
        AND   COALESCE(OW_MD.SALES_CHANNEL.HAS_STORE_ID,'') = COALESCE(M.HAS_STORE_ID,'')
        AND   COALESCE(OW_MD.SALES_CHANNEL.SKU_MAPPING,'') = COALESCE(M.SKU_MAPPING,'')
        AND   OW_MD.SALES_CHANNEL.SALES_ORG = 'SEDA'
        WHEN MATCHED 
            THEN
            UPDATE SET
                PLATAFORM_TYPE = M.PLATAFORM_TYPE,            
                PLATAFORM_ACCOUNT = M.PLATAFORM_ACCOUNT,
                IDENTIFIER = M.IDENTIFIER,
                RELATIONSHIP_TYPES = M.RELATIONSHIP_TYPES,
                CHANNEL = M.CHANNEL,
                SUB_CHANNEL = M.SUB_CHANNEL,
                PARTNER_LEVEL = M.PARTNER_LEVEL,
                GLOBAL_CHANNEL = M.GLOBAL_CHANNEL,
                BIZ_TYPE = M.BIZ_TYPE,
                AUDIENCE_TYPE = M.AUDIENCE_TYPE,
                SALES_ORG = M.SALES_ORG,
                BUSINESS_AREA = M.BUSINESS_AREA,
                COMPANY_CODE = M.COMPANY_CODE,
                COUNTRY = M.COUNTRY,
                COUNTRY_CODE = M.COUNTRY_CODE,
                CURRENCY = M.CURRENCY,
                CUSTOMER_TYPE = M.CUSTOMER_TYPE,
                PO_MOBILE_OS = M.PO_MOBILE_OS,
                SKU_MAPPING = M.SKU_MAPPING,
                FILE_NAME = M.FILE_NAME,
                UPDATE_DATE = M.LOAD_DATE,
                PROCESS_DATE = CURRENT_TIMESTAMP 
        WHEN NOT MATCHED 
            THEN
            INSERT
                (PLATAFORM_TYPE,            
                PLATAFORM_ACCOUNT,
                IDENTIFIER,
                HAS_STORE_ID,
                SALES_CHANNEL,
                AFFILIATE_ID,
                RELATIONSHIP_TYPES,
                CHANNEL,
                SUB_CHANNEL,
                PARTNER_LEVEL,
                GLOBAL_CHANNEL,
                GLOBAL_CHANNEL_EBI,
                BIZ_TYPE,
                BIZ_TYPE_EBI,
                AUDIENCE_TYPE,
                AUDIENCE_TYPE_EBI,
                SALES_ORG,
                BUSINESS_AREA,
                COMPANY_CODE,
                COUNTRY,
                COUNTRY_CODE,
                CURRENCY,
                CUSTOMER_TYPE,
                PO_MOBILE_OS,
                SKU_MAPPING,
                FILE_NAME,
                UPDATE_DATE,
                LOAD_DATE,
                PROCESS_DATE)
            VALUES
                (M.PLATAFORM_TYPE,          
                M.PLATAFORM_ACCOUNT,
                M.IDENTIFIER,
                M.HAS_STORE_ID,
                M.SALES_CHANNEL,
                M.AFFILIATE_ID,
                M.RELATIONSHIP_TYPES,
                M.CHANNEL,
                M.SUB_CHANNEL,
                M.PARTNER_LEVEL,
                M.GLOBAL_CHANNEL,
                M.GLOBAL_CHANNEL_EBI,
                M.BIZ_TYPE,
                M.BIZ_TYPE_EBI,
                M.AUDIENCE_TYPE,
                M.AUDIENCE_TYPE_EBI,
                M.SALES_ORG,
                M.BUSINESS_AREA,
                M.COMPANY_CODE,
                M.COUNTRY,
                M.COUNTRY_CODE,
                M.CURRENCY,
                M.CUSTOMER_TYPE,
                M.PO_MOBILE_OS,
                M.SKU_MAPPING,
                M.FILE_NAME,
                M.LOAD_DATE,
                M.LOAD_DATE,
                CURRENT_TIMESTAMP);

    PERFORM MERGE INTO OW_MD.SALES_CHANNEL
        USING OW_MD.TMP_SALES_CHANNEL_LAO M 
        ON  COALESCE(OW_MD.SALES_CHANNEL.PLATAFORM_TYPE,'') = COALESCE(M.PLATAFORM_TYPE,'')
        AND COALESCE(OW_MD.SALES_CHANNEL.PLATAFORM_ACCOUNT,'') = COALESCE(M.PLATAFORM_ACCOUNT,'')
        AND COALESCE(OW_MD.SALES_CHANNEL.IDENTIFIER,'') = COALESCE(M.IDENTIFIER,'')
        AND COALESCE(OW_MD.SALES_CHANNEL.HAS_STORE_ID,'') = COALESCE(M.HAS_STORE_ID,'')
        AND COALESCE(OW_MD.SALES_CHANNEL.SALES_CHANNEL,'') = COALESCE(M.SALES_CHANNEL,'')
        AND COALESCE(OW_MD.SALES_CHANNEL.AFFILIATE_ID,'') = COALESCE(M.AFFILIATE_ID,'')
        AND COALESCE(OW_MD.SALES_CHANNEL.SKU_MAPPING,'') = COALESCE(M.SKU_MAPPING,'')
        AND COALESCE(OW_MD.SALES_CHANNEL.COUNTRY,'') = COALESCE(M.COUNTRY,'')
        AND M.SALES_ORG <> 'SEDA'
            
        WHEN MATCHED 
            THEN
            UPDATE SET
                RELATIONSHIP_TYPES = M.RELATIONSHIP_TYPES,
                CHANNEL = M.CHANNEL,
                SUB_CHANNEL = M.SUB_CHANNEL,
                PARTNER_LEVEL = M.PARTNER_LEVEL,
                GLOBAL_CHANNEL = M.GLOBAL_CHANNEL,
                GLOBAL_CHANNEL_EBI = M.GLOBAL_CHANNEL_EBI,
                BIZ_TYPE = M.BIZ_TYPE,
                BIZ_TYPE_EBI = M.BIZ_TYPE_EBI,
                AUDIENCE_TYPE = M.AUDIENCE_TYPE,
                AUDIENCE_TYPE_EBI = M.AUDIENCE_TYPE_EBI,
                SALES_ORG = M.SALES_ORG,
                BUSINESS_AREA = M.BUSINESS_AREA,
                COMPANY_CODE = M.COMPANY_CODE,
                COUNTRY_CODE = M.COUNTRY_CODE,
                CURRENCY = M.CURRENCY,
                CUSTOMER_TYPE = M.CUSTOMER_TYPE,
                PO_MOBILE_OS = M.PO_MOBILE_OS,
                SKU_MAPPING = M.SKU_MAPPING,
                FILE_NAME = M.FILE_NAME,
                UPDATE_DATE = M.LOAD_DATE,
                PROCESS_DATE = CURRENT_TIMESTAMP 
        WHEN NOT MATCHED 
            THEN
            INSERT
                (PLATAFORM_TYPE,            
                PLATAFORM_ACCOUNT,
                IDENTIFIER,
                HAS_STORE_ID,
                SALES_CHANNEL,
                AFFILIATE_ID,
                RELATIONSHIP_TYPES,
                CHANNEL,
                SUB_CHANNEL,
                PARTNER_LEVEL,
                GLOBAL_CHANNEL,
                GLOBAL_CHANNEL_EBI,
                BIZ_TYPE,
                BIZ_TYPE_EBI,
                AUDIENCE_TYPE,
                AUDIENCE_TYPE_EBI,
                SALES_ORG,
                BUSINESS_AREA,
                COMPANY_CODE,
                COUNTRY,
                COUNTRY_CODE,
                CURRENCY,
                CUSTOMER_TYPE,
                PO_MOBILE_OS,
                SKU_MAPPING,
                FILE_NAME,
                UPDATE_DATE,
                LOAD_DATE,
                PROCESS_DATE)
            VALUES
                (M.PLATAFORM_TYPE,          
                M.PLATAFORM_ACCOUNT,
                M.IDENTIFIER,
                M.HAS_STORE_ID,
                M.SALES_CHANNEL,
                M.AFFILIATE_ID,
                M.RELATIONSHIP_TYPES,
                M.CHANNEL,
                M.SUB_CHANNEL,
                M.PARTNER_LEVEL,
                M.GLOBAL_CHANNEL,
                M.GLOBAL_CHANNEL_EBI,
                M.BIZ_TYPE,
                M.BIZ_TYPE_EBI,
                M.AUDIENCE_TYPE,
                M.AUDIENCE_TYPE_EBI,
                M.SALES_ORG,
                M.BUSINESS_AREA,
                M.COMPANY_CODE,
                M.COUNTRY,
                M.COUNTRY_CODE,
                M.CURRENCY,
                M.CUSTOMER_TYPE,
                M.PO_MOBILE_OS,
                M.SKU_MAPPING,
                M.FILE_NAME,
                M.LOAD_DATE,
                M.LOAD_DATE,
                CURRENT_TIMESTAMP);
 
    PERFORM UPDATE OW_MD.SALES_CHANNEL
        SET GLOBAL_CHANNEL_EBI = M.GLOBAL_CHANNEL_EBI,
            BIZ_TYPE_EBI = M.BIZ_TYPE_EBI,
            AUDIENCE_TYPE_EBI = M.AUDIENCE_TYPE_EBI,
            FILE_NAME = M.FILE_NAME,
            UPDATE_DATE = M.LOAD_DATE,
            PROCESS_DATE = CURRENT_TIMESTAMP
        FROM OW_MD.TMP_SALES_CHANNEL_LAO M 
        WHERE    COALESCE(OW_MD.SALES_CHANNEL.PLATAFORM_TYPE,'') = COALESCE(M.PLATAFORM_TYPE,'')
        AND COALESCE(OW_MD.SALES_CHANNEL.PLATAFORM_ACCOUNT,'') = COALESCE(M.PLATAFORM_ACCOUNT,'')
        AND COALESCE(OW_MD.SALES_CHANNEL.IDENTIFIER,'') = COALESCE(M.IDENTIFIER,'')
        AND COALESCE(OW_MD.SALES_CHANNEL.HAS_STORE_ID,'') = COALESCE(M.HAS_STORE_ID,'')
        AND COALESCE(OW_MD.SALES_CHANNEL.SALES_CHANNEL,'') = COALESCE(M.SALES_CHANNEL,'')
        AND COALESCE(OW_MD.SALES_CHANNEL.AFFILIATE_ID,'') = COALESCE(M.AFFILIATE_ID,'')
        AND M.SALES_ORG = 'SEDA';

    PERFORM DELETE FROM OW_MD.SALES_CHANNEL 
        WHERE SALES_ORG <> 'SEDA'
        AND (COALESCE(PLATAFORM_TYPE,'')||COALESCE(PLATAFORM_ACCOUNT,'')||COALESCE(IDENTIFIER,'')||
             COALESCE(HAS_STORE_ID,'')||COALESCE(SALES_CHANNEL,'')||COALESCE(AFFILIATE_ID,'')) 
             NOT IN 
            (SELECT (COALESCE(M.PLATAFORM_TYPE,'')||COALESCE(M.PLATAFORM_ACCOUNT,'')||COALESCE(M.IDENTIFIER,'')||
                     COALESCE(M.HAS_STORE_ID,'')||COALESCE(M.SALES_CHANNEL,'')||COALESCE(M.AFFILIATE_ID,''))
                 FROM OW_MD.TMP_SALES_CHANNEL_SEDA M
                 WHERE M.SALES_ORG <> 'SEDA'
                 UNION
                 SELECT (COALESCE(N.PLATAFORM_TYPE,'')||COALESCE(N.PLATAFORM_ACCOUNT,'')||COALESCE(N.IDENTIFIER,'')||
                     COALESCE(N.HAS_STORE_ID,'')||COALESCE(N.SALES_CHANNEL,'')||COALESCE(N.AFFILIATE_ID,''))
                 FROM OW_MD.TMP_SALES_CHANNEL_LAO N
                 WHERE N.SALES_ORG <> 'SEDA');

    PERFORM DELETE FROM OW_MD.SALES_CHANNEL 
        WHERE SALES_ORG = 'SEDA'
        AND (COALESCE(AFFILIATE_ID,'')||COALESCE(SALES_CHANNEL,'')||COALESCE(HAS_STORE_ID,'')) 
             NOT IN 
            (SELECT (COALESCE(M.AFFILIATE_ID,'')||COALESCE(M.SALES_CHANNEL,'')||COALESCE(M.HAS_STORE_ID,''))
                 FROM OW_MD.TMP_SALES_CHANNEL_SEDA M
                 WHERE M.SALES_ORG = 'SEDA'
                 UNION
                 SELECT (COALESCE(N.AFFILIATE_ID,'')||COALESCE(N.SALES_CHANNEL,'')||COALESCE(N.HAS_STORE_ID,''))
                 FROM OW_MD.TMP_SALES_CHANNEL_LAO N
                 WHERE N.SALES_ORG = 'SEDA');

END
$$;

CALL OW_MD.PROC_DIM_SALES_CHANNEL();
-- PROC_DIM_SALES_CHANNEL
-- ----------------------
-- 0

