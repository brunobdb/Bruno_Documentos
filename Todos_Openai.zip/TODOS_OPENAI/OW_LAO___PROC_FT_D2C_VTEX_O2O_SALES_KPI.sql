CREATE OR REPLACE PROCEDURE OW_LAO.PROC_FT_D2C_VTEX_O2O_SALES_KPI()
LANGUAGE PLvSQL AS $$
BEGIN
  PERFORM CALL OW_LAO.PROC_D2C_VTEX_O2O_SALES_KPI();
END;
$$;

-- CALL OW_LAO.PROC_FT_D2C_VTEX_O2O_SALES_KPI();
-- ERROR: Severity: ERROR, Message: Function OW_LAO.PROC_D2C_VTEX_O2O_SALES_KPI() does not exist, or permission is denied for OW_LAO.PROC_D2C_VTEX_O2O_SALES_KPI(), Sqlstate: 42883, Hint: No function matches the given name and argument types. You may need to add explicit type casts, Where: PL/vSQL procedure PROC_FT_D2C_VTEX_O2O_SALES_KPI line 3 at static SQL, Routine: throwErrorFunctionDoesNotMatch, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/ParseFunc.cpp, Line: 4559, Error Code: 3457, 
-- CALL OW_LAO.PROC_FT_D2C_VTEX_O2O_SALES_KPI();
-- ERROR: Severity: ERROR, Message: Function OW_LAO.PROC_D2C_VTEX_O2O_SALES_KPI() does not exist, or permission is denied for OW_LAO.PROC_D2C_VTEX_O2O_SALES_KPI(), Sqlstate: 42883, Hint: No function matches the given name and argument types. You may need to add explicit type casts, Where: PL/vSQL procedure PROC_FT_D2C_VTEX_O2O_SALES_KPI line 3 at static SQL, Routine: throwErrorFunctionDoesNotMatch, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/ParseFunc.cpp, Line: 4559, Error Code: 3457, 
CREATE OR REPLACE PROCEDURE OW_LAO.PROC_FT_D2C_VTEX_O2O_SALES_KPI()
LANGUAGE PLvSQL AS $$
DECLARE v_cnt INT;
BEGIN
  SELECT COUNT(*) INTO v_cnt FROM v_catalog.procedures 
   WHERE schema_name = 'OW_LAO' AND procedure_name = 'PROC_D2C_VTEX_O2O_SALES_KPI';
  IF v_cnt > 0 THEN
    PERFORM CALL OW_LAO.PROC_D2C_VTEX_O2O_SALES_KPI();
  END IF;
END;
$$;

-- CALL OW_LAO.PROC_FT_D2C_VTEX_O2O_SALES_KPI();
-- ERROR: Severity: ERROR, Message: Relation "v_catalog.procedures" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_FT_D2C_VTEX_O2O_SALES_KPI line 4 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
-- CALL OW_LAO.PROC_FT_D2C_VTEX_O2O_SALES_KPI();
-- ERROR: Severity: ERROR, Message: Relation "v_catalog.procedures" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_FT_D2C_VTEX_O2O_SALES_KPI line 4 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
