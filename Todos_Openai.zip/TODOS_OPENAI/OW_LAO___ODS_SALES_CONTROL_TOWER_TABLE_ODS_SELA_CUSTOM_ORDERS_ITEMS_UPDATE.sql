LANGUAGE PLvSQL AS $$
BEGIN
 
  PERFORM CREATE LOCAL TEMP TABLE ods_sales_ctrl_twr_ods_sela_items_upd_prep ON COMMIT PRESERVE ROWS AS
    SELECT a.subsidiary_id    AS client_subsidiary_id
         , a.account          AS po_sitecode
         , a.order_id         AS po_orderid
         , a.code             AS po_sku
         , a.delivered_date   AS nerp_billingdate
         , a.invoice_date     AS so_date
         , a.delivered_date   AS do_date
         , a.delivered_date   AS billing_date_local
      FROM ow_lao.ods_sela_custom_orders_items a
     WHERE (a.delivered_date IS NOT NULL OR a.invoice_date IS NOT NULL);
        
  PERFORM UPDATE ow_lao.ods_sales_control_tower_table a
     SET nerp_billingdate   = CAST(b.nerp_billingdate AS DATE)
       , so_date            = CAST(b.so_date AS DATE)
       , do_date            = CAST(b.do_date AS DATE)
       , billing_date_local = CAST(b.billing_date_local AS DATE)
    FROM ods_sales_ctrl_twr_ods_sela_items_upd_prep b
   WHERE b.po_orderid           = a.po_orderid
     AND b.po_sku               = a.po_sku
     AND b.client_subsidiary_id = a.client_subsidiary_id
     AND b.po_sitecode          = a.po_sitecode; 
 
END;
$$;

-- CALL ow_lao.ods_sales_control_tower_table_ods_sela_custom_orders_items_update();
-- ods_sales_control_tower_table_ods_sela_custom_orders_items_update
-- -----------------------------------------------------------------
-- 0