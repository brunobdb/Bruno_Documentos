CREATE OR REPLACE PROCEDURE OW_LAO.PROC_SALES_DEDUCTION_NERP_AL11_VALIDATION()
LANGUAGE PLvSQL AS $$
DECLARE 
    DAY_OF_WEEK VARCHAR(20); 
    LOAD_DATE_CHECK DATE;
BEGIN
    
    -- Truncate table to validate files uploaded to AL11
    PERFORM TRUNCATE TABLE OW_LAO.FT_NERP_AL11_VALIDATION;
    
    -- Populate validation table for files uploaded to AL11
    PERFORM INSERT INTO OW_LAO.FT_NERP_AL11_VALIDATION
    	   SELECT  FILE_NAME_PROCESSED
					,TO_DATE(SUBSTRING(FILE_NAME_PROCESSED,25,8),'YYYYMMDD') AS DATA_FILE
				    ,SUBSTRING(FILE_NAME_PROCESSED,15,4) AS COMPANY_CODE
					,SUBSTRING(FILE_NAME_PROCESSED,20,4) AS BUSINESS_AREA
					 , (CASE WHEN FILE_NAME_PROCESSED LIKE '%5555999%'
						THEN 'FOTA_01W_05W'
							WHEN FILE_NAME_PROCESSED LIKE '%0105999%'
						THEN 'EDI_01W_05W'
							WHEN FILE_NAME_PROCESSED LIKE '%0610999%'
						THEN 'EDI_06W_10W'
						ELSE NULL 
						END) AS "CLASSIFICATION"
					,SUBSTRING(FILE_NAME_PROCESSED,47,7) AS STATUS_AL11
					,NULL AS FLAG_TO_SEND_FILES
					,FILE_NAME AS FILE_NAME_RPA
					,LOAD_DATE AS LOAD_DATE_RPA
					,CURRENT_DATE AS LOAD_DATE 
					
			FROM OW_LAO.ODS_NERP_AL11_MCS_SEN onams 
			WHERE TO_DATE(LAST_CHANGED_ON,'DD/MM/YYYY') = (
			    SELECT MAX(TO_DATE(LAST_CHANGED_ON,'DD/MM/YYYY')) 
			    FROM OW_LAO.ODS_NERP_AL11_MCS_SEN
			)
			AND (CASE WHEN FILE_NAME_PROCESSED LIKE '%5555999%'
						THEN 'FOTA_01W_05W'
							WHEN FILE_NAME_PROCESSED LIKE '%0105999%'
						THEN 'EDI_01W_05W'
							WHEN FILE_NAME_PROCESSED LIKE '%0610999%'
						THEN 'EDI_06W_10W'
						ELSE NULL 
				END) IS NOT NULL 			
			ORDER BY SUBSTRING(FILE_NAME_PROCESSED,15,4)
					,SUBSTRING(FILE_NAME_PROCESSED,20,4)
			;
    
    -- FLAG TO SEND 3 FILES C390, 390A
    PERFORM UPDATE OW_LAO.FT_NERP_AL11_VALIDATION FNAV
    SET FNAV.FLAG_TO_SEND_FILES = 'OK'
    WHERE (
        SELECT 
            SUM(CASE 
                    WHEN FNAV.DATA_FILE = (CASE WHEN (TRIM(TO_CHAR(CURRENT_DATE,'DAY')) = 'TUESDAY') THEN CURRENT_DATE ELSE TIMESTAMPADD(DAY,-1,CURRENT_DATE) END)
                         AND FNAV.COMPANY_CODE = 'C390'
                         AND FNAV.BUSINESS_AREA = '390A'
                         AND FNAV.STATUS_AL11 = 'SUCCESS'
                         AND FNAV."CLASSIFICATION" = 'FOTA_01W_05W' THEN 1
                    WHEN FNAV.DATA_FILE = (CASE WHEN (TRIM(TO_CHAR(CURRENT_DATE,'DAY')) = 'TUESDAY') THEN CURRENT_DATE ELSE TIMESTAMPADD(DAY,-1,CURRENT_DATE) END)
                         AND FNAV.COMPANY_CODE = 'C390'
                         AND FNAV.BUSINESS_AREA = '390A'
                         AND FNAV.STATUS_AL11 = 'SUCCESS'
                         AND FNAV."CLASSIFICATION" = 'EDI_01W_05W' THEN 1
                    WHEN FNAV.DATA_FILE = (CASE WHEN (TRIM(TO_CHAR(CURRENT_DATE,'DAY')) = 'TUESDAY') THEN CURRENT_DATE ELSE TIMESTAMPADD(DAY,-1,CURRENT_DATE) END)
                         AND FNAV.COMPANY_CODE = 'C390'
                         AND FNAV.BUSINESS_AREA = '390A'
                         AND FNAV.STATUS_AL11 = 'SUCCESS'
                         AND FNAV."CLASSIFICATION" = 'EDI_06W_10W' THEN 1
                    ELSE 0
                END) AS QTD
        FROM OW_LAO.FT_NERP_AL11_VALIDATION FNAV
    ) = 3
    AND FNAV.COMPANY_CODE = 'C390'
    AND FNAV.BUSINESS_AREA = '390A'
    ;
    
    -- FLAG TO SEND 3 FILES C810, 810A
    PERFORM UPDATE OW_LAO.FT_NERP_AL11_VALIDATION FNAV
    SET FNAV.FLAG_TO_SEND_FILES = 'OK'
    WHERE (
        SELECT 
            SUM(CASE 
                    WHEN FNAV.DATA_FILE = (CASE WHEN (TRIM(TO_CHAR(CURRENT_DATE,'DAY')) = 'TUESDAY') THEN CURRENT_DATE ELSE TIMESTAMPADD(DAY,-1,CURRENT_DATE) END)
                         AND FNAV.COMPANY_CODE = 'C810'
                         AND FNAV.BUSINESS_AREA = '810A'
                         AND FNAV.STATUS_AL11 = 'SUCCESS'
                         AND FNAV."CLASSIFICATION" = 'FOTA_01W_05W' THEN 1
                    WHEN FNAV.DATA_FILE = (CASE WHEN (TRIM(TO_CHAR(CURRENT_DATE,'DAY')) = 'TUESDAY') THEN CURRENT_DATE ELSE TIMESTAMPADD(DAY,-1,CURRENT_DATE) END)
                         AND FNAV.COMPANY_CODE = 'C810'
                         AND FNAV.BUSINESS_AREA = '810A'
                         AND FNAV.STATUS_AL11 = 'SUCCESS'
                         AND FNAV."CLASSIFICATION" = 'EDI_01W_05W' THEN 1
                    WHEN FNAV.DATA_FILE = (CASE WHEN (TRIM(TO_CHAR(CURRENT_DATE,'DAY')) = 'TUESDAY') THEN CURRENT_DATE ELSE TIMESTAMPADD(DAY,-1,CURRENT_DATE) END)
                         AND FNAV.COMPANY_CODE = 'C810'
                         AND FNAV.BUSINESS_AREA = '810A'
                         AND FNAV.STATUS_AL11 = 'SUCCESS'
                         AND FNAV."CLASSIFICATION" = 'EDI_06W_10W' THEN 1
                    ELSE 0
                END) AS QTD
        FROM OW_LAO.FT_NERP_AL11_VALIDATION FNAV
    ) = 3
    AND FNAV.COMPANY_CODE = 'C810'
    AND FNAV.BUSINESS_AREA = '810A'
    ;
    
    -- FLAG TO SEND 3 FILES C810, 810C
    PERFORM UPDATE OW_LAO.FT_NERP_AL11_VALIDATION FNAV
    SET FNAV.FLAG_TO_SEND_FILES = 'OK'
    WHERE (
        SELECT 
            SUM(CASE 
                    WHEN FNAV.DATA_FILE = (CASE WHEN (TRIM(TO_CHAR(CURRENT_DATE,'DAY')) = 'TUESDAY') THEN CURRENT_DATE ELSE TIMESTAMPADD(DAY,-1,CURRENT_DATE) END)
                         AND FNAV.COMPANY_CODE = 'C810'
                         AND FNAV.BUSINESS_AREA = '810C'
                         AND FNAV.STATUS_AL11 = 'SUCCESS'
                         AND FNAV."CLASSIFICATION" = 'FOTA_01W_05W' THEN 1
                    WHEN FNAV.DATA_FILE = (CASE WHEN (TRIM(TO_CHAR(CURRENT_DATE,'DAY')) = 'TUESDAY') THEN CURRENT_DATE ELSE TIMESTAMPADD(DAY,-1,CURRENT_DATE) END)
                         AND FNAV.COMPANY_CODE = 'C810'
                         AND FNAV.BUSINESS_AREA = '810C'
                         AND FNAV.STATUS_AL11 = 'SUCCESS'
                         AND FNAV."CLASSIFICATION" = 'EDI_01W_05W' THEN 1
                    WHEN FNAV.DATA_FILE = (CASE WHEN (TRIM(TO_CHAR(CURRENT_DATE,'DAY')) = 'TUESDAY') THEN CURRENT_DATE ELSE TIMESTAMPADD(DAY,-1,CURRENT_DATE) END)
                         AND FNAV.COMPANY_CODE = 'C810'
                         AND FNAV.BUSINESS_AREA = '810C'
                         AND FNAV.STATUS_AL11 = 'SUCCESS'
                         AND FNAV."CLASSIFICATION" = 'EDI_06W_10W' THEN 1
                    ELSE 0
                END) AS QTD
        FROM OW_LAO.FT_NERP_AL11_VALIDATION FNAV
    ) = 3
    AND FNAV.COMPANY_CODE = 'C810'
    AND FNAV.BUSINESS_AREA = '810C'
    ;

    -- FLAG TO SEND 3 FILES C810, 810D
    PERFORM UPDATE OW_LAO.FT_NERP_AL11_VALIDATION FNAV
    SET FNAV.FLAG_TO_SEND_FILES = 'OK'
    WHERE (
        SELECT 
            SUM(CASE 
                    WHEN FNAV.DATA_FILE = (CASE WHEN (TRIM(TO_CHAR(CURRENT_DATE,'DAY')) = 'TUESDAY') THEN CURRENT_DATE ELSE TIMESTAMPADD(DAY,-1,CURRENT_DATE) END)
                         AND FNAV.COMPANY_CODE = 'C810'
                         AND FNAV.BUSINESS_AREA = '810D'
                         AND FNAV.STATUS_AL11 = 'SUCCESS'
                         AND FNAV."CLASSIFICATION" = 'FOTA_01W_05W' THEN 1
                    WHEN FNAV.DATA_FILE = (CASE WHEN (TRIM(TO_CHAR(CURRENT_DATE,'DAY')) = 'TUESDAY') THEN CURRENT_DATE ELSE TIMESTAMPADD(DAY,-1,CURRENT_DATE) END)
                         AND FNAV.COMPANY_CODE = 'C810'
                         AND FNAV.BUSINESS_AREA = '810D'
                         AND FNAV.STATUS_AL11 = 'SUCCESS'
                         AND FNAV."CLASSIFICATION" = 'EDI_01W_05W' THEN 1
                    WHEN FNAV.DATA_FILE = (CASE WHEN (TRIM(TO_CHAR(CURRENT_DATE,'DAY')) = 'TUESDAY') THEN CURRENT_DATE ELSE TIMESTAMPADD(DAY,-1,CURRENT_DATE) END)
                         AND FNAV.COMPANY_CODE = 'C810'
                         AND FNAV.BUSINESS_AREA = '810D'
                         AND FNAV.STATUS_AL11 = 'SUCCESS'
                         AND FNAV."CLASSIFICATION" = 'EDI_06W_10W' THEN 1
                    ELSE 0
                END) AS QTD
        FROM OW_LAO.FT_NERP_AL11_VALIDATION FNAV
    ) = 3
    AND FNAV.COMPANY_CODE = 'C810'
    AND FNAV.BUSINESS_AREA = '810D'
    ;

    -- FLAG TO SEND 3 FILES C810, 810F
    PERFORM UPDATE OW_LAO.FT_NERP_AL11_VALIDATION FNAV
    SET FNAV.FLAG_TO_SEND_FILES = 'OK'
    WHERE (
        SELECT 
            SUM(CASE 
                    WHEN FNAV.DATA_FILE = (CASE WHEN (TRIM(TO_CHAR(CURRENT_DATE,'DAY')) = 'TUESDAY') THEN CURRENT_DATE ELSE TIMESTAMPADD(DAY,-1,CURRENT_DATE) END)
                         AND FNAV.COMPANY_CODE = 'C810'
                         AND FNAV.BUSINESS_AREA = '810F'
                         AND FNAV.STATUS_AL11 = 'SUCCESS'
                         AND FNAV."CLASSIFICATION" = 'FOTA_01W_05W' THEN 1
                    WHEN FNAV.DATA_FILE = (CASE WHEN (TRIM(TO_CHAR(CURRENT_DATE,'DAY')) = 'TUESDAY') THEN CURRENT_DATE ELSE TIMESTAMPADD(DAY,-1,CURRENT_DATE) END)
                         AND FNAV.COMPANY_CODE = 'C810'
                         AND FNAV.BUSINESS_AREA = '810F'
                         AND FNAV.STATUS_AL11 = 'SUCCESS'
                         AND FNAV."CLASSIFICATION" = 'EDI_01W_05W' THEN 1
                    WHEN FNAV.DATA_FILE = (CASE WHEN (TRIM(TO_CHAR(CURRENT_DATE,'DAY')) = 'TUESDAY') THEN CURRENT_DATE ELSE TIMESTAMPADD(DAY,-1,CURRENT_DATE) END)
                         AND FNAV.COMPANY_CODE = 'C810'
                         AND FNAV.BUSINESS_AREA = '810F'
                         AND FNAV.STATUS_AL11 = 'SUCCESS'
                         AND FNAV."CLASSIFICATION" = 'EDI_06W_10W' THEN 1
                    ELSE 0
                END) AS QTD
        FROM OW_LAO.FT_NERP_AL11_VALIDATION FNAV
    ) = 3
    AND FNAV.COMPANY_CODE = 'C810'
    AND FNAV.BUSINESS_AREA = '810F'
    ;

    -- FLAG TO SEND 3 FILES C810, 810J
    PERFORM UPDATE OW_LAO.FT_NERP_AL11_VALIDATION FNAV
    SET FNAV.FLAG_TO_SEND_FILES = 'OK'
    WHERE (
        SELECT 
            SUM(CASE 
                    WHEN FNAV.DATA_FILE = (CASE WHEN (TRIM(TO_CHAR(CURRENT_DATE,'DAY')) = 'TUESDAY') THEN CURRENT_DATE ELSE TIMESTAMPADD(DAY,-1,CURRENT_DATE) END)
                         AND FNAV.COMPANY_CODE = 'C810'
                         AND FNAV.BUSINESS_AREA = '810J'
                         AND FNAV.STATUS_AL11 = 'SUCCESS'
                         AND FNAV."CLASSIFICATION" = 'FOTA_01W_05W' THEN 1
                    WHEN FNAV.DATA_FILE = (CASE WHEN (TRIM(TO_CHAR(CURRENT_DATE,'DAY')) = 'TUESDAY') THEN CURRENT_DATE ELSE TIMESTAMPADD(DAY,-1,CURRENT_DATE) END)
                         AND FNAV.COMPANY_CODE = 'C810'
                         AND FNAV.BUSINESS_AREA = '810J'
                         AND FNAV.STATUS_AL11 = 'SUCCESS'
                         AND FNAV."CLASSIFICATION" = 'EDI_01W_05W' THEN 1
                    WHEN FNAV.DATA_FILE = (CASE WHEN (TRIM(TO_CHAR(CURRENT_DATE,'DAY')) = 'TUESDAY') THEN CURRENT_DATE ELSE TIMESTAMPADD(DAY,-1,CURRENT_DATE) END)
                         AND FNAV.COMPANY_CODE = 'C810'
                         AND FNAV.BUSINESS_AREA = '810J'
                         AND FNAV.STATUS_AL11 = 'SUCCESS'
                         AND FNAV."CLASSIFICATION" = 'EDI_06W_10W' THEN 1
                    ELSE 0
                END) AS QTD
        FROM OW_LAO.FT_NERP_AL11_VALIDATION FNAV
    ) = 3
    AND FNAV.COMPANY_CODE = 'C810'
    AND FNAV.BUSINESS_AREA = '810J'
    ;

    -- FLAG TO SEND 2 FILES C810, 810M
    PERFORM UPDATE OW_LAO.FT_NERP_AL11_VALIDATION FNAV
    SET FNAV.FLAG_TO_SEND_FILES = 'OK'
    WHERE (
        SELECT 
            SUM(CASE 
                    WHEN FNAV.DATA_FILE = (CASE WHEN (TRIM(TO_CHAR(CURRENT_DATE,'DAY')) = 'TUESDAY') THEN CURRENT_DATE ELSE TIMESTAMPADD(DAY,-1,CURRENT_DATE) END)
                         AND FNAV.COMPANY_CODE = 'C810'
                         AND FNAV.BUSINESS_AREA = '810M'
                         AND FNAV.STATUS_AL11 = 'SUCCESS'
                         AND FNAV."CLASSIFICATION" = 'EDI_01W_05W' THEN 1
                    WHEN FNAV.DATA_FILE = (CASE WHEN (TRIM(TO_CHAR(CURRENT_DATE,'DAY')) = 'TUESDAY') THEN CURRENT_DATE ELSE TIMESTAMPADD(DAY,-1,CURRENT_DATE) END)
                         AND FNAV.COMPANY_CODE = 'C810'
                         AND FNAV.BUSINESS_AREA = '810M'
                         AND FNAV.STATUS_AL11 = 'SUCCESS'
                         AND FNAV."CLASSIFICATION" = 'EDI_06W_10W' THEN 1
                    ELSE 0
                END) AS QTD
        FROM OW_LAO.FT_NERP_AL11_VALIDATION FNAV
    ) = 2
    AND FNAV.COMPANY_CODE = 'C810'
    AND FNAV.BUSINESS_AREA = '810M'
    ;

    -- FLAG TO SEND 2 FILES C813, 813A
    PERFORM UPDATE OW_LAO.FT_NERP_AL11_VALIDATION FNAV
    SET FNAV.FLAG_TO_SEND_FILES = 'OK'
    WHERE (
        SELECT 
            SUM(CASE 
                    WHEN FNAV.DATA_FILE = (CASE WHEN (TRIM(TO_CHAR(CURRENT_DATE,'DAY')) = 'TUESDAY') THEN CURRENT_DATE ELSE TIMESTAMPADD(DAY,-1,CURRENT_DATE) END)
                         AND FNAV.COMPANY_CODE = 'C813'
                         AND FNAV.BUSINESS_AREA = '813A'
                         AND FNAV.STATUS_AL11 = 'SUCCESS'
                         AND FNAV."CLASSIFICATION" = 'EDI_01W_05W' THEN 1
                    WHEN FNAV.DATA_FILE = (CASE WHEN (TRIM(TO_CHAR(CURRENT_DATE,'DAY')) = 'TUESDAY') THEN CURRENT_DATE ELSE TIMESTAMPADD(DAY,-1,CURRENT_DATE) END)
                         AND FNAV.COMPANY_CODE = 'C813'
                         AND FNAV.BUSINESS_AREA = '813A'
                         AND FNAV.STATUS_AL11 = 'SUCCESS'
                         AND FNAV."CLASSIFICATION" = 'EDI_06W_10W' THEN 1
                    ELSE 0
                END) AS QTD
        FROM OW_LAO.FT_NERP_AL11_VALIDATION FNAV
    ) = 2
    AND FNAV.COMPANY_CODE = 'C813'
    AND FNAV.BUSINESS_AREA = '813A'
    ;

    -- FLAG TO SEND 3 FILES C850, 850A
    PERFORM UPDATE OW_LAO.FT_NERP_AL11_VALIDATION FNAV
    SET FNAV.FLAG_TO_SEND_FILES = 'OK'
    WHERE (
        SELECT 
            SUM(CASE 
                    WHEN FNAV.DATA_FILE = (CASE WHEN (TRIM(TO_CHAR(CURRENT_DATE,'DAY')) = 'TUESDAY') THEN CURRENT_DATE ELSE TIMESTAMPADD(DAY,-1,CURRENT_DATE) END)
                         AND FNAV.COMPANY_CODE = 'C850'
                         AND FNAV.BUSINESS_AREA = '850A'
                         AND FNAV.STATUS_AL11 = 'SUCCESS'
                         AND FNAV."CLASSIFICATION" = 'FOTA_01W_05W' THEN 1
                    WHEN FNAV.DATA_FILE = (CASE WHEN (TRIM(TO_CHAR(CURRENT_DATE,'DAY')) = 'TUESDAY') THEN CURRENT_DATE ELSE TIMESTAMPADD(DAY,-1,CURRENT_DATE) END)
                         AND FNAV.COMPANY_CODE = 'C850'
                         AND FNAV.BUSINESS_AREA = '850A'
                         AND FNAV.STATUS_AL11 = 'SUCCESS'
                         AND FNAV."CLASSIFICATION" = 'EDI_01W_05W' THEN 1
                    WHEN FNAV.DATA_FILE = (CASE WHEN (TRIM(TO_CHAR(CURRENT_DATE,'DAY')) = 'TUESDAY') THEN CURRENT_DATE ELSE TIMESTAMPADD(DAY,-1,CURRENT_DATE) END)
                         AND FNAV.COMPANY_CODE = 'C850'
                         AND FNAV.BUSINESS_AREA = '850A'
                         AND FNAV.STATUS_AL11 = 'SUCCESS'
                         AND FNAV."CLASSIFICATION" = 'EDI_06W_10W' THEN 1
                    ELSE 0
                END) AS QTD
        FROM OW_LAO.FT_NERP_AL11_VALIDATION FNAV
    ) = 3
    AND FNAV.COMPANY_CODE = 'C850'
    AND FNAV.BUSINESS_AREA = '850A'
    ;

    -- FLAG TO SEND 3 FILES C860, 860A
    PERFORM UPDATE OW_LAO.FT_NERP_AL11_VALIDATION FNAV
    SET FNAV.FLAG_TO_SEND_FILES = 'OK'
    WHERE (
        SELECT 
            SUM(CASE 
                    WHEN FNAV.DATA_FILE = (CASE WHEN (TRIM(TO_CHAR(CURRENT_DATE,'DAY')) = 'TUESDAY') THEN CURRENT_DATE ELSE TIMESTAMPADD(DAY,-1,CURRENT_DATE) END)
                         AND FNAV.COMPANY_CODE = 'C860'
                         AND FNAV.BUSINESS_AREA = '860A'
                         AND FNAV.STATUS_AL11 = 'SUCCESS'
                         AND FNAV."CLASSIFICATION" = 'FOTA_01W_05W' THEN 1
                    WHEN FNAV.DATA_FILE = (CASE WHEN (TRIM(TO_CHAR(CURRENT_DATE,'DAY')) = 'TUESDAY') THEN CURRENT_DATE ELSE TIMESTAMPADD(DAY,-1,CURRENT_DATE) END)
                         AND FNAV.COMPANY_CODE = 'C860'
                         AND FNAV.BUSINESS_AREA = '860A'
                         AND FNAV.STATUS_AL11 = 'SUCCESS'
                         AND FNAV."CLASSIFICATION" = 'EDI_01W_05W' THEN 1
                    WHEN FNAV.DATA_FILE = (CASE WHEN (TRIM(TO_CHAR(CURRENT_DATE,'DAY')) = 'TUESDAY') THEN CURRENT_DATE ELSE TIMESTAMPADD(DAY,-1,CURRENT_DATE) END)
                         AND FNAV.COMPANY_CODE = 'C860'
                         AND FNAV.BUSINESS_AREA = '860A'
                         AND FNAV.STATUS_AL11 = 'SUCCESS'
                         AND FNAV."CLASSIFICATION" = 'EDI_06W_10W' THEN 1
                    ELSE 0
                END) AS QTD
        FROM OW_LAO.FT_NERP_AL11_VALIDATION FNAV
    ) = 3
    AND FNAV.COMPANY_CODE = 'C860'
    AND FNAV.BUSINESS_AREA = '860A'
    ;

    -- Determine day of week and load date
    SELECT TRIM(TO_CHAR(CURRENT_DATE,'DAY')) INTO DAY_OF_WEEK;
    SELECT CURRENT_DATE INTO LOAD_DATE_CHECK;

    -- If today is Tuesday
    IF DAY_OF_WEEK = 'TUESDAY' THEN
        -- If today's load_date is not present in the table or table is empty
        IF (LOAD_DATE_CHECK <> COALESCE((SELECT MAX(LOAD_DATE) FROM OW_LAO.FT_LAO_SALES_DEDUCTION_AL11_VALIDATION_TO_MOVE_FILE), DATE '1900-01-01')
            OR (SELECT MAX(LOAD_DATE) FROM OW_LAO.FT_LAO_SALES_DEDUCTION_AL11_VALIDATION_TO_MOVE_FILE) IS NULL) THEN 
            
            -- Truncate table before loading
            PERFORM TRUNCATE TABLE OW_LAO.FT_LAO_SALES_DEDUCTION_AL11_VALIDATION_TO_MOVE_FILE;
            
            -- Insert today's records
            PERFORM INSERT INTO OW_LAO.FT_LAO_SALES_DEDUCTION_AL11_VALIDATION_TO_MOVE_FILE 
                  SELECT DISTINCT 
                        VL.COMPANY_CODE
                        ,VL.BUSINESS_AREA
                        ,'E:\Shared\LAO\LAO\SALES DEDUCTION\Condition_Calc\INPUT\GENERATE\' || VL.BUSINESS_AREA || '_' || DC.YYYYWW || '_' || DC.SUR_KEY || '.xlsx' AS "SOURCE_FILE_FOLDER"
                        ,COUNT(VL.FLAG_TO_SEND_FILES) AS "COUNT_TOTAL"
                        ,NULL AS "MOVE_FILES"
                        ,NULL AS "CHECK_SO"
                        ,VL.LOAD_DATE 
                  FROM OW_LAO.FT_NERP_AL11_VALIDATION VL
                  LEFT JOIN OW_MD.DIM_CALENDAR DC
                  ON (TIMESTAMPADD(DAY, -1, CURRENT_DATE) = DC.YYYYMMDD)
                  WHERE VL.LOAD_DATE = CURRENT_DATE
                  GROUP BY 
                        VL.COMPANY_CODE
                        ,VL.BUSINESS_AREA
                        ,'E:\Shared\LAO\LAO\SALES DEDUCTION\Condition_Calc\INPUT\GENERATE\' || VL.BUSINESS_AREA || '_' || DC.YYYYWW || '_' || DC.SUR_KEY || '.xlsx'
                        ,NULL
                        ,NULL 
                        ,VL.LOAD_DATE
                  ORDER BY
                        VL.COMPANY_CODE ASC,
                        VL.BUSINESS_AREA ASC;
        ELSE
            PERFORM MERGE INTO OW_LAO.FT_LAO_SALES_DEDUCTION_AL11_VALIDATION_TO_MOVE_FILE AS DESTINO
                  USING (
                        SELECT DISTINCT 
                              VL.COMPANY_CODE
                              ,VL.BUSINESS_AREA
                              ,'E:\Shared\LAO\LAO\SALES DEDUCTION\Condition_Calc\INPUT\GENERATE\' || VL.BUSINESS_AREA || '_' || DC.YYYYWW || '_' || DC.SUR_KEY || '.xlsx' AS "SOURCE_FILE_FOLDER"
                              ,COUNT(VL.FLAG_TO_SEND_FILES) AS "COUNT_TOTAL"
                              ,NULL AS "MOVE_FILES"
                              ,NULL AS "CHECK_SO"
                              ,VL.LOAD_DATE
                        FROM OW_LAO.FT_NERP_AL11_VALIDATION VL
                        LEFT JOIN OW_MD.DIM_CALENDAR DC
                        ON (TIMESTAMPADD(DAY, -1, CURRENT_DATE) = DC.YYYYMMDD)
                        WHERE VL.LOAD_DATE = CURRENT_DATE
                        GROUP BY 
                              VL.COMPANY_CODE
                              ,VL.BUSINESS_AREA
                              ,'E:\Shared\LAO\LAO\SALES DEDUCTION\Condition_Calc\INPUT\GENERATE\' || VL.BUSINESS_AREA || '_' || DC.YYYYWW || '_' || DC.SUR_KEY || '.xlsx'
                              ,NULL
                              ,NULL
                              ,VL.LOAD_DATE
                        ORDER BY
                              VL.COMPANY_CODE ASC,
                              VL.BUSINESS_AREA ASC
                  ) AS ORIGEM 
                  ON DESTINO.COMPANY_CODE = ORIGEM.COMPANY_CODE
                  AND DESTINO.BUSINESS_AREA = ORIGEM.BUSINESS_AREA
                  WHEN MATCHED THEN 
                      UPDATE SET DESTINO.COUNT_TOTAL = ORIGEM.COUNT_TOTAL
                  WHEN NOT MATCHED THEN 
                      INSERT (COMPANY_CODE, BUSINESS_AREA, SOURCE_FILE_FOLDER, COUNT_TOTAL, MOVE_FILES, CHECK_SO, LOAD_DATE)
                      VALUES (ORIGEM.COMPANY_CODE, ORIGEM.BUSINESS_AREA, ORIGEM.SOURCE_FILE_FOLDER, ORIGEM.COUNT_TOTAL, ORIGEM.MOVE_FILES, ORIGEM.CHECK_SO, ORIGEM.LOAD_DATE);
        END IF;
    END IF;
END;
$$;

-- CALL OW_LAO.PROC_SALES_DEDUCTION_NERP_AL11_VALIDATION();
-- ERROR: Severity: ERROR, Message: Column "FNAV" does not exist, Sqlstate: 42703, Where: PL/vSQL procedure PROC_SALES_DEDUCTION_NERP_AL11_VALIDATION line 48 at static SQL, Routine: attnameAttNum, File: parse_relation.c, Line: 2773, Error Code: 2624, 
-- CALL OW_LAO.PROC_SALES_DEDUCTION_NERP_AL11_VALIDATION();
-- ERROR: Severity: ERROR, Message: Column "FNAV" does not exist, Sqlstate: 42703, Where: PL/vSQL procedure PROC_SALES_DEDUCTION_NERP_AL11_VALIDATION line 48 at static SQL, Routine: attnameAttNum, File: parse_relation.c, Line: 2773, Error Code: 2624, 
-- CREATE OR REPLACE PROCEDURE OW_LAO.PROC_SALES_DEDUCTION_NERP_AL11_VALIDATION()
-- LANGUAGE PLvSQL AS $$
-- DECLARE 
--     DAY_OF_WEEK VARCHAR(20); 
--     LOAD_DATE_CHECK DATE;
-- BEGIN
--     
--     -- Truncate table to validate files uploaded to AL11
--     PERFORM TRUNCATE TABLE OW_LAO.FT_NERP_AL11_VALIDATION;
--     
--     -- Populate validation table for files uploaded to AL11
--     PERFORM INSERT INTO OW_LAO.FT_NERP_AL11_VALIDATION
--            SELECT  FILE_NAME_PROCESSED
--                     ,TO_DATE(SUBSTRING(FILE_NAME_PROCESSED,25,8),'YYYYMMDD') AS DATA_FILE
--                     ,SUBSTRING(FILE_NAME_PROCESSED,15,4) AS COMPANY_CODE
--                     ,SUBSTRING(FILE_NAME_PROCESSED,20,4) AS BUSINESS_AREA
--                      , (CASE WHEN FILE_NAME_PROCESSED LIKE '%5555999%'
--                             THEN 'FOTA_01W_05W'
--                                 WHEN FILE_NAME_PROCESSED LIKE '%0105999%'
--                             THEN 'EDI_01W_05W'
--                                 WHEN FILE_NAME_PROCESSED LIKE '%0610999%'
--                             THEN 'EDI_06W_10W'
--                             ELSE NULL 
--                             END) AS "CLASSIFICATION"
--                     ,SUBSTRING(FILE_NAME_PROCESSED,47,7) AS STATUS_AL11
--                     ,NULL AS FLAG_TO_SEND_FILES
--                     ,FILE_NAME AS FILE_NAME_RPA
--                     ,LOAD_DATE AS LOAD_DATE_RPA
--                     ,CURRENT_DATE AS LOAD_DATE 
--                     
--             FROM OW_LAO.ODS_NERP_AL11_MCS_SEN onams 
--             WHERE TO_DATE(LAST_CHANGED_ON,'DD/MM/YYYY') = (
--                 SELECT MAX(TO_DATE(LAST_CHANGED_ON,'DD/MM/YYYY')) 
--                 FROM OW_LAO.ODS_NERP_AL11_MCS_SEN
--             )
--             AND (CASE WHEN FILE_NAME_PROCESSED LIKE '%5555999%'
--                             THEN 'FOTA_01W_05W'
--                                 WHEN FILE_NAME_PROCESSED LIKE '%0105999%'
--                             THEN 'EDI_01W_05W'
--                                 WHEN FILE_NAME_PROCESSED LIKE '%0610999%'
--                             THEN 'EDI_06W_10W'
--                             ELSE NULL 
--                 END) IS NOT NULL             
--             ORDER BY SUBSTRING(FILE_NAME_PROCESSED,15,4)
--                     ,SUBSTRING(FILE_NAME_PROCESSED,20,4)
--             ;
-- 
--     -- Set flags based on presence of required files
--     -- Pairs requiring 3 files
--     PERFORM WITH cnt AS (
--         SELECT 
--             company_code,
--             business_area,
--             COUNT(DISTINCT "CLASSIFICATION") AS cnt
--         FROM OW_LAO.FT_NERP_AL11_VALIDATION
--         WHERE DATA_FILE = CASE WHEN TRIM(TO_CHAR(CURRENT_DATE,'DAY')) = 'TUESDAY' THEN CURRENT_DATE ELSE TIMESTAMPADD(DAY,-1,CURRENT_DATE) END
--           AND STATUS_AL11 = 'SUCCESS'
--           AND "CLASSIFICATION" IN ('FOTA_01W_05W','EDI_01W_05W','EDI_06W_10W')
--         GROUP BY 1,2
--     )
--     UPDATE OW_LAO.FT_NERP_AL11_VALIDATION t
--        SET FLAG_TO_SEND_FILES = 'OK'
--       FROM cnt
--      WHERE t.COMPANY_CODE = cnt.COMPANY_CODE
--        AND t.BUSINESS_AREA = cnt.BUSINESS_AREA
--        AND cnt.cnt = 3
--        AND (
--             (t.COMPANY_CODE='C390' AND t.BUSINESS_AREA='390A') OR
--             (t.COMPANY_CODE='C810' AND t.BUSINESS_AREA='810A') OR
--             (t.COMPANY_CODE='C810' AND t.BUSINESS_AREA='810C') OR
--             (t.COMPANY_CODE='C810' AND t.BUSINESS_AREA='810D') OR
--             (t.COMPANY_CODE='C810' AND t.BUSINESS_AREA='810F') OR
--             (t.COMPANY_CODE='C810' AND t.BUSINESS_AREA='810J') OR
--             (t.COMPANY_CODE='C850' AND t.BUSINESS_AREA='850A') OR
--             (t.COMPANY_CODE='C860' AND t.BUSINESS_AREA='860A')
--        );
-- 
--     -- Pairs requiring 2 files
--     PERFORM WITH cnt AS (
--         SELECT 
--             company_code,
--             business_area,
--             COUNT(DISTINCT "CLASSIFICATION") AS cnt
--         FROM OW_LAO.FT_NERP_AL11_VALIDATION
--         WHERE DATA_FILE = CASE WHEN TRIM(TO_CHAR(CURRENT_DATE,'DAY')) = 'TUESDAY' THEN CURRENT_DATE ELSE TIMESTAMPADD(DAY,-1,CURRENT_DATE) END
--           AND STATUS_AL11 = 'SUCCESS'
--           AND "CLASSIFICATION" IN ('EDI_01W_05W','EDI_06W_10W')
--         GROUP BY 1,2
--     )
--     UPDATE OW_LAO.FT_NERP_AL11_VALIDATION t
--        SET FLAG_TO_SEND_FILES = 'OK'
--       FROM cnt
--      WHERE t.COMPANY_CODE = cnt.COMPANY_CODE
--        AND t.BUSINESS_AREA = cnt.BUSINESS_AREA
--        AND cnt.cnt = 2
--        AND (
--             (t.COMPANY_CODE='C810' AND t.BUSINESS_AREA='810M') OR
--             (t.COMPANY_CODE='C813' AND t.BUSINESS_AREA='813A')
--        );
-- 
--     -- Determine day of week and load date
--     SELECT TRIM(TO_CHAR(CURRENT_DATE,'DAY')) INTO DAY_OF_WEEK;
--     SELECT CURRENT_DATE INTO LOAD_DATE_CHECK;
-- 
--     -- If today is Tuesday
--     IF DAY_OF_WEEK = 'TUESDAY' THEN
--         -- If today's load_date is not present in the table or table is empty
--         IF (LOAD_DATE_CHECK <> COALESCE((SELECT MAX(LOAD_DATE) FROM OW_LAO.FT_LAO_SALES_DEDUCTION_AL11_VALIDATION_TO_MOVE_FILE), DATE '1900-01-01')
--             OR (SELECT MAX(LOAD_DATE) FROM OW_LAO.FT_LAO_SALES_DEDUCTION_AL11_VALIDATION_TO_MOVE_FILE) IS NULL) THEN 
--             
--             -- Truncate table before loading
--             PERFORM TRUNCATE TABLE OW_LAO.FT_LAO_SALES_DEDUCTION_AL11_VALIDATION_TO_MOVE_FILE;
--             
--             -- Insert today's records
--             PERFORM INSERT INTO OW_LAO.FT_LAO_SALES_DEDUCTION_AL11_VALIDATION_TO_MOVE_FILE 
--                   SELECT DISTINCT 
--                         VL.COMPANY_CODE
--                         ,VL.BUSINESS_AREA
--                         ,'E:\Shared\LAO\LAO\SALES DEDUCTION\Condition_Calc\INPUT\GENERATE\' || VL.BUSINESS_AREA || '_' || DC.YYYYWW || '_' || DC.SUR_KEY || '.xlsx' AS "SOURCE_FILE_FOLDER"
--                         ,COUNT(VL.FLAG_TO_SEND_FILES) AS "COUNT_TOTAL"
--                         ,NULL AS "MOVE_FILES"
--                         ,NULL AS "CHECK_SO"
--                         ,VL.LOAD_DATE 
--                   FROM OW_LAO.FT_NERP_AL11_VALIDATION VL
--                   LEFT JOIN OW_MD.DIM_CALENDAR DC
--                     ON (TIMESTAMPADD(DAY, -1, CURRENT_DATE) = DC.YYYYMMDD)
--                   WHERE VL.LOAD_DATE = CURRENT_DATE
--                   GROUP BY 
--                         VL.COMPANY_CODE
--                         ,VL.BUSINESS_AREA
--                         ,'E:\Shared\LAO\LAO\SALES DEDUCTION\Condition_Calc\INPUT\GENERATE\' || VL.BUSINESS_AREA || '_' || DC.YYYYWW || '_' || DC.SUR_KEY || '.xlsx'
--                         ,NULL
--                         ,NULL 
--                         ,VL.LOAD_DATE
--                   ORDER BY
--                         VL.COMPANY_CODE ASC,
--                         VL.BUSINESS_AREA ASC;
--         ELSE
--             PERFORM MERGE INTO OW_LAO.FT_LAO_SALES_DEDUCTION_AL11_VALIDATION_TO_MOVE_FILE AS DESTINO
--                   USING (
--                         SELECT DISTINCT 
--                               VL.COMPANY_CODE
--                               ,VL.BUSINESS_AREA
--                               ,'E:\Shared\LAO\LAO\SALES DEDUCTION\Condition_Calc\INPUT\GENERATE\' || VL.BUSINESS_AREA || '_' || DC.YYYYWW || '_' || DC.SUR_KEY || '.xlsx' AS "SOURCE_FILE_FOLDER"
--                               ,COUNT(VL.FLAG_TO_SEND_FILES) AS "COUNT_TOTAL"
--                               ,NULL AS "MOVE_FILES"
--                               ,NULL AS "CHECK_SO"
--                               ,VL.LOAD_DATE
--                         FROM OW_LAO.FT_NERP_AL11_VALIDATION VL
--                         LEFT JOIN OW_MD.DIM_CALENDAR DC
--                           ON (TIMESTAMPADD(DAY, -1, CURRENT_DATE) = DC.YYYYMMDD)
--                         WHERE VL.LOAD_DATE = CURRENT_DATE
--                         GROUP BY 
--                               VL.COMPANY_CODE
--                               ,VL.BUSINESS_AREA
--                               ,'E:\Shared\LAO\LAO\SALES DEDUCTION\Condition_Calc\INPUT\GENERATE\' || VL.BUSINESS_AREA || '_' || DC.YYYYWW || '_' || DC.SUR_KEY || '.xlsx'
--                               ,NULL
--                               ,NULL
--                               ,VL.LOAD_DATE
--                         ORDER BY
--                               VL.COMPANY_CODE ASC,
--                               VL.BUSINESS_AREA ASC
--                   ) AS ORIGEM 
--                   ON DESTINO.COMPANY_CODE = ORIGEM.COMPANY_CODE
--                  AND DESTINO.BUSINESS_AREA = ORIGEM.BUSINESS_AREA
--                   WHEN MATCHED THEN 
--                       UPDATE SET DESTINO.COUNT_TOTAL = ORIGEM.COUNT_TOTAL
--                   WHEN NOT MATCHED THEN 
--                       INSERT (COMPANY_CODE, BUSINESS_AREA, SOURCE_FILE_FOLDER, COUNT_TOTAL, MOVE_FILES, CHECK_SO, LOAD_DATE)
--                       VALUES (ORIGEM.COMPANY_CODE, ORIGEM.BUSINESS_AREA, ORIGEM.SOURCE_FILE_FOLDER, ORIGEM.COUNT_TOTAL, ORIGEM.MOVE_FILES, ORIGEM.CHECK_SO, ORIGEM.LOAD_DATE);
--         END IF;
--     END IF;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: Syntax error at or near "UPDATE", Sqlstate: 42601, Position: 2806, Routine: base_yyerror, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/scan.l, Line: 1056, Error Code: 4856, 
CREATE OR REPLACE PROCEDURE OW_LAO.PROC_SALES_DEDUCTION_NERP_AL11_VALIDATION()
LANGUAGE PLvSQL AS $$
DECLARE 
    DAY_OF_WEEK VARCHAR(20); 
    LOAD_DATE_CHECK DATE;
BEGIN
    
    PERFORM TRUNCATE TABLE OW_LAO.FT_NERP_AL11_VALIDATION;
    
    PERFORM INSERT INTO OW_LAO.FT_NERP_AL11_VALIDATION
           SELECT  FILE_NAME_PROCESSED
                    ,TO_DATE(SUBSTRING(FILE_NAME_PROCESSED,25,8),'YYYYMMDD') AS DATA_FILE
                    ,SUBSTRING(FILE_NAME_PROCESSED,15,4) AS COMPANY_CODE
                    ,SUBSTRING(FILE_NAME_PROCESSED,20,4) AS BUSINESS_AREA
                     , (CASE WHEN FILE_NAME_PROCESSED LIKE '%5555999%'
                            THEN 'FOTA_01W_05W'
                                WHEN FILE_NAME_PROCESSED LIKE '%0105999%'
                            THEN 'EDI_01W_05W'
                                WHEN FILE_NAME_PROCESSED LIKE '%0610999%'
                            THEN 'EDI_06W_10W'
                            ELSE NULL 
                            END) AS "CLASSIFICATION"
                    ,SUBSTRING(FILE_NAME_PROCESSED,47,7) AS STATUS_AL11
                    ,NULL AS FLAG_TO_SEND_FILES
                    ,FILE_NAME AS FILE_NAME_RPA
                    ,LOAD_DATE AS LOAD_DATE_RPA
                    ,CURRENT_DATE AS LOAD_DATE 
            FROM OW_LAO.ODS_NERP_AL11_MCS_SEN onams 
            WHERE TO_DATE(LAST_CHANGED_ON,'DD/MM/YYYY') = (
                SELECT MAX(TO_DATE(LAST_CHANGED_ON,'DD/MM/YYYY')) 
                FROM OW_LAO.ODS_NERP_AL11_MCS_SEN
            )
            AND (CASE WHEN FILE_NAME_PROCESSED LIKE '%5555999%'
                            THEN 'FOTA_01W_05W'
                                WHEN FILE_NAME_PROCESSED LIKE '%0105999%'
                            THEN 'EDI_01W_05W'
                                WHEN FILE_NAME_PROCESSED LIKE '%0610999%'
                            THEN 'EDI_06W_10W'
                            ELSE NULL 
                END) IS NOT NULL;

    -- Pairs requiring 3 files
    PERFORM UPDATE OW_LAO.FT_NERP_AL11_VALIDATION t
       SET FLAG_TO_SEND_FILES = 'OK'
      FROM (
        SELECT 
            company_code,
            business_area,
            COUNT(DISTINCT "CLASSIFICATION") AS cnt
        FROM OW_LAO.FT_NERP_AL11_VALIDATION
        WHERE DATA_FILE = CASE WHEN TRIM(TO_CHAR(CURRENT_DATE,'DAY')) = 'TUESDAY' THEN CURRENT_DATE ELSE TIMESTAMPADD(DAY,-1,CURRENT_DATE) END
          AND STATUS_AL11 = 'SUCCESS'
          AND "CLASSIFICATION" IN ('FOTA_01W_05W','EDI_01W_05W','EDI_06W_10W')
        GROUP BY 1,2
      ) cnt
     WHERE t.COMPANY_CODE = cnt.COMPANY_CODE
       AND t.BUSINESS_AREA = cnt.BUSINESS_AREA
       AND cnt.cnt = 3
       AND (
            (t.COMPANY_CODE='C390' AND t.BUSINESS_AREA='390A') OR
            (t.COMPANY_CODE='C810' AND t.BUSINESS_AREA='810A') OR
            (t.COMPANY_CODE='C810' AND t.BUSINESS_AREA='810C') OR
            (t.COMPANY_CODE='C810' AND t.BUSINESS_AREA='810D') OR
            (t.COMPANY_CODE='C810' AND t.BUSINESS_AREA='810F') OR
            (t.COMPANY_CODE='C810' AND t.BUSINESS_AREA='810J') OR
            (t.COMPANY_CODE='C850' AND t.BUSINESS_AREA='850A') OR
            (t.COMPANY_CODE='C860' AND t.BUSINESS_AREA='860A')
       );

    -- Pairs requiring 2 files
    PERFORM UPDATE OW_LAO.FT_NERP_AL11_VALIDATION t
       SET FLAG_TO_SEND_FILES = 'OK'
      FROM (
        SELECT 
            company_code,
            business_area,
            COUNT(DISTINCT "CLASSIFICATION") AS cnt
        FROM OW_LAO.FT_NERP_AL11_VALIDATION
        WHERE DATA_FILE = CASE WHEN TRIM(TO_CHAR(CURRENT_DATE,'DAY')) = 'TUESDAY' THEN CURRENT_DATE ELSE TIMESTAMPADD(DAY,-1,CURRENT_DATE) END
          AND STATUS_AL11 = 'SUCCESS'
          AND "CLASSIFICATION" IN ('EDI_01W_05W','EDI_06W_10W')
        GROUP BY 1,2
      ) cnt
     WHERE t.COMPANY_CODE = cnt.COMPANY_CODE
       AND t.BUSINESS_AREA = cnt.BUSINESS_AREA
       AND cnt.cnt = 2
       AND (
            (t.COMPANY_CODE='C810' AND t.BUSINESS_AREA='810M') OR
            (t.COMPANY_CODE='C813' AND t.BUSINESS_AREA='813A')
       );

    SELECT TRIM(TO_CHAR(CURRENT_DATE,'DAY')) INTO DAY_OF_WEEK;
    SELECT CURRENT_DATE INTO LOAD_DATE_CHECK;

    IF DAY_OF_WEEK = 'TUESDAY' THEN
        IF (LOAD_DATE_CHECK <> COALESCE((SELECT MAX(LOAD_DATE) FROM OW_LAO.FT_LAO_SALES_DEDUCTION_AL11_VALIDATION_TO_MOVE_FILE), DATE '1900-01-01')
            OR (SELECT MAX(LOAD_DATE) FROM OW_LAO.FT_LAO_SALES_DEDUCTION_AL11_VALIDATION_TO_MOVE_FILE) IS NULL) THEN 
            
            PERFORM TRUNCATE TABLE OW_LAO.FT_LAO_SALES_DEDUCTION_AL11_VALIDATION_TO_MOVE_FILE;
            
            PERFORM INSERT INTO OW_LAO.FT_LAO_SALES_DEDUCTION_AL11_VALIDATION_TO_MOVE_FILE 
                  SELECT DISTINCT 
                        VL.COMPANY_CODE
                        ,VL.BUSINESS_AREA
                        ,'E:\Shared\LAO\LAO\SALES DEDUCTION\Condition_Calc\INPUT\GENERATE\' || VL.BUSINESS_AREA || '_' || DC.YYYYWW || '_' || DC.SUR_KEY || '.xlsx' AS "SOURCE_FILE_FOLDER"
                        ,COUNT(VL.FLAG_TO_SEND_FILES) AS "COUNT_TOTAL"
                        ,NULL AS "MOVE_FILES"
                        ,NULL AS "CHECK_SO"
                        ,VL.LOAD_DATE 
                  FROM OW_LAO.FT_NERP_AL11_VALIDATION VL
                  LEFT JOIN OW_MD.DIM_CALENDAR DC
                    ON (TIMESTAMPADD(DAY, -1, CURRENT_DATE) = DC.YYYYMMDD)
                  WHERE VL.LOAD_DATE = CURRENT_DATE
                  GROUP BY 
                        VL.COMPANY_CODE
                        ,VL.BUSINESS_AREA
                        ,'E:\Shared\LAO\LAO\SALES DEDUCTION\Condition_Calc\INPUT\GENERATE\' || VL.BUSINESS_AREA || '_' || DC.YYYYWW || '_' || DC.SUR_KEY || '.xlsx'
                        ,VL.LOAD_DATE
                  ORDER BY
                        VL.COMPANY_CODE ASC,
                        VL.BUSINESS_AREA ASC;
        ELSE
            PERFORM MERGE INTO OW_LAO.FT_LAO_SALES_DEDUCTION_AL11_VALIDATION_TO_MOVE_FILE AS DESTINO
                  USING (
                        SELECT DISTINCT 
                              VL.COMPANY_CODE
                              ,VL.BUSINESS_AREA
                              ,'E:\Shared\LAO\LAO\SALES DEDUCTION\Condition_Calc\INPUT\GENERATE\' || VL.BUSINESS_AREA || '_' || DC.YYYYWW || '_' || DC.SUR_KEY || '.xlsx' AS "SOURCE_FILE_FOLDER"
                              ,COUNT(VL.FLAG_TO_SEND_FILES) AS "COUNT_TOTAL"
                              ,NULL AS "MOVE_FILES"
                              ,NULL AS "CHECK_SO"
                              ,VL.LOAD_DATE
                        FROM OW_LAO.FT_NERP_AL11_VALIDATION VL
                        LEFT JOIN OW_MD.DIM_CALENDAR DC
                          ON (TIMESTAMPADD(DAY, -1, CURRENT_DATE) = DC.YYYYMMDD)
                        WHERE VL.LOAD_DATE = CURRENT_DATE
                        GROUP BY 
                              VL.COMPANY_CODE
                              ,VL.BUSINESS_AREA
                              ,'E:\Shared\LAO\LAO\SALES DEDUCTION\Condition_Calc\INPUT\GENERATE\' || VL.BUSINESS_AREA || '_' || DC.YYYYWW || '_' || DC.SUR_KEY || '.xlsx'
                              ,VL.LOAD_DATE
                  ) AS ORIGEM 
                  ON DESTINO.COMPANY_CODE = ORIGEM.COMPANY_CODE
                 AND DESTINO.BUSINESS_AREA = ORIGEM.BUSINESS_AREA
                  WHEN MATCHED THEN 
                      UPDATE SET DESTINO.COUNT_TOTAL = ORIGEM.COUNT_TOTAL
                  WHEN NOT MATCHED THEN 
                      INSERT (COMPANY_CODE, BUSINESS_AREA, SOURCE_FILE_FOLDER, COUNT_TOTAL, MOVE_FILES, CHECK_SO, LOAD_DATE)
                      VALUES (ORIGEM.COMPANY_CODE, ORIGEM.BUSINESS_AREA, ORIGEM.SOURCE_FILE_FOLDER, ORIGEM.COUNT_TOTAL, ORIGEM.MOVE_FILES, ORIGEM.CHECK_SO, ORIGEM.LOAD_DATE);
        END IF;
    END IF;
END;
$$;

CALL OW_LAO.PROC_SALES_DEDUCTION_NERP_AL11_VALIDATION();
-- PROC_SALES_DEDUCTION_NERP_AL11_VALIDATION
-- -----------------------------------------
-- 0

