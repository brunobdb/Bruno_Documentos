-- SELECT JSON_EXTRACT_ARRAY_ELEMENT_TEXT('["a","b"]', 1) AS val;
-- ERROR: Severity: ERROR, Message: Function JSON_EXTRACT_ARRAY_ELEMENT_TEXT(unknown, int) does not exist, or permission is denied for JSON_EXTRACT_ARRAY_ELEMENT_TEXT(unknown, int), Sqlstate: 42883, Hint: No function matches the given name and argument types. You may need to add explicit type casts, Routine: throwErrorFunctionDoesNotMatch, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/ParseFunc.cpp, Line: 4559, Error Code: 3457, 
SELECT MAPLOOKUP(MAPJSONEXTRACTOR('{"address":{"addressType":"x"}}'), 'address.addressType') AS val;
-- val
-- ---
-- x

-- SELECT 
--   OID, PROCEDURE_NAME
-- FROM V_CATALOG.PROCEDURES
-- WHERE SCHEMA_NAME = 'V_CATALOG' AND PROCEDURE_NAME ILIKE '%JSON%'
-- LIMIT 50;
-- ERROR: Severity: ERROR, Message: Relation "V_CATALOG.PROCEDURES" does not exist, Sqlstate: 42V01, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
