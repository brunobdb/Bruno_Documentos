-- CREATE OR REPLACE PROCEDURE ow_lao.proc_TF_NERP_GROSS_MARGIN_monitoring_datasource()
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--     SELECT 2 AS monitoring_execution_result_status,
--            LISTAGG(
--                'Billing date: ' || CHR(10) || TO_CHAR(billing_date, 'YYYY-MM-DD') || CHR(10) ||
--                'Amount ZKE: '   || CHR(10) || TO_CHAR(amount_zke)
--                USING PARAMETERS separator=CHR(10) || CHR(10)
--            ) AS value
--       FROM (
--             SELECT billing_date,
--                    SUM(amount_zke) AS amount_zke
--               FROM OW_LAO.TF_NERP_GROSS_MARGIN
--              WHERE billing_date = TIMESTAMPADD(DAY, -1, CURRENT_DATE)
--              GROUP BY billing_date
--            ) a;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 15.15 of source string: syntax error, unexpected ;, expecting INTO, Sqlstate: 42601, Position: 692, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
CREATE OR REPLACE PROCEDURE ow_lao.proc_TF_NERP_GROSS_MARGIN_monitoring_datasource(
    OUT monitoring_execution_result_status INTEGER,
    OUT value VARCHAR(65000)
)
LANGUAGE PLvSQL AS $$
BEGIN
    SELECT 2,
           LISTAGG(
               'Billing date: ' || CHR(10) || TO_CHAR(billing_date) || CHR(10) ||
               'Amount ZKE: '   || CHR(10) || TO_CHAR(amount_zke)
               USING PARAMETERS separator=CHR(10) || CHR(10)
           )
      INTO monitoring_execution_result_status, value
      FROM (
            SELECT billing_date,
                   SUM(amount_zke) AS amount_zke
              FROM OW_LAO.TF_NERP_GROSS_MARGIN
             WHERE billing_date = TIMESTAMPADD(DAY, -1, CURRENT_DATE)
             GROUP BY billing_date
           ) a;
END;
$$;

CALL ow_lao.proc_TF_NERP_GROSS_MARGIN_monitoring_datasource();
-- monitoring_execution_result_status | value
-- -----------------------------------+------
-- 2 | NULL

CREATE OR REPLACE PROCEDURE ow_lao.proc_TF_NERP_GROSS_MARGIN_monitoring_datasource(
    OUT monitoring_execution_result_status INTEGER,
    OUT value VARCHAR(65000)
)
LANGUAGE PLvSQL AS $$
BEGIN
    monitoring_execution_result_status := 2;
    SELECT (
        SELECT LISTAGG(
                   'Billing date: ' || CHR(10) || TO_CHAR(billing_date) || CHR(10) ||
                   'Amount ZKE: '   || CHR(10) || TO_CHAR(amount_zke)
                   USING PARAMETERS separator=CHR(10) || CHR(10)
               )
          FROM (
                SELECT billing_date,
                       SUM(amount_zke) AS amount_zke
                  FROM OW_LAO.TF_NERP_GROSS_MARGIN
                 WHERE billing_date = TIMESTAMPADD(DAY, -1, CURRENT_DATE)
                 GROUP BY billing_date
               ) a
    ) INTO value;
END;
$$;

CALL ow_lao.proc_TF_NERP_GROSS_MARGIN_monitoring_datasource();
-- monitoring_execution_result_status | value
-- -----------------------------------+------
-- 2 | NULL

