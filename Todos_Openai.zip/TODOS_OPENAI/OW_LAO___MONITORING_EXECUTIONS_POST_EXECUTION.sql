CREATE OR REPLACE PROCEDURE ow_lao.monitoring_executions_post_execution(
       IN _monitoring_execution        INT
     , IN _monitoring_execution_status INT
     , IN _execution_post_message      VARCHAR(4000)
)
LANGUAGE PLvSQL AS $$
BEGIN
   PERFORM UPDATE ow_lao.monitoring_executions
      SET monitoring_execution_status = _monitoring_execution_status
        , execution_post_message      = _execution_post_message
        , ended_at                    = CURRENT_TIMESTAMP
    WHERE id                     = _monitoring_execution
      AND _monitoring_execution != 2 ;

   PERFORM UPDATE ow_lao.monitoring_executions
      SET monitoring_execution_status = _monitoring_execution_status
        , execution_post_message      = _execution_post_message
    WHERE id                    = _monitoring_execution
      AND _monitoring_execution = 2 ;
END
$$;

CALL ow_lao.monitoring_executions_post_execution(1, 3, 'done');
-- monitoring_executions_post_execution
-- ------------------------------------
-- 0

