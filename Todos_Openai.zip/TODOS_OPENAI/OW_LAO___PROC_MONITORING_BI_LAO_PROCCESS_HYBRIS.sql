CREATE OR REPLACE PROCEDURE ow_lao.proc_monitoring_bi_lao_proccess_hybris()
LANGUAGE PLvSQL AS $$
DECLARE
    hybrisSalesMaxInserted TIMESTAMP := NULL;
BEGIN
    SELECT MAX(po_source_insert_date)
      INTO hybrisSalesMaxInserted
      FROM ow_lao.ods_sales_control_tower_table
     WHERE po_plataform_datasource IN ('ow_lao.ods_hybris_sales');

    PERFORM INSERT INTO ow_lao.monitoring_bi_lao_proccess(
                   origem_nome
                 , processo_nome
                 , referencia
                 , quantidade
       )
       SELECT 'ow_lao.ods_hybris_sales'  AS dataSource
            , 'Control Tower'            AS proccess
            , a.order_code               AS referencia
            , COUNT(1)                   AS quantity
         FROM ow_lao.ods_hybris_sales   a
         JOIN u_prj_ecom.dim_subsidiary b ON LOWER(b.country_code) = LOWER(a.country_cd)
        WHERE a.order_creation_date >= TIMESTAMPADD(DAY, -180, CURRENT_DATE)
          AND a.order_creation_date <= hybrisSalesMaxInserted
          AND NOT EXISTS (
                SELECT 1
                  FROM ow_lao.ods_sales_control_tower_table aa
                 WHERE aa.po_orderid = a.order_code
                   AND aa.po_sku     = a.product_code
                   AND aa.country    = b.country
              )
           AND NOT EXISTS (
                    SELECT 1
                      FROM ow_lao.monitoring_bi_lao_proccess cc
                     WHERE cc.processo_nome = 'Control Tower'
                       AND cc.origem_nome   = 'ow_lao.ods_hybris_sales'
                       AND cc.referencia    = a.order_code
                       AND cc.status_nome   = 'Em analise'
               )
      GROUP BY a.order_code;
END;
$$;

-- CALL ow_lao.proc_monitoring_bi_lao_proccess_hybris();
-- ERROR: Severity: ERROR, Message: Operator does not exist: varchar >= timestamp, Sqlstate: 42883, Hint: No operator matches the given name and argument type(s). You may need to add explicit type casts, Where: PL/vSQL procedure proc_monitoring_bi_lao_proccess_hybris line 10 at static SQL, Routine: op_error, File: parse_oper.c, Line: 608, Error Code: 4286, 
-- CALL ow_lao.proc_monitoring_bi_lao_proccess_hybris();
-- ERROR: Severity: ERROR, Message: Operator does not exist: varchar >= timestamp, Sqlstate: 42883, Hint: No operator matches the given name and argument type(s). You may need to add explicit type casts, Where: PL/vSQL procedure proc_monitoring_bi_lao_proccess_hybris line 10 at static SQL, Routine: op_error, File: parse_oper.c, Line: 608, Error Code: 4286, 
CREATE OR REPLACE PROCEDURE ow_lao.proc_monitoring_bi_lao_proccess_hybris()
LANGUAGE PLvSQL AS $$
DECLARE
    hybrisSalesMaxInserted TIMESTAMP := NULL;
BEGIN
    SELECT MAX(po_source_insert_date)
      INTO hybrisSalesMaxInserted
      FROM ow_lao.ods_sales_control_tower_table
     WHERE po_plataform_datasource IN ('ow_lao.ods_hybris_sales');

    PERFORM INSERT INTO ow_lao.monitoring_bi_lao_proccess(
                   origem_nome
                 , processo_nome
                 , referencia
                 , quantidade
       )
       SELECT 'ow_lao.ods_hybris_sales'  AS dataSource
            , 'Control Tower'            AS proccess
            , a.order_code               AS referencia
            , COUNT(1)                   AS quantity
         FROM ow_lao.ods_hybris_sales   a
         JOIN u_prj_ecom.dim_subsidiary b ON LOWER(b.country_code) = LOWER(a.country_cd)
        WHERE TRY_TO_TIMESTAMP(a.order_creation_date) >= TIMESTAMPADD(DAY, -180, CURRENT_DATE)
          AND TRY_TO_TIMESTAMP(a.order_creation_date) <= hybrisSalesMaxInserted
          AND NOT EXISTS (
                SELECT 1
                  FROM ow_lao.ods_sales_control_tower_table aa
                 WHERE aa.po_orderid = a.order_code
                   AND aa.po_sku     = a.product_code
                   AND aa.country    = b.country
              )
           AND NOT EXISTS (
                    SELECT 1
                      FROM ow_lao.monitoring_bi_lao_proccess cc
                     WHERE cc.processo_nome = 'Control Tower'
                       AND cc.origem_nome   = 'ow_lao.ods_hybris_sales'
                       AND cc.referencia    = a.order_code
                       AND cc.status_nome   = 'Em analise'
               )
      GROUP BY a.order_code;
END;
$$;

-- CALL ow_lao.proc_monitoring_bi_lao_proccess_hybris();
-- ERROR: Severity: ERROR, Message: Function TRY_TO_TIMESTAMP(varchar) does not exist, or permission is denied for TRY_TO_TIMESTAMP(varchar), Sqlstate: 42883, Hint: No function matches the given name and argument types. You may need to add explicit type casts, Where: PL/vSQL procedure proc_monitoring_bi_lao_proccess_hybris line 10 at static SQL, Routine: throwErrorFunctionDoesNotMatch, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/ParseFunc.cpp, Line: 4559, Error Code: 3457, 
-- CALL ow_lao.proc_monitoring_bi_lao_proccess_hybris();
-- ERROR: Severity: ERROR, Message: Function TRY_TO_TIMESTAMP(varchar) does not exist, or permission is denied for TRY_TO_TIMESTAMP(varchar), Sqlstate: 42883, Hint: No function matches the given name and argument types. You may need to add explicit type casts, Where: PL/vSQL procedure proc_monitoring_bi_lao_proccess_hybris line 10 at static SQL, Routine: throwErrorFunctionDoesNotMatch, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/ParseFunc.cpp, Line: 4559, Error Code: 3457, 
-- CREATE OR REPLACE PROCEDURE ow_lao.proc_monitoring_bi_lao_proccess_hybris()
-- LANGUAGE PLvSQL AS $$
-- DECLARE
--     hybrisSalesMaxInserted TIMESTAMP := NULL;
-- BEGIN
--     SELECT MAX(po_source_insert_date)
--       INTO hybrisSalesMaxInserted
--       FROM ow_lao.ods_sales_control_tower_table
--      WHERE po_plataform_datasource IN ('ow_lao.ods_hybris_sales');
-- 
--     PERFORM INSERT INTO ow_lao.monitoring_bi_lao_proccess(
--                    origem_nome
--                  , processo_nome
--                  , referencia
--                  , quantidade
--        )
--        SELECT 'ow_lao.ods_hybris_sales'  AS dataSource
--             , 'Control Tower'            AS proccess
--             , a.order_code               AS referencia
--             , COUNT(1)                   AS quantity
--          FROM ow_lao.ods_hybris_sales   a
--          JOIN u_prj_ecom.dim_subsidiary b ON LOWER(b.country_code) = LOWER(a.country_cd)
--         WHERE TRY_CAST(a.order_creation_date AS TIMESTAMP) >= TIMESTAMPADD(DAY, -180, CURRENT_DATE)
--           AND TRY_CAST(a.order_creation_date AS TIMESTAMP) <= hybrisSalesMaxInserted
--           AND NOT EXISTS (
--                 SELECT 1
--                   FROM ow_lao.ods_sales_control_tower_table aa
--                  WHERE aa.po_orderid = a.order_code
--                    AND aa.po_sku     = a.product_code
--                    AND aa.country    = b.country
--               )
--            AND NOT EXISTS (
--                     SELECT 1
--                       FROM ow_lao.monitoring_bi_lao_proccess cc
--                      WHERE cc.processo_nome = 'Control Tower'
--                        AND cc.origem_nome   = 'ow_lao.ods_hybris_sales'
--                        AND cc.referencia    = a.order_code
--                        AND cc.status_nome   = 'Em analise'
--                )
--       GROUP BY a.order_code;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: Syntax error at or near "AS", Sqlstate: 42601, Position: 931, Routine: base_yyerror, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/scan.l, Line: 1056, Error Code: 4856, 
CREATE OR REPLACE PROCEDURE ow_lao.proc_monitoring_bi_lao_proccess_hybris()
LANGUAGE PLvSQL AS $$
DECLARE
    hybrisSalesMaxInserted TIMESTAMP := NULL;
BEGIN
    SELECT MAX(po_source_insert_date)
      INTO hybrisSalesMaxInserted
      FROM ow_lao.ods_sales_control_tower_table
     WHERE po_plataform_datasource IN ('ow_lao.ods_hybris_sales');

    PERFORM INSERT INTO ow_lao.monitoring_bi_lao_proccess(
                   origem_nome
                 , processo_nome
                 , referencia
                 , quantidade
       )
       SELECT 'ow_lao.ods_hybris_sales'
            , 'Control Tower'
            , a.order_code
            , COUNT(1)
         FROM ow_lao.ods_hybris_sales   a
         JOIN u_prj_ecom.dim_subsidiary b ON LOWER(b.country_code) = LOWER(a.country_cd)
        WHERE CAST(a.order_creation_date AS TIMESTAMP) >= TIMESTAMPADD(DAY, -180, CURRENT_DATE)
          AND CAST(a.order_creation_date AS TIMESTAMP) <= hybrisSalesMaxInserted
          AND NOT EXISTS (
                SELECT 1
                  FROM ow_lao.ods_sales_control_tower_table aa
                 WHERE aa.po_orderid = a.order_code
                   AND aa.po_sku     = a.product_code
                   AND aa.country    = b.country
              )
           AND NOT EXISTS (
                    SELECT 1
                      FROM ow_lao.monitoring_bi_lao_proccess cc
                     WHERE cc.processo_nome = 'Control Tower'
                       AND cc.origem_nome   = 'ow_lao.ods_hybris_sales'
                       AND cc.referencia    = a.order_code
                       AND cc.status_nome   = 'Em analise'
               )
      GROUP BY a.order_code;
END;
$$;

-- CALL ow_lao.proc_monitoring_bi_lao_proccess_hybris();
-- ERROR: Severity: ERROR, Message: Cannot set NOT NULL columns (ID, STATUS_NOME) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure proc_monitoring_bi_lao_proccess_hybris line 10 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3211, Error Code: 2514, 
-- CALL ow_lao.proc_monitoring_bi_lao_proccess_hybris();
-- ERROR: Severity: ERROR, Message: Cannot set NOT NULL columns (ID, STATUS_NOME) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure proc_monitoring_bi_lao_proccess_hybris line 10 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3211, Error Code: 2514, 
-- SELECT column_name, data_type, is_nullable, default_value FROM v_catalog.columns WHERE table_schema='ow_lao' AND table_name='monitoring_bi_lao_proccess' ORDER BY ordinal_position;
-- ERROR: Severity: ERROR, Message: Column "default_value" does not exist, Sqlstate: 42703, Routine: transformSQLColumnRef, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Optimizer/OptUtil/ExprUtil.cpp, Line: 7401, Error Code: 2624, 
SELECT column_name, data_type, is_nullable FROM v_catalog.columns WHERE table_schema='ow_lao' AND table_name='monitoring_bi_lao_proccess' ORDER BY ordinal_position;
-- column_name | data_type | is_nullable
-- ------------+-----------+------------

SELECT * FROM ow_lao.monitoring_bi_lao_proccess LIMIT 0;
-- ID | INSERTED_TIMESTAMP | UPDATED_TIMESTAMP | PROCESSO_NOME | ORIGEM_NOME | QUANTIDADE | REFERENCIA | STATUS_NOME | ANALISTA_NOME | OBSERVACAO
-- ---+--------------------+-------------------+---------------+-------------+------------+------------+-------------+---------------+-----------

