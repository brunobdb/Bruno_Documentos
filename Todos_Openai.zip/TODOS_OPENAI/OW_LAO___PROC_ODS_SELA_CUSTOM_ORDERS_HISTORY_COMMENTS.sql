CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_sela_custom_orders_history_comments()
LANGUAGE PLvSQL AS $$
BEGIN
 
  PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_sela_custom_orders_history_comments ON COMMIT PRESERVE ROWS AS
  SELECT
      *
    , SHA256(
        COALESCE(CAST(subsidiary_id AS VARCHAR), '0') || '|'
        || COALESCE(CAST(account AS VARCHAR), '0') || '|'
        || COALESCE(CAST(order_id AS VARCHAR), '0') || '|'
        || COALESCE(CAST("date" AS VARCHAR), '0')
      ) AS guid
  FROM ow_lao.stg_sela_custom_orders_history_comments
  ;

  PERFORM DELETE FROM ow_lao.ods_sela_custom_orders_history_comments
  WHERE guid IN (SELECT DISTINCT guid FROM ow_lao.stg_sela_custom_orders_history_comments);

  PERFORM MERGE INTO ow_lao.ods_sela_custom_orders_history_comments a
  USING tmp_ods_sela_custom_orders_history_comments b
  ON b.guid = a.guid
  WHEN MATCHED THEN UPDATE SET
         updated_timestamp = CURRENT_TIMESTAMP
       , "comment"        = b."comment"
  WHEN NOT MATCHED THEN INSERT
         ( updated_timestamp
         , "comment"
         , subsidiary_id
         , account
         , order_id
         , "date"
         , guid
         )
  VALUES ( CURRENT_TIMESTAMP
         , b."comment"
         , b.subsidiary_id
         , b.account
         , b.order_id
         , b."date"
         , b.guid
         );

END;
$$;

-- CALL OW_LAO.proc_ods_sela_custom_orders_history_comments();
-- ERROR: Severity: ERROR, Message: Relation "ow_lao.stg_sela_custom_orders_history_comments" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ods_sela_custom_orders_history_comments line 4 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
-- CALL OW_LAO.proc_ods_sela_custom_orders_history_comments();
-- ERROR: Severity: ERROR, Message: Relation "ow_lao.stg_sela_custom_orders_history_comments" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ods_sela_custom_orders_history_comments line 4 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
