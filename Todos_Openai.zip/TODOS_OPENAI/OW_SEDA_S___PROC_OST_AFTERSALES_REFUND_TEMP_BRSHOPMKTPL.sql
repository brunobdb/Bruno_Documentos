-- SELECT JSON_EXTRACT_ARRAY_ELEMENT_TEXT('["x","y"]', 1) AS el;
-- ERROR: Severity: ERROR, Message: Function JSON_EXTRACT_ARRAY_ELEMENT_TEXT(unknown, int) does not exist, or permission is denied for JSON_EXTRACT_ARRAY_ELEMENT_TEXT(unknown, int), Sqlstate: 42883, Hint: No function matches the given name and argument types. You may need to add explicit type casts, Routine: throwErrorFunctionDoesNotMatch, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/ParseFunc.cpp, Line: 4559, Error Code: 3457, 
SELECT MAPLOOKUP(MAPJSONEXTRACTOR('{"a":1, "b":2, "friendlyName":"X"}'), 'friendlyName') AS fn;
-- fn
-- --
-- X

-- SELECT JSON_EXTRACT_STRING('[{"number":"123","nfe":"ABC"}]', '$[0].number') AS num;
-- ERROR: Severity: ERROR, Message: Function JSON_EXTRACT_STRING(unknown, unknown) does not exist, or permission is denied for JSON_EXTRACT_STRING(unknown, unknown), Sqlstate: 42883, Hint: No function matches the given name and argument types. You may need to add explicit type casts, Routine: throwErrorFunctionDoesNotMatch, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/ParseFunc.cpp, Line: 4559, Error Code: 3457, 
-- SELECT schema_name, function_name, argument_data_types FROM v_catalog.user_functions WHERE function_name ILIKE '%json%'
-- UNION ALL
-- SELECT schema_name, function_name, argument_data_types FROM v_catalog.functions WHERE function_name ILIKE '%json%'
-- ORDER BY 1,2;
-- ERROR: Severity: ERROR, Message: Column "argument_data_types" does not exist, Sqlstate: 42703, Routine: transformSQLColumnRef, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Optimizer/OptUtil/ExprUtil.cpp, Line: 7401, Error Code: 2624, 
-- SELECT * FROM v_catalog.functions LIMIT 5;
-- ERROR: Severity: ERROR, Message: Relation "v_catalog.functions" does not exist, Sqlstate: 42V01, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
