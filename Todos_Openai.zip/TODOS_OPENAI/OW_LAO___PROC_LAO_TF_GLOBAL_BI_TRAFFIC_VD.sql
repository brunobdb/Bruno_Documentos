-- CREATE OR REPLACE PROCEDURE OW_LAO.PROC_LAO_TF_GLOBAL_BI_TRAFFIC_VD()
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--   SELECT
--     A.REGION,
--     A.SUBSIDIARY,
--     A.COUNTRY,
--     A."YEAR",
--     A."MONTH",
--     A.WEEK,
--     A."DAY",
--     A.CHANNEL_GROUP_1,
--     A.CHANNEL_GROUP_2,
--     A.FILE_NAME,
--     A.RPA_DATE,
--     MAX(CASE WHEN B.ROW_NUM IN (1) THEN A.MEASURE_VALUES ELSE NULL END) AS "COM_Visit",
--     MAX(CASE WHEN B.ROW_NUM IN (8,11,12,13) THEN A.MEASURE_VALUES ELSE NULL END) AS "Shopper_Visit",
--     MAX(CASE WHEN B.ROW_NUM IN (19,2) THEN A.MEASURE_VALUES ELSE NULL END) AS "Add_to_Cart_Current",
--     MAX(CASE WHEN B.ROW_NUM IN (18,3) THEN A.MEASURE_VALUES ELSE NULL END) AS "Cart_Page_Visit_Current",
--     MAX(CASE WHEN B.ROW_NUM IN (17,4) THEN A.MEASURE_VALUES ELSE NULL END) AS "Checkout_Page_Current",
--     MAX(CASE WHEN B.ROW_NUM IN (16,10,5,22,23) THEN ROUND(A.MEASURE_VALUES,0) ELSE NULL END) AS "Gross_Order",
--     MAX(CASE WHEN B.ROW_NUM IN (6,15,20) THEN ROUND(A.MEASURE_VALUES,0) ELSE NULL END) AS "Net_Orders_Current",
--     MAX(CASE WHEN B.ROW_NUM IN (7,9,14) THEN A.MEASURE_VALUES ELSE NULL END) AS "Net_Revenue",
--     MAX(CASE WHEN B.ROW_NUM IN (21,24) THEN A.MEASURE_VALUES ELSE NULL END) AS "gross_order_cvr",
--     TO_DATE(TO_CHAR(A."YEAR") || '-' || TO_CHAR(A."MONTH") || '-' || TO_CHAR(A."DAY"), 'YYYY-MM-DD') AS DT_CREATION
--   FROM OW_LAO.TMP_GLOBAL_BI_TRAFFIC_VD A
--   LEFT JOIN OW_LAO.DIM_MEASURE_NAMES_TRAFFIC B
--     ON B.Measure_Names = A.Measure_Names
--   GROUP BY
--     A.REGION,
--     A.SUBSIDIARY,
--     A.COUNTRY,
--     A."YEAR",
--     A."MONTH",
--     A.WEEK,
--     A."DAY",
--     A.CHANNEL_GROUP_1,
--     A.CHANNEL_GROUP_2,
--     A.FILE_NAME,
--     A.RPA_DATE;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 39.15 of source string: syntax error, unexpected ;, expecting INTO, Sqlstate: 42601, Position: 1636, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
CREATE OR REPLACE PROCEDURE OW_LAO.PROC_LAO_TF_GLOBAL_BI_TRAFFIC_VD()
LANGUAGE PLvSQL AS $$
BEGIN
  -- Prepare temp output table structure
  PERFORM CREATE LOCAL TEMPORARY TABLE IF NOT EXISTS TMP_LAO_TF_GLOBAL_BI_TRAFFIC_VD_OUT ON COMMIT PRESERVE ROWS AS
    SELECT
      A.REGION,
      A.SUBSIDIARY,
      A.COUNTRY,
      A."YEAR",
      A."MONTH",
      A.WEEK,
      A."DAY",
      A.CHANNEL_GROUP_1,
      A.CHANNEL_GROUP_2,
      A.FILE_NAME,
      A.RPA_DATE,
      CAST(NULL AS NUMERIC) AS "COM_Visit",
      CAST(NULL AS NUMERIC) AS "Shopper_Visit",
      CAST(NULL AS NUMERIC) AS "Add_to_Cart_Current",
      CAST(NULL AS NUMERIC) AS "Cart_Page_Visit_Current",
      CAST(NULL AS NUMERIC) AS "Checkout_Page_Current",
      CAST(NULL AS NUMERIC) AS "Gross_Order",
      CAST(NULL AS NUMERIC) AS "Net_Orders_Current",
      CAST(NULL AS NUMERIC) AS "Net_Revenue",
      CAST(NULL AS NUMERIC) AS "gross_order_cvr",
      TO_DATE(TO_CHAR(A."YEAR") || '-' || TO_CHAR(A."MONTH") || '-' || TO_CHAR(A."DAY"), 'YYYY-MM-DD') AS DT_CREATION
    FROM OW_LAO.TMP_GLOBAL_BI_TRAFFIC_VD A
    LEFT JOIN OW_LAO.DIM_MEASURE_NAMES_TRAFFIC B
      ON B.Measure_Names = A.Measure_Names
    WHERE 1=0;

  -- Refresh data
  PERFORM TRUNCATE TABLE TMP_LAO_TF_GLOBAL_BI_TRAFFIC_VD_OUT;

  PERFORM INSERT INTO TMP_LAO_TF_GLOBAL_BI_TRAFFIC_VD_OUT
  SELECT
    A.REGION,
    A.SUBSIDIARY,
    A.COUNTRY,
    A."YEAR",
    A."MONTH",
    A.WEEK,
    A."DAY",
    A.CHANNEL_GROUP_1,
    A.CHANNEL_GROUP_2,
    A.FILE_NAME,
    A.RPA_DATE,
    MAX(CASE WHEN B.ROW_NUM IN (1) THEN A.MEASURE_VALUES END) AS "COM_Visit",
    MAX(CASE WHEN B.ROW_NUM IN (8,11,12,13) THEN A.MEASURE_VALUES END) AS "Shopper_Visit",
    MAX(CASE WHEN B.ROW_NUM IN (19,2) THEN A.MEASURE_VALUES END) AS "Add_to_Cart_Current",
    MAX(CASE WHEN B.ROW_NUM IN (18,3) THEN A.MEASURE_VALUES END) AS "Cart_Page_Visit_Current",
    MAX(CASE WHEN B.ROW_NUM IN (17,4) THEN A.MEASURE_VALUES END) AS "Checkout_Page_Current",
    MAX(CASE WHEN B.ROW_NUM IN (16,10,5,22,23) THEN ROUND(A.MEASURE_VALUES,0) END) AS "Gross_Order",
    MAX(CASE WHEN B.ROW_NUM IN (6,15,20) THEN ROUND(A.MEASURE_VALUES,0) END) AS "Net_Orders_Current",
    MAX(CASE WHEN B.ROW_NUM IN (7,9,14) THEN A.MEASURE_VALUES END) AS "Net_Revenue",
    MAX(CASE WHEN B.ROW_NUM IN (21,24) THEN A.MEASURE_VALUES END) AS "gross_order_cvr",
    TO_DATE(TO_CHAR(A."YEAR") || '-' || TO_CHAR(A."MONTH") || '-' || TO_CHAR(A."DAY"), 'YYYY-MM-DD') AS DT_CREATION
  FROM OW_LAO.TMP_GLOBAL_BI_TRAFFIC_VD A
  LEFT JOIN OW_LAO.DIM_MEASURE_NAMES_TRAFFIC B
    ON B.Measure_Names = A.Measure_Names
  GROUP BY
    A.REGION,
    A.SUBSIDIARY,
    A.COUNTRY,
    A."YEAR",
    A."MONTH",
    A.WEEK,
    A."DAY",
    A.CHANNEL_GROUP_1,
    A.CHANNEL_GROUP_2,
    A.FILE_NAME,
    A.RPA_DATE;
END;
$$;

-- CALL OW_LAO.PROC_LAO_TF_GLOBAL_BI_TRAFFIC_VD();
-- ERROR: Severity: ERROR, Message: Relation "OW_LAO.DIM_MEASURE_NAMES_TRAFFIC" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_LAO_TF_GLOBAL_BI_TRAFFIC_VD line 4 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
-- CALL OW_LAO.PROC_LAO_TF_GLOBAL_BI_TRAFFIC_VD();
-- ERROR: Severity: ERROR, Message: Relation "OW_LAO.DIM_MEASURE_NAMES_TRAFFIC" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_LAO_TF_GLOBAL_BI_TRAFFIC_VD line 4 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
