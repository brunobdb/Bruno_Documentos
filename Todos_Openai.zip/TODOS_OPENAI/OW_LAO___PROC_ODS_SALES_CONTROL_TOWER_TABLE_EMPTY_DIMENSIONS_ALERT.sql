-- CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_sales_control_tower_table_empty_dimensions_alert()
-- LANGUAGE PLvSQL AS $$
-- BEGIN 
--   
--   PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_sales_control_tower_table_dimensions ON COMMIT PRESERVE ROWS AS (
--     SELECT DISTINCT  
--            country
--          , po_devicetype
--          , po_storename
--          , audience_type
--          , biz_type
--       FROM ow_lao.ods_sales_control_tower_table
--      WHERE po_date >= TIMESTAMPADD(DAY, -10, CURRENT_DATE)
--        AND po_devicetype IS NOT NULL 
--        AND po_storename IS NOT NULL
--   );
--       
--   SELECT a.country
--        , a.po_devicetype
--        , a.po_storename
--        , a.audience_type
--        , a.biz_type
--        , COUNT(b.id) AS quantity
--     FROM tmp_ods_sales_control_tower_table_dimensions a
--     LEFT JOIN ow_lao.ods_sales_control_tower_table      b ON b.country       = a.country      
--                                                          AND b.po_devicetype = a.po_devicetype 
--                                                          AND b.po_storename  = a.po_storename 
--                                                          AND b.audience_type = a.audience_type
--                                                          AND b.biz_type      = a.biz_type   
--                                                          AND b.po_date      >= TIMESTAMPADD(DAY, -5, CURRENT_DATE)
--    GROUP BY a.country
--          , a.po_devicetype
--          , a.po_storename
--          , a.audience_type
--          , a.biz_type
--   HAVING COUNT(b.id) = 0;
--   
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 35.25 of source string: syntax error, unexpected ;, expecting INTO, Sqlstate: 42601, Position: 1508, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
-- CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_sales_control_tower_table_empty_dimensions_alert()
-- LANGUAGE PLvSQL AS $$
-- BEGIN 
--   
--   PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_sales_control_tower_table_dimensions ON COMMIT PRESERVE ROWS AS 
--     SELECT DISTINCT  
--            country
--          , po_devicetype
--          , po_storename
--          , audience_type
--          , biz_type
--       FROM ow_lao.ods_sales_control_tower_table
--      WHERE po_date >= TIMESTAMPADD(DAY, -10, CURRENT_DATE)
--        AND po_devicetype IS NOT NULL 
--        AND po_storename IS NOT NULL;
--       
--   SELECT a.country
--        , a.po_devicetype
--        , a.po_storename
--        , a.audience_type
--        , a.biz_type
--        , COUNT(b.id) AS quantity
--     FROM tmp_ods_sales_control_tower_table_dimensions a
--     LEFT JOIN ow_lao.ods_sales_control_tower_table      b ON b.country       = a.country      
--                                                          AND b.po_devicetype = a.po_devicetype 
--                                                          AND b.po_storename  = a.po_storename 
--                                                          AND b.audience_type = a.audience_type
--                                                          AND b.biz_type      = a.biz_type   
--                                                          AND b.po_date      >= TIMESTAMPADD(DAY, -5, CURRENT_DATE)
--    GROUP BY a.country
--          , a.po_devicetype
--          , a.po_storename
--          , a.audience_type
--          , a.biz_type
--   HAVING COUNT(b.id) = 0;
--   
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 34.25 of source string: syntax error, unexpected ;, expecting INTO, Sqlstate: 42601, Position: 1503, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
-- CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_sales_control_tower_table_empty_dimensions_alert()
-- LANGUAGE PLvSQL AS $$
-- BEGIN 
--   
--   PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_sales_control_tower_table_dimensions ON COMMIT PRESERVE ROWS AS 
--     SELECT DISTINCT  
--            country
--          , po_devicetype
--          , po_storename
--          , audience_type
--          , biz_type
--       FROM ow_lao.ods_sales_control_tower_table
--      WHERE po_date >= TIMESTAMPADD(DAY, -10, CURRENT_DATE)
--        AND po_devicetype IS NOT NULL 
--        AND po_storename IS NOT NULL;
--       
--   RETURN QUERY SELECT a.country
--        , a.po_devicetype
--        , a.po_storename
--        , a.audience_type
--        , a.biz_type
--        , COUNT(b.id) AS quantity
--     FROM tmp_ods_sales_control_tower_table_dimensions a
--     LEFT JOIN ow_lao.ods_sales_control_tower_table      b ON b.country       = a.country      
--                                                          AND b.po_devicetype = a.po_devicetype 
--                                                          AND b.po_storename  = a.po_storename 
--                                                          AND b.audience_type = a.audience_type
--                                                          AND b.biz_type      = a.biz_type   
--                                                          AND b.po_date      >= TIMESTAMPADD(DAY, -5, CURRENT_DATE)
--    GROUP BY a.country
--          , a.po_devicetype
--          , a.po_storename
--          , a.audience_type
--          , a.biz_type
--   HAVING COUNT(b.id) = 0;
--   
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 16.10-14 of source string: syntax error, unexpected QUERY, expecting := or <-, Sqlstate: 42601, Position: 573, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_sales_control_tower_table_empty_dimensions_alert()
LANGUAGE PLvSQL AS $$
BEGIN 
  PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_sales_control_tower_table_dimensions ON COMMIT PRESERVE ROWS AS
    SELECT DISTINCT  
           country
         , po_devicetype
         , po_storename
         , audience_type
         , biz_type
      FROM ow_lao.ods_sales_control_tower_table
     WHERE po_date >= TIMESTAMPADD(DAY, -10, CURRENT_DATE)
       AND po_devicetype IS NOT NULL 
       AND po_storename IS NOT NULL;
  
  PERFORM CREATE LOCAL TEMPORARY TABLE tmp_proc_ods_sales_control_tower_table_empty_dimensions_alert_result ON COMMIT PRESERVE ROWS AS
    SELECT a.country
         , a.po_devicetype
         , a.po_storename
         , a.audience_type
         , a.biz_type
         , COUNT(b.id) AS quantity
      FROM tmp_ods_sales_control_tower_table_dimensions a
      LEFT JOIN ow_lao.ods_sales_control_tower_table b
        ON b.country       = a.country      
       AND b.po_devicetype = a.po_devicetype 
       AND b.po_storename  = a.po_storename 
       AND b.audience_type = a.audience_type
       AND b.biz_type      = a.biz_type   
       AND b.po_date      >= TIMESTAMPADD(DAY, -5, CURRENT_DATE)
     GROUP BY a.country
            , a.po_devicetype
            , a.po_storename
            , a.audience_type
            , a.biz_type
    HAVING COUNT(b.id) = 0;
END;
$$;

CALL OW_LAO.proc_ods_sales_control_tower_table_empty_dimensions_alert();
-- proc_ods_sales_control_tower_table_empty_dimensions_alert
-- ---------------------------------------------------------
-- 0

