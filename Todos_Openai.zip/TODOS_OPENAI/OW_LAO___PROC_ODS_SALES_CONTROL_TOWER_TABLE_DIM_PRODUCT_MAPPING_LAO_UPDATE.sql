CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_sales_control_tower_table_dim_product_mapping_lao_update()
LANGUAGE PLvSQL AS $$
BEGIN
   PERFORM UPDATE OW_LAO.ods_sales_control_tower_table a
      SET product = c.product,
          product_family = c.product_family,
          product_group = c.product_group,
          division = c.division,
          product_category = c.product_category
     FROM "OW_LAO"."DIM_PRODUCT_MAPPING_LAO" c
    WHERE LOWER(c.item) = LOWER(a.po_sku)
      AND a.division = 'Unmapped';

   PERFORM UPDATE OW_LAO.ods_sales_control_tower_table a
      SET product = NULL,
          product_family = NULL,
          product_group = NULL,
          division = 'Unmapped',
          product_category = NULL
    WHERE a.division IS NULL;
END;
$$;

CALL OW_LAO.proc_ods_sales_control_tower_table_dim_product_mapping_lao_update();
-- proc_ods_sales_control_tower_table_dim_product_mapping_lao_update
-- -----------------------------------------------------------------
-- 0

