-- CREATE OR REPLACE PROCEDURE OW_LAO.RAW_VTEX_PAYMENTS_FILES_GET()
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--     SELECT id,
--            file_path,
--            file_name
--     FROM OW_LAO.RAW_VTEX_PAYMENTS_FILES
--     WHERE processed = FALSE
--       AND file_path LIKE '\\105.202.32.19\SHARED\LAO\LAO\VTEX_PAYMENTS\year=2025\month=01\day=31\hour=14\%';
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 8.108 of source string: syntax error, unexpected ;, expecting INTO, Sqlstate: 42601, Position: 327, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
-- CREATE OR REPLACE PROCEDURE OW_LAO.RAW_VTEX_PAYMENTS_FILES_GET()
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--     RETURN QUERY
--     SELECT id,
--            file_path,
--            file_name
--     FROM OW_LAO.RAW_VTEX_PAYMENTS_FILES
--     WHERE processed = FALSE
--       AND file_path LIKE '\\105.202.32.19\SHARED\LAO\LAO\VTEX_PAYMENTS\year=2025\month=01\day=31\hour=14\%';
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 3.12-16 of source string: syntax error, unexpected QUERY, expecting := or <-, Sqlstate: 42601, Position: 105, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
CREATE OR REPLACE PROCEDURE OW_LAO.RAW_VTEX_PAYMENTS_FILES_GET()
LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM CREATE LOCAL TEMP TABLE RAW_VTEX_PAYMENTS_FILES_GET_RS ON COMMIT PRESERVE ROWS AS
        SELECT id,
               file_path,
               file_name
        FROM OW_LAO.RAW_VTEX_PAYMENTS_FILES
        WHERE processed = FALSE
          AND file_path LIKE '\105.202.32.19\SHARED\LAO\LAO\VTEX_PAYMENTS\year=2025\month=01\day=31\hour=14\%';
END;
$$;

CALL OW_LAO.RAW_VTEX_PAYMENTS_FILES_GET();
-- RAW_VTEX_PAYMENTS_FILES_GET
-- ---------------------------
-- 0

