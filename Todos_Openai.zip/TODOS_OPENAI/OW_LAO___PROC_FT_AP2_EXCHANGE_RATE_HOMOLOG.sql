-- CREATE OR REPLACE PROCEDURE ow_lao.proc_ft_ap2_exchange_rate_homolog()
-- LANGUAGE PLvSQL AS $$
-- DECLARE 
--     load_date_newest DATE;
--     load_date_not_exists BOOLEAN;
-- BEGIN
--     -- Get newest load_date where Exchange Rate Type = 'M'
--     SELECT MAX(a."load_date")
--       INTO load_date_newest
--       FROM ow_lao.ods_erp_exchange_rate a
--      WHERE a."Exchange Rate Type" = 'M';
-- 
--     -- Check if that load_date already exists in target
--     SELECT CASE WHEN COUNT(1) > 0 THEN TRUE ELSE FALSE END
--       INTO load_date_not_exists
--       FROM ow_lao.ft_ap2_exchange_rate_homolog b
--      WHERE b.load_date = load_date_newest;
-- 
--     IF load_date_not_exists = FALSE THEN
--         -- Prep temp tables
--         PERFORM DROP TABLE IF EXISTS ods_erp_exchange_rate_temp;
--         PERFORM DROP TABLE IF EXISTS ods_erp_exchange_rate_null_fix;
-- 
--         PERFORM CREATE LOCAL TEMPORARY TABLE ods_erp_exchange_rate_temp ON COMMIT PRESERVE ROWS AS (
--             SELECT 
--                    "From currency"                  AS from_currency
--                  , "To-currency"                    AS to_currency
--                  , REPLACE("Valid from", '.', '-')  AS valid_from
--                  , REPLACE("Exchange Rate", ',', '') AS exchange_rate
--                  , load_date
--                  , CAST(NULL AS VARCHAR(256))        AS process_status
--                  , CAST(NULL AS VARCHAR(256))        AS comment_status
--                  , CAST(NULL AS INT)                 AS dedup
--               FROM ow_lao.ods_erp_exchange_rate
--              WHERE 1 = 0
--         );
-- 
--         PERFORM INSERT INTO ods_erp_exchange_rate_temp 
--             SELECT DISTINCT
--                    a."From currency"                    AS from_currency
--                  , a."To-currency"                      AS to_currency
--                  , REPLACE(a."Valid from", '.', '-')    AS valid_from
--                  , REPLACE(a."Exchange Rate", ',', '')  AS exchange_rate
--                  , a.load_date                           AS load_date
--                  , NULL                                  AS process_status
--                  , NULL                                  AS comment_status
--                  , ROW_NUMBER() OVER (
--                         PARTITION BY a."From currency", a."To-currency", REPLACE(a."Valid from", '.', '-')
--                         ORDER BY a.load_date DESC
--                    )                                     AS dedup
--               FROM ow_lao.ods_erp_exchange_rate a
--              WHERE a."Exchange Rate Type" = 'M'
--                AND a."Exchange Rate" IS NOT NULL
--                AND a.load_date = load_date_newest;
-- 
--         PERFORM CREATE LOCAL TEMPORARY TABLE ods_erp_exchange_rate_null_fix ON COMMIT PRESERVE ROWS AS (
--             SELECT a."From currency"
--                  , a."To-currency"
--                  , a."Valid from"
--                  , CAST(NULL AS DATE) AS valid_from_next_not_null_value
--                  , CAST(NULL AS DATE) AS load_date_next_not_null_value
--               FROM ow_lao.ods_erp_exchange_rate a
--              WHERE 1 = 0
--         );
-- 
--         PERFORM INSERT INTO ods_erp_exchange_rate_null_fix
--             SELECT a."From currency"
--                  , a."To-currency"
--                  , a."Valid from"
--                  , MIN(CAST(REPLACE(b."Valid from", '.', '-') AS DATE)) AS valid_from_next_not_null_value
--                  , MIN(b.load_date)                                      AS load_date_next_not_null_value
--               FROM ow_lao.ods_erp_exchange_rate a
--               JOIN ow_lao.ods_erp_exchange_rate b
--                 ON b."From currency" = a."From currency"
--                AND b."To-currency"   = a."To-currency"
--                AND CAST(REPLACE(b."Valid from", '.', '-') AS DATE) > CAST(REPLACE(a."Valid from", '.', '-') AS DATE)
--              WHERE a."Exchange Rate" IS NULL
--                AND b."Exchange Rate" IS NOT NULL
--                AND b."Exchange Rate Type" = 'M'
--                AND a.load_date = load_date_newest
--                AND NOT EXISTS (
--                     SELECT 1
--                       FROM ods_erp_exchange_rate_temp aa
--                      WHERE aa.from_currency = a."From currency"
--                        AND aa.to_currency   = a."To-currency"
--                        AND aa.valid_from    = REPLACE(a."Valid from", '.', '-')
--                )
--              GROUP BY a."From currency", a."To-currency", a."Valid from"
--              ORDER BY a."From currency", a."To-currency", a."Valid from";
-- 
--         PERFORM INSERT INTO ods_erp_exchange_rate_null_fix
--             SELECT a."From currency"
--                  , a."To-currency"
--                  , a."Valid from"
--                  , MAX(CAST(REPLACE(b."Valid from", '.', '-') AS DATE)) AS valid_from_next_not_null_value
--                  , MAX(b.load_date)                                      AS load_date_next_not_null_value
--               FROM ow_lao.ods_erp_exchange_rate a
--               JOIN ow_lao.ods_erp_exchange_rate b
--                 ON b."From currency" = a."From currency"
--                AND b."To-currency"   = a."To-currency"
--                AND CAST(REPLACE(b."Valid from", '.', '-') AS DATE) < CAST(REPLACE(a."Valid from", '.', '-') AS DATE)
--              WHERE a."Exchange Rate" IS NULL
--                AND b."Exchange Rate" IS NOT NULL
--                AND b."Exchange Rate Type" = 'M'
--                AND a.load_date = load_date_newest
--                AND NOT EXISTS (
--                     SELECT 1
--                       FROM ods_erp_exchange_rate_temp aa
--                      WHERE aa.from_currency = a."From currency"
--                        AND aa.to_currency   = a."To-currency"
--                        AND aa.valid_from    = REPLACE(a."Valid from", '.', '-')
--                )
--                AND NOT EXISTS (
--                     SELECT 1
--                       FROM ods_erp_exchange_rate_null_fix aa
--                      WHERE aa."From currency" = a."From currency"
--                        AND aa."To-currency"   = a."To-currency"
--                        AND aa."Valid from"    = a."Valid from"
--                )
--              GROUP BY a."From currency", a."To-currency", a."Valid from"
--              ORDER BY a."From currency", a."To-currency", a."Valid from";
-- 
--         PERFORM INSERT INTO ods_erp_exchange_rate_null_fix
--             SELECT a."From currency"
--                  , a."To-currency"
--                  , TO_CHAR(DATEADD(DAY, -1, CURRENT_DATE), 'YYYY.MM.DD') AS "Valid from"
--                  , MAX(CAST(REPLACE(a."Valid from", '.', '-') AS DATE)) AS valid_from_next_not_null_value
--                  , MAX(a.load_date)                                      AS load_date_next_not_null_value
--               FROM ow_lao.ods_erp_exchange_rate a
--              WHERE a."Exchange Rate" IS NOT NULL
--                AND a."Exchange Rate Type" = 'M'
--                AND NOT EXISTS (
--                     SELECT 1
--                       FROM ods_erp_exchange_rate_temp aa
--                      WHERE aa.from_currency = a."From currency"
--                        AND aa.to_currency   = a."To-currency"
--                        AND aa.valid_from    = TO_CHAR(DATEADD(DAY, -1, CURRENT_DATE), 'YYYY-MM-DD')
--                )
--              GROUP BY a."From currency", a."To-currency";
-- 
--         PERFORM INSERT INTO ods_erp_exchange_rate_temp
--             SELECT DISTINCT
--                    a."From currency"                    AS from_currency
--                  , a."To-currency"                      AS to_currency
--                  , REPLACE(b."Valid from", '.', '-')    AS valid_from
--                  , REPLACE(a."Exchange Rate", ',', '')  AS exchange_rate
--                  , a.load_date                           AS load_date
--                  , 'ADJUSTMENT'                          AS process_status
--                  , 'Null on GERP'                        AS comment_status
--                  , ROW_NUMBER() OVER (
--                         PARTITION BY b."From currency", b."To-currency", REPLACE(b."Valid from", '.', '-')
--                         ORDER BY a.load_date DESC
--                    )                                     AS dedup
--               FROM ow_lao.ods_erp_exchange_rate a
--               JOIN ods_erp_exchange_rate_null_fix b
--                 ON b."From currency"                 = a."From currency"
--                AND b."To-currency"                   = a."To-currency"
--                AND b.valid_from_next_not_null_value   = CAST(REPLACE(a."Valid from", '.', '-') AS DATE)
--                AND b.load_date_next_not_null_value    = a.load_date
--              WHERE a."Exchange Rate Type" = 'M'
--                AND a."Exchange Rate" IS NOT NULL
--              ORDER BY a."From currency", a."To-currency", REPLACE(b."Valid from", '.', '-')
--         ;
-- 
--         PERFORM DELETE FROM ods_erp_exchange_rate_temp WHERE dedup <> 1;
-- 
--         PERFORM MERGE INTO ow_lao.ft_ap2_exchange_rate_homolog a
--         USING ods_erp_exchange_rate_temp b
--            ON b.from_currency = a.from_currency
--           AND b.to_currency   = a.to_currency
--           AND b.valid_from    = a.valid_from
--         WHEN MATCHED THEN UPDATE SET
--               load_date         = b.load_date
--             , exchange_rate     = b.exchange_rate
--             , process_status    = b.process_status
--             , comment_status    = b.comment_status
--             , updated_timestamp = CURRENT_TIMESTAMP
--         WHEN NOT MATCHED THEN INSERT (
--               from_currency
--             , to_currency
--             , valid_from
--             , load_date
--             , exchange_rate
--             , process_status
--             , comment_status
--         ) VALUES (
--               b.from_currency
--             , b.to_currency
--             , b.valid_from
--             , b.load_date
--             , b.exchange_rate
--             , b.process_status
--             , b.comment_status
--         );
-- 
--         -- Return temp data for inspection
--         SELECT * FROM ods_erp_exchange_rate_temp;
--         SELECT * FROM ods_erp_exchange_rate_null_fix;
-- 
--     ELSE
--         SELECT 'Not new data to import' AS message;
--         RETURN;
--     END IF;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 196.49 of source string: syntax error, unexpected ;, expecting INTO, Sqlstate: 42601, Position: 9755, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
CREATE OR REPLACE PROCEDURE ow_lao.proc_ft_ap2_exchange_rate_homolog()
LANGUAGE PLvSQL AS $$
DECLARE 
    load_date_newest DATE;
    load_date_not_exists BOOLEAN;
BEGIN
    -- Get newest load_date where Exchange Rate Type = 'M'
    SELECT MAX(a.load_date)
      INTO load_date_newest
      FROM ow_lao.ods_erp_exchange_rate a
     WHERE a."Exchange Rate Type" = 'M';

    -- Check if that load_date already exists in target
    SELECT CASE WHEN COUNT(1) > 0 THEN TRUE ELSE FALSE END
      INTO load_date_not_exists
      FROM ow_lao.ft_ap2_exchange_rate_homolog b
     WHERE b.load_date = load_date_newest;

    IF load_date_not_exists = FALSE THEN
        -- Prep temp tables
        PERFORM DROP TABLE IF EXISTS ods_erp_exchange_rate_temp;
        PERFORM DROP TABLE IF EXISTS ods_erp_exchange_rate_null_fix;

        PERFORM CREATE LOCAL TEMPORARY TABLE ods_erp_exchange_rate_temp ON COMMIT PRESERVE ROWS AS (
            SELECT 
                   "From currency"                  AS from_currency
                 , "To-currency"                    AS to_currency
                 , REPLACE("Valid from", '.', '-')  AS valid_from
                 , REPLACE("Exchange Rate", ',', '') AS exchange_rate
                 , load_date
                 , CAST(NULL AS VARCHAR(256))        AS process_status
                 , CAST(NULL AS VARCHAR(256))        AS comment_status
                 , CAST(NULL AS INT)                 AS dedup
              FROM ow_lao.ods_erp_exchange_rate
             WHERE 1 = 0
        );

        PERFORM INSERT INTO ods_erp_exchange_rate_temp 
            SELECT DISTINCT
                   a."From currency"                    AS from_currency
                 , a."To-currency"                      AS to_currency
                 , REPLACE(a."Valid from", '.', '-')    AS valid_from
                 , REPLACE(a."Exchange Rate", ',', '')  AS exchange_rate
                 , a.load_date                           AS load_date
                 , NULL                                  AS process_status
                 , NULL                                  AS comment_status
                 , ROW_NUMBER() OVER (
                        PARTITION BY a."From currency", a."To-currency", REPLACE(a."Valid from", '.', '-')
                        ORDER BY a.load_date DESC
                   )                                     AS dedup
              FROM ow_lao.ods_erp_exchange_rate a
             WHERE a."Exchange Rate Type" = 'M'
               AND a."Exchange Rate" IS NOT NULL
               AND a.load_date = load_date_newest;

        PERFORM CREATE LOCAL TEMPORARY TABLE ods_erp_exchange_rate_null_fix ON COMMIT PRESERVE ROWS AS (
            SELECT a."From currency"
                 , a."To-currency"
                 , a."Valid from"
                 , CAST(NULL AS DATE) AS valid_from_next_not_null_value
                 , CAST(NULL AS DATE) AS load_date_next_not_null_value
              FROM ow_lao.ods_erp_exchange_rate a
             WHERE 1 = 0
        );

        PERFORM INSERT INTO ods_erp_exchange_rate_null_fix
            SELECT a."From currency"
                 , a."To-currency"
                 , a."Valid from"
                 , MIN(CAST(REPLACE(b."Valid from", '.', '-') AS DATE)) AS valid_from_next_not_null_value
                 , MIN(b.load_date)                                      AS load_date_next_not_null_value
              FROM ow_lao.ods_erp_exchange_rate a
              JOIN ow_lao.ods_erp_exchange_rate b
                ON b."From currency" = a."From currency"
               AND b."To-currency"   = a."To-currency"
               AND CAST(REPLACE(b."Valid from", '.', '-') AS DATE) > CAST(REPLACE(a."Valid from", '.', '-') AS DATE)
             WHERE a."Exchange Rate" IS NULL
               AND b."Exchange Rate" IS NOT NULL
               AND b."Exchange Rate Type" = 'M'
               AND a.load_date = load_date_newest
               AND NOT EXISTS (
                    SELECT 1
                      FROM ods_erp_exchange_rate_temp aa
                     WHERE aa.from_currency = a."From currency"
                       AND aa.to_currency   = a."To-currency"
                       AND aa.valid_from    = REPLACE(a."Valid from", '.', '-')
               )
             GROUP BY a."From currency", a."To-currency", a."Valid from"
             ORDER BY a."From currency", a."To-currency", a."Valid from";

        PERFORM INSERT INTO ods_erp_exchange_rate_null_fix
            SELECT a."From currency"
                 , a."To-currency"
                 , a."Valid from"
                 , MAX(CAST(REPLACE(b."Valid from", '.', '-') AS DATE)) AS valid_from_next_not_null_value
                 , MAX(b.load_date)                                      AS load_date_next_not_null_value
              FROM ow_lao.ods_erp_exchange_rate a
              JOIN ow_lao.ods_erp_exchange_rate b
                ON b."From currency" = a."From currency"
               AND b."To-currency"   = a."To-currency"
               AND CAST(REPLACE(b."Valid from", '.', '-') AS DATE) < CAST(REPLACE(a."Valid from", '.', '-') AS DATE)
             WHERE a."Exchange Rate" IS NULL
               AND b."Exchange Rate" IS NOT NULL
               AND b."Exchange Rate Type" = 'M'
               AND a.load_date = load_date_newest
               AND NOT EXISTS (
                    SELECT 1
                      FROM ods_erp_exchange_rate_temp aa
                     WHERE aa.from_currency = a."From currency"
                       AND aa.to_currency   = a."To-currency"
                       AND aa.valid_from    = REPLACE(a."Valid from", '.', '-')
               )
               AND NOT EXISTS (
                    SELECT 1
                      FROM ods_erp_exchange_rate_null_fix aa
                     WHERE aa."From currency" = a."From currency"
                       AND aa."To-currency"   = a."To-currency"
                       AND aa."Valid from"    = a."Valid from"
               )
             GROUP BY a."From currency", a."To-currency", a."Valid from"
             ORDER BY a."From currency", a."To-currency", a."Valid from";

        PERFORM INSERT INTO ods_erp_exchange_rate_null_fix
            SELECT a."From currency"
                 , a."To-currency"
                 , TO_CHAR(TIMESTAMPADD('day', -1, CURRENT_DATE), 'YYYY.MM.DD') AS "Valid from"
                 , MAX(CAST(REPLACE(a."Valid from", '.', '-') AS DATE)) AS valid_from_next_not_null_value
                 , MAX(a.load_date)                                      AS load_date_next_not_null_value
              FROM ow_lao.ods_erp_exchange_rate a
             WHERE a."Exchange Rate" IS NOT NULL
               AND a."Exchange Rate Type" = 'M'
               AND NOT EXISTS (
                    SELECT 1
                      FROM ods_erp_exchange_rate_temp aa
                     WHERE aa.from_currency = a."From currency"
                       AND aa.to_currency   = a."To-currency"
                       AND aa.valid_from    = TO_CHAR(TIMESTAMPADD('day', -1, CURRENT_DATE), 'YYYY-MM-DD')
               )
             GROUP BY a."From currency", a."To-currency";

        PERFORM INSERT INTO ods_erp_exchange_rate_temp
            SELECT DISTINCT
                   a."From currency"                    AS from_currency
                 , a."To-currency"                      AS to_currency
                 , REPLACE(b."Valid from", '.', '-')    AS valid_from
                 , REPLACE(a."Exchange Rate", ',', '')  AS exchange_rate
                 , a.load_date                           AS load_date
                 , 'ADJUSTMENT'                          AS process_status
                 , 'Null on GERP'                        AS comment_status
                 , ROW_NUMBER() OVER (
                        PARTITION BY b."From currency", b."To-currency", REPLACE(b."Valid from", '.', '-')
                        ORDER BY a.load_date DESC
                   )                                     AS dedup
              FROM ow_lao.ods_erp_exchange_rate a
              JOIN ods_erp_exchange_rate_null_fix b
                ON b."From currency"                 = a."From currency"
               AND b."To-currency"                   = a."To-currency"
               AND b.valid_from_next_not_null_value   = CAST(REPLACE(a."Valid from", '.', '-') AS DATE)
               AND b.load_date_next_not_null_value    = a.load_date
             WHERE a."Exchange Rate Type" = 'M'
               AND a."Exchange Rate" IS NOT NULL
             ORDER BY a."From currency", a."To-currency", REPLACE(b."Valid from", '.', '-')
        ;

        PERFORM DELETE FROM ods_erp_exchange_rate_temp WHERE dedup <> 1;

        PERFORM MERGE INTO ow_lao.ft_ap2_exchange_rate_homolog a
        USING ods_erp_exchange_rate_temp b
           ON b.from_currency = a.from_currency
          AND b.to_currency   = a.to_currency
          AND b.valid_from    = a.valid_from
        WHEN MATCHED THEN UPDATE SET
              load_date         = b.load_date
            , exchange_rate     = b.exchange_rate
            , process_status    = b.process_status
            , comment_status    = b.comment_status
            , updated_timestamp = CURRENT_TIMESTAMP
        WHEN NOT MATCHED THEN INSERT (
              from_currency
            , to_currency
            , valid_from
            , load_date
            , exchange_rate
            , process_status
            , comment_status
        ) VALUES (
              b.from_currency
            , b.to_currency
            , b.valid_from
            , b.load_date
            , b.exchange_rate
            , b.process_status
            , b.comment_status
        );

    ELSE
        -- do nothing
        NULL;
    END IF;
END;
$$;

-- CALL ow_lao.proc_ft_ap2_exchange_rate_homolog();
-- ERROR: Severity: ERROR, Message: Relation "ow_lao.ft_ap2_exchange_rate_homolog" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ft_ap2_exchange_rate_homolog line 13 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
-- CALL ow_lao.proc_ft_ap2_exchange_rate_homolog();
-- ERROR: Severity: ERROR, Message: Relation "ow_lao.ft_ap2_exchange_rate_homolog" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ft_ap2_exchange_rate_homolog line 13 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
