-- CREATE OR REPLACE PROCEDURE ow_lao.proc_monitoring_bi_lao_proccess_sales_order_tracking()
-- LANGUAGE PLvSQL AS $$
-- DECLARE
--     synapcomMaxInserted TIMESTAMP := NULL;
--     salesOrderTrackingDaysFilter INT := -5;
-- BEGIN
--     SELECT MAX(po_source_insert_date)
--     INTO synapcomMaxInserted
--     FROM ow_lao.ods_sales_control_tower_table
--     WHERE po_plataform_datasource IN ('u_prj_ecom_synapcom.ft_ecom_order','u_prj_ecom.ft_ecom_order');
-- 
--     PERFORM DROP TABLE IF EXISTS ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter;
--     PERFORM CREATE TABLE ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter AS 
--         SELECT DISTINCT
--                ROW_NUMBER() OVER() AS id
--              , a.customer_po
--              , a.sales_document
--              , a.material
--              , a.sales_org
--              , a.load_date
--         FROM ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking a
--         WHERE 1=0;
-- 
--     PERFORM INSERT INTO ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter
--         (id, customer_po, sales_document, material, sales_org, load_date)
--     SELECT DISTINCT
--            ROW_NUMBER() OVER() AS id
--          , a.customer_po
--          , a.sales_document
--          , a.material
--          , a.sales_org
--          , a.load_date
--     FROM ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking a
--     WHERE CAST(a.so_create_on AS DATE) >= TIMESTAMPADD(DAY, salesOrderTrackingDaysFilter, CURRENT_DATE)
--       AND a.sales_org = '8201'
--       AND a.sales_doc_type = 'YS10'
--       AND a.last_modification_file <= synapcomMaxInserted;
-- 
--     PERFORM DROP TABLE IF EXISTS ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_delete;
--     PERFORM CREATE TABLE ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_delete AS
--     SELECT c.*
--       FROM ow_lao.ods_sales_control_tower_table a
--       JOIN ow_md.dim_subsidiary b ON LOWER(b.country) = LOWER(a.country)
--       JOIN ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter c
--         ON c.customer_po = a.po_sequence_orderid
--        AND c.sales_org   = b.sales_org
--     UNION ALL
--     SELECT c.*
--       FROM ow_lao.ods_sales_control_tower_table a
--       JOIN ow_md.dim_subsidiary b ON LOWER(b.country) = LOWER(a.country)
--       JOIN ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter c
--         ON c.sales_document = a.po_ordersid
--        AND c.sales_org      = b.sales_org
--     UNION ALL
--     SELECT c.*
--       FROM ow_lao.ods_sales_control_tower_table a
--       JOIN ow_md.dim_subsidiary b ON LOWER(b.country) = LOWER(a.country)
--       JOIN ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter c
--         ON c.customer_po    = a.po_orderid
--        AND c.sales_org      = b.sales_org;
-- 
--     PERFORM DELETE
--       FROM ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter a
--      WHERE id IN (SELECT DISTINCT id FROM ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_delete);
-- 
--     PERFORM INSERT INTO ow_lao.monitoring_bi_lao_proccess(
--                    origem_nome
--                  , processo_nome
--                  , referencia
--                  , quantidade
--     )
--     SELECT 'ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking' AS origem_nome
--          , 'Control Tower'                                   AS processo_nome
--          , ('customer_po: ' || customer_po || 'sales_document: ' || sales_document) AS referencia
--          , COUNT(1) AS quantidade
--       FROM ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter t
--      WHERE NOT EXISTS(
--                 SELECT 1
--                   FROM ow_lao.monitoring_bi_lao_proccess cc
--                  WHERE cc.processo_nome = 'Control Tower'
--                    AND cc.origem_nome   = 'ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking'
--                    AND cc.status_nome   = 'Em analise'
--                    AND cc.referencia    = ('customer_po: ' || t.customer_po || 'sales_document: ' || t.sales_document)
--                )
--      GROUP BY ('customer_po: ' || customer_po || 'sales_document: ' || sales_document);
-- 
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: Syntax error at or near "a", Sqlstate: 42601, Position: 2845, Routine: base_yyerror, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/scan.l, Line: 1056, Error Code: 4856, 
-- CREATE OR REPLACE PROCEDURE ow_lao.proc_monitoring_bi_lao_proccess_sales_order_tracking()
-- LANGUAGE PLvSQL AS $$
-- DECLARE
--     synapcomMaxInserted TIMESTAMP := NULL;
--     salesOrderTrackingDaysFilter INT := -5;
-- BEGIN
--     SELECT MAX(po_source_insert_date)
--     INTO synapcomMaxInserted
--     FROM ow_lao.ods_sales_control_tower_table
--     WHERE po_plataform_datasource IN ('u_prj_ecom_synapcom.ft_ecom_order','u_prj_ecom.ft_ecom_order');
-- 
--     PERFORM DROP TABLE IF EXISTS ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter;
--     PERFORM CREATE TABLE ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter AS 
--         SELECT DISTINCT
--                ROW_NUMBER() OVER(ORDER BY a.load_date DESC) AS id
--              , a.customer_po
--              , a.sales_document
--              , a.material
--              , a.sales_org
--              , a.load_date
--         FROM ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking a
--         WHERE 1=0;
-- 
--     PERFORM INSERT INTO ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter
--         (id, customer_po, sales_document, material, sales_org, load_date)
--     SELECT DISTINCT
--            ROW_NUMBER() OVER(ORDER BY a.load_date DESC) AS id
--          , a.customer_po
--          , a.sales_document
--          , a.material
--          , a.sales_org
--          , a.load_date
--     FROM ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking a
--     WHERE CAST(a.so_create_on AS DATE) >= TIMESTAMPADD(DAY, salesOrderTrackingDaysFilter, CURRENT_DATE)
--       AND a.sales_org = '8201'
--       AND a.sales_doc_type = 'YS10'
--       AND a.last_modification_file <= synapcomMaxInserted;
-- 
--     PERFORM DROP TABLE IF EXISTS ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_delete;
--     PERFORM CREATE TABLE ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_delete AS
--     (
--         SELECT c.*
--           FROM ow_lao.ods_sales_control_tower_table a
--           JOIN ow_md.dim_subsidiary b ON LOWER(b.country) = LOWER(a.country)
--           JOIN ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter c
--             ON c.customer_po = a.po_sequence_orderid
--            AND c.sales_org   = b.sales_org
--         UNION ALL
--         SELECT c.*
--           FROM ow_lao.ods_sales_control_tower_table a
--           JOIN ow_md.dim_subsidiary b ON LOWER(b.country) = LOWER(a.country)
--           JOIN ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter c
--             ON c.sales_document = a.po_ordersid
--            AND c.sales_org      = b.sales_org  
--         UNION ALL
--         SELECT c.*
--           FROM ow_lao.ods_sales_control_tower_table a
--           JOIN ow_md.dim_subsidiary b ON LOWER(b.country) = LOWER(a.country)
--           JOIN ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter c
--             ON c.customer_po    = a.po_orderid
--            AND c.sales_org      = b.sales_org
--     );
-- 
--     PERFORM DELETE
--       FROM ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter a
--      WHERE id IN (SELECT DISTINCT id FROM ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_delete);
-- 
--     PERFORM INSERT INTO ow_lao.monitoring_bi_lao_proccess(
--                    origem_nome
--                  , processo_nome
--                  , referencia
--                  , quantidade
--     )
--     SELECT 'ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking' AS origem_nome
--          , 'Control Tower'                                   AS processo_nome
--          , ('customer_po: ' || customer_po || 'sales_document: ' || sales_document) AS referencia
--          , COUNT(1) AS quantidade
--       FROM ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter t
--      WHERE NOT EXISTS(
--                 SELECT 1
--                   FROM ow_lao.monitoring_bi_lao_proccess cc
--                  WHERE cc.processo_nome = 'Control Tower'
--                    AND cc.origem_nome   = 'ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking'
--                    AND cc.status_nome   = 'Em analise'
--                    AND cc.referencia    = ('customer_po: ' || t.customer_po || 'sales_document: ' || t.sales_document)
--                )
--      GROUP BY ('customer_po: ' || customer_po || 'sales_document: ' || sales_document);
-- 
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: Syntax error at or near "a", Sqlstate: 42601, Position: 2989, Routine: base_yyerror, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/scan.l, Line: 1056, Error Code: 4856, 
CREATE OR REPLACE PROCEDURE ow_lao.proc_monitoring_bi_lao_proccess_sales_order_tracking()
LANGUAGE PLvSQL AS $$
DECLARE
    synapcomMaxInserted TIMESTAMP := NULL;
    salesOrderTrackingDaysFilter INT := -5;
BEGIN
    SELECT MAX(po_source_insert_date)
    INTO synapcomMaxInserted
    FROM ow_lao.ods_sales_control_tower_table
    WHERE po_plataform_datasource IN ('u_prj_ecom_synapcom.ft_ecom_order','u_prj_ecom.ft_ecom_order');

    PERFORM DROP TABLE IF EXISTS ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter;
    PERFORM CREATE TABLE ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter AS 
        SELECT DISTINCT
               ROW_NUMBER() OVER(ORDER BY a.load_date DESC) AS id
             , a.customer_po
             , a.sales_document
             , a.material
             , a.sales_org
             , a.load_date
        FROM ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking a
        WHERE 1=0;

    PERFORM INSERT INTO ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter
        (id, customer_po, sales_document, material, sales_org, load_date)
    SELECT DISTINCT
           ROW_NUMBER() OVER(ORDER BY a.load_date DESC) AS id
         , a.customer_po
         , a.sales_document
         , a.material
         , a.sales_org
         , a.load_date
    FROM ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking a
    WHERE CAST(a.so_create_on AS DATE) >= TIMESTAMPADD(DAY, salesOrderTrackingDaysFilter, CURRENT_DATE)
      AND a.sales_org = '8201'
      AND a.sales_doc_type = 'YS10'
      AND a.last_modification_file <= synapcomMaxInserted;

    PERFORM DROP TABLE IF EXISTS ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_delete;
    PERFORM CREATE TABLE ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_delete AS
    (
        SELECT c.*
          FROM ow_lao.ods_sales_control_tower_table a
          JOIN ow_md.dim_subsidiary b ON LOWER(b.country) = LOWER(a.country)
          JOIN ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter c
            ON c.customer_po = a.po_sequence_orderid
           AND c.sales_org   = b.sales_org
        UNION ALL
        SELECT c.*
          FROM ow_lao.ods_sales_control_tower_table a
          JOIN ow_md.dim_subsidiary b ON LOWER(b.country) = LOWER(a.country)
          JOIN ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter c
            ON c.sales_document = a.po_ordersid
           AND c.sales_org      = b.sales_org  
        UNION ALL
        SELECT c.*
          FROM ow_lao.ods_sales_control_tower_table a
          JOIN ow_md.dim_subsidiary b ON LOWER(b.country) = LOWER(a.country)
          JOIN ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter c
            ON c.customer_po    = a.po_orderid
           AND c.sales_org      = b.sales_org
    );

    PERFORM DELETE
      FROM ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter
     WHERE id IN (SELECT DISTINCT id FROM ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_delete);

    PERFORM INSERT INTO ow_lao.monitoring_bi_lao_proccess(
                   origem_nome
                 , processo_nome
                 , referencia
                 , quantidade
    )
    SELECT 'ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking' AS origem_nome
         , 'Control Tower'                                   AS processo_nome
         , ('customer_po: ' || customer_po || 'sales_document: ' || sales_document) AS referencia
         , COUNT(1) AS quantidade
      FROM ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter t
     WHERE NOT EXISTS(
                SELECT 1
                  FROM ow_lao.monitoring_bi_lao_proccess cc
                 WHERE cc.processo_nome = 'Control Tower'
                   AND cc.origem_nome   = 'ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking'
                   AND cc.status_nome   = 'Em analise'
                   AND cc.referencia    = ('customer_po: ' || t.customer_po || 'sales_document: ' || t.sales_document)
               )
     GROUP BY ('customer_po: ' || customer_po || 'sales_document: ' || sales_document);

END;
$$;

-- CALL ow_lao.proc_monitoring_bi_lao_proccess_sales_order_tracking();
-- ERROR: Severity: ERROR, Message: Operator does not exist: varchar <= timestamp, Sqlstate: 42883, Hint: No operator matches the given name and argument type(s). You may need to add explicit type casts, Where: PL/vSQL procedure proc_monitoring_bi_lao_proccess_sales_order_tracking line 23 at static SQL, Routine: op_error, File: parse_oper.c, Line: 608, Error Code: 4286, 
-- CALL ow_lao.proc_monitoring_bi_lao_proccess_sales_order_tracking();
-- ERROR: Severity: ERROR, Message: Operator does not exist: varchar <= timestamp, Sqlstate: 42883, Hint: No operator matches the given name and argument type(s). You may need to add explicit type casts, Where: PL/vSQL procedure proc_monitoring_bi_lao_proccess_sales_order_tracking line 23 at static SQL, Routine: op_error, File: parse_oper.c, Line: 608, Error Code: 4286, 
CREATE OR REPLACE PROCEDURE ow_lao.proc_monitoring_bi_lao_proccess_sales_order_tracking()
LANGUAGE PLvSQL AS $$
DECLARE
    synapcomMaxInserted TIMESTAMP := NULL;
    salesOrderTrackingDaysFilter INT := -5;
BEGIN
    SELECT MAX(po_source_insert_date)
    INTO synapcomMaxInserted
    FROM ow_lao.ods_sales_control_tower_table
    WHERE po_plataform_datasource IN ('u_prj_ecom_synapcom.ft_ecom_order','u_prj_ecom.ft_ecom_order');

    PERFORM DROP TABLE IF EXISTS ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter;
    PERFORM CREATE TABLE ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter AS 
        SELECT DISTINCT
               ROW_NUMBER() OVER(ORDER BY a.load_date DESC) AS id
             , a.customer_po
             , a.sales_document
             , a.material
             , a.sales_org
             , a.load_date
        FROM ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking a
        WHERE 1=0;

    PERFORM INSERT INTO ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter
        (id, customer_po, sales_document, material, sales_org, load_date)
    SELECT DISTINCT
           ROW_NUMBER() OVER(ORDER BY a.load_date DESC) AS id
         , a.customer_po
         , a.sales_document
         , a.material
         , a.sales_org
         , a.load_date
    FROM ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking a
    WHERE CAST(a.so_create_on AS DATE) >= TIMESTAMPADD(DAY, salesOrderTrackingDaysFilter, CURRENT_DATE)
      AND a.sales_org = '8201'
      AND a.sales_doc_type = 'YS10'
      AND CAST(a.last_modification_file AS TIMESTAMP) <= synapcomMaxInserted;

    PERFORM DROP TABLE IF EXISTS ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_delete;
    PERFORM CREATE TABLE ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_delete AS
    (
        SELECT c.*
          FROM ow_lao.ods_sales_control_tower_table a
          JOIN ow_md.dim_subsidiary b ON LOWER(b.country) = LOWER(a.country)
          JOIN ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter c
            ON c.customer_po = a.po_sequence_orderid
           AND c.sales_org   = b.sales_org
        UNION ALL
        SELECT c.*
          FROM ow_lao.ods_sales_control_tower_table a
          JOIN ow_md.dim_subsidiary b ON LOWER(b.country) = LOWER(a.country)
          JOIN ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter c
            ON c.sales_document = a.po_ordersid
           AND c.sales_org      = b.sales_org  
        UNION ALL
        SELECT c.*
          FROM ow_lao.ods_sales_control_tower_table a
          JOIN ow_md.dim_subsidiary b ON LOWER(b.country) = LOWER(a.country)
          JOIN ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter c
            ON c.customer_po    = a.po_orderid
           AND c.sales_org      = b.sales_org
    );

    PERFORM DELETE
      FROM ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter
     WHERE id IN (SELECT DISTINCT id FROM ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_delete);

    PERFORM INSERT INTO ow_lao.monitoring_bi_lao_proccess(
                   origem_nome
                 , processo_nome
                 , referencia
                 , quantidade
    )
    SELECT 'ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking' AS origem_nome
         , 'Control Tower'                                   AS processo_nome
         , ('customer_po: ' || t.customer_po || 'sales_document: ' || t.sales_document) AS referencia
         , COUNT(1) AS quantidade
      FROM ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter t
     WHERE NOT EXISTS(
                SELECT 1
                  FROM ow_lao.monitoring_bi_lao_proccess cc
                 WHERE cc.processo_nome = 'Control Tower'
                   AND cc.origem_nome   = 'ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking'
                   AND cc.status_nome   = 'Em analise'
                   AND cc.referencia    = ('customer_po: ' || t.customer_po || 'sales_document: ' || t.sales_document)
               )
     GROUP BY ('customer_po: ' || t.customer_po || 'sales_document: ' || t.sales_document);

END;
$$;

-- CALL ow_lao.proc_monitoring_bi_lao_proccess_sales_order_tracking();
-- ERROR: Severity: ERROR, Message: Cannot set NOT NULL columns (ID, STATUS_NOME) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure proc_monitoring_bi_lao_proccess_sales_order_tracking line 67 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3211, Error Code: 2514, 
-- CALL ow_lao.proc_monitoring_bi_lao_proccess_sales_order_tracking();
-- ERROR: Severity: ERROR, Message: Cannot set NOT NULL columns (ID, STATUS_NOME) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure proc_monitoring_bi_lao_proccess_sales_order_tracking line 67 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3211, Error Code: 2514, 
SELECT column_name, data_type, is_nullable, ordinal_position
FROM v_catalog.columns
WHERE table_schema = 'ow_lao' AND table_name = 'monitoring_bi_lao_proccess'
ORDER BY ordinal_position;
-- column_name | data_type | is_nullable | ordinal_position
-- ------------+-----------+-------------+-----------------

SELECT * FROM ow_lao.monitoring_bi_lao_proccess LIMIT 1;
-- ID | INSERTED_TIMESTAMP | UPDATED_TIMESTAMP | PROCESSO_NOME | ORIGEM_NOME | QUANTIDADE | REFERENCIA | STATUS_NOME | ANALISTA_NOME | OBSERVACAO
-- ---+--------------------+-------------------+---------------+-------------+------------+------------+-------------+---------------+-----------

SELECT column_name, data_type, is_nullable, column_default
FROM v_catalog.columns
WHERE table_schema ILIKE 'ow_lao' AND table_name ILIKE 'monitoring_bi_lao_proccess'
ORDER BY ordinal_position;
-- column_name | data_type | is_nullable | column_default
-- ------------+-----------+-------------+---------------
-- ID | int | False | 
-- INSERTED_TIMESTAMP | timestamp | True | 
-- UPDATED_TIMESTAMP | timestamp | True | 
-- PROCESSO_NOME | varchar(255) | True | 
-- ORIGEM_NOME | varchar(255) | True | 
-- QUANTIDADE | int | True | 
-- REFERENCIA | varchar(255) | False | 
-- STATUS_NOME | varchar(255) | False | 
-- ANALISTA_NOME | varchar(255) | True | 
-- OBSERVACAO | varchar(3000) | True | 

CREATE OR REPLACE PROCEDURE ow_lao.proc_monitoring_bi_lao_proccess_sales_order_tracking()
LANGUAGE PLvSQL AS $$
DECLARE
    synapcomMaxInserted TIMESTAMP := NULL;
    salesOrderTrackingDaysFilter INT := -5;
BEGIN
    SELECT MAX(po_source_insert_date)
    INTO synapcomMaxInserted
    FROM ow_lao.ods_sales_control_tower_table
    WHERE po_plataform_datasource IN ('u_prj_ecom_synapcom.ft_ecom_order','u_prj_ecom.ft_ecom_order');

    PERFORM DROP TABLE IF EXISTS ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter;
    PERFORM CREATE TABLE ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter AS 
        SELECT DISTINCT
               ROW_NUMBER() OVER(ORDER BY a.load_date DESC) AS id
             , a.customer_po
             , a.sales_document
             , a.material
             , a.sales_org
             , a.load_date
        FROM ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking a
        WHERE 1=0;

    PERFORM INSERT INTO ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter
        (id, customer_po, sales_document, material, sales_org, load_date)
    SELECT DISTINCT
           ROW_NUMBER() OVER(ORDER BY a.load_date DESC) AS id
         , a.customer_po
         , a.sales_document
         , a.material
         , a.sales_org
         , a.load_date
    FROM ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking a
    WHERE CAST(a.so_create_on AS DATE) >= TIMESTAMPADD(DAY, salesOrderTrackingDaysFilter, CURRENT_DATE)
      AND a.sales_org = '8201'
      AND a.sales_doc_type = 'YS10'
      AND CAST(a.last_modification_file AS TIMESTAMP) <= synapcomMaxInserted;

    PERFORM DROP TABLE IF EXISTS ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_delete;
    PERFORM CREATE TABLE ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_delete AS
    (
        SELECT c.*
          FROM ow_lao.ods_sales_control_tower_table a
          JOIN ow_md.dim_subsidiary b ON LOWER(b.country) = LOWER(a.country)
          JOIN ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter c
            ON c.customer_po = a.po_sequence_orderid
           AND c.sales_org   = b.sales_org
        UNION ALL
        SELECT c.*
          FROM ow_lao.ods_sales_control_tower_table a
          JOIN ow_md.dim_subsidiary b ON LOWER(b.country) = LOWER(a.country)
          JOIN ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter c
            ON c.sales_document = a.po_ordersid
           AND c.sales_org      = b.sales_org  
        UNION ALL
        SELECT c.*
          FROM ow_lao.ods_sales_control_tower_table a
          JOIN ow_md.dim_subsidiary b ON LOWER(b.country) = LOWER(a.country)
          JOIN ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter c
            ON c.customer_po    = a.po_orderid
           AND c.sales_org      = b.sales_org
    );

    PERFORM DELETE
      FROM ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter
     WHERE id IN (SELECT DISTINCT id FROM ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter_delete);

    PERFORM INSERT INTO ow_lao.monitoring_bi_lao_proccess(
                   id
                 , inserted_timestamp
                 , updated_timestamp
                 , processo_nome
                 , origem_nome
                 , quantidade
                 , referencia
                 , status_nome
                 , analista_nome
                 , observacao
    )
    WITH base AS (
        SELECT COALESCE(MAX(ID),0) AS max_id FROM ow_lao.monitoring_bi_lao_proccess
    ), src AS (
        SELECT 
            ('customer_po: ' || t.customer_po || 'sales_document: ' || t.sales_document) AS referencia,
            COUNT(1) AS quantidade
        FROM ow_lao.temp_ods_sales_control_tower_table_nerp_update_monitoring_filter t
        WHERE NOT EXISTS(
                    SELECT 1
                      FROM ow_lao.monitoring_bi_lao_proccess cc
                     WHERE cc.processo_nome = 'Control Tower'
                       AND cc.origem_nome   = 'ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking'
                       AND cc.status_nome   = 'Em analise'
                       AND cc.referencia    = ('customer_po: ' || t.customer_po || 'sales_document: ' || t.sales_document)
                )
        GROUP BY ('customer_po: ' || t.customer_po || 'sales_document: ' || t.sales_document)
    )
    SELECT 
        b.max_id + ROW_NUMBER() OVER (ORDER BY s.referencia) AS id,
        CURRENT_TIMESTAMP AS inserted_timestamp,
        CURRENT_TIMESTAMP AS updated_timestamp,
        'Control Tower' AS processo_nome,
        'ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking' AS origem_nome,
        s.quantidade,
        s.referencia,
        'Em analise' AS status_nome,
        NULL::VARCHAR AS analista_nome,
        NULL::VARCHAR AS observacao
    FROM src s
    CROSS JOIN base b;

END;
$$;

CALL ow_lao.proc_monitoring_bi_lao_proccess_sales_order_tracking();
-- proc_monitoring_bi_lao_proccess_sales_order_tracking
-- ----------------------------------------------------
-- 0

