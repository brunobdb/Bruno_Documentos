CREATE OR REPLACE PROCEDURE ow_lao.proc_ods_sales_control_tower_table_raw_vtex_ssg_ar_smb_sales_order()
LANGUAGE PLvSQL AS $$
BEGIN

  PERFORM TRUNCATE TABLE ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_smb_sales_order;

  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_smb_sales_order
  (
    po_date, podate_year, podate_month, country, samsung_care_order, samsung_care, samsung_care_eligibility,
    trade_in, trade_in_eligibility, trade_up, trade_up_eligibility, costumer_code_id_name, po_orderid,
    seller_po_orderid, payment_card_brand, payment_type, installment, installment_eligibility, po_cancelation_reason,
    po_productgroup, po_code_sales_channel, po_costumer_id, po_sitecode, po_internal_status, po_invoicenumber,
    po_campain_tags, po_campain, po_coupon, po_medium, po_src, po_utmi_campaing, po_sequence_orderid, po_prodname,
    po_sku, po_seller_id, po_seller_name, po_status, client_subsidiary_id, subsidiary, currency, po_tradepolicy,
    po_vendortype, channel, biz_type, audience_type, po_storename, client_acquirer_message, po_lastupdate_date_hour,
    po_orderqty, po_qty, po_itemdiscount_localcurr, po_itemdiscount_usd, po_price_localcurr, po_price_usd,
    po_plataform_datasource, po_source_insert_date, po_source_last_update_date, po_insert_date, po_last_update_date,
    po_payment_remark, po_hour, po_totalprice_usd, po_totalprice_local, po_devicetype, po_sku_kit, po_prodname_kit,
    po_price_localcurr_kit, po_itemdiscount_localcurr_kit, is_kit, country_cd, biz_type_ebi_hq, global_channel_ebi_hq,
    po_sku_attachments, shipping_method, customer_type, po_mobile_os
  )
  SELECT
    CAST(TIMESTAMPADD(SECOND, (-3*60)*60, TO_TIMESTAMP(a.creation_date)) AS DATE) AS po_date,
    EXTRACT(YEAR FROM CAST(TIMESTAMPADD(SECOND, (-3*60)*60, TO_TIMESTAMP(a.creation_date)) AS DATE)) AS podate_year,
    EXTRACT(MONTH FROM CAST(TIMESTAMPADD(SECOND, (-3*60)*60, TO_TIMESTAMP(a.creation_date)) AS DATE)) AS podate_month,
    'Argentina' AS country,
    0 AS samsung_care_order,
    0 AS samsung_care,
    0 AS samsung_care_eligibility,
    0 AS trade_in,
    0 AS trade_in_eligibility,
    0 AS trade_up,
    0 AS trade_up_eligibility,
    a.affiliate_id AS costumer_code_id_name,
    a.order_id AS po_orderid,
    a.seller_order_id AS seller_po_orderid,
    CAST(NULL AS VARCHAR(3000)) AS payment_card_brand,
    CAST(NULL AS VARCHAR(3000)) AS payment_type,
    0 AS installment,
    NULL AS installment_eligibility,
    a.cancellation_reason AS po_cancelation_reason,
    c.product_group_1 AS po_productgroup,
    a.sales_channel AS po_code_sales_channel,
    NULL AS po_costumer_id,
    a.hostname AS po_sitecode,
    a.status AS po_internal_status,
    NULL AS po_invoicenumber,
    a.marketing_tags AS po_campain_tags,
    a.utm_campaign AS po_campain,
    a.coupon AS po_coupon,
    a.utm_medium AS po_medium,
    a.utm_source AS po_src,
    a.utmi_campaign AS po_utmi_campaing,
    a.sequence AS po_sequence_orderid,
    b.name AS po_prodname,
    COALESCE(b.ref_id, b.name) AS po_sku,
    REPLACE(REPLACE(a.seller_id, '["', ''), '"]', '') AS po_seller_id,
    REPLACE(REPLACE(a.seller_name, '["', ''), '"]', '') AS po_seller_name,
    d.status AS po_status,
    1 AS client_subsidiary_id,
    'SEASA' AS subsidiary,
    'ARS' AS currency,
    NULL AS po_tradepolicy,
    a.origin AS po_vendortype,
    CAST(NULL AS VARCHAR(255)) AS channel,
    CAST(NULL AS VARCHAR(255)) AS biz_type,
    CAST(NULL AS VARCHAR(255)) AS audience_type,
    CAST(NULL AS VARCHAR(255)) AS po_storename,
    CAST(NULL AS VARCHAR(255)) AS client_acquirer_message,
    a.creation_timestamp AS po_lastupdate_date_hour,
    0 AS po_orderqty,
    SUM(b.quantity) AS po_qty,
    SUM((b.price - b.selling_price) / 100.00) AS po_itemdiscount_localcurr,
    0 AS po_itemdiscount_usd,
    SUM(b.price / 100.00) AS po_price_localcurr,
    0 AS po_price_usd,
    'u_prj_ecom.raw_vtex_ssg_ar_smb_sales_order' AS po_plataform_datasource,
    a.created_at AS po_source_insert_date,
    a.creation_timestamp AS po_source_last_update_date,
    CURRENT_TIMESTAMP AS po_insert_date,
    NULL AS po_last_update_date,
    CAST(NULL AS VARCHAR(3000)) AS po_payment_remark,
    CAST(TIMESTAMPADD(SECOND, (-3*60)*60, TO_TIMESTAMP(a.creation_date)) AS TIME) AS po_hour,
    0 AS po_totalprice_usd,
    0 AS po_totalprice_local,
    CAST(NULL AS VARCHAR(255)) AS po_devicetype,
    CAST('' AS VARCHAR(255)) AS po_sku_kit,
    CAST('' AS VARCHAR(255)) AS po_prodname_kit,
    CAST(0.00 AS DECIMAL(18,2)) AS po_price_localcurr_kit,
    CAST(0.00 AS DECIMAL(18,2)) AS po_itemdiscount_localcurr_kit,
    FALSE AS is_kit,
    'ARG' AS country_cd,
    CAST(NULL AS VARCHAR(255)) AS biz_type_ebi_hq,
    CAST(NULL AS VARCHAR(255)) AS global_channel_ebi_hq,
    b.attachments AS po_sku_attachments,
    e.selected_sla AS shipping_method,
    CAST(NULL AS VARCHAR(255)) AS customer_type,
    CAST(NULL AS VARCHAR(255)) AS po_mobile_os
  FROM u_prj_ecom.raw_vtex_ssg_ar_smb_sales_order a
  JOIN u_prj_ecom.raw_vtex_ssg_ar_smb_sales_order_item b ON b.order_id = a.order_id
  LEFT JOIN ow_md.dim_product c ON c.sku = b.ref_id
  LEFT JOIN ow_lao.dim_ods_sales_control_tower_table_status_mapping d ON d.status_origin = COALESCE(a.status, 'incomplete')
  LEFT JOIN u_prj_ecom.raw_vtex_ssg_ar_smb_sales_order_shipping e ON e.order_id = a.order_id AND e.item_index = b.item_index
  WHERE a.creation_timestamp >= TIMESTAMPADD(DAY, -3, CURRENT_DATE)
    AND NOT EXISTS (
      SELECT 1
      FROM ow_lao.ods_sales_control_tower_table aa
      WHERE aa.po_orderid = a.order_id
        AND aa.po_sku = b.ref_id
        AND aa.po_sitecode = a.hostname
        AND aa.country = 'Argentina'
        AND aa.po_internal_status = COALESCE(a.status, 'incomplete')
        AND aa.po_source_last_update_date >= CAST(a.creation_timestamp AS TIMESTAMP)
    )
  GROUP BY a.creation_date, a.affiliate_id, a.order_id, a.seller_order_id, a.cancellation_reason, c.product_group_1,
           a.sales_channel, a.hostname, a.status, a.marketing_tags, a.utm_campaign, a.coupon, a.utm_medium,
           a.utm_source, a.utmi_campaign, a.sequence, b.name, b.ref_id, a.seller_id, a.seller_name, d.status,
           a.created_at, a.creation_timestamp, a.origin, b.attachments, e.selected_sla;

  -- Samsung Care
  PERFORM UPDATE ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_smb_sales_order
     SET samsung_care = 1
   WHERE UPPER(po_prodname) LIKE UPPER('%samsung care%');

  -- Payments staging
  PERFORM CREATE LOCAL TEMPORARY TABLE vtmp_ecom_sales_payments ON COMMIT PRESERVE ROWS AS
  SELECT po_orderid,
         MAX(installments) AS installment,
         LISTAGG(brand USING PARAMETERS separator='|') AS payment_card_brand,
         LISTAGG(payment_type USING PARAMETERS separator='|') AS payment_type,
         LISTAGG(payment_type || ':' || brand || ':' || (value/100.00)::VARCHAR || ':' || installments USING PARAMETERS separator='|') AS po_payment_remark
    FROM (
           SELECT DISTINCT
                  a.po_orderid,
                  CASE COALESCE(b.payment_group, '') WHEN '' THEN '' ELSE COALESCE(b.payment_system_name, '') END AS brand,
                  COALESCE(b.payment_group, '') AS payment_type,
                  b.value,
                  CASE WHEN b.installments IS NULL THEN 1 ELSE b.installments END AS installments
             FROM ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_smb_sales_order a
             JOIN u_prj_ecom.raw_vtex_ssg_ar_smb_sales_order_payment b ON b.order_id = a.po_orderid
         ) s
   GROUP BY po_orderid;

  PERFORM UPDATE ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_smb_sales_order a
     SET installment = b.installment,
         payment_card_brand = b.payment_card_brand,
         payment_type = b.payment_type,
         po_payment_remark = b.po_payment_remark
    FROM vtmp_ecom_sales_payments b
   WHERE b.po_orderid = a.po_orderid;

  -- Order aggregates
  PERFORM CREATE LOCAL TEMPORARY TABLE vtmp_ecom_order_agg ON COMMIT PRESERVE ROWS AS
  SELECT country, po_orderid, SUM(po_qty) AS po_orderqty, SUM(po_price_localcurr) AS po_totalprice_local
    FROM ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_smb_sales_order
   GROUP BY country, po_orderid;

  PERFORM CREATE LOCAL TEMPORARY TABLE vtmp_ecom_sku_agg ON COMMIT PRESERVE ROWS AS
  SELECT country, po_orderid, po_sku,
         SUM(po_qty) AS po_orderqty,
         SUM(po_price_localcurr) AS po_totalprice_local,
         SUM(po_itemdiscount_localcurr) AS po_itemdiscount_localcurr
    FROM ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_smb_sales_order
   GROUP BY country, po_orderid, po_sku;

  PERFORM UPDATE ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_smb_sales_order a
     SET po_orderqty = b.po_orderqty,
         po_totalprice_local = (c.po_totalprice_local * c.po_orderqty) - c.po_itemdiscount_localcurr,
         po_price_localcurr  = (c.po_totalprice_local * c.po_orderqty) - c.po_itemdiscount_localcurr
    FROM vtmp_ecom_order_agg b, vtmp_ecom_sku_agg c
   WHERE b.country = a.country
     AND b.po_orderid = a.po_orderid
     AND c.country = a.country
     AND c.po_orderid = a.po_orderid
     AND c.po_sku = a.po_sku;

  -- USD conversion
  PERFORM UPDATE ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_smb_sales_order a
     SET po_itemdiscount_usd = COALESCE(a.po_itemdiscount_localcurr / CAST(b.exchange_rate AS DECIMAL(18,6)), 0),
         po_price_usd        = COALESCE(a.po_price_localcurr / CAST(b.exchange_rate AS DECIMAL(18,6)), 0),
         po_totalprice_usd   = COALESCE(a.po_totalprice_local / CAST(b.exchange_rate AS DECIMAL(18,6)), 0)
    FROM ow_lao.ft_ap2_exchange_rate b
   WHERE b.valid_from = TIMESTAMPADD(DAY, -1, a.po_date)
     AND b.to_currency = a.currency;

  -- Sales channel mapping
  PERFORM UPDATE ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_smb_sales_order a
     SET channel              = b.global_channel,
         biz_type             = b.biz_type,
         audience_type        = b.audience_type,
         po_storename         = b.partner_level,
         biz_type_ebi_hq      = b.biz_type_ebi,
         global_channel_ebi_hq= b.global_channel_ebi,
         customer_type        = b.customer_type,
         po_mobile_os         = b.po_mobile_os
    FROM ow_md.sales_channel b
   WHERE LOWER(b.country) = LOWER(a.country)
     AND b.sales_channel = a.po_code_sales_channel
     AND COALESCE(b.identifier,'') = a.costumer_code_id_name
     AND b.plataform_account = a.po_sitecode
     AND a.client_subsidiary_id IN (1)
     AND LOWER(b.plataform_type) = 'vtex'
     AND COALESCE(b.has_store_id, 'N') = 'N'
     AND COALESCE(b.identifier,'') <> '';

  PERFORM UPDATE ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_smb_sales_order a
     SET channel              = b.global_channel,
         biz_type             = b.biz_type,
         audience_type        = b.audience_type,
         po_storename         = b.partner_level,
         biz_type_ebi_hq      = b.biz_type_ebi,
         global_channel_ebi_hq= b.global_channel_ebi,
         customer_type        = b.customer_type,
         po_mobile_os         = b.po_mobile_os
    FROM ow_md.sales_channel b
   WHERE LOWER(b.country) = LOWER(a.country)
     AND b.sales_channel = a.po_code_sales_channel
     AND b.plataform_account = a.po_sitecode
     AND a.client_subsidiary_id IN (1)
     AND LOWER(b.plataform_type) = 'vtex'
     AND COALESCE(b.has_store_id, 'N') = 'N'
     AND COALESCE(b.identifier,'') = '';

  PERFORM UPDATE ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_smb_sales_order a
     SET channel               = b.channel,
         biz_type              = b.byz_type,
         audience_type         = b.audience_type,
         po_storename          = b.storename,
         biz_type_ebi_hq       = b.biz_type_ebi_hq,
         global_channel_ebi_hq = b.global_channel_ebi_hq
    FROM ow_lao.temp_dim_ecom_store_seasa_mkm b
   WHERE b.id = SUBSTR(a.po_orderid, 1, 6)
     AND a.client_subsidiary_id = 1
     AND a.costumer_code_id_name = 'MKM';

  PERFORM UPDATE ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_smb_sales_order a
     SET channel               = 'eStore',
         biz_type              = '3PD',
         audience_type         = '3PD',
         po_storename          = 'Mercado Libre',
         biz_type_ebi_hq       = 'B2C',
         global_channel_ebi_hq = '3PD'
   WHERE a.client_subsidiary_id = 1
     AND a.costumer_code_id_name = 'MKM'
     AND a.channel IS NULL
     AND NOT EXISTS (
           SELECT 1 FROM ow_lao.temp_dim_ecom_store_seasa_mkm aa WHERE aa.id = SUBSTR(a.po_orderid, 1, 6)
         );

  PERFORM UPDATE ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_smb_sales_order a
     SET channel              = b.global_channel,
         biz_type             = b.biz_type,
         audience_type        = b.audience_type,
         po_storename         = b.partner_level,
         biz_type_ebi_hq      = b.biz_type_ebi,
         global_channel_ebi_hq= b.global_channel_ebi
    FROM ow_md.sales_channel b
   WHERE LOWER(b.country) = LOWER(a.country)
     AND COALESCE(b.identifier,'') = a.costumer_code_id_name
     AND b.plataform_account = a.po_sitecode
     AND a.client_subsidiary_id IN (1)
     AND LOWER(b.plataform_type) = 'vtex'
     AND COALESCE(b.has_store_id, 'N') = 'N'
     AND COALESCE(b.identifier,'') <> ''
     AND SUBSTR(a.po_orderid, 1, 3) = 'MKB';

  -- App Samsung
  PERFORM UPDATE ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_smb_sales_order
     SET po_devicetype = 'MOBILEAPP'
   WHERE po_sitecode IN ('samsungarapp', 'samsungarappios')
     AND client_subsidiary_id = 1;

  -- O2O ENDLESS AISLE
  PERFORM UPDATE ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_smb_sales_order a
     SET channel               = 'eStore',
         biz_type              = 'EPP',
         audience_type         = 'Endless Aisle',
         po_storename          = 'Endless Aisle',
         biz_type_ebi_hq       = 'EPP',
         global_channel_ebi_hq = 'eStore'
    FROM u_prj_ecom.raw_vtex_ssg_ar_smb_sales_order_shipping b
   WHERE b.order_id = a.po_orderid
     AND a.client_subsidiary_id = 1
     AND b.delivery_company = 'Retiro en Tienda'
     AND a.biz_type <> 'EPP';

  -- Trade in/up flags
  PERFORM CREATE LOCAL TEMPORARY TABLE vtmp_trade_flags ON COMMIT PRESERVE ROWS AS
  SELECT po_orderid,
         CASE WHEN COALESCE(JSON_EXTRACT_PATH_TEXT(REPLACE(REPLACE(REGEXP_REPLACE(po_sku_attachments, '\\\\', ''), '"{', '{'), '}"', '}'), 'content','TradeIn'), 'false') = 'false' THEN 0 ELSE 1 END AS tradeIn,
         CASE WHEN COALESCE(JSON_EXTRACT_PATH_TEXT(REPLACE(REPLACE(REGEXP_REPLACE(po_sku_attachments, '\\\\', ''), '"{', '{'), '}"', '}'), 'content','TradeIn','device1','ecoTradein'), 'false') = 'false' THEN 0 ELSE 1 END AS tradeUP
    FROM ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_smb_sales_order
   WHERE po_sku_attachments IS NOT NULL;

  PERFORM CREATE LOCAL TEMPORARY TABLE vtmp_trade_flags_agg ON COMMIT PRESERVE ROWS AS
  SELECT po_orderid, SUM(tradeIn) AS tradeIn, SUM(tradeUP) AS tradeUP
    FROM vtmp_trade_flags
   GROUP BY po_orderid;

  PERFORM UPDATE ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_smb_sales_order a
     SET trade_in = b.tradeIn,
         trade_up = b.tradeUP
    FROM vtmp_trade_flags_agg b
   WHERE b.po_orderid = a.po_orderid
     AND a.client_subsidiary_id = 1;

  -- Default device type
  PERFORM UPDATE ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_smb_sales_order
     SET po_devicetype = 'Web'
   WHERE po_devicetype IS NULL
     AND client_subsidiary_id = 1;

  -- Merge into control tower
  PERFORM MERGE INTO ow_lao.ods_sales_control_tower_table a
  USING ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_smb_sales_order b
     ON b.po_orderid = a.po_orderid
    AND b.po_sku = a.po_sku
    AND b.country = a.country
    AND b.po_sku_kit = a.po_sku_kit
    AND b.po_sitecode = a.po_sitecode
  WHEN MATCHED THEN UPDATE SET
       po_date                    = b.po_date,
       po_hour                    = b.po_hour,
       podate_year                = b.podate_year,
       podate_month               = b.podate_month,
       samsung_care_order         = b.samsung_care_order,
       samsung_care               = b.samsung_care,
       samsung_care_eligibility   = b.samsung_care_eligibility,
       trade_in                   = b.trade_in,
       trade_in_eligibility       = b.trade_in_eligibility,
       costumer_code_id_name      = b.costumer_code_id_name,
       seller_po_orderid          = b.seller_po_orderid,
       payment_card_brand         = b.payment_card_brand,
       payment_type               = b.payment_type,
       installment                = b.installment,
       installment_eligibility    = b.installment_eligibility,
       po_cancelation_reason      = b.po_cancelation_reason,
       po_productgroup            = b.po_productgroup,
       po_code_sales_channel      = b.po_code_sales_channel,
       po_costumer_id             = b.po_costumer_id,
       po_sitecode                = b.po_sitecode,
       po_internal_status         = b.po_internal_status,
       po_invoicenumber           = b.po_invoicenumber,
       po_campain_tags            = b.po_campain_tags,
       po_campain                 = b.po_campain,
       po_coupon                  = b.po_coupon,
       po_medium                  = b.po_medium,
       po_src                     = b.po_src,
       po_utmi_campaing           = b.po_utmi_campaing,
       po_prodname                = b.po_prodname,
       po_seller_id               = b.po_seller_id,
       po_seller_name             = b.po_seller_name,
       po_status                  = b.po_status,
       client_subsidiary_id       = b.client_subsidiary_id,
       subsidiary                 = b.subsidiary,
       currency                   = b.currency,
       po_tradepolicy             = b.po_tradepolicy,
       po_vendortype              = b.po_vendortype,
       channel                    = b.channel,
       biz_type                   = b.biz_type,
       audience_type              = b.audience_type,
       po_storename               = b.po_storename,
       client_acquirer_message    = b.client_acquirer_message,
       po_lastupdate_date_hour    = b.po_lastupdate_date_hour,
       po_orderqty                = b.po_orderqty,
       po_qty                     = b.po_qty,
       po_itemdiscount_localcurr  = b.po_itemdiscount_localcurr,
       po_itemdiscount_usd        = b.po_itemdiscount_usd,
       po_price_localcurr         = b.po_price_localcurr,
       po_price_usd               = b.po_price_usd,
       po_plataform_datasource    = b.po_plataform_datasource,
       po_source_insert_date      = b.po_source_insert_date,
       po_source_last_update_date = b.po_source_last_update_date,
       po_insert_date             = b.po_insert_date,
       po_last_update_date        = b.po_last_update_date,
       po_payment_remark          = b.po_payment_remark,
       po_totalprice_usd          = b.po_totalprice_usd,
       po_totalprice_local        = b.po_totalprice_local,
       po_devicetype              = b.po_devicetype,
       updated_datetime           = CURRENT_TIMESTAMP,
       po_sku_kit                 = b.po_sku_kit,
       po_prodname_kit            = b.po_prodname_kit,
       is_kit                     = b.is_kit,
       country_cd                 = b.country_cd,
       biz_type_ebi_hq            = b.biz_type_ebi_hq,
       global_channel_ebi_hq      = b.global_channel_ebi_hq,
       shipping_method            = b.shipping_method,
       customer_type              = b.customer_type,
       po_mobile_os               = b.po_mobile_os
  WHEN NOT MATCHED THEN INSERT (
       po_date, po_hour, podate_year, podate_month, country, samsung_care_order, samsung_care, samsung_care_eligibility,
       trade_in, trade_in_eligibility, costumer_code_id_name, po_orderid, seller_po_orderid, payment_card_brand,
       payment_type, installment, installment_eligibility, po_cancelation_reason, po_productgroup, po_code_sales_channel,
       po_costumer_id, po_sitecode, po_internal_status, po_invoicenumber, po_campain_tags, po_campain, po_coupon,
       po_medium, po_src, po_utmi_campaing, po_sequence_orderid, po_prodname, po_sku, po_seller_id, po_seller_name,
       po_status, client_subsidiary_id, subsidiary, currency, po_tradepolicy, po_vendortype, channel, biz_type,
       audience_type, po_storename, client_acquirer_message, po_lastupdate_date_hour, po_orderqty, po_qty,
       po_itemdiscount_localcurr, po_itemdiscount_usd, po_price_localcurr, po_price_usd, po_plataform_datasource,
       po_source_insert_date, po_source_last_update_date, po_insert_date, po_last_update_date, po_payment_remark,
       po_totalprice_usd, po_totalprice_local, po_devicetype, po_sku_kit, po_prodname_kit, is_kit, country_cd,
       biz_type_ebi_hq, global_channel_ebi_hq, shipping_method, customer_type, po_mobile_os
  ) VALUES (
       b.po_date, b.po_hour, b.podate_year, b.podate_month, b.country, b.samsung_care_order, b.samsung_care,
       b.samsung_care_eligibility, b.trade_in, b.trade_in_eligibility, b.costumer_code_id_name, b.po_orderid,
       b.seller_po_orderid, b.payment_card_brand, b.payment_type, b.installment, b.installment_eligibility,
       b.po_cancelation_reason, b.po_productgroup, b.po_code_sales_channel, b.po_costumer_id, b.po_sitecode,
       b.po_internal_status, b.po_invoicenumber, b.po_campain_tags, b.po_campain, b.po_coupon, b.po_medium, b.po_src,
       b.po_utmi_campaing, b.po_sequence_orderid, b.po_prodname, b.po_sku, b.po_seller_id, b.po_seller_name,
       b.po_status, b.client_subsidiary_id, b.subsidiary, b.currency, b.po_tradepolicy, b.po_vendortype, b.channel,
       b.biz_type, b.audience_type, b.po_storename, b.client_acquirer_message, b.po_lastupdate_date_hour,
       b.po_orderqty, b.po_qty, b.po_itemdiscount_localcurr, b.po_itemdiscount_usd, b.po_price_localcurr,
       b.po_price_usd, b.po_plataform_datasource, b.po_source_insert_date, b.po_source_last_update_date,
       b.po_insert_date, b.po_last_update_date, b.po_payment_remark, b.po_totalprice_usd, b.po_totalprice_local,
       b.po_devicetype, b.po_sku_kit, b.po_prodname_kit, b.is_kit, b.country_cd, b.biz_type_ebi_hq,
       b.global_channel_ebi_hq, b.shipping_method, b.customer_type, b.po_mobile_os
  );

END;
$$;

-- CALL ow_lao.proc_ods_sales_control_tower_table_raw_vtex_ssg_ar_smb_sales_order();
-- ERROR: Severity: ERROR, Message: Relation "ow_md.dim_product" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ods_sales_control_tower_table_raw_vtex_ssg_ar_smb_sales_order line 6 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
-- CALL ow_lao.proc_ods_sales_control_tower_table_raw_vtex_ssg_ar_smb_sales_order();
-- ERROR: Severity: ERROR, Message: Relation "ow_md.dim_product" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ods_sales_control_tower_table_raw_vtex_ssg_ar_smb_sales_order line 6 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
