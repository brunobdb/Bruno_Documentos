-- CREATE OR REPLACE PROCEDURE OW_SEDA_S.PRC_DEAD_INVENTORY_CALCULATION(weeknum_ref INT, category_ref VARCHAR(10), account_ref VARCHAR(30))
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--   
--   PERFORM DELETE FROM OW_SEDA_S."FT_CE_READY" fr
--   USING OW_SEDA_S."FT_CE_READY" fr2
--   INNER JOIN OW_SEDA_S."MAP_CE_STORES" ml ON ml."SITE_ID" = fr2."SITE_ID"
--   INNER JOIN OW_SEDA_S."MAP_CE_PRODUCTS" mcp ON mcp."ITEM" = fr2."ITEM"
--   WHERE fr."SITE_ID" = fr2."SITE_ID"
--     AND fr."ITEM" = fr2."ITEM"
--     AND fr."WEEKNUM" = fr2."WEEKNUM"
--     AND fr."PARAMETER" = fr2."PARAMETER"
--     AND fr2."WEEKNUM" = weeknum_ref
--     AND fr2."PARAMETER" = 'Dead Inventory'
--     AND mcp."CATEGORY_ITEM" = category_ref
--     AND ml."ACCOUNT" = account_ref;
-- 
--   PERFORM MERGE INTO OW_SEDA_S."FT_CE_READY" target
--   USING (
--     SELECT DISTINCT
--       'Dead Inventory' AS "PARAMETER",
--       tb1."WEEKNUM",
--       tb1."SITE_ID",
--       tb1."ITEM",
--       "DATA" - 1 AS "DATA",
--       'Dead Inventory Manual' AS "REPORT",
--       CURRENT_DATE AS "INPUT_DATE",
--       CASE
--         WHEN last_weeknum_sell_out IS NULL THEN first_weeknum_inventory
--         ELSE last_weeknum_sell_out
--       END AS weeknum_to_diff,
--       DATEDIFF('day', tb5."CALENDAR", tb4."CALENDAR")/7 AS difference
--     FROM OW_SEDA_S."FT_CE_READY" tb1
--     INNER JOIN OW_SEDA_S."MAP_CE_STORES" tb2 ON tb1."SITE_ID" = tb2."SITE_ID"
--     INNER JOIN OW_SEDA_S."MAP_CE_PRODUCTS" tb3 ON tb1."ITEM" = tb3."ITEM"
--     INNER JOIN (
--       SELECT
--         LAG("YEARWEEK", 7) OVER (ORDER BY "YEARWEEK") AS weeknum_lag_7,
--         "YEARWEEK",
--         "CALENDAR"
--       FROM OW_SEDA_S."MAP_CE_CALENDAR" mc 
--       WHERE 1=1
--         AND "YEAR" BETWEEN 2024 AND 2025
--     ) tb4 ON tb1."WEEKNUM" = tb4."YEARWEEK"
--     LEFT JOIN (
--       SELECT
--         MAX("WEEKNUM") AS last_weeknum_sell_out,
--         "SITE_ID",
--         "ITEM"
--       FROM OW_SEDA_S."FT_CE_READY"
--       WHERE 1=1
--         AND "PARAMETER" = 'Sell Out' 
--         AND "WEEKNUM" <= weeknum_ref
--         AND "DATA" > 0
--       GROUP BY "SITE_ID", "ITEM"
--     ) tb_last_sale
--       ON tb1."SITE_ID" = tb_last_sale."SITE_ID"
--      AND tb1."ITEM"    = tb_last_sale."ITEM"
--     LEFT JOIN (
--       SELECT
--         MIN("WEEKNUM") AS first_weeknum_inventory,
--         "SITE_ID",
--         "ITEM",
--         MAX("DATA") AS first_inventory
--       FROM OW_SEDA_S."FT_CE_READY"
--       WHERE 1=1
--         AND "PARAMETER" = 'Inventory' 
--         AND "WEEKNUM" <= weeknum_ref
--         AND "DATA" > 0
--       GROUP BY "SITE_ID", "ITEM"
--     ) tb_first_inventory
--       ON tb1."SITE_ID" = tb_first_inventory."SITE_ID"
--      AND tb1."ITEM"    = tb_first_inventory."ITEM"
--     INNER JOIN OW_SEDA_S."MAP_CE_CALENDAR" tb5 
--       ON COALESCE(last_weeknum_sell_out, first_weeknum_inventory) = tb5."YEARWEEK"
--     WHERE 
--       tb1."PARAMETER" = 'Inventory' AND 
--       tb1."WEEKNUM" = weeknum_ref AND 
--       DATEDIFF('day', tb5."CALENDAR", tb4."CALENDAR")/7 + 1 -
--         CASE WHEN last_weeknum_sell_out IS NOT NULL THEN 1 ELSE 0 END >= 8 AND
--       "DATA" - 1 > 0 AND
--       tb2."STORE_TYPE" = 'Reg. Stores' AND
--       tb2."ACCOUNT" = account_ref AND
--       tb3."CATEGORY_ITEM" = category_ref
--   ) source
--   ON source."PARAMETER" = target."PARAMETER"
--      AND source."WEEKNUM"   = target."WEEKNUM"
--      AND source."SITE_ID"   = target."SITE_ID"
--      AND source."ITEM"      = target."ITEM"
--   WHEN MATCHED THEN UPDATE SET 
--     target."DATA" = source."DATA",
--     target."REPORT" = source."REPORT",
--     target."INPUT_DATE" = source."INPUT_DATE"
--   WHEN NOT MATCHED THEN INSERT (
--     "PARAMETER", "WEEKNUM", "SITE_ID", "ITEM", "DATA", "REPORT", "INPUT_DATE"
--   ) VALUES (
--     source."PARAMETER", source."WEEKNUM", source."SITE_ID", source."ITEM", source."DATA", source."REPORT", source."INPUT_DATE"
--   );
-- 
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: Syntax error at or near "fr", Sqlstate: 42601, Position: 215, Routine: base_yyerror, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/scan.l, Line: 1056, Error Code: 4856, 
-- CREATE OR REPLACE PROCEDURE OW_SEDA_S.PRC_DEAD_INVENTORY_CALCULATION(weeknum_ref INT, category_ref VARCHAR(10), account_ref VARCHAR(30))
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--   
--   PERFORM DELETE FROM OW_SEDA_S."FT_CE_READY" fr 
--   WHERE EXISTS (
--     SELECT 1 
--     FROM OW_SEDA_S."FT_CE_READY" fr2 
--     INNER JOIN OW_SEDA_S."MAP_CE_STORES" ml ON ml."SITE_ID" = fr2."SITE_ID" 
--     INNER JOIN OW_SEDA_S."MAP_CE_PRODUCTS" mcp ON mcp."ITEM" = fr2."ITEM" 
--     WHERE fr2."WEEKNUM" = weeknum_ref
--       AND fr2."PARAMETER" = 'Dead Inventory' 
--       AND mcp."CATEGORY_ITEM" = category_ref 
--       AND ml."ACCOUNT" = account_ref
--       AND fr."SITE_ID" = fr2."SITE_ID"
--       AND fr."ITEM" = fr2."ITEM"
--       AND fr."WEEKNUM" = fr2."WEEKNUM"
--       AND fr."PARAMETER" = fr2."PARAMETER"
--   );
-- 
--   PERFORM MERGE INTO OW_SEDA_S."FT_CE_READY" target
--   USING (
--     SELECT DISTINCT
--       'Dead Inventory' AS "PARAMETER",
--       tb1."WEEKNUM",
--       tb1."SITE_ID",
--       tb1."ITEM",
--       tb1."DATA" - 1 AS "DATA",
--       'Dead Inventory Manual' AS "REPORT",
--       CURRENT_DATE AS "INPUT_DATE",
--       CASE
--         WHEN last_weeknum_sell_out IS NULL THEN first_weeknum_inventory
--         ELSE last_weeknum_sell_out
--       END AS weeknum_to_diff,
--       DATEDIFF('day', tb5."CALENDAR", tb4."CALENDAR")/7 AS difference
--     FROM OW_SEDA_S."FT_CE_READY" tb1
--     INNER JOIN OW_SEDA_S."MAP_CE_STORES" tb2 ON tb1."SITE_ID" = tb2."SITE_ID"
--     INNER JOIN OW_SEDA_S."MAP_CE_PRODUCTS" tb3 ON tb1."ITEM" = tb3."ITEM"
--     INNER JOIN (
--       SELECT
--         LAG("YEARWEEK", 7) OVER (ORDER BY "YEARWEEK") AS weeknum_lag_7,
--         "YEARWEEK",
--         "CALENDAR"
--       FROM OW_SEDA_S."MAP_CE_CALENDAR" mc 
--       WHERE "YEAR" BETWEEN 2024 AND 2025
--     ) tb4 ON tb1."WEEKNUM" = tb4."YEARWEEK"
--     LEFT JOIN (
--       SELECT
--         MAX("WEEKNUM") AS last_weeknum_sell_out,
--         "SITE_ID",
--         "ITEM"
--       FROM OW_SEDA_S."FT_CE_READY"
--       WHERE "PARAMETER" = 'Sell Out' 
--         AND "WEEKNUM" <= weeknum_ref
--         AND "DATA" > 0
--       GROUP BY "SITE_ID", "ITEM"
--     ) tb_last_sale
--       ON tb1."SITE_ID" = tb_last_sale."SITE_ID"
--      AND tb1."ITEM"    = tb_last_sale."ITEM"
--     LEFT JOIN (
--       SELECT
--         MIN("WEEKNUM") AS first_weeknum_inventory,
--         "SITE_ID",
--         "ITEM",
--         MAX("DATA") AS first_inventory
--       FROM OW_SEDA_S."FT_CE_READY"
--       WHERE "PARAMETER" = 'Inventory' 
--         AND "WEEKNUM" <= weeknum_ref
--         AND "DATA" > 0
--       GROUP BY "SITE_ID", "ITEM"
--     ) tb_first_inventory
--       ON tb1."SITE_ID" = tb_first_inventory."SITE_ID"
--      AND tb1."ITEM"    = tb_first_inventory."ITEM"
--     INNER JOIN OW_SEDA_S."MAP_CE_CALENDAR" tb5 
--       ON COALESCE(last_weeknum_sell_out, first_weeknum_inventory) = tb5."YEARWEEK"
--     WHERE 
--       tb1."PARAMETER" = 'Inventory' AND 
--       tb1."WEEKNUM" = weeknum_ref AND 
--       DATEDIFF('day', tb5."CALENDAR", tb4."CALENDAR")/7 + 1 -
--         CASE WHEN last_weeknum_sell_out IS NOT NULL THEN 1 ELSE 0 END >= 8 AND
--       tb1."DATA" - 1 > 0 AND
--       tb2."STORE_TYPE" = 'Reg. Stores' AND
--       tb2."ACCOUNT" = account_ref AND
--       tb3."CATEGORY_ITEM" = category_ref
--   ) source
--   ON source."PARAMETER" = target."PARAMETER"
--      AND source."WEEKNUM"   = target."WEEKNUM"
--      AND source."SITE_ID"   = target."SITE_ID"
--      AND source."ITEM"      = target."ITEM"
--   WHEN MATCHED THEN UPDATE SET 
--     target."DATA" = source."DATA",
--     target."REPORT" = source."REPORT",
--     target."INPUT_DATE" = source."INPUT_DATE"
--   WHEN NOT MATCHED THEN INSERT (
--     "PARAMETER", "WEEKNUM", "SITE_ID", "ITEM", "DATA", "REPORT", "INPUT_DATE"
--   ) VALUES (
--     source."PARAMETER", source."WEEKNUM", source."SITE_ID", source."ITEM", source."DATA", source."REPORT", source."INPUT_DATE"
--   );
-- 
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: Syntax error at or near "fr", Sqlstate: 42601, Position: 215, Routine: base_yyerror, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/scan.l, Line: 1056, Error Code: 4856, 
CREATE OR REPLACE PROCEDURE OW_SEDA_S.PRC_DEAD_INVENTORY_CALCULATION(weeknum_ref INT, category_ref VARCHAR(10), account_ref VARCHAR(30))
LANGUAGE PLvSQL AS $$
BEGIN
  
  PERFORM DELETE FROM OW_SEDA_S."FT_CE_READY"
  WHERE EXISTS (
    SELECT 1 
    FROM OW_SEDA_S."FT_CE_READY" fr2 
    INNER JOIN OW_SEDA_S."MAP_CE_STORES" ml ON ml."SITE_ID" = fr2."SITE_ID" 
    INNER JOIN OW_SEDA_S."MAP_CE_PRODUCTS" mcp ON mcp."ITEM" = fr2."ITEM" 
    WHERE fr2."WEEKNUM" = weeknum_ref
      AND fr2."PARAMETER" = 'Dead Inventory' 
      AND mcp."CATEGORY_ITEM" = category_ref 
      AND ml."ACCOUNT" = account_ref
      AND OW_SEDA_S."FT_CE_READY"."SITE_ID" = fr2."SITE_ID"
      AND OW_SEDA_S."FT_CE_READY"."ITEM" = fr2."ITEM"
      AND OW_SEDA_S."FT_CE_READY"."WEEKNUM" = fr2."WEEKNUM"
      AND OW_SEDA_S."FT_CE_READY"."PARAMETER" = fr2."PARAMETER"
  );

  PERFORM MERGE INTO OW_SEDA_S."FT_CE_READY" target
  USING (
    SELECT DISTINCT
      'Dead Inventory' AS "PARAMETER",
      tb1."WEEKNUM",
      tb1."SITE_ID",
      tb1."ITEM",
      tb1."DATA" - 1 AS "DATA",
      'Dead Inventory Manual' AS "REPORT",
      CURRENT_DATE AS "INPUT_DATE",
      CASE
        WHEN last_weeknum_sell_out IS NULL THEN first_weeknum_inventory
        ELSE last_weeknum_sell_out
      END AS weeknum_to_diff,
      DATEDIFF('day', tb5."CALENDAR", tb4."CALENDAR")/7 AS difference
    FROM OW_SEDA_S."FT_CE_READY" tb1
    INNER JOIN OW_SEDA_S."MAP_CE_STORES" tb2 ON tb1."SITE_ID" = tb2."SITE_ID"
    INNER JOIN OW_SEDA_S."MAP_CE_PRODUCTS" tb3 ON tb1."ITEM" = tb3."ITEM"
    INNER JOIN (
      SELECT
        LAG("YEARWEEK", 7) OVER (ORDER BY "YEARWEEK") AS weeknum_lag_7,
        "YEARWEEK",
        "CALENDAR"
      FROM OW_SEDA_S."MAP_CE_CALENDAR" mc 
      WHERE "YEAR" BETWEEN 2024 AND 2025
    ) tb4 ON tb1."WEEKNUM" = tb4."YEARWEEK"
    LEFT JOIN (
      SELECT
        MAX("WEEKNUM") AS last_weeknum_sell_out,
        "SITE_ID",
        "ITEM"
      FROM OW_SEDA_S."FT_CE_READY"
      WHERE "PARAMETER" = 'Sell Out' 
        AND "WEEKNUM" <= weeknum_ref
        AND "DATA" > 0
      GROUP BY "SITE_ID", "ITEM"
    ) tb_last_sale
      ON tb1."SITE_ID" = tb_last_sale."SITE_ID"
     AND tb1."ITEM"    = tb_last_sale."ITEM"
    LEFT JOIN (
      SELECT
        MIN("WEEKNUM") AS first_weeknum_inventory,
        "SITE_ID",
        "ITEM",
        MAX("DATA") AS first_inventory
      FROM OW_SEDA_S."FT_CE_READY"
      WHERE "PARAMETER" = 'Inventory' 
        AND "WEEKNUM" <= weeknum_ref
        AND "DATA" > 0
      GROUP BY "SITE_ID", "ITEM"
    ) tb_first_inventory
      ON tb1."SITE_ID" = tb_first_inventory."SITE_ID"
     AND tb1."ITEM"    = tb_first_inventory."ITEM"
    INNER JOIN OW_SEDA_S."MAP_CE_CALENDAR" tb5 
      ON COALESCE(last_weeknum_sell_out, first_weeknum_inventory) = tb5."YEARWEEK"
    WHERE 
      tb1."PARAMETER" = 'Inventory' AND 
      tb1."WEEKNUM" = weeknum_ref AND 
      DATEDIFF('day', tb5."CALENDAR", tb4."CALENDAR")/7 + 1 -
        CASE WHEN last_weeknum_sell_out IS NOT NULL THEN 1 ELSE 0 END >= 8 AND
      tb1."DATA" - 1 > 0 AND
      tb2."STORE_TYPE" = 'Reg. Stores' AND
      tb2."ACCOUNT" = account_ref AND
      tb3."CATEGORY_ITEM" = category_ref
  ) source
  ON source."PARAMETER" = target."PARAMETER"
     AND source."WEEKNUM"   = target."WEEKNUM"
     AND source."SITE_ID"   = target."SITE_ID"
     AND source."ITEM"      = target."ITEM"
  WHEN MATCHED THEN UPDATE SET 
    target."DATA" = source."DATA",
    target."REPORT" = source."REPORT",
    target."INPUT_DATE" = source."INPUT_DATE"
  WHEN NOT MATCHED THEN INSERT (
    "PARAMETER", "WEEKNUM", "SITE_ID", "ITEM", "DATA", "REPORT", "INPUT_DATE"
  ) VALUES (
    source."PARAMETER", source."WEEKNUM", source."SITE_ID", source."ITEM", source."DATA", source."REPORT", source."INPUT_DATE"
  );

END;
$$;

-- CALL OW_SEDA_S.PRC_DEAD_INVENTORY_CALCULATION(201940, 'TV', 'VIA VAREJO');
-- ERROR: Severity: ERROR, Message: Either column "target" does not exist or table alias "target" is not allowed in "WHEN MATCHED THEN UPDATE SET", Sqlstate: 42602, Hint: Either fix the column name "target" or remove table alias "target" from all column names in "WHEN MATCHED THEN UPDATE SET", Where: PL/vSQL procedure PRC_DEAD_INVENTORY_CALCULATION line 20 at static SQL, Routine: transformVMergeStmt, File: analyze.c, Line: 3541, Error Code: 5569, 
CREATE OR REPLACE PROCEDURE OW_SEDA_S.PRC_DEAD_INVENTORY_CALCULATION(weeknum_ref INT, category_ref VARCHAR(10), account_ref VARCHAR(30))
LANGUAGE PLvSQL AS $$
BEGIN
  
  PERFORM DELETE FROM OW_SEDA_S."FT_CE_READY"
  WHERE EXISTS (
    SELECT 1 
    FROM OW_SEDA_S."FT_CE_READY" fr2 
    INNER JOIN OW_SEDA_S."MAP_CE_STORES" ml ON ml."SITE_ID" = fr2."SITE_ID" 
    INNER JOIN OW_SEDA_S."MAP_CE_PRODUCTS" mcp ON mcp."ITEM" = fr2."ITEM" 
    WHERE fr2."WEEKNUM" = weeknum_ref
      AND fr2."PARAMETER" = 'Dead Inventory' 
      AND mcp."CATEGORY_ITEM" = category_ref 
      AND ml."ACCOUNT" = account_ref
      AND OW_SEDA_S."FT_CE_READY"."SITE_ID" = fr2."SITE_ID"
      AND OW_SEDA_S."FT_CE_READY"."ITEM" = fr2."ITEM"
      AND OW_SEDA_S."FT_CE_READY"."WEEKNUM" = fr2."WEEKNUM"
      AND OW_SEDA_S."FT_CE_READY"."PARAMETER" = fr2."PARAMETER"
  );

  PERFORM MERGE INTO OW_SEDA_S."FT_CE_READY" target
  USING (
    SELECT DISTINCT
      'Dead Inventory' AS "PARAMETER",
      tb1."WEEKNUM",
      tb1."SITE_ID",
      tb1."ITEM",
      tb1."DATA" - 1 AS "DATA",
      'Dead Inventory Manual' AS "REPORT",
      CURRENT_DATE AS "INPUT_DATE",
      CASE
        WHEN last_weeknum_sell_out IS NULL THEN first_weeknum_inventory
        ELSE last_weeknum_sell_out
      END AS weeknum_to_diff,
      DATEDIFF('day', tb5."CALENDAR", tb4."CALENDAR")/7 AS difference
    FROM OW_SEDA_S."FT_CE_READY" tb1
    INNER JOIN OW_SEDA_S."MAP_CE_STORES" tb2 ON tb1."SITE_ID" = tb2."SITE_ID"
    INNER JOIN OW_SEDA_S."MAP_CE_PRODUCTS" tb3 ON tb1."ITEM" = tb3."ITEM"
    INNER JOIN (
      SELECT
        LAG("YEARWEEK", 7) OVER (ORDER BY "YEARWEEK") AS weeknum_lag_7,
        "YEARWEEK",
        "CALENDAR"
      FROM OW_SEDA_S."MAP_CE_CALENDAR" mc 
      WHERE "YEAR" BETWEEN 2024 AND 2025
    ) tb4 ON tb1."WEEKNUM" = tb4."YEARWEEK"
    LEFT JOIN (
      SELECT
        MAX("WEEKNUM") AS last_weeknum_sell_out,
        "SITE_ID",
        "ITEM"
      FROM OW_SEDA_S."FT_CE_READY"
      WHERE "PARAMETER" = 'Sell Out' 
        AND "WEEKNUM" <= weeknum_ref
        AND "DATA" > 0
      GROUP BY "SITE_ID", "ITEM"
    ) tb_last_sale
      ON tb1."SITE_ID" = tb_last_sale."SITE_ID"
     AND tb1."ITEM"    = tb_last_sale."ITEM"
    LEFT JOIN (
      SELECT
        MIN("WEEKNUM") AS first_weeknum_inventory,
        "SITE_ID",
        "ITEM",
        MAX("DATA") AS first_inventory
      FROM OW_SEDA_S."FT_CE_READY"
      WHERE "PARAMETER" = 'Inventory' 
        AND "WEEKNUM" <= weeknum_ref
        AND "DATA" > 0
      GROUP BY "SITE_ID", "ITEM"
    ) tb_first_inventory
      ON tb1."SITE_ID" = tb_first_inventory."SITE_ID"
     AND tb1."ITEM"    = tb_first_inventory."ITEM"
    INNER JOIN OW_SEDA_S."MAP_CE_CALENDAR" tb5 
      ON COALESCE(last_weeknum_sell_out, first_weeknum_inventory) = tb5."YEARWEEK"
    WHERE 
      tb1."PARAMETER" = 'Inventory' AND 
      tb1."WEEKNUM" = weeknum_ref AND 
      DATEDIFF('day', tb5."CALENDAR", tb4."CALENDAR")/7 + 1 -
        CASE WHEN last_weeknum_sell_out IS NOT NULL THEN 1 ELSE 0 END >= 8 AND
      tb1."DATA" - 1 > 0 AND
      tb2."STORE_TYPE" = 'Reg. Stores' AND
      tb2."ACCOUNT" = account_ref AND
      tb3."CATEGORY_ITEM" = category_ref
  ) source
  ON source."PARAMETER" = target."PARAMETER"
     AND source."WEEKNUM"   = target."WEEKNUM"
     AND source."SITE_ID"   = target."SITE_ID"
     AND source."ITEM"      = target."ITEM"
  WHEN MATCHED THEN UPDATE SET 
    "DATA" = source."DATA",
    "REPORT" = source."REPORT",
    "INPUT_DATE" = source."INPUT_DATE"
  WHEN NOT MATCHED THEN INSERT (
    "PARAMETER", "WEEKNUM", "SITE_ID", "ITEM", "DATA", "REPORT", "INPUT_DATE"
  ) VALUES (
    source."PARAMETER", source."WEEKNUM", source."SITE_ID", source."ITEM", source."DATA", source."REPORT", source."INPUT_DATE"
  );

END;
$$;

CALL OW_SEDA_S.PRC_DEAD_INVENTORY_CALCULATION(201940, 'TV', 'VIA VAREJO');
-- PRC_DEAD_INVENTORY_CALCULATION
-- ------------------------------
-- 0

