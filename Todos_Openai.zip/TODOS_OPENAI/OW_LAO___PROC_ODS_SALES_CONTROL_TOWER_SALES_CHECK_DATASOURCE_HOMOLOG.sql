-- CREATE OR REPLACE PROCEDURE OW_LAO.PROC_ODS_SALES_CONTROL_TOWER_SALES_CHECK_DATASOURCE_HOMOLOG()
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--   RETURN QUERY
--   WITH ecommerce_orders AS (
--      SELECT
--         MAX(COALESCE(o.po_source_last_update_date, o.po_source_insert_date)) AS last_data,
--         'ods_sales_control_tower_table' AS origin,
--         CASE WHEN o.subsidiary LIKE 'SELA%' THEN 'SELA' ELSE o.subsidiary END AS subsidiary,
--         CASE WHEN CAST(o.po_source_last_update_date AS DATE) = CURRENT_DATE THEN 'OK' ELSE 'NOT OK' END AS status,
--         o.country
--      FROM ow_lao.ods_sales_control_tower_table o
--      JOIN (
--         SELECT subsidiary, country, MAX(po_source_last_update_date) AS po_source_last_update_date
--         FROM ow_lao.ods_sales_control_tower_table
--         WHERE CAST(po_source_last_update_date AS DATE) BETWEEN TIMESTAMPADD(DAY, -10, CURRENT_DATE) AND CURRENT_DATE
--         GROUP BY subsidiary, country
--      ) m
--        ON o.subsidiary = m.subsidiary
--       AND o.country = m.country
--       AND o.po_source_last_update_date = m.po_source_last_update_date
--      WHERE o.po_plataform_datasource NOT IN ('ow_lao.ods_global_bi_sales', 'u_prj_ecom_synapcom.ft_ecom_order')
--      GROUP BY o.po_source_last_update_date, o.subsidiary, o.country
--   ),
--   complementary_data AS (
--      SELECT
--         MAX(nerp_last_update_date) AS sales_order_tracking_timestamp,
--         CASE WHEN DATEDIFF('minute', MAX(nerp_last_update_date), CURRENT_TIMESTAMP) <= 120 THEN 'OK' ELSE 'NOT OK' END AS sales_order_tracking_status,
--         MAX(nerp_outbound_last_update_date) AS outbound_timestamp,
--         CASE WHEN DATEDIFF('minute', MAX(nerp_outbound_last_update_date), CURRENT_TIMESTAMP) <= 60 THEN 'OK' ELSE 'NOT OK' END AS outbound_status,
--         MAX(ebi_last_update_date) AS global_bi_timestamp,
--         CASE WHEN DATEDIFF('minute', MAX(ebi_last_update_date), CURRENT_TIMESTAMP) <= 1440 THEN 'OK' ELSE 'NOT OK' END AS global_bi_status,
--         MAX(po_source_payment_last_update_date) AS payment_timestamp,
--         CASE WHEN DATEDIFF('minute', MAX(po_source_payment_last_update_date), CURRENT_TIMESTAMP) <= 60 THEN 'OK' ELSE 'NOT OK' END AS payment_status,
--         NULL::VARCHAR AS country,
--         NULL::VARCHAR AS subsidiary
--      FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE
--   )
--   SELECT
--      CASE element_number
--          WHEN 1 THEN 'Sales Order Tracking'
--          WHEN 2 THEN 'Outbound'
--          WHEN 3 THEN 'Global BI Files'
--          WHEN 4 THEN 'Payments'
--      END AS origin,
--      CASE element_number
--          WHEN 1 THEN sales_order_tracking_status
--          WHEN 2 THEN outbound_status
--          WHEN 3 THEN global_bi_status
--          WHEN 4 THEN payment_status
--      END AS status,
--      CASE element_number
--          WHEN 1 THEN sales_order_tracking_timestamp
--          WHEN 2 THEN outbound_timestamp
--          WHEN 3 THEN global_bi_timestamp
--          WHEN 4 THEN payment_timestamp
--      END AS last_data,
--      country
--   FROM complementary_data
--   CROSS JOIN (
--      SELECT 1 AS element_number
--      UNION ALL SELECT 2
--      UNION ALL SELECT 3
--      UNION ALL SELECT 4
--   ) s
--   UNION ALL
--   SELECT
--      origin,
--      status,
--      last_data,
--      country
--   FROM ecommerce_orders;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 3.10-14 of source string: syntax error, unexpected QUERY, expecting := or <-, Sqlstate: 42601, Position: 135, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
-- CREATE OR REPLACE PROCEDURE OW_LAO.PROC_ODS_SALES_CONTROL_TOWER_SALES_CHECK_DATASOURCE_HOMOLOG()
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--   WITH ecommerce_orders AS ( 
--         SELECT 
--             MAX(COALESCE(po_source_last_update_date, po_source_insert_date)) AS last_data,
--             'ods_sales_control_tower_table' AS origin,
--             CASE 
--                 WHEN subsidiary LIKE 'SELA%' THEN 'SELA' 
--                 ELSE subsidiary 
--             END AS subsidiary ,
--             CASE 
--                 WHEN CAST(po_source_last_update_date AS DATE) = CURRENT_DATE THEN 'OK'
--                 ELSE 'NOT OK'
--             END AS status,
--             country
--         FROM ow_lao.ods_sales_control_tower_table
--         WHERE po_plataform_datasource NOT IN ('ow_lao.ods_global_bi_sales', 'u_prj_ecom_synapcom.ft_ecom_order')
--           AND (subsidiary, country, po_source_last_update_date) IN (
--               SELECT 
--                   subsidiary, 
--                   country,
--                   MAX(po_source_last_update_date) AS po_source_last_update_date
--               FROM ow_lao.ods_sales_control_tower_table
--               WHERE CAST(po_source_last_update_date AS DATE) BETWEEN TIMESTAMPADD(DAY, -10, CURRENT_DATE) AND CURRENT_DATE
--               GROUP BY subsidiary, country
--           )
--         GROUP BY po_source_last_update_date, subsidiary, country
--     ), 
--     complementary_data AS (
--         SELECT 
--             MAX(nerp_last_update_date) AS sales_order_tracking_timestamp,
--             CASE
--                 WHEN DATEDIFF('minute', MAX(nerp_last_update_date), CURRENT_TIMESTAMP) <= 120 THEN 'OK'
--                 ELSE 'NOT OK'
--             END AS sales_order_tracking_status,
--             MAX(nerp_outbound_last_update_date) AS outbound_timestamp,
--             CASE
--                 WHEN DATEDIFF('minute', MAX(nerp_outbound_last_update_date), CURRENT_TIMESTAMP) <= 60 THEN 'OK'
--                 ELSE 'NOT OK'
--             END AS outbound_status,
--             MAX(ebi_last_update_date) AS global_bi_timestamp,
--             CASE
--                 WHEN DATEDIFF('minute', MAX(ebi_last_update_date), CURRENT_TIMESTAMP) <= 1440 THEN 'OK'
--                 ELSE 'NOT OK'
--             END AS global_bi_status,
--             MAX(po_source_payment_last_update_date) AS payment_timestamp,
--             CASE
--                 WHEN DATEDIFF('minute', MAX(po_source_payment_last_update_date), CURRENT_TIMESTAMP) <= 60 THEN 'OK'
--                 ELSE 'NOT OK'
--             END AS payment_status,
--             NULL::VARCHAR AS country  ,
--             NULL::VARCHAR AS subsidiary 
--         FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE
--     )   
--     SELECT 
--         CASE s.element_number 
--             WHEN 1 THEN 'Sales Order Tracking'
--             WHEN 2 THEN 'Outbound'
--             WHEN 3 THEN 'Global BI Files'
--             WHEN 4 THEN 'Payments'
--         END AS origin,
--         CASE s.element_number 
--             WHEN 1 THEN sales_order_tracking_status
--             WHEN 2 THEN outbound_status
--             WHEN 3 THEN global_bi_status
--             WHEN 4 THEN payment_status
--         END AS status,
--         CASE s.element_number 
--             WHEN 1 THEN sales_order_tracking_timestamp
--             WHEN 2 THEN outbound_timestamp
--             WHEN 3 THEN global_bi_timestamp
--             WHEN 4 THEN payment_timestamp
--         END AS last_data,
--         country 
--     FROM complementary_data
--     CROSS JOIN (
--         SELECT 1 AS element_number
--         UNION ALL SELECT 2
--         UNION ALL SELECT 3
--         UNION ALL SELECT 4
--     ) s
--     UNION ALL
--     SELECT 
--         origin,
--         status,
--         last_data,
--         country
--     FROM ecommerce_orders;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 3.8-23 of source string: syntax error, unexpected IDENT, expecting := or <-, Sqlstate: 42601, Position: 133, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
CREATE OR REPLACE PROCEDURE OW_LAO.PROC_ODS_SALES_CONTROL_TOWER_SALES_CHECK_DATASOURCE_HOMOLOG()
LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM CREATE LOCAL TEMP TABLE tmp_proc_ods_sales_control_tower_sales_check_datasource_homolog_result ON COMMIT PRESERVE ROWS AS
      SELECT CAST(NULL AS VARCHAR) AS origin,
             CAST(NULL AS VARCHAR) AS status,
             CAST(NULL AS TIMESTAMP) AS last_data,
             CAST(NULL AS VARCHAR) AS country
      WHERE 1=0;

    PERFORM INSERT INTO tmp_proc_ods_sales_control_tower_sales_check_datasource_homolog_result(origin, status, last_data, country)
    WITH ecommerce_orders AS (
        SELECT 
            MAX(COALESCE(o.po_source_last_update_date, o.po_source_insert_date))::TIMESTAMP AS last_data,
            'ods_sales_control_tower_table' AS origin,
            CASE 
                WHEN o.subsidiary LIKE 'SELA%' THEN 'SELA' 
                ELSE o.subsidiary 
            END AS subsidiary,
            CASE 
                WHEN CAST(o.po_source_last_update_date AS DATE) = CURRENT_DATE THEN 'OK'
                ELSE 'NOT OK'
            END AS status,
            o.country
        FROM ow_lao.ods_sales_control_tower_table o
        JOIN (
            SELECT subsidiary, country, MAX(po_source_last_update_date) AS po_source_last_update_date
            FROM ow_lao.ods_sales_control_tower_table
            WHERE CAST(po_source_last_update_date AS DATE) BETWEEN TIMESTAMPADD(DAY, -10, CURRENT_DATE) AND CURRENT_DATE
            GROUP BY subsidiary, country
        ) m
          ON o.subsidiary = m.subsidiary
         AND o.country = m.country
         AND o.po_source_last_update_date = m.po_source_last_update_date
        WHERE o.po_plataform_datasource NOT IN ('ow_lao.ods_global_bi_sales', 'u_prj_ecom_synapcom.ft_ecom_order')
        GROUP BY o.po_source_last_update_date, o.subsidiary, o.country
    ), 
    complementary_data AS (
        SELECT 
            MAX(nerp_last_update_date) AS sales_order_tracking_timestamp,
            CASE WHEN DATEDIFF('minute', MAX(nerp_last_update_date), CURRENT_TIMESTAMP) <= 120 THEN 'OK' ELSE 'NOT OK' END AS sales_order_tracking_status,
            MAX(nerp_outbound_last_update_date) AS outbound_timestamp,
            CASE WHEN DATEDIFF('minute', MAX(nerp_outbound_last_update_date), CURRENT_TIMESTAMP) <= 60 THEN 'OK' ELSE 'NOT OK' END AS outbound_status,
            MAX(ebi_last_update_date) AS global_bi_timestamp,
            CASE WHEN DATEDIFF('minute', MAX(ebi_last_update_date), CURRENT_TIMESTAMP) <= 1440 THEN 'OK' ELSE 'NOT OK' END AS global_bi_status,
            MAX(po_source_payment_last_update_date) AS payment_timestamp,
            CASE WHEN DATEDIFF('minute', MAX(po_source_payment_last_update_date), CURRENT_TIMESTAMP) <= 60 THEN 'OK' ELSE 'NOT OK' END AS payment_status,
            NULL::VARCHAR AS country,
            NULL::VARCHAR AS subsidiary
        FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE
    )
    SELECT 
        CASE s.element_number
            WHEN 1 THEN 'Sales Order Tracking'
            WHEN 2 THEN 'Outbound'
            WHEN 3 THEN 'Global BI Files'
            WHEN 4 THEN 'Payments'
        END AS origin,
        CASE s.element_number
            WHEN 1 THEN sales_order_tracking_status
            WHEN 2 THEN outbound_status
            WHEN 3 THEN global_bi_status
            WHEN 4 THEN payment_status
        END AS status,
        CASE s.element_number
            WHEN 1 THEN sales_order_tracking_timestamp
            WHEN 2 THEN outbound_timestamp
            WHEN 3 THEN global_bi_timestamp
            WHEN 4 THEN payment_timestamp
        END AS last_data,
        country
    FROM complementary_data
    CROSS JOIN (
        SELECT 1 AS element_number
        UNION ALL SELECT 2
        UNION ALL SELECT 3
        UNION ALL SELECT 4
    ) s
    UNION ALL
    SELECT 
        origin,
        status,
        last_data,
        country
    FROM ecommerce_orders;
END;
$$;

-- CALL OW_LAO.PROC_ODS_SALES_CONTROL_TOWER_SALES_CHECK_DATASOURCE_HOMOLOG();
-- ERROR: Severity: ERROR, Message: String of 8 octets is too long for type Varchar(1), Sqlstate: 22001, Where: PL/vSQL procedure PROC_ODS_SALES_CONTROL_TOWER_SALES_CHECK_DATASOURCE_HOMOLOG line 10 at static SQL, Routine: Char_Resize, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/EE/Functions/Chars.cpp, Line: 218, Error Code: 4800, 
-- CALL OW_LAO.PROC_ODS_SALES_CONTROL_TOWER_SALES_CHECK_DATASOURCE_HOMOLOG();
-- ERROR: Severity: ERROR, Message: String of 20 octets is too long for type Varchar(1), Sqlstate: 22001, Where: PL/vSQL procedure PROC_ODS_SALES_CONTROL_TOWER_SALES_CHECK_DATASOURCE_HOMOLOG line 10 at static SQL, Routine: Char_Resize, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/EE/Functions/Chars.cpp, Line: 218, Error Code: 4800, 
-- CREATE OR REPLACE PROCEDURE OW_LAO.PROC_ODS_SALES_CONTROL_TOWER_SALES_CHECK_DATASOURCE_HOMOLOG()
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--     PERFORM CREATE LOCAL TEMP TABLE tmp_proc_ods_sales_control_tower_sales_check_datasource_homolog_result ON COMMIT PRESERVE ROWS AS
--       SELECT CAST(NULL AS VARCHAR(64)) AS origin,
--              CAST(NULL AS VARCHAR(10)) AS status,
--              CAST(NULL AS TIMESTAMP) AS last_data,
--              CAST(NULL AS VARCHAR(64)) AS country
--       WHERE 1=0;
-- 
--     PERFORM INSERT INTO tmp_proc_ods_sales_control_tower_sales_check_datasource_homolog_result(origin, status, last_data, country)
--     WITH ecommerce_orders AS (
--         SELECT 
--             MAX(COALESCE(o.po_source_last_update_date, o.po_source_insert_date))::TIMESTAMP AS last_data,
--             'ods_sales_control_tower_table' AS origin,
--             CASE 
--                 WHEN o.subsidiary LIKE 'SELA%' THEN 'SELA' 
--                 ELSE o.subsidiary 
--             END AS subsidiary,
--             CASE 
--                 WHEN CAST(o.po_source_last_update_date AS DATE) = CURRENT_DATE THEN 'OK'
--                 ELSE 'NOT OK'
--             END AS status,
--             o.country
--         FROM ow_lao.ods_sales_control_tower_table o
--         JOIN (
--             SELECT subsidiary, country, MAX(po_source_last_update_date) AS po_source_last_update_date
--             FROM ow_lao.ods_sales_control_tower_table
--             WHERE CAST(po_source_last_update_date AS DATE) BETWEEN TIMESTAMPADD(DAY, -10, CURRENT_DATE) AND CURRENT_DATE
--             GROUP BY subsidiary, country
--         ) m
--           ON o.subsidiary = m.subsidiary
--          AND o.country = m.country
--          AND o.po_source_last_update_date = m.po_source_last_update_date
--         WHERE o.po_plataform_datasource NOT IN ('ow_lao.ods_global_bi_sales', 'u_prj_ecom_synapcom.ft_ecom_order')
--         GROUP BY o.po_source_last_update_date, o.subsidiary, o.country
--     ), 
--     complementary_data AS (
--         SELECT 
--             MAX(nerp_last_update_date) AS sales_order_tracking_timestamp,
--             CASE WHEN DATEDIFF('minute', MAX(nerp_last_update_date), CURRENT_TIMESTAMP) <= 120 THEN 'OK' ELSE 'NOT OK' END AS sales_order_tracking_status,
--             MAX(nerp_outbound_last_update_date) AS outbound_timestamp,
--             CASE WHEN DATEDIFF('minute', MAX(nerp_outbound_last_update_date), CURRENT_TIMESTAMP) <= 60 THEN 'OK' ELSE 'NOT OK' END AS outbound_status,
--             MAX(ebi_last_update_date) AS global_bi_timestamp,
--             CASE WHEN DATEDIFF('minute', MAX(ebi_last_update_date), CURRENT_TIMESTAMP) <= 1440 THEN 'OK' ELSE 'NOT OK' END AS global_bi_status,
--             MAX(po_source_payment_last_update_date) AS payment_timestamp,
--             CASE WHEN DATEDIFF('minute', MAX(po_source_payment_last_update_date), CURRENT_TIMESTAMP) <= 60 THEN 'OK' ELSE 'NOT OK' END AS payment_status,
--             NULL::VARCHAR(64) AS country,
--             NULL::VARCHAR(64) AS subsidiary
--         FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE
--     )
--     SELECT 
--         CASE s.element_number
--             WHEN 1 THEN 'Sales Order Tracking'
--             WHEN 2 THEN 'Outbound'
--             WHEN 3 THEN 'Global BI Files'
--             WHEN 4 THEN 'Payments'
--         END AS origin,
--         CASE s.element_number
--             WHEN 1 THEN sales_order_tracking_status
--             WHEN 2 THEN outbound_status
--             WHEN 3 THEN global_bi_status
--             WHEN 4 THEN payment_status
--         END AS status,
--         CASE s.element_number
--             WHEN 1 THEN sales_order_tracking_timestamp
--             WHEN 2 THEN outbound_timestamp
--             WHEN 3 THEN global_bi_timestamp
--             WHEN 4 THEN payment_timestamp
--         END AS last_data,
--         country
--     FROM complementary_data
--     CROSS JOIN (
--         SELECT 1 AS element_number
--         UNION ALL SELECT 2
--         UNION ALL SELECT 3
--         UNION ALL SELECT 4
--     ) s
--     UNION ALL
--     SELECT 
--         origin,
--         status,
--         last_data,
--         country
--     FROM ecommerce_orders;
-- 
--     SELECT origin, status, last_data, country
--     FROM tmp_proc_ods_sales_control_tower_sales_check_datasource_homolog_result;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 87.80 of source string: syntax error, unexpected ;, expecting INTO, Sqlstate: 42601, Position: 4079, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
CREATE OR REPLACE PROCEDURE OW_LAO.PROC_ODS_SALES_CONTROL_TOWER_SALES_CHECK_DATASOURCE_HOMOLOG()
LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM CREATE LOCAL TEMP TABLE tmp_proc_ods_sales_control_tower_sales_check_datasource_homolog_result ON COMMIT PRESERVE ROWS AS
      SELECT CAST(NULL AS VARCHAR(64)) AS origin,
             CAST(NULL AS VARCHAR(10)) AS status,
             CAST(NULL AS TIMESTAMP) AS last_data,
             CAST(NULL AS VARCHAR(64)) AS country
      WHERE 1=0;

    PERFORM INSERT INTO tmp_proc_ods_sales_control_tower_sales_check_datasource_homolog_result(origin, status, last_data, country)
    WITH ecommerce_orders AS (
        SELECT 
            MAX(COALESCE(o.po_source_last_update_date, o.po_source_insert_date))::TIMESTAMP AS last_data,
            'ods_sales_control_tower_table' AS origin,
            CASE 
                WHEN o.subsidiary LIKE 'SELA%' THEN 'SELA' 
                ELSE o.subsidiary 
            END AS subsidiary,
            CASE 
                WHEN CAST(o.po_source_last_update_date AS DATE) = CURRENT_DATE THEN 'OK'
                ELSE 'NOT OK'
            END AS status,
            o.country
        FROM ow_lao.ods_sales_control_tower_table o
        JOIN (
            SELECT subsidiary, country, MAX(po_source_last_update_date) AS po_source_last_update_date
            FROM ow_lao.ods_sales_control_tower_table
            WHERE CAST(po_source_last_update_date AS DATE) BETWEEN TIMESTAMPADD(DAY, -10, CURRENT_DATE) AND CURRENT_DATE
            GROUP BY subsidiary, country
        ) m
          ON o.subsidiary = m.subsidiary
         AND o.country = m.country
         AND o.po_source_last_update_date = m.po_source_last_update_date
        WHERE o.po_plataform_datasource NOT IN ('ow_lao.ods_global_bi_sales', 'u_prj_ecom_synapcom.ft_ecom_order')
        GROUP BY o.po_source_last_update_date, o.subsidiary, o.country
    ), 
    complementary_data AS (
        SELECT 
            MAX(nerp_last_update_date) AS sales_order_tracking_timestamp,
            CASE WHEN DATEDIFF('minute', MAX(nerp_last_update_date), CURRENT_TIMESTAMP) <= 120 THEN 'OK' ELSE 'NOT OK' END AS sales_order_tracking_status,
            MAX(nerp_outbound_last_update_date) AS outbound_timestamp,
            CASE WHEN DATEDIFF('minute', MAX(nerp_outbound_last_update_date), CURRENT_TIMESTAMP) <= 60 THEN 'OK' ELSE 'NOT OK' END AS outbound_status,
            MAX(ebi_last_update_date) AS global_bi_timestamp,
            CASE WHEN DATEDIFF('minute', MAX(ebi_last_update_date), CURRENT_TIMESTAMP) <= 1440 THEN 'OK' ELSE 'NOT OK' END AS global_bi_status,
            MAX(po_source_payment_last_update_date) AS payment_timestamp,
            CASE WHEN DATEDIFF('minute', MAX(po_source_payment_last_update_date), CURRENT_TIMESTAMP) <= 60 THEN 'OK' ELSE 'NOT OK' END AS payment_status,
            NULL::VARCHAR(64) AS country,
            NULL::VARCHAR(64) AS subsidiary
        FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE
    )
    SELECT 
        CASE s.element_number
            WHEN 1 THEN 'Sales Order Tracking'
            WHEN 2 THEN 'Outbound'
            WHEN 3 THEN 'Global BI Files'
            WHEN 4 THEN 'Payments'
        END AS origin,
        CASE s.element_number
            WHEN 1 THEN sales_order_tracking_status
            WHEN 2 THEN outbound_status
            WHEN 3 THEN global_bi_status
            WHEN 4 THEN payment_status
        END AS status,
        CASE s.element_number
            WHEN 1 THEN sales_order_tracking_timestamp
            WHEN 2 THEN outbound_timestamp
            WHEN 3 THEN global_bi_timestamp
            WHEN 4 THEN payment_timestamp
        END AS last_data,
        country
    FROM complementary_data
    CROSS JOIN (
        SELECT 1 AS element_number
        UNION ALL SELECT 2
        UNION ALL SELECT 3
        UNION ALL SELECT 4
    ) s
    UNION ALL
    SELECT 
        origin,
        status,
        last_data,
        country
    FROM ecommerce_orders;
END;
$$;

CALL OW_LAO.PROC_ODS_SALES_CONTROL_TOWER_SALES_CHECK_DATASOURCE_HOMOLOG();
-- PROC_ODS_SALES_CONTROL_TOWER_SALES_CHECK_DATASOURCE_HOMOLOG
-- -----------------------------------------------------------
-- 0

