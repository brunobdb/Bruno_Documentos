CREATE OR REPLACE PROCEDURE OW_LAO.PROC_D2C_NERP_DELIVERY_PENDING()
LANGUAGE PLvSQL AS $$
BEGIN
  -- Truncate table for Delivery Pending info
  PERFORM TRUNCATE TABLE OW_LAO.FT_D2C_NERP_DELIVERY_PENDING;

  -- Insert Delivery Pending info
  PERFORM INSERT INTO OW_LAO.FT_D2C_NERP_DELIVERY_PENDING
  SELECT 
      DS.SUBSIDIARY --1
    , ONZOT.REGION AS STATE --2
    , ONZOT.CITY --3
    , ONZOT.TRANSPORTER_NAME --4
    , ONZOT.PLANT --5
    , DP."DIVISION" AS DIMPROD_DIVISION 
    , DP.PRODUCT_GROUP_1 AS DIMPROD_PRODUCT_GROUP 
    , DP.PRODUCT_1 AS DIMPROD_PRODUCT 
    , DP2.ORIGIN AS PLANT_NAME --6
    , ONZOT.DELIVERY_NO --7
    , ONZOT.MATERIAL
    , ONZOT.REFERENCE_DOC_SO_PO  --8
    , ONZOT."1ST_GI_DATE" --9 
    , ONZOT.PLANNED_GI 
    , ONZOT.DELIVERY_DATE
    , ONZOT.RDD_SO_ITEM
    , (
        SELECT CASE 
                 WHEN (SUM(WORK_DAY_SEDA) - 1) = -1 THEN 0 
                 WHEN (DAYOFWEEK_ISO(CAST(ONZOT."1ST_GI_DATE" AS DATE)) IN (6,7) 
                       AND DAYOFWEEK_ISO(CURRENT_DATE) IN (6,7)) 
                      THEN SUM(WORK_DAY_SEDA) 
                 ELSE (SUM(WORK_DAY_SEDA) - 1) 
               END
          FROM OW_MD.DIM_CALENDAR DC 
         WHERE (YYYYMMDD BETWEEN CAST(ONZOT."1ST_GI_DATE" AS DATE) AND CURRENT_DATE)
      ) AS "LT_GI_IOD" 
    , (CASE WHEN DS.SUBSIDIARY = 'SEDA' AND (ONZOT.SPI = 'CR02' OR ONZOT.SPI = 'AGS1') 
            THEN COALESCE((
                   SELECT CASE WHEN (SUM(WORK_DAY_SEDA) - 1) = -1 THEN 0 
                               WHEN (DAYOFWEEK_ISO(CAST(ONZOT.PLANNED_GI AS DATE)) IN (6,7) 
                                     AND DAYOFWEEK_ISO(CAST(ONZOT.DELIVERY_DATE AS DATE)) IN (6,7)) 
                                    THEN SUM(WORK_DAY_SEDA) 
                                    ELSE (SUM(WORK_DAY_SEDA) - 1) 
                          END
                     FROM OW_MD.DIM_CALENDAR DC 
                    WHERE (YYYYMMDD BETWEEN CAST(ONZOT.PLANNED_GI AS DATE) AND CAST(ONZOT.DELIVERY_DATE AS DATE))
                 ), 0)
            ELSE COALESCE((
                   SELECT CASE WHEN (SUM(WORK_DAY_SEDA) - 1) = -1 THEN 0 
                               WHEN (DAYOFWEEK_ISO(CAST(ONZOT.PLANNED_GI AS DATE)) IN (6,7) 
                                     AND DAYOFWEEK_ISO(CAST(ONZOT.RDD_SO_ITEM AS DATE)) IN (6,7)) 
                                    THEN SUM(WORK_DAY_SEDA) 
                                    ELSE (SUM(WORK_DAY_SEDA) - 1) 
                          END
                     FROM OW_MD.DIM_CALENDAR DC 
                    WHERE (YYYYMMDD BETWEEN CAST(ONZOT.PLANNED_GI AS DATE) AND CAST(ONZOT.RDD_SO_ITEM AS DATE))
                 ), 0)
       END) AS "TGT_WK_GI_IOD"
    , CASE 
        WHEN ((
                SELECT CASE WHEN (SUM(WORK_DAY_SEDA) - 1) = -1 THEN 0 
                            WHEN (DAYOFWEEK_ISO(CAST(ONZOT."1ST_GI_DATE" AS DATE)) IN (6,7) 
                                  AND DAYOFWEEK_ISO(CURRENT_DATE) IN (6,7)) 
                                 THEN SUM(WORK_DAY_SEDA) 
                                 ELSE (SUM(WORK_DAY_SEDA) - 1) 
                       END
                  FROM OW_MD.DIM_CALENDAR DC 
                 WHERE (YYYYMMDD BETWEEN CAST(ONZOT."1ST_GI_DATE" AS DATE) AND CURRENT_DATE)
              )
              - /*DLTW.LEAD_TIME_GI_IOD*/
              (CASE WHEN DS.SUBSIDIARY = 'SEDA' AND (ONZOT.SPI = 'CR02' OR ONZOT.SPI = 'AGS1') 
                    THEN COALESCE((
                           SELECT CASE WHEN (SUM(WORK_DAY_SEDA) - 1) = -1 THEN 0 
                                       WHEN (DAYOFWEEK_ISO(CAST(ONZOT.PLANNED_GI AS DATE)) IN (6,7) 
                                             AND DAYOFWEEK_ISO(CAST(ONZOT.DELIVERY_DATE AS DATE)) IN (6,7)) 
                                              THEN SUM(WORK_DAY_SEDA) 
                                              ELSE (SUM(WORK_DAY_SEDA) - 1) 
                                    END
                              FROM OW_MD.DIM_CALENDAR DC 
                             WHERE (YYYYMMDD BETWEEN CAST(ONZOT.PLANNED_GI AS DATE) AND CAST(ONZOT.DELIVERY_DATE AS DATE))
                         ), 0)
                    ELSE COALESCE((
                           SELECT CASE WHEN (SUM(WORK_DAY_SEDA) - 1) = -1 THEN 0 
                                       WHEN (DAYOFWEEK_ISO(CAST(ONZOT.PLANNED_GI AS DATE)) IN (6,7) 
                                             AND DAYOFWEEK_ISO(CAST(ONZOT.RDD_SO_ITEM AS DATE)) IN (6,7)) 
                                              THEN SUM(WORK_DAY_SEDA) 
                                              ELSE (SUM(WORK_DAY_SEDA) - 1) 
                                    END
                              FROM OW_MD.DIM_CALENDAR DC 
                             WHERE (YYYYMMDD BETWEEN CAST(ONZOT.PLANNED_GI AS DATE) AND CAST(ONZOT.RDD_SO_ITEM AS DATE))
                         ), 0)
               END)) <= 0 
         THEN 0 
         ELSE ((
                SELECT CASE WHEN (SUM(WORK_DAY_SEDA) - 1) = -1 THEN 0 
                            WHEN (DAYOFWEEK_ISO(CAST(ONZOT."1ST_GI_DATE" AS DATE)) IN (6,7) 
                                  AND DAYOFWEEK_ISO(CURRENT_DATE) IN (6,7)) 
                                 THEN SUM(WORK_DAY_SEDA) 
                                 ELSE (SUM(WORK_DAY_SEDA) - 1) 
                       END
                  FROM OW_MD.DIM_CALENDAR DC 
                 WHERE (YYYYMMDD BETWEEN CAST(ONZOT."1ST_GI_DATE" AS DATE) AND CURRENT_DATE)
              )
              - /*DLTW.LEAD_TIME_GI_IOD*/
              (CASE WHEN DS.SUBSIDIARY = 'SEDA' AND (ONZOT.SPI = 'CR02' OR ONZOT.SPI = 'AGS1') 
                    THEN COALESCE((
                           SELECT CASE WHEN (SUM(WORK_DAY_SEDA) - 1) = -1 THEN 0 
                                       WHEN (DAYOFWEEK_ISO(CAST(ONZOT.PLANNED_GI AS DATE)) IN (6,7) 
                                             AND DAYOFWEEK_ISO(CAST(ONZOT.DELIVERY_DATE AS DATE)) IN (6,7)) 
                                              THEN SUM(WORK_DAY_SEDA) 
                                              ELSE (SUM(WORK_DAY_SEDA) - 1) 
                                    END
                              FROM OW_MD.DIM_CALENDAR DC 
                             WHERE (YYYYMMDD BETWEEN CAST(ONZOT.PLANNED_GI AS DATE) AND CAST(ONZOT.DELIVERY_DATE AS DATE))
                         ), 0)
                    ELSE COALESCE((
                           SELECT CASE WHEN (SUM(WORK_DAY_SEDA) - 1) = -1 THEN 0 
                                       WHEN (DAYOFWEEK_ISO(CAST(ONZOT.PLANNED_GI AS DATE)) IN (6,7) 
                                             AND DAYOFWEEK_ISO(CAST(ONZOT.RDD_SO_ITEM AS DATE)) IN (6,7)) 
                                              THEN SUM(WORK_DAY_SEDA) 
                                              ELSE (SUM(WORK_DAY_SEDA) - 1) 
                                    END
                              FROM OW_MD.DIM_CALENDAR DC 
                             WHERE (YYYYMMDD BETWEEN CAST(ONZOT.PLANNED_GI AS DATE) AND CAST(ONZOT.RDD_SO_ITEM AS DATE))
                         ), 0)
               END)) 
       END AS LEAD_TIME_VS_TARGET_LEAD_TIME
    , DATEDIFF('day', CAST(ONZOT."1ST_GI_DATE" AS DATE), CURRENT_DATE) AS "LT_CAL_GI_IOD" 
    , (CASE WHEN DS.SUBSIDIARY = 'SEDA' AND (ONZOT.SPI = 'CR02' OR ONZOT.SPI = 'AGS1') 
            THEN COALESCE(DATEDIFF('day', CAST(ONZOT.PLANNED_GI AS DATE), CAST(ONZOT.DELIVERY_DATE AS DATE)), 0)
            ELSE COALESCE(DATEDIFF('day', CAST(ONZOT.PLANNED_GI AS DATE), CAST(ONZOT.RDD_SO_ITEM AS DATE)), 0)
       END) AS "TGT_CAL_GI_IOD"
    , CASE 
        WHEN ((DATEDIFF('day', CAST(ONZOT."1ST_GI_DATE" AS DATE), CURRENT_DATE))
              - /*DLTW.LEAD_TIME_GI_IOD*/
              (CASE WHEN DS.SUBSIDIARY = 'SEDA' AND (ONZOT.SPI = 'CR02' OR ONZOT.SPI = 'AGS1') 
                    THEN COALESCE(DATEDIFF('day', CAST(ONZOT.PLANNED_GI AS DATE), CAST(ONZOT.DELIVERY_DATE AS DATE)), 0)
                    ELSE COALESCE(DATEDIFF('day', CAST(ONZOT.PLANNED_GI AS DATE), CAST(ONZOT.RDD_SO_ITEM AS DATE)), 0)
               END)
             ) <= 0 
         THEN 0 
         ELSE ((DATEDIFF('day', CAST(ONZOT."1ST_GI_DATE" AS DATE), CURRENT_DATE))
               - /*DLTW.LEAD_TIME_GI_IOD*/
               (CASE WHEN DS.SUBSIDIARY = 'SEDA' AND (ONZOT.SPI = 'CR02' OR ONZOT.SPI = 'AGS1') 
                     THEN COALESCE(DATEDIFF('day', CAST(ONZOT.PLANNED_GI AS DATE), CAST(ONZOT.DELIVERY_DATE AS DATE)), 0)
                     ELSE COALESCE(DATEDIFF('day', CAST(ONZOT.PLANNED_GI AS DATE), CAST(ONZOT.RDD_SO_ITEM AS DATE)), 0)
                END)               
             ) 
       END AS LEAD_TIME_CAL_VS_TARGET_LEAD_TIME_CAL
    , ONZOT.DELIVERY_QTY AS ORDER_QTY 
    , NULL AS LAST_UPDATE
  FROM OW_LAO.ODS_NERP_ZLLEJ50090_OUTBOUND_TRACKING ONZOT
  LEFT JOIN OW_LAO.ODS_NERP_ZRSDD6A120_SALES_ORDER_TRACKING ONZASOT 
    ON (ONZOT.REFERENCE_DOC_SO_PO = ONZASOT.SALES_DOCUMENT AND ONZOT.MATERIAL = ONZASOT.MATERIAL 
        AND ONZOT.DELIVERY_ITEM = ONZASOT.DELIVERY_ITEM AND ONZOT.DELIVERY_NO = ONZASOT.DELIVERY)
  --LEFT JOIN OW_MD.DIM_LEAD_TIME_UF DLTU ON (ONZOT.REGION = DLTU.DESTINATION)
  LEFT JOIN OW_MD.DIM_SUBSIDIARY DS ON ONZOT.SALES_ORG = DS.SALES_ORG
  LEFT JOIN OW_MD.DIM_PLANT DP2 ON (ONZOT.PLANT = DP2.PLANT_CODE) 
  --LEFT JOIN OW_MD.DIM_LEAD_TIME_WH DLTW ON (DP2.ORIGIN = DLTW."FROM" AND ONZOT.REGION = DLTW."TO")
  LEFT JOIN OW_MD.DIM_PRODUCT DP ON (ONZOT.MATERIAL = DP.SKU) 
  --LEFT JOIN OW_MD.DIM_TARGET_LEAD_TIME_WORKING_DAY DTLTWD ON (DS.SUBSIDIARY = DTLTWD.SUBSIDIARY)
  WHERE ONZOT."1ST_GI_DATE" IS NOT NULL 
    AND (ONZOT.EPOD_DATE IS NULL AND ONZOT."2ND_GI_DATE" IS NULL)
    AND ONZOT.SO_TYPE = 'YS10' -- AND ONZASOT.SALES_DOC_TYPE = 'YS10'
    AND ONZOT.DO_TYPE = 'ZND1'
    -- AND ONZOT.SHIPPING_TYPE  IN ('P3','P4')
    AND ONZASOT.REJECT_REASON IS NULL 
    -- AND ONZOT.DELIVERY_NO NOT IN (SELECT REFERENCE_NO FROM OW_LAO.ODS_NERP_ZLLEB57910_CLAIM_FOLDER WHERE REFERENCE_NO IS NOT NULL)
    AND ONZOT.DELIVERY_NO NOT IN (SELECT DELIVERY_NO FROM OW_LAO.ODS_NERP_ZLLEB57910_CLAIM_FOLDER WHERE DELIVERY_NO IS NOT NULL) 
    AND ONZASOT.REJECT_REASON_1 IS NULL 
  ;

  -- Update to set the load timestamp (avoid milliseconds issues)
  PERFORM UPDATE OW_LAO.FT_D2C_NERP_DELIVERY_PENDING
     SET LAST_UPDATE = NOW()
   WHERE LAST_UPDATE IS NULL;
END
$$;

-- CALL OW_LAO.PROC_D2C_NERP_DELIVERY_PENDING();
-- ERROR: Severity: ERROR, Message: Relation "OW_MD.DIM_PLANT" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_D2C_NERP_DELIVERY_PENDING line 7 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
-- CALL OW_LAO.PROC_D2C_NERP_DELIVERY_PENDING();
-- ERROR: Severity: ERROR, Message: Relation "OW_MD.DIM_PLANT" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_D2C_NERP_DELIVERY_PENDING line 7 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
