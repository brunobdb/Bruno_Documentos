-- SELECT * FROM SERIES_GENERATE_INTEGER(1,1,5) LIMIT 3;
-- ERROR: Severity: ERROR, Message: Function SERIES_GENERATE_INTEGER(int, int, int) does not exist, or permission is denied for SERIES_GENERATE_INTEGER(int, int, int), Sqlstate: 42883, Hint: No function matches the given name and argument types. You may need to add explicit type casts, Routine: throwErrorFunctionDoesNotMatch, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/ParseFunc.cpp, Line: 4559, Error Code: 3457, 
-- SELECT * FROM GENERATE_SERIES(1, 5) AS t(n);
-- ERROR: Severity: ERROR, Message: Function GENERATE_SERIES(int, int) does not exist, or permission is denied for GENERATE_SERIES(int, int), Sqlstate: 42883, Hint: No function matches the given name and argument types. You may need to add explicit type casts, Routine: throwErrorFunctionDoesNotMatch, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/ParseFunc.cpp, Line: 4559, Error Code: 3457, 
CREATE OR REPLACE PROCEDURE OW_LAO.PROC_FT_NERP_SALES_PROGRESS_KPI()
LANGUAGE PLvSQL AS $$
BEGIN
  
  -- Clean up existing staging/target tables (prefer TRUNCATE over DROP)
  PERFORM TRUNCATE TABLE OW_LAO.AUX_NERP_SALES_PROGRESS_KPI_INTENCTIVE_RULES;
  PERFORM TRUNCATE TABLE OW_LAO.AUX_NERP_SALES_PROGRESS_KPI;
  PERFORM TRUNCATE TABLE OW_LAO.AUX_NERP_SALES_PROGRESS_KPI_TARGET;
  PERFORM TRUNCATE TABLE OW_LAO.TF_AP2_EXCHANGE_RATE_END_OF_MONTH;
  PERFORM TRUNCATE TABLE OW_LAO.TF_NERP_SALES_PROGRESS_KPI;
  PERFORM TRUNCATE TABLE OW_LAO.FT_NERP_SALES_PROGRESS_KPI;
  PERFORM TRUNCATE TABLE OW_LAO.RAW_NERP_ZRCOA20250_FORECAST_SALES_DEDUP;

  -- TMP_SOT_SALES_PROGRESS_KPI as local temp table
  PERFORM CREATE LOCAL TEMPORARY TABLE TMP_SOT_SALES_PROGRESS_KPI ON COMMIT PRESERVE ROWS AS
    SELECT DISTINCT
          CAST(SALES_DOCUMENT AS VARCHAR(70)) AS SALES_DOCUMENT
        , MATERIAL 
        , SO_LOCAL_CREATE_ON_D
        , SALES_ORG
    FROM OW_LAO.ODS_NERP_ZRSDD6A120_SALES_ORDER_TRACKING
    WHERE SALES_ORG = '8201';

  -- Insert CUSTOMER_PO
  PERFORM INSERT INTO TMP_SOT_SALES_PROGRESS_KPI(
        SALES_DOCUMENT, MATERIAL, SO_LOCAL_CREATE_ON_D, SALES_ORG)
    SELECT DISTINCT
           CAST(O.CUSTOMER_PO AS VARCHAR(70)) AS SALES_DOCUMENT
         , O.MATERIAL 
         , O.SO_LOCAL_CREATE_ON_D
         , O.SALES_ORG
      FROM OW_LAO.ODS_NERP_ZRSDD6A120_SALES_ORDER_TRACKING O
      LEFT JOIN TMP_SOT_SALES_PROGRESS_KPI S ON CAST(O.CUSTOMER_PO AS VARCHAR(70)) = S.SALES_DOCUMENT
     WHERE O.SALES_ORG = '8201'
       AND O.CUSTOMER_PO IS NOT NULL
       AND S.SALES_DOCUMENT IS NULL;

  -- Insert from OUTBOUND_TRACKING
  PERFORM INSERT INTO TMP_SOT_SALES_PROGRESS_KPI(
        SALES_DOCUMENT, MATERIAL, SO_LOCAL_CREATE_ON_D, SALES_ORG)
    SELECT DISTINCT
           CAST(O.REFERENCE_DOC_SO_PO AS VARCHAR(70)) AS SALES_DOCUMENT
         , O.MATERIAL
         , O.SO_CREATED_ON
         , O.SALES_ORG
      FROM OW_LAO.ODS_NERP_ZLLEJ50090_OUTBOUND_TRACKING O
      LEFT JOIN TMP_SOT_SALES_PROGRESS_KPI S ON CAST(O.REFERENCE_DOC_SO_PO AS VARCHAR(70)) = S.SALES_DOCUMENT
     WHERE O.SALES_ORG = '8201'
       AND O.REFERENCE_DOC_SO_PO IS NOT NULL
       AND S.SALES_DOCUMENT IS NULL;

  -- RAW_NERP_ZRCOA20250_FORECAST_SALES_DEDUP
  PERFORM INSERT INTO OW_LAO.RAW_NERP_ZRCOA20250_FORECAST_SALES_DEDUP(
        YEAR, MONTH, SALES_ORGANIZATION, SUBSIDIARY, PRODUCT_NUMBER, CUSTOMER, CURRENCY,
        QUANTITY_NET, NET_SALES)
  SELECT
        SUBSTR(FCT.PERIOD,1,4) AS YEAR
      , SUBSTR(FCT.PERIOD,5,2) AS MONTH
      , FCT.SALES_ORGANIZATION
      , SUB.SUBSIDIARY
      , FCT.PRODUCT_NUMBER AS PRODUCT_NUMBER
      , FCT.CUSTOMER AS CUSTOMER
      , FCT.CURRENCY AS CURRENCY
      , SUM(FCT.QUANTITY_NET) AS QUANTITY_NET
      , SUM(FCT.NET_SALES) AS NET_SALES
    FROM OW_LAO.RAW_NERP_ZRCOA20250_FORECAST_SALES FCT
    INNER JOIN OW_MD.DIM_SUBSIDIARY SUB
            ON FCT.SALES_ORGANIZATION = SUB.SALES_ORG
           AND SUB.SUBSIDIARY = 'SEDA'
    INNER JOIN (
        SELECT 
              SUBSTR(F.PERIOD,1,4) AS YEAR
            , SUBSTR(F.PERIOD,5,2) AS MONTH
            , S.SUBSIDIARY
            , MAX(TO_DATE(REGEXP_SUBSTR(F.FILE_NAME,'[0-9]{8}'),'YYYYMMDD')) AS FILE_NAME_DATE
          FROM OW_LAO.RAW_NERP_ZRCOA20250_FORECAST_SALES F
          INNER JOIN OW_MD.DIM_SUBSIDIARY S ON F.SALES_ORGANIZATION = S.SALES_ORG
         WHERE S.SUBSIDIARY = 'SEDA'
         GROUP BY SUBSTR(F.PERIOD,1,4), SUBSTR(F.PERIOD,5,2), S.SUBSIDIARY
    ) LF
      ON LF.FILE_NAME_DATE = TO_DATE(REGEXP_SUBSTR(FCT.FILE_NAME,'[0-9]{8}'),'YYYYMMDD')
     AND LF.YEAR  = SUBSTR(FCT.PERIOD,1,4)
     AND LF.MONTH = SUBSTR(FCT.PERIOD,5,2)
     AND LF.SUBSIDIARY = SUB.SUBSIDIARY
   WHERE FCT.CUSTOMER IN (
         SELECT DISTINCT CAST(SOLD_TO_PARTY AS VARCHAR(50))
           FROM OW_LAO.DIM_SOLD_TO 
          WHERE SUBSIDIARY = 'SEDA')
   GROUP BY SUBSTR(FCT.PERIOD,1,4), SUBSTR(FCT.PERIOD,5,2), SUB.SUBSIDIARY,
            FCT.SALES_ORGANIZATION, FCT.PRODUCT_NUMBER, FCT.CUSTOMER, FCT.CURRENCY;

  -- AUX_NERP_SALES_PROGRESS_KPI_INTENCTIVE_RULES
  PERFORM INSERT INTO OW_LAO.AUX_NERP_SALES_PROGRESS_KPI_INTENCTIVE_RULES(
        SUBSIDIARY, MONTH, YEAR, REFERENCIA, PLANT, TRANSPORT_ZONE_DESTINATION, ITEM_DIVISION,
        DIMPROD_DIVISION, DIMPROD_PRODUCT_GROUP, DIMPROD_SEDA_BU_ESTORE, DIMPROD_SEDA_DIVISION_ESTORE,
        DIMPROD_SEDA_CATEGORY_ESTORE,
        So_Progress_Quantity, So_Progress_Amount, So_Progress_Next_Month_Quantity, So_Progress_Next_Month_Amount,
        Do_Progress_Quantity, Do_Progress_Amount, GI_Progress_Quantity, GI_Progress_Amount,
        In_Transit_Quantity, In_Transit_Amount, billing_IOD_Progress_Quantity, billing_IOD_Progress_Amount,
        billingIODProgressPreviousQuantity, billingIODProgressPreviousAmount,
        InTransitNetTotalQuantity, InTransitNetTotalAmount,
        ForecastQuantity, ForecastAmount, InTransitNextMonthQuantity, InTransitNextMonthAmount)
  SELECT subsidiary, month, year, referencia, plant, transport_zone_destination, item_division,
         dimprod_division, dimprod_product_group, dimprod_seda_bu_estore, dimprod_seda_division_estore,
         dimprod_seda_category_estore,
         SUM(SoProgressQuantity), SUM(SoProgressAmount), SUM(So_Progress_Next_Month_Quantity), SUM(So_Progress_Next_Month_Amount),
         SUM(DoProgressQuantity), SUM(DoProgressAmount), SUM(GIProgressQuantity), SUM(GIProgressAmount),
         SUM(InTransitQuantity), SUM(InTransitAmount), SUM(billingIODProgressQuantity), SUM(billingIODProgressAmount),
         SUM(billingIODProgressPreviousQuantity), SUM(billingIODProgressPreviousAmount),
         SUM(InTransitNetTotalQuantity), SUM(InTransitNetTotalAmount),
         SUM(ForecastQuantity), SUM(ForecastAmount), SUM(InTransitNextMonthQuantity), SUM(InTransitNextMonthAmount)
    FROM (
      SELECT b.subsidiary AS subsidiary
           , MONTH(a.SO_LOCAL_CREATE_ON_D) AS month
           , YEAR(a.SO_LOCAL_CREATE_ON_D)  AS year
           , TO_CHAR(a.SO_LOCAL_CREATE_ON_D, 'YYYYMM') AS referencia
           , a.plant AS plant
           , SUBSTR(transport_zone, 3, 2) AS transport_zone_destination
           , a.item_division AS item_division
           , z.division AS dimprod_division
           , z.product_group_1 AS dimprod_product_group
           , z.seda_bu_estore AS dimprod_seda_bu_estore
           , z.seda_division_estore AS dimprod_seda_division_estore
           , z.seda_category_estore AS dimprod_seda_category_estore
           , SUM(CAST(a.ORDER_QTY_BASE AS INT)) AS SoProgressQuantity
           , SUM(CAST(REPLACE(a.SO_NET_VALUE, ',' ,'') AS DECIMAL(15,2))) AS SoProgressAmount
           , CAST(0 AS INT) AS So_Progress_Next_Month_Quantity
           , CAST(0.00 AS DECIMAL(15,2)) AS So_Progress_Next_Month_Amount
           , 0 AS DoProgressQuantity
           , 0 AS DoProgressAmount
           , 0 AS GIProgressQuantity
           , 0 AS GIProgressAmount
           , 0 AS InTransitQuantity
           , 0 AS InTransitAmount
           , 0 AS billingIODProgressQuantity
           , 0 AS billingIODProgressAmount
           , 0 AS billingIODProgressPreviousQuantity
           , 0 AS billingIODProgressPreviousAmount
           , 0 AS InTransitNetTotalQuantity
           , 0 AS InTransitNetTotalAmount
           , 0 AS ForecastQuantity
           , 0 AS ForecastAmount
           , CAST(0 AS INT) AS InTransitNextMonthQuantity
           , CAST(0 AS DECIMAL(15,2)) AS InTransitNextMonthAmount
        FROM OW_LAO.ODS_NERP_ZRSDD6A120_SALES_ORDER_TRACKING a
        JOIN OW_MD.DIM_SUBSIDIARY b ON b.sales_org = a.sales_org
        LEFT JOIN OW_MD.DIM_PRODUCT z ON z.sku = a.material
       WHERE b.sur_key_subsidiary = 1
         AND CAST(a.SO_LOCAL_CREATE_ON_D AS DATE) >= DATE '2023-04-01'
         AND a.REJECT_REASON IS NULL
         AND a.REJECT_REASON_1 IS NULL
         AND CAST(a.ORDER_QTY_BASE AS INT) >= 0
         AND CAST(REPLACE(a.SO_NET_VALUE, ',' ,'') AS DECIMAL(15,2)) >= 0
       GROUP BY b.subsidiary, MONTH(a.SO_LOCAL_CREATE_ON_D), YEAR(a.SO_LOCAL_CREATE_ON_D), TO_CHAR(a.SO_LOCAL_CREATE_ON_D,'YYYYMM'),
                a.plant, SUBSTR(transport_zone,3,2), a.item_division, z.division, z.product_group_1,
                z.seda_bu_estore, z.seda_division_estore, z.seda_category_estore

      UNION ALL

      SELECT b.subsidiary AS subsidiary
           , MONTH(a.SO_LOCAL_CREATE_ON_D) AS month
           , YEAR(a.SO_LOCAL_CREATE_ON_D)  AS year
           , TO_CHAR(a.SO_LOCAL_CREATE_ON_D, 'YYYYMM') AS referencia
           , a.plant AS plant
           , SUBSTR(transport_zone, 3, 2) AS transport_zone_destination
           , a.item_division AS item_division
           , z.division AS dimprod_division
           , z.product_group_1 AS dimprod_product_group
           , z.seda_bu_estore AS dimprod_seda_bu_estore
           , z.seda_division_estore AS dimprod_seda_division_estore
           , z.seda_category_estore AS dimprod_seda_category_estore
           , 0 AS SoProgressQuantity
           , 0 AS SoProgressAmount
           , CAST(0 AS INT) AS So_Progress_Next_Month_Quantity
           , CAST(0.00 AS DECIMAL(15,2)) AS So_Progress_Next_Month_Amount
           , SUM(CAST(a.ORDER_QTY_BASE AS INT)) AS DoProgressQuantity
           , SUM(CAST(REPLACE(a.SO_NET_VALUE, ',' ,'') AS DECIMAL(15,2))) AS DoProgressAmount
           , 0 AS GIProgressQuantity
           , 0 AS GIProgressAmount
           , 0 AS InTransitQuantity
           , 0 AS InTransitAmount
           , 0 AS billingIODProgressQuantity
           , 0 AS billingIODProgressAmount
           , 0 AS billingIODProgressPreviousQuantity
           , 0 AS billingIODProgressPreviousAmount
           , 0 AS InTransitNetTotalQuantity
           , 0 AS InTransitNetTotalAmount
           , 0 AS ForecastQuantity
           , 0 AS ForecastAmount
           , CAST(0 AS INT) AS InTransitNextMonthQuantity
           , CAST(0 AS DECIMAL(15,2)) AS InTransitNextMonthAmount
        FROM OW_LAO.ODS_NERP_ZRSDD6A120_SALES_ORDER_TRACKING a
        JOIN OW_MD.DIM_SUBSIDIARY b ON b.sales_org = a.sales_org
        LEFT JOIN OW_MD.DIM_PRODUCT z ON z.sku = a.material
       WHERE b.sur_key_subsidiary = 1
         AND CAST(a.SO_LOCAL_CREATE_ON_D AS DATE) >= DATE '2023-04-01'
         AND a.REJECT_REASON IS NULL
         AND a.REJECT_REASON_1 IS NULL
         AND a.DO_LOCAL_CREATE_ON_D IS NOT NULL
         AND CAST(a.ORDER_QTY_BASE AS INT) >= 0
         AND CAST(REPLACE(a.SO_NET_VALUE, ',' ,'') AS DECIMAL(15,2)) >= 0
       GROUP BY b.subsidiary, MONTH(a.SO_LOCAL_CREATE_ON_D), YEAR(a.SO_LOCAL_CREATE_ON_D), TO_CHAR(a.SO_LOCAL_CREATE_ON_D,'YYYYMM'),
                a.plant, SUBSTR(transport_zone,3,2), a.item_division, z.division, z.product_group_1,
                z.seda_bu_estore, z.seda_division_estore, z.seda_category_estore

      UNION ALL

      SELECT b.subsidiary AS subsidiary
           , MONTH(a.SO_LOCAL_CREATE_ON_D) AS month
           , YEAR(a.SO_LOCAL_CREATE_ON_D)  AS year
           , TO_CHAR(a.SO_LOCAL_CREATE_ON_D, 'YYYYMM') AS referencia
           , a.plant AS plant
           , SUBSTR(transport_zone, 3, 2) AS transport_zone_destination
           , a.item_division AS item_division
           , z.division AS dimprod_division
           , z.product_group_1 AS dimprod_product_group
           , z.seda_bu_estore AS dimprod_seda_bu_estore
           , z.seda_division_estore AS dimprod_seda_division_estore
           , z.seda_category_estore AS dimprod_seda_category_estore
           , 0 AS SoProgressQuantity
           , 0 AS SoProgressAmount
           , CAST(0 AS INT) AS So_Progress_Next_Month_Quantity
           , CAST(0.00 AS DECIMAL(15,2)) AS So_Progress_Next_Month_Amount
           , 0 AS DOProgressQuantity
           , 0 AS DOProgressAmount
           , SUM(CAST(a.ORDER_QTY_BASE AS INT)) AS GIProgressQuantity
           , SUM(CAST(REPLACE(a.SO_NET_VALUE, ',' ,'') AS DECIMAL(15,2))) AS GIProgressAmount
           , 0 AS InTransitQuantity
           , 0 AS InTransitAmount
           , 0 AS billingIODProgressQuantity
           , 0 AS billingIODProgressAmount
           , 0 AS billingIODProgressPreviousQuantity
           , 0 AS billingIODProgressPreviousAmount
           , 0 AS InTransitNetTotalQuantity
           , 0 AS InTransitNetTotalAmount
           , 0 AS ForecastQuantity
           , 0 AS ForecastAmount
           , CAST(0 AS INT) AS InTransitNextMonthQuantity
           , CAST(0 AS DECIMAL(15,2)) AS InTransitNextMonthAmount
        FROM OW_LAO.ODS_NERP_ZRSDD6A120_SALES_ORDER_TRACKING a
        JOIN OW_MD.DIM_SUBSIDIARY b ON b.sales_org = a.sales_org
        LEFT JOIN OW_MD.DIM_PRODUCT z ON z.sku = a.material
       WHERE b.sur_key_subsidiary = 1
         AND CAST(a.SO_LOCAL_CREATE_ON_D AS DATE) >= DATE '2023-04-01'
         AND a.REJECT_REASON IS NULL
         AND a.REJECT_REASON_1 IS NULL
         AND a."1ST_GI_LOCAL_CREATE" IS NOT NULL
         AND CAST(a.ORDER_QTY_BASE AS INT) >= 0
         AND CAST(REPLACE(a.SO_NET_VALUE, ',' ,'') AS DECIMAL(15,2)) >= 0
       GROUP BY b.subsidiary, MONTH(a.SO_LOCAL_CREATE_ON_D), YEAR(a.SO_LOCAL_CREATE_ON_D), TO_CHAR(a.SO_LOCAL_CREATE_ON_D,'YYYYMM'),
                a.plant, SUBSTR(transport_zone,3,2), a.item_division, z.division, z.product_group_1,
                z.seda_bu_estore, z.seda_division_estore, z.seda_category_estore

      UNION ALL

      SELECT b.subsidiary AS subsidiary
           , MONTH(a.SO_LOCAL_CREATE_ON_D) AS month
           , YEAR(a.SO_LOCAL_CREATE_ON_D)  AS year
           , TO_CHAR(a.SO_LOCAL_CREATE_ON_D, 'YYYYMM') AS referencia
           , a.plant AS plant
           , SUBSTR(transport_zone, 3, 2) AS transport_zone_destination
           , a.item_division AS item_division
           , z.division AS dimprod_division
           , z.product_group_1 AS dimprod_product_group
           , z.seda_bu_estore AS dimprod_seda_bu_estore
           , z.seda_division_estore AS dimprod_seda_division_estore
           , z.seda_category_estore AS dimprod_seda_category_estore
           , 0 AS SoProgressQuantity
           , 0 AS SoProgressAmount
           , CAST(0 AS INT) AS So_Progress_Next_Month_Quantity
           , CAST(0.00 AS DECIMAL(15,2)) AS So_Progress_Next_Month_Amount
           , 0 AS DoProgressQuantity
           , 0 AS DoProgressAmount
           , 0 AS GIProgressQuantity
           , 0 AS GIProgressAmount
           , SUM(CAST(a.ORDER_QTY_BASE AS INT)) AS InTransitQuantity
           , SUM(CAST(REPLACE(a.SO_NET_VALUE, ',' ,'') AS DECIMAL(15,2))) AS InTransitAmount
           , 0 AS billingIODProgressQuantity
           , 0 AS billingIODProgressAmount
           , 0 AS billingIODProgressPreviousQuantity
           , 0 AS billingIODProgressPreviousAmount
           , 0 AS InTransitNetTotalQuantity
           , 0 AS InTransitNetTotalAmount
           , 0 AS ForecastQuantity
           , 0 AS ForecastAmount
           , CAST(0 AS INT) AS InTransitNextMonthQuantity
           , CAST(0 AS DECIMAL(15,2)) AS InTransitNextMonthAmount
        FROM OW_LAO.ODS_NERP_ZRSDD6A120_SALES_ORDER_TRACKING a
        JOIN OW_MD.DIM_SUBSIDIARY b ON b.sales_org = a.sales_org
        LEFT JOIN OW_MD.DIM_PRODUCT z ON z.sku = a.material
       WHERE b.sur_key_subsidiary = 1
         AND CAST(a.SO_LOCAL_CREATE_ON_D AS DATE) >= DATE '2023-04-01'
         AND a.REJECT_REASON IS NULL
         AND a.REJECT_REASON_1 IS NULL
         AND a.BILLING_LOCAL_CREATE IS NULL
         AND a."1ST_GI_LOCAL_CREATE" IS NOT NULL
         AND CAST(a.ORDER_QTY_BASE AS INT) >= 0
         AND CAST(REPLACE(a.SO_NET_VALUE, ',' ,'') AS DECIMAL(15,2)) >= 0
         AND LAST_DAY(a.SO_LOCAL_CREATE_ON_D) = LAST_DAY(
               COALESCE(CAST(billing_create_on AS DATE), CAST(final_sch_date AS DATE), CAST(first_sc_date AS DATE)))
       GROUP BY b.subsidiary, MONTH(a.SO_LOCAL_CREATE_ON_D), YEAR(a.SO_LOCAL_CREATE_ON_D), TO_CHAR(a.SO_LOCAL_CREATE_ON_D,'YYYYMM'),
                a.plant, SUBSTR(transport_zone,3,2), a.item_division, z.division, z.product_group_1,
                z.seda_bu_estore, z.seda_division_estore, z.seda_category_estore

      UNION ALL

      SELECT b.subsidiary AS subsidiary
           , MONTH(a.SO_LOCAL_CREATE_ON_D) AS month
           , YEAR(a.SO_LOCAL_CREATE_ON_D)  AS year
           , TO_CHAR(a.SO_LOCAL_CREATE_ON_D, 'YYYYMM') AS referencia
           , a.plant AS plant
           , SUBSTR(transport_zone, 3, 2) AS transport_zone_destination
           , a.item_division AS item_division
           , z.division AS dimprod_division
           , z.product_group_1 AS dimprod_product_group
           , z.seda_bu_estore AS dimprod_seda_bu_estore
           , z.seda_division_estore AS dimprod_seda_division_estore
           , z.seda_category_estore AS dimprod_seda_category_estore
           , 0 AS SoProgressQuantity
           , 0 AS SoProgressAmount
           , CAST(0 AS INT) AS So_Progress_Next_Month_Quantity
           , CAST(0.00 AS DECIMAL(15,2)) AS So_Progress_Next_Month_Amount
           , 0 AS DoProgressQuantity
           , 0 AS DoProgressAmount
           , 0 AS GIProgressQuantity
           , 0 AS GIProgressAmount
           , 0 AS InTransitQuantity
           , 0 AS InTransitAmount
           , 0 AS billingIODProgressQuantity
           , 0 AS billingIODProgressAmount
           , 0 AS billingIODProgressPreviousQuantity
           , 0 AS billingIODProgressPreviousAmount
           , SUM(CAST(a.ORDER_QTY_BASE AS INT)) AS InTransitNetTotalQuantity
           , SUM(CAST(REPLACE(a.SO_NET_VALUE, ',' ,'') AS DECIMAL(15,2))) AS InTransitNetTotalAmount
           , 0 AS ForecastQuantity
           , 0 AS ForecastAmount
           , CAST(0 AS INT) AS InTransitNextMonthQuantity
           , CAST(0 AS DECIMAL(15,2)) AS InTransitNextMonthAmount
        FROM OW_LAO.ODS_NERP_ZRSDD6A120_SALES_ORDER_TRACKING a
        JOIN OW_MD.DIM_SUBSIDIARY b ON b.sales_org = a.sales_org
        LEFT JOIN OW_MD.DIM_PRODUCT z ON z.sku = a.material
       WHERE b.sur_key_subsidiary = 1
         AND CAST(a.SO_LOCAL_CREATE_ON_D AS DATE) >= DATE '2023-04-01'
         AND a.REJECT_REASON IS NULL
         AND a.REJECT_REASON_1 IS NULL
         AND a.BILLING_LOCAL_CREATE IS NULL
         AND a."1ST_GI_LOCAL_CREATE" IS NOT NULL
         AND CAST(a.ORDER_QTY_BASE AS INT) >= 0
         AND CAST(REPLACE(a.SO_NET_VALUE, ',' ,'') AS DECIMAL(15,2)) >= 0
       GROUP BY b.subsidiary, MONTH(a.SO_LOCAL_CREATE_ON_D), YEAR(a.SO_LOCAL_CREATE_ON_D), TO_CHAR(a.SO_LOCAL_CREATE_ON_D,'YYYYMM'),
                a.plant, SUBSTR(transport_zone,3,2), a.item_division, z.division, z.product_group_1,
                z.seda_bu_estore, z.seda_division_estore, z.seda_category_estore

      UNION ALL

      SELECT b.subsidiary AS subsidiary
           , MONTH(a.SO_LOCAL_CREATE_ON_D) AS month
           , YEAR(a.SO_LOCAL_CREATE_ON_D)  AS year
           , TO_CHAR(a.SO_LOCAL_CREATE_ON_D, 'YYYYMM') AS referencia
           , a.plant AS plant
           , SUBSTR(transport_zone, 3, 2) AS transport_zone_destination
           , a.item_division AS item_division
           , z.division AS dimprod_division
           , z.product_group_1 AS dimprod_product_group
           , z.seda_bu_estore AS dimprod_seda_bu_estore
           , z.seda_division_estore AS dimprod_seda_division_estore
           , z.seda_category_estore AS dimprod_seda_category_estore
           , 0 AS SoProgressQuantity
           , 0 AS SoProgressAmount
           , SUM(CAST(a.ORDER_QTY_BASE AS INT)) AS So_Progress_Next_Month_Quantity
           , SUM(CAST(REPLACE(a.SO_NET_VALUE, ',' ,'') AS DECIMAL(15,2))) AS So_Progress_Next_Month_Amount
           , 0 AS DoProgressQuantity
           , 0 AS DoProgressAmount
           , 0 AS GIProgressQuantity
           , 0 AS GIProgressAmount
           , 0 AS InTransitQuantity
           , 0 AS InTransitAmount
           , 0 AS billingIODProgressQuantity
           , 0 AS billingIODProgressAmount
           , 0 AS billingIODProgressPreviousQuantity
           , 0 AS billingIODProgressPreviousAmount
           , 0 AS InTransitNetTotalQuantity
           , 0 AS InTransitNetTotalAmount
           , 0 AS ForecastQuantity
           , 0 AS ForecastAmount
           , CAST(0 AS INT) AS InTransitNextMonthQuantity
           , CAST(0 AS DECIMAL(15,2)) AS InTransitNextMonthAmount
        FROM OW_LAO.ODS_NERP_ZRSDD6A120_SALES_ORDER_TRACKING a
        JOIN OW_MD.DIM_SUBSIDIARY b ON b.sales_org = a.sales_org
        LEFT JOIN OW_MD.DIM_PRODUCT z ON z.sku = a.material
       WHERE b.sur_key_subsidiary = 1
         AND CAST(a.SO_LOCAL_CREATE_ON_D AS DATE) >= DATE '2023-04-01'
         AND a.REJECT_REASON IS NULL
         AND a.REJECT_REASON_1 IS NULL
         AND CAST(a.ORDER_QTY_BASE AS INT) >= 0
         AND CAST(REPLACE(a.SO_NET_VALUE, ',' ,'') AS DECIMAL(15,2)) >= 0
         AND LAST_DAY(ADD_MONTHS(a.SO_LOCAL_CREATE_ON_D, 1)) = LAST_DAY(
               COALESCE(CAST(billing_create_on AS DATE), CAST(final_sch_date AS DATE), CAST(first_sc_date AS DATE)))
       GROUP BY b.subsidiary, MONTH(a.SO_LOCAL_CREATE_ON_D), YEAR(a.SO_LOCAL_CREATE_ON_D), TO_CHAR(a.SO_LOCAL_CREATE_ON_D,'YYYYMM'),
                a.plant, SUBSTR(transport_zone,3,2), a.item_division, z.division, z.product_group_1,
                z.seda_bu_estore, z.seda_division_estore, z.seda_category_estore

      UNION ALL

      SELECT b.subsidiary AS subsidiary
           , MONTH(a.SO_LOCAL_CREATE_ON_D) AS month
           , YEAR(a.SO_LOCAL_CREATE_ON_D)  AS year
           , TO_CHAR(a.SO_LOCAL_CREATE_ON_D, 'YYYYMM') AS referencia
           , a.plant AS plant
           , SUBSTR(transport_zone, 3, 2) AS transport_zone_destination
           , a.item_division AS item_division
           , z.division AS dimprod_division
           , z.product_group_1 AS dimprod_product_group
           , z.seda_bu_estore AS dimprod_seda_bu_estore
           , z.seda_division_estore AS dimprod_seda_division_estore
           , z.seda_category_estore AS dimprod_seda_category_estore
           , 0 AS SoProgressQuantity
           , 0 AS SoProgressAmount
           , CAST(0 AS INT) AS So_Progress_Next_Month_Quantity
           , CAST(0.00 AS DECIMAL(15,2)) AS So_Progress_Next_Month_Amount
           , 0 AS DoProgressQuantity
           , 0 AS DoProgressAmount
           , 0 AS GIProgressQuantity
           , 0 AS GIProgressAmount
           , 0 AS InTransitQuantity
           , 0 AS InTransitAmount
           , 0 AS billingIODProgressQuantity
           , 0 AS billingIODProgressAmount
           , 0 AS billingIODProgressPreviousQuantity
           , 0 AS billingIODProgressPreviousAmount
           , 0 AS InTransitNetTotalQuantity
           , 0 AS InTransitNetTotalAmount
           , 0 AS ForecastQuantity
           , 0 AS ForecastAmount
           , SUM(CAST(a.ORDER_QTY_BASE AS INT)) AS InTransitNextMonthQuantity
           , SUM(CAST(REPLACE(a.SO_NET_VALUE, ',' ,'') AS DECIMAL(15,2))) AS InTransitNextMonthAmount
        FROM OW_LAO.ODS_NERP_ZRSDD6A120_SALES_ORDER_TRACKING a
        JOIN OW_MD.DIM_SUBSIDIARY b ON b.sales_org = a.sales_org
        LEFT JOIN OW_MD.DIM_PRODUCT z ON z.sku = a.material
       WHERE b.sur_key_subsidiary = 1
         AND CAST(a.SO_LOCAL_CREATE_ON_D AS DATE) >= DATE '2023-04-01'
         AND a.REJECT_REASON IS NULL
         AND a.REJECT_REASON_1 IS NULL
         AND a.BILLING_LOCAL_CREATE IS NULL
         AND a."1ST_GI_LOCAL_CREATE" IS NOT NULL
         AND CAST(a.ORDER_QTY_BASE AS INT) >= 0
         AND CAST(REPLACE(a.SO_NET_VALUE, ',' ,'') AS DECIMAL(15,2)) >= 0
         AND LAST_DAY(ADD_MONTHS(a.SO_LOCAL_CREATE_ON_D, 1)) = LAST_DAY(
               COALESCE(CAST(billing_create_on AS DATE), CAST(final_sch_date AS DATE), CAST(first_sc_date AS DATE)))
       GROUP BY b.subsidiary, MONTH(a.SO_LOCAL_CREATE_ON_D), YEAR(a.SO_LOCAL_CREATE_ON_D), TO_CHAR(a.SO_LOCAL_CREATE_ON_D,'YYYYMM'),
                a.plant, SUBSTR(transport_zone,3,2), a.item_division, z.division, z.product_group_1,
                z.seda_bu_estore, z.seda_division_estore, z.seda_category_estore
    ) a
  GROUP BY subsidiary, month, year, referencia, plant, transport_zone_destination, item_division,
           dimprod_division, dimprod_product_group, dimprod_seda_bu_estore, dimprod_seda_division_estore, dimprod_seda_category_estore;

  -- Incentive rule updates
  PERFORM UPDATE OW_LAO.AUX_NERP_SALES_PROGRESS_KPI_INTENCTIVE_RULES a
       SET So_Progress_Amount            = (a.So_Progress_Amount            * b.incentive_total)
         , So_Progress_Next_Month_Amount = (a.So_Progress_Next_Month_Amount * b.incentive_total)
         , Do_Progress_Amount            = (a.Do_Progress_Amount            * b.incentive_total)
         , GI_Progress_Amount            = (a.GI_Progress_Amount            * b.incentive_total)
         , In_Transit_Amount             = (a.In_Transit_Amount             * b.incentive_total)
         , InTransitNetTotalAmount       = (a.InTransitNetTotalAmount       * b.incentive_total)
         , InTransitNextMonthAmount      = (a.InTransitNextMonthAmount      * b.incentive_total)
      FROM OW_LAO."DIM_PLANT_DESTINATION_INCENTIVE" b
     WHERE b.plant = a.plant
       AND b.division = a.item_division
       AND b.division_all = FALSE
       AND b.incentive_to_different_destination = FALSE
       AND a.transport_zone_destination = 'SP'
       AND a.transport_zone_destination IS NOT NULL;

  PERFORM UPDATE OW_LAO.AUX_NERP_SALES_PROGRESS_KPI_INTENCTIVE_RULES a
       SET So_Progress_Amount            = (a.So_Progress_Amount            * b.incentive_total)
         , So_Progress_Next_Month_Amount = (a.So_Progress_Next_Month_Amount * b.incentive_total)
         , Do_Progress_Amount            = (a.Do_Progress_Amount            * b.incentive_total)
         , GI_Progress_Amount            = (a.GI_Progress_Amount            * b.incentive_total)
         , In_Transit_Amount             = (a.In_Transit_Amount             * b.incentive_total)
         , InTransitNetTotalAmount       = (a.InTransitNetTotalAmount       * b.incentive_total)
         , InTransitNextMonthAmount      = (a.InTransitNextMonthAmount      * b.incentive_total)
      FROM OW_LAO."DIM_PLANT_DESTINATION_INCENTIVE" b
     WHERE b.plant = a.plant
       AND b.division = a.item_division
       AND b.division_all = FALSE
       AND b.incentive_to_different_destination = TRUE
       AND a.transport_zone_destination <> 'SP'
       AND a.transport_zone_destination IS NOT NULL;

  PERFORM UPDATE OW_LAO.AUX_NERP_SALES_PROGRESS_KPI_INTENCTIVE_RULES a
       SET So_Progress_Amount            = (a.So_Progress_Amount            * b.incentive_total)
         , So_Progress_Next_Month_Amount = (a.So_Progress_Next_Month_Amount * b.incentive_total)
         , Do_Progress_Amount            = (a.Do_Progress_Amount            * b.incentive_total)
         , GI_Progress_Amount            = (a.GI_Progress_Amount            * b.incentive_total)
         , In_Transit_Amount             = (a.In_Transit_Amount             * b.incentive_total)
         , InTransitNetTotalAmount       = (a.InTransitNetTotalAmount       * b.incentive_total)
         , InTransitNextMonthAmount      = (a.InTransitNextMonthAmount      * b.incentive_total)
      FROM OW_LAO."DIM_PLANT_DESTINATION_INCENTIVE" b
     WHERE b.plant = a.plant
       AND b.division = a.item_division
       AND b.division_all = FALSE
       AND b.incentive_to_all_destination = TRUE
       AND a.transport_zone_destination IS NOT NULL;

  PERFORM UPDATE OW_LAO.AUX_NERP_SALES_PROGRESS_KPI_INTENCTIVE_RULES a
       SET So_Progress_Amount            = (a.So_Progress_Amount            * b.incentive_total)
         , So_Progress_Next_Month_Amount = (a.So_Progress_Next_Month_Amount * b.incentive_total)
         , Do_Progress_Amount            = (a.Do_Progress_Amount            * b.incentive_total)
         , GI_Progress_Amount            = (a.GI_Progress_Amount            * b.incentive_total)
         , In_Transit_Amount             = (a.In_Transit_Amount             * b.incentive_total)
         , InTransitNetTotalAmount       = (a.InTransitNetTotalAmount       * b.incentive_total)
         , InTransitNextMonthAmount      = (a.InTransitNextMonthAmount      * b.incentive_total)
      FROM OW_LAO."DIM_PLANT_DESTINATION_INCENTIVE" b
     WHERE b.plant = a.plant
       AND b.division_all = TRUE
       AND b.incentive_to_all_destination = TRUE
       AND a.transport_zone_destination IS NOT NULL;

  -- AUX_NERP_SALES_PROGRESS_KPI aggregation
  PERFORM INSERT INTO OW_LAO.AUX_NERP_SALES_PROGRESS_KPI(
        subsidiary, month, year, referencia,
        dimprod_division, dimprod_product_group, dimprod_seda_bu_estore, dimprod_seda_division_estore, dimprod_seda_category_estore,
        So_Progress_Quantity, So_Progress_Amount, So_Progress_Next_Month_Quantity, So_Progress_Next_Month_Amount,
        Do_Progress_Quantity, Do_Progress_Amount, GI_Progress_Quantity, GI_Progress_Amount,
        In_Transit_Quantity, In_Transit_Amount,
        billing_IOD_Progress_Quantity, billing_IOD_Progress_Amount,
        billingIODProgressPreviousQuantity, billingIODProgressPreviousAmount,
        InTransitNetTotalQuantity, InTransitNetTotalAmount,
        ForecastQuantity, ForecastAmount,
        InTransitNextMonthQuantity, InTransitNextMonthAmount)
  SELECT subsidiary, month, year, referencia,
         dimprod_division, dimprod_product_group, dimprod_seda_bu_estore, dimprod_seda_division_estore, dimprod_seda_category_estore,
         SUM(So_Progress_Quantity), SUM(So_Progress_Amount), SUM(So_Progress_Next_Month_Quantity), SUM(So_Progress_Next_Month_Amount),
         SUM(Do_Progress_Quantity), SUM(Do_Progress_Amount), SUM(GI_Progress_Quantity), SUM(GI_Progress_Amount),
         SUM(In_Transit_Quantity), SUM(In_Transit_Amount),
         SUM(billing_IOD_Progress_Quantity), SUM(billing_IOD_Progress_Amount),
         SUM(billingIODProgressPreviousQuantity), SUM(billingIODProgressPreviousAmount),
         SUM(InTransitNetTotalQuantity), SUM(InTransitNetTotalAmount),
         SUM(ForecastQuantity), SUM(ForecastAmount),
         SUM(InTransitNextMonthQuantity), SUM(InTransitNextMonthAmount)
    FROM (
      SELECT subsidiary, month, year, referencia,
             dimprod_division, dimprod_product_group, dimprod_seda_bu_estore, dimprod_seda_division_estore, dimprod_seda_category_estore,
             SUM(So_Progress_Quantity) AS So_Progress_Quantity,
             SUM(So_Progress_Amount) AS So_Progress_Amount,
             SUM(So_Progress_Next_Month_Quantity) AS So_Progress_Next_Month_Quantity,
             SUM(So_Progress_Next_Month_Amount) AS So_Progress_Next_Month_Amount,
             SUM(Do_Progress_Quantity) AS Do_Progress_Quantity,
             SUM(Do_Progress_Amount) AS Do_Progress_Amount,
             SUM(GI_Progress_Quantity) AS GI_Progress_Quantity,
             SUM(GI_Progress_Amount) AS GI_Progress_Amount,
             SUM(In_Transit_Quantity) AS In_Transit_Quantity,
             SUM(In_Transit_Amount) AS In_Transit_Amount,
             SUM(billing_IOD_Progress_Quantity) AS billing_IOD_Progress_Quantity,
             SUM(billing_IOD_Progress_Amount) AS billing_IOD_Progress_Amount,
             SUM(billingIODProgressPreviousQuantity) AS billingIODProgressPreviousQuantity,
             SUM(billingIODProgressPreviousAmount) AS billingIODProgressPreviousAmount,
             SUM(InTransitNetTotalQuantity) AS InTransitNetTotalQuantity,
             SUM(InTransitNetTotalAmount) AS InTransitNetTotalAmount,
             0 AS ForecastQuantity,
             0 AS ForecastAmount,
             SUM(InTransitNextMonthQuantity) AS InTransitNextMonthQuantity,
             SUM(InTransitNextMonthAmount) AS InTransitNextMonthAmount
        FROM OW_LAO.AUX_NERP_SALES_PROGRESS_KPI_INTENCTIVE_RULES
       GROUP BY subsidiary, month, year, referencia,
                dimprod_division, dimprod_product_group, dimprod_seda_bu_estore, dimprod_seda_division_estore, dimprod_seda_category_estore

      UNION ALL

      SELECT c.subsidiary,
             a.posting_period AS month,
             a.year AS year,
             CAST(a.year AS VARCHAR(4)) || LPAD(CAST(a.posting_period AS VARCHAR),2,'0') AS referencia,
             z.division AS dimprod_division,
             z.product_group_1 AS dimprod_product_group,
             z.seda_bu_estore AS dimprod_seda_bu_estore,
             z.seda_division_estore AS dimprod_seda_division_estore,
             z.seda_category_estore AS dimprod_seda_category_estore,
             0, 0, CAST(0 AS INT), CAST(0.00 AS DECIMAL(15,2)), 0, 0, 0, 0, 0, 0,
             SUM(a.sales_qty) AS billingIODProgressQuantity,
             SUM(a.amount_company_code_currency) AS billingIODProgressAmount,
             0, 0, 0, 0, 0, 0, CAST(0 AS INT), CAST(0 AS DECIMAL(15,2))
        FROM OW_LAO.ODS_NERP_ZKE24_DISPLAY_ACTUAL_LINE_ITEMS a
        INNER JOIN OW_MD.DIM_SUBSIDIARY c ON c.company_code = a.company_code
        INNER JOIN TMP_SOT_SALES_PROGRESS_KPI b ON b.sales_document = CAST(a.sales_order AS VARCHAR(70))
                                               AND b.material = a.product
                                               AND MONTH(b.SO_LOCAL_CREATE_ON_D) = a.posting_period
                                               AND YEAR(b.SO_LOCAL_CREATE_ON_D)  = a.year
                                               AND c.sales_org = b.sales_org
        LEFT JOIN OW_MD.DIM_PRODUCT z ON z.sku = a.product
       WHERE c.sur_key_subsidiary = 1
       GROUP BY c.subsidiary, a.year, a.posting_period, z.division, z.product_group_1, z.seda_bu_estore, z.seda_division_estore, z.seda_category_estore

      UNION ALL

      SELECT b.subsidiary,
             a.posting_period AS month,
             a.year AS year,
             CAST(a.year AS VARCHAR(4)) || LPAD(CAST(a.posting_period AS VARCHAR),2,'0') AS referencia,
             z.division AS dimprod_division,
             z.product_group_1 AS dimprod_product_group,
             z.seda_bu_estore AS dimprod_seda_bu_estore,
             z.seda_division_estore AS dimprod_seda_division_estore,
             z.seda_category_estore AS dimprod_seda_category_estore,
             0,0,CAST(0 AS INT),CAST(0.00 AS DECIMAL(15,2)),0,0,0,0,0,0,
             SUM(a.sales_qty) AS billingIODProgressQuantity,
             SUM(a.amount_company_code_currency) AS billingIODProgressAmount,
             0,0,0,0,0,0,CAST(0 AS INT),CAST(0 AS DECIMAL(15,2))
        FROM OW_LAO.ODS_NERP_ZKE24_DISPLAY_ACTUAL_LINE_ITEMS a
        JOIN OW_MD.DIM_SUBSIDIARY b ON b.company_code = a.company_code
        LEFT JOIN OW_MD.DIM_PRODUCT z ON z.sku = a.product
       WHERE a.sales_order IS NULL
         AND b.sur_key_subsidiary = 1
       GROUP BY b.subsidiary, a.year, a.posting_period, z.division, z.product_group_1, z.seda_bu_estore, z.seda_division_estore, z.seda_category_estore

      UNION ALL

      SELECT c.subsidiary,
             a.posting_period AS month,
             a.year AS year,
             CAST(a.year AS VARCHAR(4)) || LPAD(CAST(a.posting_period AS VARCHAR),2,'0') AS referencia,
             z.division AS dimprod_division,
             z.product_group_1 AS dimprod_product_group,
             z.seda_bu_estore AS dimprod_seda_bu_estore,
             z.seda_division_estore AS dimprod_seda_division_estore,
             z.seda_category_estore AS dimprod_seda_category_estore,
             0,0,CAST(0 AS INT),CAST(0.00 AS DECIMAL(15,2)),0,0,0,0,0,0,0,0,
             SUM(a.sales_qty) AS billingIODProgressPreviousQuantity,
             SUM(a.amount_company_code_currency) AS billingIODProgressPreviousAmount,
             0,0,0,0,CAST(0 AS INT),CAST(0 AS DECIMAL(15,2))
        FROM OW_LAO.ODS_NERP_ZKE24_DISPLAY_ACTUAL_LINE_ITEMS a
        JOIN OW_MD.DIM_SUBSIDIARY c ON c.company_code = a.company_code
        JOIN TMP_SOT_SALES_PROGRESS_KPI b ON b.sales_document = CAST(a.sales_order AS VARCHAR(70))
                                         AND b.material = a.product
                                         AND b.SO_LOCAL_CREATE_ON_D < TO_DATE(CAST(a.year AS VARCHAR(4)) || LPAD(CAST(a.posting_period AS VARCHAR),2,'0') || '01','YYYYMMDD')
                                         AND c.sales_org = b.sales_org
        LEFT JOIN OW_MD.DIM_PRODUCT z ON z.sku = a.product
       WHERE c.sur_key_subsidiary = 1
       GROUP BY c.subsidiary, a.year, a.posting_period, z.division, z.product_group_1, z.seda_bu_estore, z.seda_division_estore, z.seda_category_estore

      UNION ALL

      SELECT b.subsidiary AS subsidiary,
             a.month AS month,
             a.year AS year,
             CAST(a.year AS VARCHAR(4)) || LPAD(CAST(a.month AS VARCHAR),2,'0') AS referencia,
             z.division AS dimprod_division,
             z.product_group_1 AS dimprod_product_group,
             z.seda_bu_estore AS dimprod_seda_bu_estore,
             z.seda_division_estore AS dimprod_seda_division_estore,
             z.seda_category_estore AS dimprod_seda_category_estore,
             0,0,CAST(0 AS INT),CAST(0.00 AS DECIMAL(15,2)),0,0,0,0,0,0,0,0,0,0,0,0,
             SUM(a.quantity_net) AS ForecastQuantity,
             SUM(a.net_sales) AS ForecastAmount,
             CAST(0 AS INT), CAST(0 AS DECIMAL(15,2))
        FROM OW_LAO.RAW_NERP_ZRCOA20250_FORECAST_SALES_DEDUP a
        JOIN OW_MD.DIM_SUBSIDIARY b ON b.sales_org = a.sales_organization
        LEFT JOIN OW_MD.DIM_PRODUCT z ON z.sku = a.product_number
       WHERE b.sur_key_subsidiary = 1
       GROUP BY b.subsidiary, a.year, a.month, z.division, z.product_group_1, z.seda_bu_estore, z.seda_division_estore, z.seda_category_estore
    ) a
  GROUP BY subsidiary, month, year, referencia,
           dimprod_division, dimprod_product_group, dimprod_seda_bu_estore, dimprod_seda_division_estore, dimprod_seda_category_estore;

  -- AUX_NERP_SALES_PROGRESS_KPI_TARGET
  PERFORM INSERT INTO OW_LAO.AUX_NERP_SALES_PROGRESS_KPI_TARGET
  (
    subsidiary, month, year, referencia, dimprod_division, dimprod_product_group, dimprod_seda_bu_estore,
    dimprod_seda_division_estore, dimprod_seda_category_estore,
    So_Progress_Quantity, So_Progress_Amount, So_Progress_Next_Month_Quantity, So_Progress_Next_Month_Amount,
    Do_Progress_Quantity, Do_Progress_Amount, GI_Progress_Quantity, GI_Progress_Amount,
    In_Transit_Quantity, In_Transit_Amount, billing_IOD_Progress_Quantity, billing_IOD_Progress_Amount,
    billingIODProgressPreviousQuantity, billingIODProgressPreviousAmount, InTransitNetTotalQuantity, InTransitNetTotalAmount,
    ForecastQuantity, ForecastAmount, InTransitNextMonthQuantity, InTransitNextMonthAmount,
    target_qty, target_amount, exchange_rate_usd
  )
  SELECT
      SP.subsidiary, SP.month, SP.year, SP.referencia,
      SP.dimprod_division, SP.dimprod_product_group, SP.dimprod_seda_bu_estore,
      SP.dimprod_seda_division_estore, SP.dimprod_seda_category_estore,
      SP.So_Progress_Quantity, SP.So_Progress_Amount, SP.So_Progress_Next_Month_Quantity, SP.So_Progress_Next_Month_Amount,
      SP.Do_Progress_Quantity, SP.Do_Progress_Amount, SP.GI_Progress_Quantity, SP.GI_Progress_Amount,
      SP.In_Transit_Quantity, SP.In_Transit_Amount, SP.billing_IOD_Progress_Quantity, SP.billing_IOD_Progress_Amount,
      SP.billingIODProgressPreviousQuantity, SP.billingIODProgressPreviousAmount,
      SP.InTransitNetTotalQuantity, SP.InTransitNetTotalAmount,
      SP.ForecastQuantity, SP.ForecastAmount, SP.InTransitNextMonthQuantity, SP.InTransitNextMonthAmount,
      COALESCE(TA.TARGET_QTY,0) AS TARGET_QTY,
      COALESCE(TA.TARGET_AMOUNT,0) AS TARGET_AMOUNT,
      CAST(0.0000 AS DECIMAL(15,4)) AS exchange_rate_usd
    FROM OW_LAO.AUX_NERP_SALES_PROGRESS_KPI SP
    LEFT JOIN (
      SELECT 
            TAR."YEAR"
          , TAR."MONTH"
          , PRD.DIVISION AS DIMPROD_DIVISION
          , PRD.PRODUCT_GROUP_1 AS DIMPROD_PRODUCT_GROUP
          , PRD.SEDA_BU_ESTORE AS DIMPROD_SEDA_BU_ESTORE
          , PRD.SEDA_DIVISION_ESTORE AS DIMPROD_SEDA_DIVISION_ESTORE
          , PRD.SEDA_CATEGORY_ESTORE AS DIMPROD_SEDA_CATEGORY_ESTORE
          , SUM(CAST(TAR.QTY AS DECIMAL(18,4))) AS TARGET_QTY
          , SUM(CAST(TAR.AMOUNT AS DECIMAL(18,4))) AS TARGET_AMOUNT
        FROM OW_LAO.VIEW_NERP_ZRCOS43400_TARGET TAR
        INNER JOIN OW_MD.DIM_PRODUCT PRD ON PRD.SKU = TAR.MATERIAL
       WHERE UPPER(TAR.COMPANY_CODE_DESC) = 'SEDA'
       GROUP BY TAR."YEAR", TAR."MONTH", PRD.DIVISION, PRD.PRODUCT_GROUP_1,
                PRD.SEDA_BU_ESTORE, PRD.SEDA_DIVISION_ESTORE, PRD.SEDA_CATEGORY_ESTORE
    ) TA
      ON TA.YEAR = SP.YEAR
     AND TA.MONTH = SP.MONTH
     AND TA.DIMPROD_DIVISION = SP.DIMPROD_DIVISION
     AND TA.DIMPROD_PRODUCT_GROUP = SP.DIMPROD_PRODUCT_GROUP
     AND TA.DIMPROD_SEDA_BU_ESTORE = SP.DIMPROD_SEDA_BU_ESTORE
     AND TA.DIMPROD_SEDA_DIVISION_ESTORE = SP.DIMPROD_SEDA_DIVISION_ESTORE
     AND TA.DIMPROD_SEDA_CATEGORY_ESTORE = SP.DIMPROD_SEDA_CATEGORY_ESTORE;

  -- Insert missing target-only combinations
  PERFORM INSERT INTO OW_LAO.AUX_NERP_SALES_PROGRESS_KPI_TARGET
  (
    subsidiary, month, year, referencia, dimprod_division, dimprod_product_group, dimprod_seda_bu_estore,
    dimprod_seda_division_estore, dimprod_seda_category_estore,
    So_Progress_Quantity, So_Progress_Amount, So_Progress_Next_Month_Quantity, So_Progress_Next_Month_Amount,
    Do_Progress_Quantity, Do_Progress_Amount, GI_Progress_Quantity, GI_Progress_Amount,
    In_Transit_Quantity, In_Transit_Amount, billing_IOD_Progress_Quantity, billing_IOD_Progress_Amount,
    billingIODProgressPreviousQuantity, billingIODProgressPreviousAmount, InTransitNetTotalQuantity, InTransitNetTotalAmount,
    ForecastQuantity, ForecastAmount, InTransitNextMonthQuantity, InTransitNextMonthAmount,
    target_qty, target_amount, exchange_rate_usd
  )
  SELECT 'SEDA' AS subsidiary
       , b."MONTH" AS month
       , b."YEAR" AS year
       , CAST(b."YEAR" AS VARCHAR(4)) || LPAD(CAST(b."MONTH" AS VARCHAR),2,'0') AS referencia
       , b.DIMPROD_DIVISION
       , b.DIMPROD_PRODUCT_GROUP
       , b.DIMPROD_SEDA_BU_ESTORE
       , b.DIMPROD_SEDA_DIVISION_ESTORE
       , b.DIMPROD_SEDA_CATEGORY_ESTORE
       , 0,0,0,CAST(0.00 AS DECIMAL(15,2)),0,0,0,0,0,0,0,0,0,0,0,0,0,0, CAST(0 AS INT), CAST(0 AS DECIMAL(15,2))
       , SUM(b.TARGET_QTY) AS TARGET_QTY
       , SUM(b.TARGET_AMOUNT) AS TARGET_AMOUNT
       , CAST(0.0000 AS DECIMAL(15,4)) AS exchange_rate_usd
    FROM (
      SELECT 
            TAR."YEAR"
          , TAR."MONTH"
          , PRD.DIVISION AS DIMPROD_DIVISION
          , PRD.PRODUCT_GROUP_1 AS DIMPROD_PRODUCT_GROUP
          , PRD.SEDA_BU_ESTORE AS DIMPROD_SEDA_BU_ESTORE
          , PRD.SEDA_DIVISION_ESTORE AS DIMPROD_SEDA_DIVISION_ESTORE
          , PRD.SEDA_CATEGORY_ESTORE AS DIMPROD_SEDA_CATEGORY_ESTORE
          , SUM(CAST(TAR.QTY AS DECIMAL(18,4))) AS TARGET_QTY
          , SUM(CAST(TAR.AMOUNT AS DECIMAL(18,4))) AS TARGET_AMOUNT
        FROM OW_LAO.VIEW_NERP_ZRCOS43400_TARGET TAR
        INNER JOIN OW_MD.DIM_PRODUCT PRD ON PRD.SKU = TAR.MATERIAL
        INNER JOIN (
          SELECT DISTINCT year, month FROM OW_LAO.AUX_NERP_SALES_PROGRESS_KPI_TARGET
        ) DT ON TAR."YEAR" = DT.year AND TAR."MONTH" = DT.month
       WHERE UPPER(TAR.COMPANY_CODE_DESC) = 'SEDA'
       GROUP BY TAR."YEAR", TAR."MONTH", PRD.DIVISION, PRD.PRODUCT_GROUP_1,
                PRD.SEDA_BU_ESTORE, PRD.SEDA_DIVISION_ESTORE, PRD.SEDA_CATEGORY_ESTORE
    ) b
   WHERE NOT EXISTS (
          SELECT 1 FROM OW_LAO.AUX_NERP_SALES_PROGRESS_KPI a
           WHERE b."YEAR" = a.year
             AND b."MONTH" = a.month
             AND b.DIMPROD_DIVISION = a.dimprod_division
             AND b.DIMPROD_PRODUCT_GROUP = a.dimprod_product_group
             AND b.DIMPROD_SEDA_BU_ESTORE = a.dimprod_seda_bu_estore
             AND b.DIMPROD_SEDA_DIVISION_ESTORE = a.dimprod_seda_division_estore
             AND b.DIMPROD_SEDA_CATEGORY_ESTORE = a.dimprod_seda_category_estore)
   GROUP BY b."MONTH", b."YEAR",
            CAST(b."YEAR" AS VARCHAR(4)) || LPAD(CAST(b."MONTH" AS VARCHAR),2,'0'),
            b.DIMPROD_DIVISION, b.DIMPROD_PRODUCT_GROUP, b.DIMPROD_SEDA_BU_ESTORE,
            b.DIMPROD_SEDA_DIVISION_ESTORE, b.DIMPROD_SEDA_CATEGORY_ESTORE;

  -- Exchange rate end of month snapshot
  PERFORM INSERT INTO OW_LAO.TF_AP2_EXCHANGE_RATE_END_OF_MONTH(year, month, dedup, subsidiary, exchange_rate)
  SELECT EXTRACT(YEAR FROM valid_from)::INT AS year
       , EXTRACT(MONTH FROM valid_from)::INT AS month
       , ROW_NUMBER() OVER (PARTITION BY EXTRACT(YEAR FROM valid_from), EXTRACT(MONTH FROM valid_from), to_currency ORDER BY valid_from DESC) AS dedup
       , 'SEDA' AS subsidiary
       , CAST(exchange_rate AS DECIMAL(18,6)) AS exchange_rate
    FROM OW_LAO.FT_AP2_EXCHANGE_RATE 
   WHERE to_currency = 'BRL';

  PERFORM DELETE FROM OW_LAO.TF_AP2_EXCHANGE_RATE_END_OF_MONTH WHERE dedup <> 1;

  PERFORM INSERT INTO OW_LAO.TF_AP2_EXCHANGE_RATE_END_OF_MONTH(year, month, dedup, subsidiary, exchange_rate)
  SELECT EXTRACT(YEAR FROM CURRENT_DATE)::INT AS year
       , EXTRACT(MONTH FROM CURRENT_DATE)::INT AS month
       , 1 AS dedup
       , 'SEDA' AS subsidiary
       , CAST(exchange_rate AS DECIMAL(18,6)) AS exchange_rate
    FROM OW_LAO.TF_AP2_EXCHANGE_RATE_END_OF_MONTH a
   WHERE LAST_DAY(ADD_MONTHS(CURRENT_DATE, -1)) = 
         CASE WHEN LENGTH(CAST(a.month AS VARCHAR)) = 1
              THEN LAST_DAY(TO_DATE(CAST(a.year AS VARCHAR(4)) || '0' || CAST(a.month AS VARCHAR), 'YYYYMM'))
              ELSE LAST_DAY(TO_DATE(CAST(a.year AS VARCHAR(4)) || CAST(a.month AS VARCHAR), 'YYYYMM')) END
     AND NOT EXISTS (
           SELECT 1 FROM OW_LAO.TF_AP2_EXCHANGE_RATE_END_OF_MONTH
            WHERE EXTRACT(YEAR FROM CURRENT_DATE)::INT = year
              AND EXTRACT(MONTH FROM CURRENT_DATE)::INT = month);

  -- Update exchange rate into KPI_TARGET
  PERFORM UPDATE OW_LAO.AUX_NERP_SALES_PROGRESS_KPI_TARGET a
       SET exchange_rate_usd = COALESCE(b.exchange_rate, 0.0000)
      FROM OW_LAO.TF_AP2_EXCHANGE_RATE_END_OF_MONTH b
     WHERE b.year = a.year
       AND b.month = a.month
       AND b.subsidiary = a.subsidiary;

  -- TF_NERP_SALES_PROGRESS_KPI using generated element numbers 1..34
  PERFORM INSERT INTO OW_LAO.TF_NERP_SALES_PROGRESS_KPI(
        subsidiary, dimprod_division, dimprod_product_group, dimprod_seda_bu_estore,
        dimprod_seda_division_estore, dimprod_seda_category_estore, year, referencia,
        measure_type, measure_desc, measure_value)
  SELECT 
        t.subsidiary,
        t.dimprod_division,
        t.dimprod_product_group,
        t.dimprod_seda_bu_estore,
        t.dimprod_seda_division_estore,
        t.dimprod_seda_category_estore,
        t.year,
        t.referencia,
        CASE n.element_number
          WHEN 1 THEN 'QTY' WHEN 2 THEN 'QTY' WHEN 3 THEN 'QTY' WHEN 4 THEN 'QTY'
          WHEN 5 THEN 'QTY' WHEN 6 THEN 'QTY' WHEN 7 THEN 'QTY' WHEN 8 THEN 'QTY'
          WHEN 9 THEN 'AMT_Local' WHEN 10 THEN 'AMT_Local' WHEN 11 THEN 'AMT_Local' WHEN 12 THEN 'AMT_Local'
          WHEN 13 THEN 'AMT_Local' WHEN 14 THEN 'AMT_Local' WHEN 15 THEN 'AMT_Local' WHEN 16 THEN 'AMT_Local'
          WHEN 17 THEN 'AMT_USD' WHEN 18 THEN 'AMT_USD' WHEN 19 THEN 'AMT_USD' WHEN 20 THEN 'AMT_USD'
          WHEN 21 THEN 'AMT_USD' WHEN 22 THEN 'AMT_USD' WHEN 23 THEN 'AMT_USD' WHEN 24 THEN 'AMT_USD'
          WHEN 25 THEN 'AMT_Local' WHEN 26 THEN 'QTY' WHEN 27 THEN 'AMT_Local' WHEN 28 THEN 'AMT_USD'
          WHEN 29 THEN 'QTY' WHEN 30 THEN 'AMT_Local' WHEN 31 THEN 'AMT_USD' WHEN 32 THEN 'QTY'
          WHEN 33 THEN 'AMT_Local' WHEN 34 THEN 'AMT_USD' END AS measure_type,
        CASE n.element_number
          WHEN 1 THEN 'SO Progress'
          WHEN 2 THEN 'DO Progress'
          WHEN 3 THEN 'GI Progress'
          WHEN 4 THEN 'In Transit'
          WHEN 5 THEN 'In Transit Net Total'
          WHEN 6 THEN 'Billing (IOD)'
          WHEN 7 THEN 'Billing (IOD) Previous'
          WHEN 8 THEN 'Target'
          WHEN 9 THEN 'SO Progress'
          WHEN 10 THEN 'DO Progress'
          WHEN 11 THEN 'GI Progress'
          WHEN 12 THEN 'In Transit'
          WHEN 13 THEN 'In Transit Net Total'
          WHEN 14 THEN 'Billing (IOD)'
          WHEN 15 THEN 'Billing (IOD) Previous'
          WHEN 16 THEN 'Target'
          WHEN 17 THEN 'SO Progress'
          WHEN 18 THEN 'DO Progress'
          WHEN 19 THEN 'GI Progress'
          WHEN 20 THEN 'In Transit'
          WHEN 21 THEN 'In Transit Net Total'
          WHEN 22 THEN 'Billing (IOD)'
          WHEN 23 THEN 'Billing (IOD) Previous'
          WHEN 24 THEN 'Target'
          WHEN 25 THEN 'exchange_rate'
          WHEN 26 THEN 'SO Progress Next Month'
          WHEN 27 THEN 'SO Progress Next Month'
          WHEN 28 THEN 'SO Progress Next Month'
          WHEN 29 THEN 'Forecast'
          WHEN 30 THEN 'Forecast'
          WHEN 31 THEN 'Forecast'
          WHEN 32 THEN 'In Transit Next Month'
          WHEN 33 THEN 'In Transit Next Month'
          WHEN 34 THEN 'In Transit Next Month' END AS measure_desc,
        CASE n.element_number
          WHEN 1 THEN t.So_Progress_Quantity
          WHEN 2 THEN t.Do_Progress_Quantity
          WHEN 3 THEN t.GI_Progress_Quantity
          WHEN 4 THEN t.In_Transit_Quantity
          WHEN 5 THEN t.InTransitNetTotalQuantity
          WHEN 6 THEN t.billing_IOD_Progress_Quantity
          WHEN 7 THEN t.billingIODProgressPreviousQuantity
          WHEN 8 THEN t.target_qty
          WHEN 9 THEN t.So_Progress_Amount
          WHEN 10 THEN t.Do_Progress_Amount
          WHEN 11 THEN t.GI_Progress_Amount
          WHEN 12 THEN t.In_Transit_Amount
          WHEN 13 THEN t.InTransitNetTotalAmount
          WHEN 14 THEN t.billing_IOD_Progress_Amount
          WHEN 15 THEN t.billingIODProgressPreviousAmount
          WHEN 16 THEN t.target_amount
          WHEN 17 THEN CASE WHEN t.exchange_rate_usd <> 0 THEN (t.So_Progress_Amount / t.exchange_rate_usd) ELSE 0 END
          WHEN 18 THEN CASE WHEN t.exchange_rate_usd <> 0 THEN (t.Do_Progress_Amount / t.exchange_rate_usd) ELSE 0 END
          WHEN 19 THEN CASE WHEN t.exchange_rate_usd <> 0 THEN (t.GI_Progress_Amount / t.exchange_rate_usd) ELSE 0 END
          WHEN 20 THEN CASE WHEN t.exchange_rate_usd <> 0 THEN (t.In_Transit_Amount / t.exchange_rate_usd) ELSE 0 END
          WHEN 21 THEN CASE WHEN t.exchange_rate_usd <> 0 THEN (t.InTransitNetTotalAmount / t.exchange_rate_usd) ELSE 0 END
          WHEN 22 THEN CASE WHEN t.exchange_rate_usd <> 0 THEN (t.billing_IOD_Progress_Amount / t.exchange_rate_usd) ELSE 0 END
          WHEN 23 THEN CASE WHEN t.exchange_rate_usd <> 0 THEN (t.billingIODProgressPreviousAmount / t.exchange_rate_usd) ELSE 0 END
          WHEN 24 THEN CASE WHEN t.exchange_rate_usd <> 0 THEN (t.target_amount / t.exchange_rate_usd) ELSE 0 END
          WHEN 25 THEN t.exchange_rate_usd
          WHEN 26 THEN t.So_Progress_Next_Month_Quantity
          WHEN 27 THEN t.So_Progress_Next_Month_Amount
          WHEN 28 THEN CASE WHEN t.exchange_rate_usd <> 0 THEN (t.So_Progress_Next_Month_Amount / t.exchange_rate_usd) ELSE 0 END
          WHEN 29 THEN t.ForecastQuantity
          WHEN 30 THEN t.ForecastAmount
          WHEN 31 THEN CASE WHEN t.exchange_rate_usd <> 0 THEN (t.ForecastAmount / t.exchange_rate_usd) ELSE 0 END
          WHEN 32 THEN t.InTransitNextMonthQuantity
          WHEN 33 THEN t.InTransitNextMonthAmount
          WHEN 34 THEN CASE WHEN t.exchange_rate_usd <> 0 THEN (t.InTransitNextMonthAmount / t.exchange_rate_usd) ELSE 0 END
        END AS measure_value
    FROM OW_LAO.AUX_NERP_SALES_PROGRESS_KPI_TARGET t
    CROSS JOIN (
      SELECT 1 AS element_number UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL
      SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9 UNION ALL SELECT 10 UNION ALL
      SELECT 11 UNION ALL SELECT 12 UNION ALL SELECT 13 UNION ALL SELECT 14 UNION ALL SELECT 15 UNION ALL SELECT 16 UNION ALL
      SELECT 17 UNION ALL SELECT 18 UNION ALL SELECT 19 UNION ALL SELECT 20 UNION ALL SELECT 21 UNION ALL SELECT 22 UNION ALL
      SELECT 23 UNION ALL SELECT 24 UNION ALL SELECT 25 UNION ALL SELECT 26 UNION ALL SELECT 27 UNION ALL SELECT 28 UNION ALL
      SELECT 29 UNION ALL SELECT 30 UNION ALL SELECT 31 UNION ALL SELECT 32 UNION ALL SELECT 33 UNION ALL SELECT 34
    ) n;

  -- Load FT table from TF
  PERFORM INSERT INTO OW_LAO.FT_NERP_SALES_PROGRESS_KPI(
        subsidiary, dimprod_division, dimprod_product_group, dimprod_seda_bu_estore,
        dimprod_seda_division_estore, dimprod_seda_category_estore, year, referencia,
        measure_type, measure_desc, measure_value, KPI_LAST_UPDATE)
  SELECT a.subsidiary,
         COALESCE(a.dimprod_division,'') AS dimprod_division,
         COALESCE(a.dimprod_product_group,'') AS dimprod_product_group,
         COALESCE(a.dimprod_seda_bu_estore,'') AS dimprod_seda_bu_estore,
         COALESCE(a.dimprod_seda_division_estore,'') AS dimprod_seda_division_estore,
         COALESCE(a.dimprod_seda_category_estore,'') AS dimprod_seda_category_estore,
         a.year,
         a.referencia,
         a.measure_type,
         a.measure_desc,
         a.measure_value,
         CURRENT_TIMESTAMP
    FROM OW_LAO.TF_NERP_SALES_PROGRESS_KPI a;

  -- Insert aggregations (grouping sets)
  PERFORM INSERT INTO OW_LAO.FT_NERP_SALES_PROGRESS_KPI(
        subsidiary, dimprod_division, dimprod_product_group, dimprod_seda_bu_estore,
        dimprod_seda_division_estore, dimprod_seda_category_estore, year, referencia,
        measure_type, measure_desc, measure_value, KPI_LAST_UPDATE)
  SELECT COALESCE(a.subsidiary,'Total') AS subsidiary,
         COALESCE(a.dimprod_division,'Total') AS dimprod_division,
         COALESCE(a.dimprod_product_group,'Total') AS dimprod_product_group,
         COALESCE(a.dimprod_seda_bu_estore,'Total') AS dimprod_seda_bu_estore,
         COALESCE(a.dimprod_seda_division_estore,'Total') AS dimprod_seda_division_estore,
         'Total' AS dimprod_seda_category_estore,
         a.year,
         a.referencia,
         a.measure_type,
         a.measure_desc,
         SUM(a.measure_value) AS measure_value,
         CURRENT_TIMESTAMP AS KPI_LAST_UPDATE
    FROM OW_LAO.FT_NERP_SALES_PROGRESS_KPI a
   GROUP BY GROUPING SETS (
        (a.year, a.referencia, a.subsidiary, a.measure_type, a.measure_desc),
        (a.year, a.referencia, a.subsidiary, a.dimprod_division, a.measure_type, a.measure_desc),
        (a.year, a.referencia, a.subsidiary, a.dimprod_division, a.dimprod_product_group, a.measure_type, a.measure_desc),
        (a.year, a.referencia, a.subsidiary, a.dimprod_division, a.dimprod_product_group, a.dimprod_seda_bu_estore, a.measure_type, a.measure_desc),
        (a.year, a.referencia, a.subsidiary, a.dimprod_division, a.dimprod_product_group, a.dimprod_seda_bu_estore, a.dimprod_seda_division_estore, a.measure_type, a.measure_desc)
   );

END;
$$;

-- CALL OW_LAO.PROC_FT_NERP_SALES_PROGRESS_KPI();
-- ERROR: Severity: ROLLBACK, Message: Table "AUX_NERP_SALES_PROGRESS_KPI_INTENCTIVE_RULES" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_FT_NERP_SALES_PROGRESS_KPI line 5 at static SQL, Routine: TruncateTable, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Commands/DDL.cpp, Line: 20681, Error Code: 4876, 
-- CALL OW_LAO.PROC_FT_NERP_SALES_PROGRESS_KPI();
-- ERROR: Severity: ROLLBACK, Message: Table "AUX_NERP_SALES_PROGRESS_KPI_INTENCTIVE_RULES" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_FT_NERP_SALES_PROGRESS_KPI line 5 at static SQL, Routine: TruncateTable, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Commands/DDL.cpp, Line: 20681, Error Code: 4876, 
