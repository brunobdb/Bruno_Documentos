CREATE OR REPLACE PROCEDURE "OW_SELA"."PROCSNAPSHOTFCST_OLD"()
LANGUAGE PLvSQL AS $$
BEGIN
  PERFORM TRUNCATE TABLE "OW_SELA"."FCST_SNAPSHOT";
  PERFORM INSERT INTO "OW_SELA"."FCST_SNAPSHOT"
  (
    "COMPANYCD",
    "COMPANY",
    "MARKETNAME",
    "PRODUCTTYPE",
    "SEGMENT",
    "SEGMENT_AGE",
    "DCID",
    "DC",
    "VRESELLER",
    "DT_YW",
    "START_DT",
    "WR",
    "WWWMM",
    "Sell-in_YW",
    "Sell-out_YW",
    "Sell-thru_YW",
    "EOH_YW",
    "EOH_R_YW",
    "Sell-thru_Sum_4W",
    "Sell-out_Sum_4W"
  )
  SELECT
     "COMPANYCD",
     "COMPANY",
     "MARKETNAME",
     "PRODUCTTYPE",
     "SEGMENT",
     "SEGMENT_AGE",
     "DCID",
     "DC",
     "VRESELLER",
     "YYYYWW",
     "START_DT",
     "WR",
     "WWWMM",
     "Sell-in_YW",
     "Sell-out_YW",
     "Sell-thru_YW",
     "EOH_YW",
     "EOH(R)_YW",
     CASE WHEN "WR" IN('W-8','W-7','W-6') THEN NULL ELSE "Sell-thru_YW" +
         LAG("Sell-thru_YW",1) OVER (PARTITION BY "COMPANYCD","MARKETNAME","DCID","VRESELLER" ORDER BY "YYYYWW") +
         LAG("Sell-thru_YW",2) OVER (PARTITION BY "COMPANYCD","MARKETNAME","DCID","VRESELLER" ORDER BY "YYYYWW") +
         LAG("Sell-thru_YW",3) OVER (PARTITION BY "COMPANYCD","MARKETNAME","DCID","VRESELLER" ORDER BY "YYYYWW") END,
     CASE WHEN "WR" IN('W-8','W-7','W-6') THEN NULL ELSE "Sell-out_YW" +
         LAG("Sell-out_YW",1) OVER (PARTITION BY "COMPANYCD","MARKETNAME","DCID","VRESELLER" ORDER BY "YYYYWW") +
         LAG("Sell-out_YW",2) OVER (PARTITION BY "COMPANYCD","MARKETNAME","DCID","VRESELLER" ORDER BY "YYYYWW") +
         LAG("Sell-out_YW",3) OVER (PARTITION BY "COMPANYCD","MARKETNAME","DCID","VRESELLER" ORDER BY "YYYYWW") END
  FROM "_SYS_BIC"."DLAKE_DMS/DMS_FCST_SUM";
END;
$$;

-- CALL "OW_SELA"."PROCSNAPSHOTFCST_OLD"();
-- ERROR: Severity: ERROR, Message: Relation "_SYS_BIC.DLAKE_DMS/DMS_FCST_SUM" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROCSNAPSHOTFCST_OLD line 4 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
