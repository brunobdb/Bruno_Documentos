CREATE OR REPLACE PROCEDURE ow_lao.proc_ods_sela_orders_coupons_status_history()
LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM MERGE INTO ow_lao.ods_sela_orders_coupons_status_history a
          USING ow_lao.stg_sela_orders_coupons_status_history b 
            ON b.store_id      = a.store_id
           AND b.subsidiary_id = a.subsidiary_id
           AND b.account       = a.account
           AND b.entity_id     = a.entity_id
           AND b.parent_id     = a.parent_id
     WHEN MATCHED THEN UPDATE  
                         SET a.updated_timestamp       = CURRENT_TIMESTAMP     
                           , a.comment                 = b.comment 
                           , a.created_at              = b.created_at 
                           , a.entity_name             = b.entity_name 
                           , a.is_customer_notified    = b.is_customer_notified 
                           , a.is_visible_on_front     = b.is_visible_on_front 
                           , a.status                  = b.status 
                           , a.coupons_entity_id       = b.coupons_entity_id                                                                                         
     WHEN NOT MATCHED THEN INSERT(           
                               updated_timestamp 
                             , comment 
                             , created_at 
                             , entity_id 
                             , entity_name 
                             , is_customer_notified 
                             , is_visible_on_front 
                             , parent_id 
                             , status 
                             , coupons_entity_id 
                             , store_id 
                             , subsidiary_id
                             , account         
                       )      
                       VALUES(
                               CURRENT_TIMESTAMP
                             , b.comment 
                             , b.created_at 
                             , b.entity_id 
                             , b.entity_name 
                             , b.is_customer_notified 
                             , b.is_visible_on_front 
                             , b.parent_id 
                             , b.status 
                             , b.coupons_entity_id 
                             , b.store_id 
                             , b.subsidiary_id
                             , b.account                                            
                       );
END;
$$;

-- CALL ow_lao.proc_ods_sela_orders_coupons_status_history();
-- ERROR: Severity: ERROR, Message: Relation "ow_lao.stg_sela_orders_coupons_status_history" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ods_sela_orders_coupons_status_history line 3 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
-- CALL ow_lao.proc_ods_sela_orders_coupons_status_history();
-- ERROR: Severity: ERROR, Message: Relation "ow_lao.stg_sela_orders_coupons_status_history" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ods_sela_orders_coupons_status_history line 3 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
