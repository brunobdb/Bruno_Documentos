-- CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_global_bi_sales_empty_dimensions_alert()
--  LANGUAGE PLvSQL AS $$
-- BEGIN 
--   PERFORM CREATE LOCAL TEMP TABLE tmp_ods_global_bi_sales_dimensions ON COMMIT PRESERVE ROWS AS
--     SELECT DISTINCT  
--            country
--          , device_type
--          , channel
--          , site
--          , biz_type
--       FROM ow_lao.ods_global_bi_sales
--      WHERE order_date >= TIMESTAMPADD('DAY', -10, CURRENT_DATE)
--        AND site IS NOT NULL 
--        AND device_type IS NOT NULL
--        AND region = 'Latin America';
--             
--   RETURN QUERY
--     SELECT a.country
--          , a.device_type
--          , a.channel
--          , a.site
--          , a.biz_type
--          , COUNT(b.po_id) AS quantity
--       FROM tmp_ods_global_bi_sales_dimensions a
--  LEFT JOIN ow_lao.ods_global_bi_sales      b ON b.country     = a.country      
--                                             AND b.device_type = a.device_type 
--                                             AND b.channel     = a.channel 
--                                             AND b.site        = a.site
--                                             AND b.biz_type    = a.biz_type   
--                                             AND b.order_date >= TIMESTAMPADD('DAY', -5, CURRENT_DATE)
--   GROUP BY a.country
--          , a.device_type
--          , a.channel
--          , a.site
--          , a.biz_type
--     HAVING COUNT(b.po_id) = 0;
-- END
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 16.10-14 of source string: syntax error, unexpected QUERY, expecting := or <-, Sqlstate: 42601, Position: 556, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
-- CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_global_bi_sales_empty_dimensions_alert()
--  LANGUAGE PLvSQL AS $$
-- BEGIN 
--   PERFORM CREATE LOCAL TEMP TABLE tmp_ods_global_bi_sales_dimensions ON COMMIT PRESERVE ROWS AS
--     SELECT DISTINCT  
--            country
--          , device_type
--          , channel
--          , site
--          , biz_type
--       FROM ow_lao.ods_global_bi_sales
--      WHERE order_date >= TIMESTAMPADD(DAY, -10, CURRENT_DATE)
--        AND site IS NOT NULL 
--        AND device_type IS NOT NULL
--        AND region = 'Latin America';
--             
--   SELECT a.country
--        , a.device_type
--        , a.channel
--        , a.site
--        , a.biz_type
--        , COUNT(b.po_id) AS quantity
--     FROM tmp_ods_global_bi_sales_dimensions a
-- LEFT JOIN ow_lao.ods_global_bi_sales      b ON b.country     = a.country      
--                                           AND b.device_type = a.device_type 
--                                           AND b.channel     = a.channel 
--                                           AND b.site        = a.site
--                                           AND b.biz_type    = a.biz_type   
--                                           AND b.order_date >= TIMESTAMPADD(DAY, -5, CURRENT_DATE)
-- GROUP BY a.country
--        , a.device_type
--        , a.channel
--        , a.site
--        , a.biz_type
--   HAVING COUNT(b.po_id) = 0;
-- END
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 34.28 of source string: syntax error, unexpected ;, expecting INTO, Sqlstate: 42601, Position: 1320, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_global_bi_sales_empty_dimensions_alert()
 LANGUAGE PLvSQL AS $$
BEGIN 
  PERFORM CREATE LOCAL TEMP TABLE tmp_ods_global_bi_sales_dimensions ON COMMIT PRESERVE ROWS AS
    SELECT DISTINCT  
           country
         , device_type
         , channel
         , site
         , biz_type
      FROM ow_lao.ods_global_bi_sales
     WHERE order_date >= TIMESTAMPADD(DAY, -10, CURRENT_DATE)
       AND site IS NOT NULL 
       AND device_type IS NOT NULL
       AND region = 'Latin America';

  PERFORM CREATE LOCAL TEMP TABLE tmp_empty_dimensions_alert ON COMMIT PRESERVE ROWS AS
    SELECT a.country
         , a.device_type
         , a.channel
         , a.site
         , a.biz_type
         , COUNT(b.po_id) AS quantity
      FROM tmp_ods_global_bi_sales_dimensions a
 LEFT JOIN ow_lao.ods_global_bi_sales      b ON b.country     = a.country      
                                            AND b.device_type = a.device_type 
                                            AND b.channel     = a.channel 
                                            AND b.site        = a.site
                                            AND b.biz_type    = a.biz_type   
                                            AND b.order_date >= TIMESTAMPADD(DAY, -5, CURRENT_DATE)
  GROUP BY a.country
         , a.device_type
         , a.channel
         , a.site
         , a.biz_type
    HAVING COUNT(b.po_id) = 0;
END
$$;

CALL OW_LAO.proc_ods_global_bi_sales_empty_dimensions_alert();
-- proc_ods_global_bi_sales_empty_dimensions_alert
-- -----------------------------------------------
-- 0

