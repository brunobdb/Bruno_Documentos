CREATE OR REPLACE PROCEDURE ow_lao.monitoring_executions_results_update_jenkins(
       _execution_result_status   INT
     , _monitoring_parameter      INT
     , _jenkins_api_result_status VARCHAR(255)
     , _jenkins_timestamp_fix     VARCHAR(1000)
     , _jenkins_inProgress        VARCHAR(255)
)
LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM UPDATE ow_lao.monitoring_executions_results
       SET monitoring_execution_result_status = 2       -- Success
         , value    = _jenkins_timestamp_fix
         , is_ok    = true
         , ended_at = CURRENT_TIMESTAMP
     WHERE started_at                         <= CURRENT_TIMESTAMP
       AND monitoring_execution_result_status  = _execution_result_status 
       AND monitoring_parameter                =  _monitoring_parameter
       AND _jenkins_api_result_status         != 'FAILURE'
       AND _jenkins_inProgress                != 'true';

    PERFORM UPDATE ow_lao.monitoring_executions_results
       SET monitoring_execution_result_status = 3       -- Failure
         , value    = _jenkins_timestamp_fix
         , is_ok    = false
         , ended_at = CURRENT_TIMESTAMP
     WHERE started_at                         <= CURRENT_TIMESTAMP
       AND monitoring_execution_result_status  = _execution_result_status 
       AND monitoring_parameter                = _monitoring_parameter  
       AND _jenkins_api_result_status          = 'FAILURE'
       AND _jenkins_inProgress                != 'true';

    PERFORM UPDATE ow_lao.monitoring_executions_results
       SET monitoring_execution_result_status = 4       -- Executing
         , value    = _jenkins_timestamp_fix
         , is_ok    = true
         , ended_at = CURRENT_TIMESTAMP
     WHERE started_at                         <= CURRENT_TIMESTAMP
       AND monitoring_execution_result_status  = _execution_result_status 
       AND monitoring_parameter                = _monitoring_parameter  
       --AND _jenkins_api_result_status          = 'null'
       AND _jenkins_inProgress                 = 'true';
END;
$$;

CALL ow_lao.monitoring_executions_results_update_jenkins(1, 100, 'SUCCESS', '2025-09-29T10:00:00Z', 'false');
-- monitoring_executions_results_update_jenkins
-- --------------------------------------------
-- 0

CREATE OR REPLACE PROCEDURE ow_lao.monitoring_executions_results_update_jenkins(
       _execution_result_status   INT
     , _monitoring_parameter      INT
     , _jenkins_api_result_status VARCHAR(255)
     , _jenkins_timestamp_fix     VARCHAR(1000)
     , _jenkins_inProgress        VARCHAR(255)
)
LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM UPDATE ow_lao.monitoring_executions_results
       SET monitoring_execution_result_status = 2       -- Success
         , "value" = _jenkins_timestamp_fix
         , is_ok    = true
         , ended_at = CURRENT_TIMESTAMP
     WHERE started_at                         <= CURRENT_TIMESTAMP
       AND monitoring_execution_result_status  = _execution_result_status 
       AND monitoring_parameter                =  _monitoring_parameter
       AND _jenkins_api_result_status         != 'FAILURE'
       AND _jenkins_inProgress                != 'true';

    PERFORM UPDATE ow_lao.monitoring_executions_results
       SET monitoring_execution_result_status = 3       -- Failure
         , "value" = _jenkins_timestamp_fix
         , is_ok    = false
         , ended_at = CURRENT_TIMESTAMP
     WHERE started_at                         <= CURRENT_TIMESTAMP
       AND monitoring_execution_result_status  = _execution_result_status 
       AND monitoring_parameter                = _monitoring_parameter  
       AND _jenkins_api_result_status          = 'FAILURE'
       AND _jenkins_inProgress                != 'true';

    PERFORM UPDATE ow_lao.monitoring_executions_results
       SET monitoring_execution_result_status = 4       -- Executing
         , "value" = _jenkins_timestamp_fix
         , is_ok    = true
         , ended_at = CURRENT_TIMESTAMP
     WHERE started_at                         <= CURRENT_TIMESTAMP
       AND monitoring_execution_result_status  = _execution_result_status 
       AND monitoring_parameter                = _monitoring_parameter  
       --AND _jenkins_api_result_status          = 'null'
       AND _jenkins_inProgress                 = 'true';
END;
$$;

CALL ow_lao.monitoring_executions_results_update_jenkins(1, 100, 'SUCCESS', '2025-09-29T10:00:00Z', 'false');
-- monitoring_executions_results_update_jenkins
-- --------------------------------------------
-- 0

