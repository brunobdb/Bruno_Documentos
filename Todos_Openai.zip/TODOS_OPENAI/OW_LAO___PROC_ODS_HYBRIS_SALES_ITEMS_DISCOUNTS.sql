CREATE OR REPLACE PROCEDURE ow_lao.proc_ods_hybris_sales_items_discounts()
LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM INSERT INTO u_r_bojart.ods_hybris_sales_items_discounts(
           order_id
         , sku
         , discount_name
         , discount_value
    )
    SELECT
        r.order_code AS order_id,
        r.product_code AS sku,
        MAX(CASE b.id WHEN 6 THEN b.output_split END) AS discount_name,
        MAX(CASE b.id WHEN 3 THEN b.output_split END) AS discount_value
    FROM ow_lao.raw_hybris_sales_homolog r
    JOIN "U_R_BOJART"."SPLIT_STRING_ID"(REPLACE(REPLACE(r.trade_in_discount, '[<','<'), '>]','>'), '|') a ON 1=1
    JOIN "U_R_BOJART"."SPLIT_STRING_ID"(SUBSTRING(a.output_split, LENGTH('<MDV<') + 1, LENGTH(a.output_split) - (LENGTH('<MDV<') + LENGTH('>VDM>'))), '#') b ON 1=1
    WHERE r.trade_in_discount != '[]'
      AND b.id IN (3,6)
    GROUP BY r.order_code, r.product_code, a.id;
END;
$$;

-- CALL ow_lao.proc_ods_hybris_sales_items_discounts();
-- ERROR: Severity: ERROR, Message: Schema "u_r_bojart" does not exist, Sqlstate: 3F000, Where: PL/vSQL procedure proc_ods_hybris_sales_items_discounts line 3 at static SQL, Routine: RangeVarGetObjid, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/NamespaceLookup.cpp, Line: 317, Error Code: 4650, 
-- CALL ow_lao.proc_ods_hybris_sales_items_discounts();
-- ERROR: Severity: ERROR, Message: Schema "u_r_bojart" does not exist, Sqlstate: 3F000, Where: PL/vSQL procedure proc_ods_hybris_sales_items_discounts line 3 at static SQL, Routine: RangeVarGetObjid, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/NamespaceLookup.cpp, Line: 317, Error Code: 4650, 
