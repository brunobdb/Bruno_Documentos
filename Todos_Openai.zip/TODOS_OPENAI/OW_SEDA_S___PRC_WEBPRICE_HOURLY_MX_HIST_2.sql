-- CREATE OR REPLACE PROCEDURE OW_SEDA_S.PRC_WEBPRICE_HOURLY_MX_HIST_2(IN PREVIOUS_DAYS INT)
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--     -- Build tmp_mx
--     PERFORM CREATE LOCAL TEMPORARY TABLE TMP_MX ON COMMIT PRESERVE ROWS AS
--     SELECT
--         mmwci.MARCA,
--         mmwci.CATEGORY,
--         ocwa.ITEM,
--         mmwci.MARKETING_NAME,
--         CASE 
--             WHEN mmwci.CATEGORY = 'HHP' THEN REPLACE(REPLACE(REPLACE(mmwci.MARKETING_NAME, 'Galaxy ', ''), 'Galaxy-', ''), 'Ultra', 'U') || ' (' || mmwci.STORAGE || ')'
--             WHEN mmwci.CATEGORY = 'TAB' THEN mmwci.MARKETING_NAME || ' (' || mmwci.STORAGE || ')'
--             ELSE mmwci.MARKETING_NAME 
--         END AS PRODUCT_NAME,
--         mmwci.STORAGE,
--         mmwci.COLOR,
--         UPPER(ocwa.STORE_NAME) AS STORE_NAME,
--         COALESCE(UPPER(CASE WHEN ocwa.STORE_NAME = ocwa.MARKETPLACE_NAME THEN '-' ELSE CASE WHEN ocwa.STORE_NAME = 'Mercado Livre' AND UPPER(ocwa.MARKETPLACE_NAME) LIKE '%MERCADO LIVRE ELETRONICOS%' THEN NULL ELSE ocwa.MARKETPLACE_NAME END END), '-') AS MARKETPLACE_NAME,
--         ocwa.INPUT_DATE AS COLLECT_TIMESTAMP,
--         ocwa.PRECO_A_VISTA,
--         ocwa.PRECO_A_PRAZO,
--         ocwa.PARCELAS,
--         ocwa.PRECO_PARCELAS
--     FROM OW_SEDA_S.ODS_CE_WEBPRICE_API ocwa 
--     INNER JOIN OW_SEDA_S.MAP_MX_WEBPRICE_CODIGO_INTERNO mmwci ON ocwa.ITEM = mmwci.CODIGO_INTERNO
--     WHERE CAST(ocwa.INPUT_DATE AS DATE) BETWEEN DATE '2025-04-05' AND DATE '2025-04-06';
-- 
--     -- Build tmp_complete using tmp_mx
--     PERFORM CREATE LOCAL TEMPORARY TABLE TMP_COMPLETE ON COMMIT PRESERVE ROWS AS
--     SELECT
--         tmx.MARCA,
--         tmx.CATEGORY,
--         tmx.ITEM,
--         tmx.MARKETING_NAME,
--         tmx.PRODUCT_NAME,
--         tmx.STORAGE,
--         tmx.COLOR,
--         tmx.STORE_NAME,
--         tmx.MARKETPLACE_NAME,
--         tmx.COLLECT_TIMESTAMP,
--         vcc.YEARWEEK,
--         tmx.PRECO_A_VISTA,
--         tmx.PRECO_A_PRAZO,
--         tmx.PARCELAS,
--         tmx.PRECO_PARCELAS,
--         omrp.REFERENCE_PRICE_SPOT AS SENSING_A_VISTA,
--         omrp.REFERENCE_PRICE_INSTALLMENT AS SENSING_A_PRAZO,
--         omrp.RRP 
--     FROM TMP_MX tmx
--     INNER JOIN OW_SEDA_S.VW_CE_CALENDAR vcc ON vcc."DATE" = CAST(tmx.COLLECT_TIMESTAMP AS DATE)
--     LEFT JOIN OW_SEDA_S.ODS_MX_REFERENCE_PRICE omrp 
--       ON omrp.WEEKNUM = vcc.YEARWEEK
--      AND omrp.PRODUCT_NAME = CASE WHEN tmx.CATEGORY = 'NPC' THEN tmx.ITEM ELSE tmx.PRODUCT_NAME END;
-- 
--     -- Delete existing rows for same collect dates
--     PERFORM DELETE FROM OW_SEDA_S.FT_WEBPRICE_TRACKING_HOURLY_MX owtdt 
--     WHERE EXISTS (
--         SELECT 1 FROM TMP_COMPLETE t 
--         WHERE CAST(owtdt.COLLECT_TIMESTAMP AS DATE) = CAST(t.COLLECT_TIMESTAMP AS DATE)
--     );
-- 
--     -- Insert new rows
--     PERFORM INSERT INTO OW_SEDA_S.FT_WEBPRICE_TRACKING_HOURLY_MX
--     SELECT * FROM TMP_COMPLETE;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: Syntax error at or near "owtdt", Sqlstate: 42601, Position: 2468, Routine: base_yyerror, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/scan.l, Line: 1056, Error Code: 4856, 
CREATE OR REPLACE PROCEDURE OW_SEDA_S.PRC_WEBPRICE_HOURLY_MX_HIST_2(IN PREVIOUS_DAYS INT)
LANGUAGE PLvSQL AS $$
BEGIN
    -- Build tmp_mx
    PERFORM CREATE LOCAL TEMPORARY TABLE TMP_MX ON COMMIT PRESERVE ROWS AS
    SELECT
        mmwci.MARCA,
        mmwci.CATEGORY,
        ocwa.ITEM,
        mmwci.MARKETING_NAME,
        CASE 
            WHEN mmwci.CATEGORY = 'HHP' THEN REPLACE(REPLACE(REPLACE(mmwci.MARKETING_NAME, 'Galaxy ', ''), 'Galaxy-', ''), 'Ultra', 'U') || ' (' || mmwci.STORAGE || ')'
            WHEN mmwci.CATEGORY = 'TAB' THEN mmwci.MARKETING_NAME || ' (' || mmwci.STORAGE || ')'
            ELSE mmwci.MARKETING_NAME 
        END AS PRODUCT_NAME,
        mmwci.STORAGE,
        mmwci.COLOR,
        UPPER(ocwa.STORE_NAME) AS STORE_NAME,
        COALESCE(UPPER(CASE WHEN ocwa.STORE_NAME = ocwa.MARKETPLACE_NAME THEN '-' ELSE CASE WHEN ocwa.STORE_NAME = 'Mercado Livre' AND UPPER(ocwa.MARKETPLACE_NAME) LIKE '%MERCADO LIVRE ELETRONICOS%' THEN NULL ELSE ocwa.MARKETPLACE_NAME END END), '-') AS MARKETPLACE_NAME,
        ocwa.INPUT_DATE AS COLLECT_TIMESTAMP,
        ocwa.PRECO_A_VISTA,
        ocwa.PRECO_A_PRAZO,
        ocwa.PARCELAS,
        ocwa.PRECO_PARCELAS
    FROM OW_SEDA_S.ODS_CE_WEBPRICE_API ocwa 
    INNER JOIN OW_SEDA_S.MAP_MX_WEBPRICE_CODIGO_INTERNO mmwci ON ocwa.ITEM = mmwci.CODIGO_INTERNO
    WHERE CAST(ocwa.INPUT_DATE AS DATE) BETWEEN DATE '2025-04-05' AND DATE '2025-04-06';

    -- Build tmp_complete using tmp_mx
    PERFORM CREATE LOCAL TEMPORARY TABLE TMP_COMPLETE ON COMMIT PRESERVE ROWS AS
    SELECT
        tmx.MARCA,
        tmx.CATEGORY,
        tmx.ITEM,
        tmx.MARKETING_NAME,
        tmx.PRODUCT_NAME,
        tmx.STORAGE,
        tmx.COLOR,
        tmx.STORE_NAME,
        tmx.MARKETPLACE_NAME,
        tmx.COLLECT_TIMESTAMP,
        vcc.YEARWEEK,
        tmx.PRECO_A_VISTA,
        tmx.PRECO_A_PRAZO,
        tmx.PARCELAS,
        tmx.PRECO_PARCELAS,
        omrp.REFERENCE_PRICE_SPOT AS SENSING_A_VISTA,
        omrp.REFERENCE_PRICE_INSTALLMENT AS SENSING_A_PRAZO,
        omrp.RRP 
    FROM TMP_MX tmx
    INNER JOIN OW_SEDA_S.VW_CE_CALENDAR vcc ON vcc."DATE" = CAST(tmx.COLLECT_TIMESTAMP AS DATE)
    LEFT JOIN OW_SEDA_S.ODS_MX_REFERENCE_PRICE omrp 
      ON omrp.WEEKNUM = vcc.YEARWEEK
     AND omrp.PRODUCT_NAME = CASE WHEN tmx.CATEGORY = 'NPC' THEN tmx.ITEM ELSE tmx.PRODUCT_NAME END;

    -- Delete existing rows for same collect dates
    PERFORM DELETE FROM OW_SEDA_S.FT_WEBPRICE_TRACKING_HOURLY_MX
     WHERE CAST(COLLECT_TIMESTAMP AS DATE) IN (
        SELECT CAST(COLLECT_TIMESTAMP AS DATE) FROM TMP_COMPLETE GROUP BY 1
     );

    -- Insert new rows
    PERFORM INSERT INTO OW_SEDA_S.FT_WEBPRICE_TRACKING_HOURLY_MX
    SELECT * FROM TMP_COMPLETE;
END;
$$;

-- CALL OW_SEDA_S.PRC_WEBPRICE_HOURLY_MX_HIST_2(7);
-- ERROR: Severity: ERROR, Message: Relation "OW_SEDA_S.VW_CE_CALENDAR" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PRC_WEBPRICE_HOURLY_MX_HIST_2 line 29 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
