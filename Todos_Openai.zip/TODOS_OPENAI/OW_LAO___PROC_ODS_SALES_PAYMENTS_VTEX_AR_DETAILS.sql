CREATE OR REPLACE PROCEDURE OW_LAO.PROC_ODS_SALES_PAYMENTS_VTEX_AR_DETAILS()
LANGUAGE PLvSQL AS $$
BEGIN
    
    PERFORM TRUNCATE TABLE OW_LAO.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS;
        
    PERFORM INSERT INTO OW_LAO.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS
    SELECT DISTINCT
        NULL AS ID,
        CURRENT_TIMESTAMP AS INSERT_TIMESTAMP,
        CURRENT_TIMESTAMP AS UPDATED_TIMESTAMP,
        CAST(A.PO_DATE AS DATE) AS PO_DATE,
        A.PODATE_MONTH AS PO_MONTH,
        A.PODATE_YEAR AS PO_YEAR,
        CAST(SUBSTR(A.PO_HOUR, 1, 2) AS INT) AS PO_HOUR,
        A.SUBSIDIARY AS PAY_SUBSIDIARY,
        C.KEY_TRANSACTION_ID AS PAY_CODE,
        C.PAYMENT_ID AS PAY_ID,
        CAST(A.PO_DATE AS DATE) AS PAY_DATE, 
        A.PODATE_MONTH AS PAY_MONTH,
        A.PODATE_YEAR AS PAY_YEAR,
        CAST(SUBSTR(A.PO_HOUR, 1, 2) AS INT) AS PAY_HOUR,
        C.STATUS AS PAY_STATUS,
        A.PO_PAYMENT_REMARK AS PAY_DETAIL,
        C."SOURCE" AS PAY_GATEWAY_CODE, 
        A.PAYMENT_TYPE,
        C."SOURCE"             AS PAY_GATEWAY,
        CAST(NULL AS DECIMAL)  AS REVENUE_LOCAL,
        A.PO_ORDERID AS PAY_ORDERID,
        LOWER(A.PO_STORENAME) AS PAY_STORENAME,
        CAST(NULL AS VARCHAR(255)) AS POSTORETYPE,
        A.PO_DEVICETYPE,
        COALESCE(A.PO_INTERNAL_STATUS, 'incomplete') AS PO_STATUS,
        CAST(NULL AS VARCHAR(255)) AS ORDER_STATUS_TYPE,
        A.CURRENCY,
        C."DATE"       AS PO_ORDER_LASTMODIFYDATE,
        A.PO_STORENAME AS POSTORENAME,
        A.CHANNEL,
        A.BIZ_TYPE,
        A.AUDIENCE_TYPE,
        A.SUBSIDIARY ,
        CAST(NULL AS DECIMAL)  AS PE_AMOUNT,
        CAST(NULL AS DECIMAL)  AS REVENU_USD,
        A.PO_ORDERID, 
        CAST(NULL AS VARCHAR(255)) AS PAY_ACTION,
        CAST(NULL AS VARCHAR(255)) AS PAY_RESULT,
        CAST(NULL AS VARCHAR(255)) AS PAY_DESCRIPTION,
        C.MESSAGE AS PAY_MESSAGE,
        COALESCE(A.PO_INTERNAL_STATUS, 'incomplete') AS PO_INTERNAL_STATUS, 
        A.PAYMENT_TYPE AS PO_PAYMENT_TYPE,
        C."SOURCE" AS PO_PAYMENTPROVIDER,
        A.PAYMENT_CARD_BRAND AS PAYMENT_CARD_BRAND,
        A.PO_STATUS AS PO_STATUS_CT,
        CAST(NULL AS VARCHAR(255)) AS FUNNEL_STATUS,
        C."DATE" AS DATASOURCE_ORIGIN_TIMESTAMP,
        ROW_NUMBER() OVER (
                   PARTITION BY C.KEY_TRANSACTION_ID, B.ORDER_ID
                   ORDER BY C."DATE" DESC, B.VALUE DESC ) AS DEDUP,
        'VTEX_AR'                             as PO_PLATAFORM_DATASOURCE,
        CAST(NULL AS VARCHAR(255))           as PAY_GATEWAY_STATUS,
        CAST(NULL AS VARCHAR(255))           as PO_PAYMENT_TYPE_STATUS
    FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A
    JOIN U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER_PAYMENT B ON B.ORDER_ID = A.PO_ORDERID 
    JOIN OW_LAO.RAW_VTEX_PAYMENTS C ON     C.KEY_TRANSACTION_ID     = B.TRANSACTION_ID
                                      AND C.PAYMENT_ID         = B.PAYMENT_ID 
    WHERE    A.CLIENT_SUBSIDIARY_ID = 1
        AND PO_PLATAFORM_DATASOURCE = 'u_prj_ecom.raw_vtex_ssg_ar_sales_order'
      AND NOT EXISTS (
          SELECT 1
          FROM OW_LAO.ODS_PAYMENT_FUNNEL AA
          WHERE A.PO_ORDERID = AA.PO_ORDERID
            AND A.SUBSIDIARY = AA.SUBSIDIARY
            AND COALESCE(A.PO_INTERNAL_STATUS, 'incomplete') = COALESCE(AA.PO_INTERNAL_STATUS, 'incomplete')
      )
     ;
 
    -- DEDUP LAST UPDATE
    PERFORM DELETE 
      FROM OW_LAO.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS
     WHERE DEDUP != 1;     
 
    -- Update sales payments 
    PERFORM UPDATE OW_LAO.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS A
       SET REVENUE_LOCAL = B.VALUE  / 100 ,
           PE_AMOUNT     = B.VALUE  / 100 
      FROM U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER_PAYMENT B 
     WHERE B.ORDER_ID = A.PAY_ORDERID; 
 
    -- Update sales payments usd
    PERFORM UPDATE OW_LAO.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS A
       SET REVENU_USD = A.PE_AMOUNT / CAST(B.EXCHANGE_RATE AS DECIMAL)
      FROM OW_LAO.FT_AP2_EXCHANGE_RATE               B 
     WHERE B.VALID_FROM         =  TIMESTAMPADD(DAY, -1, CAST(A.PO_DATE AS DATE))
       AND LOWER(B.TO_CURRENCY) =  LOWER(A.CURRENCY);
 
    -- Update sales payments vtex AR status
    PERFORM UPDATE OW_LAO.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS A
       SET FUNNEL_STATUS = B.STATUS
      FROM ow_lao.DIM_PAYMENT_FUNNEL_STATUS_MAPPING B 
     WHERE A.PO_INTERNAL_STATUS          = B.PO_STATUS
       AND A.PAY_STATUS                  = B.PAY_STATUS 
       AND A.po_plataform_datasource     = B.data_source     
       AND B.ACTIVE = true; 
 
    -- Map gateway status            
    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS  a
       SET pay_gateway_status = b.gateway
      FROM ow_lao.dim_payment_pay_gateway_mapping       b 
     WHERE b.data_source = a.po_plataform_datasource 
       AND b.pay_gateway = a.pay_gateway
       AND b.active = true;     
      
    -- Map payment type status   
    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS  a
       SET po_payment_type_status = b.payment_mode
      FROM ow_lao.dim_payment_type_mapping                b 
     WHERE b.data_source   = a.po_plataform_datasource 
       AND b.payment_type  = a.payment_type
       AND b.active = true;     
 
 
    -- Upsert into ODS_PAYMENT_FUNNEL for VTEX AR Payments
    PERFORM MERGE INTO 
            ow_lao.ODS_PAYMENT_FUNNEL a
        USING ow_lao.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS b
           ON b.pay_orderid    = a.pay_orderid
          AND b.pay_subsidiary = a.pay_subsidiary
        WHEN MATCHED THEN UPDATE 
            SET   po_date                     = b.po_date 
                , po_month                    = b.po_month 
                , po_year                     = b.po_year 
                , po_hour                     = b.po_hour 
                , pay_subsidiary              = b.pay_subsidiary 
                , pay_code                    = b.pay_code 
                , pay_id                      = b.pay_id 
                , pay_date                    = b.pay_date 
                , pay_month                   = b.pay_month 
                , pay_year                    = b.pay_year 
                , pay_hour                    = b.pay_hour 
                , pay_status                  = b.pay_status 
                , pay_detail                  = b.pay_detail 
                , pay_gateway_code            = b.pay_gateway_code 
                , payment_type                = b.payment_type 
                , pay_gateway                 = b.pay_gateway 
                , revenue_local               = b.revenue_local 
                , pay_orderid                 = b.pay_orderid 
                , pay_storename               = b.pay_storename 
                , postoretype                 = b.postoretype 
                , po_devicetype               = b.po_devicetype 
                , po_status                   = b.po_status 
                , order_status_type           = b.order_status_type 
                , currency                    = b.currency 
                , po_order_lastmodifydate     = b.po_order_lastmodifydate 
                , postorename                 = b.postorename 
                , channel                     = b.channel 
                , biz_type                    = b.biz_type 
                , audience_type               = b.audience_type 
                , subsidiary                  = b.subsidiary 
                , pe_amount                   = b.pe_amount
                , revenu_usd                  = b.revenu_usd
                , po_orderid                  = b.po_orderid 
                , pay_action                  = b.pay_action 
                , pay_result                  = b.pay_result 
                , pay_description             = b.pay_description 
                , pay_message                 = b.pay_message 
                , po_internal_status          = b.po_internal_status
                , po_payment_type             = b.po_payment_type
                , po_paymentprovider          = b.po_paymentprovider
                , payment_card_brand          = b.payment_card_brand
                , po_status_ct                = b.po_status_ct 
                , funnel_status               = b.funnel_status                                  
                , datasource_origin_timestamp = b.datasource_origin_timestamp
                , PAY_GATEWAY_STATUS          = b.PAY_GATEWAY_STATUS
                , PO_PAYMENT_TYPE_STATUS      = b.PO_PAYMENT_TYPE_STATUS
                , PO_PLATAFORM_DATASOURCE     = b.PO_PLATAFORM_DATASOURCE
                , updated_timestamp           = current_timestamp
        WHEN NOT MATCHED THEN INSERT(
                po_date 
                , po_month 
                , po_year 
                , po_hour 
                , pay_subsidiary 
                , pay_code 
                , pay_id 
                , pay_date 
                , pay_month 
                , pay_year 
                , pay_hour 
                , pay_status 
                , pay_detail 
                , pay_gateway_code 
                , payment_type 
                , pay_gateway 
                , revenue_local 
                , pay_orderid 
                , pay_storename 
                , postoretype 
                , po_devicetype 
                , po_status 
                , order_status_type 
                , currency 
                , po_order_lastmodifydate 
                , postorename 
                , channel 
                , biz_type 
                , audience_type 
                , subsidiary 
                , pe_amount
                , revenu_usd
                , po_orderid 
                , pay_action 
                , pay_result 
                , pay_description 
                , pay_message 
                , po_internal_status
                , po_payment_type
                , po_paymentprovider
                , payment_card_brand
                , po_status_ct 
                , funnel_status 
                , datasource_origin_timestamp
                , PAY_GATEWAY_STATUS
                , PO_PAYMENT_TYPE_STATUS
                , PO_PLATAFORM_DATASOURCE
                )
                VALUES(
                b.po_date 
                , b.po_month 
                , b.po_year 
                , b.po_hour 
                , b.pay_subsidiary 
                , b.pay_code 
                , b.pay_id 
                , b.pay_date 
                , b.pay_month 
                , b.pay_year 
                , b.pay_hour 
                , b.pay_status 
                , b.pay_detail 
                , b.pay_gateway_code 
                , b.payment_type 
                , b.pay_gateway 
                , b.revenue_local 
                , b.pay_orderid 
                , b.pay_storename 
                , b.postoretype 
                , b.po_devicetype 
                , b.po_status 
                , b.order_status_type 
                , b.currency 
                , b.po_order_lastmodifydate 
                , b.postorename 
                , b.channel 
                , b.biz_type 
                , b.audience_type 
                , b.subsidiary 
                , b.pe_amount
                , b.revenu_usd
                , b.po_orderid 
                , b.pay_action 
                , b.pay_result 
                , b.pay_description 
                , b.pay_message 
                , b.po_internal_status
                , b.po_payment_type
                , b.po_paymentprovider
                , b.payment_card_brand
                , b.po_status_ct 
                , b.funnel_status 
                , b.datasource_origin_timestamp 
                , b.PAY_GATEWAY_STATUS
                , b.PO_PAYMENT_TYPE_STATUS
                , b.PO_PLATAFORM_DATASOURCE
                ); 
END;
$$;

-- CALL OW_LAO.PROC_ODS_SALES_PAYMENTS_VTEX_AR_DETAILS();
-- ERROR: Severity: ERROR, Message: Function SUBSTR(time, int, int) does not exist, or permission is denied for SUBSTR(time, int, int), Sqlstate: 42883, Hint: No function matches the given name and argument types. Candidates are: SUBSTR(string::varchar, position::numeric) SUBSTR(string::varchar, position::numeric, extent::numeric) SUBSTR(string::varchar, position::float) SUBSTR(string::varchar, position::float, extent::float) SUBSTR(string::long varbinary, position::int, extent::int) SUBSTR(string::varbinary, position::int, extent::int) SUBSTR(string::varchar, position::int, extent::int) SUBSTR(string::long varchar, position::int, extent::int), Where: PL/vSQL procedure PROC_ODS_SALES_PAYMENTS_VTEX_AR_DETAILS line 6 at static SQL, Routine: throwErrorFunctionDoesNotMatchCandidates, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/ParseFunc.cpp, Line: 4569, Error Code: 3457, 
-- CALL OW_LAO.PROC_ODS_SALES_PAYMENTS_VTEX_AR_DETAILS();
-- ERROR: Severity: ERROR, Message: Function SUBSTR(time, int, int) does not exist, or permission is denied for SUBSTR(time, int, int), Sqlstate: 42883, Hint: No function matches the given name and argument types. Candidates are: SUBSTR(string::varchar, position::numeric) SUBSTR(string::varchar, position::numeric, extent::numeric) SUBSTR(string::varchar, position::float) SUBSTR(string::varchar, position::float, extent::float) SUBSTR(string::long varbinary, position::int, extent::int) SUBSTR(string::varbinary, position::int, extent::int) SUBSTR(string::varchar, position::int, extent::int) SUBSTR(string::long varchar, position::int, extent::int), Where: PL/vSQL procedure PROC_ODS_SALES_PAYMENTS_VTEX_AR_DETAILS line 6 at static SQL, Routine: throwErrorFunctionDoesNotMatchCandidates, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/ParseFunc.cpp, Line: 4569, Error Code: 3457, 
CREATE OR REPLACE PROCEDURE OW_LAO.PROC_ODS_SALES_PAYMENTS_VTEX_AR_DETAILS()
LANGUAGE PLvSQL AS $$
BEGIN
    
    PERFORM TRUNCATE TABLE OW_LAO.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS;
        
    PERFORM INSERT INTO OW_LAO.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS
    SELECT DISTINCT
        NULL AS ID,
        CURRENT_TIMESTAMP AS INSERT_TIMESTAMP,
        CURRENT_TIMESTAMP AS UPDATED_TIMESTAMP,
        CAST(A.PO_DATE AS DATE) AS PO_DATE,
        A.PODATE_MONTH AS PO_MONTH,
        A.PODATE_YEAR AS PO_YEAR,
        EXTRACT(HOUR FROM A.PO_HOUR) AS PO_HOUR,
        A.SUBSIDIARY AS PAY_SUBSIDIARY,
        C.KEY_TRANSACTION_ID AS PAY_CODE,
        C.PAYMENT_ID AS PAY_ID,
        CAST(A.PO_DATE AS DATE) AS PAY_DATE, 
        A.PODATE_MONTH AS PAY_MONTH,
        A.PODATE_YEAR AS PAY_YEAR,
        EXTRACT(HOUR FROM A.PO_HOUR) AS PAY_HOUR,
        C.STATUS AS PAY_STATUS,
        A.PO_PAYMENT_REMARK AS PAY_DETAIL,
        C."SOURCE" AS PAY_GATEWAY_CODE, 
        A.PAYMENT_TYPE,
        C."SOURCE"             AS PAY_GATEWAY,
        CAST(NULL AS DECIMAL)  AS REVENUE_LOCAL,
        A.PO_ORDERID AS PAY_ORDERID,
        LOWER(A.PO_STORENAME) AS PAY_STORENAME,
        CAST(NULL AS VARCHAR(255)) AS POSTORETYPE,
        A.PO_DEVICETYPE,
        COALESCE(A.PO_INTERNAL_STATUS, 'incomplete') AS PO_STATUS,
        CAST(NULL AS VARCHAR(255)) AS ORDER_STATUS_TYPE,
        A.CURRENCY,
        C."DATE"       AS PO_ORDER_LASTMODIFYDATE,
        A.PO_STORENAME AS POSTORENAME,
        A.CHANNEL,
        A.BIZ_TYPE,
        A.AUDIENCE_TYPE,
        A.SUBSIDIARY ,
        CAST(NULL AS DECIMAL)  AS PE_AMOUNT,
        CAST(NULL AS DECIMAL)  AS REVENU_USD,
        A.PO_ORDERID, 
        CAST(NULL AS VARCHAR(255)) AS PAY_ACTION,
        CAST(NULL AS VARCHAR(255)) AS PAY_RESULT,
        CAST(NULL AS VARCHAR(255)) AS PAY_DESCRIPTION,
        C.MESSAGE AS PAY_MESSAGE,
        COALESCE(A.PO_INTERNAL_STATUS, 'incomplete') AS PO_INTERNAL_STATUS, 
        A.PAYMENT_TYPE AS PO_PAYMENT_TYPE,
        C."SOURCE" AS PO_PAYMENTPROVIDER,
        A.PAYMENT_CARD_BRAND AS PAYMENT_CARD_BRAND,
        A.PO_STATUS AS PO_STATUS_CT,
        CAST(NULL AS VARCHAR(255)) AS FUNNEL_STATUS,
        C."DATE" AS DATASOURCE_ORIGIN_TIMESTAMP,
        ROW_NUMBER() OVER (
                   PARTITION BY C.KEY_TRANSACTION_ID, B.ORDER_ID
                   ORDER BY C."DATE" DESC, B.VALUE DESC ) AS DEDUP,
        'VTEX_AR'                             as PO_PLATAFORM_DATASOURCE,
        CAST(NULL AS VARCHAR(255))           as PAY_GATEWAY_STATUS,
        CAST(NULL AS VARCHAR(255))           as PO_PAYMENT_TYPE_STATUS
    FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A
    JOIN U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER_PAYMENT B ON B.ORDER_ID = A.PO_ORDERID 
    JOIN OW_LAO.RAW_VTEX_PAYMENTS C ON     C.KEY_TRANSACTION_ID     = B.TRANSACTION_ID
                                      AND C.PAYMENT_ID         = B.PAYMENT_ID 
    WHERE    A.CLIENT_SUBSIDIARY_ID = 1
        AND PO_PLATAFORM_DATASOURCE = 'u_prj_ecom.raw_vtex_ssg_ar_sales_order'
      AND NOT EXISTS (
          SELECT 1
          FROM OW_LAO.ODS_PAYMENT_FUNNEL AA
          WHERE A.PO_ORDERID = AA.PO_ORDERID
            AND A.SUBSIDIARY = AA.SUBSIDIARY
            AND COALESCE(A.PO_INTERNAL_STATUS, 'incomplete') = COALESCE(AA.PO_INTERNAL_STATUS, 'incomplete')
      )
     ;
 
    -- DEDUP LAST UPDATE
    PERFORM DELETE 
      FROM OW_LAO.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS
     WHERE DEDUP != 1;     
 
    -- Update sales payments 
    PERFORM UPDATE OW_LAO.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS A
       SET REVENUE_LOCAL = B.VALUE  / 100 ,
           PE_AMOUNT     = B.VALUE  / 100 
      FROM U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER_PAYMENT B 
     WHERE B.ORDER_ID = A.PAY_ORDERID; 
 
    -- Update sales payments usd
    PERFORM UPDATE OW_LAO.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS A
       SET REVENU_USD = A.PE_AMOUNT / CAST(B.EXCHANGE_RATE AS DECIMAL)
      FROM OW_LAO.FT_AP2_EXCHANGE_RATE               B 
     WHERE B.VALID_FROM         =  TIMESTAMPADD(DAY, -1, CAST(A.PO_DATE AS DATE))
       AND LOWER(B.TO_CURRENCY) =  LOWER(A.CURRENCY);
 
    -- Update sales payments vtex AR status
    PERFORM UPDATE OW_LAO.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS A
       SET FUNNEL_STATUS = B.STATUS
      FROM ow_lao.DIM_PAYMENT_FUNNEL_STATUS_MAPPING B 
     WHERE A.PO_INTERNAL_STATUS          = B.PO_STATUS
       AND A.PAY_STATUS                  = B.PAY_STATUS 
       AND A.po_plataform_datasource     = B.data_source     
       AND B.ACTIVE = true; 
 
    -- Map gateway status            
    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS  a
       SET pay_gateway_status = b.gateway
      FROM ow_lao.dim_payment_pay_gateway_mapping       b 
     WHERE b.data_source = a.po_plataform_datasource 
       AND b.pay_gateway = a.pay_gateway
       AND b.active = true;     
      
    -- Map payment type status   
    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS  a
       SET po_payment_type_status = b.payment_mode
      FROM ow_lao.dim_payment_type_mapping                b 
     WHERE b.data_source   = a.po_plataform_datasource 
       AND b.payment_type  = a.payment_type
       AND b.active = true;     
 
 
    -- Upsert into ODS_PAYMENT_FUNNEL for VTEX AR Payments
    PERFORM MERGE INTO 
            ow_lao.ODS_PAYMENT_FUNNEL a
        USING ow_lao.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS b
           ON b.pay_orderid    = a.pay_orderid
          AND b.pay_subsidiary = a.pay_subsidiary
        WHEN MATCHED THEN UPDATE 
            SET   po_date                     = b.po_date 
                , po_month                    = b.po_month 
                , po_year                     = b.po_year 
                , po_hour                     = b.po_hour 
                , pay_subsidiary              = b.pay_subsidiary 
                , pay_code                    = b.pay_code 
                , pay_id                      = b.pay_id 
                , pay_date                    = b.pay_date 
                , pay_month                   = b.pay_month 
                , pay_year                    = b.pay_year 
                , pay_hour                    = b.pay_hour 
                , pay_status                  = b.pay_status 
                , pay_detail                  = b.pay_detail 
                , pay_gateway_code            = b.pay_gateway_code 
                , payment_type                = b.payment_type 
                , pay_gateway                 = b.pay_gateway 
                , revenue_local               = b.revenue_local 
                , pay_orderid                 = b.pay_orderid 
                , pay_storename               = b.pay_storename 
                , postoretype                 = b.postoretype 
                , po_devicetype               = b.po_devicetype 
                , po_status                   = b.po_status 
                , order_status_type           = b.order_status_type 
                , currency                    = b.currency 
                , po_order_lastmodifydate     = b.po_order_lastmodifydate 
                , postorename                 = b.postorename 
                , channel                     = b.channel 
                , biz_type                    = b.biz_type 
                , audience_type               = b.audience_type 
                , subsidiary                  = b.subsidiary 
                , pe_amount                   = b.pe_amount
                , revenu_usd                  = b.revenu_usd
                , po_orderid                  = b.po_orderid 
                , pay_action                  = b.pay_action 
                , pay_result                  = b.pay_result 
                , pay_description             = b.pay_description 
                , pay_message                 = b.pay_message 
                , po_internal_status          = b.po_internal_status
                , po_payment_type             = b.po_payment_type
                , po_paymentprovider          = b.po_paymentprovider
                , payment_card_brand          = b.payment_card_brand
                , po_status_ct                = b.po_status_ct 
                , funnel_status               = b.funnel_status                                  
                , datasource_origin_timestamp = b.datasource_origin_timestamp
                , PAY_GATEWAY_STATUS          = b.PAY_GATEWAY_STATUS
                , PO_PAYMENT_TYPE_STATUS      = b.PO_PAYMENT_TYPE_STATUS
                , PO_PLATAFORM_DATASOURCE     = b.PO_PLATAFORM_DATASOURCE
                , updated_timestamp           = current_timestamp
        WHEN NOT MATCHED THEN INSERT(
                po_date 
                , po_month 
                , po_year 
                , po_hour 
                , pay_subsidiary 
                , pay_code 
                , pay_id 
                , pay_date 
                , pay_month 
                , pay_year 
                , pay_hour 
                , pay_status 
                , pay_detail 
                , pay_gateway_code 
                , payment_type 
                , pay_gateway 
                , revenue_local 
                , pay_orderid 
                , pay_storename 
                , postoretype 
                , po_devicetype 
                , po_status 
                , order_status_type 
                , currency 
                , po_order_lastmodifydate 
                , postorename 
                , channel 
                , biz_type 
                , audience_type 
                , subsidiary 
                , pe_amount
                , revenu_usd
                , po_orderid 
                , pay_action 
                , pay_result 
                , pay_description 
                , pay_message 
                , po_internal_status
                , po_payment_type
                , po_paymentprovider
                , payment_card_brand
                , po_status_ct 
                , funnel_status 
                , datasource_origin_timestamp
                , PAY_GATEWAY_STATUS
                , PO_PAYMENT_TYPE_STATUS
                , PO_PLATAFORM_DATASOURCE
                )
                VALUES(
                b.po_date 
                , b.po_month 
                , b.po_year 
                , b.po_hour 
                , b.pay_subsidiary 
                , b.pay_code 
                , b.pay_id 
                , b.pay_date 
                , b.pay_month 
                , b.pay_year 
                , b.pay_hour 
                , b.pay_status 
                , b.pay_detail 
                , b.pay_gateway_code 
                , b.payment_type 
                , b.pay_gateway 
                , b.revenue_local 
                , b.pay_orderid 
                , b.pay_storename 
                , b.postoretype 
                , b.po_devicetype 
                , b.po_status 
                , b.order_status_type 
                , b.currency 
                , b.po_order_lastmodifydate 
                , b.postorename 
                , b.channel 
                , b.biz_type 
                , b.audience_type 
                , b.subsidiary 
                , b.pe_amount
                , b.revenu_usd
                , b.po_orderid 
                , b.pay_action 
                , b.pay_result 
                , b.pay_description 
                , b.pay_message 
                , b.po_internal_status
                , b.po_payment_type
                , b.po_paymentprovider
                , b.payment_card_brand
                , b.po_status_ct 
                , b.funnel_status 
                , b.datasource_origin_timestamp 
                , b.PAY_GATEWAY_STATUS
                , b.PO_PAYMENT_TYPE_STATUS
                , b.PO_PLATAFORM_DATASOURCE
                ); 
END;
$$;

-- CALL OW_LAO.PROC_ODS_SALES_PAYMENTS_VTEX_AR_DETAILS();
-- ERROR: Severity: ERROR, Message: Operator does not exist: varchar = timestamp, Sqlstate: 42883, Hint: No operator matches the given name and argument type(s). You may need to add explicit type casts, Where: PL/vSQL procedure PROC_ODS_SALES_PAYMENTS_VTEX_AR_DETAILS line 89 at static SQL, Routine: op_error, File: parse_oper.c, Line: 608, Error Code: 4286, 
-- CALL OW_LAO.PROC_ODS_SALES_PAYMENTS_VTEX_AR_DETAILS();
-- ERROR: Severity: ERROR, Message: Operator does not exist: varchar = timestamp, Sqlstate: 42883, Hint: No operator matches the given name and argument type(s). You may need to add explicit type casts, Where: PL/vSQL procedure PROC_ODS_SALES_PAYMENTS_VTEX_AR_DETAILS line 89 at static SQL, Routine: op_error, File: parse_oper.c, Line: 608, Error Code: 4286, 
CREATE OR REPLACE PROCEDURE OW_LAO.PROC_ODS_SALES_PAYMENTS_VTEX_AR_DETAILS()
LANGUAGE PLvSQL AS $$
BEGIN
    
    PERFORM TRUNCATE TABLE OW_LAO.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS;
        
    PERFORM INSERT INTO OW_LAO.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS
    SELECT DISTINCT
        NULL AS ID,
        CURRENT_TIMESTAMP AS INSERT_TIMESTAMP,
        CURRENT_TIMESTAMP AS UPDATED_TIMESTAMP,
        CAST(A.PO_DATE AS DATE) AS PO_DATE,
        A.PODATE_MONTH AS PO_MONTH,
        A.PODATE_YEAR AS PO_YEAR,
        EXTRACT(HOUR FROM A.PO_HOUR) AS PO_HOUR,
        A.SUBSIDIARY AS PAY_SUBSIDIARY,
        C.KEY_TRANSACTION_ID AS PAY_CODE,
        C.PAYMENT_ID AS PAY_ID,
        CAST(A.PO_DATE AS DATE) AS PAY_DATE, 
        A.PODATE_MONTH AS PAY_MONTH,
        A.PODATE_YEAR AS PAY_YEAR,
        EXTRACT(HOUR FROM A.PO_HOUR) AS PAY_HOUR,
        C.STATUS AS PAY_STATUS,
        A.PO_PAYMENT_REMARK AS PAY_DETAIL,
        C."SOURCE" AS PAY_GATEWAY_CODE, 
        A.PAYMENT_TYPE,
        C."SOURCE"             AS PAY_GATEWAY,
        CAST(NULL AS DECIMAL)  AS REVENUE_LOCAL,
        A.PO_ORDERID AS PAY_ORDERID,
        LOWER(A.PO_STORENAME) AS PAY_STORENAME,
        CAST(NULL AS VARCHAR(255)) AS POSTORETYPE,
        A.PO_DEVICETYPE,
        COALESCE(A.PO_INTERNAL_STATUS, 'incomplete') AS PO_STATUS,
        CAST(NULL AS VARCHAR(255)) AS ORDER_STATUS_TYPE,
        A.CURRENCY,
        C."DATE"       AS PO_ORDER_LASTMODIFYDATE,
        A.PO_STORENAME AS POSTORENAME,
        A.CHANNEL,
        A.BIZ_TYPE,
        A.AUDIENCE_TYPE,
        A.SUBSIDIARY ,
        CAST(NULL AS DECIMAL)  AS PE_AMOUNT,
        CAST(NULL AS DECIMAL)  AS REVENU_USD,
        A.PO_ORDERID, 
        CAST(NULL AS VARCHAR(255)) AS PAY_ACTION,
        CAST(NULL AS VARCHAR(255)) AS PAY_RESULT,
        CAST(NULL AS VARCHAR(255)) AS PAY_DESCRIPTION,
        C.MESSAGE AS PAY_MESSAGE,
        COALESCE(A.PO_INTERNAL_STATUS, 'incomplete') AS PO_INTERNAL_STATUS, 
        A.PAYMENT_TYPE AS PO_PAYMENT_TYPE,
        C."SOURCE" AS PO_PAYMENTPROVIDER,
        A.PAYMENT_CARD_BRAND AS PAYMENT_CARD_BRAND,
        A.PO_STATUS AS PO_STATUS_CT,
        CAST(NULL AS VARCHAR(255)) AS FUNNEL_STATUS,
        C."DATE" AS DATASOURCE_ORIGIN_TIMESTAMP,
        ROW_NUMBER() OVER (
                   PARTITION BY C.KEY_TRANSACTION_ID, B.ORDER_ID
                   ORDER BY C."DATE" DESC, B.VALUE DESC ) AS DEDUP,
        'VTEX_AR'                             as PO_PLATAFORM_DATASOURCE,
        CAST(NULL AS VARCHAR(255))           as PAY_GATEWAY_STATUS,
        CAST(NULL AS VARCHAR(255))           as PO_PAYMENT_TYPE_STATUS
    FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A
    JOIN U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER_PAYMENT B ON B.ORDER_ID = A.PO_ORDERID 
    JOIN OW_LAO.RAW_VTEX_PAYMENTS C ON     C.KEY_TRANSACTION_ID     = B.TRANSACTION_ID
                                      AND C.PAYMENT_ID         = B.PAYMENT_ID 
    WHERE    A.CLIENT_SUBSIDIARY_ID = 1
        AND PO_PLATAFORM_DATASOURCE = 'u_prj_ecom.raw_vtex_ssg_ar_sales_order'
      AND NOT EXISTS (
          SELECT 1
          FROM OW_LAO.ODS_PAYMENT_FUNNEL AA
          WHERE A.PO_ORDERID = AA.PO_ORDERID
            AND A.SUBSIDIARY = AA.SUBSIDIARY
            AND COALESCE(A.PO_INTERNAL_STATUS, 'incomplete') = COALESCE(AA.PO_INTERNAL_STATUS, 'incomplete')
      )
     ;
 
    -- DEDUP LAST UPDATE
    PERFORM DELETE 
      FROM OW_LAO.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS
     WHERE DEDUP != 1;     
 
    -- Update sales payments 
    PERFORM UPDATE OW_LAO.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS A
       SET REVENUE_LOCAL = B.VALUE  / 100 ,
           PE_AMOUNT     = B.VALUE  / 100 
      FROM U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER_PAYMENT B 
     WHERE B.ORDER_ID = A.PAY_ORDERID; 
 
    -- Update sales payments usd
    PERFORM UPDATE OW_LAO.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS A
       SET REVENU_USD = A.PE_AMOUNT / CAST(B.EXCHANGE_RATE AS DECIMAL)
      FROM OW_LAO.FT_AP2_EXCHANGE_RATE               B 
     WHERE CAST(B.VALID_FROM AS DATE) =  CAST(TIMESTAMPADD(DAY, -1, CAST(A.PO_DATE AS DATE)) AS DATE)
       AND LOWER(B.TO_CURRENCY) =  LOWER(A.CURRENCY);
 
    -- Update sales payments vtex AR status
    PERFORM UPDATE OW_LAO.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS A
       SET FUNNEL_STATUS = B.STATUS
      FROM ow_lao.DIM_PAYMENT_FUNNEL_STATUS_MAPPING B 
     WHERE A.PO_INTERNAL_STATUS          = B.PO_STATUS
       AND A.PAY_STATUS                  = B.PAY_STATUS 
       AND A.po_plataform_datasource     = B.data_source     
       AND B.ACTIVE = true; 
 
    -- Map gateway status            
    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS  a
       SET pay_gateway_status = b.gateway
      FROM ow_lao.dim_payment_pay_gateway_mapping       b 
     WHERE b.data_source = a.po_plataform_datasource 
       AND b.pay_gateway = a.pay_gateway
       AND b.active = true;     
      
    -- Map payment type status   
    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS  a
       SET po_payment_type_status = b.payment_mode
      FROM ow_lao.dim_payment_type_mapping                b 
     WHERE b.data_source   = a.po_plataform_datasource 
       AND b.payment_type  = a.payment_type
       AND b.active = true;     
 
 
    -- Upsert into ODS_PAYMENT_FUNNEL for VTEX AR Payments
    PERFORM MERGE INTO 
            ow_lao.ODS_PAYMENT_FUNNEL a
        USING ow_lao.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS b
           ON b.pay_orderid    = a.pay_orderid
          AND b.pay_subsidiary = a.pay_subsidiary
        WHEN MATCHED THEN UPDATE 
            SET   po_date                     = b.po_date 
                , po_month                    = b.po_month 
                , po_year                     = b.po_year 
                , po_hour                     = b.po_hour 
                , pay_subsidiary              = b.pay_subsidiary 
                , pay_code                    = b.pay_code 
                , pay_id                      = b.pay_id 
                , pay_date                    = b.pay_date 
                , pay_month                   = b.pay_month 
                , pay_year                    = b.pay_year 
                , pay_hour                    = b.pay_hour 
                , pay_status                  = b.pay_status 
                , pay_detail                  = b.pay_detail 
                , pay_gateway_code            = b.pay_gateway_code 
                , payment_type                = b.payment_type 
                , pay_gateway                 = b.pay_gateway 
                , revenue_local               = b.revenue_local 
                , pay_orderid                 = b.pay_orderid 
                , pay_storename               = b.pay_storename 
                , postoretype                 = b.postoretype 
                , po_devicetype               = b.po_devicetype 
                , po_status                   = b.po_status 
                , order_status_type           = b.order_status_type 
                , currency                    = b.currency 
                , po_order_lastmodifydate     = b.po_order_lastmodifydate 
                , postorename                 = b.postorename 
                , channel                     = b.channel 
                , biz_type                    = b.biz_type 
                , audience_type               = b.audience_type 
                , subsidiary                  = b.subsidiary 
                , pe_amount                   = b.pe_amount
                , revenu_usd                  = b.revenu_usd
                , po_orderid                  = b.po_orderid 
                , pay_action                  = b.pay_action 
                , pay_result                  = b.pay_result 
                , pay_description             = b.pay_description 
                , pay_message                 = b.pay_message 
                , po_internal_status          = b.po_internal_status
                , po_payment_type             = b.po_payment_type
                , po_paymentprovider          = b.po_paymentprovider
                , payment_card_brand          = b.payment_card_brand
                , po_status_ct                = b.po_status_ct 
                , funnel_status               = b.funnel_status                                  
                , datasource_origin_timestamp = b.datasource_origin_timestamp
                , PAY_GATEWAY_STATUS          = b.PAY_GATEWAY_STATUS
                , PO_PAYMENT_TYPE_STATUS      = b.PO_PAYMENT_TYPE_STATUS
                , PO_PLATAFORM_DATASOURCE     = b.PO_PLATAFORM_DATASOURCE
                , updated_timestamp           = current_timestamp
        WHEN NOT MATCHED THEN INSERT(
                po_date 
                , po_month 
                , po_year 
                , po_hour 
                , pay_subsidiary 
                , pay_code 
                , pay_id 
                , pay_date 
                , pay_month 
                , pay_year 
                , pay_hour 
                , pay_status 
                , pay_detail 
                , pay_gateway_code 
                , payment_type 
                , pay_gateway 
                , revenue_local 
                , pay_orderid 
                , pay_storename 
                , postoretype 
                , po_devicetype 
                , po_status 
                , order_status_type 
                , currency 
                , po_order_lastmodifydate 
                , postorename 
                , channel 
                , biz_type 
                , audience_type 
                , subsidiary 
                , pe_amount
                , revenu_usd
                , po_orderid 
                , pay_action 
                , pay_result 
                , pay_description 
                , pay_message 
                , po_internal_status
                , po_payment_type
                , po_paymentprovider
                , payment_card_brand
                , po_status_ct 
                , funnel_status 
                , datasource_origin_timestamp
                , PAY_GATEWAY_STATUS
                , PO_PAYMENT_TYPE_STATUS
                , PO_PLATAFORM_DATASOURCE
                )
                VALUES(
                b.po_date 
                , b.po_month 
                , b.po_year 
                , b.po_hour 
                , b.pay_subsidiary 
                , b.pay_code 
                , b.pay_id 
                , b.pay_date 
                , b.pay_month 
                , b.pay_year 
                , b.pay_hour 
                , b.pay_status 
                , b.pay_detail 
                , b.pay_gateway_code 
                , b.payment_type 
                , b.pay_gateway 
                , b.revenue_local 
                , b.pay_orderid 
                , b.pay_storename 
                , b.postoretype 
                , b.po_devicetype 
                , b.po_status 
                , b.order_status_type 
                , b.currency 
                , b.po_order_lastmodifydate 
                , b.postorename 
                , b.channel 
                , b.biz_type 
                , b.audience_type 
                , b.subsidiary 
                , b.pe_amount
                , b.revenu_usd
                , b.po_orderid 
                , b.pay_action 
                , b.pay_result 
                , b.pay_description 
                , b.pay_message 
                , b.po_internal_status
                , b.po_payment_type
                , b.po_paymentprovider
                , b.payment_card_brand
                , b.po_status_ct 
                , b.funnel_status 
                , b.datasource_origin_timestamp 
                , b.PAY_GATEWAY_STATUS
                , b.PO_PAYMENT_TYPE_STATUS
                , b.PO_PLATAFORM_DATASOURCE
                ); 
END;
$$;

-- CALL OW_LAO.PROC_ODS_SALES_PAYMENTS_VTEX_AR_DETAILS();
-- ERROR: Severity: ERROR, Message: Column "datasource_origin_timestamp" is of type timestamp but expression is of type varchar, Sqlstate: 42804, Hint: You will need to rewrite or cast the expression, Where: PL/vSQL procedure PROC_ODS_SALES_PAYMENTS_VTEX_AR_DETAILS line 122 at static SQL, Routine: updateTargetListEntry, File: parse_target.c, Line: 853, Error Code: 2631, 
-- CALL OW_LAO.PROC_ODS_SALES_PAYMENTS_VTEX_AR_DETAILS();
-- ERROR: Severity: ERROR, Message: Column "datasource_origin_timestamp" is of type timestamp but expression is of type varchar, Sqlstate: 42804, Hint: You will need to rewrite or cast the expression, Where: PL/vSQL procedure PROC_ODS_SALES_PAYMENTS_VTEX_AR_DETAILS line 122 at static SQL, Routine: updateTargetListEntry, File: parse_target.c, Line: 853, Error Code: 2631, 
CREATE OR REPLACE PROCEDURE OW_LAO.PROC_ODS_SALES_PAYMENTS_VTEX_AR_DETAILS()
LANGUAGE PLvSQL AS $$
BEGIN
    
    PERFORM TRUNCATE TABLE OW_LAO.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS;
        
    PERFORM INSERT INTO OW_LAO.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS
    SELECT DISTINCT
        NULL AS ID,
        CURRENT_TIMESTAMP AS INSERT_TIMESTAMP,
        CURRENT_TIMESTAMP AS UPDATED_TIMESTAMP,
        CAST(A.PO_DATE AS DATE) AS PO_DATE,
        A.PODATE_MONTH AS PO_MONTH,
        A.PODATE_YEAR AS PO_YEAR,
        EXTRACT(HOUR FROM A.PO_HOUR) AS PO_HOUR,
        A.SUBSIDIARY AS PAY_SUBSIDIARY,
        C.KEY_TRANSACTION_ID AS PAY_CODE,
        C.PAYMENT_ID AS PAY_ID,
        CAST(A.PO_DATE AS DATE) AS PAY_DATE, 
        A.PODATE_MONTH AS PAY_MONTH,
        A.PODATE_YEAR AS PAY_YEAR,
        EXTRACT(HOUR FROM A.PO_HOUR) AS PAY_HOUR,
        C.STATUS AS PAY_STATUS,
        A.PO_PAYMENT_REMARK AS PAY_DETAIL,
        C."SOURCE" AS PAY_GATEWAY_CODE, 
        A.PAYMENT_TYPE,
        C."SOURCE"             AS PAY_GATEWAY,
        CAST(NULL AS DECIMAL)  AS REVENUE_LOCAL,
        A.PO_ORDERID AS PAY_ORDERID,
        LOWER(A.PO_STORENAME) AS PAY_STORENAME,
        CAST(NULL AS VARCHAR(255)) AS POSTORETYPE,
        A.PO_DEVICETYPE,
        COALESCE(A.PO_INTERNAL_STATUS, 'incomplete') AS PO_STATUS,
        CAST(NULL AS VARCHAR(255)) AS ORDER_STATUS_TYPE,
        A.CURRENCY,
        C."DATE"       AS PO_ORDER_LASTMODIFYDATE,
        A.PO_STORENAME AS POSTORENAME,
        A.CHANNEL,
        A.BIZ_TYPE,
        A.AUDIENCE_TYPE,
        A.SUBSIDIARY ,
        CAST(NULL AS DECIMAL)  AS PE_AMOUNT,
        CAST(NULL AS DECIMAL)  AS REVENU_USD,
        A.PO_ORDERID, 
        CAST(NULL AS VARCHAR(255)) AS PAY_ACTION,
        CAST(NULL AS VARCHAR(255)) AS PAY_RESULT,
        CAST(NULL AS VARCHAR(255)) AS PAY_DESCRIPTION,
        C.MESSAGE AS PAY_MESSAGE,
        COALESCE(A.PO_INTERNAL_STATUS, 'incomplete') AS PO_INTERNAL_STATUS, 
        A.PAYMENT_TYPE AS PO_PAYMENT_TYPE,
        C."SOURCE" AS PO_PAYMENTPROVIDER,
        A.PAYMENT_CARD_BRAND AS PAYMENT_CARD_BRAND,
        A.PO_STATUS AS PO_STATUS_CT,
        CAST(NULL AS VARCHAR(255)) AS FUNNEL_STATUS,
        CAST(C."DATE" AS TIMESTAMP) AS DATASOURCE_ORIGIN_TIMESTAMP,
        ROW_NUMBER() OVER (
                   PARTITION BY C.KEY_TRANSACTION_ID, B.ORDER_ID
                   ORDER BY C."DATE" DESC, B.VALUE DESC ) AS DEDUP,
        'VTEX_AR'                             as PO_PLATAFORM_DATASOURCE,
        CAST(NULL AS VARCHAR(255))           as PAY_GATEWAY_STATUS,
        CAST(NULL AS VARCHAR(255))           as PO_PAYMENT_TYPE_STATUS
    FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A
    JOIN U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER_PAYMENT B ON B.ORDER_ID = A.PO_ORDERID 
    JOIN OW_LAO.RAW_VTEX_PAYMENTS C ON     C.KEY_TRANSACTION_ID     = B.TRANSACTION_ID
                                      AND C.PAYMENT_ID         = B.PAYMENT_ID 
    WHERE    A.CLIENT_SUBSIDIARY_ID = 1
        AND PO_PLATAFORM_DATASOURCE = 'u_prj_ecom.raw_vtex_ssg_ar_sales_order'
      AND NOT EXISTS (
          SELECT 1
          FROM OW_LAO.ODS_PAYMENT_FUNNEL AA
          WHERE A.PO_ORDERID = AA.PO_ORDERID
            AND A.SUBSIDIARY = AA.SUBSIDIARY
            AND COALESCE(A.PO_INTERNAL_STATUS, 'incomplete') = COALESCE(AA.PO_INTERNAL_STATUS, 'incomplete')
      )
     ;
 
    -- DEDUP LAST UPDATE
    PERFORM DELETE 
      FROM OW_LAO.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS
     WHERE DEDUP != 1;     
 
    -- Update sales payments 
    PERFORM UPDATE OW_LAO.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS A
       SET REVENUE_LOCAL = B.VALUE  / 100 ,
           PE_AMOUNT     = B.VALUE  / 100 
      FROM U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER_PAYMENT B 
     WHERE B.ORDER_ID = A.PAY_ORDERID; 
 
    -- Update sales payments usd
    PERFORM UPDATE OW_LAO.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS A
       SET REVENU_USD = A.PE_AMOUNT / CAST(B.EXCHANGE_RATE AS DECIMAL)
      FROM OW_LAO.FT_AP2_EXCHANGE_RATE               B 
     WHERE CAST(B.VALID_FROM AS DATE) =  CAST(TIMESTAMPADD(DAY, -1, CAST(A.PO_DATE AS DATE)) AS DATE)
       AND LOWER(B.TO_CURRENCY) =  LOWER(A.CURRENCY);
 
    -- Update sales payments vtex AR status
    PERFORM UPDATE OW_LAO.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS A
       SET FUNNEL_STATUS = B.STATUS
      FROM ow_lao.DIM_PAYMENT_FUNNEL_STATUS_MAPPING B 
     WHERE A.PO_INTERNAL_STATUS          = B.PO_STATUS
       AND A.PAY_STATUS                  = B.PAY_STATUS 
       AND A.po_plataform_datasource     = B.data_source     
       AND B.ACTIVE = true; 
 
    -- Map gateway status            
    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS  a
       SET pay_gateway_status = b.gateway
      FROM ow_lao.dim_payment_pay_gateway_mapping       b 
     WHERE b.data_source = a.po_plataform_datasource 
       AND b.pay_gateway = a.pay_gateway
       AND b.active = true;     
      
    -- Map payment type status   
    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS  a
       SET po_payment_type_status = b.payment_mode
      FROM ow_lao.dim_payment_type_mapping                b 
     WHERE b.data_source   = a.po_plataform_datasource 
       AND b.payment_type  = a.payment_type
       AND b.active = true;     
 
 
    -- Upsert into ODS_PAYMENT_FUNNEL for VTEX AR Payments
    PERFORM MERGE INTO 
            ow_lao.ODS_PAYMENT_FUNNEL a
        USING ow_lao.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS b
           ON b.pay_orderid    = a.pay_orderid
          AND b.pay_subsidiary = a.pay_subsidiary
        WHEN MATCHED THEN UPDATE 
            SET   po_date                     = b.po_date 
                , po_month                    = b.po_month 
                , po_year                     = b.po_year 
                , po_hour                     = b.po_hour 
                , pay_subsidiary              = b.pay_subsidiary 
                , pay_code                    = b.pay_code 
                , pay_id                      = b.pay_id 
                , pay_date                    = b.pay_date 
                , pay_month                   = b.pay_month 
                , pay_year                    = b.pay_year 
                , pay_hour                    = b.pay_hour 
                , pay_status                  = b.pay_status 
                , pay_detail                  = b.pay_detail 
                , pay_gateway_code            = b.pay_gateway_code 
                , payment_type                = b.payment_type 
                , pay_gateway                 = b.pay_gateway 
                , revenue_local               = b.revenue_local 
                , pay_orderid                 = b.pay_orderid 
                , pay_storename               = b.pay_storename 
                , postoretype                 = b.postoretype 
                , po_devicetype               = b.po_devicetype 
                , po_status                   = b.po_status 
                , order_status_type           = b.order_status_type 
                , currency                    = b.currency 
                , po_order_lastmodifydate     = b.po_order_lastmodifYdate 
                , postorename                 = b.postorename 
                , channel                     = b.channel 
                , biz_type                    = b.biz_type 
                , audience_type               = b.audience_type 
                , subsidiary                  = b.subsidiary 
                , pe_amount                   = b.pe_amount
                , revenu_usd                  = b.revenu_usd
                , po_orderid                  = b.po_orderid 
                , pay_action                  = b.pay_action 
                , pay_result                  = b.pay_result 
                , pay_description             = b.pay_description 
                , pay_message                 = b.pay_message 
                , po_internal_status          = b.po_internal_status
                , po_payment_type             = b.po_payment_type
                , po_paymentprovider          = b.po_paymentprovider
                , payment_card_brand          = b.payment_card_brand
                , po_status_ct                = b.po_status_ct 
                , funnel_status               = b.funnel_status                                  
                , datasource_origin_timestamp = CAST(b.datasource_origin_timestamp AS TIMESTAMP)
                , PAY_GATEWAY_STATUS          = b.PAY_GATEWAY_STATUS
                , PO_PAYMENT_TYPE_STATUS      = b.PO_PAYMENT_TYPE_STATUS
                , PO_PLATAFORM_DATASOURCE     = b.PO_PLATAFORM_DATASOURCE
                , updated_timestamp           = current_timestamp
        WHEN NOT MATCHED THEN INSERT(
                po_date 
                , po_month 
                , po_year 
                , po_hour 
                , pay_subsidiary 
                , pay_code 
                , pay_id 
                , pay_date 
                , pay_month 
                , pay_year 
                , pay_hour 
                , pay_status 
                , pay_detail 
                , pay_gateway_code 
                , payment_type 
                , pay_gateway 
                , revenue_local 
                , pay_orderid 
                , pay_storename 
                , postoretype 
                , po_devicetype 
                , po_status 
                , order_status_type 
                , currency 
                , po_order_lastmodifydate 
                , postorename 
                , channel 
                , biz_type 
                , audience_type 
                , subsidiary 
                , pe_amount
                , revenu_usd
                , po_orderid 
                , pay_action 
                , pay_result 
                , pay_description 
                , pay_message 
                , po_internal_status
                , po_payment_type
                , po_paymentprovider
                , payment_card_brand
                , po_status_ct 
                , funnel_status 
                , datasource_origin_timestamp
                , PAY_GATEWAY_STATUS
                , PO_PAYMENT_TYPE_STATUS
                , PO_PLATAFORM_DATASOURCE
                )
                VALUES(
                b.po_date 
                , b.po_month 
                , b.po_year 
                , b.po_hour 
                , b.pay_subsidiary 
                , b.pay_code 
                , b.pay_id 
                , b.pay_date 
                , b.pay_month 
                , b.pay_year 
                , b.pay_hour 
                , b.pay_status 
                , b.pay_detail 
                , b.pay_gateway_code 
                , b.payment_type 
                , b.pay_gateway 
                , b.revenue_local 
                , b.pay_orderid 
                , b.pay_storename 
                , b.postoretype 
                , b.po_devicetype 
                , b.po_status 
                , b.order_status_type 
                , b.currency 
                , b.po_order_lastmodifydate 
                , b.postorename 
                , b.channel 
                , b.biz_type 
                , b.audience_type 
                , b.subsidiary 
                , b.pe_amount
                , b.revenu_usd
                , b.po_orderid 
                , b.pay_action 
                , b.pay_result 
                , b.pay_description 
                , b.pay_message 
                , b.po_internal_status
                , b.po_payment_type
                , b.po_paymentprovider
                , b.payment_card_brand
                , b.po_status_ct 
                , b.funnel_status 
                , CAST(b.datasource_origin_timestamp AS TIMESTAMP)
                , b.PAY_GATEWAY_STATUS
                , b.PO_PAYMENT_TYPE_STATUS
                , b.PO_PLATAFORM_DATASOURCE
                ); 
END;
$$;

-- CALL OW_LAO.PROC_ODS_SALES_PAYMENTS_VTEX_AR_DETAILS();
-- ERROR: Severity: ERROR, Message: Cannot set a NOT NULL column (ID) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure PROC_ODS_SALES_PAYMENTS_VTEX_AR_DETAILS line 122 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3216, Error Code: 2502, 
-- CALL OW_LAO.PROC_ODS_SALES_PAYMENTS_VTEX_AR_DETAILS();
-- ERROR: Severity: ERROR, Message: Cannot set a NOT NULL column (ID) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure PROC_ODS_SALES_PAYMENTS_VTEX_AR_DETAILS line 122 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3216, Error Code: 2502, 
SELECT table_schema, table_name, column_name, data_type, is_nullable, column_default FROM v_catalog.columns WHERE table_schema='OW_LAO' AND table_name IN ('TMP_SALES_PAYMENTS_VTEX_AR_DETAILS','ODS_PAYMENT_FUNNEL') ORDER BY table_name, ordinal_position;
-- table_schema | table_name | column_name | data_type | is_nullable | column_default
-- -------------+------------+-------------+-----------+-------------+---------------
-- OW_LAO | ODS_PAYMENT_FUNNEL | ID | int | False | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | INSERT_TIMESTAMP | timestamp | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | UPDATED_TIMESTAMP | timestamp | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PO_DATE | date | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PO_MONTH | int | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PO_YEAR | int | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PO_HOUR | int | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PAY_SUBSIDIARY | varchar(1000) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PAY_CODE | varchar(1000) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PAY_ID | varchar(1000) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PAY_DATE | date | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PAY_MONTH | int | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PAY_YEAR | int | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PAY_HOUR | int | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PAY_STATUS | varchar(1000) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PAY_DETAIL | varchar(1000) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PAY_GATEWAY_CODE | varchar(1000) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PAYMENT_TYPE | varchar(1000) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PAY_GATEWAY | varchar(1000) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | REVENUE_LOCAL | varchar(1000) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PAY_ORDERID | varchar(1000) | False | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PAY_STORENAME | varchar(1000) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | POSTORETYPE | varchar(1000) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PO_DEVICETYPE | varchar(1000) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PO_STATUS | varchar(1000) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | ORDER_STATUS_TYPE | varchar(1000) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | CURRENCY | varchar(1000) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PO_ORDER_LASTMODIFYDATE | varchar(1000) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | POSTORENAME | varchar(155) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | CHANNEL | varchar(50) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | BIZ_TYPE | varchar(3) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | AUDIENCE_TYPE | varchar(20) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | SUBSIDIARY | varchar(50) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PE_AMOUNT | varchar(1000) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | REVENU_USD | numeric(34,0) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PO_ORDERID | varchar(255) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PAY_ACTION | varchar(255) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PAY_RESULT | varchar(255) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PAY_DESCRIPTION | varchar(1000) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PAY_MESSAGE | varchar(5000) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PO_INTERNAL_STATUS | varchar(255) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PO_PAYMENT_TYPE | varchar(255) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PO_PAYMENTPROVIDER | varchar(255) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PAYMENT_CARD_BRAND | varchar(255) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PO_STATUS_CT | varchar(255) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | FUNNEL_STATUS | varchar(255) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | DATASOURCE_ORIGIN_TIMESTAMP | timestamp | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PO_PLATAFORM_DATASOURCE | varchar(255) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PAY_GATEWAY_STATUS | varchar(255) | True | 
-- OW_LAO | ODS_PAYMENT_FUNNEL | PO_PAYMENT_TYPE_STATUS | varchar(255) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | ID | varchar(1) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | INSERT_TIMESTAMP | timestamp | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | UPDATED_TIMESTAMP | timestamp | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PO_DATE | date | False | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PO_MONTH | int | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PO_YEAR | int | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PO_HOUR | int | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PAY_SUBSIDIARY | varchar(10) | False | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PAY_CODE | varchar(4000) | False | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PAY_ID | varchar(4000) | False | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PAY_DATE | date | False | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PAY_MONTH | int | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PAY_YEAR | int | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PAY_HOUR | int | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PAY_STATUS | varchar(4000) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PAY_DETAIL | varchar(2000) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PAY_GATEWAY_CODE | varchar(4000) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PAYMENT_TYPE | varchar(1000) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PAY_GATEWAY | varchar(4000) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | REVENUE_LOCAL | numeric(34,0) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PAY_ORDERID | varchar(50) | False | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PAY_STORENAME | varchar(255) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | POSTORETYPE | varchar(255) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PO_DEVICETYPE | varchar(255) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PO_STATUS | varchar(255) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | ORDER_STATUS_TYPE | varchar(255) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | CURRENCY | varchar(3) | False | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PO_ORDER_LASTMODIFYDATE | varchar(4000) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | POSTORENAME | varchar(255) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | CHANNEL | varchar(255) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | BIZ_TYPE | varchar(255) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | AUDIENCE_TYPE | varchar(255) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | SUBSIDIARY | varchar(10) | False | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PE_AMOUNT | numeric(34,0) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | REVENU_USD | numeric(34,0) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PO_ORDERID | varchar(50) | False | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PAY_ACTION | varchar(255) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PAY_RESULT | varchar(255) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PAY_DESCRIPTION | varchar(255) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PAY_MESSAGE | varchar(4000) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PO_INTERNAL_STATUS | varchar(255) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PO_PAYMENT_TYPE | varchar(1000) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PO_PAYMENTPROVIDER | varchar(4000) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PAYMENT_CARD_BRAND | varchar(1000) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PO_STATUS_CT | varchar(1000) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | FUNNEL_STATUS | varchar(255) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | DATASOURCE_ORIGIN_TIMESTAMP | varchar(4000) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | DEDUP | int | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PO_PLATAFORM_DATASOURCE | varchar(255) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PAY_GATEWAY_STATUS | varchar(255) | True | 
-- OW_LAO | TMP_SALES_PAYMENTS_VTEX_AR_DETAILS | PO_PAYMENT_TYPE_STATUS | varchar(255) | True | 

CREATE OR REPLACE PROCEDURE OW_LAO.PROC_ODS_SALES_PAYMENTS_VTEX_AR_DETAILS()
LANGUAGE PLvSQL AS $$
DECLARE base_id INT;
BEGIN
    
    PERFORM TRUNCATE TABLE OW_LAO.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS;
        
    PERFORM INSERT INTO OW_LAO.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS
    SELECT DISTINCT
        NULL AS ID,
        CURRENT_TIMESTAMP AS INSERT_TIMESTAMP,
        CURRENT_TIMESTAMP AS UPDATED_TIMESTAMP,
        CAST(A.PO_DATE AS DATE) AS PO_DATE,
        A.PODATE_MONTH AS PO_MONTH,
        A.PODATE_YEAR AS PO_YEAR,
        EXTRACT(HOUR FROM A.PO_HOUR) AS PO_HOUR,
        A.SUBSIDIARY AS PAY_SUBSIDIARY,
        C.KEY_TRANSACTION_ID AS PAY_CODE,
        C.PAYMENT_ID AS PAY_ID,
        CAST(A.PO_DATE AS DATE) AS PAY_DATE, 
        A.PODATE_MONTH AS PAY_MONTH,
        A.PODATE_YEAR AS PAY_YEAR,
        EXTRACT(HOUR FROM A.PO_HOUR) AS PAY_HOUR,
        C.STATUS AS PAY_STATUS,
        A.PO_PAYMENT_REMARK AS PAY_DETAIL,
        C."SOURCE" AS PAY_GATEWAY_CODE, 
        A.PAYMENT_TYPE,
        C."SOURCE"             AS PAY_GATEWAY,
        CAST(NULL AS DECIMAL)  AS REVENUE_LOCAL,
        A.PO_ORDERID AS PAY_ORDERID,
        LOWER(A.PO_STORENAME) AS PAY_STORENAME,
        CAST(NULL AS VARCHAR(255)) AS POSTORETYPE,
        A.PO_DEVICETYPE,
        COALESCE(A.PO_INTERNAL_STATUS, 'incomplete') AS PO_STATUS,
        CAST(NULL AS VARCHAR(255)) AS ORDER_STATUS_TYPE,
        A.CURRENCY,
        C."DATE"       AS PO_ORDER_LASTMODIFYDATE,
        A.PO_STORENAME AS POSTORENAME,
        A.CHANNEL,
        A.BIZ_TYPE,
        A.AUDIENCE_TYPE,
        A.SUBSIDIARY ,
        CAST(NULL AS DECIMAL)  AS PE_AMOUNT,
        CAST(NULL AS DECIMAL)  AS REVENU_USD,
        A.PO_ORDERID, 
        CAST(NULL AS VARCHAR(255)) AS PAY_ACTION,
        CAST(NULL AS VARCHAR(255)) AS PAY_RESULT,
        CAST(NULL AS VARCHAR(255)) AS PAY_DESCRIPTION,
        C.MESSAGE AS PAY_MESSAGE,
        COALESCE(A.PO_INTERNAL_STATUS, 'incomplete') AS PO_INTERNAL_STATUS, 
        A.PAYMENT_TYPE AS PO_PAYMENT_TYPE,
        C."SOURCE" AS PO_PAYMENTPROVIDER,
        A.PAYMENT_CARD_BRAND AS PAYMENT_CARD_BRAND,
        A.PO_STATUS AS PO_STATUS_CT,
        CAST(NULL AS VARCHAR(255)) AS FUNNEL_STATUS,
        C."DATE" AS DATASOURCE_ORIGIN_TIMESTAMP,
        ROW_NUMBER() OVER (
                   PARTITION BY C.KEY_TRANSACTION_ID, B.ORDER_ID
                   ORDER BY C."DATE" DESC, B.VALUE DESC ) AS DEDUP,
        'VTEX_AR'                             as PO_PLATAFORM_DATASOURCE,
        CAST(NULL AS VARCHAR(255))           as PAY_GATEWAY_STATUS,
        CAST(NULL AS VARCHAR(255))           as PO_PAYMENT_TYPE_STATUS
    FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A
    JOIN U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER_PAYMENT B ON B.ORDER_ID = A.PO_ORDERID 
    JOIN OW_LAO.RAW_VTEX_PAYMENTS C ON     C.KEY_TRANSACTION_ID     = B.TRANSACTION_ID
                                      AND C.PAYMENT_ID         = B.PAYMENT_ID 
    WHERE    A.CLIENT_SUBSIDIARY_ID = 1
        AND PO_PLATAFORM_DATASOURCE = 'u_prj_ecom.raw_vtex_ssg_ar_sales_order'
      AND NOT EXISTS (
          SELECT 1
          FROM OW_LAO.ODS_PAYMENT_FUNNEL AA
          WHERE A.PO_ORDERID = AA.PO_ORDERID
            AND A.SUBSIDIARY = AA.SUBSIDIARY
            AND COALESCE(A.PO_INTERNAL_STATUS, 'incomplete') = COALESCE(AA.PO_INTERNAL_STATUS, 'incomplete')
      )
     ;
 
    -- DEDUP LAST UPDATE
    PERFORM DELETE 
      FROM OW_LAO.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS
     WHERE DEDUP != 1;     
 
    -- Update sales payments 
    PERFORM UPDATE OW_LAO.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS A
       SET REVENUE_LOCAL = B.VALUE  / 100 ,
           PE_AMOUNT     = B.VALUE  / 100 
      FROM U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER_PAYMENT B 
     WHERE B.ORDER_ID = A.PAY_ORDERID; 
 
    -- Update sales payments usd
    PERFORM UPDATE OW_LAO.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS A
       SET REVENU_USD = A.PE_AMOUNT / CAST(B.EXCHANGE_RATE AS DECIMAL)
      FROM OW_LAO.FT_AP2_EXCHANGE_RATE               B 
     WHERE CAST(B.VALID_FROM AS DATE) =  CAST(TIMESTAMPADD(DAY, -1, CAST(A.PO_DATE AS DATE)) AS DATE)
       AND LOWER(B.TO_CURRENCY) =  LOWER(A.CURRENCY);
 
    -- Update sales payments vtex AR status
    PERFORM UPDATE OW_LAO.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS A
       SET FUNNEL_STATUS = B.STATUS
      FROM ow_lao.DIM_PAYMENT_FUNNEL_STATUS_MAPPING B 
     WHERE A.PO_INTERNAL_STATUS          = B.PO_STATUS
       AND A.PAY_STATUS                  = B.PAY_STATUS 
       AND A.po_plataform_datasource     = B.data_source     
       AND B.ACTIVE = true; 
 
    -- Map gateway status            
    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS  a
       SET pay_gateway_status = b.gateway
      FROM ow_lao.dim_payment_pay_gateway_mapping       b 
     WHERE b.data_source = a.po_plataform_datasource 
       AND b.pay_gateway = a.pay_gateway
       AND b.active = true;     
      
    -- Map payment type status   
    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS  a
       SET po_payment_type_status = b.payment_mode
      FROM ow_lao.dim_payment_type_mapping                b 
     WHERE b.data_source   = a.po_plataform_datasource 
       AND b.payment_type  = a.payment_type
       AND b.active = true;     
 
 
    -- Update existing rows in ODS_PAYMENT_FUNNEL
    PERFORM UPDATE ow_lao.ODS_PAYMENT_FUNNEL a
       SET   po_date                     = b.po_date 
           , po_month                    = b.po_month 
           , po_year                     = b.po_year 
           , po_hour                     = b.po_hour 
           , pay_subsidiary              = b.pay_subsidiary 
           , pay_code                    = b.pay_code 
           , pay_id                      = b.pay_id 
           , pay_date                    = b.pay_date 
           , pay_month                   = b.pay_month 
           , pay_year                    = b.pay_year 
           , pay_hour                    = b.pay_hour 
           , pay_status                  = b.pay_status 
           , pay_detail                  = b.pay_detail 
           , pay_gateway_code            = b.pay_gateway_code 
           , payment_type                = b.payment_type 
           , pay_gateway                 = b.pay_gateway 
           , revenue_local               = b.revenue_local::varchar 
           , pay_orderid                 = b.pay_orderid 
           , pay_storename               = b.pay_storename 
           , postoretype                 = b.postoretype 
           , po_devicetype               = b.po_devicetype 
           , po_status                   = b.po_status 
           , order_status_type           = b.order_status_type 
           , currency                    = b.currency 
           , po_order_lastmodifydate     = b.po_order_lastmodifydate 
           , postorename                 = b.postorename 
           , channel                     = b.channel 
           , biz_type                    = b.biz_type 
           , audience_type               = b.audience_type 
           , subsidiary                  = b.subsidiary 
           , pe_amount                   = b.pe_amount::varchar
           , revenu_usd                  = b.revenu_usd
           , po_orderid                  = b.po_orderid 
           , pay_action                  = b.pay_action 
           , pay_result                  = b.pay_result 
           , pay_description             = b.pay_description 
           , pay_message                 = b.pay_message 
           , po_internal_status          = b.po_internal_status
           , po_payment_type             = b.po_payment_type
           , po_paymentprovider          = b.po_paymentprovider
           , payment_card_brand          = b.payment_card_brand
           , po_status_ct                = b.po_status_ct 
           , funnel_status               = b.funnel_status                                  
           , datasource_origin_timestamp = CAST(b.datasource_origin_timestamp AS TIMESTAMP)
           , PAY_GATEWAY_STATUS          = b.PAY_GATEWAY_STATUS
           , PO_PAYMENT_TYPE_STATUS      = b.PO_PAYMENT_TYPE_STATUS
           , PO_PLATAFORM_DATASOURCE     = b.PO_PLATAFORM_DATASOURCE
           , updated_timestamp           = current_timestamp
      FROM ow_lao.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS b
     WHERE b.pay_orderid    = a.pay_orderid
       AND b.pay_subsidiary = a.pay_subsidiary;

    -- Prepare base ID for inserts
    SELECT COALESCE(MAX(ID),0) INTO base_id FROM ow_lao.ODS_PAYMENT_FUNNEL;

    -- Insert new rows with generated IDs
    PERFORM INSERT INTO ow_lao.ODS_PAYMENT_FUNNEL (
        ID, INSERT_TIMESTAMP, UPDATED_TIMESTAMP, 
        po_date, po_month, po_year, po_hour, 
        pay_subsidiary, pay_code, pay_id, pay_date, pay_month, pay_year, pay_hour, 
        pay_status, pay_detail, pay_gateway_code, payment_type, pay_gateway, revenue_local, 
        pay_orderid, pay_storename, postoretype, po_devicetype, po_status, order_status_type, 
        currency, po_order_lastmodifydate, postorename, channel, biz_type, audience_type, 
        subsidiary, pe_amount, revenu_usd, po_orderid, pay_action, pay_result, pay_description, 
        pay_message, po_internal_status, po_payment_type, po_paymentprovider, payment_card_brand, 
        po_status_ct, funnel_status, datasource_origin_timestamp, 
        PO_PLATAFORM_DATASOURCE, PAY_GATEWAY_STATUS, PO_PAYMENT_TYPE_STATUS
    )
    SELECT 
        base_id + ROW_NUMBER() OVER (ORDER BY b.pay_orderid, b.pay_subsidiary) AS ID,
        CURRENT_TIMESTAMP, NULL,
        b.po_date, b.po_month, b.po_year, b.po_hour,
        b.pay_subsidiary, b.pay_code, b.pay_id, b.pay_date, b.pay_month, b.pay_year, b.pay_hour,
        b.pay_status, b.pay_detail, b.pay_gateway_code, b.payment_type, b.pay_gateway, b.revenue_local::varchar,
        b.pay_orderid, b.pay_storename, b.postoretype, b.po_devicetype, b.po_status, b.order_status_type,
        b.currency, b.po_order_lastmodifydate, b.postorename, b.channel, b.biz_type, b.audience_type,
        b.subsidiary, b.pe_amount::varchar, b.revenu_usd, b.po_orderid, b.pay_action, b.pay_result, b.pay_description,
        b.pay_message, b.po_internal_status, b.po_payment_type, b.po_paymentprovider, b.payment_card_brand,
        b.po_status_ct, b.funnel_status, CAST(b.datasource_origin_timestamp AS TIMESTAMP),
        b.PO_PLATAFORM_DATASOURCE, b.PAY_GATEWAY_STATUS, b.PO_PAYMENT_TYPE_STATUS
    FROM ow_lao.TMP_SALES_PAYMENTS_VTEX_AR_DETAILS b
    LEFT JOIN ow_lao.ODS_PAYMENT_FUNNEL a
      ON b.pay_orderid    = a.pay_orderid
     AND b.pay_subsidiary = a.pay_subsidiary
    WHERE a.pay_orderid IS NULL;
END;
$$;

CALL OW_LAO.PROC_ODS_SALES_PAYMENTS_VTEX_AR_DETAILS();
-- PROC_ODS_SALES_PAYMENTS_VTEX_AR_DETAILS
-- ---------------------------------------
-- 0

