CREATE OR REPLACE PROCEDURE OW_LAO.PROC_ODS_SELA_SALES_COUPONS()
LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM MERGE INTO OW_LAO.ODS_SELA_SALES_COUPONS a
    USING OW_LAO.STG_SELA_SALES_COUPONS b
      ON COALESCE(b.applied_rule_ids, '') = COALESCE(a.applied_rule_ids, '')
    WHEN MATCHED THEN UPDATE SET
         updated_timestamp = CURRENT_TIMESTAMP
       , base_currency_code = b.base_currency_code
       , base_discount_amount = b.base_discount_amount
       , base_discount_invoiced = b.base_discount_invoiced
       , base_grand_total = b.base_grand_total
       , base_discount_tax_compensation_amount = b.base_discount_tax_compensation_amount
       , base_discount_tax_compensation_invoiced = b.base_discount_tax_compensation_invoiced
       , base_shipping_amount = b.base_shipping_amount
       , base_shipping_discount_amount = b.base_shipping_discount_amount
       , base_shipping_discount_tax_compensation_amnt = b.base_shipping_discount_tax_compensation_amnt
       , base_shipping_incl_tax = b.base_shipping_incl_tax
       , base_shipping_invoiced = b.base_shipping_invoiced
       , base_shipping_tax_amount = b.base_shipping_tax_amount
       , base_subtotal = b.base_subtotal
       , base_subtotal_incl_tax = b.base_subtotal_incl_tax
       , base_subtotal_invoiced = b.base_subtotal_invoiced
       , base_tax_amount = b.base_tax_amount
       , base_tax_invoiced = b.base_tax_invoiced
       , base_total_due = b.base_total_due
       , base_total_invoiced = b.base_total_invoiced
       , base_total_invoiced_cost = b.base_total_invoiced_cost
       , base_total_paid = b.base_total_paid
       , base_to_global_rate = b.base_to_global_rate
       , base_to_order_rate = b.base_to_order_rate
       , billing_address_id = b.billing_address_id
       , created_at = b.created_at
       , customer_email = b.customer_email
       , customer_firstname = b.customer_firstname
       , customer_group_id = b.customer_group_id
       , customer_is_guest = b.customer_is_guest
       , customer_lastname = b.customer_lastname
       , customer_note = b.customer_note
       , customer_note_notify = b.customer_note_notify
       , discount_amount = b.discount_amount
       , discount_invoiced = b.discount_invoiced
       , email_sent = b.email_sent
       , global_currency_code = b.global_currency_code
       , grand_total = b.grand_total
       , discount_tax_compensation_amount = b.discount_tax_compensation_amount
       , discount_tax_compensation_invoiced = b.discount_tax_compensation_invoiced
       , increment_id = b.increment_id
       , is_virtual = b.is_virtual
       , order_currency_code = b.order_currency_code
       , protect_code = b.protect_code
       , quote_id = b.quote_id
       , remote_ip = b.remote_ip
       , shipping_amount = b.shipping_amount
       , shipping_description = b.shipping_description
       , shipping_discount_amount = b.shipping_discount_amount
       , shipping_discount_tax_compensation_amount = b.shipping_discount_tax_compensation_amount
       , shipping_incl_tax = b.shipping_incl_tax
       , shipping_invoiced = b.shipping_invoiced
       , shipping_tax_amount = b.shipping_tax_amount
       , state = b.state
       , status = b.status
       , store_currency_code = b.store_currency_code
       , store_id = b.store_id
       , store_name = b.store_name
       , store_to_base_rate = b.store_to_base_rate
       , store_to_order_rate = b.store_to_order_rate
       , subtotal = b.subtotal
       , subtotal_incl_tax = b.subtotal_incl_tax
       , subtotal_invoiced = b.subtotal_invoiced
       , tax_amount = b.tax_amount
       , tax_invoiced = b.tax_invoiced
       , total_due = b.total_due
       , total_invoiced = b.total_invoiced
       , total_item_count = b.total_item_count
       , total_paid = b.total_paid
       , total_qty_ordered = b.total_qty_ordered
       , updated_at = b.updated_at
       , weight = b.weight
       , billing_address_address_type = b.billing_address_address_type
       , billing_address_city = b.billing_address_city
       , billing_address_country_id = b.billing_address_country_id
       , billing_address_email = b.billing_address_email
       , billing_address_entity_id = b.billing_address_entity_id
       , billing_address_firstname = b.billing_address_firstname
       , billing_address_lastname = b.billing_address_lastname
       , billing_address_parent_id = b.billing_address_parent_id
       , billing_address_postcode = b.billing_address_postcode
       , billing_address_region = b.billing_address_region
       , billing_address_region_code = b.billing_address_region_code
       , billing_address_region_id = b.billing_address_region_id
       , billing_address_street = b.billing_address_street
       , billing_address_telephone = b.billing_address_telephone
       , billing_address_vat_id = b.billing_address_vat_id
       , payment_account_status = b.payment_account_status
       , payment_additional_information = b.payment_additional_information
       , payment_amount_ordered = b.payment_amount_ordered
       , payment_base_amount_ordered = b.payment_base_amount_ordered
       , payment_base_shipping_amount = b.payment_base_shipping_amount
       , payment_cc_exp_month = b.payment_cc_exp_month
       , payment_cc_exp_year = b.payment_cc_exp_year
       , payment_cc_last4 = b.payment_cc_last4
       , payment_cc_type = b.payment_cc_type
       , payment_entity_id = b.payment_entity_id
       , payment_method = b.payment_method
       , payment_parent_id = b.payment_parent_id
       , payment_shipping_amount = b.payment_shipping_amount
       , payment_amount_paid = b.payment_amount_paid
       , payment_base_amount_paid = b.payment_base_amount_paid
       , payment_base_shipping_captured = b.payment_base_shipping_captured
       , payment_last_trans_id = b.payment_last_trans_id
       , payment_shipping_captured = b.payment_shipping_captured
       , base_discount_canceled = b.base_discount_canceled
       , base_shipping_canceled = b.base_shipping_canceled
       , base_subtotal_canceled = b.base_subtotal_canceled
       , base_tax_canceled = b.base_tax_canceled
       , base_total_canceled = b.base_total_canceled
       , discount_canceled = b.discount_canceled
       , shipping_canceled = b.shipping_canceled
       , subtotal_canceled = b.subtotal_canceled
       , tax_canceled = b.tax_canceled
       , total_canceled = b.total_canceled
       , extension_attributes_pickup_location_code = b.extension_attributes_pickup_location_code
       , extension_attributes_applied_taxes = b.extension_attributes_applied_taxes
       , extension_attributes_item_applied_taxes = b.extension_attributes_item_applied_taxes
       , extension_attributes_billing_customer_identification = b.extension_attributes_billing_customer_identification
    WHEN NOT MATCHED THEN INSERT (
           applied_rule_ids
         , base_currency_code
         , base_discount_amount
         , base_discount_invoiced
         , base_grand_total
         , base_discount_tax_compensation_amount
         , base_discount_tax_compensation_invoiced
         , base_shipping_amount
         , base_shipping_discount_amount
         , base_shipping_discount_tax_compensation_amnt
         , base_shipping_incl_tax
         , base_shipping_invoiced
         , base_shipping_tax_amount
         , base_subtotal
         , base_subtotal_incl_tax
         , base_subtotal_invoiced
         , base_tax_amount
         , base_tax_invoiced
         , base_total_due
         , base_total_invoiced
         , base_total_invoiced_cost
         , base_total_paid
         , base_to_global_rate
         , base_to_order_rate
         , billing_address_id
         , created_at
         , customer_email
         , customer_firstname
         , customer_group_id
         , customer_is_guest
         , customer_lastname
         , customer_note
         , customer_note_notify
         , discount_amount
         , discount_invoiced
         , email_sent
         , entity_id
         , global_currency_code
         , grand_total
         , discount_tax_compensation_amount
         , discount_tax_compensation_invoiced
         , increment_id
         , is_virtual
         , order_currency_code
         , protect_code
         , quote_id
         , remote_ip
         , shipping_amount
         , shipping_description
         , shipping_discount_amount
         , shipping_discount_tax_compensation_amount
         , shipping_incl_tax
         , shipping_invoiced
         , shipping_tax_amount
         , state
         , status
         , store_currency_code
         , store_id
         , store_name
         , store_to_base_rate
         , store_to_order_rate
         , subtotal
         , subtotal_incl_tax
         , subtotal_invoiced
         , tax_amount
         , tax_invoiced
         , total_due
         , total_invoiced
         , total_item_count
         , total_paid
         , total_qty_ordered
         , updated_at
         , weight
         , billing_address_address_type
         , billing_address_city
         , billing_address_country_id
         , billing_address_email
         , billing_address_entity_id
         , billing_address_firstname
         , billing_address_lastname
         , billing_address_parent_id
         , billing_address_postcode
         , billing_address_region
         , billing_address_region_code
         , billing_address_region_id
         , billing_address_street
         , billing_address_telephone
         , billing_address_vat_id
         , payment_account_status
         , payment_additional_information
         , payment_amount_ordered
         , payment_base_amount_ordered
         , payment_base_shipping_amount
         , payment_cc_exp_month
         , payment_cc_exp_year
         , payment_cc_last4
         , payment_cc_type
         , payment_entity_id
         , payment_method
         , payment_parent_id
         , payment_shipping_amount
         , payment_amount_paid
         , payment_base_amount_paid
         , payment_base_shipping_captured
         , payment_last_trans_id
         , payment_shipping_captured
         , base_discount_canceled
         , base_shipping_canceled
         , base_subtotal_canceled
         , base_tax_canceled
         , base_total_canceled
         , discount_canceled
         , shipping_canceled
         , subtotal_canceled
         , tax_canceled
         , total_canceled
         , extension_attributes_pickup_location_code
         , extension_attributes_applied_taxes
         , extension_attributes_item_applied_taxes
         , extension_attributes_billing_customer_identification
         , subsidiary_id
         , account
         , updated_timestamp
    ) VALUES (
           COALESCE(b.applied_rule_ids, '')
         , b.base_currency_code
         , b.base_discount_amount
         , b.base_discount_invoiced
         , b.base_grand_total
         , b.base_discount_tax_compensation_amount
         , b.base_discount_tax_compensation_invoiced
         , b.base_shipping_amount
         , b.base_shipping_discount_amount
         , b.base_shipping_discount_tax_compensation_amnt
         , b.base_shipping_incl_tax
         , b.base_shipping_invoiced
         , b.base_shipping_tax_amount
         , b.base_subtotal
         , b.base_subtotal_incl_tax
         , b.base_subtotal_invoiced
         , b.base_tax_amount
         , b.base_tax_invoiced
         , b.base_total_due
         , b.base_total_invoiced
         , b.base_total_invoiced_cost
         , b.base_total_paid
         , b.base_to_global_rate
         , b.base_to_order_rate
         , b.billing_address_id
         , b.created_at
         , b.customer_email
         , b.customer_firstname
         , b.customer_group_id
         , b.customer_is_guest
         , b.customer_lastname
         , b.customer_note
         , b.customer_note_notify
         , b.discount_amount
         , b.discount_invoiced
         , b.email_sent
         , b.entity_id
         , b.global_currency_code
         , b.grand_total
         , b.discount_tax_compensation_amount
         , b.discount_tax_compensation_invoiced
         , b.increment_id
         , b.is_virtual
         , b.order_currency_code
         , b.protect_code
         , b.quote_id
         , b.remote_ip
         , b.shipping_amount
         , b.shipping_description
         , b.shipping_discount_amount
         , b.shipping_discount_tax_compensation_amount
         , b.shipping_incl_tax
         , b.shipping_invoiced
         , b.shipping_tax_amount
         , b.state
         , b.status
         , b.store_currency_code
         , b.store_id
         , b.store_name
         , b.store_to_base_rate
         , b.store_to_order_rate
         , b.subtotal
         , b.subtotal_incl_tax
         , b.subtotal_invoiced
         , b.tax_amount
         , b.tax_invoiced
         , b.total_due
         , b.total_invoiced
         , b.total_item_count
         , b.total_paid
         , b.total_qty_ordered
         , b.updated_at
         , b.weight
         , b.billing_address_address_type
         , b.billing_address_city
         , b.billing_address_country_id
         , b.billing_address_email
         , b.billing_address_entity_id
         , b.billing_address_firstname
         , b.billing_address_lastname
         , b.billing_address_parent_id
         , b.billing_address_postcode
         , b.billing_address_region
         , b.billing_address_region_code
         , b.billing_address_region_id
         , b.billing_address_street
         , b.billing_address_telephone
         , b.billing_address_vat_id
         , b.payment_account_status
         , b.payment_additional_information
         , b.payment_amount_ordered
         , b.payment_base_amount_ordered
         , b.payment_base_shipping_amount
         , b.payment_cc_exp_month
         , b.payment_cc_exp_year
         , b.payment_cc_last4
         , b.payment_cc_type
         , b.payment_entity_id
         , b.payment_method
         , b.payment_parent_id
         , b.payment_shipping_amount
         , b.payment_amount_paid
         , b.payment_base_amount_paid
         , b.payment_base_shipping_captured
         , b.payment_last_trans_id
         , b.payment_shipping_captured
         , b.base_discount_canceled
         , b.base_shipping_canceled
         , b.base_subtotal_canceled
         , b.base_tax_canceled
         , b.base_total_canceled
         , b.discount_canceled
         , b.shipping_canceled
         , b.subtotal_canceled
         , b.tax_canceled
         , b.total_canceled
         , b.extension_attributes_pickup_location_code
         , b.extension_attributes_applied_taxes
         , b.extension_attributes_item_applied_taxes
         , b.extension_attributes_billing_customer_identification
         , b.subsidiary_id
         , b.account
         , CURRENT_TIMESTAMP
    );
END;
$$;

-- CALL OW_LAO.PROC_ODS_SELA_SALES_COUPONS();
-- ERROR: Severity: ERROR, Message: Relation "OW_LAO.STG_SELA_SALES_COUPONS" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_ODS_SELA_SALES_COUPONS line 3 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
-- CALL OW_LAO.PROC_ODS_SELA_SALES_COUPONS();
-- ERROR: Severity: ERROR, Message: Relation "OW_LAO.STG_SELA_SALES_COUPONS" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_ODS_SELA_SALES_COUPONS line 3 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
