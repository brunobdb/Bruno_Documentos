-- CREATE OR REPLACE PROCEDURE ow_lao.proc_ods_sela_custom_orders_items_validation()
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--   SELECT
--     CASE WHEN EXISTS (
--            SELECT 1
--              FROM ow_lao.ods_sela_custom_orders_items
--             WHERE CAST(inserted_timestamp AS DATE) >= TIMESTAMPADD(DAY, -1, CURRENT_DATE)
--          ) THEN 2 ELSE 3 END AS monitoring_execution_result_status,
--     CASE WHEN EXISTS (
--            SELECT 1
--              FROM ow_lao.ods_sela_custom_orders_items
--             WHERE CAST(inserted_timestamp AS DATE) >= TIMESTAMPADD(DAY, -1, CURRENT_DATE)
--          ) THEN 'OK' ELSE 'NOT OK' END AS value;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 13.48 of source string: syntax error, unexpected ;, expecting INTO, Sqlstate: 42601, Position: 609, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
-- CREATE OR REPLACE PROCEDURE ow_lao.proc_ods_sela_custom_orders_items_validation()
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--   RETURN QUERY
--   SELECT
--     CASE WHEN EXISTS (
--            SELECT 1
--              FROM ow_lao.ods_sela_custom_orders_items
--             WHERE CAST(inserted_timestamp AS DATE) >= TIMESTAMPADD(DAY, -1, CURRENT_DATE)
--          ) THEN 2 ELSE 3 END AS monitoring_execution_result_status,
--     CASE WHEN EXISTS (
--            SELECT 1
--              FROM ow_lao.ods_sela_custom_orders_items
--             WHERE CAST(inserted_timestamp AS DATE) >= TIMESTAMPADD(DAY, -1, CURRENT_DATE)
--          ) THEN 'OK' ELSE 'NOT OK' END AS value;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 3.10-14 of source string: syntax error, unexpected QUERY, expecting := or <-, Sqlstate: 42601, Position: 120, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
CREATE OR REPLACE PROCEDURE ow_lao.proc_ods_sela_custom_orders_items_validation()
LANGUAGE PLvSQL AS $$
DECLARE
  monitoring_execution_result_status INT;
  result_value VARCHAR(10);
BEGIN
  SELECT
    CASE WHEN EXISTS (
           SELECT 1
             FROM ow_lao.ods_sela_custom_orders_items
            WHERE CAST(inserted_timestamp AS DATE) >= TIMESTAMPADD(DAY, -1, CURRENT_DATE)
         ) THEN 2 ELSE 3 END,
    CASE WHEN EXISTS (
           SELECT 1
             FROM ow_lao.ods_sela_custom_orders_items
            WHERE CAST(inserted_timestamp AS DATE) >= TIMESTAMPADD(DAY, -1, CURRENT_DATE)
         ) THEN 'OK' ELSE 'NOT OK' END
  INTO monitoring_execution_result_status, result_value;
END;
$$;

CALL ow_lao.proc_ods_sela_custom_orders_items_validation();
-- proc_ods_sela_custom_orders_items_validation
-- --------------------------------------------
-- 0

