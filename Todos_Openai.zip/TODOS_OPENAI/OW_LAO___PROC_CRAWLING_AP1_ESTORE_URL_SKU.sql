-- CREATE OR REPLACE PROCEDURE OW_LAO.PROC_CRAWLING_AP1_ESTORE_URL_SKU()
-- LANGUAGE PLvSQL AS $$
-- DECLARE
--   CLASSIFICATION_FILE VARCHAR(25);
-- BEGIN
--   /* Classify file */
--   SELECT CASE WHEN FILE_NAME LIKE '%SELA%' THEN 'SELA' ELSE 'OTHERS' END
--     INTO CLASSIFICATION_FILE
--   FROM OW_LAO.TMP_TABLE
--   LIMIT 1;
-- 
--   /* If URL exists in both tables set status to ACTIVE */
--   PERFORM UPDATE OW_LAO.MAP_ESTORE_URL_SKU O
--      SET STATUS_SKU = 'ACTIVE',
--          LOAD_DATE = TO_CHAR(NOW())
--    FROM OW_LAO.TMP_MAP_ESTORE_URL_SKU T
--   WHERE TRIM(O.PROD_HREF) = TRIM(T.PROD_HREF)
--     AND TRIM(UPPER(O.SKU)) = TRIM(UPPER(T.SKU));
-- 
--   /* If URL exists only in temp table, insert into MAP */
--   PERFORM INSERT INTO OW_LAO.MAP_ESTORE_URL_SKU(
--     AP2,
--     COMPANY_NAME,
--     "DESC",
--     LAST_RUN_DATE,
--     LOAD_DATE,
--     PREMIUM,
--     PROD_HREF,
--     PRODUCT_CATEGORY,
--     PRODUCT_DIVISION,
--     PRODUCT_FAMILY,
--     PRODUCT_SERIES,
--     PRODUCT_SUB_CATEGORY,
--     SKU,
--     STATUS_SKU,
--     COLOR,
--     MEMORY,
--     TRADE_IN,
--     GIFT)
--   SELECT T.AP2,
--          T.COMPANY_NAME,
--          T."DESC",
--          NULL AS LAST_RUN_DATE,
--          T.LOAD_DATE,
--          T.PREMIUM,
--          T.PROD_HREF,
--          T.PRODUCT_CATEGORY,
--          T.PRODUCT_DIVISION,
--          T.PRODUCT_FAMILY,
--          T.PRODUCT_SERIES,
--          T.PRODUCT_SUB_CATEGORY,
--          T.SKU,
--          'ACTIVE' AS STATUS_SKU,
--          T.COLOR,
--          T.MEMORY,
--          T.TRADE_IN,
--          T.GIFT
--     FROM OW_LAO.MAP_ESTORE_URL_SKU O
--     RIGHT JOIN OW_LAO.TMP_MAP_ESTORE_URL_SKU T
--       ON (TRIM(O.PROD_HREF) = TRIM(T.PROD_HREF)
--       AND TRIM(UPPER(O.SKU)) = TRIM(UPPER(T.SKU)))
--    WHERE O.PROD_HREF IS NULL;
-- 
--   /* If URL exists only in MAP and not in temp, disable */
--   PERFORM UPDATE OW_LAO.MAP_ESTORE_URL_SKU O
--      SET STATUS_SKU = 'DISABLED'
--    WHERE NOT EXISTS (
--            SELECT 1
--              FROM OW_LAO.TMP_MAP_ESTORE_URL_SKU T
--             WHERE TRIM(O.PROD_HREF) = TRIM(T.PROD_HREF)
--               AND TRIM(UPPER(O.SKU)) = TRIM(UPPER(T.SKU))
--          );
-- 
--   /* Delete and reload RAW from TMP */
--   PERFORM DELETE FROM OW_LAO.RAW_DATA
--    WHERE FILE_NAME IN (SELECT DISTINCT FILE_NAME FROM OW_LAO.TMP_TABLE);
-- 
--   PERFORM INSERT INTO OW_LAO.RAW_DATA
--   SELECT * FROM OW_LAO.TMP_TABLE;
-- 
--   /* Save daily snapshot into historical */
--   PERFORM INSERT INTO OW_LAO.MAP_ESTORE_URL_SKU_HISTORICAL
--   SELECT ID_REF_URL,
--          AP2,
--          COMPANY_NAME,
--          "DESC",
--          LAST_RUN_DATE,
--          LOAD_DATE,
--          PREMIUM,
--          PROD_HREF,
--          PRODUCT_CATEGORY,
--          PRODUCT_DIVISION,
--          PRODUCT_FAMILY,
--          PRODUCT_SERIES,
--          PRODUCT_SUB_CATEGORY,
--          SKU,
--          STATUS_SKU,
--          COLOR,
--          MEMORY,
--          TRADE_IN,
--          GIFT,
--          NOW()
--     FROM OW_LAO.MAP_ESTORE_URL_SKU;
-- 
--   /* Transformation stage 1 */
--   PERFORM TRUNCATE TABLE OW_LAO.TF_CRAWLING_AP1_ESTORE_URL_SKU_1;
-- 
--   PERFORM INSERT INTO OW_LAO.TF_CRAWLING_AP1_ESTORE_URL_SKU_1
--   (
--     SELECT DISTINCT
--         P.AP2 AS SUBSIDIARY,
--         P.COUNTRY AS COUNTRY,
--         P.SKU AS SKU,
--         P."DESC" AS MODEL_DESC,
--         P.COMPANY_NAME AS SITE_COMPANY_NAME,
--         P.TODAY_DATE AS REFER_DATE,
--         SUBSTR(P."DE_VALUE",1,16) AS RETAIL_PRICE_BASE,
--         SUBSTR(P."POR_VALUE",1,16) AS RETAIL_PRICE_ACTUAL,
--         SUBSTR(P."PROD_HREF",1,499) AS SITE_URL,
--         SUBSTR(P."CURRENCY",1,99) AS SITE_PRICE_CURRENCY,
--         D.PRODUCT_DIVISION AS PRODUCT_DIVISION,
--         D.PRODUCT_CATEGORY AS PRODUCT_CATEGORY,
--         D.PRODUCT_SUB_CATEGORY AS PRODUCT_SUB_CATEGORY,
--         D.PRODUCT_FAMILY AS PRODUCT_FAMILY,
--         D.PRODUCT_SERIES AS PRODUCT_SERIES,
--         D.PREMIUM AS PREMIUM,
--         CASE WHEN TRIM(UPPER(P.PROD_HREF)) <> TRIM(UPPER(P.PROD_HREF_OUT)) THEN 'URL  Redirected' ELSE P.STATUS_SITE END AS STATUS_SITE
--     FROM OW_LAO.ODS_CRAWLING_AP1_ESTORE_DAILY_PRICE P
--     INNER JOIN OW_LAO.MAP_ESTORE_URL_SKU_HISTORICAL D
--       ON TRIM(UPPER(P.PROD_HREF)) = TRIM(UPPER(D.PROD_HREF))
--      AND TRIM(UPPER(P.SKU)) = TRIM(UPPER(D.SKU))
--      AND TO_CHAR(P."TODAY_DATE", 'YYYY-MM-DD') = TO_CHAR(D."LOAD_DATE", 'YYYY-MM-DD')
--     WHERE TO_CHAR(P."TODAY_DATE", 'YYYY-MM-DD') < TO_CHAR(CURRENT_DATE, 'YYYY-MM-DD')
--   );
-- 
--   PERFORM UPDATE OW_LAO.TF_CRAWLING_AP1_ESTORE_URL_SKU_1
--      SET RETAIL_PRICE_BASE = REGEXP_SUBSTR(UPPER(TRIM(RETAIL_PRICE_BASE)), '[0-9]+(\.[0-9]{1,2})?', 1, 1),
--          RETAIL_PRICE_ACTUAL = REGEXP_SUBSTR(UPPER(TRIM(RETAIL_PRICE_ACTUAL)), '[0-9]+(\.[0-9]{1,2})?', 1, 1);
-- 
--   /* Transformation stage 2 */
--   PERFORM TRUNCATE TABLE OW_LAO.TF_CRAWLING_AP1_ESTORE_URL_SKU_2;
-- 
--   PERFORM INSERT INTO OW_LAO.TF_CRAWLING_AP1_ESTORE_URL_SKU_2
--   (
--     SELECT
--       SUBSIDIARY,
--       COUNTRY,
--       SKU,
--       MODEL_DESC,
--       SITE_COMPANY_NAME,
--       REFER_DATE,
--       SITE_URL,
--       SITE_PRICE_CURRENCY,
--       PRODUCT_DIVISION,
--       PRODUCT_CATEGORY,
--       PRODUCT_SUB_CATEGORY,
--       PRODUCT_FAMILY,
--       PRODUCT_SERIES,
--       PREMIUM,
--       STATUS_SITE,
--       ROUND(MAX(RETAIL_PRICE_BASE),2) AS PRICE_LOCAL_FROM,
--       ROUND(MAX(RETAIL_PRICE_ACTUAL),2) AS PRICE_LOCAL_TO
--     FROM OW_LAO.TF_CRAWLING_AP1_ESTORE_URL_SKU_1
--     GROUP BY
--       SUBSIDIARY,
--       COUNTRY,
--       SKU,
--       MODEL_DESC,
--       SITE_COMPANY_NAME,
--       REFER_DATE,
--       SITE_URL,
--       SITE_PRICE_CURRENCY,
--       PRODUCT_DIVISION,
--       PRODUCT_CATEGORY,
--       PRODUCT_SUB_CATEGORY,
--       PRODUCT_FAMILY,
--       PRODUCT_SERIES,
--       PREMIUM,
--       STATUS_SITE
--   );
-- 
--   /* Validation aux table */
--   PERFORM TRUNCATE TABLE OW_LAO.TF_CRAWLING_AP1_ESTORE_DAILY_PRICE_AUX;
-- 
--   PERFORM INSERT INTO OW_LAO.TF_CRAWLING_AP1_ESTORE_DAILY_PRICE_AUX
--   (
--     SELECT DISTINCT * FROM (
--       SELECT 
--               J.SUBSIDIARY, 
--               J.SKU, 
--               J.REFER_DATE, 
--               J.SUBSIDIARY_2, 
--               J.SKU_2, 
--               J.DATE_2, 
--               J.VALID_PRICE_SAMSUNG, 
--               J.VALID_PRICE_VAREJO, 
--               J.VALID_FINAL, 
--               J.ROW_NUM,
--               J.MAX_TO_JOIN,
--               COALESCE(K.VALID,'NOK VAREJO') AS VALID
--       FROM (
--               SELECT DISTINCT  O.SUBSIDIARY, 
--                         O.SKU, 
--                         O.REFER_DATE, 
--                         O.SUBSIDIARY_2, 
--                         O.SKU_2, 
--                         O.DATE_2, 
--                         O.VALID_PRICE_SAMSUNG, 
--                         O.VALID_PRICE_VAREJO, 
--                         O.VALID_FINAL, 
--                         O.ROW_NUM,
--                         D.MAX_TO_JOIN,
--                         CASE 
--                           WHEN D.MAX_TO_JOIN = 1 THEN O.VALID_FINAL 
--                           WHEN O.VALID_PRICE_SAMSUNG IS NULL OR O.VALID_PRICE_SAMSUNG = 'NOK' THEN 'NOK SAMSUNG'
--                           WHEN D.MAX_TO_JOIN = 2 AND (ROW_NUM = 1 OR ROW_NUM = 2) AND O.VALID_FINAL IN ('OK') THEN 'OK' 
--                           WHEN D.MAX_TO_JOIN = 3 AND (ROW_NUM IN (1,2,3)) AND O.VALID_FINAL IN ('OK') THEN 'OK' 
--                           ELSE NULL 
--                         END AS VALID
--               FROM (
--                       SELECT DISTINCT M.SUBSIDIARY, M.SKU, M.REFER_DATE, 
--                         N.SUBSIDIARY AS SUBSIDIARY_2, N.SKU AS SKU_2, N.REFER_DATE AS DATE_2,
--                         M.VALID_PRICE_SAMSUNG,N.VALID_PRICE_VAREJO,
--                         CASE 
--                           WHEN M.VALID_PRICE_SAMSUNG = 'OK' AND N.VALID_PRICE_VAREJO = 'OK' THEN 'OK'
--                           WHEN (M.VALID_PRICE_SAMSUNG = 'NOK' OR M.VALID_PRICE_SAMSUNG IS NULL)
--                            AND (N.VALID_PRICE_VAREJO = 'NOK' OR N.VALID_PRICE_VAREJO IS NULL) THEN 'NOK AMBOS'
--                           WHEN M.VALID_PRICE_SAMSUNG = 'OK' AND (N.VALID_PRICE_VAREJO = 'NOK' OR N.VALID_PRICE_VAREJO IS NULL) THEN 'NOK VAREJO'
--                           WHEN N.VALID_PRICE_VAREJO = 'OK' AND (M.VALID_PRICE_SAMSUNG = 'NOK' OR M.VALID_PRICE_SAMSUNG IS NULL) THEN 'NOK SAMSUNG'
--                         END VALID_FINAL,
--                         ROW_NUMBER() OVER (PARTITION BY COALESCE(M.SUBSIDIARY,N.SUBSIDIARY), COALESCE(M.SKU,N.SKU), COALESCE(M.REFER_DATE,N.REFER_DATE)
--                                            ORDER BY COALESCE(M.REFER_DATE,N.REFER_DATE) DESC, COALESCE(M.SUBSIDIARY,N.SUBSIDIARY), COALESCE(M.SKU,N.SKU) ASC) as ROW_NUM
--                       FROM 
--                         (SELECT DISTINCT SUBSIDIARY, SITE_COMPANY_NAME, SKU, PRICE_LOCAL_TO, REFER_DATE,
--                                 CASE WHEN PRICE_LOCAL_TO IS NOT NULL  THEN 'OK' ELSE 'NOK' END AS VALID_PRICE_SAMSUNG
--                            FROM OW_LAO.VW_CRAWLING_AP1_ESTORE_DAILY_PRICE
--                           WHERE SITE_COMPANY_NAME LIKE '%SAMSUNG%') M
--                       FULL OUTER JOIN
--                         (SELECT DISTINCT SUBSIDIARY, SITE_COMPANY_NAME, SKU, PRICE_LOCAL_TO, REFER_DATE,
--                                 CASE WHEN PRICE_LOCAL_TO IS NOT NULL  THEN 'OK' ELSE 'NOK' END AS VALID_PRICE_VAREJO
--                            FROM OW_LAO.VW_CRAWLING_AP1_ESTORE_DAILY_PRICE
--                           WHERE SITE_COMPANY_NAME NOT LIKE '%SAMSUNG%') N
--                         ON (UPPER(TRIM(M.SUBSIDIARY)) = UPPER(TRIM(N.SUBSIDIARY)) AND UPPER(TRIM(M.SKU)) = UPPER(TRIM(N.SKU)) AND M.REFER_DATE = N.REFER_DATE)
--                       ORDER BY COALESCE(M.REFER_DATE,N.REFER_DATE) DESC, COALESCE(M.SUBSIDIARY,N.SUBSIDIARY), COALESCE(M.SKU,N.SKU) ASC,ROW_NUM ASC 
--                    ) AS O
--               LEFT JOIN (
--                         SELECT COALESCE(SUBSIDIARY,SUBSIDIARY_2) AS SUB_TO_JOIN ,COALESCE(SKU,SKU_2) AS SKU_TO_JOIN,COALESCE(REFER_DATE,DATE_2) AS DATE_TO_JOIN,
--                                MAX(ROW_NUM) AS MAX_TO_JOIN
--                           FROM (
--                                   SELECT DISTINCT A.SUBSIDIARY,  A.SKU,  A.REFER_DATE, 
--                                          B.SUBSIDIARY AS SUBSIDIARY_2,  B.SKU AS SKU_2,  B.REFER_DATE AS DATE_2,
--                                          A.VALID_PRICE_SAMSUNG,B.VALID_PRICE_VAREJO,
--                                          CASE 
--                                            WHEN A.VALID_PRICE_SAMSUNG = 'OK' AND B.VALID_PRICE_VAREJO = 'OK' THEN 'OK'
--                                            WHEN (A.VALID_PRICE_SAMSUNG = 'NOK' OR A.VALID_PRICE_SAMSUNG IS NULL)
--                                             AND (B.VALID_PRICE_VAREJO = 'NOK' OR B.VALID_PRICE_VAREJO IS NULL) THEN 'NOK AMBOS'
--                                            WHEN A.VALID_PRICE_SAMSUNG = 'OK' AND (B.VALID_PRICE_VAREJO = 'NOK' OR B.VALID_PRICE_VAREJO IS NULL) THEN 'NOK VAREJO'
--                                            WHEN B.VALID_PRICE_VAREJO = 'OK' AND (A.VALID_PRICE_SAMSUNG = 'NOK' OR A.VALID_PRICE_SAMSUNG IS NULL) THEN 'NOK SAMSUNG'
--                                          END VALID_FINAL,
--                                          ROW_NUMBER() OVER (PARTITION BY COALESCE(A.SUBSIDIARY,B.SUBSIDIARY), COALESCE(A.SKU,B.SKU), COALESCE(A.REFER_DATE,B.REFER_DATE)
--                                                             ORDER BY COALESCE(A.REFER_DATE,B.REFER_DATE) DESC, COALESCE(A.SUBSIDIARY,B.SUBSIDIARY), COALESCE(A.SKU,B.SKU) ASC) as ROW_NUM
--                                     FROM 
--                                       (SELECT DISTINCT SUBSIDIARY, SITE_COMPANY_NAME, SKU, PRICE_LOCAL_TO, REFER_DATE,
--                                               CASE WHEN PRICE_LOCAL_TO IS NOT NULL  THEN 'OK' ELSE 'NOK' END AS VALID_PRICE_SAMSUNG
--                                          FROM OW_LAO.VW_CRAWLING_AP1_ESTORE_DAILY_PRICE
--                                         WHERE SITE_COMPANY_NAME LIKE '%SAMSUNG%') A
--                                     FULL OUTER JOIN
--                                       (SELECT DISTINCT SUBSIDIARY, SITE_COMPANY_NAME, SKU, PRICE_LOCAL_TO, REFER_DATE,
--                                               CASE WHEN PRICE_LOCAL_TO IS NOT NULL  THEN 'OK' ELSE 'NOK' END AS VALID_PRICE_VAREJO
--                                          FROM OW_LAO.VW_CRAWLING_AP1_ESTORE_DAILY_PRICE
--                                         WHERE SITE_COMPANY_NAME NOT LIKE '%SAMSUNG%') B
--                                       ON (UPPER(TRIM(A.SUBSIDIARY)) = UPPER(TRIM(B.SUBSIDIARY))
--                                       AND UPPER(TRIM(A.SKU)) = UPPER(TRIM(B.SKU))
--                                       AND A.REFER_DATE = B.REFER_DATE)
--                                     ORDER BY COALESCE(A.REFER_DATE,B.REFER_DATE) DESC, COALESCE(A.SUBSIDIARY,B.SUBSIDIARY), COALESCE(A.SKU,B.SKU) ASC,ROW_NUM ASC
--                                ) AS C 
--                          GROUP BY COALESCE(SUBSIDIARY,SUBSIDIARY_2),COALESCE(SKU,SKU_2),COALESCE(REFER_DATE,DATE_2)
--                     ) AS D
--                 ON (COALESCE(O.SUBSIDIARY,O.SUBSIDIARY_2) = D.SUB_TO_JOIN)
--                AND (COALESCE(O.SKU,O.SKU_2) = D.SKU_TO_JOIN)
--                AND (COALESCE(O.REFER_DATE,O.DATE_2) = D.DATE_TO_JOIN)
--               ORDER BY COALESCE(O.REFER_DATE,O.DATE_2) DESC, COALESCE(O.SUBSIDIARY,O.SUBSIDIARY_2), COALESCE(O.SKU,O.SKU_2) ASC, O.ROW_NUM ASC  
--            ) J 
--       LEFT JOIN (
--             SELECT DISTINCT COALESCE(SUBSIDIARY,SUBSIDIARY_2) AS SUB , 
--                     COALESCE(SKU,SKU_2) AS SKU,
--                     COALESCE(REFER_DATE,DATE_2) AS REFER_DATE,
--                     VALID
--               FROM (
--                     SELECT DISTINCT O.SUBSIDIARY, 
--                            O.SKU, 
--                            O.REFER_DATE, 
--                            O.SUBSIDIARY_2, 
--                            O.SKU_2, 
--                            O.DATE_2, 
--                            O.VALID_PRICE_SAMSUNG, 
--                            O.VALID_PRICE_VAREJO, 
--                            O.VALID_FINAL, 
--                            O.ROW_NUM,
--                            D.MAX_TO_JOIN,
--                            CASE 
--                              WHEN D.MAX_TO_JOIN = 1 THEN O.VALID_FINAL 
--                              WHEN O.VALID_PRICE_SAMSUNG IS NULL OR O.VALID_PRICE_SAMSUNG = 'NOK' THEN 'NOK SAMSUNG'
--                              WHEN D.MAX_TO_JOIN = 2 AND (ROW_NUM = 1 OR ROW_NUM = 2) AND O.VALID_FINAL IN ('OK') THEN 'OK' 
--                              WHEN D.MAX_TO_JOIN = 3 AND (ROW_NUM IN (1,2,3)) AND O.VALID_FINAL IN ('OK') THEN 'OK' 
--                              ELSE NULL 
--                            END AS VALID
--                       FROM (
--                             SELECT DISTINCT M.SUBSIDIARY, M.SKU, M.REFER_DATE, 
--                                    N.SUBSIDIARY AS SUBSIDIARY_2, N.SKU AS SKU_2, N.REFER_DATE AS DATE_2,
--                                    M.VALID_PRICE_SAMSUNG,N.VALID_PRICE_VAREJO,
--                                    CASE 
--                                      WHEN M.VALID_PRICE_SAMSUNG = 'OK' AND N.VALID_PRICE_VAREJO = 'OK' THEN 'OK'
--                                      WHEN (M.VALID_PRICE_SAMSUNG = 'NOK' OR M.VALID_PRICE_SAMSUNG IS NULL)
--                                       AND (N.VALID_PRICE_VAREJO = 'NOK' OR N.VALID_PRICE_VAREJO IS NULL) THEN 'NOK AMBOS'
--                                      WHEN M.VALID_PRICE_SAMSUNG = 'OK' AND (N.VALID_PRICE_VAREJO = 'NOK' OR N.VALID_PRICE_VAREJO IS NULL) THEN 'NOK VAREJO'
--                                      WHEN N.VALID_PRICE_VAREJO = 'OK' AND (M.VALID_PRICE_SAMSUNG = 'NOK' OR M.VALID_PRICE_SAMSUNG IS NULL) THEN 'NOK SAMSUNG'
--                                    END VALID_FINAL,
--                                    ROW_NUMBER() OVER (PARTITION BY COALESCE(M.SUBSIDIARY,N.SUBSIDIARY), COALESCE(M.SKU,N.SKU), COALESCE(M.REFER_DATE,N.REFER_DATE)
--                                                       ORDER BY COALESCE(M.REFER_DATE,N.REFER_DATE) DESC, COALESCE(M.SUBSIDIARY,N.SUBSIDIARY), COALESCE(M.SKU,N.SKU) ASC) as ROW_NUM
--                               FROM (
--                                     SELECT DISTINCT SUBSIDIARY, SITE_COMPANY_NAME, SKU, PRICE_LOCAL_TO, REFER_DATE,
--                                            CASE WHEN PRICE_LOCAL_TO IS NOT NULL  THEN 'OK' ELSE 'NOK' END AS VALID_PRICE_SAMSUNG
--                                       FROM OW_LAO.VW_CRAWLING_AP1_ESTORE_DAILY_PRICE
--                                      WHERE SITE_COMPANY_NAME LIKE '%SAMSUNG%') M
--                               FULL OUTER JOIN
--                                     (SELECT DISTINCT SUBSIDIARY, SITE_COMPANY_NAME, SKU, PRICE_LOCAL_TO, REFER_DATE,
--                                            CASE WHEN PRICE_LOCAL_TO IS NOT NULL  THEN 'OK' ELSE 'NOK' END AS VALID_PRICE_VAREJO
--                                       FROM OW_LAO.VW_CRAWLING_AP1_ESTORE_DAILY_PRICE
--                                      WHERE SITE_COMPANY_NAME NOT LIKE '%SAMSUNG%') N
--                                 ON (UPPER(TRIM(M.SUBSIDIARY)) = UPPER(TRIM(N.SUBSIDIARY)) AND UPPER(TRIM(M.SKU)) = UPPER(TRIM(N.SKU)) AND M.REFER_DATE = N.REFER_DATE)
--                               ORDER BY COALESCE(M.REFER_DATE,N.REFER_DATE) DESC, COALESCE(M.SUBSIDIARY,N.SUBSIDIARY), COALESCE(M.SKU,N.SKU) ASC,ROW_NUM ASC
--                            ) AS O
--                       LEFT JOIN (
--                             SELECT COALESCE(SUBSIDIARY,SUBSIDIARY_2) AS SUB_TO_JOIN ,COALESCE(SKU,SKU_2) AS SKU_TO_JOIN,COALESCE(REFER_DATE,DATE_2) AS DATE_TO_JOIN,
--                                    MAX(ROW_NUM) AS MAX_TO_JOIN
--                               FROM (
--                                     SELECT DISTINCT A.SUBSIDIARY,  A.SKU,  A.REFER_DATE, 
--                                            B.SUBSIDIARY AS SUBSIDIARY_2,  B.SKU AS SKU_2,  B.REFER_DATE AS DATE_2,
--                                            A.VALID_PRICE_SAMSUNG,B.VALID_PRICE_VAREJO,
--                                            CASE 
--                                              WHEN A.VALID_PRICE_SAMSUNG = 'OK' AND B.VALID_PRICE_VAREJO = 'OK' THEN 'OK'
--                                              WHEN (A.VALID_PRICE_SAMSUNG = 'NOK' OR A.VALID_PRICE_SAMSUNG IS NULL)
--                                               AND (B.VALID_PRICE_VAREJO = 'NOK' OR B.VALID_PRICE_VAREJO IS NULL) THEN 'NOK AMBOS'
--                                              WHEN A.VALID_PRICE_SAMSUNG = 'OK' AND (B.VALID_PRICE_VAREJO = 'NOK' OR B.VALID_PRICE_VAREJO IS NULL) THEN 'NOK VAREJO'
--                                              WHEN B.VALID_PRICE_VAREJO = 'OK' AND (A.VALID_PRICE_SAMSUNG = 'NOK' OR A.VALID_PRICE_SAMSUNG IS NULL) THEN 'NOK SAMSUNG'
--                                            END VALID_FINAL,
--                                            ROW_NUMBER() OVER (PARTITION BY COALESCE(A.SUBSIDIARY,B.SUBSIDIARY), COALESCE(A.SKU,B.SKU), COALESCE(A.REFER_DATE,B.REFER_DATE)
--                                                               ORDER BY COALESCE(A.REFER_DATE,B.REFER_DATE) DESC, COALESCE(A.SUBSIDIARY,B.SUBSIDIARY), COALESCE(A.SKU,B.SKU) ASC) as ROW_NUM
--                                       FROM (
--                                             SELECT DISTINCT SUBSIDIARY, SITE_COMPANY_NAME, SKU, PRICE_LOCAL_TO, REFER_DATE,
--                                                    CASE WHEN PRICE_LOCAL_TO IS NOT NULL  THEN 'OK' ELSE 'NOK' END AS VALID_PRICE_SAMSUNG
--                                               FROM OW_LAO.VW_CRAWLING_AP1_ESTORE_DAILY_PRICE
--                                              WHERE SITE_COMPANY_NAME LIKE '%SAMSUNG%') A
--                                       FULL OUTER JOIN
--                                             (SELECT DISTINCT SUBSIDIARY, SITE_COMPANY_NAME, SKU, PRICE_LOCAL_TO, REFER_DATE,
--                                                    CASE WHEN PRICE_LOCAL_TO IS NOT NULL  THEN 'OK' ELSE 'NOK' END AS VALID_PRICE_VAREJO
--                                               FROM OW_LAO.VW_CRAWLING_AP1_ESTORE_DAILY_PRICE
--                                              WHERE SITE_COMPANY_NAME NOT LIKE '%SAMSUNG%') B
--                                         ON (UPPER(TRIM(A.SUBSIDIARY)) = UPPER(TRIM(B.SUBSIDIARY))
--                                         AND UPPER(TRIM(A.SKU)) = UPPER(TRIM(B.SKU))
--                                         AND A.REFER_DATE = B.REFER_DATE)
--                                       ORDER BY COALESCE(A.REFER_DATE,B.REFER_DATE) DESC, COALESCE(A.SUBSIDIARY,B.Subsidiary), COALESCE(A.SKU,B.SKU) ASC,ROW_NUM ASC
--                                    ) AS C 
--                              GROUP BY COALESCE(SUBSIDIARY,SUBSIDIARY_2),COALESCE(SKU,SKU_2),COALESCE(REFER_DATE,DATE_2)
--                            ) AS D
--                         ON (COALESCE(O.SUBSIDIARY,O.SUBSIDIARY_2) = D.SUB_TO_JOIN)
--                        AND (COALESCE(O.SKU,O.SKU_2) = D.SKU_TO_JOIN)
--                        AND (COALESCE(O.REFER_DATE,O.DATE_2) = D.DATE_TO_JOIN)
--                    )        
--             WHERE VALID IS NOT NULL
--       ) K 
--       ON ((COALESCE(J.SUBSIDIARY,J.SUBSIDIARY_2) = K.SUB) AND (COALESCE(J.SKU,J.SKU_2) = K.SKU) AND (COALESCE(J.REFER_DATE,J.DATE_2) = K.REFER_DATE))
--       WHERE J.VALID IS NULL
--       UNION ALL 
--       SELECT DISTINCT  * FROM (
--               SELECT DISTINCT O.SUBSIDIARY, 
--                         O.SKU, 
--                         O.REFER_DATE, 
--                         O.SUBSIDIARY_2, 
--                         O.SKU_2, 
--                         O.DATE_2, 
--                         O.VALID_PRICE_SAMSUNG, 
--                         O.VALID_PRICE_VAREJO, 
--                         O.VALID_FINAL, 
--                         O.ROW_NUM,
--                         D.MAX_TO_JOIN,
--                         CASE 
--                           WHEN D.MAX_TO_JOIN = 1 THEN O.VALID_FINAL 
--                           WHEN O.VALID_PRICE_SAMSUNG IS NULL OR O.VALID_PRICE_SAMSUNG = 'NOK' THEN 'NOK SAMSUNG'
--                           WHEN D.MAX_TO_JOIN = 2 AND (ROW_NUM = 1 OR ROW_NUM = 2) AND O.VALID_FINAL IN ('OK') THEN 'OK' 
--                           WHEN D.MAX_TO_JOIN = 3 AND (ROW_NUM IN (1,2,3)) AND O.VALID_FINAL IN ('OK') THEN 'OK' 
--                           ELSE NULL 
--                         END AS VALID
--               FROM (
--                       SELECT DISTINCT M.SUBSIDIARY, M.SKU, M.REFER_DATE, 
--                         N.SUBSIDIARY AS SUBSIDIARY_2, N.SKU AS SKU_2, N.REFER_DATE AS DATE_2,
--                         M.VALID_PRICE_SAMSUNG,N.VALID_PRICE_VAREJO,
--                         CASE 
--                           WHEN M.VALID_PRICE_SAMSUNG = 'OK' AND N.VALID_PRICE_VAREJO = 'OK' THEN 'OK'
--                           WHEN (M.VALID_PRICE_SAMSUNG = 'NOK' OR M.VALID_PRICE_SAMSUNG IS NULL)
--                            AND (N.VALID_PRICE_VAREJO = 'NOK' OR N.VALID_PRICE_VAREJO IS NULL) THEN 'NOK AMBOS'
--                           WHEN M.VALID_PRICE_SAMSUNG = 'OK' AND (N.VALID_PRICE_VAREJO = 'NOK' OR N.VALID_PRICE_VAREJO IS NULL) THEN 'NOK VAREJO'
--                           WHEN N.VALID_PRICE_VAREJO = 'OK' AND (M.VALID_PRICE_SAMSUNG = 'NOK' OR M.VALID_PRICE_SAMSUNG IS NULL) THEN 'NOK SAMSUNG'
--                         END VALID_FINAL,
--                         ROW_NUMBER() OVER (PARTITION BY COALESCE(M.SUBSIDIARY,N.SUBSIDIARY), COALESCE(M.SKU,N.SKU), COALESCE(M.REFER_DATE,N.REFER_DATE)
--                                            ORDER BY COALESCE(M.REFER_DATE,N.REFER_DATE) DESC, COALESCE(M.SUBSIDIARY,N.SUBSIDIARY), COALESCE(M.SKU,N.SKU) ASC) as ROW_NUM
--                       FROM 
--                         (SELECT DISTINCT SUBSIDIARY, SITE_COMPANY_NAME, SKU, PRICE_LOCAL_TO, REFER_DATE,
--                                 CASE WHEN PRICE_LOCAL_TO IS NOT NULL  THEN 'OK' ELSE 'NOK' END AS VALID_PRICE_SAMSUNG
--                            FROM OW_LAO.VW_CRAWLING_AP1_ESTORE_DAILY_PRICE
--                           WHERE SITE_COMPANY_NAME LIKE '%SAMSUNG%') M
--                       FULL OUTER JOIN
--                         (SELECT DISTINCT SUBSIDIARY, SITE_COMPANY_NAME, SKU, PRICE_LOCAL_TO, REFER_DATE,
--                                 CASE WHEN PRICE_LOCAL_TO IS NOT NULL  THEN 'OK' ELSE 'NOK' END AS VALID_PRICE_VAREJO
--                            FROM OW_LAO.VW_CRAWLING_AP1_ESTORE_DAILY_PRICE
--                           WHERE SITE_COMPANY_NAME NOT LIKE '%SAMSUNG%') N
--                         ON (UPPER(TRIM(M.SUBSIDIARY)) = UPPER(TRIM(N.SUBSIDIARY)) AND UPPER(TRIM(M.SKU)) = UPPER(TRIM(N.SKU)) AND M.REFER_DATE = N.REFER_DATE)
--                       ORDER BY COALESCE(M.REFER_DATE,N.REFER_DATE) DESC, COALESCE(M.SUBSIDIARY,N.SUBSIDIARY), COALESCE(M.SKU,N.SKU) ASC,ROW_NUM ASC 
--                    ) AS O
--               LEFT JOIN (
--                         SELECT COALESCE(SUBSIDIARY,SUBSIDIARY_2) AS SUB_TO_JOIN ,COALESCE(SKU,SKU_2) AS SKU_TO_JOIN,COALESCE(REFER_DATE,DATE_2) AS DATE_TO_JOIN,
--                                MAX(ROW_NUM) AS MAX_TO_JOIN
--                           FROM (
--                                   SELECT DISTINCT A.SUBSIDIARY,  A.SKU,  A.REFER_DATE, 
--                                          B.SUBSIDIARY AS SUBSIDIARY_2,  B.SKU AS SKU_2,  B.REFERDATE AS DATE_2,
--                                          A.VALID_PRICE_SAMSUNG,B.VALID_PRICE_VAREJO,
--                                          CASE 
--                                            WHEN A.VALID_PRICE_SAMSUNG = 'OK' AND B.VALID_PRICE_VAREJO = 'OK' THEN 'OK'
--                                            WHEN (A.VALID_PRICE_SAMSUNG = 'NOK' OR A.VALID_PRICE_SAMSUNG IS NULL)
--                                             AND (B.VALID_PRICE_VAREJO = 'NOK' OR B.VALID_PRICE_VAREJO IS NULL) THEN 'NOK AMBOS'
--                                            WHEN A.VALID_PRICE_SAMSUNG = 'OK' AND (B.VALID_PRICE_VAREJO = 'NOK' OR B.VALID_PRICE_VAREJO IS NULL) THEN 'NOK VAREJO'
--                                            WHEN B.VALID_PRICE_VAREJO = 'OK' AND (A.VALID_PRICE_SAMSUNG = 'NOK' OR A.VALID_PRICE_SAMSUNG IS NULL) THEN 'NOK SAMSUNG'
--                                          END VALID_FINAL,
--                                          ROW_NUMBER() OVER (PARTITION BY COALESCE(A.SUBSIDIARY,B.SUBSIDIARY), COALESCE(A.SKU,B.SKU), COALESCE(A.REFER_DATE,B.REFER_DATE)
--                                                             ORDER BY COALESCE(A.REFER_DATE,B.REFER_DATE) DESC, COALESCE(A.SUBSIDIARY,B.SUBSIDIARY), COALESCE(A.SKU,B.SKU) ASC) as ROW_NUM
--                                     FROM 
--                                       (SELECT DISTINCT SUBSIDIARY, SITE_COMPANY_NAME, SKU, PRICE_LOCAL_TO, REFER_DATE,
--                                               CASE WHEN PRICE_LOCAL_TO IS NOT NULL  THEN 'OK' ELSE 'NOK' END AS VALID_PRICE_SAMSUNG
--                                          FROM OW_LAO.VW_CRAWLING_AP1_ESTORE_DAILY_PRICE
--                                         WHERE SITE_COMPANY_NAME LIKE '%SAMSUNG%') A
--                                     FULL OUTER JOIN
--                                       (SELECT DISTINCT SUBSIDIARY, SITE_COMPANY_NAME, SKU, PRICE_LOCAL_TO, REFER_DATE,
--                                               CASE WHEN PRICE_LOCAL_TO IS NOT NULL  THEN 'OK' ELSE 'NOK' END AS VALID_PRICE_VAREJO
--                                          FROM OW_LAO.VW_CRAWLING_AP1_ESTORE_DAILY_PRICE
--                                         WHERE SITE_COMPANY_NAME NOT LIKE '%SAMSUNG%') B
--                                       ON (UPPER(TRIM(A.SUBSIDIARY)) = UPPER(TRIM(B.SUBSIDIARY))
--                                       AND UPPER(TRIM(A.SKU)) = UPPER(TRIM(B.SKU))
--                                       AND A.REFER_DATE = B.REFER_DATE)
--                                     ORDER BY COALESCE(A.REFER_DATE,B.REFER_DATE) DESC, COALESCE(A.SUBSIDIARY,B.SUBSIDIARY), COALESCE(A.SKU,B.SKU) ASC,ROW_NUM ASC
--                                ) AS C 
--                          GROUP BY COALESCE(SUBSIDIARY,SUBSIDIARY_2),COALESCE(SKU,SKU_2),COALESCE(REFER_DATE,DATE_2)
--                 ) AS D
--         ON (COALESCE(O.SUBSIDIARY,O.SUBSIDIARY_2) = D.SUB_TO_JOIN)
--        AND (COALESCE(O.SKU,O.SKU_2) = D.SKU_TO_JOIN)
--        AND (COALESCE(O.REFER_DATE,O.DATE_2) = D.DATE_TO_JOIN)
--       ORDER BY COALESCE(O.REFER_DATE,O.DATE_2) DESC, COALESCE(O.SUBSIDIARY,O.SUBSIDIARY_2), COALESCE(O.SKU,O.SKU_2) ASC, O.ROW_NUM ASC   
--     ) S WHERE S.VALID IS NOT NULL 
--     )
--     ORDER BY COALESCE(REFER_DATE,DATE_2) DESC, COALESCE(SUBSIDIARY,SUBSIDIARY_2), COALESCE(SKU,SKU_2) ASC, ROW_NUM ASC
--   );
-- 
--   /* Load fact table */
--   PERFORM TRUNCATE TABLE OW_LAO.FT_CRAWLING_AP1_ESTORE_DAILY_PRICE;
-- 
--   PERFORM INSERT INTO OW_LAO.FT_CRAWLING_AP1_ESTORE_DAILY_PRICE
--   SELECT
--     FT.SUBSIDIARY,
--     FT.COUNTRY,
--     FT.SKU,
--     FT.MODEL_DESC,
--     FT.SITE_COMPANY_NAME,
--     TO_DATE(FT.REFER_DATE,'YYYY-MM-DD') AS REFER_DATE,
--     FT.FROM_CURRENCY,
--     FT.TO_CURRENCY,
--     FT.PRICE_LOCAL_FROM,
--     FT.PRICE_LOCAL_TO,
--     FT.PRICE_USD_FROM,
--     FT.PRICE_USD_TO,
--     FT.SITE_URL,
--     FT.PRODUCT_DIVISION,
--     FT.PRODUCT_CATEGORY,
--     FT.PRODUCT_SUB_CATEGORY,
--     FT.PRODUCT_FAMILY,
--     FT.PRODUCT_SERIES,
--     FT.PREMIUM,
--     FT.STATUS_SITE,
--     TF.VALID 
--   FROM OW_LAO.VW_CRAWLING_AP1_ESTORE_DAILY_PRICE FT 
--   LEFT JOIN OW_LAO.TF_CRAWLING_AP1_ESTORE_DAILY_PRICE_AUX TF 
--     ON (FT.SUBSIDIARY = COALESCE(TF.SUBSIDIARY,TF.SUBSIDIARY_2) 
--     AND FT.SKU = COALESCE(TF.SKU,TF.SKU_2) 
--     AND FT.REFER_DATE = COALESCE(TF.REFER_DATE,TF.DATE_2));
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: Subquery in FROM must have an alias, Sqlstate: 42601, Hint: For example, FROM (SELECT ...) [AS] foo, Position: 5519, Routine: base_yyparse, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/gram.y, Line: 15782, Error Code: 4833, 
-- CREATE OR REPLACE PROCEDURE OW_LAO.PROC_CRAWLING_AP1_ESTORE_URL_SKU()
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--   /* If URL exists in both tables set status to ACTIVE */
--   PERFORM UPDATE OW_LAO.MAP_ESTORE_URL_SKU O
--      SET STATUS_SKU = 'ACTIVE',
--          LOAD_DATE = TO_CHAR(NOW())
--    FROM OW_LAO.TMP_MAP_ESTORE_URL_SKU T
--   WHERE TRIM(O.PROD_HREF) = TRIM(T.PROD_HREF)
--     AND TRIM(UPPER(O.SKU)) = TRIM(UPPER(T.SKU));
-- 
--   /* If URL exists only in temp table, insert into MAP */
--   PERFORM INSERT INTO OW_LAO.MAP_ESTORE_URL_SKU(
--     AP2,
--     COMPANY_NAME,
--     "DESC",
--     LAST_RUN_DATE,
--     LOAD_DATE,
--     PREMIUM,
--     PROD_HREF,
--     PRODUCT_CATEGORY,
--     PRODUCT_DIVISION,
--     PRODUCT_FAMILY,
--     PRODUCT_SERIES,
--     PRODUCT_SUB_CATEGORY,
--     SKU,
--     STATUS_SKU,
--     COLOR,
--     MEMORY,
--     TRADE_IN,
--     GIFT)
--   SELECT T.AP2,
--          T.COMPANY_NAME,
--          T."DESC",
--          NULL AS LAST_RUN_DATE,
--          T.LOAD_DATE,
--          T.PREMIUM,
--          T.PROD_HREF,
--          T.PRODUCT_CATEGORY,
--          T.PRODUCT_DIVISION,
--          T.PRODUCT_FAMILY,
--          T.PRODUCT_SERIES,
--          T.PRODUCT_SUB_CATEGORY,
--          T.SKU,
--          'ACTIVE' AS STATUS_SKU,
--          T.COLOR,
--          T.MEMORY,
--          T.TRADE_IN,
--          T.GIFT
--     FROM OW_LAO.MAP_ESTORE_URL_SKU O
--     RIGHT JOIN OW_LAO.TMP_MAP_ESTORE_URL_SKU T
--       ON (TRIM(O.PROD_HREF) = TRIM(T.PROD_HREF)
--       AND TRIM(UPPER(O.SKU)) = TRIM(UPPER(T.SKU)))
--    WHERE O.PROD_HREF IS NULL;
-- 
--   /* If URL exists only in MAP and not in temp, disable */
--   PERFORM UPDATE OW_LAO.MAP_ESTORE_URL_SKU O
--      SET STATUS_SKU = 'DISABLED'
--    WHERE NOT EXISTS (
--            SELECT 1
--              FROM OW_LAO.TMP_MAP_ESTORE_URL_SKU T
--             WHERE TRIM(O.PROD_HREF) = TRIM(T.PROD_HREF)
--               AND TRIM(UPPER(O.SKU)) = TRIM(UPPER(T.SKU))
--          );
-- 
--   /* Save daily snapshot into historical */
--   PERFORM INSERT INTO OW_LAO.MAP_ESTORE_URL_SKU_HISTORICAL (
--     SELECT ID_REF_URL,
--            AP2,
--            COMPANY_NAME,
--            "DESC",
--            LAST_RUN_DATE,
--            LOAD_DATE,
--            PREMIUM,
--            PROD_HREF,
--            PRODUCT_CATEGORY,
--            PRODUCT_DIVISION,
--            PRODUCT_FAMILY,
--            PRODUCT_SERIES,
--            PRODUCT_SUB_CATEGORY,
--            SKU,
--            STATUS_SKU,
--            COLOR,
--            MEMORY,
--            TRADE_IN,
--            GIFT,
--            NOW()
--       FROM OW_LAO.MAP_ESTORE_URL_SKU
--   );
-- 
--   /* Transformation stage 1 */
--   PERFORM TRUNCATE TABLE OW_LAO.TF_CRAWLING_AP1_ESTORE_URL_SKU_1;
-- 
--   PERFORM INSERT INTO OW_LAO.TF_CRAWLING_AP1_ESTORE_URL_SKU_1
--   (
--     SELECT DISTINCT
--         P.AP2 AS SUBSIDIARY,
--         P.COUNTRY AS COUNTRY,
--         P.SKU AS SKU,
--         P."DESC" AS MODEL_DESC,
--         P.COMPANY_NAME AS SITE_COMPANY_NAME,
--         P.TODAY_DATE AS REFER_DATE,
--         SUBSTR(P."DE_VALUE",1,16) AS RETAIL_PRICE_BASE,
--         SUBSTR(P."POR_VALUE",1,16) AS RETAIL_PRICE_ACTUAL,
--         SUBSTR(P."PROD_HREF",1,499) AS SITE_URL,
--         SUBSTR(P."CURRENCY",1,99) AS SITE_PRICE_CURRENCY,
--         D.PRODUCT_DIVISION AS PRODUCT_DIVISION,
--         D.PRODUCT_CATEGORY AS PRODUCT_CATEGORY,
--         D.PRODUCT_SUB_CATEGORY AS PRODUCT_SUB_CATEGORY,
--         D.PRODUCT_FAMILY AS PRODUCT_FAMILY,
--         D.PRODUCT_SERIES AS PRODUCT_SERIES,
--         D.PREMIUM AS PREMIUM,
--         CASE WHEN TRIM(UPPER(P.PROD_HREF)) <> TRIM(UPPER(P.PROD_HREF_OUT)) THEN 'URL  Redirected' ELSE P.STATUS_SITE END AS STATUS_SITE
--     FROM OW_LAO.ODS_CRAWLING_AP1_ESTORE_DAILY_PRICE P
--     INNER JOIN OW_LAO.MAP_ESTORE_URL_SKU_HISTORICAL D
--       ON TRIM(UPPER(P.PROD_HREF)) = TRIM(UPPER(D.PROD_HREF))
--      AND TRIM(UPPER(P.SKU)) = TRIM(UPPER(D.SKU))
--      AND TO_CHAR(P."TODAY_DATE", 'YYYY-MM-DD') = TO_CHAR(D."LOAD_DATE", 'YYYY-MM-DD')
--     WHERE TO_CHAR(P."TODAY_DATE", 'YYYY-MM-DD') < TO_CHAR(CURRENT_DATE, 'YYYY-MM-DD')
--   );
-- 
--   PERFORM UPDATE OW_LAO.TF_CRAWLING_AP1_ESTORE_URL_SKU_1
--      SET RETAIL_PRICE_BASE = REGEXP_SUBSTR(UPPER(TRIM(RETAIL_PRICE_BASE)), '[0-9]+([.][0-9]{1,2})?', 1, 1),
--          RETAIL_PRICE_ACTUAL = REGEXP_SUBSTR(UPPER(TRIM(RETAIL_PRICE_ACTUAL)), '[0-9]+([.][0-9]{1,2})?', 1, 1);
-- 
--   /* Transformation stage 2 */
--   PERFORM TRUNCATE TABLE OW_LAO.TF_CRAWLING_AP1_ESTORE_URL_SKU_2;
-- 
--   PERFORM INSERT INTO OW_LAO.TF_CRAWLING_AP1_ESTORE_URL_SKU_2
--   (
--     SELECT
--       SUBSIDIARY,
--       COUNTRY,
--       SKU,
--       MODEL_DESC,
--       SITE_COMPANY_NAME,
--       REFER_DATE,
--       SITE_URL,
--       SITE_PRICE_CURRENCY,
--       PRODUCT_DIVISION,
--       PRODUCT_CATEGORY,
--       PRODUCT_SUB_CATEGORY,
--       PRODUCT_FAMILY,
--       PRODUCT_SERIES,
--       PREMIUM,
--       STATUS_SITE,
--       ROUND(MAX(CAST(RETAIL_PRICE_BASE AS NUMERIC)),2) AS PRICE_LOCAL_FROM,
--       ROUND(MAX(CAST(RETAIL_PRICE_ACTUAL AS NUMERIC)),2) AS PRICE_LOCAL_TO
--     FROM OW_LAO.TF_CRAWLING_AP1_ESTORE_URL_SKU_1
--     GROUP BY
--       SUBSIDIARY,
--       COUNTRY,
--       SKU,
--       MODEL_DESC,
--       SITE_COMPANY_NAME,
--       REFER_DATE,
--       SITE_URL,
--       SITE_PRICE_CURRENCY,
--       PRODUCT_DIVISION,
--       PRODUCT_CATEGORY,
--       PRODUCT_SUB_CATEGORY,
--       PRODUCT_FAMILY,
--       PRODUCT_SERIES,
--       PREMIUM,
--       STATUS_SITE
--   );
-- 
--   /* Validation aux table */
--   PERFORM TRUNCATE TABLE OW_LAO.TF_CRAWLING_AP1_ESTORE_DAILY_PRICE_AUX;
-- 
--   PERFORM INSERT INTO OW_LAO.TF_CRAWLING_AP1_ESTORE_DAILY_PRICE_AUX
--   (
--     SELECT DISTINCT * FROM (
--       SELECT 
--               J.SUBSIDIARY, 
--               J.SKU, 
--               J.REFER_DATE, 
--               J.SUBSIDIARY_2, 
--               J.SKU_2, 
--               J.DATE_2, 
--               J.VALID_PRICE_SAMSUNG, 
--               J.VALID_PRICE_VAREJO, 
--               J.VALID_FINAL, 
--               J.ROW_NUM,
--               J.MAX_TO_JOIN,
--               COALESCE(K.VALID,'NOK VAREJO') AS VALID
--       FROM (
--               SELECT DISTINCT  O.SUBSIDIARY, 
--                         O.SKU, 
--                         O.REFER_DATE, 
--                         O.SUBSIDIARY_2, 
--                         O.SKU_2, 
--                         O.DATE_2, 
--                         O.VALID_PRICE_SAMSUNG, 
--                         O.VALID_PRICE_VAREJO, 
--                         O.VALID_FINAL, 
--                         O.ROW_NUM,
--                         D.MAX_TO_JOIN,
--                         CASE 
--                           WHEN D.MAX_TO_JOIN = 1 THEN O.VALID_FINAL 
--                           WHEN O.VALID_PRICE_SAMSUNG IS NULL OR O.VALID_PRICE_SAMSUNG = 'NOK' THEN 'NOK SAMSUNG'
--                           WHEN D.MAX_TO_JOIN = 2 AND (ROW_NUM = 1 OR ROW_NUM = 2) AND O.VALID_FINAL IN ('OK') THEN 'OK' 
--                           WHEN D.MAX_TO_JOIN = 3 AND (ROW_NUM IN (1,2,3)) AND O.VALID_FINAL IN ('OK') THEN 'OK' 
--                           ELSE NULL 
--                         END AS VALID
--               FROM (
--                       SELECT DISTINCT M.SUBSIDIARY, M.SKU, M.REFER_DATE, 
--                         N.SUBSIDIARY AS SUBSIDIARY_2, N.SKU AS SKU_2, N.REFER_DATE AS DATE_2,
--                         M.VALID_PRICE_SAMSUNG,N.VALID_PRICE_VAREJO,
--                         CASE 
--                           WHEN M.VALID_PRICE_SAMSUNG = 'OK' AND N.VALID_PRICE_VAREJO = 'OK' THEN 'OK'
--                           WHEN (M.VALID_PRICE_SAMSUNG = 'NOK' OR M.VALID_PRICE_SAMSUNG IS NULL)
--                            AND (N.VALID_PRICE_VAREJO = 'NOK' OR N.VALID_PRICE_VAREJO IS NULL) THEN 'NOK AMBOS'
--                           WHEN M.VALID_PRICE_SAMSUNG = 'OK' AND (N.VALID_PRICE_VAREJO = 'NOK' OR N.VALID_PRICE_VAREJO IS NULL) THEN 'NOK VAREJO'
--                           WHEN N.VALID_PRICE_VAREJO = 'OK' AND (M.VALID_PRICE_SAMSUNG = 'NOK' OR M.VALID_PRICE_SAMSUNG IS NULL) THEN 'NOK SAMSUNG'
--                         END VALID_FINAL,
--                         ROW_NUMBER() OVER (PARTITION BY COALESCE(M.SUBSIDIARY,N.SUBSIDIARY), COALESCE(M.SKU,N.SKU), COALESCE(M.REFER_DATE,N.REFER_DATE)
--                                            ORDER BY COALESCE(M.REFER_DATE,N.REFER_DATE) DESC, COALESCE(M.SUBSIDIARY,N.SUBSIDIARY), COALESCE(M.SKU,N.SKU) ASC) as ROW_NUM
--                       FROM 
--                         (SELECT DISTINCT SUBSIDIARY, SITE_COMPANY_NAME, SKU, PRICE_LOCAL_TO, REFER_DATE,
--                                 CASE WHEN PRICE_LOCAL_TO IS NOT NULL  THEN 'OK' ELSE 'NOK' END AS VALID_PRICE_SAMSUNG
--                            FROM OW_LAO.VW_CRAWLING_AP1_ESTORE_DAILY_PRICE
--                           WHERE SITE_COMPANY_NAME LIKE '%SAMSUNG%') M
--                       FULL OUTER JOIN
--                         (SELECT DISTINCT SUBSIDIARY, SITE_COMPANY_NAME, SKU, PRICE_LOCAL_TO, REFER_DATE,
--                                 CASE WHEN PRICE_LOCAL_TO IS NOT NULL  THEN 'OK' ELSE 'NOK' END AS VALID_PRICE_VAREJO
--                            FROM OW_LAO.VW_CRAWLING_AP1_ESTORE_DAILY_PRICE
--                           WHERE SITE_COMPANY_NAME NOT LIKE '%SAMSUNG%') N
--                         ON (UPPER(TRIM(M.SUBSIDIARY)) = UPPER(TRIM(N.SUBSIDIARY)) AND UPPER(TRIM(M.SKU)) = UPPER(TRIM(N.SKU)) AND M.REFER_DATE = N.REFER_DATE)
--                    ) AS O
--               LEFT JOIN (
--                         SELECT COALESCE(SUBSIDIARY,SUBSIDIARY_2) AS SUB_TO_JOIN ,COALESCE(SKU,SKU_2) AS SKU_TO_JOIN,COALESCE(REFER_DATE,DATE_2) AS DATE_TO_JOIN,
--                                MAX(ROW_NUM) AS MAX_TO_JOIN
--                           FROM (
--                                   SELECT DISTINCT A.SUBSIDIARY,  A.SKU,  A.REFER_DATE, 
--                                          B.SUBSIDIARY AS SUBSIDIARY_2,  B.SKU AS SKU_2,  B.REFER_DATE AS DATE_2,
--                                          A.VALID_PRICE_SAMSUNG,B.VALID_PRICE_VAREJO,
--                                          CASE 
--                                            WHEN A.VALID_PRICE_SAMSUNG = 'OK' AND B.VALID_PRICE_VAREJO = 'OK' THEN 'OK'
--                                            WHEN (A.VALID_PRICE_SAMSUNG = 'NOK' OR A.VALID_PRICE_SAMSUNG IS NULL)
--                                             AND (B.VALID_PRICE_VAREJO = 'NOK' OR B.VALID_PRICE_VAREJO IS NULL) THEN 'NOK AMBOS'
--                                            WHEN A.VALID_PRICE_SAMSUNG = 'OK' AND (B.VALID_PRICE_VAREJO = 'NOK' OR B.VALID_PRICE_VAREJO IS NULL) THEN 'NOK VAREJO'
--                                            WHEN B.VALID_PRICE_VAREJO = 'OK' AND (A.VALID_PRICE_SAMSUNG = 'NOK' OR A.VALID_PRICE_SAMSUNG IS NULL) THEN 'NOK SAMSUNG'
--                                          END VALID_FINAL,
--                                          ROW_NUMBER() OVER (PARTITION BY COALESCE(A.SUBSIDIARY,B.SUBSIDIARY), COALESCE(A.SKU,B.SKU), COALESCE(A.REFER_DATE,B.REFER_DATE)
--                                                             ORDER BY COALESCE(A.REFER_DATE,B.REFER_DATE) DESC, COALESCE(A.SUBSIDIARY,B.SUBSIDIARY), COALESCE(A.SKU,B.SKU) ASC) as ROW_NUM
--                                     FROM 
--                                       (SELECT DISTINCT SUBSIDIARY, SITE_COMPANY_NAME, SKU, PRICE_LOCAL_TO, REFER_DATE,
--                                               CASE WHEN PRICE_LOCAL_TO IS NOT NULL  THEN 'OK' ELSE 'NOK' END AS VALID_PRICE_SAMSUNG
--                                          FROM OW_LAO.VW_CRAWLING_AP1_ESTORE_DAILY_PRICE
--                                         WHERE SITE_COMPANY_NAME LIKE '%SAMSUNG%') A
--                                     FULL OUTER JOIN
--                                       (SELECT DISTINCT SUBSIDIARY, SITE_COMPANY_NAME, SKU, PRICE_LOCAL_TO, REFERDATE AS REFER_DATE, REFER_DATE AS REFERDATE
--                                        FROM (
--                                          SELECT SUBSIDIARY, SITE_COMPANY_NAME, SKU, PRICE_LOCAL_TO, REFER_DATE,
--                                                 REFER_DATE AS REFERDATE
--                                            FROM OW_LAO.VW_CRAWLING_AP1_ESTORE_DAILY_PRICE
--                                           WHERE SITE_COMPANY_NAME NOT LIKE '%SAMSUNG%'
--                                        ) B1
--                                       ) B
--                                       ON (UPPER(TRIM(A.SUBSIDIARY)) = UPPER(TRIM(B.SUBSIDIARY))
--                                       AND UPPER(TRIM(A.SKU)) = UPPER(TRIM(B.SKU))
--                                       AND A.REFER_DATE = B.REFER_DATE)
--                                ) AS C 
--                          GROUP BY COALESCE(SUBSIDIARY,SUBSIDIARY_2),COALESCE(SKU,SKU_2),COALESCE(REFER_DATE,DATE_2)
--                     ) AS D
--                 ON (COALESCE(O.SUBSIDIARY,O.SUBSIDIARY_2) = D.SUB_TO_JOIN)
--                AND (COALESCE(O.SKU,O.SKU_2) = D.SKU_TO_JOIN)
--                AND (COALESCE(O.REFER_DATE,O.DATE_2) = D.DATE_TO_JOIN)
--            ) J 
--       LEFT JOIN (
--             SELECT DISTINCT COALESCE(SUBSIDIARY,SUBSIDIARY_2) AS SUB , 
--                     COALESCE(SKU,SKU_2) AS SKU,
--                     COALESCE(REFER_DATE,DATE_2) AS REFER_DATE,
--                     VALID
--               FROM (
--                     SELECT DISTINCT O.SUBSIDIARY, 
--                            O.SKU, 
--                            O.REFER_DATE, 
--                            O.SUBSIDIARY_2, 
--                            O.SKU_2, 
--                            O.DATE_2, 
--                            O.VALID_PRICE_SAMSUNG, 
--                            O.VALID_PRICE_VAREJO, 
--                            O.VALID_FINAL, 
--                            O.ROW_NUM,
--                            D.MAX_TO_JOIN,
--                            CASE 
--                              WHEN D.MAX_TO_JOIN = 1 THEN O.VALID_FINAL 
--                              WHEN O.VALID_PRICE_SAMSUNG IS NULL OR O.VALID_PRICE_SAMSUNG = 'NOK' THEN 'NOK SAMSUNG'
--                              WHEN D.MAX_TO_JOIN = 2 AND (ROW_NUM = 1 OR ROW_NUM = 2) AND O.VALID_FINAL IN ('OK') THEN 'OK' 
--                              WHEN D.MAX_TO_JOIN = 3 AND (ROW_NUM IN (1,2,3)) AND O.VALID_FINAL IN ('OK') THEN 'OK' 
--                              ELSE NULL 
--                            END AS VALID
--                       FROM (
--                             SELECT DISTINCT M.SUBSIDIARY, M.SKU, M.REFER_DATE, 
--                                    N.SUBSIDIARY AS SUBSIDIARY_2, N.SKU AS SKU_2, N.REFER_DATE AS DATE_2,
--                                    M.VALID_PRICE_SAMSUNG,N.VALID_PRICE_VAREJO,
--                                    CASE 
--                                      WHEN M.VALID_PRICE_SAMSUNG = 'OK' AND N.VALID_PRICE_VAREJO = 'OK' THEN 'OK'
--                                      WHEN (M.VALID_PRICE_SAMSUNG = 'NOK' OR M.VALID_PRICE_SAMSUNG IS NULL)
--                                       AND (N.VALID_PRICE_VAREJO = 'NOK' OR N.VALID_PRICE_VAREJO IS NULL) THEN 'NOK AMBOS'
--                                      WHEN M.VALID_PRICE_SAMSUNG = 'OK' AND (N.VALID_PRICE_VAREJO = 'NOK' OR N.VALID_PRICE_VAREJO IS NULL) THEN 'NOK VAREJO'
--                                      WHEN N.VALID_PRICE_VAREJO = 'OK' AND (M.VALID_PRICE_SAMSUNG = 'NOK' OR M.VALID_PRICE_SAMSUNG IS NULL) THEN 'NOK SAMSUNG'
--                                    END VALID_FINAL,
--                                    ROW_NUMBER() OVER (PARTITION BY COALESCE(M.SUBSIDIARY,N.SUBSIDIARY), COALESCE(M.SKU,N.SKU), COALESCE(M.REFER_DATE,N.REFER_DATE)
--                                                       ORDER BY COALESCE(M.REFER_DATE,N.REFER_DATE) DESC, COALESCE(M.SUBSIDIARY,N.SUBSIDIARY), COALESCE(M.SKU,N.SKU) ASC) as ROW_NUM
--                               FROM (
--                                     SELECT DISTINCT SUBSIDIARY, SITE_COMPANY_NAME, SKU, PRICE_LOCAL_TO, REFER_DATE,
--                                            CASE WHEN PRICE_LOCAL_TO IS NOT NULL  THEN 'OK' ELSE 'NOK' END AS VALID_PRICE_SAMSUNG
--                                       FROM OW_LAO.VW_CRAWLING_AP1_ESTORE_DAILY_PRICE
--                                      WHERE SITE_COMPANY_NAME LIKE '%SAMSUNG%') M
--                               FULL OUTER JOIN
--                                     (SELECT DISTINCT SUBSIDIARY, SITE_COMPANY_NAME, SKU, PRICE_LOCAL_TO, REFER_DATE,
--                                            CASE WHEN PRICE_LOCAL_TO IS NOT NULL  THEN 'OK' ELSE 'NOK' END AS VALID_PRICE_VAREJO
--                                       FROM OW_LAO.VW_CRAWLING_AP1_ESTORE_DAILY_PRICE
--                                      WHERE SITE_COMPANY_NAME NOT LIKE '%SAMSUNG%') N
--                                 ON (UPPER(TRIM(M.SUBSIDIARY)) = UPPER(TRIM(N.SUBSIDIARY)) AND UPPER(TRIM(M.SKU)) = UPPER(TRIM(N.SKU)) AND M.REFER_DATE = N.REFER_DATE)
--                            ) AS O
--                       LEFT JOIN (
--                             SELECT COALESCE(SUBSIDIARY,SUBSIDIARY_2) AS SUB_TO_JOIN ,COALESCE(SKU,SKU_2) AS SKU_TO_JOIN,COALESCE(REFER_DATE,DATE_2) AS DATE_TO_JOIN,
--                                    MAX(ROW_NUM) AS MAX_TO_JOIN
--                               FROM (
--                                     SELECT DISTINCT A.SUBSIDIARY,  A.SKU,  A.REFER_DATE, 
--                                            B.SUBSIDIARY AS SUBSIDIARY_2,  B.SKU AS SKU_2,  B.REFER_DATE AS DATE_2,
--                                            A.VALID_PRICE_SAMSUNG,B.VALID_PRICE_VAREJO,
--                                            CASE 
--                                              WHEN A.VALID_PRICE_SAMSUNG = 'OK' AND B.VALID_PRICE_VAREJO = 'OK' THEN 'OK'
--                                              WHEN (A.VALID_PRICE_SAMSUNG = 'NOK' OR A.VALID_PRICE_SAMSUNG IS NULL)
--                                               AND (B.VALID_PRICE_VAREJO = 'NOK' OR B.VALID_PRICE_VAREJO IS NULL) THEN 'NOK AMBOS'
--                                              WHEN A.VALID_PRICE_SAMSUNG = 'OK' AND (B.VALID_PRICE_VAREJO = 'NOK' OR B.VALID_PRICE_VAREJO IS NULL) THEN 'NOK VAREJO'
--                                              WHEN B.VALID_PRICE_VAREJO = 'OK' AND (A.VALID_PRICE_SAMSUNG = 'NOK' OR A.VALID_PRICE_SAMSUNG IS NULL) THEN 'NOK SAMSUNG'
--                                            END VALID_FINAL,
--                                            ROW_NUMBER() OVER (PARTITION BY COALESCE(A.SUBSIDIARY,B.SUBSIDIARY), COALESCE(A.SKU,B.SKU), COALESCE(A.REFER_DATE,B.REFER_DATE)
--                                                               ORDER BY COALESCE(A.REFER_DATE,B.REFER_DATE) DESC, COALESCE(A.SUBSIDIARY,B.SUBSIDIARY), COALESCE(A.SKU,B.SKU) ASC) as ROW_NUM
--                                       FROM (
--                                             SELECT DISTINCT SUBSIDIARY, SITE_COMPANY_NAME, SKU, PRICE_LOCAL_TO, REFER_DATE,
--                                                    CASE WHEN PRICE_LOCAL_TO IS NOT NULL  THEN 'OK' ELSE 'NOK' END AS VALID_PRICE_SAMSUNG
--                                               FROM OW_LAO.VW_CRAWLING_AP1_ESTORE_DAILY_PRICE
--                                              WHERE SITE_COMPANY_NAME LIKE '%SAMSUNG%') A
--                                       FULL OUTER JOIN
--                                             (SELECT DISTINCT SUBSIDIARY, SITE_COMPANY_NAME, SKU, PRICE_LOCAL_TO, REFER_DATE,
--                                                    CASE WHEN PRICE_LOCAL_TO IS NOT NULL  THEN 'OK' ELSE 'NOK' END AS VALID_PRICE_VAREJO
--                                               FROM OW_LAO.VW_CRAWLING_AP1_ESTORE_DAILY_PRICE
--                                              WHERE SITE_COMPANY_NAME NOT LIKE '%SAMSUNG%') B
--                                         ON (UPPER(TRIM(A.SUBSIDIARY)) = UPPER(TRIM(B.SUBSIDIARY))
--                                         AND UPPER(TRIM(A.SKU)) = UPPER(TRIM(B.SKU))
--                                         AND A.REFER_DATE = B.REFER_DATE)
--                                    ) AS C 
--                              GROUP BY COALESCE(SUBSIDIARY,SUBSIDIARY_2),COALESCE(SKU,SKU_2),COALESCE(REFER_DATE,DATE_2)
--                            ) AS D
--                         ON (COALESCE(O.SUBSIDIARY,O.SUBSIDIARY_2) = D.SUB_TO_JOIN)
--                        AND (COALESCE(O.SKU,O.SKU_2) = D.SKU_TO_JOIN)
--                        AND (COALESCE(O.REFER_DATE,O.DATE_2) = D.DATE_TO_JOIN)
--                    )        
--             WHERE VALID IS NOT NULL
--       ) K 
--       ON ((COALESCE(J.SUBSIDIARY,J.SUBSIDIARY_2) = K.SUB) AND (COALESCE(J.SKU,J.SKU_2) = K.SKU) AND (COALESCE(J.REFER_DATE,J.DATE_2) = K.REFER_DATE))
--       WHERE J.VALID IS NULL
--       UNION ALL 
--       SELECT DISTINCT  * FROM (
--               SELECT DISTINCT O.SUBSIDIARY, 
--                         O.SKU, 
--                         O.REFER_DATE, 
--                         O.SUBSIDIARY_2, 
--                         O.SKU_2, 
--                         O.DATE_2, 
--                         O.VALID_PRICE_SAMSUNG, 
--                         O.VALID_PRICE_VAREJO, 
--                         O.VALID_FINAL, 
--                         O.ROW_NUM,
--                         D.MAX_TO_JOIN,
--                         CASE 
--                           WHEN D.MAX_TO_JOIN = 1 THEN O.VALID_FINAL 
--                           WHEN O.VALID_PRICE_SAMSUNG IS NULL OR O.VALID_PRICE_SAMSUNG = 'NOK' THEN 'NOK SAMSUNG'
--                           WHEN D.MAX_TO_JOIN = 2 AND (ROW_NUM = 1 OR ROW_NUM = 2) AND O.VALID_FINAL IN ('OK') THEN 'OK' 
--                           WHEN D.MAX_TO_JOIN = 3 AND (ROW_NUM IN (1,2,3)) AND O.VALID_FINAL IN ('OK') THEN 'OK' 
--                           ELSE NULL 
--                         END AS VALID
--               FROM (
--                       SELECT DISTINCT M.SUBSIDIARY, M.SKU, M.REFER_DATE, 
--                         N.SUBSIDIARY AS SUBSIDIARY_2, N.SKU AS SKU_2, N.REFER_DATE AS DATE_2,
--                         M.VALID_PRICE_SAMSUNG,N.VALID_PRICE_VAREJO,
--                         CASE 
--                           WHEN M.VALID_PRICE_SAMSUNG = 'OK' AND N.VALID_PRICE_VAREJO = 'OK' THEN 'OK'
--                           WHEN (M.VALID_PRICE_SAMSUNG = 'NOK' OR M.VALID_PRICE_SAMSUNG IS NULL)
--                            AND (N.VALID_PRICE_VAREJO = 'NOK' OR N.VALID_PRICE_VAREJO IS NULL) THEN 'NOK AMBOS'
--                           WHEN M.VALID_PRICE_SAMSUNG = 'OK' AND (N.VALID_PRICE_VAREJO = 'NOK' OR N.VALID_PRICE_VAREJO IS NULL) THEN 'NOK VAREJO'
--                           WHEN N.VALID_PRICE_VAREJO = 'OK' AND (M.VALID_PRICE_SAMSUNG = 'NOK' OR M.VALID_PRICE_SAMSUNG IS NULL) THEN 'NOK SAMSUNG'
--                         END VALID_FINAL,
--                         ROW_NUMBER() OVER (PARTITION BY COALESCE(M.SUBSIDIARY,N.SUBSIDIARY), COALESCE(M.SKU,N.SKU), COALESCE(M.REFER_DATE,N.REFER_DATE)
--                                            ORDER BY COALESCE(M.REFER_DATE,N.REFER_DATE) DESC, COALESCE(M.SUBSIDIARY,N.SUBSIDIARY), COALESCE(M.SKU,N.SKU) ASC) as ROW_NUM
--                       FROM 
--                         (SELECT DISTINCT SUBSIDIARY, SITE_COMPANY_NAME, SKU, PRICE_LOCAL_TO, REFER_DATE,
--                                 CASE WHEN PRICE_LOCAL_TO IS NOT NULL  THEN 'OK' ELSE 'NOK' END AS VALID_PRICE_SAMSUNG
--                            FROM OW_LAO.VW_CRAWLING_AP1_ESTORE_DAILY_PRICE
--                           WHERE SITE_COMPANY_NAME LIKE '%SAMSUNG%') M
--                       FULL OUTER JOIN
--                         (SELECT DISTINCT SUBSIDIARY, SITE_COMPANY_NAME, SKU, PRICE_LOCAL_TO, REFER_DATE,
--                                 CASE WHEN PRICE_LOCAL_TO IS NOT NULL  THEN 'OK' ELSE 'NOK' END AS VALID_PRICE_VAREJO
--                            FROM OW_LAO.VW_CRAWLING_AP1_ESTORE_DAILY_PRICE
--                           WHERE SITE_COMPANY_NAME NOT LIKE '%SAMSUNG%') N
--                         ON (UPPER(TRIM(M.SUBSIDIARY)) = UPPER(TRIM(N.SUBSIDIARY)) AND UPPER(TRIM(M.SKU)) = UPPER(TRIM(N.SKU)) AND M.REFER_DATE = N.REFER_DATE)
--                    ) AS O
--               LEFT JOIN (
--                         SELECT COALESCE(SUBSIDIARY,SUBSIDIARY_2) AS SUB_TO_JOIN ,COALESCE(SKU,SKU_2) AS SKU_TO_JOIN,COALESCE(REFER_DATE,DATE_2) AS DATE_TO_JOIN,
--                                MAX(ROW_NUM) AS MAX_TO_JOIN
--                           FROM (
--                                   SELECT DISTINCT A.SUBSIDIARY,  A.SKU,  A.REFER_DATE, 
--                                          B.SUBSIDIARY AS SUBSIDIARY_2,  B.SKU AS SKU_2,  B.REFER_DATE AS DATE_2,
--                                          A.VALID_PRICE_SAMSUNG,B.VALID_PRICE_VAREJO,
--                                          CASE 
--                                            WHEN A.VALID_PRICE_SAMSUNG = 'OK' AND B.VALID_PRICE_VAREJO = 'OK' THEN 'OK'
--                                            WHEN (A.VALID_PRICE_SAMSUNG = 'NOK' OR A.VALID_PRICE_SAMSUNG IS NULL)
--                                             AND (B.VALID_PRICE_VAREJO = 'NOK' OR B.VALID_PRICE_VAREJO IS NULL) THEN 'NOK AMBOS'
--                                            WHEN A.VALID_PRICE_SAMSUNG = 'OK' AND (B.VALID_PRICE_VAREJO = 'NOK' OR B.VALID_PRICE_VAREJO IS NULL) THEN 'NOK VAREJO'
--                                            WHEN B.VALID_PRICE_VAREJO = 'OK' AND (A.VALID_PRICE_SAMSUNG = 'NOK' OR A.VALID_PRICE_SAMSUNG IS NULL) THEN 'NOK SAMSUNG'
--                                          END VALID_FINAL,
--                                          ROW_NUMBER() OVER (PARTITION BY COALESCE(A.SUBSIDIARY,B.SUBSIDIARY), COALESCE(A.SKU,B.SKU), COALESCE(A.REFER_DATE,B.REFER_DATE)
--                                                             ORDER BY COALESCE(A.REFER_DATE,B.REFER_DATE) DESC, COALESCE(A.SUBSIDIARY,B.SUBSIDIARY), COALESCE(A.SKU,B.SKU) ASC) as ROW_NUM
--                                     FROM 
--                                       (SELECT DISTINCT SUBSIDIARY, SITE_COMPANY_NAME, SKU, PRICE_LOCAL_TO, REFER_DATE,
--                                               CASE WHEN PRICE_LOCAL_TO IS NOT NULL  THEN 'OK' ELSE 'NOK' END AS VALID_PRICE_SAMSUNG
--                                          FROM OW_LAO.VW_CRAWLING_AP1_ESTORE_DAILY_PRICE
--                                         WHERE SITE_COMPANY_NAME LIKE '%SAMSUNG%') A
--                                     FULL OUTER JOIN
--                                       (SELECT DISTINCT SUBSIDIARY, SITE_COMPANY_NAME, SKU, PRICE_LOCAL_TO, REFER_DATE,
--                                               CASE WHEN PRICE_LOCAL_TO IS NOT NULL  THEN 'OK' ELSE 'NOK' END AS VALID_PRICE_VAREJO
--                                          FROM OW_LAO.VW_CRAWLING_AP1_ESTORE_DAILY_PRICE
--                                         WHERE SITE_COMPANY_NAME NOT LIKE '%SAMSUNG%') B
--                                       ON (UPPER(TRIM(A.SUBSIDIARY)) = UPPER(TRIM(B.SUBSIDIARY))
--                                       AND UPPER(TRIM(A.SKU)) = UPPER(TRIM(B.SKU))
--                                       AND A.REFER_DATE = B.REFER_DATE)
--                                ) AS C 
--                          GROUP BY COALESCE(SUBSIDIARY,SUBSIDIARY_2),COALESCE(SKU,SKU_2),COALESCE(REFER_DATE,DATE_2)
--                 ) AS D
--         ON (COALESCE(O.SUBSIDIARY,O.SUBSIDIARY_2) = D.SUB_TO_JOIN)
--        AND (COALESCE(O.SKU,O.SKU_2) = D.SKU_TO_JOIN)
--        AND (COALESCE(O.REFER_DATE,O.DATE_2) = D.DATE_TO_JOIN)
--     ) S
--     WHERE S.VALID IS NOT NULL
--     ) X
--   );
-- 
--   /* Load fact table */
--   PERFORM TRUNCATE TABLE OW_LAO.FT_CRAWLING_AP1_ESTORE_DAILY_PRICE;
-- 
--   PERFORM INSERT INTO OW_LAO.FT_CRAWLING_AP1_ESTORE_DAILY_PRICE
--   SELECT
--     FT.SUBSIDIARY,
--     FT.COUNTRY,
--     FT.SKU,
--     FT.MODEL_DESC,
--     FT.SITE_COMPANY_NAME,
--     TO_DATE(FT.REFER_DATE,'YYYY-MM-DD') AS REFER_DATE,
--     FT.FROM_CURRENCY,
--     FT.TO_CURRENCY,
--     FT.PRICE_LOCAL_FROM,
--     FT.PRICE_LOCAL_TO,
--     FT.PRICE_USD_FROM,
--     FT.PRICE_USD_TO,
--     FT.SITE_URL,
--     FT.PRODUCT_DIVISION,
--     FT.PRODUCT_CATEGORY,
--     FT.PRODUCT_SUB_CATEGORY,
--     FT.PRODUCT_FAMILY,
--     FT.PRODUCT_SERIES,
--     FT.PREMIUM,
--     FT.STATUS_SITE,
--     TF.VALID 
--   FROM OW_LAO.VW_CRAWLING_AP1_ESTORE_DAILY_PRICE FT 
--   LEFT JOIN OW_LAO.TF_CRAWLING_AP1_ESTORE_DAILY_PRICE_AUX TF 
--     ON (FT.SUBSIDIARY = COALESCE(TF.SUBSIDIARY,TF.SUBSIDIARY_2) 
--     AND FT.SKU = COALESCE(TF.SKU,TF.SKU_2) 
--     AND FT.REFER_DATE = COALESCE(TF.REFER_DATE,TF.DATE_2));
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: Subquery in FROM must have an alias, Sqlstate: 42601, Hint: For example, FROM (SELECT ...) [AS] foo, Position: 5176, Routine: base_yyparse, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/gram.y, Line: 15782, Error Code: 4833, 
CREATE OR REPLACE PROCEDURE OW_LAO.PROC_CRAWLING_AP1_ESTORE_URL_SKU()
LANGUAGE PLvSQL AS $$
BEGIN
  /* 1) If URL exists in both tables set status to ACTIVE */
  PERFORM UPDATE OW_LAO.MAP_ESTORE_URL_SKU O
     SET STATUS_SKU = 'ACTIVE',
         LOAD_DATE = TO_CHAR(NOW())
   FROM OW_LAO.TMP_MAP_ESTORE_URL_SKU T
  WHERE TRIM(O.PROD_HREF) = TRIM(T.PROD_HREF)
    AND TRIM(UPPER(O.SKU)) = TRIM(UPPER(T.SKU));

  /* 2) If URL exists only in temp table, insert into MAP */
  PERFORM INSERT INTO OW_LAO.MAP_ESTORE_URL_SKU(
    AP2,
    COMPANY_NAME,
    "DESC",
    LAST_RUN_DATE,
    LOAD_DATE,
    PREMIUM,
    PROD_HREF,
    PRODUCT_CATEGORY,
    PRODUCT_DIVISION,
    PRODUCT_FAMILY,
    PRODUCT_SERIES,
    PRODUCT_SUB_CATEGORY,
    SKU,
    STATUS_SKU,
    COLOR,
    MEMORY,
    TRADE_IN,
    GIFT)
  SELECT T.AP2,
         T.COMPANY_NAME,
         T."DESC",
         NULL AS LAST_RUN_DATE,
         T.LOAD_DATE,
         T.PREMIUM,
         T.PROD_HREF,
         T.PRODUCT_CATEGORY,
         T.PRODUCT_DIVISION,
         T.PRODUCT_FAMILY,
         T.PRODUCT_SERIES,
         T.PRODUCT_SUB_CATEGORY,
         T.SKU,
         'ACTIVE' AS STATUS_SKU,
         T.COLOR,
         T.MEMORY,
         T.TRADE_IN,
         T.GIFT
    FROM OW_LAO.MAP_ESTORE_URL_SKU O
    RIGHT JOIN OW_LAO.TMP_MAP_ESTORE_URL_SKU T
      ON (TRIM(O.PROD_HREF) = TRIM(T.PROD_HREF)
      AND TRIM(UPPER(O.SKU)) = TRIM(UPPER(T.SKU)))
   WHERE O.PROD_HREF IS NULL;

  /* 3) If URL exists only in MAP and not in temp, disable */
  PERFORM UPDATE OW_LAO.MAP_ESTORE_URL_SKU O
     SET STATUS_SKU = 'DISABLED'
   WHERE NOT EXISTS (
           SELECT 1
             FROM OW_LAO.TMP_MAP_ESTORE_URL_SKU T
            WHERE TRIM(O.PROD_HREF) = TRIM(T.PROD_HREF)
              AND TRIM(UPPER(O.SKU)) = TRIM(UPPER(T.SKU))
         );

  /* 4) Save daily snapshot into historical */
  PERFORM INSERT INTO OW_LAO.MAP_ESTORE_URL_SKU_HISTORICAL
  SELECT ID_REF_URL,
         AP2,
         COMPANY_NAME,
         "DESC",
         LAST_RUN_DATE,
         LOAD_DATE,
         PREMIUM,
         PROD_HREF,
         PRODUCT_CATEGORY,
         PRODUCT_DIVISION,
         PRODUCT_FAMILY,
         PRODUCT_SERIES,
         PRODUCT_SUB_CATEGORY,
         SKU,
         STATUS_SKU,
         COLOR,
         MEMORY,
         TRADE_IN,
         GIFT,
         NOW()
    FROM OW_LAO.MAP_ESTORE_URL_SKU;

  /* 5) Transformation stage 1 */
  PERFORM TRUNCATE TABLE OW_LAO.TF_CRAWLING_AP1_ESTORE_URL_SKU_1;

  PERFORM INSERT INTO OW_LAO.TF_CRAWLING_AP1_ESTORE_URL_SKU_1
  (
    SELECT DISTINCT
        P.AP2 AS SUBSIDIARY,
        P.COUNTRY AS COUNTRY,
        P.SKU AS SKU,
        P."DESC" AS MODEL_DESC,
        P.COMPANY_NAME AS SITE_COMPANY_NAME,
        P.TODAY_DATE AS REFER_DATE,
        SUBSTR(P."DE_VALUE",1,16) AS RETAIL_PRICE_BASE,
        SUBSTR(P."POR_VALUE",1,16) AS RETAIL_PRICE_ACTUAL,
        SUBSTR(P."PROD_HREF",1,499) AS SITE_URL,
        SUBSTR(P."CURRENCY",1,99) AS SITE_PRICE_CURRENCY,
        D.PRODUCT_DIVISION AS PRODUCT_DIVISION,
        D.PRODUCT_CATEGORY AS PRODUCT_CATEGORY,
        D.PRODUCT_SUB_CATEGORY AS PRODUCT_SUB_CATEGORY,
        D.PRODUCT_FAMILY AS PRODUCT_FAMILY,
        D.PRODUCT_SERIES AS PRODUCT_SERIES,
        D.PREMIUM AS PREMIUM,
        CASE WHEN TRIM(UPPER(P.PROD_HREF)) <> TRIM(UPPER(P.PROD_HREF_OUT)) THEN 'URL  Redirected' ELSE P.STATUS_SITE END AS STATUS_SITE
    FROM OW_LAO.ODS_CRAWLING_AP1_ESTORE_DAILY_PRICE P
    INNER JOIN OW_LAO.MAP_ESTORE_URL_SKU_HISTORICAL D
      ON TRIM(UPPER(P.PROD_HREF)) = TRIM(UPPER(D.PROD_HREF))
     AND TRIM(UPPER(P.SKU)) = TRIM(UPPER(D.SKU))
     AND TO_CHAR(P."TODAY_DATE", 'YYYY-MM-DD') = TO_CHAR(D."LOAD_DATE", 'YYYY-MM-DD')
    WHERE TO_CHAR(P."TODAY_DATE", 'YYYY-MM-DD') < TO_CHAR(CURRENT_DATE, 'YYYY-MM-DD')
  );

  PERFORM UPDATE OW_LAO.TF_CRAWLING_AP1_ESTORE_URL_SKU_1
     SET RETAIL_PRICE_BASE = REGEXP_SUBSTR(UPPER(TRIM(RETAIL_PRICE_BASE)), '[0-9]+([.][0-9]{1,2})?', 1, 1),
         RETAIL_PRICE_ACTUAL = REGEXP_SUBSTR(UPPER(TRIM(RETAIL_PRICE_ACTUAL)), '[0-9]+([.][0-9]{1,2})?', 1, 1);

  /* 6) Transformation stage 2 */
  PERFORM TRUNCATE TABLE OW_LAO.TF_CRAWLING_AP1_ESTORE_URL_SKU_2;

  PERFORM INSERT INTO OW_LAO.TF_CRAWLING_AP1_ESTORE_URL_SKU_2
  (
    SELECT
      SUBSIDIARY,
      COUNTRY,
      SKU,
      MODEL_DESC,
      SITE_COMPANY_NAME,
      REFER_DATE,
      SITE_URL,
      SITE_PRICE_CURRENCY,
      PRODUCT_DIVISION,
      PRODUCT_CATEGORY,
      PRODUCT_SUB_CATEGORY,
      PRODUCT_FAMILY,
      PRODUCT_SERIES,
      PREMIUM,
      STATUS_SITE,
      ROUND(MAX(CAST(RETAIL_PRICE_BASE AS NUMERIC)),2) AS PRICE_LOCAL_FROM,
      ROUND(MAX(CAST(RETAIL_PRICE_ACTUAL AS NUMERIC)),2) AS PRICE_LOCAL_TO
    FROM OW_LAO.TF_CRAWLING_AP1_ESTORE_URL_SKU_1
    GROUP BY
      SUBSIDIARY,
      COUNTRY,
      SKU,
      MODEL_DESC,
      SITE_COMPANY_NAME,
      REFER_DATE,
      SITE_URL,
      SITE_PRICE_CURRENCY,
      PRODUCT_DIVISION,
      PRODUCT_CATEGORY,
      PRODUCT_SUB_CATEGORY,
      PRODUCT_FAMILY,
      PRODUCT_SERIES,
      PREMIUM,
      STATUS_SITE
  );

  /* 7) Build validation auxiliary table */
  PERFORM TRUNCATE TABLE OW_LAO.TF_CRAWLING_AP1_ESTORE_DAILY_PRICE_AUX;

  PERFORM INSERT INTO OW_LAO.TF_CRAWLING_AP1_ESTORE_DAILY_PRICE_AUX
  (
    WITH
    M AS (
      SELECT DISTINCT SUBSIDIARY, SITE_COMPANY_NAME, SKU, PRICE_LOCAL_TO, REFER_DATE,
             CASE WHEN PRICE_LOCAL_TO IS NOT NULL THEN 'OK' ELSE 'NOK' END AS VALID_PRICE_SAMSUNG
        FROM OW_LAO.VW_CRAWLING_AP1_ESTORE_DAILY_PRICE
       WHERE SITE_COMPANY_NAME LIKE '%SAMSUNG%'
    ),
    N AS (
      SELECT DISTINCT SUBSIDIARY, SITE_COMPANY_NAME, SKU, PRICE_LOCAL_TO, REFER_DATE,
             CASE WHEN PRICE_LOCAL_TO IS NOT NULL THEN 'OK' ELSE 'NOK' END AS VALID_PRICE_VAREJO
        FROM OW_LAO.VW_CRAWLING_AP1_ESTORE_DAILY_PRICE
       WHERE SITE_COMPANY_NAME NOT LIKE '%SAMSUNG%'
    ),
    O AS (
      SELECT DISTINCT 
             M.SUBSIDIARY, M.SKU, M.REFER_DATE,
             N.SUBSIDIARY AS SUBSIDIARY_2, N.SKU AS SKU_2, N.REFER_DATE AS DATE_2,
             M.VALID_PRICE_SAMSUNG, N.VALID_PRICE_VAREJO,
             CASE 
               WHEN M.VALID_PRICE_SAMSUNG = 'OK' AND N.VALID_PRICE_VAREJO = 'OK' THEN 'OK'
               WHEN (M.VALID_PRICE_SAMSUNG = 'NOK' OR M.VALID_PRICE_SAMSUNG IS NULL)
                 AND (N.VALID_PRICE_VAREJO = 'NOK' OR N.VALID_PRICE_VAREJO IS NULL) THEN 'NOK AMBOS'
               WHEN M.VALID_PRICE_SAMSUNG = 'OK' AND (N.VALID_PRICE_VAREJO = 'NOK' OR N.VALID_PRICE_VAREJO IS NULL) THEN 'NOK VAREJO'
               WHEN N.VALID_PRICE_VAREJO = 'OK' AND (M.VALID_PRICE_SAMSUNG = 'NOK' OR M.VALID_PRICE_SAMSUNG IS NULL) THEN 'NOK SAMSUNG'
             END AS VALID_FINAL,
             ROW_NUMBER() OVER (
               PARTITION BY COALESCE(M.SUBSIDIARY,N.SUBSIDIARY), COALESCE(M.SKU,N.SKU), COALESCE(M.REFER_DATE,N.REFER_DATE)
               ORDER BY COALESCE(M.REFER_DATE,N.REFER_DATE) DESC, COALESCE(M.SUBSIDIARY,N.SUBSIDIARY), COALESCE(M.SKU,N.SKU)
             ) AS ROW_NUM
        FROM M
        FULL OUTER JOIN N
          ON (UPPER(TRIM(M.SUBSIDIARY)) = UPPER(TRIM(N.SUBSIDIARY))
          AND UPPER(TRIM(M.SKU)) = UPPER(TRIM(N.SKU))
          AND M.REFER_DATE = N.REFER_DATE)
    ),
    D AS (
      SELECT COALESCE(SUBSIDIARY,SUBSIDIARY_2) AS SUB_TO_JOIN,
             COALESCE(SKU,SKU_2) AS SKU_TO_JOIN,
             COALESCE(REFER_DATE,DATE_2) AS DATE_TO_JOIN,
             MAX(ROW_NUM) AS MAX_TO_JOIN
        FROM O
       GROUP BY 1,2,3
    ),
    J AS (
      SELECT DISTINCT
             O.SUBSIDIARY, O.SKU, O.REFER_DATE,
             O.SUBSIDIARY_2, O.SKU_2, O.DATE_2,
             O.VALID_PRICE_SAMSUNG, O.VALID_PRICE_VAREJO,
             O.VALID_FINAL, O.ROW_NUM,
             D.MAX_TO_JOIN,
             CASE
               WHEN D.MAX_TO_JOIN = 1 THEN O.VALID_FINAL
               WHEN O.VALID_PRICE_SAMSUNG IS NULL OR O.VALID_PRICE_SAMSUNG = 'NOK' THEN 'NOK SAMSUNG'
               WHEN D.MAX_TO_JOIN = 2 AND O.ROW_NUM IN (1,2) AND O.VALID_FINAL IN ('OK') THEN 'OK'
               WHEN D.MAX_TO_JOIN = 3 AND O.ROW_NUM IN (1,2,3) AND O.VALID_FINAL IN ('OK') THEN 'OK'
               ELSE NULL
             END AS VALID
        FROM O
        LEFT JOIN D
          ON (COALESCE(O.SUBSIDIARY,O.SUBSIDIARY_2) = D.SUB_TO_JOIN
          AND COALESCE(O.SKU,O.SKU_2) = D.SKU_TO_JOIN
          AND COALESCE(O.REFER_DATE,O.DATE_2) = D.DATE_TO_JOIN)
    ),
    K AS (
      SELECT DISTINCT 
             COALESCE(SUBSIDIARY,SUBSIDIARY_2) AS SUB,
             COALESCE(SKU,SKU_2) AS SKU,
             COALESCE(REFER_DATE,DATE_2) AS REFER_DATE,
             VALID
        FROM J
       WHERE VALID IS NOT NULL
    )
    SELECT DISTINCT 
           J.SUBSIDIARY, J.SKU, J.REFER_DATE, 
           J.SUBSIDIARY_2, J.SKU_2, J.DATE_2,
           J.VALID_PRICE_SAMSUNG, J.VALID_PRICE_VAREJO, J.VALID_FINAL,
           J.ROW_NUM, J.MAX_TO_JOIN,
           COALESCE(K.VALID,'NOK VAREJO') AS VALID
      FROM J
      LEFT JOIN K
        ON (COALESCE(J.SUBSIDIARY,J.SUBSIDIARY_2) = K.SUB
        AND COALESCE(J.SKU,J.SKU_2) = K.SKU
        AND COALESCE(J.REFER_DATE,J.DATE_2) = K.REFER_DATE)
     WHERE J.VALID IS NULL
     UNION ALL
    SELECT DISTINCT 
           J.SUBSIDIARY, J.SKU, J.REFER_DATE, 
           J.SUBSIDIARY_2, J.SKU_2, J.DATE_2,
           J.VALID_PRICE_SAMSUNG, J.VALID_PRICE_VAREJO, J.VALID_FINAL,
           J.ROW_NUM, J.MAX_TO_JOIN,
           J.VALID
      FROM J
     WHERE J.VALID IS NOT NULL
  );

  /* 8) Load fact table */
  PERFORM TRUNCATE TABLE OW_LAO.FT_CRAWLING_AP1_ESTORE_DAILY_PRICE;

  PERFORM INSERT INTO OW_LAO.FT_CRAWLING_AP1_ESTORE_DAILY_PRICE
  SELECT
    FT.SUBSIDIARY,
    FT.COUNTRY,
    FT.SKU,
    FT.MODEL_DESC,
    FT.SITE_COMPANY_NAME,
    TO_DATE(FT.REFER_DATE,'YYYY-MM-DD') AS REFER_DATE,
    FT.FROM_CURRENCY,
    FT.TO_CURRENCY,
    FT.PRICE_LOCAL_FROM,
    FT.PRICE_LOCAL_TO,
    FT.PRICE_USD_FROM,
    FT.PRICE_USD_TO,
    FT.SITE_URL,
    FT.PRODUCT_DIVISION,
    FT.PRODUCT_CATEGORY,
    FT.PRODUCT_SUB_CATEGORY,
    FT.PRODUCT_FAMILY,
    FT.PRODUCT_SERIES,
    FT.PREMIUM,
    FT.STATUS_SITE,
    TF.VALID 
  FROM OW_LAO.VW_CRAWLING_AP1_ESTORE_DAILY_PRICE FT 
  LEFT JOIN OW_LAO.TF_CRAWLING_AP1_ESTORE_DAILY_PRICE_AUX TF 
    ON (FT.SUBSIDIARY = COALESCE(TF.SUBSIDIARY,TF.SUBSIDIARY_2) 
    AND FT.SKU = COALESCE(TF.SKU,TF.SKU_2) 
    AND FT.REFER_DATE = COALESCE(TF.REFER_DATE,TF.DATE_2));
END;
$$;

-- CALL OW_LAO.PROC_CRAWLING_AP1_ESTORE_URL_SKU();
-- ERROR: Severity: ERROR, Message: Table "OW_LAO.MAP_ESTORE_URL_SKU" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_CRAWLING_AP1_ESTORE_URL_SKU line 4 at static SQL, Routine: throwErrInvalidTab, File: analyze.c, Line: 3378, Error Code: 4883, 
-- CALL OW_LAO.PROC_CRAWLING_AP1_ESTORE_URL_SKU();
-- ERROR: Severity: ERROR, Message: Table "OW_LAO.MAP_ESTORE_URL_SKU" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_CRAWLING_AP1_ESTORE_URL_SKU line 4 at static SQL, Routine: throwErrInvalidTab, File: analyze.c, Line: 3378, Error Code: 4883, 
