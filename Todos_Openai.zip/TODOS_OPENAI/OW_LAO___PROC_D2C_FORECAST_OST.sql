-- CREATE OR REPLACE PROCEDURE OW_LAO.PROC_D2C_FORECAST_OST()
-- LANGUAGE PLvSQL AS $$
-- DECLARE
--     counter INT DEFAULT 1;
-- BEGIN
--     -- Drop temp tables if exist
--     PERFORM DROP TABLE IF EXISTS OW_LAO.TMP_FBL5N_FORECAST;
--     PERFORM DROP TABLE IF EXISTS OW_LAO.TMP_OST_FORECAST;
-- 
--     -- Create TMP_FBL5N_FORECAST
--     PERFORM CREATE TABLE OW_LAO.TMP_FBL5N_FORECAST AS
--     SELECT
--           CUSTOMER
--         , DOCUMENT_DATE
--         , DOCUMENT_NUMBER
--         , LINE_ITEM
--         , LOAD_DATE
--         , MAC.CUSTOMER_NAME_SUMMARY AS CHANNEL
--         , MAC.CUSTOMER_NAME_DETAIL AS SUBCHANNEL
--         , (CAST(AMOUNT_IN_LOCAL_CURRENCY AS DECIMAL(18,2)) * -1) AS AMOUNT
--     FROM (
--         SELECT
--               ROW_NUMBER() OVER (
--                   PARTITION BY FB.CUSTOMER, FB.DOCUMENT_DATE, FB.DOCUMENT_NUMBER, FB.LINE_ITEM
--                   ORDER BY FB.CUSTOMER, FB.DOCUMENT_DATE, FB.DOCUMENT_NUMBER, FB.LINE_ITEM
--               ) AS ROW_COUNT
--             , FB.CUSTOMER
--             , FB.DOCUMENT_DATE
--             , FB.DOCUMENT_NUMBER
--             , FB.LINE_ITEM
--             , FB.LOAD_DATE
--             , MAC.CUSTOMER_NAME_SUMMARY
--             , MAC.CUSTOMER_NAME_DETAIL
--             , FB.LOCAL_CURRENCY
--             , FB.AMOUNT_IN_LOCAL_CURRENCY
--         FROM OW_SEDA_S.ODS_NERP_FBL5N_CUSTOMER_LINE_ITEM_DISPLAY_OPEN_ITEMS_HIST FB
--         INNER JOIN (
--             SELECT CUSTOMER
--                  , DOCUMENT_DATE
--                  , DOCUMENT_NUMBER
--                  , LINE_ITEM
--                  , MAX(LOAD_DATE) AS LOAD_DATE
--             FROM OW_SEDA_S.ODS_NERP_FBL5N_CUSTOMER_LINE_ITEM_DISPLAY_OPEN_ITEMS_HIST
--             WHERE DOCUMENT_TYPE = 'DK'
--               AND POSTING_KEY = 19
--             GROUP BY CUSTOMER, DOCUMENT_DATE, DOCUMENT_NUMBER, LINE_ITEM
--         ) FL
--           ON FB.CUSTOMER = FL.CUSTOMER
--          AND FB.DOCUMENT_DATE = FL.DOCUMENT_DATE
--          AND FB.DOCUMENT_NUMBER = FL.DOCUMENT_NUMBER
--          AND FB.LINE_ITEM = FL.LINE_ITEM
--          AND FB.LOAD_DATE = FL.LOAD_DATE
--         LEFT JOIN OW_MD.MAP_AR_MONTH_CUSTOMER MAC
--           ON FB.CUSTOMER = MAC.CUSTOMER_CODE
--     ) FBL
--     WHERE FBL.ROW_COUNT = 1;
-- 
--     -- Create TMP_OST_FORECAST with initial actuals and moving average
--     PERFORM CREATE TABLE OW_LAO.TMP_OST_FORECAST AS
--     SELECT
--           s.YEAR_MONTH
--         , s.CHANNEL
--         , s.SUBCHANNEL
--         , s.AMOUNT
--         , AVG(s.AMOUNT) OVER (
--             PARTITION BY s.SUBCHANNEL
--             ORDER BY s.YEAR_MONTH
--             ROWS BETWEEN 2 PRECEDING AND CURRENT ROW
--           ) AS AVG_LAST_3_MONTHS_ACTUAL
--         , 0 AS IS_FORECAST
--     FROM (
--         SELECT YEAR_MONTH, CHANNEL, SUBCHANNEL, SUM(AMOUNT) AS AMOUNT
--         FROM (
--             SELECT
--                   TO_CHAR(DOCUMENT_DATE, 'YYYY-MM') AS YEAR_MONTH
--                 , CHANNEL
--                 , SUBCHANNEL
--                 , AMOUNT
--             FROM OW_LAO.TMP_FBL5N_FORECAST
--             WHERE EXTRACT(YEAR FROM DOCUMENT_DATE) >= 2024
-- 
--             UNION ALL
-- 
--             SELECT
--                   TO_CHAR(DOCUMENT_DATE, 'YYYY-MM') AS YEAR_MONTH
--                 , CHANNEL
--                 , SUBCHANNEL
--                 , AMOUNT * -1 AS AMOUNT
--             FROM OW_LAO.RAW_REPASSES_D2C_2022_2024
--             WHERE EXTRACT(YEAR FROM DOCUMENT_DATE) < 2024
--         ) b
--         GROUP BY YEAR_MONTH, CHANNEL, SUBCHANNEL
--     ) s;
-- 
--     -- Forecast next 3 months iteratively
--     WHILE counter <= 3 LOOP
--         -- Insert one month of forecast per (channel, subchannel)
--         PERFORM INSERT INTO OW_LAO.TMP_OST_FORECAST (
--               YEAR_MONTH
--             , CHANNEL
--             , SUBCHANNEL
--             , AMOUNT
--             , IS_FORECAST
--         )
--         SELECT
--               TO_CHAR(ADD_MONTHS(TO_DATE(F.YEAR_MONTH || '-01', 'YYYY-MM-DD'), 1), 'YYYY-MM') AS YEAR_MONTH_
--             , F.CHANNEL
--             , F.SUBCHANNEL
--             , F.AVG_LAST_3_MONTHS_ACTUAL AS AMOUNT
--             , 1 AS IS_FORECAST
--         FROM OW_LAO.TMP_OST_FORECAST F
--         INNER JOIN (
--             SELECT CHANNEL, SUBCHANNEL, MAX(YEAR_MONTH) AS YEAR_MONTH
--             FROM OW_LAO.TMP_OST_FORECAST
--             GROUP BY CHANNEL, SUBCHANNEL
--         ) L
--           ON F.YEAR_MONTH = L.YEAR_MONTH
--          AND F.CHANNEL = L.CHANNEL
--          AND F.SUBCHANNEL = L.SUBCHANNEL;
-- 
--         -- Recompute moving average over monthly sums per subchannel and update rows
--         PERFORM UPDATE OW_LAO.TMP_OST_FORECAST F
--         SET AVG_LAST_3_MONTHS_ACTUAL = L.AVG_LAST_3_MONTHS_ACTUAL
--         FROM (
--             WITH month_sum AS (
--                 SELECT YEAR_MONTH, SUBCHANNEL, SUM(AMOUNT) AS MONTH_AMT
--                 FROM OW_LAO.TMP_OST_FORECAST
--                 GROUP BY YEAR_MONTH, SUBCHANNEL
--             ),
--             avg3 AS (
--                 SELECT YEAR_MONTH, SUBCHANNEL,
--                        AVG(MONTH_AMT) OVER (
--                            PARTITION BY SUBCHANNEL
--                            ORDER BY YEAR_MONTH
--                            ROWS BETWEEN 2 PRECEDING AND CURRENT ROW
--                        ) AS AVG_LAST_3_MONTHS_ACTUAL
--                 FROM month_sum
--             )
--             SELECT DISTINCT F2.YEAR_MONTH, F2.CHANNEL, F2.SUBCHANNEL, A.AVG_LAST_3_MONTHS_ACTUAL
--             FROM OW_LAO.TMP_OST_FORECAST F2
--             JOIN avg3 A
--               ON F2.YEAR_MONTH = A.YEAR_MONTH
--              AND F2.SUBCHANNEL = A.SUBCHANNEL
--         ) L
--         WHERE F.YEAR_MONTH = L.YEAR_MONTH
--           AND F.CHANNEL = L.CHANNEL
--           AND F.SUBCHANNEL = L.SUBCHANNEL;
-- 
--         counter := counter + 1;
--     END LOOP;
-- 
--     -- Build final fact table
--     PERFORM DROP TABLE IF EXISTS OW_LAO.FT_D2C_FORECAST_OST;
--     PERFORM CREATE TABLE OW_LAO.FT_D2C_FORECAST_OST AS
--     SELECT
--           F.YEAR_MONTH
--         , F.CHANNEL
--         , F.SUBCHANNEL
--         , CASE WHEN F.IS_FORECAST = 0 THEN F.AMOUNT END AS AMOUNT
--         , FO.FORECAST_AMOUNT AS FORECAST_AMOUNT
--         , F.IS_FORECAST
--     FROM OW_LAO.TMP_OST_FORECAST F
--     JOIN (
--         WITH month_sum AS (
--             SELECT YEAR_MONTH, SUBCHANNEL, SUM(AMOUNT) AS MONTH_AMT
--             FROM OW_LAO.TMP_OST_FORECAST
--             GROUP BY YEAR_MONTH, SUBCHANNEL
--         )
--         SELECT YEAR_MONTH, SUBCHANNEL,
--                AVG(MONTH_AMT) OVER (
--                    PARTITION BY SUBCHANNEL
--                    ORDER BY YEAR_MONTH
--                    ROWS BETWEEN 3 PRECEDING AND 1 PRECEDING
--                ) AS FORECAST_AMOUNT
--         FROM month_sum
--     ) FO
--       ON FO.YEAR_MONTH = F.YEAR_MONTH
--      AND FO.SUBCHANNEL = F.SUBCHANNEL;
-- 
--     -- Cleanup temp tables
--     PERFORM DROP TABLE IF EXISTS OW_LAO.TMP_FBL5N_FORECAST;
--     PERFORM DROP TABLE IF EXISTS OW_LAO.TMP_OST_FORECAST;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: Syntax error at or near "DEFAULT", Sqlstate: 42601, Position: 106, Routine: base_yyerror, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/scan.l, Line: 1056, Error Code: 4856, 
CREATE OR REPLACE PROCEDURE OW_LAO.PROC_D2C_FORECAST_OST()
LANGUAGE PLvSQL AS $$
DECLARE
    counter INT;
BEGIN
    counter := 1;

    -- Drop temp tables if exist
    PERFORM DROP TABLE IF EXISTS OW_LAO.TMP_FBL5N_FORECAST;
    PERFORM DROP TABLE IF EXISTS OW_LAO.TMP_OST_FORECAST;

    -- Create TMP_FBL5N_FORECAST
    PERFORM CREATE TABLE OW_LAO.TMP_FBL5N_FORECAST AS
    SELECT
          CUSTOMER
        , DOCUMENT_DATE
        , DOCUMENT_NUMBER
        , LINE_ITEM
        , LOAD_DATE
        , MAC.CUSTOMER_NAME_SUMMARY AS CHANNEL
        , MAC.CUSTOMER_NAME_DETAIL AS SUBCHANNEL
        , (CAST(AMOUNT_IN_LOCAL_CURRENCY AS DECIMAL(18,2)) * -1) AS AMOUNT
    FROM (
        SELECT
              ROW_NUMBER() OVER (
                  PARTITION BY FB.CUSTOMER, FB.DOCUMENT_DATE, FB.DOCUMENT_NUMBER, FB.LINE_ITEM
                  ORDER BY FB.CUSTOMER, FB.DOCUMENT_DATE, FB.DOCUMENT_NUMBER, FB.LINE_ITEM
              ) AS ROW_COUNT
            , FB.CUSTOMER
            , FB.DOCUMENT_DATE
            , FB.DOCUMENT_NUMBER
            , FB.LINE_ITEM
            , FB.LOAD_DATE
            , MAC.CUSTOMER_NAME_SUMMARY
            , MAC.CUSTOMER_NAME_DETAIL
            , FB.LOCAL_CURRENCY
            , FB.AMOUNT_IN_LOCAL_CURRENCY
        FROM OW_SEDA_S.ODS_NERP_FBL5N_CUSTOMER_LINE_ITEM_DISPLAY_OPEN_ITEMS_HIST FB
        INNER JOIN (
            SELECT CUSTOMER
                 , DOCUMENT_DATE
                 , DOCUMENT_NUMBER
                 , LINE_ITEM
                 , MAX(LOAD_DATE) AS LOAD_DATE
            FROM OW_SEDA_S.ODS_NERP_FBL5N_CUSTOMER_LINE_ITEM_DISPLAY_OPEN_ITEMS_HIST
            WHERE DOCUMENT_TYPE = 'DK'
              AND POSTING_KEY = 19
            GROUP BY CUSTOMER, DOCUMENT_DATE, DOCUMENT_NUMBER, LINE_ITEM
        ) FL
          ON FB.CUSTOMER = FL.CUSTOMER
         AND FB.DOCUMENT_DATE = FL.DOCUMENT_DATE
         AND FB.DOCUMENT_NUMBER = FL.DOCUMENT_NUMBER
         AND FB.LINE_ITEM = FL.LINE_ITEM
         AND FB.LOAD_DATE = FL.LOAD_DATE
        LEFT JOIN OW_MD.MAP_AR_MONTH_CUSTOMER MAC
          ON FB.CUSTOMER = MAC.CUSTOMER_CODE
    ) FBL
    WHERE FBL.ROW_COUNT = 1;

    -- Create TMP_OST_FORECAST with initial actuals and moving average
    PERFORM CREATE TABLE OW_LAO.TMP_OST_FORECAST AS
    SELECT
          s.YEAR_MONTH
        , s.CHANNEL
        , s.SUBCHANNEL
        , s.AMOUNT
        , AVG(s.AMOUNT) OVER (
            PARTITION BY s.SUBCHANNEL
            ORDER BY s.YEAR_MONTH
            ROWS BETWEEN 2 PRECEDING AND CURRENT ROW
          ) AS AVG_LAST_3_MONTHS_ACTUAL
        , 0 AS IS_FORECAST
    FROM (
        SELECT YEAR_MONTH, CHANNEL, SUBCHANNEL, SUM(AMOUNT) AS AMOUNT
        FROM (
            SELECT
                  TO_CHAR(DOCUMENT_DATE, 'YYYY-MM') AS YEAR_MONTH
                , CHANNEL
                , SUBCHANNEL
                , AMOUNT
            FROM OW_LAO.TMP_FBL5N_FORECAST
            WHERE EXTRACT(YEAR FROM DOCUMENT_DATE) >= 2024

            UNION ALL

            SELECT
                  TO_CHAR(DOCUMENT_DATE, 'YYYY-MM') AS YEAR_MONTH
                , CHANNEL
                , SUBCHANNEL
                , AMOUNT * -1 AS AMOUNT
            FROM OW_LAO.RAW_REPASSES_D2C_2022_2024
            WHERE EXTRACT(YEAR FROM DOCUMENT_DATE) < 2024
        ) b
        GROUP BY YEAR_MONTH, CHANNEL, SUBCHANNEL
    ) s;

    -- Forecast next 3 months iteratively
    WHILE counter <= 3 LOOP
        -- Insert one month of forecast per (channel, subchannel)
        PERFORM INSERT INTO OW_LAO.TMP_OST_FORECAST (
              YEAR_MONTH
            , CHANNEL
            , SUBCHANNEL
            , AMOUNT
            , IS_FORECAST
        )
        SELECT
              TO_CHAR(ADD_MONTHS(TO_DATE(F.YEAR_MONTH || '-01', 'YYYY-MM-DD'), 1), 'YYYY-MM') AS YEAR_MONTH_
            , F.CHANNEL
            , F.SUBCHANNEL
            , F.AVG_LAST_3_MONTHS_ACTUAL AS AMOUNT
            , 1 AS IS_FORECAST
        FROM OW_LAO.TMP_OST_FORECAST F
        INNER JOIN (
            SELECT CHANNEL, SUBCHANNEL, MAX(YEAR_MONTH) AS YEAR_MONTH
            FROM OW_LAO.TMP_OST_FORECAST
            GROUP BY CHANNEL, SUBCHANNEL
        ) L
          ON F.YEAR_MONTH = L.YEAR_MONTH
         AND F.CHANNEL = L.CHANNEL
         AND F.SUBCHANNEL = L.SUBCHANNEL;

        -- Recompute moving average over monthly sums per subchannel and update rows
        PERFORM UPDATE OW_LAO.TMP_OST_FORECAST F
        SET AVG_LAST_3_MONTHS_ACTUAL = L.AVG_LAST_3_MONTHS_ACTUAL
        FROM (
            WITH month_sum AS (
                SELECT YEAR_MONTH, SUBCHANNEL, SUM(AMOUNT) AS MONTH_AMT
                FROM OW_LAO.TMP_OST_FORECAST
                GROUP BY YEAR_MONTH, SUBCHANNEL
            ),
            avg3 AS (
                SELECT YEAR_MONTH, SUBCHANNEL,
                       AVG(MONTH_AMT) OVER (
                           PARTITION BY SUBCHANNEL
                           ORDER BY YEAR_MONTH
                           ROWS BETWEEN 2 PRECEDING AND CURRENT ROW
                       ) AS AVG_LAST_3_MONTHS_ACTUAL
                FROM month_sum
            )
            SELECT DISTINCT F2.YEAR_MONTH, F2.CHANNEL, F2.SUBCHANNEL, A.AVG_LAST_3_MONTHS_ACTUAL
            FROM OW_LAO.TMP_OST_FORECAST F2
            JOIN avg3 A
              ON F2.YEAR_MONTH = A.YEAR_MONTH
             AND F2.SUBCHANNEL = A.SUBCHANNEL
        ) L
        WHERE F.YEAR_MONTH = L.YEAR_MONTH
          AND F.CHANNEL = L.CHANNEL
          AND F.SUBCHANNEL = L.SUBCHANNEL;

        counter := counter + 1;
    END LOOP;

    -- Build final fact table
    PERFORM DROP TABLE IF EXISTS OW_LAO.FT_D2C_FORECAST_OST;
    PERFORM CREATE TABLE OW_LAO.FT_D2C_FORECAST_OST AS
    SELECT
          F.YEAR_MONTH
        , F.CHANNEL
        , F.SUBCHANNEL
        , CASE WHEN F.IS_FORECAST = 0 THEN F.AMOUNT END AS AMOUNT
        , FO.FORECAST_AMOUNT AS FORECAST_AMOUNT
        , F.IS_FORECAST
    FROM OW_LAO.TMP_OST_FORECAST F
    JOIN (
        WITH month_sum AS (
            SELECT YEAR_MONTH, SUBCHANNEL, SUM(AMOUNT) AS MONTH_AMT
            FROM OW_LAO.TMP_OST_FORECAST
            GROUP BY YEAR_MONTH, SUBCHANNEL
        )
        SELECT YEAR_MONTH, SUBCHANNEL,
               AVG(MONTH_AMT) OVER (
                   PARTITION BY SUBCHANNEL
                   ORDER BY YEAR_MONTH
                   ROWS BETWEEN 3 PRECEDING AND 1 PRECEDING
               ) AS FORECAST_AMOUNT
        FROM month_sum
    ) FO
      ON FO.YEAR_MONTH = F.YEAR_MONTH
     AND FO.SUBCHANNEL = F.SUBCHANNEL;

    -- Cleanup temp tables
    PERFORM DROP TABLE IF EXISTS OW_LAO.TMP_FBL5N_FORECAST;
    PERFORM DROP TABLE IF EXISTS OW_LAO.TMP_OST_FORECAST;
END;
$$;

-- CALL OW_LAO.PROC_D2C_FORECAST_OST();
-- ERROR: Severity: ERROR, Message: Relation "OW_MD.MAP_AR_MONTH_CUSTOMER" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_D2C_FORECAST_OST line 12 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
-- CALL OW_LAO.PROC_D2C_FORECAST_OST();
-- ERROR: Severity: ERROR, Message: Relation "OW_MD.MAP_AR_MONTH_CUSTOMER" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_D2C_FORECAST_OST line 12 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
