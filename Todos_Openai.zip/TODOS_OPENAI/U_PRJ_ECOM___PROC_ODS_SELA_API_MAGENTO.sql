CREATE OR REPLACE PROCEDURE U_PRJ_ECOM.PROC_ODS_SELA_API_MAGENTO()
LANGUAGE PLvSQL AS $$
BEGIN

  -- Drop temp tables if exist
  PERFORM DROP TABLE IF EXISTS tmp_ods_sela_api_magento_insert;
  PERFORM DROP TABLE IF EXISTS tmp_ods_sela_api_magento_update;
  PERFORM DROP TABLE IF EXISTS tmp_ods_sela_api_magento_sub;
  PERFORM DROP TABLE IF EXISTS tmp_ods_sela_api_magento_totals_temp;
  PERFORM DROP TABLE IF EXISTS tmp_ods_sela_api_magento_totals_temp_update;
  PERFORM DROP TABLE IF EXISTS tmp_ods_sela_api_magento_totals_temp_sub;
  PERFORM DROP TABLE IF EXISTS tmp_ods_sela_api_magento_update_temp;

  -- Build staging temp tables from source
  PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_sela_api_magento_insert ON COMMIT PRESERVE ROWS AS
  SELECT DISTINCT 
    A.ID,
    CURRENT_TIMESTAMP AS inserteddate,
    A.ORDER_ID,
    A.STATUS,
    A.CREATION_DATE,
    A.PAYMENT_APPROVED_DATE,
    A.INVOICE_DATE,
    A.SHIPPING_ESTIMATE_DATE,
    A.HANDLING_DATE,
    A.DELIVERED_DATE,
    A.PAYMENT_TYPE,
    A.PAYMENT_BRAND,
    A.QTY_INSTALLMENTS,
    A.CANCELATION_DATE,
    A.SHIPPING_COST,
    A.UNITS,
    A.CHANNEL,
    A.DISCOUNT,
    A.CONSUMER_ID,
    A.CURRENCY_CODE,
    A.CODE,
    A.DESCRIPTION,
    A.PRICE,
    A.QUANTITY,
    A.SHIPPING_COST_SKU,
    A.DISCOUNT_SKU,
    A.ORDERVALUE,
    A.SUBSIDIARYID,
    A.COUNTRY,
    A.COUNTRY_COD,
    A.ORDERITEMQUANTITY,
    A.SELLERINSTANCEID
  FROM U_PRJ_ECOM.TMP_ODS_SELA_API_MAGENTO A
  WHERE NOT EXISTS (
        SELECT 1
        FROM U_PRJ_ECOM.FT_ECOM_ORDER B
        WHERE B.EXTERNAL_ORDER_ID = A.ORDER_ID
          AND B.SUBSIDIARY_ID     = A.SUBSIDIARYID
          AND B.INTERNAL_STATUS   = A.STATUS
  );

  PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_sela_api_magento_update ON COMMIT PRESERVE ROWS AS
  SELECT DISTINCT 
    A.ID,
    CURRENT_TIMESTAMP AS inserteddate,
    A.ORDER_ID,
    A.STATUS,
    A.CREATION_DATE,
    A.PAYMENT_APPROVED_DATE,
    A.INVOICE_DATE,
    A.SHIPPING_ESTIMATE_DATE,
    A.HANDLING_DATE,
    A.DELIVERED_DATE,
    A.PAYMENT_TYPE,
    A.PAYMENT_BRAND,
    A.QTY_INSTALLMENTS,
    A.CANCELATION_DATE,
    A.SHIPPING_COST,
    A.UNITS,
    A.CHANNEL,
    A.DISCOUNT,
    A.CONSUMER_ID,
    A.CURRENCY_CODE,
    A.CODE,
    A.DESCRIPTION,
    A.PRICE,
    A.QUANTITY,
    A.SHIPPING_COST_SKU,
    A.DISCOUNT_SKU,
    A.ORDERVALUE,
    A.SUBSIDIARYID,
    A.COUNTRY,
    A.COUNTRY_COD,
    A.ORDERITEMQUANTITY,
    A.SELLERINSTANCEID
  FROM U_PRJ_ECOM.TMP_ODS_SELA_API_MAGENTO A
  WHERE NOT EXISTS (
        SELECT 1
        FROM U_PRJ_ECOM.FT_ECOM_ORDER B
        WHERE B.EXTERNAL_ORDER_ID = A.ORDER_ID
          AND B.SUBSIDIARY_ID     = A.SUBSIDIARYID
          AND B.INTERNAL_STATUS   = A.STATUS
  );

  PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_sela_api_magento_sub ON COMMIT PRESERVE ROWS AS
  SELECT DISTINCT 
    A.ID,
    CURRENT_TIMESTAMP AS inserteddate,
    A.ORDER_ID,
    A.STATUS,
    A.CREATION_DATE,
    A.PAYMENT_APPROVED_DATE,
    A.INVOICE_DATE,
    A.SHIPPING_ESTIMATE_DATE,
    A.HANDLING_DATE,
    A.DELIVERED_DATE,
    A.PAYMENT_TYPE,
    A.PAYMENT_BRAND,
    A.QTY_INSTALLMENTS,
    A.CANCELATION_DATE,
    A.SHIPPING_COST,
    A.UNITS,
    A.CHANNEL,
    A.DISCOUNT,
    A.CONSUMER_ID,
    A.CURRENCY_CODE,
    A.CODE,
    A.DESCRIPTION,
    A.PRICE,
    A.QUANTITY,
    A.SHIPPING_COST_SKU,
    A.DISCOUNT_SKU,
    A.ORDERVALUE,
    A.SUBSIDIARYID,
    A.COUNTRY,
    A.COUNTRY_COD,
    A.ORDERITEMQUANTITY,
    A.SELLERINSTANCEID
  FROM U_PRJ_ECOM.TMP_ODS_SELA_API_MAGENTO A
  WHERE NOT EXISTS (
        SELECT 1
        FROM U_PRJ_ECOM.FT_ECOM_ORDER B
        WHERE B.EXTERNAL_ORDER_ID = A.ORDER_ID
          AND B.SUBSIDIARY_ID     = A.SUBSIDIARYID
          AND B.INTERNAL_STATUS   = A.STATUS
  );

  -- Cleansing filters
  PERFORM DELETE FROM tmp_ods_sela_api_magento_insert WHERE code IS NULL;
  PERFORM DELETE FROM tmp_ods_sela_api_magento_insert WHERE UPPER(currency_code) <> 'GTQ' AND subsidiaryId = 10;
  PERFORM DELETE FROM tmp_ods_sela_api_magento_insert WHERE LOWER(code) LIKE 'cup%';

  PERFORM DELETE FROM tmp_ods_sela_api_magento_update WHERE code IS NULL;
  PERFORM DELETE FROM tmp_ods_sela_api_magento_update WHERE UPPER(currency_code) <> 'GTQ' AND subsidiaryId = 10;
  PERFORM DELETE FROM tmp_ods_sela_api_magento_update WHERE LOWER(code) LIKE 'cup%';

  PERFORM DELETE FROM tmp_ods_sela_api_magento_sub WHERE code IS NULL;
  PERFORM DELETE FROM tmp_ods_sela_api_magento_sub WHERE UPPER(currency_code) <> 'GTQ' AND subsidiaryId = 10;
  PERFORM DELETE FROM tmp_ods_sela_api_magento_sub WHERE LOWER(code) LIKE 'cup%';

  -- Totals temp tables
  PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_sela_api_magento_totals_temp ON COMMIT PRESERVE ROWS AS
    SELECT order_id                               AS orderid
         , SUM(quantity)                          AS quantity
         , SUM(CAST(price AS DECIMAL) * quantity) AS ordervalue
         , sellerinstanceid                       AS seller_instance_id
         , COALESCE(consumer_id, '0')             AS consumer_id
         , subsidiaryid                           AS subsidiary_id
         , country_cod                            AS country_cod
    FROM tmp_ods_sela_api_magento_insert
    WHERE COALESCE(ordervalue, 0) = 0
    GROUP BY subsidiaryid, sellerinstanceid, order_id, COALESCE(consumer_id, '0'), country_cod;

  PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_sela_api_magento_totals_temp_update ON COMMIT PRESERVE ROWS AS
    SELECT order_id                               AS orderid
         , SUM(quantity)                          AS quantity
         , SUM(CAST(price AS DECIMAL) * quantity) AS ordervalue
         , sellerinstanceid                       AS seller_instance_id
         , COALESCE(consumer_id, '0')             AS consumer_id
         , subsidiaryid                           AS subsidiary_id
         , country_cod                            AS country_cod
    FROM tmp_ods_sela_api_magento_update
    WHERE COALESCE(ordervalue, 0) = 0
    GROUP BY subsidiaryid, sellerinstanceid, order_id, COALESCE(consumer_id, '0'), country_cod;

  PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_sela_api_magento_totals_temp_sub ON COMMIT PRESERVE ROWS AS
    SELECT order_id                               AS orderid
         , SUM(quantity)                          AS quantity
         , SUM(CAST(price AS DECIMAL) * quantity) AS ordervalue
         , sellerinstanceid                       AS seller_instance_id
         , COALESCE(consumer_id, '0')             AS consumer_id
         , subsidiaryid                           AS subsidiary_id
         , country_cod                            AS country_cod
    FROM tmp_ods_sela_api_magento_sub
    WHERE COALESCE(ordervalue, 0) = 0
    GROUP BY subsidiaryid, sellerinstanceid, order_id, COALESCE(consumer_id, '0'), country_cod;

  -- Update backfill from totals
  PERFORM UPDATE tmp_ods_sela_api_magento_insert b
     SET ordervalue        = a.ordervalue
       , orderitemquantity = a.quantity
       , consumer_id       = a.consumer_id
    FROM tmp_ods_sela_api_magento_totals_temp a
   WHERE b.subsidiaryid      = a.subsidiary_id
     AND b.sellerinstanceid  = a.seller_instance_id
     AND b.order_id          = a.orderid
     AND b.country_cod       = a.country_cod;

  PERFORM UPDATE tmp_ods_sela_api_magento_update b
     SET ordervalue        = a.ordervalue
       , orderitemquantity = a.quantity
       , consumer_id       = a.consumer_id
    FROM tmp_ods_sela_api_magento_totals_temp_update a
   WHERE b.subsidiaryid      = a.subsidiary_id
     AND b.sellerinstanceid  = a.seller_instance_id
     AND b.order_id          = a.orderid
     AND b.country_cod       = a.country_cod;

  PERFORM UPDATE tmp_ods_sela_api_magento_sub b
     SET ordervalue        = a.ordervalue
       , orderitemquantity = a.quantity
       , consumer_id       = a.consumer_id
    FROM tmp_ods_sela_api_magento_totals_temp_sub a
   WHERE b.subsidiaryid      = a.subsidiary_id
     AND b.sellerinstanceid  = a.seller_instance_id
     AND b.order_id          = a.orderid
     AND b.country_cod       = a.country_cod;

  -- Customers (insert)
  PERFORM INSERT INTO u_prj_ecom.dim_customer (
           external_id
         , insert_date
         , seller_instance_id
         , subsidiary_id
  )
  SELECT a.consumer_id      AS external_id
       , NOW()              AS insert_date
       , a.sellerinstanceid AS seller_instance_id
       , a.subsidiaryid     AS subsidiary_id
    FROM tmp_ods_sela_api_magento_insert a
   WHERE NOT EXISTS (
          SELECT 1
            FROM u_prj_ecom.dim_customer z
           WHERE z.subsidiary_id      = a.subsidiaryid
             AND z.seller_instance_id = a.sellerinstanceid
             AND z.external_id        = COALESCE(a.consumer_id, '0')
        )
   GROUP BY a.consumer_id, a.subsidiaryid, a.sellerinstanceid;

  -- Orders (insert)
  PERFORM INSERT INTO u_prj_ecom.ft_ecom_order (
           external_order_id
         , subsidiary_id
         , creation_date
         , status
         , internal_status
         , order_value
         , customer_id
         , country
         , shipping_cost
         , discount
         , status_order_created_date
         , status_payment_approved_date
         , status_invoiced_date
         , status_start_handling_date
         , status_handling_shipping_date
         , status_delivered_date
         , status_canceled_date
         , insert_date
         , last_update_date
         , affiliate_id
         , seller_instance_id
         , source
         , cod_sales_channel
         , is_trade_in
         , hostname
  )
  SELECT DISTINCT
         a.order_id                             AS external_order_id
       , a.subsidiaryid                         AS subsidiary_id
       , CAST(a.creation_date AS TIMESTAMP)     AS creation_date
       , a.status                               AS status
       , a.status                               AS internal_status
       , a.ordervalue                           AS order_value
       , b.id                                   AS customer_id
       , a.country                              AS country
       , CAST(a.shipping_cost AS DECIMAL)       AS shipping_cost
       , CAST(a.discount AS DECIMAL)            AS discount
       , CAST(a.creation_date AS TIMESTAMP)     AS status_order_created_date
       , CAST(a.payment_approved_date AS TIMESTAMP)  AS status_payment_approved_date
       , CAST(a.invoice_date AS TIMESTAMP)      AS status_invoiced_date
       , CAST(a.handling_date AS TIMESTAMP)     AS status_start_handling_date
       , CAST(a.shipping_estimate_date AS TIMESTAMP) AS status_handling_shipping_date
       , CAST(a.delivered_date AS TIMESTAMP)    AS status_delivered_date
       , CAST(a.cancelation_date AS TIMESTAMP)  AS status_canceled_date
       , NOW()                                  AS insert_date
       , NOW()                                  AS last_update_date
       , 'SAMSUNG'                              AS affiliate_id
       , a.sellerinstanceid                     AS seller_instance_id
       , 'jenkins'                              AS source
       , a.channel                              AS cod_sales_channel
       , 0                                      AS is_trade_in
       , a.country_cod                          AS hostname
    FROM tmp_ods_sela_api_magento_insert a
    JOIN u_prj_ecom.dim_customer b
      ON b.external_id        = a.consumer_id
     AND b.subsidiary_id      = a.subsidiaryid
     AND b.seller_instance_id = a.sellerinstanceid
   WHERE NOT EXISTS (
          SELECT 1
            FROM u_prj_ecom.ft_ecom_order z
           WHERE z.external_order_id  = a.order_id
             AND z.subsidiary_id      = a.subsidiaryid
             AND z.seller_instance_id = a.sellerinstanceid
             AND z.hostname           = a.country_cod
        );

  -- Order Items (insert)
  PERFORM INSERT INTO u_prj_ecom.ft_ecom_order_item (
           order_id
         , product_name         
         , reference_code
         , quantity
         , discount
         , ean
         , price
         , kit
         , is_samsung_care
  )
  SELECT DISTINCT
         b.id                               AS order_id
       , a.description                      AS product_name         
       , a.code                             AS reference_code
       , CAST(a.quantity AS INT)            AS quantity
       , CAST(a.discount_sku AS DECIMAL)    AS discount
       , CASE WHEN LENGTH(a.code) > 20 THEN NULL ELSE a.code END AS ean
       , CAST(a.price AS DECIMAL)           AS price
       , 0                                  AS kit
       , 0                                  AS is_samsung_care
    FROM tmp_ods_sela_api_magento_insert a
    JOIN u_prj_ecom.ft_ecom_order b
      ON b.external_order_id = a.order_id
   WHERE b.subsidiary_id      = a.subsidiaryid
     AND b.source             = 'jenkins'
     AND b.seller_instance_id = a.sellerinstanceid
     AND b.hostname           = a.country_cod
     AND NOT EXISTS (
          SELECT 1
            FROM u_prj_ecom.ft_ecom_order_item z
           WHERE z.order_id       = b.id
             AND z.reference_code = a.code
        );

  -- Payments (insert)
  PERFORM INSERT INTO u_prj_ecom.ft_ecom_order_payment (
           order_id
         , payment_type         
         , installment
         , brand
         , value
  )
  SELECT DISTINCT
         b.id                                        AS order_id
       , SUBSTR(a.payment_type, 1, 23)               AS payment_type
       , COALESCE(CAST(a.qty_installments AS INT),1) AS installment
       , SUBSTR(a.payment_brand, 1, 24)              AS brand
       , a.ordervalue                                AS value
    FROM tmp_ods_sela_api_magento_insert a
    JOIN u_prj_ecom.ft_ecom_order b
      ON b.external_order_id = a.order_id
   WHERE b.subsidiary_id      = a.subsidiaryid
     AND b.source             = 'jenkins'
     AND b.seller_instance_id = a.sellerinstanceid
     AND b.hostname           = a.country_cod
     AND NOT EXISTS (
          SELECT 1
            FROM u_prj_ecom.ft_ecom_order_payment z
           WHERE z.order_id = b.id
        );

  -- Customers (SUB)
  PERFORM INSERT INTO u_prj_ecom.dim_customer (
           external_id
         , insert_date
         , seller_instance_id
         , subsidiary_id
  )
  SELECT a.consumer_id      AS external_id
       , NOW()              AS insert_date
       , a.sellerinstanceid AS seller_instance_id
       , a.subsidiaryid     AS subsidiary_id
    FROM tmp_ods_sela_api_magento_sub a
   WHERE NOT EXISTS (
          SELECT 1
            FROM u_prj_ecom.dim_customer z
           WHERE z.subsidiary_id      = a.subsidiaryid
             AND z.seller_instance_id = a.sellerinstanceid
             AND z.external_id        = COALESCE(a.consumer_id, '0')
        )
   GROUP BY a.consumer_id, a.subsidiaryid, a.sellerinstanceid;

  -- Orders (SUB)
  PERFORM INSERT INTO u_prj_ecom.ft_ecom_order (
           external_order_id
         , subsidiary_id
         , creation_date
         , status
         , internal_status
         , order_value
         , customer_id
         , country
         , shipping_cost
         , discount
         , status_order_created_date
         , status_payment_approved_date
         , status_invoiced_date
         , status_start_handling_date
         , status_handling_shipping_date
         , status_delivered_date
         , status_canceled_date
         , insert_date
         , last_update_date
         , affiliate_id
         , seller_instance_id
         , source
         , cod_sales_channel
         , is_trade_in
         , hostname
  )
  SELECT DISTINCT
         a.order_id                             AS external_order_id
       , a.subsidiaryid                         AS subsidiary_id
       , CAST(a.creation_date AS TIMESTAMP)     AS creation_date
       , a.status                               AS status
       , a.status                               AS internal_status
       , a.ordervalue                           AS order_value
       , b.id                                   AS customer_id
       , a.country                              AS country
       , CAST(a.shipping_cost AS DECIMAL)       AS shipping_cost
       , CAST(a.discount AS DECIMAL)            AS discount
       , CAST(a.creation_date AS TIMESTAMP)     AS status_order_created_date
       , CAST(a.payment_approved_date AS TIMESTAMP)  AS status_payment_approved_date
       , CAST(a.invoice_date AS TIMESTAMP)      AS status_invoiced_date
       , CAST(a.handling_date AS TIMESTAMP)     AS status_start_handling_date
       , CAST(a.shipping_estimate_date AS TIMESTAMP) AS status_handling_shipping_date
       , CAST(a.delivered_date AS TIMESTAMP)    AS status_delivered_date
       , CAST(a.cancelation_date AS TIMESTAMP)  AS status_canceled_date
       , NOW()                                  AS insert_date
       , NOW()                                  AS last_update_date
       , 'SAMSUNG'                              AS affiliate_id
       , a.sellerinstanceid                     AS seller_instance_id
       , 'jenkins'                              AS source
       , a.channel                              AS cod_sales_channel
       , 0                                      AS is_trade_in
       , a.country_cod                          AS hostname
    FROM tmp_ods_sela_api_magento_sub a
    JOIN u_prj_ecom.dim_customer b
      ON b.external_id        = a.consumer_id
     AND b.subsidiary_id      = a.subsidiaryid
     AND b.seller_instance_id = a.sellerinstanceid
   WHERE NOT EXISTS (
          SELECT 1
            FROM u_prj_ecom.ft_ecom_order z
           WHERE z.external_order_id  = a.order_id
             AND z.subsidiary_id      = a.subsidiaryid
             AND z.seller_instance_id = a.sellerinstanceid
             AND z.hostname           = a.country_cod
        );

  -- Order Items (SUB)
  PERFORM INSERT INTO u_prj_ecom.ft_ecom_order_item (
           order_id
         , product_name         
         , reference_code
         , quantity
         , discount
         , ean
         , price
         , kit
         , is_samsung_care
  )
  SELECT DISTINCT
         b.id                               AS order_id
       , a.description                      AS product_name         
       , a.code                             AS reference_code
       , CAST(a.quantity AS INT)            AS quantity
       , CAST(a.discount_sku AS DECIMAL)    AS discount
       , CASE WHEN LENGTH(a.code) > 20 THEN NULL ELSE a.code END AS ean
       , CAST(a.price AS DECIMAL)           AS price
       , 0                                  AS kit
       , 0                                  AS is_samsung_care
    FROM tmp_ods_sela_api_magento_sub a
    JOIN u_prj_ecom.ft_ecom_order b
      ON b.external_order_id = a.order_id
   WHERE b.subsidiary_id      = a.subsidiaryid
     AND b.source             = 'jenkins'
     AND b.seller_instance_id = a.sellerinstanceid
     AND b.hostname           = a.country_cod
     AND NOT EXISTS (
          SELECT 1
            FROM u_prj_ecom.ft_ecom_order_item z
           WHERE z.order_id       = b.id
             AND z.reference_code = a.code
        );

  -- Payments (SUB)
  PERFORM INSERT INTO u_prj_ecom.ft_ecom_order_payment (
           order_id
         , payment_type         
         , installment
         , brand
         , value
  )
  SELECT DISTINCT
         b.id                                        AS order_id
       , SUBSTR(a.payment_type, 1, 23)               AS payment_type
       , COALESCE(CAST(a.qty_installments AS INT),1) AS installment
       , SUBSTR(a.payment_brand, 1, 24)              AS brand
       , a.ordervalue                                AS value
    FROM tmp_ods_sela_api_magento_sub a
    JOIN u_prj_ecom.ft_ecom_order b
      ON b.external_order_id = a.order_id
   WHERE b.subsidiary_id      = a.subsidiaryid
     AND b.source             = 'jenkins'
     AND b.seller_instance_id = a.sellerinstanceid
     AND b.hostname           = a.country_cod
     AND NOT EXISTS (
          SELECT 1
            FROM u_prj_ecom.ft_ecom_order_payment z
           WHERE z.order_id = b.id
        );

  -- Build update temp
  PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_sela_api_magento_update_temp ON COMMIT PRESERVE ROWS AS
  SELECT DISTINCT
         a.order_id                         AS external_order_id
       , a.subsidiaryid                     AS subsidiary_id
       , a.sellerinstanceid                 AS seller_instance_id
       , CAST(a.creation_date AS TIMESTAMP) AS creation_date
       , a.status                           AS status
       , a.status                           AS internal_status
       , a.country_cod                      AS hostname
       , CURRENT_TIMESTAMP                  AS last_update_date
    FROM tmp_ods_sela_api_magento_update a;

  -- Apply updates to orders
  PERFORM UPDATE u_prj_ecom.ft_ecom_order so
     SET status = tmp.status,
         internal_status = tmp.internal_status,
         last_update_date = tmp.last_update_date
    FROM tmp_ods_sela_api_magento_update_temp tmp
   WHERE so.external_order_id = tmp.external_order_id
     AND so.subsidiary_id     = tmp.subsidiary_id
     AND so.status            <> tmp.status;

  -- Insert into ODS
  PERFORM INSERT INTO U_PRJ_ECOM.ODS_SELA_API_MAGENTO (
    ID,
    ORDER_ID,
    STATUS,
    CREATION_DATE,
    PAYMENT_APPROVED_DATE,
    INVOICE_DATE,
    SHIPPING_ESTIMATE_DATE,
    HANDLING_DATE,
    DELIVERED_DATE,
    PAYMENT_TYPE,
    PAYMENT_BRAND,
    QTY_INSTALLMENTS,
    CANCELATION_DATE,
    SHIPPING_COST,
    UNITS,
    CHANNEL,
    DISCOUNT,
    CONSUMER_ID,
    CURRENCY_CODE,
    CODE,
    DESCRIPTION,
    PRICE,
    QUANTITY,
    SHIPPING_COST_SKU,
    DISCOUNT_SKU,
    ORDERVALUE,
    SUBSIDIARYID,
    COUNTRY,
    COUNTRY_COD,
    ORDERITEMQUANTITY,
    SELLERINSTANCEID
  )
  SELECT DISTINCT 
    a.ID,
    a.ORDER_ID,
    a.STATUS,
    a.CREATION_DATE,
    a.PAYMENT_APPROVED_DATE,
    a.INVOICE_DATE,
    a.SHIPPING_ESTIMATE_DATE,
    a.HANDLING_DATE,
    a.DELIVERED_DATE,
    a.PAYMENT_TYPE,
    a.PAYMENT_BRAND,
    a.QTY_INSTALLMENTS,
    a.CANCELATION_DATE,
    a.SHIPPING_COST,
    a.QUANTITY AS UNITS,
    a.CHANNEL,
    a.DISCOUNT,
    a.CONSUMER_ID,
    a.CURRENCY_CODE,
    a.CODE,
    a.DESCRIPTION,
    a.PRICE,
    a.QUANTITY,
    a.SHIPPING_COST_SKU,
    a.DISCOUNT_SKU,
    a.ORDERVALUE,
    a.SUBSIDIARYID,
    a.COUNTRY,
    a.COUNTRY_COD,
    a.ORDERITEMQUANTITY,
    a.SELLERINSTANCEID
  FROM tmp_ods_sela_api_magento_insert a
  WHERE NOT EXISTS (
        SELECT 1
        FROM U_PRJ_ECOM.ODS_SELA_API_MAGENTO B
        WHERE B.ORDER_ID     = A.ORDER_ID
          AND B.CODE         = A.CODE
          AND B.SUBSIDIARYID = A.SUBSIDIARYID
  );

  -- Update ODS statuses
  PERFORM UPDATE U_PRJ_ECOM.ODS_SELA_API_MAGENTO so
     SET status = tmp.status,
         last_update_date = tmp.last_update_date
    FROM tmp_ods_sela_api_magento_update_temp tmp
   WHERE so.order_id     = tmp.external_order_id
     AND so.SUBSIDIARYID = tmp.subsidiary_id
     AND so.status       <> tmp.status;

END;
$$;

-- CALL U_PRJ_ECOM.PROC_ODS_SELA_API_MAGENTO();
-- ERROR: Severity: ERROR, Message: Cannot set a NOT NULL column (ID) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure PROC_ODS_SELA_API_MAGENTO line 225 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3216, Error Code: 2502, 
-- CALL U_PRJ_ECOM.PROC_ODS_SELA_API_MAGENTO();
-- ERROR: Severity: ERROR, Message: Cannot set a NOT NULL column (ID) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure PROC_ODS_SELA_API_MAGENTO line 225 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3216, Error Code: 2502, 
CREATE OR REPLACE PROCEDURE U_PRJ_ECOM.PROC_ODS_SELA_API_MAGENTO()
LANGUAGE PLvSQL AS $$
BEGIN

  -- Drop temp tables if exist
  PERFORM DROP TABLE IF EXISTS tmp_ods_sela_api_magento_insert;
  PERFORM DROP TABLE IF EXISTS tmp_ods_sela_api_magento_update;
  PERFORM DROP TABLE IF EXISTS tmp_ods_sela_api_magento_sub;
  PERFORM DROP TABLE IF EXISTS tmp_ods_sela_api_magento_totals_temp;
  PERFORM DROP TABLE IF EXISTS tmp_ods_sela_api_magento_totals_temp_update;
  PERFORM DROP TABLE IF EXISTS tmp_ods_sela_api_magento_totals_temp_sub;
  PERFORM DROP TABLE IF EXISTS tmp_ods_sela_api_magento_update_temp;

  -- Build staging temp tables from source
  PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_sela_api_magento_insert ON COMMIT PRESERVE ROWS AS
  SELECT DISTINCT 
    A.ID,
    CURRENT_TIMESTAMP AS inserteddate,
    A.ORDER_ID,
    A.STATUS,
    A.CREATION_DATE,
    A.PAYMENT_APPROVED_DATE,
    A.INVOICE_DATE,
    A.SHIPPING_ESTIMATE_DATE,
    A.HANDLING_DATE,
    A.DELIVERED_DATE,
    A.PAYMENT_TYPE,
    A.PAYMENT_BRAND,
    A.QTY_INSTALLMENTS,
    A.CANCELATION_DATE,
    A.SHIPPING_COST,
    A.UNITS,
    A.CHANNEL,
    A.DISCOUNT,
    A.CONSUMER_ID,
    A.CURRENCY_CODE,
    A.CODE,
    A.DESCRIPTION,
    A.PRICE,
    A.QUANTITY,
    A.SHIPPING_COST_SKU,
    A.DISCOUNT_SKU,
    A.ORDERVALUE,
    A.SUBSIDIARYID,
    A.COUNTRY,
    A.COUNTRY_COD,
    A.ORDERITEMQUANTITY,
    A.SELLERINSTANCEID
  FROM U_PRJ_ECOM.TMP_ODS_SELA_API_MAGENTO A
  WHERE NOT EXISTS (
        SELECT 1
        FROM U_PRJ_ECOM.FT_ECOM_ORDER B
        WHERE B.EXTERNAL_ORDER_ID = A.ORDER_ID
          AND B.SUBSIDIARY_ID     = A.SUBSIDIARYID
          AND B.INTERNAL_STATUS   = A.STATUS
  );

  PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_sela_api_magento_update ON COMMIT PRESERVE ROWS AS
  SELECT DISTINCT 
    A.ID,
    CURRENT_TIMESTAMP AS inserteddate,
    A.ORDER_ID,
    A.STATUS,
    A.CREATION_DATE,
    A.PAYMENT_APPROVED_DATE,
    A.INVOICE_DATE,
    A.SHIPPING_ESTIMATE_DATE,
    A.HANDLING_DATE,
    A.DELIVERED_DATE,
    A.PAYMENT_TYPE,
    A.PAYMENT_BRAND,
    A.QTY_INSTALLMENTS,
    A.CANCELATION_DATE,
    A.SHIPPING_COST,
    A.UNITS,
    A.CHANNEL,
    A.DISCOUNT,
    A.CONSUMER_ID,
    A.CURRENCY_CODE,
    A.CODE,
    A.DESCRIPTION,
    A.PRICE,
    A.QUANTITY,
    A.SHIPPING_COST_SKU,
    A.DISCOUNT_SKU,
    A.ORDERVALUE,
    A.SUBSIDIARYID,
    A.COUNTRY,
    A.COUNTRY_COD,
    A.ORDERITEMQUANTITY,
    A.SELLERINSTANCEID
  FROM U_PRJ_ECOM.TMP_ODS_SELA_API_MAGENTO A
  WHERE NOT EXISTS (
        SELECT 1
        FROM U_PRJ_ECOM.FT_ECOM_ORDER B
        WHERE B.EXTERNAL_ORDER_ID = A.ORDER_ID
          AND B.SUBSIDIARY_ID     = A.SUBSIDIARYID
          AND B.INTERNAL_STATUS   = A.STATUS
  );

  PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_sela_api_magento_sub ON COMMIT PRESERVE ROWS AS
  SELECT DISTINCT 
    A.ID,
    CURRENT_TIMESTAMP AS inserteddate,
    A.ORDER_ID,
    A.STATUS,
    A.CREATION_DATE,
    A.PAYMENT_APPROVED_DATE,
    A.INVOICE_DATE,
    A.SHIPPING_ESTIMATE_DATE,
    A.HANDLING_DATE,
    A.DELIVERED_DATE,
    A.PAYMENT_TYPE,
    A.PAYMENT_BRAND,
    A.QTY_INSTALLMENTS,
    A.CANCELATION_DATE,
    A.SHIPPING_COST,
    A.UNITS,
    A.CHANNEL,
    A.DISCOUNT,
    A.CONSUMER_ID,
    A.CURRENCY_CODE,
    A.CODE,
    A.DESCRIPTION,
    A.PRICE,
    A.QUANTITY,
    A.SHIPPING_COST_SKU,
    A.DISCOUNT_SKU,
    A.ORDERVALUE,
    A.SUBSIDIARYID,
    A.COUNTRY,
    A.COUNTRY_COD,
    A.ORDERITEMQUANTITY,
    A.SELLERINSTANCEID
  FROM U_PRJ_ECOM.TMP_ODS_SELA_API_MAGENTO A
  WHERE NOT EXISTS (
        SELECT 1
        FROM U_PRJ_ECOM.FT_ECOM_ORDER B
        WHERE B.EXTERNAL_ORDER_ID = A.ORDER_ID
          AND B.SUBSIDIARY_ID     = A.SUBSIDIARYID
          AND B.INTERNAL_STATUS   = A.STATUS
  );

  -- Cleansing filters
  PERFORM DELETE FROM tmp_ods_sela_api_magento_insert WHERE code IS NULL;
  PERFORM DELETE FROM tmp_ods_sela_api_magento_insert WHERE UPPER(currency_code) <> 'GTQ' AND subsidiaryId = 10;
  PERFORM DELETE FROM tmp_ods_sela_api_magento_insert WHERE LOWER(code) LIKE 'cup%';

  PERFORM DELETE FROM tmp_ods_sela_api_magento_update WHERE code IS NULL;
  PERFORM DELETE FROM tmp_ods_sela_api_magento_update WHERE UPPER(currency_code) <> 'GTQ' AND subsidiaryId = 10;
  PERFORM DELETE FROM tmp_ods_sela_api_magento_update WHERE LOWER(code) LIKE 'cup%';

  PERFORM DELETE FROM tmp_ods_sela_api_magento_sub WHERE code IS NULL;
  PERFORM DELETE FROM tmp_ods_sela_api_magento_sub WHERE UPPER(currency_code) <> 'GTQ' AND subsidiaryId = 10;
  PERFORM DELETE FROM tmp_ods_sela_api_magento_sub WHERE LOWER(code) LIKE 'cup%';

  -- Totals temp tables
  PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_sela_api_magento_totals_temp ON COMMIT PRESERVE ROWS AS
    SELECT order_id                               AS orderid
         , SUM(quantity)                          AS quantity
         , SUM(CAST(price AS DECIMAL) * quantity) AS ordervalue
         , sellerinstanceid                       AS seller_instance_id
         , COALESCE(consumer_id, '0')             AS consumer_id
         , subsidiaryid                           AS subsidiary_id
         , country_cod                            AS country_cod
    FROM tmp_ods_sela_api_magento_insert
    WHERE COALESCE(ordervalue, 0) = 0
    GROUP BY subsidiaryid, sellerinstanceid, order_id, COALESCE(consumer_id, '0'), country_cod;

  PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_sela_api_magento_totals_temp_update ON COMMIT PRESERVE ROWS AS
    SELECT order_id                               AS orderid
         , SUM(quantity)                          AS quantity
         , SUM(CAST(price AS DECIMAL) * quantity) AS ordervalue
         , sellerinstanceid                       AS seller_instance_id
         , COALESCE(consumer_id, '0')             AS consumer_id
         , subsidiaryid                           AS subsidiary_id
         , country_cod                            AS country_cod
    FROM tmp_ods_sela_api_magento_update
    WHERE COALESCE(ordervalue, 0) = 0
    GROUP BY subsidiaryid, sellerinstanceid, order_id, COALESCE(consumer_id, '0'), country_cod;

  PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_sela_api_magento_totals_temp_sub ON COMMIT PRESERVE ROWS AS
    SELECT order_id                               AS orderid
         , SUM(quantity)                          AS quantity
         , SUM(CAST(price AS DECIMAL) * quantity) AS ordervalue
         , sellerinstanceid                       AS seller_instance_id
         , COALESCE(consumer_id, '0')             AS consumer_id
         , subsidiaryid                           AS subsidiary_id
         , country_cod                            AS country_cod
    FROM tmp_ods_sela_api_magento_sub
    WHERE COALESCE(ordervalue, 0) = 0
    GROUP BY subsidiaryid, sellerinstanceid, order_id, COALESCE(consumer_id, '0'), country_cod;

  -- Update backfill from totals
  PERFORM UPDATE tmp_ods_sela_api_magento_insert b
     SET ordervalue        = a.ordervalue
       , orderitemquantity = a.quantity
       , consumer_id       = a.consumer_id
    FROM tmp_ods_sela_api_magento_totals_temp a
   WHERE b.subsidiaryid      = a.subsidiary_id
     AND b.sellerinstanceid  = a.seller_instance_id
     AND b.order_id          = a.orderid
     AND b.country_cod       = a.country_cod;

  PERFORM UPDATE tmp_ods_sela_api_magento_update b
     SET ordervalue        = a.ordervalue
       , orderitemquantity = a.quantity
       , consumer_id       = a.consumer_id
    FROM tmp_ods_sela_api_magento_totals_temp_update a
   WHERE b.subsidiaryid      = a.subsidiary_id
     AND b.sellerinstanceid  = a.seller_instance_id
     AND b.order_id          = a.orderid
     AND b.country_cod       = a.country_cod;

  PERFORM UPDATE tmp_ods_sela_api_magento_sub b
     SET ordervalue        = a.ordervalue
       , orderitemquantity = a.quantity
       , consumer_id       = a.consumer_id
    FROM tmp_ods_sela_api_magento_totals_temp_sub a
   WHERE b.subsidiaryid      = a.subsidiary_id
     AND b.sellerinstanceid  = a.seller_instance_id
     AND b.order_id          = a.orderid
     AND b.country_cod       = a.country_cod;

  -- Customers (insert)
  PERFORM INSERT INTO u_prj_ecom.dim_customer (
           external_id
         , insert_date
         , seller_instance_id
         , subsidiary_id
  )
  SELECT a.consumer_id      AS external_id
       , NOW()              AS insert_date
       , a.sellerinstanceid AS seller_instance_id
       , a.subsidiaryid     AS subsidiary_id
    FROM tmp_ods_sela_api_magento_insert a
   WHERE NOT EXISTS (
          SELECT 1
            FROM u_prj_ecom.dim_customer z
           WHERE z.subsidiary_id      = a.subsidiaryid
             AND z.seller_instance_id = a.sellerinstanceid
             AND z.external_id        = COALESCE(a.consumer_id, '0')
        )
   GROUP BY a.consumer_id, a.subsidiaryid, a.sellerinstanceid;

  -- Orders (insert)
  PERFORM INSERT INTO u_prj_ecom.ft_ecom_order (
           external_order_id
         , subsidiary_id
         , creation_date
         , status
         , internal_status
         , order_value
         , customer_id
         , country
         , shipping_cost
         , discount
         , status_order_created_date
         , status_payment_approved_date
         , status_invoiced_date
         , status_start_handling_date
         , status_handling_shipping_date
         , status_delivered_date
         , status_canceled_date
         , insert_date
         , last_update_date
         , affiliate_id
         , seller_instance_id
         , source
         , cod_sales_channel
         , is_trade_in
         , hostname
  )
  SELECT DISTINCT
         a.order_id                             AS external_order_id
       , a.subsidiaryid                         AS subsidiary_id
       , CAST(a.creation_date AS TIMESTAMP)     AS creation_date
       , a.status                               AS status
       , a.status                               AS internal_status
       , a.ordervalue                           AS order_value
       , b.id                                   AS customer_id
       , a.country                              AS country
       , CAST(a.shipping_cost AS DECIMAL)       AS shipping_cost
       , CAST(a.discount AS DECIMAL)            AS discount
       , CAST(a.creation_date AS TIMESTAMP)     AS status_order_created_date
       , CAST(a.payment_approved_date AS TIMESTAMP)  AS status_payment_approved_date
       , CAST(a.invoice_date AS TIMESTAMP)      AS status_invoiced_date
       , CAST(a.handling_date AS TIMESTAMP)     AS status_start_handling_date
       , CAST(a.shipping_estimate_date AS TIMESTAMP) AS status_handling_shipping_date
       , CAST(a.delivered_date AS TIMESTAMP)    AS status_delivered_date
       , CAST(a.cancelation_date AS TIMESTAMP)  AS status_canceled_date
       , NOW()                                  AS insert_date
       , NOW()                                  AS last_update_date
       , 'SAMSUNG'                              AS affiliate_id
       , a.sellerinstanceid                     AS seller_instance_id
       , 'jenkins'                              AS source
       , a.channel                              AS cod_sales_channel
       , 0                                      AS is_trade_in
       , a.country_cod                          AS hostname
    FROM tmp_ods_sela_api_magento_insert a
    JOIN u_prj_ecom.dim_customer b
      ON b.external_id        = a.consumer_id
     AND b.subsidiary_id      = a.subsidiaryid
     AND b.seller_instance_id = a.sellerinstanceid
   WHERE NOT EXISTS (
          SELECT 1
            FROM u_prj_ecom.ft_ecom_order z
           WHERE z.external_order_id  = a.order_id
             AND z.subsidiary_id      = a.subsidiaryid
             AND z.seller_instance_id = a.sellerinstanceid
             AND z.hostname           = a.country_cod
        );

  -- Order Items (insert)
  PERFORM INSERT INTO u_prj_ecom.ft_ecom_order_item (
           order_id
         , product_name         
         , reference_code
         , quantity
         , discount
         , ean
         , price
         , kit
         , is_samsung_care
  )
  SELECT DISTINCT
         b.id                               AS order_id
       , a.description                      AS product_name         
       , a.code                             AS reference_code
       , CAST(a.quantity AS INT)            AS quantity
       , CAST(a.discount_sku AS DECIMAL)    AS discount
       , CASE WHEN LENGTH(a.code) > 20 THEN NULL ELSE a.code END AS ean
       , CAST(a.price AS DECIMAL)           AS price
       , 0                                  AS kit
       , 0                                  AS is_samsung_care
    FROM tmp_ods_sela_api_magento_insert a
    JOIN u_prj_ecom.ft_ecom_order b
      ON b.external_order_id = a.order_id
   WHERE b.subsidiary_id      = a.subsidiaryid
     AND b.source             = 'jenkins'
     AND b.seller_instance_id = a.sellerinstanceid
     AND b.hostname           = a.country_cod
     AND NOT EXISTS (
          SELECT 1
            FROM u_prj_ecom.ft_ecom_order_item z
           WHERE z.order_id       = b.id
             AND z.reference_code = a.code
        );

  -- Payments (insert)
  PERFORM INSERT INTO u_prj_ecom.ft_ecom_order_payment (
           order_id
         , payment_type         
         , installment
         , brand
         , value
  )
  SELECT DISTINCT
         b.id                                        AS order_id
       , SUBSTR(a.payment_type, 1, 23)               AS payment_type
       , COALESCE(CAST(a.qty_installments AS INT),1) AS installment
       , SUBSTR(a.payment_brand, 1, 24)              AS brand
       , a.ordervalue                                AS value
    FROM tmp_ods_sela_api_magento_insert a
    JOIN u_prj_ecom.ft_ecom_order b
      ON b.external_order_id = a.order_id
   WHERE b.subsidiary_id      = a.subsidiaryid
     AND b.source             = 'jenkins'
     AND b.seller_instance_id = a.sellerinstanceid
     AND b.hostname           = a.country_cod
     AND NOT EXISTS (
          SELECT 1
            FROM u_prj_ecom.ft_ecom_order_payment z
           WHERE z.order_id = b.id
        );

  -- Customers (SUB)
  PERFORM INSERT INTO u_prj_ecom.dim_customer (
           external_id
         , insert_date
         , seller_instance_id
         , subsidiary_id
  )
  SELECT a.consumer_id      AS external_id
       , NOW()              AS insert_date
       , a.sellerinstanceid AS seller_instance_id
       , a.subsidiaryid     AS subsidiary_id
    FROM tmp_ods_sela_api_magento_sub a
   WHERE NOT EXISTS (
          SELECT 1
            FROM u_prj_ecom.dim_customer z
           WHERE z.subsidiary_id      = a.subsidiaryid
             AND z.seller_instance_id = a.sellerinstanceid
             AND z.external_id        = COALESCE(a.consumer_id, '0')
        )
   GROUP BY a.consumer_id, a.subsidiaryid, a.sellerinstanceid;

  -- Orders (SUB)
  PERFORM INSERT INTO u_prj_ecom.ft_ecom_order (
           external_order_id
         , subsidiary_id
         , creation_date
         , status
         , internal_status
         , order_value
         , customer_id
         , country
         , shipping_cost
         , discount
         , status_order_created_date
         , status_payment_approved_date
         , status_invoiced_date
         , status_start_handling_date
         , status_handling_shipping_date
         , status_delivered_date
         , status_canceled_date
         , insert_date
         , last_update_date
         , affiliate_id
         , seller_instance_id
         , source
         , cod_sales_channel
         , is_trade_in
         , hostname
  )
  SELECT DISTINCT
         a.order_id                             AS external_order_id
       , a.subsidiaryid                         AS subsidiary_id
       , CAST(a.creation_date AS TIMESTAMP)     AS creation_date
       , a.status                               AS status
       , a.status                               AS internal_status
       , a.ordervalue                           AS order_value
       , b.id                                   AS customer_id
       , a.country                              AS country
       , CAST(a.shipping_cost AS DECIMAL)       AS shipping_cost
       , CAST(a.discount AS DECIMAL)            AS discount
       , CAST(a.creation_date AS TIMESTAMP)     AS status_order_created_date
       , CAST(a.payment_approved_date AS TIMESTAMP)  AS status_payment_approved_date
       , CAST(a.invoice_date AS TIMESTAMP)      AS status_invoiced_date
       , CAST(a.handling_date AS TIMESTAMP)     AS status_start_handling_date
       , CAST(a.shipping_estimate_date AS TIMESTAMP) AS status_handling_shipping_date
       , CAST(a.delivered_date AS TIMESTAMP)    AS status_delivered_date
       , CAST(a.cancelation_date AS TIMESTAMP)  AS status_canceled_date
       , NOW()                                  AS insert_date
       , NOW()                                  AS last_update_date
       , 'SAMSUNG'                              AS affiliate_id
       , a.sellerinstanceid                     AS seller_instance_id
       , 'jenkins'                              AS source
       , a.channel                              AS cod_sales_channel
       , 0                                      AS is_trade_in
       , a.country_cod                          AS hostname
    FROM tmp_ods_sela_api_magento_sub a
    JOIN u_prj_ecom.dim_customer b
      ON b.external_id        = a.consumer_id
     AND b.subsidiary_id      = a.subsidiaryid
     AND b.seller_instance_id = a.sellerinstanceid
   WHERE NOT EXISTS (
          SELECT 1
            FROM u_prj_ecom.ft_ecom_order z
           WHERE z.external_order_id  = a.order_id
             AND z.subsidiary_id      = a.subsidiaryid
             AND z.seller_instance_id = a.sellerinstanceid
             AND z.hostname           = a.country_cod
        );

  -- Order Items (SUB)
  PERFORM INSERT INTO u_prj_ecom.ft_ecom_order_item (
           order_id
         , product_name         
         , reference_code
         , quantity
         , discount
         , ean
         , price
         , kit
         , is_samsung_care
  )
  SELECT DISTINCT
         b.id                               AS order_id
       , a.description                      AS product_name         
       , a.code                             AS reference_code
       , CAST(a.quantity AS INT)            AS quantity
       , CAST(a.discount_sku AS DECIMAL)    AS discount
       , CASE WHEN LENGTH(a.code) > 20 THEN NULL ELSE a.code END AS ean
       , CAST(a.price AS DECIMAL)           AS price
       , 0                                  AS kit
       , 0                                  AS is_samsung_care
    FROM tmp_ods_sela_api_magento_sub a
    JOIN u_prj_ecom.ft_ecom_order b
      ON b.external_order_id = a.order_id
   WHERE b.subsidiary_id      = a.subsidiaryid
     AND b.source             = 'jenkins'
     AND b.seller_instance_id = a.sellerinstanceid
     AND b.hostname           = a.country_cod
     AND NOT EXISTS (
          SELECT 1
            FROM u_prj_ecom.ft_ecom_order_item z
           WHERE z.order_id       = b.id
             AND z.reference_code = a.code
        );

  -- Payments (SUB)
  PERFORM INSERT INTO u_prj_ecom.ft_ecom_order_payment (
           order_id
         , payment_type         
         , installment
         , brand
         , value
  )
  SELECT DISTINCT
         b.id                                        AS order_id
       , SUBSTR(a.payment_type, 1, 23)               AS payment_type
       , COALESCE(CAST(a.qty_installments AS INT),1) AS installment
       , SUBSTR(a.payment_brand, 1, 24)              AS brand
       , a.ordervalue                                AS value
    FROM tmp_ods_sela_api_magento_sub a
    JOIN u_prj_ecom.ft_ecom_order b
      ON b.external_order_id = a.order_id
   WHERE b.subsidiary_id      = a.subsidiaryid
     AND b.source             = 'jenkins'
     AND b.seller_instance_id = a.sellerinstanceid
     AND b.hostname           = a.country_cod
     AND NOT EXISTS (
          SELECT 1
            FROM u_prj_ecom.ft_ecom_order_payment z
           WHERE z.order_id = b.id
        );

  -- Build update temp
  PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_sela_api_magento_update_temp ON COMMIT PRESERVE ROWS AS
  SELECT DISTINCT
         a.order_id                         AS external_order_id
       , a.subsidiaryid                     AS subsidiary_id
       , a.sellerinstanceid                 AS seller_instance_id
       , CAST(a.creation_date AS TIMESTAMP) AS creation_date
       , a.status                           AS status
       , a.status                           AS internal_status
       , a.country_cod                      AS hostname
       , CURRENT_TIMESTAMP                  AS last_update_date
    FROM tmp_ods_sela_api_magento_update a;

  -- Apply updates to orders
  PERFORM UPDATE u_prj_ecom.ft_ecom_order so
     SET status = tmp.status,
         internal_status = tmp.internal_status,
         last_update_date = tmp.last_update_date
    FROM tmp_ods_sela_api_magento_update_temp tmp
   WHERE so.external_order_id = tmp.external_order_id
     AND so.subsidiary_id     = tmp.subsidiary_id
     AND so.status            <> tmp.status;

  -- Insert into ODS
  PERFORM INSERT INTO U_PRJ_ECOM.ODS_SELA_API_MAGENTO (
    ID,
    ORDER_ID,
    STATUS,
    CREATION_DATE,
    PAYMENT_APPROVED_DATE,
    INVOICE_DATE,
    SHIPPING_ESTIMATE_DATE,
    HANDLING_DATE,
    DELIVERED_DATE,
    PAYMENT_TYPE,
    PAYMENT_BRAND,
    QTY_INSTALLMENTS,
    CANCELATION_DATE,
    SHIPPING_COST,
    UNITS,
    CHANNEL,
    DISCOUNT,
    CONSUMER_ID,
    CURRENCY_CODE,
    CODE,
    DESCRIPTION,
    PRICE,
    QUANTITY,
    SHIPPING_COST_SKU,
    DISCOUNT_SKU,
    ORDERVALUE,
    SUBSIDIARYID,
    COUNTRY,
    COUNTRY_COD,
    ORDERITEMQUANTITY,
    SELLERINSTANCEID
  )
  SELECT DISTINCT 
    a.ID,
    a.ORDER_ID,
    a.STATUS,
    a.CREATION_DATE,
    a.PAYMENT_APPROVED_DATE,
    a.INVOICE_DATE,
    a.SHIPPING_ESTIMATE_DATE,
    a.HANDLING_DATE,
    a.DELIVERED_DATE,
    a.PAYMENT_TYPE,
    a.PAYMENT_BRAND,
    a.QTY_INSTALLMENTS,
    a.CANCELATION_DATE,
    a.SHIPPING_COST,
    a.QUANTITY AS UNITS,
    a.CHANNEL,
    a.DISCOUNT,
    a.CONSUMER_ID,
    a.CURRENCY_CODE,
    a.CODE,
    a.DESCRIPTION,
    a.PRICE,
    a.QUANTITY,
    a.SHIPPING_COST_SKU,
    a.DISCOUNT_SKU,
    a.ORDERVALUE,
    a.SUBSIDIARYID,
    a.COUNTRY,
    a.COUNTRY_COD,
    a.ORDERITEMQUANTITY,
    a.SELLERINSTANCEID
  FROM tmp_ods_sela_api_magento_insert a
  WHERE a.ID IS NOT NULL
    AND NOT EXISTS (
        SELECT 1
        FROM U_PRJ_ECOM.ODS_SELA_API_MAGENTO B
        WHERE B.ORDER_ID     = A.ORDER_ID
          AND B.CODE         = A.CODE
          AND B.SUBSIDIARYID = A.SUBSIDIARYID
  );

  -- Update ODS statuses
  PERFORM UPDATE U_PRJ_ECOM.ODS_SELA_API_MAGENTO so
     SET status = tmp.status,
         last_update_date = tmp.last_update_date
    FROM tmp_ods_sela_api_magento_update_temp tmp
   WHERE so.order_id     = tmp.external_order_id
     AND so.SUBSIDIARYID = tmp.subsidiary_id
     AND so.status       <> tmp.status;

END;
$$;

-- CALL U_PRJ_ECOM.PROC_ODS_SELA_API_MAGENTO();
-- ERROR: Severity: ERROR, Message: Cannot set a NOT NULL column (ID) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure PROC_ODS_SELA_API_MAGENTO line 225 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3216, Error Code: 2502, 
-- CALL U_PRJ_ECOM.PROC_ODS_SELA_API_MAGENTO();
-- ERROR: Severity: ERROR, Message: Cannot set a NOT NULL column (ID) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure PROC_ODS_SELA_API_MAGENTO line 225 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3216, Error Code: 2502, 
-- CREATE OR REPLACE PROCEDURE U_PRJ_ECOM.PROC_ODS_SELA_API_MAGENTO()
-- LANGUAGE PLvSQL AS $$
-- BEGIN
-- 
--   PERFORM DROP TABLE IF EXISTS tmp_ods_sela_api_magento_insert;
--   PERFORM DROP TABLE IF EXISTS tmp_ods_sela_api_magento_update;
--   PERFORM DROP TABLE IF EXISTS tmp_ods_sela_api_magento_sub;
--   PERFORM DROP TABLE IF EXISTS tmp_ods_sela_api_magento_totals_temp;
--   PERFORM DROP TABLE IF EXISTS tmp_ods_sela_api_magento_totals_temp_update;
--   PERFORM DROP TABLE IF EXISTS tmp_ods_sela_api_magento_totals_temp_sub;
--   PERFORM DROP TABLE IF EXISTS tmp_ods_sela_api_magento_update_temp;
-- 
--   PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_sela_api_magento_insert ON COMMIT PRESERVE ROWS AS
--   SELECT DISTINCT 
--     A.ID,
--     CURRENT_TIMESTAMP AS inserteddate,
--     A.ORDER_ID,
--     A.STATUS,
--     A.CREATION_DATE,
--     A.PAYMENT_APPROVED_DATE,
--     A.INVOICE_DATE,
--     A.SHIPPING_ESTIMATE_DATE,
--     A.HANDLING_DATE,
--     A.DELIVERED_DATE,
--     A.PAYMENT_TYPE,
--     A.PAYMENT_BRAND,
--     A.QTY_INSTALLMENTS,
--     A.CANCELATION_DATE,
--     A.SHIPPING_COST,
--     A.UNITS,
--     A.CHANNEL,
--     A.DISCOUNT,
--     A.CONSUMER_ID,
--     A.CURRENCY_CODE,
--     A.CODE,
--     A.DESCRIPTION,
--     A.PRICE,
--     A.QUANTITY,
--     A.SHIPPING_COST_SKU,
--     A.DISCOUNT_SKU,
--     A.ORDERVALUE,
--     A.SUBSIDIARYID,
--     A.COUNTRY,
--     A.COUNTRY_COD,
--     A.ORDERITEMQUANTITY,
--     A.SELLERINSTANCEID
--   FROM U_PRJ_ECOM.TMP_ODS_SELA_API_MAGENTO A
--   WHERE NOT EXISTS (
--         SELECT 1
--         FROM U_PRJ_ECOM.FT_ECOM_ORDER B
--         WHERE B.EXTERNAL_ORDER_ID = A.ORDER_ID
--           AND B.SUBSIDIARY_ID     = A.SUBSIDIARYID
--           AND B.INTERNAL_STATUS   = A.STATUS
--   );
-- 
--   PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_sela_api_magento_update ON COMMIT PRESERVE ROWS AS
--   SELECT DISTINCT 
--     A.ID,
--     CURRENT_TIMESTAMP AS inserteddate,
--     A.ORDER_ID,
--     A.STATUS,
--     A.CREATION_DATE,
--     A.PAYMENT_APPROVED_DATE,
--     A.INVOICE_DATE,
--     A.SHIPPING_ESTIMATE_DATE,
--     A.HANDLING_DATE,
--     A.DELIVERED_DATE,
--     A.PAYMENT_TYPE,
--     A.PAYMENT_BRAND,
--     A.QTY_INSTALLMENTS,
--     A.CANCELATION_DATE,
--     A.SHIPPING_COST,
--     A.UNITS,
--     A.CHANNEL,
--     A.DISCOUNT,
--     A.CONSUMER_ID,
--     A.CURRENCY_CODE,
--     A.CODE,
--     A.DESCRIPTION,
--     A.PRICE,
--     A.QUANTITY,
--     A.SHIPPING_COST_SKU,
--     A.DISCOUNT_SKU,
--     A.ORDERVALUE,
--     A.SUBSIDIARYID,
--     A.COUNTRY,
--     A.COUNTRY_COD,
--     A.ORDERITEMQUANTITY,
--     A.SELLERINSTANCEID
--   FROM U_PRJ_ECOM.TMP_ODS_SELA_API_MAGENTO A
--   WHERE NOT EXISTS (
--         SELECT 1
--         FROM U_PRJ_ECOM.FT_ECOM_ORDER B
--         WHERE B.EXTERNAL_ORDER_ID = A.ORDER_ID
--           AND B.SUBSIDIARY_ID     = A.SUBSIDIARYID
--           AND B.INTERNAL_STATUS   = A.STATUS
--   );
-- 
--   PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_sela_api_magento_sub ON COMMIT PRESERVE ROWS AS
--   SELECT DISTINCT 
--     A.ID,
--     CURRENT_TIMESTAMP AS inserteddate,
--     A.ORDER_ID,
--     A.STATUS,
--     A.CREATION_DATE,
--     A.PAYMENT_APPROVED_DATE,
--     A.INVOICE_DATE,
--     A.SHIPPING_ESTIMATE_DATE,
--     A.HANDLING_DATE,
--     A.DELIVERED_DATE,
--     A.PAYMENT_TYPE,
--     A.PAYMENT_BRAND,
--     A.QTY_INSTALLMENTS,
--     A.CANCELATION_DATE,
--     A.SHIPPING_COST,
--     A.UNITS,
--     A.CHANNEL,
--     A.DISCOUNT,
--     A.CONSUMER_ID,
--     A.CURRENCY_CODE,
--     A.CODE,
--     A.DESCRIPTION,
--     A.PRICE,
--     A.QUANTITY,
--     A.SHIPPING_COST_SKU,
--     A.DISCOUNT_SKU,
--     A.ORDERVALUE,
--     A.SUBSIDIARYID,
--     A.COUNTRY,
--     A.COUNTRY_COD,
--     A.ORDERITEMQUANTITY,
--     A.SELLERINSTANCEID
--   FROM U_PRJ_ECOM.TMP_ODS_SELA_API_MAGENTO A
--   WHERE NOT EXISTS (
--         SELECT 1
--         FROM U_PRJ_ECOM.FT_ECOM_ORDER B
--         WHERE B.EXTERNAL_ORDER_ID = A.ORDER_ID
--           AND B.SUBSIDIARY_ID     = A.SUBSIDIARYID
--           AND B.INTERNAL_STATUS   = A.STATUS
--   );
-- 
--   PERFORM DELETE FROM tmp_ods_sela_api_magento_insert WHERE code IS NULL;
--   PERFORM DELETE FROM tmp_ods_sela_api_magento_insert WHERE UPPER(currency_code) <> 'GTQ' AND subsidiaryId = 10;
--   PERFORM DELETE FROM tmp_ods_sela_api_magento_insert WHERE LOWER(code) LIKE 'cup%';
-- 
--   PERFORM DELETE FROM tmp_ods_sela_api_magento_update WHERE code IS NULL;
--   PERFORM DELETE FROM tmp_ods_sela_api_magento_update WHERE UPPER(currency_code) <> 'GTQ' AND subsidiaryId = 10;
--   PERFORM DELETE FROM tmp_ods_sela_api_magento_update WHERE LOWER(code) LIKE 'cup%';
-- 
--   PERFORM DELETE FROM tmp_ods_sela_api_magento_sub WHERE code IS NULL;
--   PERFORM DELETE FROM tmp_ods_sela_api_magento_sub WHERE UPPER(currency_code) <> 'GTQ' AND subsidiaryId = 10;
--   PERFORM DELETE FROM tmp_ods_sela_api_magento_sub WHERE LOWER(code) LIKE 'cup%';
-- 
--   PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_sela_api_magento_totals_temp ON COMMIT PRESERVE ROWS AS
--     SELECT order_id                               AS orderid
--          , SUM(quantity)                          AS quantity
--          , SUM(CAST(price AS DECIMAL) * quantity) AS ordervalue
--          , sellerinstanceid                       AS seller_instance_id
--          , COALESCE(consumer_id, '0')             AS consumer_id
--          , subsidiaryid                           AS subsidiary_id
--          , country_cod                            AS country_cod
--     FROM tmp_ods_sela_api_magento_insert
--     WHERE COALESCE(ordervalue, 0) = 0
--     GROUP BY subsidiaryid, sellerinstanceid, order_id, COALESCE(consumer_id, '0'), country_cod;
-- 
--   PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_sela_api_magento_totals_temp_update ON COMMIT PRESERVE ROWS AS
--     SELECT order_id                               AS orderid
--          , SUM(quantity)                          AS quantity
--          , SUM(CAST(price AS DECIMAL) * quantity) AS ordervalue
--          , sellerinstanceid                       AS seller_instance_id
--          , COALESCE(consumer_id, '0')             AS consumer_id
--          , subsidiaryid                           AS subsidiary_id
--          , country_cod                            AS country_cod
--     FROM tmp_ods_sela_api_magento_update
--     WHERE COALESCE(ordervalue, 0) = 0
--     GROUP BY subsidiaryid, sellerinstanceid, order_id, COALESCE(consumer_id, '0'), country_cod;
-- 
--   PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_sela_api_magento_totals_temp_sub ON COMMIT PRESERVE ROWS AS
--     SELECT order_id                               AS orderid
--          , SUM(quantity)                          AS quantity
--          , SUM(CAST(price AS DECIMAL) * quantity) AS ordervalue
--          , sellerinstanceid                       AS seller_instance_id
--          , COALESCE(consumer_id, '0')             AS consumer_id
--          , subsidiaryid                           AS subsidiary_id
--          , country_cod                            AS country_cod
--     FROM tmp_ods_sela_api_magento_sub
--     WHERE COALESCE(ordervalue, 0) = 0
--     GROUP BY subsidiaryid, sellerinstanceid, order_id, COALESCE(consumer_id, '0'), country_cod;
-- 
--   PERFORM UPDATE tmp_ods_sela_api_magento_insert b
--      SET ordervalue        = a.ordervalue
--        , orderitemquantity = a.quantity
--        , consumer_id       = a.consumer_id
--     FROM tmp_ods_sela_api_magento_totals_temp a
--    WHERE b.subsidiaryid      = a.subsidiary_id
--      AND b.sellerinstanceid  = a.seller_instance_id
--      AND b.order_id          = a.orderid
--      AND b.country_cod       = a.country_cod;
-- 
--   PERFORM UPDATE tmp_ods_sela_api_magento_update b
--      SET ordervalue        = a.ordervalue
--        , orderitemquantity = a.quantity
--        , consumer_id       = a.consumer_id
--     FROM tmp_ods_sela_api_magento_totals_temp_update a
--    WHERE b.subsidiaryid      = a.subsidiary_id
--      AND b.sellerinstanceid  = a.seller_instance_id
--      AND b.order_id          = a.orderid
--      AND b.country_cod       = a.country_cod;
-- 
--   PERFORM UPDATE tmp_ods_sela_api_magento_sub b
--      SET ordervalue        = a.ordervalue
--        , orderitemquantity = a.quantity
--        , consumer_id       = a.consumer_id
--     FROM tmp_ods_sela_api_magento_totals_temp_sub a
--    WHERE b.subsidiaryid      = a.subsidiary_id
--      AND b.sellerinstanceid  = a.seller_instance_id
--      AND b.order_id          = a.orderid
--      AND b.country_cod       = a.country_cod;
-- 
--   PERFORM INSERT INTO u_prj_ecom.dim_customer (
--            external_id, insert_date, seller_instance_id, subsidiary_id)
--   SELECT a.consumer_id, NOW(), a.sellerinstanceid, a.subsidiaryid
--     FROM tmp_ods_sela_api_magento_insert a
--    WHERE NOT EXISTS (
--           SELECT 1 FROM u_prj_ecom.dim_customer z
--            WHERE z.subsidiary_id=a.subsidiaryid AND z.seller_instance_id=a.sellerinstanceid AND z.external_id=COALESCE(a.consumer_id,'0'))
--    GROUP BY a.consumer_id, a.subsidiaryid, a.sellerinstanceid;
-- 
--   PERFORM INSERT INTO u_prj_ecom.ft_ecom_order (
--     external_order_id, subsidiary_id, creation_date, status, internal_status, order_value, customer_id, country,
--     shipping_cost, discount, status_order_created_date, status_payment_approved_date, status_invoiced_date,
--     status_start_handling_date, status_handling_shipping_date, status_delivered_date, status_canceled_date,
--     insert_date, last_update_date, affiliate_id, seller_instance_id, source, cod_sales_channel, is_trade_in, hostname)
--   SELECT DISTINCT a.order_id, a.subsidiaryid, CAST(a.creation_date AS TIMESTAMP), a.status, a.status, a.ordervalue,
--          b.id, a.country, CAST(a.shipping_cost AS DECIMAL), CAST(a.discount AS DECIMAL),
--          CAST(a.creation_date AS TIMESTAMP), CAST(a.payment_approved_date AS TIMESTAMP), CAST(a.invoice_date AS TIMESTAMP),
--          CAST(a.handling_date AS TIMESTAMP), CAST(a.shipping_estimate_date AS TIMESTAMP), CAST(a.delivered_date AS TIMESTAMP),
--          CAST(a.cancelation_date AS TIMESTAMP), NOW(), NOW(), 'SAMSUNG', a.sellerinstanceid, 'jenkins', a.channel, 0, a.country_cod
--     FROM tmp_ods_sela_api_magento_insert a
--     JOIN u_prj_ecom.dim_customer b ON b.external_id=a.consumer_id AND b.subsidiary_id=a.subsidiaryid AND b.seller_instance_id=a.sellerinstanceid
--    WHERE NOT EXISTS (SELECT 1 FROM u_prj_ecom.ft_ecom_order z
--                       WHERE z.external_order_id=a.order_id AND z.subsidiary_id=a.subsidiaryid AND z.seller_instance_id=a.sellerinstanceid AND z.hostname=a.country_cod);
-- 
--   PERFORM INSERT INTO u_prj_ecom.ft_ecom_order_item (order_id, product_name, reference_code, quantity, discount, ean, price, kit, is_samsung_care)
--   SELECT DISTINCT b.id, a.description, a.code, CAST(a.quantity AS INT), CAST(a.discount_sku AS DECIMAL),
--          CASE WHEN LENGTH(a.code)>20 THEN NULL ELSE a.code END, CAST(a.price AS DECIMAL), 0, 0
--     FROM tmp_ods_sela_api_magento_insert a
--     JOIN u_prj_ecom.ft_ecom_order b ON b.external_order_id=a.order_id
--    WHERE b.subsidiary_id=a.subsidiaryid AND b.source='jenkins' AND b.seller_instance_id=a.sellerinstanceid AND b.hostname=a.country_cod
--      AND NOT EXISTS (SELECT 1 FROM u_prj_ecom.ft_ecom_order_item z WHERE z.order_id=b.id AND z.reference_code=a.code);
-- 
--   PERFORM INSERT INTO u_prj_ecom.ft_ecom_order_payment (order_id, payment_type, installment, brand, value)
--   SELECT DISTINCT b.id, SUBSTR(a.payment_type,1,23), COALESCE(CAST(a.qty_installments AS INT),1), SUBSTR(a.payment_brand,1,24), a.ordervalue
--     FROM tmp_ods_sela_api_magento_insert a
--     JOIN u_prj_ecom.ft_ecom_order b ON b.external_order_id=a.order_id
--    WHERE b.subsidiary_id=a.subsidiaryid AND b.source='jenkins' AND b.seller_instance_id=a.sellerinstanceid AND b.hostname=a.country_cod
--      AND NOT EXISTS (SELECT 1 FROM u_prj_ecom.ft_ecom_order_payment z WHERE z.order_id=b.id);
-- 
--   PERFORM INSERT INTO u_prj_ecom.dim_customer (external_id, insert_date, seller_instance_id, subsidiary_id)
--   SELECT a.consumer_id, NOW(), a.sellerinstanceid, a.subsidiaryid
--     FROM tmp_ods_sela_api_magento_sub a
--    WHERE NOT EXISTS (
--           SELECT 1 FROM u_prj_ecom.dim_customer z
--            WHERE z.subsidiary_id=a.subsidiaryid AND z.seller_instance_id=a.sellerinstanceid AND z.external_id=COALESCE(a.consumer_id,'0'))
--    GROUP BY a.consumer_id, a.subsidiaryid, a.sellerinstanceid;
-- 
--   PERFORM INSERT INTO u_prj_ecom.ft_ecom_order (
--     external_order_id, subsidiary_id, creation_date, status, internal_status, order_value, customer_id, country, shipping_cost, discount,
--     status_order_created_date, status_payment_approved_date, status_invoiced_date, status_start_handling_date, status_handling_shipping_date,
--     status_delivered_date, status_canceled_date, insert_date, last_update_date, affiliate_id, seller_instance_id, source, cod_sales_channel, is_trade_in, hostname)
--   SELECT DISTINCT a.order_id, a.subsidiaryid, CAST(a.creation_date AS TIMESTAMP), a.status, a.status, a.ordervalue,
--          b.id, a.country, CAST(a.shipping_cost AS DECIMAL), CAST(a.discount AS DECIMAL), CAST(a.creation_date AS TIMESTAMP),
--          CAST(a.payment_approved_date AS TIMESTAMP), CAST(a.invoice_date AS TIMESTAMP), CAST(a.handling_date AS TIMESTAMP),
--          CAST(a.shipping_estimate_date AS TIMESTAMP), CAST(a.delivered_date AS TIMESTAMP), CAST(a.cancelation_date AS TIMESTAMP), NOW(), NOW(),
--          'SAMSUNG', a.sellerinstanceid, 'jenkins', a.channel, 0, a.country_cod
--     FROM tmp_ods_sela_api_magento_sub a
--     JOIN u_prj_ecom.dim_customer b ON b.external_id=a.consumer_id AND b.subsidiary_id=a.subsidiaryid AND b.seller_instance_id=a.sellerinstanceid
--    WHERE NOT EXISTS (SELECT 1 FROM u_prj_ecom.ft_ecom_order z
--                       WHERE z.external_order_id=a.order_id AND z.subsidiary_id=a.subsidiaryid AND z.seller_instance_id=a.sellerinstanceid AND z.hostname=a.country_cod);
-- 
--   PERFORM INSERT INTO u_prj_ecom.ft_ecom_order_item (order_id, product_name, reference_code, quantity, discount, ean, price, kit, is_samsung_care)
--   SELECT DISTINCT b.id, a.description, a.code, CAST(a.quantity AS INT), CAST(a.discount_sku AS DECIMAL),
--          CASE WHEN LENGTH(a.code)>20 THEN NULL ELSE a.code END, CAST(a.price AS DECIMAL), 0, 0
--     FROM tmp_ods_sela_api_magento_sub a
--     JOIN u_prj_ecom.ft_ecom_order b ON b.external_order_id=a.order_id
--    WHERE b.subsidiary_id=a.subsidiaryid AND b.source='jenkins' AND b.seller_instance_id=a.sellerinstanceid AND b.hostname=a.country_cod
--      AND NOT EXISTS (SELECT 1 FROM u_prj_ecom.ft_ecom_order_item z WHERE z.order_id=b.id AND z.reference_code=a.code);
-- 
--   PERFORM INSERT INTO u_prj_ecom.ft_ecom_order_payment (order_id, payment_type, installment, brand, value)
--   SELECT DISTINCT b.id, SUBSTR(a.payment_type,1,23), COALESCE(CAST(a.qty_installments AS INT),1), SUBSTR(a.payment_brand,1,24), a.ordervalue
--     FROM tmp_ods_sela_api_magento_sub a
--     JOIN u_prj_ecom.ft_ecom_order b ON b.external_order_id=a.order_id
--    WHERE b.subsidiary_id=a.subsidiaryid AND b.source='jenkins' AND b.seller_instance_id=a.sellerinstanceid AND b.hostname=a.country_cod
--      AND NOT EXISTS (SELECT 1 FROM u_prj_ecom.ft_ecom_order_payment z WHERE z.order_id=b.id);
-- 
--   PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_sela_api_magento_update_temp ON COMMIT PRESERVE ROWS AS
--   SELECT DISTINCT a.order_id AS external_order_id, a.subsidiaryid AS subsidiary_id, a.sellerinstanceid AS seller_instance_id,
--          CAST(a.creation_date AS TIMESTAMP) AS creation_date, a.status AS status, a.status AS internal_status, a.country_cod AS hostname,
--          CURRENT_TIMESTAMP AS last_update_date
--     FROM tmp_ods_sela_api_magento_update a;
-- 
--   PERFORM UPDATE u_prj_ecom.ft_ecom_order so
--      SET status = tmp.status,
--          internal_status = tmp.internal_status,
--          last_update_date = tmp.last_update_date
--     FROM tmp_ods_sela_api_magento_update_temp tmp
--    WHERE so.external_order_id = tmp.external_order_id
--      AND so.subsidiary_id     = tmp.subsidiary_id
--      AND so.status            <> tmp.status;
-- 
--   RETURN;
-- 
--   -- The following ODS operations are temporarily bypassed for debugging
--   PERFORM INSERT INTO U_PRJ_ECOM.ODS_SELA_API_MAGENTO (...) SELECT 1 WHERE 1=0;
-- 
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: Syntax error at or near ".", Sqlstate: 42601, Position: 15501, Routine: base_yyerror, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/scan.l, Line: 1056, Error Code: 4856, 
SELECT COUNT(*) AS cnt_null_id FROM U_PRJ_ECOM.TMP_ODS_SELA_API_MAGENTO WHERE ID IS NULL;
-- cnt_null_id
-- -----------
-- 0

SELECT COUNT(*) AS cnt
FROM U_PRJ_ECOM.TMP_ODS_SELA_API_MAGENTO A
WHERE NOT EXISTS (
  SELECT 1 FROM U_PRJ_ECOM.FT_ECOM_ORDER B
  WHERE B.EXTERNAL_ORDER_ID = A.ORDER_ID
    AND B.SUBSIDIARY_ID     = A.SUBSIDIARYID
    AND B.INTERNAL_STATUS   = A.STATUS
)
AND A.ID IS NULL;
-- cnt
-- ---
-- 0

SELECT column_name, data_type, is_identity, is_nullable, column_default FROM columns WHERE table_schema='u_prj_ecom' AND table_name='dim_customer' ORDER BY ordinal_position;
-- column_name | data_type | is_identity | is_nullable | column_default
-- ------------+-----------+-------------+-------------+---------------

-- SELECT column_name, data_type, is_nullable, is_identity, default_value FROM v_catalog.columns WHERE table_schema='U_PRJ_ECOM' AND table_name='ODS_SELA_API_MAGENTO' ORDER BY ordinal_position;
-- ERROR: Severity: ERROR, Message: Column "default_value" does not exist, Sqlstate: 42703, Routine: transformSQLColumnRef, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Optimizer/OptUtil/ExprUtil.cpp, Line: 7401, Error Code: 2624, 
SELECT column_name, data_type, is_nullable, is_identity, column_default FROM v_catalog.columns WHERE table_schema='U_PRJ_ECOM' AND table_name='ODS_SELA_API_MAGENTO' ORDER BY ordinal_position;
-- column_name | data_type | is_nullable | is_identity | column_default
-- ------------+-----------+-------------+-------------+---------------
-- ID | int | True | False | 
-- INSERTEDDATE | timestamp | True | False | 
-- ORDER_ID | varchar(1000) | True | False | 
-- STATUS | varchar(1000) | True | False | 
-- CREATION_DATE | timestamp | True | False | 
-- PAYMENT_APPROVED_DATE | timestamp | True | False | 
-- INVOICE_DATE | timestamp | True | False | 
-- SHIPPING_ESTIMATE_DATE | timestamp | True | False | 
-- HANDLING_DATE | timestamp | True | False | 
-- DELIVERED_DATE | timestamp | True | False | 
-- PAYMENT_TYPE | varchar(1000) | True | False | 
-- PAYMENT_BRAND | varchar(1000) | True | False | 
-- QTY_INSTALLMENTS | int | True | False | 
-- CANCELATION_DATE | timestamp | True | False | 
-- SHIPPING_COST | numeric(34,0) | True | False | 
-- UNITS | int | True | False | 
-- CHANNEL | varchar(1000) | True | False | 
-- DISCOUNT | numeric(34,0) | True | False | 
-- CONSUMER_ID | varchar(1000) | True | False | 
-- CURRENCY_CODE | varchar(1000) | True | False | 
-- CODE | varchar(1000) | True | False | 
-- DESCRIPTION | varchar(1000) | True | False | 
-- PRICE | numeric(15,2) | True | False | 
-- QUANTITY | int | True | False | 
-- SHIPPING_COST_SKU | numeric(34,0) | True | False | 
-- DISCOUNT_SKU | numeric(34,0) | True | False | 
-- ORDERVALUE | numeric(34,0) | True | False | 
-- SUBSIDIARYID | int | True | False | 
-- COUNTRY | varchar(5) | True | False | 
-- COUNTRY_COD | varchar(255) | True | False | 
-- ORDERITEMQUANTITY | int | True | False | 
-- SELLERINSTANCEID | int | True | False | 
-- LAST_UPDATE_DATE | timestamp | True | False | 
-- LOAD_DATE | timestamp | True | False | 

