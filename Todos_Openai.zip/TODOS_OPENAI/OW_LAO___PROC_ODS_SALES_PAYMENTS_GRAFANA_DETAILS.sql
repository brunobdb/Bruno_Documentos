CREATE OR REPLACE PROCEDURE ow_lao.proc_ods_sales_payments_grafana_details()
LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM TRUNCATE TABLE ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS;

    PERFORM INSERT INTO ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS
    SELECT 
          a.inserted_timestamp AS insert_timestamp
        , CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_created_date)) AS DATE) AS po_date
        , EXTRACT(MONTH FROM CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_created_date)) AS DATE)) AS po_month
        , EXTRACT(YEAR  FROM CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_created_date)) AS DATE)) AS po_year
        , EXTRACT(HOUR  FROM TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_created_date))) AS po_hour
        , a.tenant AS pay_subsidiary
        , a.pe_code AS pay_code
        , a.paymentid AS pay_id
        , CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.pe_time)) AS DATE) AS pay_date
        , EXTRACT(MONTH FROM CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.pe_time)) AS DATE)) AS pay_month
        , EXTRACT(YEAR  FROM CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.pe_time)) AS DATE)) AS pay_year
        , EXTRACT(HOUR  FROM TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.pe_time))) AS pay_hour
        , COALESCE(a.pe_status, '') AS pay_status
        , a.pe_status_detail AS pay_detail
        , a.payment_code AS pay_gateway_code
        , a.payment_mode AS payment_type
        , a.payment_provider AS pay_gateway
        , a.pe_amount AS revenue_local
        , SUBSTR(a.orderid,1,17) AS pay_orderid
        , c.site AS pay_storename
        , a.isbasestore AS postoretype
        , a.sales_application AS po_devicetype
        , COALESCE(a.order_status, '') AS po_status
        , a.order_type AS order_status_type
        , a.order_currency AS currency
        , CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_modified_date)) AS TIMESTAMP) AS po_order_lastmodifydate
        , d.affiliate_id AS postorename
        , d.global_channel AS channel
        , d.biz_type AS biz_type
        , d.audience_type AS audience_type
        , d.sales_org AS subsidiary
        , a.pe_amount AS pe_amount
        , CAST(NULL AS DECIMAL) AS revenu_usd
        , CAST('' AS VARCHAR(255)) AS po_orderid
        , CAST('' AS VARCHAR(255)) AS pay_action
        , CAST('' AS VARCHAR(255)) AS pay_result
        , CAST('' AS VARCHAR(1000)) AS pay_description
        , CAST('' AS VARCHAR(255)) AS pay_message
        , CAST('' AS VARCHAR(255)) AS po_internal_status
        , CAST('' AS VARCHAR(255)) AS po_payment_type
        , CAST('' AS VARCHAR(255)) AS po_paymentprovider
        , CAST('' AS VARCHAR(255)) AS payment_card_brand
        , CAST('' AS VARCHAR(255)) AS po_status_ct
        , CAST(NULL AS VARCHAR(255)) AS funnel_status
        , SUBSTR(a.orderid,1,17) AS orderid_log
        , ROW_NUMBER() OVER(
            PARTITION BY a.tenant, c.site, SUBSTR(a.orderid,1,17)
            ORDER BY CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_modified_date)) AS TIMESTAMP) DESC
          ) AS dedup
        , CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_modified_date)) AS TIMESTAMP) AS datasource_origin_timestamp
        , 'GRAFANA_HYBRIS' AS PO_PLATAFORM_DATASOURCE
        , CAST(NULL AS VARCHAR(255)) AS PAY_GATEWAY_STATUS
        , CAST(NULL AS VARCHAR(255)) AS PO_PAYMENT_TYPE_STATUS
    FROM ow_lao.raw_grafana_document_payments_details a
    JOIN u_prj_ecom.dim_subsidiary b
      ON LOWER(b.country_code) = LOWER(a.tenant)
    JOIN ow_lao.ods_hybris_sales c
      ON SUBSTR(c.order_code,1,17) = SUBSTR(a.orderid,1,17)
    JOIN ow_md.sales_channel d
      ON LOWER(d.country) = LOWER(b.country)
     AND LOWER(d.identifier) = LOWER(c.site)
    WHERE NOT EXISTS (
            SELECT 1
            FROM ow_lao.ods_payment_funnel aa
            WHERE SUBSTR(a.orderid,1,17) = SUBSTR(aa.pay_orderid,1,17)
              AND a.tenant = aa.pay_subsidiary
              AND CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_modified_date)) AS TIMESTAMP) <= aa.datasource_origin_timestamp
          )
      AND b.order_apply_timezone = 1
      AND CAST(a.inserted_timestamp AS DATE) >= DATE '2025-04-13';

    PERFORM DELETE FROM ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS
     WHERE dedup <> 1;

    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS a
       SET po_internal_status = b.order_status,
           po_payment_type    = b.payment_mode,
           po_paymentprovider = b.payment_provider,
           payment_card_brand = b.payment_mode_creditcardtype
      FROM ow_lao.ods_hybris_sales b
     WHERE SUBSTR(b.order_code,1,17) = SUBSTR(a.pay_orderid,1,17);

    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS a
       SET po_orderid      = b.orderid,
           pay_action      = b.action,
           pay_description = b.description,
           pay_message     = b.message
      FROM ow_lao.raw_grafana_document_log_payments_details b
     WHERE SUBSTR(b.orderid,1,17) = a.orderid_log;

    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS a
       SET revenu_usd = a.pe_amount / CAST(b.exchange_rate AS DECIMAL)
      FROM ow_lao.ft_ap2_exchange_rate b
     WHERE b.valid_from = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE))
       AND LOWER(b.to_currency) = LOWER(a.currency);

    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS a
       SET po_status_ct = b.status
      FROM ow_lao.dim_ods_sales_control_tower_table_status_mapping b
     WHERE b.status_origin = a.po_internal_status;

    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS a
       SET funnel_status = b.status
      FROM ow_lao.DIM_PAYMENT_FUNNEL_STATUS_MAPPING b
     WHERE b.pay_status = a.pay_status
       AND b.po_status = a.po_status
       AND b.pay_description = a.pay_description
       AND b.data_source = a.po_plataform_datasource
       AND b.active = TRUE;

    PERFORM UPDATE ow_lao.tmp_sales_payments_grafana_details a
       SET pay_gateway_status = b.gateway
      FROM ow_lao.dim_payment_pay_gateway_mapping b
     WHERE b.data_source = a.po_plataform_datasource
       AND b.pay_gateway = a.pay_gateway
       AND b.active = TRUE;

    PERFORM UPDATE ow_lao.tmp_sales_payments_grafana_details a
       SET po_payment_type_status = b.payment_mode
      FROM ow_lao.dim_payment_type_mapping b
     WHERE b.data_source = a.po_plataform_datasource
       AND b.payment_type = a.payment_type
       AND b.active = TRUE;

    PERFORM MERGE INTO ow_lao.ods_payment_funnel a
    USING ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS b
       ON SUBSTR(b.pay_orderid,1,17) = SUBSTR(a.pay_orderid,1,17)
      AND b.pay_subsidiary = a.pay_subsidiary
    WHEN MATCHED THEN UPDATE SET
           po_date = b.po_date,
           po_month = b.po_month,
           po_year = b.po_year,
           po_hour = b.po_hour,
           pay_subsidiary = b.pay_subsidiary,
           pay_code = b.pay_code,
           pay_id = b.pay_id,
           pay_date = b.pay_date,
           pay_month = b.pay_month,
           pay_year = b.pay_year,
           pay_hour = b.pay_hour,
           pay_status = b.pay_status,
           pay_detail = b.pay_detail,
           pay_gateway_code = b.pay_gateway_code,
           payment_type = b.payment_type,
           pay_gateway = b.pay_gateway,
           revenue_local = b.revenue_local,
           pay_orderid = b.pay_orderid,
           pay_storename = b.pay_storename,
           postoretype = b.postoretype,
           po_devicetype = b.po_devicetype,
           po_status = b.po_status,
           order_status_type = b.order_status_type,
           currency = b.currency,
           po_order_lastmodifydate = b.po_order_lastmodifydate,
           postorename = b.postorename,
           channel = b.channel,
           biz_type = b.biz_type,
           audience_type = b.audience_type,
           subsidiary = b.subsidiary,
           pe_amount = b.pe_amount,
           revenu_usd = b.revenu_usd,
           po_orderid = b.po_orderid,
           pay_action = b.pay_action,
           pay_result = b.pay_result,
           pay_description = b.pay_description,
           pay_message = b.pay_message,
           po_internal_status = b.po_internal_status,
           po_payment_type = b.po_payment_type,
           po_paymentprovider = b.po_paymentprovider,
           payment_card_brand = b.payment_card_brand,
           po_status_ct = b.po_status_ct,
           funnel_status = b.funnel_status,
           updated_timestamp = CURRENT_TIMESTAMP,
           PAY_GATEWAY_STATUS = b.PAY_GATEWAY_STATUS,
           PO_PAYMENT_TYPE_STATUS = b.PO_PAYMENT_TYPE_STATUS,
           PO_PLATAFORM_DATASOURCE = b.PO_PLATAFORM_DATASOURCE,
           datasource_origin_timestamp = b.datasource_origin_timestamp
    WHEN NOT MATCHED THEN INSERT (
           po_date,
           po_month,
           po_year,
           po_hour,
           pay_subsidiary,
           pay_code,
           pay_id,
           pay_date,
           pay_month,
           pay_year,
           pay_hour,
           pay_status,
           pay_detail,
           pay_gateway_code,
           payment_type,
           pay_gateway,
           revenue_local,
           pay_orderid,
           pay_storename,
           postoretype,
           po_devicetype,
           po_status,
           order_status_type,
           currency,
           po_order_lastmodifydate,
           postorename,
           channel,
           biz_type,
           audience_type,
           subsidiary,
           pe_amount,
           revenu_usd,
           po_orderid,
           pay_action,
           pay_result,
           pay_description,
           pay_message,
           po_internal_status,
           po_payment_type,
           po_paymentprovider,
           payment_card_brand,
           po_status_ct,
           funnel_status,
           PAY_GATEWAY_STATUS,
           PO_PAYMENT_TYPE_STATUS,
           PO_PLATAFORM_DATASOURCE,
           datasource_origin_timestamp
    ) VALUES (
           b.po_date,
           b.po_month,
           b.po_year,
           b.po_hour,
           b.pay_subsidiary,
           b.pay_code,
           b.pay_id,
           b.pay_date,
           b.pay_month,
           b.pay_year,
           b.pay_hour,
           b.pay_status,
           b.pay_detail,
           b.pay_gateway_code,
           b.payment_type,
           b.pay_gateway,
           b.revenue_local,
           b.pay_orderid,
           b.pay_storename,
           b.postoretype,
           b.po_devicetype,
           b.po_status,
           b.order_status_type,
           b.currency,
           b.po_order_lastmodifydate,
           b.postorename,
           b.channel,
           b.biz_type,
           b.audience_type,
           b.subsidiary,
           b.pe_amount,
           b.revenu_usd,
           b.po_orderid,
           b.pay_action,
           b.pay_result,
           b.pay_description,
           b.pay_message,
           b.po_internal_status,
           b.po_payment_type,
           b.po_paymentprovider,
           b.payment_card_brand,
           b.po_status_ct,
           b.funnel_status,
           b.PAY_GATEWAY_STATUS,
           b.PO_PAYMENT_TYPE_STATUS,
           b.PO_PLATAFORM_DATASOURCE,
           b.datasource_origin_timestamp
    );
END;
$$;

-- CALL ow_lao.proc_ods_sales_payments_grafana_details();
-- ERROR: Severity: ERROR, Message: Operator does not exist: varchar = timestamp, Sqlstate: 42883, Hint: No operator matches the given name and argument type(s). You may need to add explicit type casts, Where: PL/vSQL procedure proc_ods_sales_payments_grafana_details line 97 at static SQL, Routine: op_error, File: parse_oper.c, Line: 608, Error Code: 4286, 
-- CALL ow_lao.proc_ods_sales_payments_grafana_details();
-- ERROR: Severity: ERROR, Message: Operator does not exist: varchar = timestamp, Sqlstate: 42883, Hint: No operator matches the given name and argument type(s). You may need to add explicit type casts, Where: PL/vSQL procedure proc_ods_sales_payments_grafana_details line 97 at static SQL, Routine: op_error, File: parse_oper.c, Line: 608, Error Code: 4286, 
CREATE OR REPLACE PROCEDURE ow_lao.proc_ods_sales_payments_grafana_details()
LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM TRUNCATE TABLE ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS;

    PERFORM INSERT INTO ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS
    SELECT 
          a.inserted_timestamp AS insert_timestamp
        , CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_created_date)) AS DATE) AS po_date
        , EXTRACT(MONTH FROM CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_created_date)) AS DATE)) AS po_month
        , EXTRACT(YEAR  FROM CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_created_date)) AS DATE)) AS po_year
        , EXTRACT(HOUR  FROM TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_created_date))) AS po_hour
        , a.tenant AS pay_subsidiary
        , a.pe_code AS pay_code
        , a.paymentid AS pay_id
        , CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.pe_time)) AS DATE) AS pay_date
        , EXTRACT(MONTH FROM CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.pe_time)) AS DATE)) AS pay_month
        , EXTRACT(YEAR  FROM CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.pe_time)) AS DATE)) AS pay_year
        , EXTRACT(HOUR  FROM TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.pe_time))) AS pay_hour
        , COALESCE(a.pe_status, '') AS pay_status
        , a.pe_status_detail AS pay_detail
        , a.payment_code AS pay_gateway_code
        , a.payment_mode AS payment_type
        , a.payment_provider AS pay_gateway
        , a.pe_amount AS revenue_local
        , SUBSTR(a.orderid,1,17) AS pay_orderid
        , c.site AS pay_storename
        , a.isbasestore AS postoretype
        , a.sales_application AS po_devicetype
        , COALESCE(a.order_status, '') AS po_status
        , a.order_type AS order_status_type
        , a.order_currency AS currency
        , CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_modified_date)) AS TIMESTAMP) AS po_order_lastmodifydate
        , d.affiliate_id AS postorename
        , d.global_channel AS channel
        , d.biz_type AS biz_type
        , d.audience_type AS audience_type
        , d.sales_org AS subsidiary
        , a.pe_amount AS pe_amount
        , CAST(NULL AS DECIMAL) AS revenu_usd
        , CAST('' AS VARCHAR(255)) AS po_orderid
        , CAST('' AS VARCHAR(255)) AS pay_action
        , CAST('' AS VARCHAR(255)) AS pay_result
        , CAST('' AS VARCHAR(1000)) AS pay_description
        , CAST('' AS VARCHAR(255)) AS pay_message
        , CAST('' AS VARCHAR(255)) AS po_internal_status
        , CAST('' AS VARCHAR(255)) AS po_payment_type
        , CAST('' AS VARCHAR(255)) AS po_paymentprovider
        , CAST('' AS VARCHAR(255)) AS payment_card_brand
        , CAST('' AS VARCHAR(255)) AS po_status_ct
        , CAST(NULL AS VARCHAR(255)) AS funnel_status
        , SUBSTR(a.orderid,1,17) AS orderid_log
        , ROW_NUMBER() OVER(
            PARTITION BY a.tenant, c.site, SUBSTR(a.orderid,1,17)
            ORDER BY CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_modified_date)) AS TIMESTAMP) DESC
          ) AS dedup
        , CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_modified_date)) AS TIMESTAMP) AS datasource_origin_timestamp
        , 'GRAFANA_HYBRIS' AS PO_PLATAFORM_DATASOURCE
        , CAST(NULL AS VARCHAR(255)) AS PAY_GATEWAY_STATUS
        , CAST(NULL AS VARCHAR(255)) AS PO_PAYMENT_TYPE_STATUS
    FROM ow_lao.raw_grafana_document_payments_details a
    JOIN u_prj_ecom.dim_subsidiary b
      ON LOWER(b.country_code) = LOWER(a.tenant)
    JOIN ow_lao.ods_hybris_sales c
      ON SUBSTR(c.order_code,1,17) = SUBSTR(a.orderid,1,17)
    JOIN ow_md.sales_channel d
      ON LOWER(d.country) = LOWER(b.country)
     AND LOWER(d.identifier) = LOWER(c.site)
    WHERE NOT EXISTS (
            SELECT 1
            FROM ow_lao.ods_payment_funnel aa
            WHERE SUBSTR(a.orderid,1,17) = SUBSTR(aa.pay_orderid,1,17)
              AND a.tenant = aa.pay_subsidiary
              AND CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_modified_date)) AS TIMESTAMP) <= aa.datasource_origin_timestamp
          )
      AND b.order_apply_timezone = 1
      AND CAST(a.inserted_timestamp AS DATE) >= DATE '2025-04-13';

    PERFORM DELETE FROM ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS
     WHERE dedup <> 1;

    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS a
       SET po_internal_status = b.order_status,
           po_payment_type    = b.payment_mode,
           po_paymentprovider = b.payment_provider,
           payment_card_brand = b.payment_mode_creditcardtype
      FROM ow_lao.ods_hybris_sales b
     WHERE SUBSTR(b.order_code,1,17) = SUBSTR(a.pay_orderid,1,17);

    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS a
       SET po_orderid      = b.orderid,
           pay_action      = b.action,
           pay_description = b.description,
           pay_message     = b.message
      FROM ow_lao.raw_grafana_document_log_payments_details b
     WHERE SUBSTR(b.orderid,1,17) = a.orderid_log;

    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS a
       SET revenu_usd = a.pe_amount / CAST(b.exchange_rate AS DECIMAL)
      FROM ow_lao.ft_ap2_exchange_rate b
     WHERE CAST(b.valid_from AS DATE) = CAST(DATEADD('day', -1, CAST(a.po_date AS DATE)) AS DATE)
       AND LOWER(b.to_currency) = LOWER(a.currency);

    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS a
       SET po_status_ct = b.status
      FROM ow_lao.dim_ods_sales_control_tower_table_status_mapping b
     WHERE b.status_origin = a.po_internal_status;

    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS a
       SET funnel_status = b.status
      FROM ow_lao.DIM_PAYMENT_FUNNEL_STATUS_MAPPING b
     WHERE b.pay_status = a.pay_status
       AND b.po_status = a.po_status
       AND b.pay_description = a.pay_description
       AND b.data_source = a.po_plataform_datasource
       AND b.active = TRUE;

    PERFORM UPDATE ow_lao.tmp_sales_payments_grafana_details a
       SET pay_gateway_status = b.gateway
      FROM ow_lao.dim_payment_pay_gateway_mapping b
     WHERE b.data_source = a.po_plataform_datasource
       AND b.pay_gateway = a.pay_gateway
       AND b.active = TRUE;

    PERFORM UPDATE ow_lao.tmp_sales_payments_grafana_details a
       SET po_payment_type_status = b.payment_mode
      FROM ow_lao.dim_payment_type_mapping b
     WHERE b.data_source = a.po_plataform_datasource
       AND b.payment_type = a.payment_type
       AND b.active = TRUE;

    PERFORM MERGE INTO ow_lao.ods_payment_funnel a
    USING ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS b
       ON SUBSTR(b.pay_orderid,1,17) = SUBSTR(a.pay_orderid,1,17)
      AND b.pay_subsidiary = a.pay_subsidiary
    WHEN MATCHED THEN UPDATE SET
           po_date = b.po_date,
           po_month = b.po_month,
           po_year = b.po_year,
           po_hour = b.po_hour,
           pay_subsidiary = b.pay_subsidiary,
           pay_code = b.pay_code,
           pay_id = b.pay_id,
           pay_date = b.pay_date,
           pay_month = b.pay_month,
           pay_year = b.pay_year,
           pay_hour = b.pay_hour,
           pay_status = b.pay_status,
           pay_detail = b.pay_detail,
           pay_gateway_code = b.pay_gateway_code,
           payment_type = b.payment_type,
           pay_gateway = b.pay_gateway,
           revenue_local = b.revenue_local,
           pay_orderid = b.pay_orderid,
           pay_storename = b.pay_storename,
           postoretype = b.postoretype,
           po_devicetype = b.po_devicetype,
           po_status = b.po_status,
           order_status_type = b.order_status_type,
           currency = b.currency,
           po_order_lastmodifydate = b.po_order_lastmodifydate,
           postorename = b.postorename,
           channel = b.channel,
           biz_type = b.biz_type,
           audience_type = b.audience_type,
           subsidiary = b.subsidiary,
           pe_amount = b.pe_amount,
           revenu_usd = b.revenu_usd,
           po_orderid = b.po_orderid,
           pay_action = b.pay_action,
           pay_result = b.pay_result,
           pay_description = b.pay_description,
           pay_message = b.pay_message,
           po_internal_status = b.po_internal_status,
           po_payment_type = b.po_payment_type,
           po_paymentprovider = b.po_paymentprovider,
           payment_card_brand = b.payment_card_brand,
           po_status_ct = b.po_status_ct,
           funnel_status = b.funnel_status,
           updated_timestamp = CURRENT_TIMESTAMP,
           PAY_GATEWAY_STATUS = b.PAY_GATEWAY_STATUS,
           PO_PAYMENT_TYPE_STATUS = b.PO_PAYMENT_TYPE_STATUS,
           PO_PLATAFORM_DATASOURCE = b.PO_PLATAFORM_DATASOURCE,
           datasource_origin_timestamp = b.datasource_origin_timestamp
    WHEN NOT MATCHED THEN INSERT (
           po_date,
           po_month,
           po_year,
           po_hour,
           pay_subsidiary,
           pay_code,
           pay_id,
           pay_date,
           pay_month,
           pay_year,
           pay_hour,
           pay_status,
           pay_detail,
           pay_gateway_code,
           payment_type,
           pay_gateway,
           revenue_local,
           pay_orderid,
           pay_storename,
           postoretype,
           po_devicetype,
           po_status,
           order_status_type,
           currency,
           po_order_lastmodifydate,
           postorename,
           channel,
           biz_type,
           audience_type,
           subsidiary,
           pe_amount,
           revenu_usd,
           po_orderid,
           pay_action,
           pay_result,
           pay_description,
           pay_message,
           po_internal_status,
           po_payment_type,
           po_paymentprovider,
           payment_card_brand,
           po_status_ct,
           funnel_status,
           PAY_GATEWAY_STATUS,
           PO_PAYMENT_TYPE_STATUS,
           PO_PLATAFORM_DATASOURCE,
           datasource_origin_timestamp
    ) VALUES (
           b.po_date,
           b.po_month,
           b.po_year,
           b.po_hour,
           b.pay_subsidiary,
           b.pay_code,
           b.pay_id,
           b.pay_date,
           b.pay_month,
           b.pay_year,
           b.pay_hour,
           b.pay_status,
           b.pay_detail,
           b.pay_gateway_code,
           b.payment_type,
           b.pay_gateway,
           b.revenue_local,
           b.pay_orderid,
           b.pay_storename,
           b.postoretype,
           b.po_devicetype,
           b.po_status,
           b.order_status_type,
           b.currency,
           b.po_order_lastmodifydate,
           b.postorename,
           b.channel,
           b.biz_type,
           b.audience_type,
           b.subsidiary,
           b.pe_amount,
           b.revenu_usd,
           b.po_orderid,
           b.pay_action,
           b.pay_result,
           b.pay_description,
           b.pay_message,
           b.po_internal_status,
           b.po_payment_type,
           b.po_paymentprovider,
           b.payment_card_brand,
           b.po_status_ct,
           b.funnel_status,
           b.PAY_GATEWAY_STATUS,
           b.PO_PAYMENT_TYPE_STATUS,
           b.PO_PLATAFORM_DATASOURCE,
           b.datasource_origin_timestamp
    );
END;
$$;

-- CALL ow_lao.proc_ods_sales_payments_grafana_details();
-- ERROR: Severity: ERROR, Message: Function DATEADD(unknown, int, date) does not exist, or permission is denied for DATEADD(unknown, int, date), Sqlstate: 42883, Hint: No function matches the given name and argument types. You may need to add explicit type casts, Where: PL/vSQL procedure proc_ods_sales_payments_grafana_details line 97 at static SQL, Routine: throwErrorFunctionDoesNotMatch, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/ParseFunc.cpp, Line: 4559, Error Code: 3457, 
-- CALL ow_lao.proc_ods_sales_payments_grafana_details();
-- ERROR: Severity: ERROR, Message: Function DATEADD(unknown, int, date) does not exist, or permission is denied for DATEADD(unknown, int, date), Sqlstate: 42883, Hint: No function matches the given name and argument types. You may need to add explicit type casts, Where: PL/vSQL procedure proc_ods_sales_payments_grafana_details line 97 at static SQL, Routine: throwErrorFunctionDoesNotMatch, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/ParseFunc.cpp, Line: 4559, Error Code: 3457, 
CREATE OR REPLACE PROCEDURE ow_lao.proc_ods_sales_payments_grafana_details()
LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM TRUNCATE TABLE ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS;

    PERFORM INSERT INTO ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS
    SELECT 
          a.inserted_timestamp AS insert_timestamp
        , CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_created_date)) AS DATE) AS po_date
        , EXTRACT(MONTH FROM CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_created_date)) AS DATE)) AS po_month
        , EXTRACT(YEAR  FROM CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_created_date)) AS DATE)) AS po_year
        , EXTRACT(HOUR  FROM TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_created_date))) AS po_hour
        , a.tenant AS pay_subsidiary
        , a.pe_code AS pay_code
        , a.paymentid AS pay_id
        , CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.pe_time)) AS DATE) AS pay_date
        , EXTRACT(MONTH FROM CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.pe_time)) AS DATE)) AS pay_month
        , EXTRACT(YEAR  FROM CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.pe_time)) AS DATE)) AS pay_year
        , EXTRACT(HOUR  FROM TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.pe_time))) AS pay_hour
        , COALESCE(a.pe_status, '') AS pay_status
        , a.pe_status_detail AS pay_detail
        , a.payment_code AS pay_gateway_code
        , a.payment_mode AS payment_type
        , a.payment_provider AS pay_gateway
        , a.pe_amount AS revenue_local
        , SUBSTR(a.orderid,1,17) AS pay_orderid
        , c.site AS pay_storename
        , a.isbasestore AS postoretype
        , a.sales_application AS po_devicetype
        , COALESCE(a.order_status, '') AS po_status
        , a.order_type AS order_status_type
        , a.order_currency AS currency
        , CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_modified_date)) AS TIMESTAMP) AS po_order_lastmodifydate
        , d.affiliate_id AS postorename
        , d.global_channel AS channel
        , d.biz_type AS biz_type
        , d.audience_type AS audience_type
        , d.sales_org AS subsidiary
        , a.pe_amount AS pe_amount
        , CAST(NULL AS DECIMAL) AS revenu_usd
        , CAST('' AS VARCHAR(255)) AS po_orderid
        , CAST('' AS VARCHAR(255)) AS pay_action
        , CAST('' AS VARCHAR(255)) AS pay_result
        , CAST('' AS VARCHAR(1000)) AS pay_description
        , CAST('' AS VARCHAR(255)) AS pay_message
        , CAST('' AS VARCHAR(255)) AS po_internal_status
        , CAST('' AS VARCHAR(255)) AS po_payment_type
        , CAST('' AS VARCHAR(255)) AS po_paymentprovider
        , CAST('' AS VARCHAR(255)) AS payment_card_brand
        , CAST('' AS VARCHAR(255)) AS po_status_ct
        , CAST(NULL AS VARCHAR(255)) AS funnel_status
        , SUBSTR(a.orderid,1,17) AS orderid_log
        , ROW_NUMBER() OVER(
            PARTITION BY a.tenant, c.site, SUBSTR(a.orderid,1,17)
            ORDER BY CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_modified_date)) AS TIMESTAMP) DESC
          ) AS dedup
        , CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_modified_date)) AS TIMESTAMP) AS datasource_origin_timestamp
        , 'GRAFANA_HYBRIS' AS PO_PLATAFORM_DATASOURCE
        , CAST(NULL AS VARCHAR(255)) AS PAY_GATEWAY_STATUS
        , CAST(NULL AS VARCHAR(255)) AS PO_PAYMENT_TYPE_STATUS
    FROM ow_lao.raw_grafana_document_payments_details a
    JOIN u_prj_ecom.dim_subsidiary b
      ON LOWER(b.country_code) = LOWER(a.tenant)
    JOIN ow_lao.ods_hybris_sales c
      ON SUBSTR(c.order_code,1,17) = SUBSTR(a.orderid,1,17)
    JOIN ow_md.sales_channel d
      ON LOWER(d.country) = LOWER(b.country)
     AND LOWER(d.identifier) = LOWER(c.site)
    WHERE NOT EXISTS (
            SELECT 1
            FROM ow_lao.ods_payment_funnel aa
            WHERE SUBSTR(a.orderid,1,17) = SUBSTR(aa.pay_orderid,1,17)
              AND a.tenant = aa.pay_subsidiary
              AND CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_modified_date)) AS TIMESTAMP) <= aa.datasource_origin_timestamp
          )
      AND b.order_apply_timezone = 1
      AND CAST(a.inserted_timestamp AS DATE) >= DATE '2025-04-13';

    PERFORM DELETE FROM ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS
     WHERE dedup <> 1;

    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS a
       SET po_internal_status = b.order_status,
           po_payment_type    = b.payment_mode,
           po_paymentprovider = b.payment_provider,
           payment_card_brand = b.payment_mode_creditcardtype
      FROM ow_lao.ods_hybris_sales b
     WHERE SUBSTR(b.order_code,1,17) = SUBSTR(a.pay_orderid,1,17);

    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS a
       SET po_orderid      = b.orderid,
           pay_action      = b.action,
           pay_description = b.description,
           pay_message     = b.message
      FROM ow_lao.raw_grafana_document_log_payments_details b
     WHERE SUBSTR(b.orderid,1,17) = a.orderid_log;

    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS a
       SET revenu_usd = a.pe_amount / CAST(b.exchange_rate AS DECIMAL)
      FROM ow_lao.ft_ap2_exchange_rate b
     WHERE CAST(b.valid_from AS DATE) = CAST(TIMESTAMPADD(DAY, -1, a.po_date) AS DATE)
       AND LOWER(b.to_currency) = LOWER(a.currency);

    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS a
       SET po_status_ct = b.status
      FROM ow_lao.dim_ods_sales_control_tower_table_status_mapping b
     WHERE b.status_origin = a.po_internal_status;

    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS a
       SET funnel_status = b.status
      FROM ow_lao.DIM_PAYMENT_FUNNEL_STATUS_MAPPING b
     WHERE b.pay_status = a.pay_status
       AND b.po_status = a.po_status
       AND b.pay_description = a.pay_description
       AND b.data_source = a.po_plataform_datasource
       AND b.active = TRUE;

    PERFORM UPDATE ow_lao.tmp_sales_payments_grafana_details a
       SET pay_gateway_status = b.gateway
      FROM ow_lao.dim_payment_pay_gateway_mapping b
     WHERE b.data_source = a.po_plataform_datasource
       AND b.pay_gateway = a.pay_gateway
       AND b.active = TRUE;

    PERFORM UPDATE ow_lao.tmp_sales_payments_grafana_details a
       SET po_payment_type_status = b.payment_mode
      FROM ow_lao.dim_payment_type_mapping b
     WHERE b.data_source = a.po_plataform_datasource
       AND b.payment_type = a.payment_type
       AND b.active = TRUE;

    PERFORM MERGE INTO ow_lao.ods_payment_funnel a
    USING ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS b
       ON SUBSTR(b.pay_orderid,1,17) = SUBSTR(a.pay_orderid,1,17)
      AND b.pay_subsidiary = a.pay_subsidiary
    WHEN MATCHED THEN UPDATE SET
           po_date = b.po_date,
           po_month = b.po_month,
           po_year = b.po_year,
           po_hour = b.po_hour,
           pay_subsidiary = b.pay_subsidiary,
           pay_code = b.pay_code,
           pay_id = b.pay_id,
           pay_date = b.pay_date,
           pay_month = b.pay_month,
           pay_year = b.pay_year,
           pay_hour = b.pay_hour,
           pay_status = b.pay_status,
           pay_detail = b.pay_detail,
           pay_gateway_code = b.pay_gateway_code,
           payment_type = b.payment_type,
           pay_gateway = b.pay_gateway,
           revenue_local = b.revenue_local,
           pay_orderid = b.pay_orderid,
           pay_storename = b.pay_storename,
           postoretype = b.postoretype,
           po_devicetype = b.po_devicetype,
           po_status = b.po_status,
           order_status_type = b.order_status_type,
           currency = b.currency,
           po_order_lastmodifydate = b.po_order_lastmodifydate,
           postorename = b.postorename,
           channel = b.channel,
           biz_type = b.biz_type,
           audience_type = b.audience_type,
           subsidiary = b.subsidiary,
           pe_amount = b.pe_amount,
           revenu_usd = b.revenu_usd,
           po_orderid = b.po_orderid,
           pay_action = b.pay_action,
           pay_result = b.pay_result,
           pay_description = b.pay_description,
           pay_message = b.pay_message,
           po_internal_status = b.po_internal_status,
           po_payment_type = b.po_payment_type,
           po_paymentprovider = b.po_paymentprovider,
           payment_card_brand = b.payment_card_brand,
           po_status_ct = b.po_status_ct,
           funnel_status = b.funnel_status,
           updated_timestamp = CURRENT_TIMESTAMP,
           PAY_GATEWAY_STATUS = b.PAY_GATEWAY_STATUS,
           PO_PAYMENT_TYPE_STATUS = b.PO_PAYMENT_TYPE_STATUS,
           PO_PLATAFORM_DATASOURCE = b.PO_PLATAFORM_DATASOURCE,
           datasource_origin_timestamp = b.datasource_origin_timestamp
    WHEN NOT MATCHED THEN INSERT (
           po_date,
           po_month,
           po_year,
           po_hour,
           pay_subsidiary,
           pay_code,
           pay_id,
           pay_date,
           pay_month,
           pay_year,
           pay_hour,
           pay_status,
           pay_detail,
           pay_gateway_code,
           payment_type,
           pay_gateway,
           revenue_local,
           pay_orderid,
           pay_storename,
           postoretype,
           po_devicetype,
           po_status,
           order_status_type,
           currency,
           po_order_lastmodifydate,
           postorename,
           channel,
           biz_type,
           audience_type,
           subsidiary,
           pe_amount,
           revenu_usd,
           po_orderid,
           pay_action,
           pay_result,
           pay_description,
           pay_message,
           po_internal_status,
           po_payment_type,
           po_paymentprovider,
           payment_card_brand,
           po_status_ct,
           funnel_status,
           PAY_GATEWAY_STATUS,
           PO_PAYMENT_TYPE_STATUS,
           PO_PLATAFORM_DATASOURCE,
           datasource_origin_timestamp
    ) VALUES (
           b.po_date,
           b.po_month,
           b.po_year,
           b.po_hour,
           b.pay_subsidiary,
           b.pay_code,
           b.pay_id,
           b.pay_date,
           b.pay_month,
           b.pay_year,
           b.pay_hour,
           b.pay_status,
           b.pay_detail,
           b.pay_gateway_code,
           b.payment_type,
           b.pay_gateway,
           b.revenue_local,
           b.pay_orderid,
           b.pay_storename,
           b.postoretype,
           b.po_devicetype,
           b.po_status,
           b.order_status_type,
           b.currency,
           b.po_order_lastmodifydate,
           b.postorename,
           b.channel,
           b.biz_type,
           b.audience_type,
           b.subsidiary,
           b.pe_amount,
           b.revenu_usd,
           b.po_orderid,
           b.pay_action,
           b.pay_result,
           b.pay_description,
           b.pay_message,
           b.po_internal_status,
           b.po_payment_type,
           b.po_paymentprovider,
           b.payment_card_brand,
           b.po_status_ct,
           b.funnel_status,
           b.PAY_GATEWAY_STATUS,
           b.PO_PAYMENT_TYPE_STATUS,
           b.PO_PLATAFORM_DATASOURCE,
           b.datasource_origin_timestamp
    );
END;
$$;

-- CALL ow_lao.proc_ods_sales_payments_grafana_details();
-- ERROR: Severity: ERROR, Message: Cannot set a NOT NULL column (ID) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure proc_ods_sales_payments_grafana_details line 131 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3216, Error Code: 2502, 
-- CALL ow_lao.proc_ods_sales_payments_grafana_details();
-- ERROR: Severity: ERROR, Message: Cannot set a NOT NULL column (ID) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure proc_ods_sales_payments_grafana_details line 131 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3216, Error Code: 2502, 
SELECT column_name, data_type, is_nullable, column_default FROM v_catalog.columns WHERE table_schema='ow_lao' AND table_name='ods_payment_funnel' ORDER BY ordinal_position;
-- column_name | data_type | is_nullable | column_default
-- ------------+-----------+-------------+---------------

SELECT * FROM ow_lao.ods_payment_funnel LIMIT 0;
-- ID | INSERT_TIMESTAMP | UPDATED_TIMESTAMP | PO_DATE | PO_MONTH | PO_YEAR | PO_HOUR | PAY_SUBSIDIARY | PAY_CODE | PAY_ID | PAY_DATE | PAY_MONTH | PAY_YEAR | PAY_HOUR | PAY_STATUS | PAY_DETAIL | PAY_GATEWAY_CODE | PAYMENT_TYPE | PAY_GATEWAY | REVENUE_LOCAL | PAY_ORDERID | PAY_STORENAME | POSTORETYPE | PO_DEVICETYPE | PO_STATUS | ORDER_STATUS_TYPE | CURRENCY | PO_ORDER_LASTMODIFYDATE | POSTORENAME | CHANNEL | BIZ_TYPE | AUDIENCE_TYPE | SUBSIDIARY | PE_AMOUNT | REVENU_USD | PO_ORDERID | PAY_ACTION | PAY_RESULT | PAY_DESCRIPTION | PAY_MESSAGE | PO_INTERNAL_STATUS | PO_PAYMENT_TYPE | PO_PAYMENTPROVIDER | PAYMENT_CARD_BRAND | PO_STATUS_CT | FUNNEL_STATUS | DATASOURCE_ORIGIN_TIMESTAMP | PO_PLATAFORM_DATASOURCE | PAY_GATEWAY_STATUS | PO_PAYMENT_TYPE_STATUS
-- ---+------------------+-------------------+---------+----------+---------+---------+----------------+----------+--------+----------+-----------+----------+----------+------------+------------+------------------+--------------+-------------+---------------+-------------+---------------+-------------+---------------+-----------+-------------------+----------+-------------------------+-------------+---------+----------+---------------+------------+-----------+------------+------------+------------+------------+-----------------+-------------+--------------------+-----------------+--------------------+--------------------+--------------+---------------+-----------------------------+-------------------------+--------------------+-----------------------

SELECT table_schema, table_name FROM v_catalog.tables WHERE table_name ILIKE 'ods_payment_funnel';
-- table_schema | table_name
-- -------------+-----------
-- OW_LAO | ODS_PAYMENT_FUNNEL

SELECT table_schema, table_name FROM v_catalog.views WHERE table_name ILIKE 'ods_payment_funnel';
-- table_schema | table_name
-- -------------+-----------

SELECT column_name, data_type, is_nullable FROM v_catalog.columns WHERE table_schema='ow_lao' AND table_name='TMP_SALES_PAYMENTS_GRAFANA_DETAILS' ORDER BY ordinal_position;
-- column_name | data_type | is_nullable
-- ------------+-----------+------------

CREATE OR REPLACE PROCEDURE ow_lao.proc_ods_sales_payments_grafana_details()
LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM TRUNCATE TABLE ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS;

    PERFORM INSERT INTO ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS
    SELECT 
          a.inserted_timestamp AS insert_timestamp
        , CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_created_date)) AS DATE) AS po_date
        , EXTRACT(MONTH FROM CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_created_date)) AS DATE)) AS po_month
        , EXTRACT(YEAR  FROM CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_created_date)) AS DATE)) AS po_year
        , EXTRACT(HOUR  FROM TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_created_date))) AS po_hour
        , a.tenant AS pay_subsidiary
        , a.pe_code AS pay_code
        , a.paymentid AS pay_id
        , CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.pe_time)) AS DATE) AS pay_date
        , EXTRACT(MONTH FROM CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.pe_time)) AS DATE)) AS pay_month
        , EXTRACT(YEAR  FROM CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.pe_time)) AS DATE)) AS pay_year
        , EXTRACT(HOUR  FROM TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.pe_time))) AS pay_hour
        , COALESCE(a.pe_status, '') AS pay_status
        , a.pe_status_detail AS pay_detail
        , a.payment_code AS pay_gateway_code
        , a.payment_mode AS payment_type
        , a.payment_provider AS pay_gateway
        , a.pe_amount AS revenue_local
        , SUBSTR(a.orderid,1,17) AS pay_orderid
        , c.site AS pay_storename
        , a.isbasestore AS postoretype
        , a.sales_application AS po_devicetype
        , COALESCE(a.order_status, '') AS po_status
        , a.order_type AS order_status_type
        , a.order_currency AS currency
        , CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_modified_date)) AS TIMESTAMP) AS po_order_lastmodifydate
        , d.affiliate_id AS postorename
        , d.global_channel AS channel
        , d.biz_type AS biz_type
        , d.audience_type AS audience_type
        , d.sales_org AS subsidiary
        , a.pe_amount AS pe_amount
        , CAST(NULL AS DECIMAL) AS revenu_usd
        , CAST('' AS VARCHAR(255)) AS po_orderid
        , CAST('' AS VARCHAR(255)) AS pay_action
        , CAST('' AS VARCHAR(255)) AS pay_result
        , CAST('' AS VARCHAR(1000)) AS pay_description
        , CAST('' AS VARCHAR(255)) AS pay_message
        , CAST('' AS VARCHAR(255)) AS po_internal_status
        , CAST('' AS VARCHAR(255)) AS po_payment_type
        , CAST('' AS VARCHAR(255)) AS po_paymentprovider
        , CAST('' AS VARCHAR(255)) AS payment_card_brand
        , CAST('' AS VARCHAR(255)) AS po_status_ct
        , CAST(NULL AS VARCHAR(255)) AS funnel_status
        , SUBSTR(a.orderid,1,17) AS orderid_log
        , ROW_NUMBER() OVER(
            PARTITION BY a.tenant, c.site, SUBSTR(a.orderid,1,17)
            ORDER BY CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_modified_date)) AS TIMESTAMP) DESC
          ) AS dedup
        , CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_modified_date)) AS TIMESTAMP) AS datasource_origin_timestamp
        , 'GRAFANA_HYBRIS' AS PO_PLATAFORM_DATASOURCE
        , CAST(NULL AS VARCHAR(255)) AS PAY_GATEWAY_STATUS
        , CAST(NULL AS VARCHAR(255)) AS PO_PAYMENT_TYPE_STATUS
    FROM ow_lao.raw_grafana_document_payments_details a
    JOIN u_prj_ecom.dim_subsidiary b
      ON LOWER(b.country_code) = LOWER(a.tenant)
    JOIN ow_lao.ods_hybris_sales c
      ON SUBSTR(c.order_code,1,17) = SUBSTR(a.orderid,1,17)
    JOIN ow_md.sales_channel d
      ON LOWER(d.country) = LOWER(b.country)
     AND LOWER(d.identifier) = LOWER(c.site)
    WHERE NOT EXISTS (
            SELECT 1
            FROM ow_lao.ods_payment_funnel aa
            WHERE SUBSTR(a.orderid,1,17) = SUBSTR(aa.pay_orderid,1,17)
              AND a.tenant = aa.pay_subsidiary
              AND CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_modified_date)) AS TIMESTAMP) <= aa.datasource_origin_timestamp
          )
      AND b.order_apply_timezone = 1
      AND CAST(a.inserted_timestamp AS DATE) >= DATE '2025-04-13';

    PERFORM DELETE FROM ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS
     WHERE dedup <> 1;

    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS a
       SET po_internal_status = b.order_status,
           po_payment_type    = b.payment_mode,
           po_paymentprovider = b.payment_provider,
           payment_card_brand = b.payment_mode_creditcardtype
      FROM ow_lao.ods_hybris_sales b
     WHERE SUBSTR(b.order_code,1,17) = SUBSTR(a.pay_orderid,1,17);

    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS a
       SET po_orderid      = b.orderid,
           pay_action      = b.action,
           pay_description = b.description,
           pay_message     = b.message
      FROM ow_lao.raw_grafana_document_log_payments_details b
     WHERE SUBSTR(b.orderid,1,17) = a.orderid_log;

    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS a
       SET revenu_usd = a.pe_amount / CAST(b.exchange_rate AS DECIMAL)
      FROM ow_lao.ft_ap2_exchange_rate b
     WHERE CAST(b.valid_from AS DATE) = CAST(TIMESTAMPADD(DAY, -1, a.po_date) AS DATE)
       AND LOWER(b.to_currency) = LOWER(a.currency);

    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS a
       SET po_status_ct = b.status
      FROM ow_lao.dim_ods_sales_control_tower_table_status_mapping b
     WHERE b.status_origin = a.po_internal_status;

    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS a
       SET funnel_status = b.status
      FROM ow_lao.DIM_PAYMENT_FUNNEL_STATUS_MAPPING b
     WHERE b.pay_status = a.pay_status
       AND b.po_status = a.po_status
       AND b.pay_description = a.pay_description
       AND b.data_source = a.po_plataform_datasource
       AND b.active = TRUE;

    PERFORM UPDATE ow_lao.tmp_sales_payments_grafana_details a
       SET pay_gateway_status = b.gateway
      FROM ow_lao.dim_payment_pay_gateway_mapping b
     WHERE b.data_source = a.po_plataform_datasource
       AND b.pay_gateway = a.pay_gateway
       AND b.active = TRUE;

    PERFORM UPDATE ow_lao.tmp_sales_payments_grafana_details a
       SET po_payment_type_status = b.payment_mode
      FROM ow_lao.dim_payment_type_mapping b
     WHERE b.data_source = a.po_plataform_datasource
       AND b.payment_type = a.payment_type
       AND b.active = TRUE;

    PERFORM MERGE INTO ow_lao.ods_payment_funnel a
    USING ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS b
       ON SUBSTR(b.pay_orderid,1,17) = SUBSTR(a.pay_orderid,1,17)
      AND b.pay_subsidiary = a.pay_subsidiary
    WHEN MATCHED THEN UPDATE SET
           po_date = b.po_date,
           po_month = b.po_month,
           po_year = b.po_year,
           po_hour = b.po_hour,
           pay_subsidiary = b.pay_subsidiary,
           pay_code = b.pay_code,
           pay_id = b.pay_id,
           pay_date = b.pay_date,
           pay_month = b.pay_month,
           pay_year = b.pay_year,
           pay_hour = b.pay_hour,
           pay_status = b.pay_status,
           pay_detail = b.pay_detail,
           pay_gateway_code = b.pay_gateway_code,
           payment_type = b.payment_type,
           pay_gateway = b.pay_gateway,
           revenue_local = b.revenue_local,
           pay_orderid = b.pay_orderid,
           pay_storename = b.pay_storename,
           postoretype = b.postoretype,
           po_devicetype = b.po_devicetype,
           po_status = b.po_status,
           order_status_type = b.order_status_type,
           currency = b.currency,
           po_order_lastmodifydate = b.po_order_lastmodifydate,
           postorename = b.postorename,
           channel = b.channel,
           biz_type = b.biz_type,
           audience_type = b.audience_type,
           subsidiary = b.subsidiary,
           pe_amount = b.pe_amount,
           revenu_usd = b.revenu_usd,
           po_orderid = b.po_orderid,
           pay_action = b.pay_action,
           pay_result = b.pay_result,
           pay_description = b.pay_description,
           pay_message = b.pay_message,
           po_internal_status = b.po_internal_status,
           po_payment_type = b.po_payment_type,
           po_paymentprovider = b.po_paymentprovider,
           payment_card_brand = b.payment_card_brand,
           po_status_ct = b.po_status_ct,
           funnel_status = b.funnel_status,
           updated_timestamp = CURRENT_TIMESTAMP,
           PAY_GATEWAY_STATUS = b.PAY_GATEWAY_STATUS,
           PO_PAYMENT_TYPE_STATUS = b.PO_PAYMENT_TYPE_STATUS,
           PO_PLATAFORM_DATASOURCE = b.PO_PLATAFORM_DATASOURCE,
           datasource_origin_timestamp = b.datasource_origin_timestamp
    WHEN NOT MATCHED THEN INSERT (
           id,
           insert_timestamp,
           po_date,
           po_month,
           po_year,
           po_hour,
           pay_subsidiary,
           pay_code,
           pay_id,
           pay_date,
           pay_month,
           pay_year,
           pay_hour,
           pay_status,
           pay_detail,
           pay_gateway_code,
           payment_type,
           pay_gateway,
           revenue_local,
           pay_orderid,
           pay_storename,
           postoretype,
           po_devicetype,
           po_status,
           order_status_type,
           currency,
           po_order_lastmodifydate,
           postorename,
           channel,
           biz_type,
           audience_type,
           subsidiary,
           pe_amount,
           revenu_usd,
           po_orderid,
           pay_action,
           pay_result,
           pay_description,
           pay_message,
           po_internal_status,
           po_payment_type,
           po_paymentprovider,
           payment_card_brand,
           po_status_ct,
           funnel_status,
           PAY_GATEWAY_STATUS,
           PO_PAYMENT_TYPE_STATUS,
           PO_PLATAFORM_DATASOURCE,
           datasource_origin_timestamp
    ) VALUES (
           b.pay_subsidiary || '|' || b.pay_orderid,
           b.insert_timestamp,
           b.po_date,
           b.po_month,
           b.po_year,
           b.po_hour,
           b.pay_subsidiary,
           b.pay_code,
           b.pay_id,
           b.pay_date,
           b.pay_month,
           b.pay_year,
           b.pay_hour,
           b.pay_status,
           b.pay_detail,
           b.pay_gateway_code,
           b.payment_type,
           b.pay_gateway,
           b.revenue_local,
           b.pay_orderid,
           b.pay_storename,
           b.postoretype,
           b.po_devicetype,
           b.po_status,
           b.order_status_type,
           b.currency,
           b.po_order_lastmodifydate,
           b.postorename,
           b.channel,
           b.biz_type,
           b.audience_type,
           b.subsidiary,
           b.pe_amount,
           b.revenu_usd,
           b.po_orderid,
           b.pay_action,
           b.pay_result,
           b.pay_description,
           b.pay_message,
           b.po_internal_status,
           b.po_payment_type,
           b.po_paymentprovider,
           b.payment_card_brand,
           b.po_status_ct,
           b.funnel_status,
           b.PAY_GATEWAY_STATUS,
           b.PO_PAYMENT_TYPE_STATUS,
           b.PO_PLATAFORM_DATASOURCE,
           b.datasource_origin_timestamp
    );
END;
$$;

-- CALL ow_lao.proc_ods_sales_payments_grafana_details();
-- ERROR: Severity: ERROR, Message: Column "id" is of type int but expression is of type varchar, Sqlstate: 42804, Hint: You will need to rewrite or cast the expression, Where: PL/vSQL procedure proc_ods_sales_payments_grafana_details line 131 at static SQL, Routine: updateTargetListEntry, File: parse_target.c, Line: 853, Error Code: 2631, 
-- CALL ow_lao.proc_ods_sales_payments_grafana_details();
-- ERROR: Severity: ERROR, Message: Column "id" is of type int but expression is of type varchar, Sqlstate: 42804, Hint: You will need to rewrite or cast the expression, Where: PL/vSQL procedure proc_ods_sales_payments_grafana_details line 131 at static SQL, Routine: updateTargetListEntry, File: parse_target.c, Line: 853, Error Code: 2631, 
SELECT HASH('abc')
-- HASH
-- ----
-- 1193732203864995963

CREATE OR REPLACE PROCEDURE ow_lao.proc_ods_sales_payments_grafana_details()
LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM TRUNCATE TABLE ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS;

    PERFORM INSERT INTO ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS
    SELECT 
          a.inserted_timestamp AS insert_timestamp
        , CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_created_date)) AS DATE) AS po_date
        , EXTRACT(MONTH FROM CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_created_date)) AS DATE)) AS po_month
        , EXTRACT(YEAR  FROM CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_created_date)) AS DATE)) AS po_year
        , EXTRACT(HOUR  FROM TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_created_date))) AS po_hour
        , a.tenant AS pay_subsidiary
        , a.pe_code AS pay_code
        , a.paymentid AS pay_id
        , CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.pe_time)) AS DATE) AS pay_date
        , EXTRACT(MONTH FROM CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.pe_time)) AS DATE)) AS pay_month
        , EXTRACT(YEAR  FROM CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.pe_time)) AS DATE)) AS pay_year
        , EXTRACT(HOUR  FROM TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.pe_time))) AS pay_hour
        , COALESCE(a.pe_status, '') AS pay_status
        , a.pe_status_detail AS pay_detail
        , a.payment_code AS pay_gateway_code
        , a.payment_mode AS payment_type
        , a.payment_provider AS pay_gateway
        , a.pe_amount AS revenue_local
        , SUBSTR(a.orderid,1,17) AS pay_orderid
        , c.site AS pay_storename
        , a.isbasestore AS postoretype
        , a.sales_application AS po_devicetype
        , COALESCE(a.order_status, '') AS po_status
        , a.order_type AS order_status_type
        , a.order_currency AS currency
        , CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_modified_date)) AS TIMESTAMP) AS po_order_lastmodifydate
        , d.affiliate_id AS postorename
        , d.global_channel AS channel
        , d.biz_type AS biz_type
        , d.audience_type AS audience_type
        , d.sales_org AS subsidiary
        , a.pe_amount AS pe_amount
        , CAST(NULL AS DECIMAL) AS revenu_usd
        , CAST('' AS VARCHAR(255)) AS po_orderid
        , CAST('' AS VARCHAR(255)) AS pay_action
        , CAST('' AS VARCHAR(255)) AS pay_result
        , CAST('' AS VARCHAR(1000)) AS pay_description
        , CAST('' AS VARCHAR(255)) AS pay_message
        , CAST('' AS VARCHAR(255)) AS po_internal_status
        , CAST('' AS VARCHAR(255)) AS po_payment_type
        , CAST('' AS VARCHAR(255)) AS po_paymentprovider
        , CAST('' AS VARCHAR(255)) AS payment_card_brand
        , CAST('' AS VARCHAR(255)) AS po_status_ct
        , CAST(NULL AS VARCHAR(255)) AS funnel_status
        , SUBSTR(a.orderid,1,17) AS orderid_log
        , ROW_NUMBER() OVER(
            PARTITION BY a.tenant, c.site, SUBSTR(a.orderid,1,17)
            ORDER BY CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_modified_date)) AS TIMESTAMP) DESC
          ) AS dedup
        , CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_modified_date)) AS TIMESTAMP) AS datasource_origin_timestamp
        , 'GRAFANA_HYBRIS' AS PO_PLATAFORM_DATASOURCE
        , CAST(NULL AS VARCHAR(255)) AS PAY_GATEWAY_STATUS
        , CAST(NULL AS VARCHAR(255)) AS PO_PAYMENT_TYPE_STATUS
    FROM ow_lao.raw_grafana_document_payments_details a
    JOIN u_prj_ecom.dim_subsidiary b
      ON LOWER(b.country_code) = LOWER(a.tenant)
    JOIN ow_lao.ods_hybris_sales c
      ON SUBSTR(c.order_code,1,17) = SUBSTR(a.orderid,1,17)
    JOIN ow_md.sales_channel d
      ON LOWER(d.country) = LOWER(b.country)
     AND LOWER(d.identifier) = LOWER(c.site)
    WHERE NOT EXISTS (
            SELECT 1
            FROM ow_lao.ods_payment_funnel aa
            WHERE SUBSTR(a.orderid,1,17) = SUBSTR(aa.pay_orderid,1,17)
              AND a.tenant = aa.pay_subsidiary
              AND CAST(TIMESTAMPADD(SECOND, (b.timezone * 60) * 60, TO_TIMESTAMP(a.order_modified_date)) AS TIMESTAMP) <= aa.datasource_origin_timestamp
          )
      AND b.order_apply_timezone = 1
      AND CAST(a.inserted_timestamp AS DATE) >= DATE '2025-04-13';

    PERFORM DELETE FROM ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS
     WHERE dedup <> 1;

    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS a
       SET po_internal_status = b.order_status,
           po_payment_type    = b.payment_mode,
           po_paymentprovider = b.payment_provider,
           payment_card_brand = b.payment_mode_creditcardtype
      FROM ow_lao.ods_hybris_sales b
     WHERE SUBSTR(b.order_code,1,17) = SUBSTR(a.pay_orderid,1,17);

    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS a
       SET po_orderid      = b.orderid,
           pay_action      = b.action,
           pay_description = b.description,
           pay_message     = b.message
      FROM ow_lao.raw_grafana_document_log_payments_details b
     WHERE SUBSTR(b.orderid,1,17) = a.orderid_log;

    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS a
       SET revenu_usd = a.pe_amount / CAST(b.exchange_rate AS DECIMAL)
      FROM ow_lao.ft_ap2_exchange_rate b
     WHERE CAST(b.valid_from AS DATE) = (CAST(a.po_date AS DATE) - INTERVAL '1 day')::DATE
       AND LOWER(b.to_currency) = LOWER(a.currency);

    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS a
       SET po_status_ct = b.status
      FROM ow_lao.dim_ods_sales_control_tower_table_status_mapping b
     WHERE b.status_origin = a.po_internal_status;

    PERFORM UPDATE ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS a
       SET funnel_status = b.status
      FROM ow_lao.DIM_PAYMENT_FUNNEL_STATUS_MAPPING b
     WHERE b.pay_status = a.pay_status
       AND b.po_status = a.po_status
       AND b.pay_description = a.pay_description
       AND b.data_source = a.po_plataform_datasource
       AND b.active = TRUE;

    PERFORM UPDATE ow_lao.tmp_sales_payments_grafana_details a
       SET pay_gateway_status = b.gateway
      FROM ow_lao.dim_payment_pay_gateway_mapping b
     WHERE b.data_source = a.po_plataform_datasource
       AND b.pay_gateway = a.pay_gateway
       AND b.active = TRUE;

    PERFORM UPDATE ow_lao.tmp_sales_payments_grafana_details a
       SET po_payment_type_status = b.payment_mode
      FROM ow_lao.dim_payment_type_mapping b
     WHERE b.data_source = a.po_plataform_datasource
       AND b.payment_type = a.payment_type
       AND b.active = TRUE;

    PERFORM MERGE INTO ow_lao.ods_payment_funnel a
    USING ow_lao.TMP_SALES_PAYMENTS_GRAFANA_DETAILS b
       ON SUBSTR(b.pay_orderid,1,17) = SUBSTR(a.pay_orderid,1,17)
      AND b.pay_subsidiary = a.pay_subsidiary
    WHEN MATCHED THEN UPDATE SET
           po_date = b.po_date,
           po_month = b.po_month,
           po_year = b.po_year,
           po_hour = b.po_hour,
           pay_subsidiary = b.pay_subsidiary,
           pay_code = b.pay_code,
           pay_id = b.pay_id,
           pay_date = b.pay_date,
           pay_month = b.pay_month,
           pay_year = b.pay_year,
           pay_hour = b.pay_hour,
           pay_status = b.pay_status,
           pay_detail = b.pay_detail,
           pay_gateway_code = b.pay_gateway_code,
           payment_type = b.payment_type,
           pay_gateway = b.pay_gateway,
           revenue_local = b.revenue_local,
           pay_orderid = b.pay_orderid,
           pay_storename = b.pay_storename,
           postoretype = b.postoretype,
           po_devicetype = b.po_devicetype,
           po_status = b.po_status,
           order_status_type = b.order_status_type,
           currency = b.currency,
           po_order_lastmodifydate = b.po_order_lastmodifydate,
           postorename = b.postorename,
           channel = b.channel,
           biz_type = b.biz_type,
           audience_type = b.audience_type,
           subsidiary = b.subsidiary,
           pe_amount = b.pe_amount,
           revenu_usd = b.revenu_usd,
           po_orderid = b.po_orderid,
           pay_action = b.pay_action,
           pay_result = b.pay_result,
           pay_description = b.pay_description,
           pay_message = b.pay_message,
           po_internal_status = b.po_internal_status,
           po_payment_type = b.po_payment_type,
           po_paymentprovider = b.po_paymentprovider,
           payment_card_brand = b.payment_card_brand,
           po_status_ct = b.po_status_ct,
           funnel_status = b.funnel_status,
           updated_timestamp = CURRENT_TIMESTAMP,
           PAY_GATEWAY_STATUS = b.PAY_GATEWAY_STATUS,
           PO_PAYMENT_TYPE_STATUS = b.PO_PAYMENT_TYPE_STATUS,
           PO_PLATAFORM_DATASOURCE = b.PO_PLATAFORM_DATASOURCE,
           datasource_origin_timestamp = b.datasource_origin_timestamp
    WHEN NOT MATCHED THEN INSERT (
           id,
           insert_timestamp,
           po_date,
           po_month,
           po_year,
           po_hour,
           pay_subsidiary,
           pay_code,
           pay_id,
           pay_date,
           pay_month,
           pay_year,
           pay_hour,
           pay_status,
           pay_detail,
           pay_gateway_code,
           payment_type,
           pay_gateway,
           revenue_local,
           pay_orderid,
           pay_storename,
           postoretype,
           po_devicetype,
           po_status,
           order_status_type,
           currency,
           po_order_lastmodifydate,
           postorename,
           channel,
           biz_type,
           audience_type,
           subsidiary,
           pe_amount,
           revenu_usd,
           po_orderid,
           pay_action,
           pay_result,
           pay_description,
           pay_message,
           po_internal_status,
           po_payment_type,
           po_paymentprovider,
           payment_card_brand,
           po_status_ct,
           funnel_status,
           PAY_GATEWAY_STATUS,
           PO_PAYMENT_TYPE_STATUS,
           PO_PLATAFORM_DATASOURCE,
           datasource_origin_timestamp
    ) VALUES (
           CAST(SUBSTR(REGEXP_REPLACE(MD5(b.pay_subsidiary || '|' || b.pay_orderid), '[^0-9]', ''), 1, 9) AS INT),
           b.insert_timestamp,
           b.po_date,
           b.po_month,
           b.po_year,
           b.po_hour,
           b.pay_subsidiary,
           b.pay_code,
           b.pay_id,
           b.pay_date,
           b.pay_month,
           b.pay_year,
           b.pay_hour,
           b.pay_status,
           b.pay_detail,
           b.pay_gateway_code,
           b.payment_type,
           b.pay_gateway,
           b.revenue_local,
           b.pay_orderid,
           b.pay_storename,
           b.postoretype,
           b.po_devicetype,
           b.po_status,
           b.order_status_type,
           b.currency,
           b.po_order_lastmodifydate,
           b.postorename,
           b.channel,
           b.biz_type,
           b.audience_type,
           b.subsidiary,
           b.pe_amount,
           b.revenu_usd,
           b.po_orderid,
           b.pay_action,
           b.pay_result,
           b.pay_description,
           b.pay_message,
           b.po_internal_status,
           b.po_payment_type,
           b.po_paymentprovider,
           b.payment_card_brand,
           b.po_status_ct,
           b.funnel_status,
           b.PAY_GATEWAY_STATUS,
           b.PO_PAYMENT_TYPE_STATUS,
           b.PO_PLATAFORM_DATASOURCE,
           b.datasource_origin_timestamp
    );
END;
$$;

CALL ow_lao.proc_ods_sales_payments_grafana_details();
-- proc_ods_sales_payments_grafana_details
-- ---------------------------------------
-- 0

