CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_dim_subsidiary_timezone_exceptions()
 LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM INSERT INTO ow_lao.ods_dim_subsidiary_timezone_exceptions(
          subsidiary_id            
        , country                  
        , timezone                 
        , daylight_save_time       
        , timezone_from            
        , timezone_until           
        , url                      
        , request_timestamp        
    )
    SELECT a.subsidiary_id
         , a.country
         , CAST(REPLACE(REPLACE(a.timezone, ':00', ''), '-0', '-') AS INT) AS timezone
         , a.daylight_save_time
         , a.daylight_save_time_from
         , a.daylight_save_time_until
         , a.url
         , a.request_timestamp
      FROM ow_lao.tmp_dim_subsidiary_timezone_exceptions a
     WHERE a.daylight_save_time = 1
       AND NOT EXISTS (
                SELECT 1
                  FROM ow_lao.ods_dim_subsidiary_timezone_exceptions aa
                 WHERE aa.subsidiary_id = a.subsidiary_id
                   AND aa.country       = a.country
                   AND aa.timezone_from = a.daylight_save_time_from
           );
END
$$;

-- CALL OW_LAO.proc_ods_dim_subsidiary_timezone_exceptions();
-- ERROR: Severity: ERROR, Message: Operator does not exist: timestamp = varchar, Sqlstate: 42883, Hint: No operator matches the given name and argument type(s). You may need to add explicit type casts, Where: PL/vSQL procedure proc_ods_dim_subsidiary_timezone_exceptions line 3 at static SQL, Routine: op_error, File: parse_oper.c, Line: 608, Error Code: 4286, 
-- CALL OW_LAO.proc_ods_dim_subsidiary_timezone_exceptions();
-- ERROR: Severity: ERROR, Message: Operator does not exist: timestamp = varchar, Sqlstate: 42883, Hint: No operator matches the given name and argument type(s). You may need to add explicit type casts, Where: PL/vSQL procedure proc_ods_dim_subsidiary_timezone_exceptions line 3 at static SQL, Routine: op_error, File: parse_oper.c, Line: 608, Error Code: 4286, 
CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_dim_subsidiary_timezone_exceptions()
 LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM INSERT INTO ow_lao.ods_dim_subsidiary_timezone_exceptions(
          subsidiary_id            
        , country                  
        , timezone                 
        , daylight_save_time       
        , timezone_from            
        , timezone_until           
        , url                      
        , request_timestamp        
    )
    SELECT a.subsidiary_id
         , a.country
         , CAST(REPLACE(REPLACE(a.timezone, ':00', ''), '-0', '-') AS INT) AS timezone
         , a.daylight_save_time
         , TO_TIMESTAMP(a.daylight_save_time_from)
         , TO_TIMESTAMP(a.daylight_save_time_until)
         , a.url
         , a.request_timestamp
      FROM ow_lao.tmp_dim_subsidiary_timezone_exceptions a
     WHERE a.daylight_save_time = 1
       AND NOT EXISTS (
                SELECT 1
                  FROM ow_lao.ods_dim_subsidiary_timezone_exceptions aa
                 WHERE aa.subsidiary_id = a.subsidiary_id
                   AND aa.country       = a.country
                   AND aa.timezone_from = TO_TIMESTAMP(a.daylight_save_time_from)
           );
END;
$$;

-- CALL OW_LAO.proc_ods_dim_subsidiary_timezone_exceptions();
-- ERROR: Severity: ERROR, Message: Column "subsidiary_id" is of type int but expression is of type varchar, Sqlstate: 42804, Hint: You will need to rewrite or cast the expression, Where: PL/vSQL procedure proc_ods_dim_subsidiary_timezone_exceptions line 3 at static SQL, Routine: updateTargetListEntry, File: parse_target.c, Line: 853, Error Code: 2631, 
-- CALL OW_LAO.proc_ods_dim_subsidiary_timezone_exceptions();
-- ERROR: Severity: ERROR, Message: Column "subsidiary_id" is of type int but expression is of type varchar, Sqlstate: 42804, Hint: You will need to rewrite or cast the expression, Where: PL/vSQL procedure proc_ods_dim_subsidiary_timezone_exceptions line 3 at static SQL, Routine: updateTargetListEntry, File: parse_target.c, Line: 853, Error Code: 2631, 
CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_dim_subsidiary_timezone_exceptions()
 LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM INSERT INTO ow_lao.ods_dim_subsidiary_timezone_exceptions(
          subsidiary_id            
        , country                  
        , timezone                 
        , daylight_save_time       
        , timezone_from            
        , timezone_until           
        , url                      
        , request_timestamp        
    )
    SELECT CAST(a.subsidiary_id AS INT)
         , a.country
         , CAST(REPLACE(REPLACE(a.timezone, ':00', ''), '-0', '-') AS INT) AS timezone
         , a.daylight_save_time
         , TO_TIMESTAMP(a.daylight_save_time_from)
         , TO_TIMESTAMP(a.daylight_save_time_until)
         , a.url
         , a.request_timestamp
      FROM ow_lao.tmp_dim_subsidiary_timezone_exceptions a
     WHERE a.daylight_save_time = 1
       AND NOT EXISTS (
                SELECT 1
                  FROM ow_lao.ods_dim_subsidiary_timezone_exceptions aa
                 WHERE aa.subsidiary_id = CAST(a.subsidiary_id AS INT)
                   AND aa.country       = a.country
                   AND aa.timezone_from = TO_TIMESTAMP(a.daylight_save_time_from)
           );
END;
$$;

-- CALL OW_LAO.proc_ods_dim_subsidiary_timezone_exceptions();
-- ERROR: Severity: ERROR, Message: Column "daylight_save_time" is of type int but expression is of type varchar, Sqlstate: 42804, Hint: You will need to rewrite or cast the expression, Where: PL/vSQL procedure proc_ods_dim_subsidiary_timezone_exceptions line 3 at static SQL, Routine: updateTargetListEntry, File: parse_target.c, Line: 853, Error Code: 2631, 
-- CALL OW_LAO.proc_ods_dim_subsidiary_timezone_exceptions();
-- ERROR: Severity: ERROR, Message: Column "daylight_save_time" is of type int but expression is of type varchar, Sqlstate: 42804, Hint: You will need to rewrite or cast the expression, Where: PL/vSQL procedure proc_ods_dim_subsidiary_timezone_exceptions line 3 at static SQL, Routine: updateTargetListEntry, File: parse_target.c, Line: 853, Error Code: 2631, 
CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_dim_subsidiary_timezone_exceptions()
 LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM INSERT INTO ow_lao.ods_dim_subsidiary_timezone_exceptions(
          subsidiary_id            
        , country                  
        , timezone                 
        , daylight_save_time       
        , timezone_from            
        , timezone_until           
        , url                      
        , request_timestamp        
    )
    SELECT CAST(a.subsidiary_id AS INT)
         , a.country
         , CAST(REPLACE(REPLACE(a.timezone, ':00', ''), '-0', '-') AS INT) AS timezone
         , CAST(a.daylight_save_time AS INT)
         , TO_TIMESTAMP(a.daylight_save_time_from)
         , TO_TIMESTAMP(a.daylight_save_time_until)
         , a.url
         , a.request_timestamp
      FROM ow_lao.tmp_dim_subsidiary_timezone_exceptions a
     WHERE CAST(a.daylight_save_time AS INT) = 1
       AND NOT EXISTS (
                SELECT 1
                  FROM ow_lao.ods_dim_subsidiary_timezone_exceptions aa
                 WHERE aa.subsidiary_id = CAST(a.subsidiary_id AS INT)
                   AND aa.country       = a.country
                   AND aa.timezone_from = TO_TIMESTAMP(a.daylight_save_time_from)
           );
END;
$$;

-- CALL OW_LAO.proc_ods_dim_subsidiary_timezone_exceptions();
-- ERROR: Severity: ERROR, Message: Column "request_timestamp" is of type timestamp but expression is of type varchar, Sqlstate: 42804, Hint: You will need to rewrite or cast the expression, Where: PL/vSQL procedure proc_ods_dim_subsidiary_timezone_exceptions line 3 at static SQL, Routine: updateTargetListEntry, File: parse_target.c, Line: 853, Error Code: 2631, 
-- CALL OW_LAO.proc_ods_dim_subsidiary_timezone_exceptions();
-- ERROR: Severity: ERROR, Message: Column "request_timestamp" is of type timestamp but expression is of type varchar, Sqlstate: 42804, Hint: You will need to rewrite or cast the expression, Where: PL/vSQL procedure proc_ods_dim_subsidiary_timezone_exceptions line 3 at static SQL, Routine: updateTargetListEntry, File: parse_target.c, Line: 853, Error Code: 2631, 
CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_dim_subsidiary_timezone_exceptions()
 LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM INSERT INTO ow_lao.ods_dim_subsidiary_timezone_exceptions(
          subsidiary_id            
        , country                  
        , timezone                 
        , daylight_save_time       
        , timezone_from            
        , timezone_until           
        , url                      
        , request_timestamp        
    )
    SELECT CAST(a.subsidiary_id AS INT)
         , a.country
         , CAST(REPLACE(REPLACE(a.timezone, ':00', ''), '-0', '-') AS INT) AS timezone
         , CAST(a.daylight_save_time AS INT)
         , TO_TIMESTAMP(a.daylight_save_time_from)
         , TO_TIMESTAMP(a.daylight_save_time_until)
         , a.url
         , CAST(a.request_timestamp AS TIMESTAMP)
      FROM ow_lao.tmp_dim_subsidiary_timezone_exceptions a
     WHERE CAST(a.daylight_save_time AS INT) = 1
       AND NOT EXISTS (
                SELECT 1
                  FROM ow_lao.ods_dim_subsidiary_timezone_exceptions aa
                 WHERE aa.subsidiary_id = CAST(a.subsidiary_id AS INT)
                   AND aa.country       = a.country
                   AND aa.timezone_from = TO_TIMESTAMP(a.daylight_save_time_from)
           );
END;
$$;

CALL OW_LAO.proc_ods_dim_subsidiary_timezone_exceptions();
-- proc_ods_dim_subsidiary_timezone_exceptions
-- -------------------------------------------
-- 0

