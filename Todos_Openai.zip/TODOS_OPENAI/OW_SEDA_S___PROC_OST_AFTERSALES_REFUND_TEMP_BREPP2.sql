-- SELECT JSON_VALUE('{"a": {"b": 123}}', '$.a.b');
-- ERROR: Severity: ERROR, Message: Function JSON_VALUE(unknown, unknown) does not exist, or permission is denied for JSON_VALUE(unknown, unknown), Sqlstate: 42883, Hint: No function matches the given name and argument types. You may need to add explicit type casts, Routine: throwErrorFunctionDoesNotMatch, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/ParseFunc.cpp, Line: 4559, Error Code: 3457, 
SELECT MAPLOOKUP(MAPJSONEXTRACTOR('{"a": {"b": 123}}'), 'a.b') AS val;
-- val
-- ---
-- 123

SELECT MAPLOOKUP(MAPJSONEXTRACTOR('{"a": {"b": 123}}'), '$.a.b') AS val1,
       MAPLOOKUP(MAPJSONEXTRACTOR('{"a": {"b": 123}}'), 'a.b') AS val2,
       MAPLOOKUP(MAPJSONEXTRACTOR('{"a": {"b": 123}}'), '/a/b') AS val3;
-- val1 | val2 | val3
-- -----+------+-----
-- NULL | 123 | NULL

-- SELECT MAPLOOKUP(MAPJSONEXTRACTOR('[1,2,3]'), '0') AS e0, MAPLOOKUP(MAPJSONEXTRACTOR('[{"a":1},{"a":2}]'), '0.a') AS a0;
-- ERROR: Severity: ERROR, Message: Error calling processBlock() in User Function MapJSONExtractor at [/data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/udx/supported/flextable/JSONExtractor.cpp:399], error code: 0, message: Unrecoverable parse exception while processing partition: [Corrupt JSON file:  Tried to add element '[1]' when not in an array or prefixed by a map key.  (If you want to parse flat values, see FDelimitedParser.) on record # [1]] while parsing JSON data for row [0] with [0] Bytes consumed., Sqlstate: VP001, Routine: UDF_MVCol, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/EE/Functions/VEval.cpp, Line: 14376, Error Code: 5861, 
-- SELECT JSON_EXTRACT_STRING('{"a":{"b":"x"}}', 'a','b');
-- ERROR: Severity: ERROR, Message: Function JSON_EXTRACT_STRING(unknown, unknown, unknown) does not exist, or permission is denied for JSON_EXTRACT_STRING(unknown, unknown, unknown), Sqlstate: 42883, Hint: No function matches the given name and argument types. You may need to add explicit type casts, Routine: throwErrorFunctionDoesNotMatch, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/ParseFunc.cpp, Line: 4559, Error Code: 3457, 
SELECT MAPLOOKUP(MAPJSONEXTRACTOR('{"a":{"b":123}}'::LONG VARCHAR), 'a.b') AS v;
-- v
-- -
-- 123

SELECT MAPLOOKUP(MAPJSONEXTRACTOR('{"x":1}'::LONG VARCHAR), 'x') AS x;
-- x
-- -
-- 1

SELECT MAPLOOKUP(MAPJSONEXTRACTOR(t.j), 'a.b') AS v
FROM (SELECT '{"a":{"b":"x"}}'::LONG VARCHAR AS j) t;
-- v
-- -
-- x

CREATE OR REPLACE PROCEDURE OW_SEDA_S.PROC_OST_AFTERSALES_REFUND_TEMP_BREPP2()
LANGUAGE PLvSQL AS $$
BEGIN
    
    PERFORM DROP TABLE IF EXISTS OW_SEDA_S.TMP_OST_REFUND_5 CASCADE;

    PERFORM CREATE TABLE OW_SEDA_S.TMP_OST_REFUND_5 AS
    WITH base_times AS (
      SELECT 
        D.*, A.*, 
        GREATEST(CAST(A.CREATED_AT AS TIMESTAMP), CAST(A.UPDATED_AT AS TIMESTAMP)) AS max_time
      FROM OW_LAO.ODS_AFTER_SALES_REFUND_DETAIL_EPP2 D
      LEFT JOIN OW_LAO.ODS_AFTER_SALES_REFUND_EPP2 A
        ON A.ID_DATA = D.ID_DETAIL
    )
    SELECT DISTINCT 
       'BREPP2' AS INSTANCES
      ,CAST(TIMESTAMPADD(SECOND, -10800, max_time) AS DATE) AS "DATE_REF"
      ,CL.YYYYWW AS "YYYYWW"
      ,CL.YYYYMM AS "YYYYMM"
      ,LPAD(CAST(EXTRACT(HOUR FROM TIMESTAMPADD(SECOND, -10800, max_time)) AS VARCHAR(2)), 2, '0') AS "Horas"
      ,LPAD(CAST(EXTRACT(MINUTE FROM TIMESTAMPADD(SECOND, -10800, max_time)) AS VARCHAR(2)), 2, '0') AS "Minutos"
      ,TO_CHAR(TIMESTAMPADD(SECOND, -10800, max_time), 'HH24:MI:SS') AS "Horário"
      ,TIMESTAMPADD(SECOND, -10800, CAST(A.CREATED_AT AS TIMESTAMP)) AS "Data criação Reembolso"
      ,TIMESTAMPADD(SECOND, -10800, CAST(A.UPDATED_AT AS TIMESTAMP)) AS "Data atualização Reembolso"
      ,D.ID_DETAIL AS "ID Reembolso"
      ,D.REVERSE_ID AS "ID Reversa"
      ,D.REVERSE_STATUS_DESCRIPTION AS "Status Reversa"
      ,A.ORDER_ID AS "ID Pedido"
      ,NULL::VARCHAR AS "Local Origem Pedido"
      ,D.REVERSE_PARTNER_STORE AS "Loja Parceira"
      ,(COALESCE(D.CUSTOMER_FIRST_NAME,'') || ' ' || COALESCE(D.CUSTOMER_LAST_NAME,'')) AS "Nome Cliente"
      ,D.CUSTOMER_EMAIL AS "Email Cliente"
      ,D.CUSTOMER_DOCUMENT AS "Documento Cliente"
      ,A.TYPE_DATA AS "Tipo Reembolso"
      ,A.ACTION_DATA AS "Ação Reembolso"
      ,D.STATUS_DESCRIPTION AS "Status Reembolso"
      ,CAST(D.REQUESTED_RAW_AMOUNT AS DECIMAL(20,2)) AS "Valor bruto solicitado"
      ,CAST(D.REQUESTED_SHIPPING_AMOUNT AS DECIMAL(20,2)) AS "Valor envio socilitado"
      ,CAST(D.REQUESTED_AMOUNT AS DECIMAL(20,2)) AS "Valor solicitado"
      ,CAST(D.BONUS_AMOUNT AS DECIMAL(20,2)) AS "Valor bônus solicitado"
      ,CASE WHEN D.FREE_SHIPPING = 'true' THEN 'Sim' WHEN D.FREE_SHIPPING = 'false' THEN 'Não' END AS "Retenção com frete grátis?"
      ,CAST(D.REQUESTED_TOTAL_AMOUNT AS DECIMAL(20,2)) AS "Valor total solicitado"
      ,CAST(D.RECEIVED_RAW_AMOUNT AS DECIMAL(20,2)) AS "Valor bruto recebido"
      ,CAST(D.RECEIVED_AMOUNT AS DECIMAL(20,2)) AS "Valor recebido"
      ,CAST(D.TOTAL_AMOUNT AS DECIMAL(20,2)) AS "Valor total"
      ,NULL::VARCHAR AS "Código Voucher"
      ,NULL::VARCHAR AS "Tem conta bancária"
      ,NULL::VARCHAR AS "Banco"
      ,NULL::VARCHAR AS "Nome do Banco"
      ,NULL::VARCHAR AS "Número da agência"
      ,NULL::VARCHAR AS "Dígito da agência"
      ,NULL::VARCHAR AS "Número da conta"
      ,NULL::VARCHAR AS "Tipo de conta"
      ,NULL::VARCHAR AS "Tipo de chave Pix"
      ,NULL::VARCHAR AS "Chave Pix"
      ,NULL::VARCHAR AS "Métodos Pagamento do pedido"
      ,NULL::TIMESTAMP AS "Solicitado em"
      ,NULL::TIMESTAMP AS "Aprovado em"
      ,NULL::TIMESTAMP AS "Pago em"
      ,NULL::TIMESTAMP AS "Falha em"
      ,NULL::TIMESTAMP AS "Cancelado em"
      ,NULL::TIMESTAMP AS "Aguardando aprovação em"
      ,NULL::TIMESTAMP AS "Aguardando dados bancários em"
      ,NULL::TIMESTAMP AS "Aguardando pagamento manual em"
      ,NULL::TIMESTAMP AS "Em avaliação em"
      ,NULL::TIMESTAMP AS "Finalizado por abandono em"
      ,NULL::TIMESTAMP AS "Pendência Financeira em"
      ,NULL::TIMESTAMP AS "Pendência Fiscal em"
      ,NULL::TIMESTAMP AS "Processando em"
      ,NULL::TIMESTAMP AS "Processando aprovação em"
      ,NULL::VARCHAR AS "Tipos Pagamentos"
      ,NULL::VARCHAR AS "Adquirente Transação"
      ,NULL::VARCHAR AS "NSU Transação"
      ,NULL::VARCHAR AS "TID Transação"
      ,NULL::DECIMAL(20,2) AS "Valor Total Transação"
      ,NULL::TIMESTAMP AS "Data Transação"
      ,D.SHIPPING_METHOD AS "Método Entrega"
      ,CAST(D.ADDED_TAXES_AMOUNT AS DECIMAL(20,2)) AS "Impostos Adicionados"
      ,D.CUSTOMER_ID AS "Id Cliente"
      ,D.STATUS_ID AS "Id Status Reembolso"
      ,NULL::VARCHAR AS "Id Transações Pedido"
      ,NULL::VARCHAR AS "Id Transações Ecommerce"
      ,NULL::VARCHAR AS "Id Transações Adquirente"
      ,D.REVERSE_REVERSE_TYPE AS "Tipo Reversa"
      ,TIMESTAMPADD(SECOND, -10800, CAST(D.REVERSE_CREATED_AT AS TIMESTAMP)) AS "Data Criação Reversa"
      ,D.REVERSE_ECOMMERCEORDER_OPTIONS_ORDER_SEQUENCE_NUMBER AS "Sequence"
      ,D.REVERSE_ECOMMERCEORDER_OPTIONS_WAREHOUSE_NUMBER_ID AS "ID WAREHOUSE"
      ,CASE WHEN D.REVERSE_ECOMMERCEORDER_OPTIONS_PAID_WITH_VOUCHER = 'false' THEN 'Não'
            WHEN D.REVERSE_ECOMMERCEORDER_OPTIONS_PAID_WITH_VOUCHER = 'true'  THEN 'Sim' END AS "PAID_WITH_VOUCHER"
      ,NULL::VARCHAR AS "Número Fatura"
      ,NULL::VARCHAR AS "NFe Fatura"
      ,NULL::VARCHAR AS "Motivos devolução/cancelamento"
      ,NULL::VARCHAR AS "SubMotivos devolução/cancelamento"
      ,NULL::VARCHAR AS "Comentários Produtos"
      ,NULL::VARCHAR AS "SKUs Produto(s)"
      ,NULL::VARCHAR AS "Nome Produto(s)"
      ,NULL::VARCHAR AS "Códigos EAN (European Article Number)"
      ,NULL::VARCHAR AS "Mensagens RDO AferSales"
      ,NULL::VARCHAR AS "Mensagens ERRO AferSales"
      ,NULL::VARCHAR AS "Outras Mensagens AferSales"
    FROM base_times bt
    CROSS JOIN (
      SELECT 'BREPP2' AS INSTANCES
    ) T_INST
    LEFT JOIN OW_MD.DIM_CALENDAR CL
      ON CL.YYYYMMDD = CAST(TIMESTAMPADD(SECOND, -10800, max_time) AS DATE)
    WHERE 1=1;

END;
$$;

-- CALL OW_SEDA_S.PROC_OST_AFTERSALES_REFUND_TEMP_BREPP2();
-- ERROR: Severity: ERROR, Message: Relation "OW_MD.DIM_CALENDAR" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_OST_AFTERSALES_REFUND_TEMP_BREPP2 line 6 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
-- CALL OW_SEDA_S.PROC_OST_AFTERSALES_REFUND_TEMP_BREPP2();
-- ERROR: Severity: ERROR, Message: Relation "OW_MD.DIM_CALENDAR" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_OST_AFTERSALES_REFUND_TEMP_BREPP2 line 6 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
