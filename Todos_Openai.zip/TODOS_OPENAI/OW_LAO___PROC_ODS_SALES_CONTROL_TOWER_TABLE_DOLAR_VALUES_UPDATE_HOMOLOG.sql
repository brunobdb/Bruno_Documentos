CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_sales_control_tower_table_dolar_values_update_homolog()
LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM UPDATE ow_lao.ods_sales_control_tower_table a
       SET po_itemdiscount_usd = COALESCE(a.po_itemdiscount_localcurr / CAST(b.exchange_rate AS DECIMAL), 0)
         , po_price_usd        = COALESCE(a.po_price_localcurr        / CAST(b.exchange_rate AS DECIMAL), 0)
         , po_totalprice_usd   = COALESCE(a.po_totalprice_local       / CAST(b.exchange_rate AS DECIMAL), 0)
      FROM ow_lao.ft_ap2_exchange_rate b
     WHERE b.valid_from  = CAST(a.po_date AS DATE)
       AND b.to_currency = a.currency
       AND COALESCE(a.po_totalprice_usd , 0)  = 0
       AND COALESCE(a.po_price_localcurr, 0) != 0
       AND a.po_plataform_datasource IN ('u_prj_ecom_synapcom.ft_ecom_order', 'u_prj_ecom.ft_ecom_order', 'u_prj_ecom.raw_vtex_ssg_br_shop_sales_order', 'ow_lao.ods_orders_visuar');

    PERFORM UPDATE ow_lao.ods_sales_control_tower_table a
       SET po_price_usd        = COALESCE(a.po_price_localcurr        / CAST(b.exchange_rate AS DECIMAL), 0)
         , po_totalprice_usd   = COALESCE(a.po_totalprice             / CAST(b.exchange_rate AS DECIMAL), 0)
         , po_itemdiscount_usd = COALESCE(a.po_itemdiscount_localcurr / CAST(b.exchange_rate AS DECIMAL), 0)
      FROM ow_lao.ft_ap2_exchange_rate b
     WHERE b.valid_from  = CAST(a.po_date AS DATE)
       AND b.to_currency = a.currency
       AND COALESCE(a.po_totalprice_usd , 0) = 0
       AND COALESCE(a.po_price_localcurr, 0) != 0
       AND a.po_plataform_datasource IN ('ow_lao.ods_hybris_sales');

    PERFORM UPDATE ow_lao.ods_sales_control_tower_table a
       SET a.nerp_netprice = COALESCE(CAST(REPLACE(c.so_net_price, ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL), 0)
         , a.nerp_netvalue = COALESCE(CAST(REPLACE(c.so_net_value, ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL), 0)
         , a.nerp_cost     = COALESCE(CAST(REPLACE(c.cost        , ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL), 0)
      FROM ow_md.dim_subsidiary b
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking c ON c.customer_po = a.po_sequence_orderid
                                                             AND c.material    = a.po_sku
                                                             AND c.sales_org   = b.sales_org
      JOIN ow_lao.ft_ap2_exchange_rate d ON d.valid_from  = CAST(a.po_date AS DATE)
                                         AND d.to_currency = a.currency
     WHERE LOWER(b.country) = LOWER(a.country)
       AND COALESCE(a.nerp_netprice, 0) = 0;

    PERFORM UPDATE ow_lao.ods_sales_control_tower_table a
       SET po_itemdiscount_usd = COALESCE(a.po_itemdiscount_localcurr / CAST(b.exchange_rate AS DECIMAL), 0)
         , po_price_usd        = COALESCE(a.po_price_localcurr        / CAST(b.exchange_rate AS DECIMAL), 0)
         , po_totalprice_usd   = COALESCE(a.po_totalprice_local       / CAST(b.exchange_rate AS DECIMAL), 0)
      FROM ow_lao.ft_ap2_exchange_rate b
     WHERE b.valid_from  = CAST(a.po_date AS DATE)
       AND b.to_currency = 'USD'
       AND a.currency    = 'PAB'
       AND COALESCE(a.po_totalprice_usd , 0)  = 0
       AND COALESCE(a.po_price_localcurr, 0) != 0
       AND a.po_plataform_datasource IN ('u_prj_ecom.ft_ecom_order')
       AND a.currency = 'PAB';
END;
$$;

-- CALL OW_LAO.proc_ods_sales_control_tower_table_dolar_values_update_homolog();
-- ERROR: Severity: ERROR, Message: Operator does not exist: varchar = date, Sqlstate: 42883, Hint: No operator matches the given name and argument type(s). You may need to add explicit type casts, Where: PL/vSQL procedure proc_ods_sales_control_tower_table_dolar_values_update_homolog line 3 at static SQL, Routine: op_error, File: parse_oper.c, Line: 608, Error Code: 4286, 
-- CALL OW_LAO.proc_ods_sales_control_tower_table_dolar_values_update_homolog();
-- ERROR: Severity: ERROR, Message: Operator does not exist: varchar = date, Sqlstate: 42883, Hint: No operator matches the given name and argument type(s). You may need to add explicit type casts, Where: PL/vSQL procedure proc_ods_sales_control_tower_table_dolar_values_update_homolog line 3 at static SQL, Routine: op_error, File: parse_oper.c, Line: 608, Error Code: 4286, 
CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_sales_control_tower_table_dolar_values_update_homolog()
LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM UPDATE ow_lao.ods_sales_control_tower_table a
       SET po_itemdiscount_usd = COALESCE(a.po_itemdiscount_localcurr / CAST(b.exchange_rate AS DECIMAL(18,6)), 0)
         , po_price_usd        = COALESCE(a.po_price_localcurr        / CAST(b.exchange_rate AS DECIMAL(18,6)), 0)
         , po_totalprice_usd   = COALESCE(a.po_totalprice_local       / CAST(b.exchange_rate AS DECIMAL(18,6)), 0)
      FROM ow_lao.ft_ap2_exchange_rate b
     WHERE CAST(b.valid_from AS DATE) = CAST(a.po_date AS DATE)
       AND b.to_currency = a.currency
       AND COALESCE(a.po_totalprice_usd , 0)  = 0
       AND COALESCE(a.po_price_localcurr, 0) != 0
       AND a.po_plataform_datasource IN ('u_prj_ecom_synapcom.ft_ecom_order', 'u_prj_ecom.ft_ecom_order', 'u_prj_ecom.raw_vtex_ssg_br_shop_sales_order', 'ow_lao.ods_orders_visuar');

    PERFORM UPDATE ow_lao.ods_sales_control_tower_table a
       SET po_price_usd        = COALESCE(a.po_price_localcurr        / CAST(b.exchange_rate AS DECIMAL(18,6)), 0)
         , po_totalprice_usd   = COALESCE(a.po_totalprice             / CAST(b.exchange_rate AS DECIMAL(18,6)), 0)
         , po_itemdiscount_usd = COALESCE(a.po_itemdiscount_localcurr / CAST(b.exchange_rate AS DECIMAL(18,6)), 0)
      FROM ow_lao.ft_ap2_exchange_rate b
     WHERE CAST(b.valid_from AS DATE) = CAST(a.po_date AS DATE)
       AND b.to_currency = a.currency
       AND COALESCE(a.po_totalprice_usd , 0) = 0
       AND COALESCE(a.po_price_localcurr, 0) != 0
       AND a.po_plataform_datasource IN ('ow_lao.ods_hybris_sales');

    PERFORM UPDATE ow_lao.ods_sales_control_tower_table a
       SET nerp_netprice = COALESCE(CAST(REPLACE(c.so_net_price, ',', '') AS DECIMAL(18,6)) / CAST(d.exchange_rate AS DECIMAL(18,6)), 0)
         , nerp_netvalue = COALESCE(CAST(REPLACE(c.so_net_value, ',', '') AS DECIMAL(18,6)) / CAST(d.exchange_rate AS DECIMAL(18,6)), 0)
         , nerp_cost     = COALESCE(CAST(REPLACE(c.cost        , ',', '') AS DECIMAL(18,6)) / CAST(d.exchange_rate AS DECIMAL(18,6)), 0)
      FROM ow_md.dim_subsidiary b
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking c ON c.customer_po = a.po_sequence_orderid
                                                             AND c.material    = a.po_sku
                                                             AND c.sales_org   = b.sales_org
      JOIN ow_lao.ft_ap2_exchange_rate d ON CAST(d.valid_from AS DATE) = CAST(a.po_date AS DATE)
                                         AND d.to_currency = a.currency
     WHERE LOWER(b.country) = LOWER(a.country)
       AND COALESCE(a.nerp_netprice, 0) = 0;

    PERFORM UPDATE ow_lao.ods_sales_control_tower_table a
       SET po_itemdiscount_usd = COALESCE(a.po_itemdiscount_localcurr / CAST(b.exchange_rate AS DECIMAL(18,6)), 0)
         , po_price_usd        = COALESCE(a.po_price_localcurr        / CAST(b.exchange_rate AS DECIMAL(18,6)), 0)
         , po_totalprice_usd   = COALESCE(a.po_totalprice_local       / CAST(b.exchange_rate AS DECIMAL(18,6)), 0)
      FROM ow_lao.ft_ap2_exchange_rate b
     WHERE CAST(b.valid_from AS DATE) = CAST(a.po_date AS DATE)
       AND b.to_currency = 'USD'
       AND a.currency    = 'PAB'
       AND COALESCE(a.po_totalprice_usd , 0)  = 0
       AND COALESCE(a.po_price_localcurr, 0) != 0
       AND a.po_plataform_datasource IN ('u_prj_ecom.ft_ecom_order');
END;
$$;

-- CALL OW_LAO.proc_ods_sales_control_tower_table_dolar_values_update_homolog();
-- ERROR: Severity: ERROR, Message: Relation "a" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ods_sales_control_tower_table_dolar_values_update_homolog line 25 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4345, Error Code: 4566, 
-- CALL OW_LAO.proc_ods_sales_control_tower_table_dolar_values_update_homolog();
-- ERROR: Severity: ERROR, Message: Relation "a" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ods_sales_control_tower_table_dolar_values_update_homolog line 25 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4345, Error Code: 4566, 
