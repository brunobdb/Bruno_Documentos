-- CREATE OR REPLACE PROCEDURE ow_lao.proc_ods_orders_visuar()
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--     -- Ensure temp/staging table exists, then refresh its contents
--     PERFORM CREATE TABLE IF NOT EXISTS ow_lao.tmp_proc_ods_orders_visuar AS (
--         SELECT 
--               fecha_de_emision_del_movimiento 
--             , codigo_de_formulario 
--             , formulario 
--             , numero 
--             , razon_social 
--             , tipo_de_producto 
--             , descripcion 
--             , codigo_de_producto 
--             , descripcion_producto 
--             , cantidad_real 
--             , monto_sin_impuestos 
--             , ABS(total_bonificado)                            AS total_bonificado 
--             , condicion_de_pago 
--             , canal_de_venta_kd 
--             , canal_de_venta_com
--             , a.formulario_origen
--             , a.nro_origen
--             , CASE a.formulario 
--                     WHEN 'FACTURA' THEN 'Approved'
--                     WHEN 'NOTA DE CRÉDITO' THEN 'returned'
--                     ELSE NULL                        
--               END                                             AS status     
--             , CASE UPPER(SUBSTRING(codigo_de_producto, 1, 2))
--                     WHEN 'SA' THEN SUBSTRING(codigo_de_producto, 3)
--                     ELSE codigo_de_producto
--               END                                             AS reference_code
--             , TO_DATE(fecha_de_emision_del_movimiento, 'DD/MM/YYYY')
--                                                               AS fecha_de_emision_del_movimiento_formated
--             , ROW_NUMBER() OVER(
--                     PARTITION BY a.codigo_de_formulario, a.codigo_de_producto, a.numero
--                     ORDER BY a.load_timestamp DESC
--               )                                               AS dedup
--         FROM ow_lao.raw_orders_visuar a
--         WHERE a.canal_de_venta_kd IN ('ONLINE-MELI', 'ONLINE-Market Place')
--           AND a.canal_de_venta_com NOT IN ('TIENDA OFICIAL OSTER MELI', 'TIENDA OFICIAL SMARTLIFE MELI')
--     ) WITH NO DATA;
-- 
--     PERFORM TRUNCATE TABLE ow_lao.tmp_proc_ods_orders_visuar;
-- 
--     PERFORM INSERT INTO ow_lao.tmp_proc_ods_orders_visuar
--     (
--           fecha_de_emision_del_movimiento 
--         , codigo_de_formulario 
--         , formulario 
--         , numero 
--         , razon_social 
--         , tipo_de_producto 
--         , descripcion 
--         , codigo_de_producto 
--         , descripcion_producto 
--         , cantidad_real 
--         , monto_sin_impuestos 
--         , total_bonificado 
--         , condicion_de_pago 
--         , canal_de_venta_kd 
--         , canal_de_venta_com
--         , formulario_origen
--         , nro_origen
--         , status     
--         , reference_code
--         , fecha_de_emision_del_movimiento_formated
--         , dedup
--     )
--     SELECT 
--           fecha_de_emision_del_movimiento 
--         , codigo_de_formulario 
--         , formulario 
--         , numero 
--         , razon_social 
--         , tipo_de_producto 
--         , descripcion 
--         , codigo_de_producto 
--         , descripcion_producto 
--         , cantidad_real 
--         , monto_sin_impuestos 
--         , ABS(total_bonificado)                            AS total_bonificado 
--         , condicion_de_pago 
--         , canal_de_venta_kd 
--         , canal_de_venta_com
--         , a.formulario_origen
--         , a.nro_origen
--         , CASE a.formulario 
--                 WHEN 'FACTURA' THEN 'Approved'
--                 WHEN 'NOTA DE CRÉDITO' THEN 'returned'
--                 ELSE NULL                        
--           END                                             AS status     
--         , CASE UPPER(SUBSTRING(codigo_de_producto, 1, 2))
--                 WHEN 'SA' THEN SUBSTRING(codigo_de_producto, 3)
--                 ELSE codigo_de_producto
--           END                                             AS reference_code
--         , TO_DATE(fecha_de_emision_del_movimiento, 'DD/MM/YYYY')
--                                                           AS fecha_de_emision_del_movimiento_formated
--         , ROW_NUMBER() OVER(
--                 PARTITION BY a.codigo_de_formulario, a.codigo_de_producto, a.numero
--                 ORDER BY a.load_timestamp DESC
--           )                                               AS dedup
--     FROM ow_lao.raw_orders_visuar a
--     WHERE a.canal_de_venta_kd IN ('ONLINE-MELI', 'ONLINE-Market Place')
--       AND a.canal_de_venta_com NOT IN ('TIENDA OFICIAL OSTER MELI', 'TIENDA OFICIAL SMARTLIFE MELI');
-- 
--     PERFORM DELETE FROM ow_lao.tmp_proc_ods_orders_visuar WHERE dedup <> 1;
-- 
--     PERFORM INSERT INTO ow_lao.ods_orders_visuar(
--               fecha_de_emision_del_movimiento 
--             , codigo_de_formulario 
--             , formulario 
--             , numero 
--             , razon_social 
--             , tipo_de_producto 
--             , descripcion 
--             , codigo_de_producto 
--             , descripcion_producto 
--             , cantidad_real 
--             , monto_sin_impuestos 
--             , total_bonificado 
--             , condicion_de_pago 
--             , canal_de_venta_kd 
--             , canal_de_venta_com
--             , status     
--             , reference_code
--             , fecha_de_emision_del_movimiento_formated
--     )
--     SELECT 
--               fecha_de_emision_del_movimiento 
--             , codigo_de_formulario 
--             , formulario 
--             , numero 
--             , razon_social 
--             , tipo_de_producto 
--             , descripcion 
--             , codigo_de_producto 
--             , descripcion_producto 
--             , cantidad_real 
--             , monto_sin_impuestos 
--             , ABS(total_bonificado)                  AS total_bonificado 
--             , condicion_de_pago 
--             , canal_de_venta_kd 
--             , canal_de_venta_com
--             , a.status                               AS status     
--             , CASE UPPER(SUBSTRING(codigo_de_producto, 1, 2))
--                     WHEN 'SA' THEN SUBSTRING(codigo_de_producto, 3)
--                     ELSE codigo_de_producto
--               END                                     AS reference_code
--             , fecha_de_emision_del_movimiento_formated
--     FROM ow_lao.tmp_proc_ods_orders_visuar a
--     WHERE a.formulario = 'FACTURA' 
--       AND a.canal_de_venta_kd IN ('ONLINE-MELI', 'ONLINE-Market Place')
--       AND a.canal_de_venta_com NOT IN ('TIENDA OFICIAL OSTER MELI', 'TIENDA OFICIAL SMARTLIFE MELI') 
--       AND NOT EXISTS (
--             SELECT 1
--             FROM ow_lao.ods_orders_visuar aa
--             WHERE aa.codigo_de_formulario = a.codigo_de_formulario
--               AND aa.codigo_de_producto   = a.codigo_de_producto
--               AND aa.numero               = a.numero
--       );
-- 
--     PERFORM UPDATE ow_lao.ods_orders_visuar a
--        SET status            = 'returned'
--          , updated_timestamp = CURRENT_TIMESTAMP
--     FROM ow_lao.tmp_proc_ods_orders_visuar b
--     WHERE b.formulario_origen  = a.codigo_de_formulario
--       AND b.codigo_de_producto = a.codigo_de_producto
--       AND b.nro_origen         = a.numero
--       AND b.formulario = 'NOTA DE CRÉDITO' 
--       AND a.canal_de_venta_kd IN ('ONLINE-MELI', 'ONLINE-Market Place')
--       AND a.canal_de_venta_com NOT IN ('TIENDA OFICIAL OSTER MELI', 'TIENDA OFICIAL SMARTLIFE MELI') 
--       AND a.status    <> 'returned';
-- 
--     PERFORM INSERT INTO ow_lao.ods_orders_visuar(
--               fecha_de_emision_del_movimiento 
--             , codigo_de_formulario 
--             , formulario 
--             , numero 
--             , razon_social 
--             , tipo_de_producto 
--             , descripcion 
--             , codigo_de_producto 
--             , descripcion_producto 
--             , cantidad_real 
--             , monto_sin_impuestos 
--             , total_bonificado 
--             , condicion_de_pago 
--             , canal_de_venta_kd 
--             , canal_de_venta_com
--             , status     
--             , reference_code
--             , fecha_de_emision_del_movimiento_formated
--     )
--     SELECT 
--               fecha_de_emision_del_movimiento 
--             , codigo_de_formulario 
--             , formulario 
--             , numero 
--             , razon_social 
--             , tipo_de_producto 
--             , descripcion 
--             , codigo_de_producto 
--             , descripcion_producto 
--             , cantidad_real 
--             , monto_sin_impuestos 
--             , ABS(total_bonificado)                  AS total_bonificado 
--             , condicion_de_pago 
--             , canal_de_venta_kd 
--             , canal_de_venta_com
--             , status                                 AS status     
--             , CASE UPPER(SUBSTRING(codigo_de_producto, 1, 2))
--                     WHEN 'SA' THEN SUBSTRING(codigo_de_producto, 3)
--                     ELSE codigo_de_producto
--               END                                     AS reference_code
--             , fecha_de_emision_del_movimiento_formated
--     FROM ow_lao.tmp_proc_ods_orders_visuar a
--     WHERE formulario = 'NOTA DE CRÉDITO'  
--       AND a.canal_de_venta_kd IN ('ONLINE-MELI', 'ONLINE-Market Place')
--       AND a.canal_de_venta_com NOT IN ('TIENDA OFICIAL OSTER MELI', 'TIENDA OFICIAL SMARTLIFE MELI') 
--       AND NOT EXISTS (
--             SELECT 1
--             FROM ow_lao.ods_orders_visuar aa
--             WHERE aa.codigo_de_formulario = a.codigo_de_formulario
--               AND aa.codigo_de_producto   = a.codigo_de_producto
--               AND aa.numero               = a.numero
--       );
-- 
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: Syntax error at or near "WITH", Sqlstate: 42601, Position: 2019, Routine: base_yyerror, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/scan.l, Line: 1056, Error Code: 4856, 
CREATE OR REPLACE PROCEDURE ow_lao.proc_ods_orders_visuar()
LANGUAGE PLvSQL AS $$
BEGIN
    -- Ensure temp/staging table exists, then refresh its contents
    PERFORM CREATE TABLE IF NOT EXISTS ow_lao.tmp_proc_ods_orders_visuar AS 
        SELECT 
              fecha_de_emision_del_movimiento 
            , codigo_de_formulario 
            , formulario 
            , numero 
            , razon_social 
            , tipo_de_producto 
            , descripcion 
            , codigo_de_producto 
            , descripcion_producto 
            , cantidad_real 
            , monto_sin_impuestos 
            , ABS(total_bonificado)                            AS total_bonificado 
            , condicion_de_pago 
            , canal_de_venta_kd 
            , canal_de_venta_com
            , a.formulario_origen
            , a.nro_origen
            , CASE a.formulario 
                    WHEN 'FACTURA' THEN 'Approved'
                    WHEN 'NOTA DE CRÉDITO' THEN 'returned'
                    ELSE NULL                        
              END                                             AS status     
            , CASE UPPER(SUBSTRING(codigo_de_producto, 1, 2))
                    WHEN 'SA' THEN SUBSTRING(codigo_de_producto, 3)
                    ELSE codigo_de_producto
              END                                             AS reference_code
            , TO_DATE(fecha_de_emision_del_movimiento, 'DD/MM/YYYY')
                                                              AS fecha_de_emision_del_movimiento_formated
            , ROW_NUMBER() OVER(
                    PARTITION BY a.codigo_de_formulario, a.codigo_de_producto, a.numero
                    ORDER BY a.load_timestamp DESC
              )                                               AS dedup
        FROM ow_lao.raw_orders_visuar a
        WHERE 1=0;

    PERFORM TRUNCATE TABLE ow_lao.tmp_proc_ods_orders_visuar;

    PERFORM INSERT INTO ow_lao.tmp_proc_ods_orders_visuar
    (
          fecha_de_emision_del_movimiento 
        , codigo_de_formulario 
        , formulario 
        , numero 
        , razon_social 
        , tipo_de_producto 
        , descripcion 
        , codigo_de_producto 
        , descripcion_producto 
        , cantidad_real 
        , monto_sin_impuestos 
        , total_bonificado 
        , condicion_de_pago 
        , canal_de_venta_kd 
        , canal_de_venta_com
        , formulario_origen
        , nro_origen
        , status     
        , reference_code
        , fecha_de_emision_del_movimiento_formated
        , dedup
    )
    SELECT 
          fecha_de_emision_del_movimiento 
        , codigo_de_formulario 
        , formulario 
        , numero 
        , razon_social 
        , tipo_de_producto 
        , descripcion 
        , codigo_de_producto 
        , descripcion_producto 
        , cantidad_real 
        , monto_sin_impuestos 
        , ABS(total_bonificado)                            AS total_bonificado 
        , condicion_de_pago 
        , canal_de_venta_kd 
        , canal_de_venta_com
        , a.formulario_origen
        , a.nro_origen
        , CASE a.formulario 
                WHEN 'FACTURA' THEN 'Approved'
                WHEN 'NOTA DE CRÉDITO' THEN 'returned'
                ELSE NULL                        
          END                                             AS status     
        , CASE UPPER(SUBSTRING(codigo_de_producto, 1, 2))
                WHEN 'SA' THEN SUBSTRING(codigo_de_producto, 3)
                ELSE codigo_de_producto
          END                                             AS reference_code
        , TO_DATE(fecha_de_emision_del_movimiento, 'DD/MM/YYYY')
                                                          AS fecha_de_emision_del_movimiento_formated
        , ROW_NUMBER() OVER(
                PARTITION BY a.codigo_de_formulario, a.codigo_de_producto, a.numero
                ORDER BY a.load_timestamp DESC
          )                                               AS dedup
    FROM ow_lao.raw_orders_visuar a
    WHERE a.canal_de_venta_kd IN ('ONLINE-MELI', 'ONLINE-Market Place')
      AND a.canal_de_venta_com NOT IN ('TIENDA OFICIAL OSTER MELI', 'TIENDA OFICIAL SMARTLIFE MELI');

    PERFORM DELETE FROM ow_lao.tmp_proc_ods_orders_visuar WHERE dedup <> 1;

    PERFORM INSERT INTO ow_lao.ods_orders_visuar(
              fecha_de_emision_del_movimiento 
            , codigo_de_formulario 
            , formulario 
            , numero 
            , razon_social 
            , tipo_de_producto 
            , descripcion 
            , codigo_de_producto 
            , descripcion_producto 
            , cantidad_real 
            , monto_sin_impuestos 
            , total_bonificado 
            , condicion_de_pago 
            , canal_de_venta_kd 
            , canal_de_venta_com
            , status     
            , reference_code
            , fecha_de_emision_del_movimiento_formated
    )
    SELECT 
              fecha_de_emision_del_movimiento 
            , codigo_de_formulario 
            , formulario 
            , numero 
            , razon_social 
            , tipo_de_producto 
            , descripcion 
            , codigo_de_producto 
            , descripcion_producto 
            , cantidad_real 
            , monto_sin_impuestos 
            , ABS(total_bonificado)                  AS total_bonificado 
            , condicion_de_pago 
            , canal_de_venta_kd 
            , canal_de_venta_com
            , a.status                               AS status     
            , CASE UPPER(SUBSTRING(codigo_de_producto, 1, 2))
                    WHEN 'SA' THEN SUBSTRING(codigo_de_producto, 3)
                    ELSE codigo_de_producto
              END                                     AS reference_code
            , fecha_de_emision_del_movimiento_formated
    FROM ow_lao.tmp_proc_ods_orders_visuar a
    WHERE a.formulario = 'FACTURA' 
      AND a.canal_de_venta_kd IN ('ONLINE-MELI', 'ONLINE-Market Place')
      AND a.canal_de_venta_com NOT IN ('TIENDA OFICIAL OSTER MELI', 'TIENDA OFICIAL SMARTLIFE MELI') 
      AND NOT EXISTS (
            SELECT 1
            FROM ow_lao.ods_orders_visuar aa
            WHERE aa.codigo_de_formulario = a.codigo_de_formulario
              AND aa.codigo_de_producto   = a.codigo_de_producto
              AND aa.numero               = a.numero
      );

    PERFORM UPDATE ow_lao.ods_orders_visuar a
       SET status            = 'returned'
         , updated_timestamp = CURRENT_TIMESTAMP
    FROM ow_lao.tmp_proc_ods_orders_visuar b
    WHERE b.formulario_origen  = a.codigo_de_formulario
      AND b.codigo_de_producto = a.codigo_de_producto
      AND b.nro_origen         = a.numero
      AND b.formulario = 'NOTA DE CRÉDITO' 
      AND a.canal_de_venta_kd IN ('ONLINE-MELI', 'ONLINE-Market Place')
      AND a.canal_de_venta_com NOT IN ('TIENDA OFICIAL OSTER MELI', 'TIENDA OFICIAL SMARTLIFE MELI') 
      AND a.status    <> 'returned';

    PERFORM INSERT INTO ow_lao.ods_orders_visuar(
              fecha_de_emision_del_movimiento 
            , codigo_de_formulario 
            , formulario 
            , numero 
            , razon_social 
            , tipo_de_producto 
            , descripcion 
            , codigo_de_producto 
            , descripcion_producto 
            , cantidad_real 
            , monto_sin_impuestos 
            , total_bonificado 
            , condicion_de_pago 
            , canal_de_venta_kd 
            , canal_de_venta_com
            , status     
            , reference_code
            , fecha_de_emision_del_movimiento_formated
    )
    SELECT 
              fecha_de_emision_del_movimiento 
            , codigo_de_formulario 
            , formulario 
            , numero 
            , razon_social 
            , tipo_de_producto 
            , descripcion 
            , codigo_de_producto 
            , descripcion_producto 
            , cantidad_real 
            , monto_sin_impuestos 
            , ABS(total_bonificado)                  AS total_bonificado 
            , condicion_de_pago 
            , canal_de_venta_kd 
            , canal_de_venta_com
            , status                                 AS status     
            , CASE UPPER(SUBSTRING(codigo_de_producto, 1, 2))
                    WHEN 'SA' THEN SUBSTRING(codigo_de_producto, 3)
                    ELSE codigo_de_producto
              END                                     AS reference_code
            , fecha_de_emision_del_movimiento_formated
    FROM ow_lao.tmp_proc_ods_orders_visuar a
    WHERE formulario = 'NOTA DE CRÉDITO'  
      AND a.canal_de_venta_kd IN ('ONLINE-MELI', 'ONLINE-Market Place')
      AND a.canal_de_venta_com NOT IN ('TIENDA OFICIAL OSTER MELI', 'TIENDA OFICIAL SMARTLIFE MELI') 
      AND NOT EXISTS (
            SELECT 1
            FROM ow_lao.ods_orders_visuar aa
            WHERE aa.codigo_de_formulario = a.codigo_de_formulario
              AND aa.codigo_de_producto   = a.codigo_de_producto
              AND aa.numero               = a.numero
      );

END;
$$;

-- CALL ow_lao.proc_ods_orders_visuar();
-- ERROR: Severity: ERROR, Message: Cannot set a NOT NULL column (ID) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure proc_ods_orders_visuar line 106 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3216, Error Code: 2502, 
-- CALL ow_lao.proc_ods_orders_visuar();
-- ERROR: Severity: ERROR, Message: Cannot set a NOT NULL column (ID) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure proc_ods_orders_visuar line 106 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3216, Error Code: 2502, 
CREATE OR REPLACE PROCEDURE ow_lao.proc_ods_orders_visuar()
LANGUAGE PLvSQL AS $$
BEGIN
    -- Ensure temp/staging table exists, then refresh its contents
    PERFORM CREATE TABLE IF NOT EXISTS ow_lao.tmp_proc_ods_orders_visuar AS 
        SELECT 
              fecha_de_emision_del_movimiento 
            , codigo_de_formulario 
            , formulario 
            , numero 
            , razon_social 
            , tipo_de_producto 
            , descripcion 
            , codigo_de_producto 
            , descripcion_producto 
            , cantidad_real 
            , monto_sin_impuestos 
            , ABS(total_bonificado)                            AS total_bonificado 
            , condicion_de_pago 
            , canal_de_venta_kd 
            , canal_de_venta_com
            , a.formulario_origen
            , a.nro_origen
            , CASE a.formulario 
                    WHEN 'FACTURA' THEN 'Approved'
                    WHEN 'NOTA DE CRÉDITO' THEN 'returned'
                    ELSE NULL                        
              END                                             AS status     
            , CASE UPPER(SUBSTRING(codigo_de_producto, 1, 2))
                    WHEN 'SA' THEN SUBSTRING(codigo_de_producto, 3)
                    ELSE codigo_de_producto
              END                                             AS reference_code
            , TO_DATE(fecha_de_emision_del_movimiento, 'DD/MM/YYYY')
                                                              AS fecha_de_emision_del_movimiento_formated
            , ROW_NUMBER() OVER(
                    PARTITION BY a.codigo_de_formulario, a.codigo_de_producto, a.numero
                    ORDER BY a.load_timestamp DESC
              )                                               AS dedup
        FROM ow_lao.raw_orders_visuar a
        WHERE 1=0;

    PERFORM TRUNCATE TABLE ow_lao.tmp_proc_ods_orders_visuar;

    PERFORM INSERT INTO ow_lao.tmp_proc_ods_orders_visuar
    (
          fecha_de_emision_del_movimiento 
        , codigo_de_formulario 
        , formulario 
        , numero 
        , razon_social 
        , tipo_de_producto 
        , descripcion 
        , codigo_de_producto 
        , descripcion_producto 
        , cantidad_real 
        , monto_sin_impuestos 
        , total_bonificado 
        , condicion_de_pago 
        , canal_de_venta_kd 
        , canal_de_venta_com
        , formulario_origen
        , nro_origen
        , status     
        , reference_code
        , fecha_de_emision_del_movimiento_formated
        , dedup
    )
    SELECT 
          fecha_de_emision_del_movimiento 
        , codigo_de_formulario 
        , formulario 
        , numero 
        , razon_social 
        , tipo_de_producto 
        , descripcion 
        , codigo_de_producto 
        , descripcion_producto 
        , cantidad_real 
        , monto_sin_impuestos 
        , ABS(total_bonificado)                            AS total_bonificado 
        , condicion_de_pago 
        , canal_de_venta_kd 
        , canal_de_venta_com
        , a.formulario_origen
        , a.nro_origen
        , CASE a.formulario 
                WHEN 'FACTURA' THEN 'Approved'
                WHEN 'NOTA DE CRÉDITO' THEN 'returned'
                ELSE NULL                        
          END                                             AS status     
        , CASE UPPER(SUBSTRING(codigo_de_producto, 1, 2))
                WHEN 'SA' THEN SUBSTRING(codigo_de_producto, 3)
                ELSE codigo_de_producto
          END                                             AS reference_code
        , TO_DATE(fecha_de_emision_del_movimiento, 'DD/MM/YYYY')
                                                          AS fecha_de_emision_del_movimiento_formated
        , ROW_NUMBER() OVER(
                PARTITION BY a.codigo_de_formulario, a.codigo_de_producto, a.numero
                ORDER BY a.load_timestamp DESC
          )                                               AS dedup
    FROM ow_lao.raw_orders_visuar a
    WHERE a.canal_de_venta_kd IN ('ONLINE-MELI', 'ONLINE-Market Place')
      AND a.canal_de_venta_com NOT IN ('TIENDA OFICIAL OSTER MELI', 'TIENDA OFICIAL SMARTLIFE MELI');

    PERFORM DELETE FROM ow_lao.tmp_proc_ods_orders_visuar WHERE dedup <> 1;

    PERFORM INSERT INTO ow_lao.ods_orders_visuar(
              id
            , fecha_de_emision_del_movimiento 
            , codigo_de_formulario 
            , formulario 
            , numero 
            , razon_social 
            , tipo_de_producto 
            , descripcion 
            , codigo_de_producto 
            , descripcion_producto 
            , cantidad_real 
            , monto_sin_impuestos 
            , total_bonificado 
            , condicion_de_pago 
            , canal_de_venta_kd 
            , canal_de_venta_com
            , status     
            , reference_code
            , fecha_de_emision_del_movimiento_formated
    )
    SELECT 
              a.codigo_de_formulario || '||' || a.codigo_de_producto || '||' || a.numero AS id
            , fecha_de_emision_del_movimiento 
            , codigo_de_formulario 
            , formulario 
            , numero 
            , razon_social 
            , tipo_de_producto 
            , descripcion 
            , codigo_de_producto 
            , descripcion_producto 
            , cantidad_real 
            , monto_sin_impuestos 
            , ABS(total_bonificado)                  AS total_bonificado 
            , condicion_de_pago 
            , canal_de_venta_kd 
            , canal_de_venta_com
            , a.status                               AS status     
            , CASE UPPER(SUBSTRING(codigo_de_producto, 1, 2))
                    WHEN 'SA' THEN SUBSTRING(codigo_de_producto, 3)
                    ELSE codigo_de_producto
              END                                     AS reference_code
            , fecha_de_emision_del_movimiento_formated
    FROM ow_lao.tmp_proc_ods_orders_visuar a
    WHERE a.formulario = 'FACTURA' 
      AND a.canal_de_venta_kd IN ('ONLINE-MELI', 'ONLINE-Market Place')
      AND a.canal_de_venta_com NOT IN ('TIENDA OFICIAL OSTER MELI', 'TIENDA OFICIAL SMARTLIFE MELI') 
      AND NOT EXISTS (
            SELECT 1
            FROM ow_lao.ods_orders_visuar aa
            WHERE aa.codigo_de_formulario = a.codigo_de_formulario
              AND aa.codigo_de_producto   = a.codigo_de_producto
              AND aa.numero               = a.numero
      );

    PERFORM UPDATE ow_lao.ods_orders_visuar a
       SET status            = 'returned'
         , updated_timestamp = CURRENT_TIMESTAMP
    FROM ow_lao.tmp_proc_ods_orders_visuar b
    WHERE b.formulario_origen  = a.codigo_de_formulario
      AND b.codigo_de_producto = a.codigo_de_producto
      AND b.nro_origen         = a.numero
      AND b.formulario = 'NOTA DE CRÉDITO' 
      AND a.canal_de_venta_kd IN ('ONLINE-MELI', 'ONLINE-Market Place')
      AND a.canal_de_venta_com NOT IN ('TIENDA OFICIAL OSTER MELI', 'TIENDA OFICIAL SMARTLIFE MELI') 
      AND a.status    <> 'returned';

    PERFORM INSERT INTO ow_lao.ods_orders_visuar(
              id
            , fecha_de_emision_del_movimiento 
            , codigo_de_formulario 
            , formulario 
            , numero 
            , razon_social 
            , tipo_de_producto 
            , descripcion 
            , codigo_de_producto 
            , descripcion_producto 
            , cantidad_real 
            , monto_sin_impuestos 
            , total_bonificado 
            , condicion_de_pago 
            , canal_de_venta_kd 
            , canal_de_venta_com
            , status     
            , reference_code
            , fecha_de_emision_del_movimiento_formated
    )
    SELECT 
              a.codigo_de_formulario || '||' || a.codigo_de_producto || '||' || a.numero AS id
            , fecha_de_emision_del_movimiento 
            , codigo_de_formulario 
            , formulario 
            , numero 
            , razon_social 
            , tipo_de_producto 
            , descripcion 
            , codigo_de_producto 
            , descripcion_producto 
            , cantidad_real 
            , monto_sin_impuestos 
            , ABS(total_bonificado)                  AS total_bonificado 
            , condicion_de_pago 
            , canal_de_venta_kd 
            , canal_de_venta_com
            , status                                 AS status     
            , CASE UPPER(SUBSTRING(codigo_de_producto, 1, 2))
                    WHEN 'SA' THEN SUBSTRING(codigo_de_producto, 3)
                    ELSE codigo_de_producto
              END                                     AS reference_code
            , fecha_de_emision_del_movimiento_formated
    FROM ow_lao.tmp_proc_ods_orders_visuar a
    WHERE formulario = 'NOTA DE CRÉDITO'  
      AND a.canal_de_venta_kd IN ('ONLINE-MELI', 'ONLINE-Market Place')
      AND a.canal_de_venta_com NOT IN ('TIENDA OFICIAL OSTER MELI', 'TIENDA OFICIAL SMARTLIFE MELI') 
      AND NOT EXISTS (
            SELECT 1
            FROM ow_lao.ods_orders_visuar aa
            WHERE aa.codigo_de_formulario = a.codigo_de_formulario
              AND aa.codigo_de_producto   = a.codigo_de_producto
              AND aa.numero               = a.numero
      );

END;
$$;

-- CALL ow_lao.proc_ods_orders_visuar();
-- ERROR: Severity: ERROR, Message: Column "id" is of type int but expression is of type varchar, Sqlstate: 42804, Hint: You will need to rewrite or cast the expression, Where: PL/vSQL procedure proc_ods_orders_visuar line 106 at static SQL, Routine: updateTargetListEntry, File: parse_target.c, Line: 853, Error Code: 2631, 
-- CALL ow_lao.proc_ods_orders_visuar();
-- ERROR: Severity: ERROR, Message: Column "id" is of type int but expression is of type varchar, Sqlstate: 42804, Hint: You will need to rewrite or cast the expression, Where: PL/vSQL procedure proc_ods_orders_visuar line 106 at static SQL, Routine: updateTargetListEntry, File: parse_target.c, Line: 853, Error Code: 2631, 
SELECT column_name, data_type FROM columns WHERE table_schema='ow_lao' AND table_name='ods_orders_visuar' AND column_name ILIKE 'id';
-- column_name | data_type
-- ------------+----------

SELECT column_name, data_type FROM columns WHERE table_schema='ow_lao' AND table_name='ods_orders_visuar' ORDER BY ordinal_position;
-- column_name | data_type
-- ------------+----------

SELECT HASH('A') AS h, HASH('A','B') AS h2;
-- h | h2
-- --+---
-- 2550622213724731536 | 12669197225334684

SELECT column_name, data_type, data_type_length, is_nullable, numeric_precision, numeric_scale, ordinal_position
FROM v_catalog.columns
WHERE table_schema='ow_lao' AND table_name='ods_orders_visuar'
ORDER BY ordinal_position;
-- column_name | data_type | data_type_length | is_nullable | numeric_precision | numeric_scale | ordinal_position
-- ------------+-----------+------------------+-------------+-------------------+---------------+-----------------

CREATE OR REPLACE PROCEDURE ow_lao.proc_ods_orders_visuar()
LANGUAGE PLvSQL AS $$
DECLARE
    v_max_id INT;
BEGIN
    -- Ensure temp/staging table exists, then refresh its contents
    PERFORM CREATE TABLE IF NOT EXISTS ow_lao.tmp_proc_ods_orders_visuar AS 
        SELECT 
              fecha_de_emision_del_movimiento 
            , codigo_de_formulario 
            , formulario 
            , numero 
            , razon_social 
            , tipo_de_producto 
            , descripcion 
            , codigo_de_producto 
            , descripcion_producto 
            , cantidad_real 
            , monto_sin_impuestos 
            , ABS(total_bonificado)                            AS total_bonificado 
            , condicion_de_pago 
            , canal_de_venta_kd 
            , canal_de_venta_com
            , a.formulario_origen
            , a.nro_origen
            , CASE a.formulario 
                    WHEN 'FACTURA' THEN 'Approved'
                    WHEN 'NOTA DE CRÉDITO' THEN 'returned'
                    ELSE NULL                        
              END                                             AS status     
            , CASE UPPER(SUBSTRING(codigo_de_producto, 1, 2))
                    WHEN 'SA' THEN SUBSTRING(codigo_de_producto, 3)
                    ELSE codigo_de_producto
              END                                             AS reference_code
            , TO_DATE(fecha_de_emision_del_movimiento, 'DD/MM/YYYY')
                                                              AS fecha_de_emision_del_movimiento_formated
            , ROW_NUMBER() OVER(
                    PARTITION BY a.codigo_de_formulario, a.codigo_de_producto, a.numero
                    ORDER BY a.load_timestamp DESC
              )                                               AS dedup
        FROM ow_lao.raw_orders_visuar a
        WHERE 1=0;

    PERFORM TRUNCATE TABLE ow_lao.tmp_proc_ods_orders_visuar;

    PERFORM INSERT INTO ow_lao.tmp_proc_ods_orders_visuar
    (
          fecha_de_emision_del_movimiento 
        , codigo_de_formulario 
        , formulario 
        , numero 
        , razon_social 
        , tipo_de_producto 
        , descripcion 
        , codigo_de_producto 
        , descripcion_producto 
        , cantidad_real 
        , monto_sin_impuestos 
        , total_bonificado 
        , condicion_de_pago 
        , canal_de_venta_kd 
        , canal_de_venta_com
        , formulario_origen
        , nro_origen
        , status     
        , reference_code
        , fecha_de_emision_del_movimiento_formated
        , dedup
    )
    SELECT 
          fecha_de_emision_del_movimiento 
        , codigo_de_formulario 
        , formulario 
        , numero 
        , razon_social 
        , tipo_de_producto 
        , descripcion 
        , codigo_de_producto 
        , descripcion_producto 
        , cantidad_real 
        , monto_sin_impuestos 
        , ABS(total_bonificado)                            AS total_bonificado 
        , condicion_de_pago 
        , canal_de_venta_kd 
        , canal_de_venta_com
        , a.formulario_origen
        , a.nro_origen
        , CASE a.formulario 
                WHEN 'FACTURA' THEN 'Approved'
                WHEN 'NOTA DE CRÉDITO' THEN 'returned'
                ELSE NULL                        
          END                                             AS status     
        , CASE UPPER(SUBSTRING(codigo_de_producto, 1, 2))
                WHEN 'SA' THEN SUBSTRING(codigo_de_producto, 3)
                ELSE codigo_de_producto
          END                                             AS reference_code
        , TO_DATE(fecha_de_emision_del_movimiento, 'DD/MM/YYYY')
                                                          AS fecha_de_emision_del_movimiento_formated
        , ROW_NUMBER() OVER(
                PARTITION BY a.codigo_de_formulario, a.codigo_de_producto, a.numero
                ORDER BY a.load_timestamp DESC
          )                                               AS dedup
    FROM ow_lao.raw_orders_visuar a
    WHERE a.canal_de_venta_kd IN ('ONLINE-MELI', 'ONLINE-Market Place')
      AND a.canal_de_venta_com NOT IN ('TIENDA OFICIAL OSTER MELI', 'TIENDA OFICIAL SMARTLIFE MELI');

    PERFORM DELETE FROM ow_lao.tmp_proc_ods_orders_visuar WHERE dedup <> 1;

    -- First batch insert for FACTURA
    SELECT COALESCE(MAX(id), 0) INTO v_max_id FROM ow_lao.ods_orders_visuar;

    PERFORM INSERT INTO ow_lao.ods_orders_visuar(
              id
            , fecha_de_emision_del_movimiento 
            , codigo_de_formulario 
            , formulario 
            , numero 
            , razon_social 
            , tipo_de_producto 
            , descripcion 
            , codigo_de_producto 
            , descripcion_producto 
            , cantidad_real 
            , monto_sin_impuestos 
            , total_bonificado 
            , condicion_de_pago 
            , canal_de_venta_kd 
            , canal_de_venta_com
            , status     
            , reference_code
            , fecha_de_emision_del_movimiento_formated
    )
    SELECT 
              v_max_id + ROW_NUMBER() OVER (ORDER BY a.codigo_de_formulario, a.codigo_de_producto, a.numero) AS id
            , fecha_de_emision_del_movimiento 
            , codigo_de_formulario 
            , formulario 
            , numero 
            , razon_social 
            , tipo_de_producto 
            , descripcion 
            , codigo_de_producto 
            , descripcion_producto 
            , cantidad_real 
            , monto_sin_impuestos 
            , ABS(total_bonificado)                  AS total_bonificado 
            , condicion_de_pago 
            , canal_de_venta_kd 
            , canal_de_venta_com
            , a.status                               AS status     
            , CASE UPPER(SUBSTRING(codigo_de_producto, 1, 2))
                    WHEN 'SA' THEN SUBSTRING(codigo_de_producto, 3)
                    ELSE codigo_de_producto
              END                                     AS reference_code
            , fecha_de_emision_del_movimiento_formated
    FROM ow_lao.tmp_proc_ods_orders_visuar a
    WHERE a.formulario = 'FACTURA' 
      AND a.canal_de_venta_kd IN ('ONLINE-MELI', 'ONLINE-Market Place')
      AND a.canal_de_venta_com NOT IN ('TIENDA OFICIAL OSTER MELI', 'TIENDA OFICIAL SMARTLIFE MELI') 
      AND NOT EXISTS (
            SELECT 1
            FROM ow_lao.ods_orders_visuar aa
            WHERE aa.codigo_de_formulario = a.codigo_de_formulario
              AND aa.codigo_de_producto   = a.codigo_de_producto
              AND aa.numero               = a.numero
      );

    -- Update returned status from credit notes
    PERFORM UPDATE ow_lao.ods_orders_visuar a
       SET status            = 'returned'
         , updated_timestamp = CURRENT_TIMESTAMP
    FROM ow_lao.tmp_proc_ods_orders_visuar b
    WHERE b.formulario_origen  = a.codigo_de_formulario
      AND b.codigo_de_producto = a.codigo_de_producto
      AND b.nro_origen         = a.numero
      AND b.formulario = 'NOTA DE CRÉDITO' 
      AND a.canal_de_venta_kd IN ('ONLINE-MELI', 'ONLINE-Market Place')
      AND a.canal_de_venta_com NOT IN ('TIENDA OFICIAL OSTER MELI', 'TIENDA OFICIAL SMARTLIFE MELI') 
      AND a.status    <> 'returned';

    -- Second batch insert for credit notes
    SELECT COALESCE(MAX(id), 0) INTO v_max_id FROM ow_lao.ods_orders_visuar;

    PERFORM INSERT INTO ow_lao.ods_orders_visuar(
              id
            , fecha_de_emision_del_movimiento 
            , codigo_de_formulario 
            , formulario 
            , numero 
            , razon_social 
            , tipo_de_producto 
            , descripcion 
            , codigo_de_producto 
            , descripcion_producto 
            , cantidad_real 
            , monto_sin_impuestos 
            , total_bonificado 
            , condicion_de_pago 
            , canal_de_venta_kd 
            , canal_de_venta_com
            , status     
            , reference_code
            , fecha_de_emision_del_movimiento_formated
    )
    SELECT 
              v_max_id + ROW_NUMBER() OVER (ORDER BY a.codigo_de_formulario, a.codigo_de_producto, a.numero) AS id
            , fecha_de_emision_del_movimiento 
            , codigo_de_formulario 
            , formulario 
            , numero 
            , razon_social 
            , tipo_de_producto 
            , descripcion 
            , codigo_de_producto 
            , descripcion_producto 
            , cantidad_real 
            , monto_sin_impuestos 
            , ABS(total_bonificado)                  AS total_bonificado 
            , condicion_de_pago 
            , canal_de_venta_kd 
            , canal_de_venta_com
            , status                                 AS status     
            , CASE UPPER(SUBSTRING(codigo_de_producto, 1, 2))
                    WHEN 'SA' THEN SUBSTRING(codigo_de_producto, 3)
                    ELSE codigo_de_producto
              END                                     AS reference_code
            , fecha_de_emision_del_movimiento_formated
    FROM ow_lao.tmp_proc_ods_orders_visuar a
    WHERE formulario = 'NOTA DE CRÉDITO'  
      AND a.canal_de_venta_kd IN ('ONLINE-MELI', 'ONLINE-Market Place')
      AND a.canal_de_venta_com NOT IN ('TIENDA OFICIAL OSTER MELI', 'TIENDA OFICIAL SMARTLIFE MELI') 
      AND NOT EXISTS (
            SELECT 1
            FROM ow_lao.ods_orders_visuar aa
            WHERE aa.codigo_de_formulario = a.codigo_de_formulario
              AND aa.codigo_de_producto   = a.codigo_de_producto
              AND aa.numero               = a.numero
      );

END;
$$;

CALL ow_lao.proc_ods_orders_visuar();
-- proc_ods_orders_visuar
-- ----------------------
-- 0

