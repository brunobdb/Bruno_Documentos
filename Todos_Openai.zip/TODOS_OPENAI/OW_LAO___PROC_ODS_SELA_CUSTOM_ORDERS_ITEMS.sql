CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_sela_custom_orders_items()
LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM MERGE INTO ow_lao.ods_sela_custom_orders_items a
    USING ow_lao.stg_sela_custom_orders_items b
      ON b.subsidiary_id = a.subsidiary_id
     AND b.account       = a.account
     AND b.order_id      = a.order_id
     AND b.item_id       = a.item_id
    WHEN MATCHED THEN UPDATE SET
         a.updated_timestamp                           = CURRENT_TIMESTAMP
       , a.order_entity_id                             = b.order_entity_id
       , a.status                                      = b.status
       , a.creation_date                               = b.creation_date
       , a.payment_approved_date                       = b.payment_approved_date
       , a.invoice_date                                = b.invoice_date
       , a.shipping_estimate_date                      = b.shipping_estimate_date
       , a.handling_date                               = b.handling_date
       , a.delivered_date                              = b.delivered_date
       , a.payment_type                                = b.payment_type
       , a.payment_brand                               = b.payment_brand
       , a.qty_installments                            = b.qty_installments
       , a.cancelation_date                            = b.cancelation_date
       , a.shipping_cost1                              = b.shipping_cost1
       , a.units                                       = b.units
       , a.channel                                     = b.channel
       , a.discount1                                   = b.discount1
       , a.consumer_id                                 = b.consumer_id
       , a.currency_code                               = b.currency_code
       , a.coupon_code                                 = b.coupon_code
       , a.rule_action                                 = b.rule_action
       , a.rule_label                                  = b.rule_label
       , a.total_order                                 = b.total_order
       , a.code                                        = b.code
       , a.sku_operador                                = b.sku_operador
       , a.description                                 = b.description
       , a.price                                       = b.price
       , a.quantity                                    = b.quantity
       , a.shipping_cost                               = b.shipping_cost
       , a.discount                                    = b.discount
       , a.billing_address_firstname                   = b.billing_address_firstname
       , a.billing_address_lastname                    = b.billing_address_lastname
       , a.billing_address_customer_identification     = b.billing_address_customer_identification
       , a.billing_address_id_type                     = b.billing_address_id_type
       , a.billing_address_invoice_type                = b.billing_address_invoice_type
       , a.billing_address_email                       = b.billing_address_email
       , a.billing_address_street                      = b.billing_address_street
       , a.billing_address_city                        = b.billing_address_city
       , a.billing_address_zone                        = b.billing_address_zone
       , a.billing_address_municipality                = b.billing_address_municipality
       , a.billing_address_state                       = b.billing_address_state
       , a.billing_address_country                     = b.billing_address_country
       , a.billing_address_phone_number                = b.billing_address_phone_number
       , a.billing_address_postal_code                 = b.billing_address_postal_code
       , a.billing_address_reference                   = b.billing_address_reference
       , a.billing_address_reference_two               = b.billing_address_reference_two
       , a.shipping_address_first_name                 = b.shipping_address_first_name
       , a.shipping_address_last_name                  = b.shipping_address_last_name
       , a.shipping_address_customer_identification    = b.shipping_address_customer_identification
       , a.shipping_address_id_type                    = b.shipping_address_id_type
       , a.shipping_address_invoice_type               = b.shipping_address_invoice_type
       , a.shipping_address_email                      = b.shipping_address_email
       , a.shipping_address_street                     = b.shipping_address_street
       , a.shipping_address_city                       = b.shipping_address_city
       , a.shipping_address_zone                       = b.shipping_address_zone
       , a.shipping_address_municipality               = b.shipping_address_municipality
       , a.shipping_address_state                      = b.shipping_address_state
       , a.shipping_address_country                    = b.shipping_address_country
       , a.shipping_address_phone_number               = b.shipping_address_phone_number
       , a.shipping_address_postal_code                = b.shipping_address_postal_code
       , a.shipping_address_reference                  = b.shipping_address_reference
       , a.shipping_address_reference_two              = b.shipping_address_reference_two
       , a.shipping_and_handling                       = b.shipping_and_handling
       , a.payment_information_epayserver_cuotas       = b.payment_information_epayserver_cuotas
       , a.payment_information_method_title            = b.payment_information_method_title
       , a.payment_information_metodo                  = b.payment_information_metodo
       , a.payment_information_auditnumber             = b.payment_information_auditnumber
       , a.payment_information_authorizationnumber     = b.payment_information_authorizationnumber
       , a.payment_information_numero_referencia       = b.payment_information_numero_referencia
       , a.payment_information_cantidad_cuotas         = b.payment_information_cantidad_cuotas
       , a.payment_information_ultimos_digitos_tarjeta = b.payment_information_ultimos_digitos_tarjeta
       , a.payment_information_monto_pagado            = b.payment_information_monto_pagado
       , a.payment_information_purchase_datetime       = b.payment_information_purchase_datetime
       , a.payment_information_clearsalesessionid      = b.payment_information_clearsalesessionid
       , a.payment_information_clearsale               = b.payment_information_clearsale
       , a.payment_information_credomatic_cuotas       = b.payment_information_credomatic_cuotas
       , a.payment_information_authcode                = b.payment_information_authcode
       , a.payment_information_transactionid           = b.payment_information_transactionid
       , a.payment_information_instructions            = b.payment_information_instructions
       , a.device                                      = b.device
    WHEN NOT MATCHED THEN INSERT (
         updated_timestamp    
       , order_id
       , order_entity_id
       , status
       , creation_date
       , payment_approved_date
       , invoice_date
       , shipping_estimate_date
       , handling_date
       , delivered_date
       , payment_type
       , payment_brand
       , qty_installments
       , cancelation_date
       , shipping_cost1
       , units
       , channel
       , discount1
       , consumer_id
       , currency_code
       , coupon_code
       , rule_action
       , rule_label
       , total_order
       , item_id
       , code
       , sku_operador
       , description
       , price
       , quantity
       , shipping_cost
       , discount
       , billing_address_firstname
       , billing_address_lastname
       , billing_address_customer_identification
       , billing_address_id_type
       , billing_address_invoice_type
       , billing_address_email
       , billing_address_street
       , billing_address_city
       , billing_address_zone
       , billing_address_municipality
       , billing_address_state
       , billing_address_country
       , billing_address_phone_number
       , billing_address_postal_code
       , billing_address_reference
       , billing_address_reference_two
       , shipping_address_first_name
       , shipping_address_last_name
       , shipping_address_customer_identification
       , shipping_address_id_type
       , shipping_address_invoice_type
       , shipping_address_email
       , shipping_address_street
       , shipping_address_city
       , shipping_address_zone
       , shipping_address_municipality
       , shipping_address_state
       , shipping_address_country
       , shipping_address_phone_number
       , shipping_address_postal_code
       , shipping_address_reference
       , shipping_address_reference_two
       , shipping_and_handling
       , payment_information_epayserver_cuotas
       , payment_information_method_title
       , payment_information_metodo
       , payment_information_auditnumber
       , payment_information_authorizationnumber
       , payment_information_numero_referencia
       , payment_information_cantidad_cuotas
       , payment_information_ultimos_digitos_tarjeta
       , payment_information_monto_pagado
       , payment_information_purchase_datetime
       , payment_information_clearsalesessionid
       , payment_information_clearsale
       , payment_information_credomatic_cuotas
       , payment_information_authcode
       , payment_information_transactionid
       , payment_information_instructions
       , subsidiary_id
       , account
       , device         
    ) VALUES (
         CURRENT_TIMESTAMP
       , b.order_id
       , b.order_entity_id
       , b.status
       , b.creation_date
       , b.payment_approved_date
       , b.invoice_date
       , b.shipping_estimate_date
       , b.handling_date
       , b.delivered_date
       , b.payment_type
       , b.payment_brand
       , b.qty_installments
       , b.cancelation_date
       , b.shipping_cost1
       , b.units
       , b.channel
       , b.discount1
       , b.consumer_id
       , b.currency_code
       , b.coupon_code
       , b.rule_action
       , b.rule_label
       , b.total_order
       , b.item_id
       , b.code
       , b.sku_operador
       , b.description
       , b.price
       , b.quantity
       , b.shipping_cost
       , b.discount
       , b.billing_address_firstname
       , b.billing_address_lastname
       , b.billing_address_customer_identification
       , b.billing_address_id_type
       , b.billing_address_invoice_type
       , b.billing_address_email
       , b.billing_address_street
       , b.billing_address_city
       , b.billing_address_zone
       , b.billing_address_municipality
       , b.billing_address_state
       , b.billing_address_country
       , b.billing_address_phone_number
       , b.billing_address_postal_code
       , b.billing_address_reference
       , b.billing_address_reference_two
       , b.shipping_address_first_name
       , b.shipping_address_last_name
       , b.shipping_address_customer_identification
       , b.shipping_address_id_type
       , b.shipping_address_invoice_type
       , b.shipping_address_email
       , b.shipping_address_street
       , b.shipping_address_city
       , b.shipping_address_zone
       , b.shipping_address_municipality
       , b.shipping_address_state
       , b.shipping_address_country
       , b.shipping_address_phone_number
       , b.shipping_address_postal_code
       , b.shipping_address_reference
       , b.shipping_address_reference_two
       , b.shipping_and_handling
       , b.payment_information_epayserver_cuotas
       , b.payment_information_method_title
       , b.payment_information_metodo
       , b.payment_information_auditnumber
       , b.payment_information_authorizationnumber
       , b.payment_information_numero_referencia
       , b.payment_information_cantidad_cuotas
       , b.payment_information_ultimos_digitos_tarjeta
       , b.payment_information_monto_pagado
       , b.payment_information_purchase_datetime
       , b.payment_information_clearsalesessionid
       , b.payment_information_clearsale
       , b.payment_information_credomatic_cuotas
       , b.payment_information_authcode
       , b.payment_information_transactionid
       , b.payment_information_instructions
       , b.subsidiary_id
       , b.account
       , b.device
    );
END;
$$;

-- CALL OW_LAO.proc_ods_sela_custom_orders_items();
-- ERROR: Severity: ERROR, Message: Relation "ow_lao.stg_sela_custom_orders_items" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ods_sela_custom_orders_items line 3 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
-- CALL OW_LAO.proc_ods_sela_custom_orders_items();
-- ERROR: Severity: ERROR, Message: Relation "ow_lao.stg_sela_custom_orders_items" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ods_sela_custom_orders_items line 3 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
