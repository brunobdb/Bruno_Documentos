-- CREATE OR REPLACE PROCEDURE PROC_GSMARENA_MAPPING_1_0()
-- LANGUAGE PLvSQL AS $$
-- BEGIN
-- -- Data Clean 
-- PERFORM TRUNCATE TABLE ODS_GSM_ARENA_STAGE;
-- PERFORM INSERT INTO ODS_GSM_ARENA_STAGE
-- 	  SELECT  
-- 	 	"brand_nm"
-- 	 , "model_code"
-- 	 , "model_nm"
-- 	 , "mktcode"
-- 	 , "mktname"
-- 	 , MAX("width_mm") "width_mm"
-- 	 , MAX("height_mm") "height_mm"
-- 	 , MAX("depth_mm") "depth_mm"
-- 	 , MAX("display_size") "display_size"
-- 	 , MAX("ram_in_mb") "ram_in_mb"
-- 	 , MAX("internal_storage") "internal_storage"
-- 	 , MAX("dual_sim") "dual_sim"
-- 	 , MAX("main_camera_mp") "main_camera_mp"
-- 	 , MAX("front_camera_mp") "front_camera_mp"
-- 	 , MAX("weight_gramm") "weight_gramm"
-- 	 , MAX("resolution_wid") "resolution_wid"
-- 	 , MAX("resolution_hig") "resolution_hig"
-- 	 , MAX("battery_capacity") "battery_capacity"
-- 	 FROM (
-- 	SELECT distinct "brand" "brand_nm", "modelcode" "model_code", "modelnm" "model_nm","mktcode" "mktcode","mktnm" "mktname"
-- 		, CASE
-- 			WHEN ( UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" = 'Dimensions_width_in_MM' ) AND "value" is not null  
-- 				THEN "value"
-- 			WHEN  "displaynm" = 'Dimensions_Width'
-- 				THEN "value"
-- 		  END "width_mm"
-- 		, CASE
-- 			WHEN ( UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" = 'Dimensions_height_in_MM')  AND "value" is not null  
-- 				THEN "value"
-- 			WHEN  "displaynm" = 'Dimensions_Length'
-- 				THEN "value"
-- 		  END "height_mm"
-- 		, CASE
-- 			WHEN ( UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" = 'Dimensions_depth_in_MM' ) AND "value" is not null  
-- 				THEN "value"
-- 			WHEN  "displaynm" = 'Dimensions_Thickness'
-- 				THEN "value"
-- 		  END "depth_mm"
-- 		, CASE
-- 			WHEN ( UPPER("subcategory") LIKE '%DISPLAY SIZE%' AND "displaynm" = 'Display_Display size' )  THEN "value" 
-- 		  END "display_size"
-- 		, CASE
-- 			WHEN ( UPPER("subcategory") LIKE '%RAM%' AND "displaynm" = 'RAM_RAM Quantity' ) THEN "value" 
-- 		  END "ram_in_mb"
-- 		, CASE
-- 			WHEN ( UPPER("subcategory") LIKE '%INTERNAL%' AND "displaynm" = 'Internal storage' ) THEN "value" 
-- 		  END "internal_storage"
-- 		, CASE
-- 			WHEN ( UPPER("subcategory") LIKE '%DUAL%' AND "displaynm" = 'Cellular_Dual SIM' ) THEN "value" 
-- 		  END "dual_sim"
-- 		, CASE
-- 			WHEN ( UPPER("subcategory") LIKE '%CAMERA%' AND "displaynm" = 'Main camera_Resolution' ) THEN "value" 
-- 		  END "main_camera_mp"
-- 		, CASE
-- 			WHEN ( UPPER("subcategory") LIKE '%FRONT%' AND "displaynm" = 'Front_Resolution' ) THEN "value" 
-- 		  END "front_camera_mp"
-- 		, CASE
-- 			WHEN ( UPPER("subcategory") LIKE '%WEIGHT%' AND "displaynm" = 'Weight_Weight in Grams' ) THEN "value" 
-- 		  END "weight_gramm"
-- 		, CASE
-- 			WHEN ( UPPER("subcategory") LIKE '%RESOLUTION%' AND "displaynm" = 'Resolution_Horizontal' ) THEN "value" 
-- 		  END "resolution_wid"
-- 		, CASE
-- 			WHEN ( UPPER("subcategory") LIKE '%RESOLUTION%' AND "displaynm" = 'Resolution_Vertical' ) THEN "value" 
-- 		  END "resolution_hig"
-- 		, CASE
-- 			WHEN ( UPPER("subcategory") LIKE '%CAPACITY%' AND "displaynm" = 'Battery_Capacity' ) THEN "value" 
-- 		  END "battery_capacity"
-- 	   , CASE
-- 			WHEN ( "displaynm" = 'Availability_Date' ) THEN "value" 
-- 		  END "availability_date"
-- 		  , "etcstatus"
-- 	 FROM ODS_GSM_ARENA_TMP
-- 	 WHERE (
-- 	   ( UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" IN ('Dimensions_width_in_MM', 'Dimensions_Width') ) -- Width
-- 	 OR ( UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" IN ( 'Dimensions_height_in_MM', 'Dimensions_Length' )) -- Height
-- 	 OR ( UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" IN ( 'Dimensions_depth_in_MM', 'Dimensions_Thickness' )) --Thickness
-- 	 OR ( UPPER("subcategory") LIKE '%DISPLAY SIZE%' AND "displaynm" = 'Display_Display size' ) -- Display size
-- 	 OR ( UPPER("subcategory") LIKE '%RAM%' AND "displaynm" = 'RAM_RAM Quantity' ) -- RAM
-- 	 OR ( UPPER("subcategory") LIKE '%INTERNAL%' AND "displaynm" = 'Internal storage' ) -- Internal Storage
-- 	 OR ( UPPER("subcategory") LIKE '%DUAL%' AND "displaynm" = 'Cellular_Dual SIM' ) -- Dual SIM
-- 	 OR ( UPPER("subcategory") LIKE '%CAMERA%' AND "displaynm" = 'Main camera_Resolution' ) -- Rear Camera Resolution
-- 	 OR ( UPPER("subcategory") LIKE '%FRONT%' AND "displaynm" = 'Front_Resolution' ) -- Front Camera Resolution
-- 	 OR ( UPPER("subcategory") LIKE '%WEIGHT%' AND "displaynm" = 'Weight_Weight in Grams' ) -- Weight
-- 	 OR ( UPPER("subcategory") LIKE '%RESOLUTION%' AND "displaynm" = 'Resolution_Horizontal' ) -- Display Resolution Horizontal
-- 	 OR ( UPPER("subcategory") LIKE '%RESOLUTION%' AND "displaynm" = 'Resolution_Vertical' ) -- Display Resolution Vertical
-- 	 OR ( UPPER("subcategory") LIKE '%CAPACITY%' AND "displaynm" = 'Battery_Capacity' ) -- Battery Capacity
-- 	 OR ( "displaynm" = 'Availability_Date' ) -- Battery Capacity
-- 	) --
-- 	--AND  "initdttm" = '20200710'
-- 	AND TO_CHAR(LOAD_DATE, 'YYYY-MM-DD') IN ( SELECT MAX(TO_CHAR(LOAD_DATE, 'YYYY-MM-DD')) FROM "OW_LAO"."ODS_GSM_ARENA_TMP"  )
-- 	GROUP BY "brand", "modelcode", "modelnm","mktcode","mktnm","subcategory","displaynm", "value", "etcstatus"
-- 	) 
-- 	WHERE 1=1
-- 	GROUP BY "brand_nm", "model_code", "model_nm","mktcode", "mktname", "etcstatus"
-- 	;
-- PERFORM UPDATE ODS_GSM_ARENA_STAGE
--  SET
--  width_mm = REGEXP_SUBSTR(UPPER(TRIM(width_mm)), '\d+(\.\d{1,2})?', 1, 1)
--   , height_mm = REGEXP_SUBSTR(UPPER(TRIM(height_mm)), '\d+(\.\d{1,2})?', 1, 1)
--   , depth_mm = REGEXP_SUBSTR(UPPER(TRIM(depth_mm)), '\d+(\.\d{1,2})?', 1, 1)
--   , display_size = REGEXP_SUBSTR(UPPER(TRIM(display_size)), '\d+(\.\d{1,2})?', 1, 1)
--   , ram_in_mb = REGEXP_SUBSTR(UPPER(TRIM(ram_in_mb)), '\d+(\.\d{1,2})?', 1, 1)
--   , internal_storage = REGEXP_SUBSTR(UPPER(TRIM(internal_storage)), '\d+(\.\d{1,2})?', 1, 1)
--   , main_camera_mp = REGEXP_SUBSTR(UPPER(TRIM(main_camera_mp)), '\d+(\.\d{1,2})?', 1, 1)
--   , front_camera_mp = REGEXP_SUBSTR(UPPER(TRIM(front_camera_mp)), '\d+(\.\d{1,2})?', 1, 1)
--   , weight_gramm = REGEXP_SUBSTR(UPPER(TRIM(weight_gramm)), '\d+(\.\d{1,2})?', 1, 1)
--   , resolution_wid = REGEXP_SUBSTR(UPPER(TRIM(resolution_wid)), '\d+(\.\d{1,2})?', 1, 1)
--   , resolution_hig = REGEXP_SUBSTR(UPPER(TRIM(resolution_hig)), '\d+(\.\d{1,2})?', 1, 1)
--   , battery_capacity = REGEXP_SUBSTR(UPPER(TRIM(battery_capacity)), '\d+(\.\d{1,2})?', 1, 1)
-- ;
-- PERFORM INSERT INTO ODS_GSM_ARENA_STAGE
--   SELECT  
-- 	 brand_nm
-- 	 , model_code || '_X'
-- 	 , model_nm
-- 	 , mktcode
-- 	 , mktname
-- 	 , CAST(
-- 		CASE 
-- 		  WHEN TRY_TO_NUMERIC(width_mm) IS NULL THEN NULL
-- 		  WHEN TRY_TO_NUMERIC(width_mm) >= 0 THEN 
-- 		    CASE WHEN (TRY_TO_NUMERIC(width_mm) - FLOOR(TRY_TO_NUMERIC(width_mm))) > 0.5 THEN CEILING(TRY_TO_NUMERIC(width_mm)) ELSE FLOOR(TRY_TO_NUMERIC(width_mm)) END
-- 		  ELSE 
-- 		    CASE WHEN ABS(TRY_TO_NUMERIC(width_mm) - CEILING(TRY_TO_NUMERIC(width_mm))) > 0.5 THEN FLOOR(TRY_TO_NUMERIC(width_mm)) ELSE CEILING(TRY_TO_NUMERIC(width_mm)) END
-- 		END AS VARCHAR)
--  	 , CAST(
-- 		CASE 
-- 		  WHEN TRY_TO_NUMERIC(height_mm) IS NULL THEN NULL
-- 		  WHEN TRY_TO_NUMERIC(height_mm) >= 0 THEN 
-- 		    CASE WHEN (TRY_TO_NUMERIC(height_mm) - FLOOR(TRY_TO_NUMERIC(height_mm))) > 0.5 THEN CEILING(TRY_TO_NUMERIC(height_mm)) ELSE FLOOR(TRY_TO_NUMERIC(height_mm)) END
-- 		  ELSE 
-- 		    CASE WHEN ABS(TRY_TO_NUMERIC(height_mm) - CEILING(TRY_TO_NUMERIC(height_mm))) > 0.5 THEN FLOOR(TRY_TO_NUMERIC(height_mm)) ELSE CEILING(TRY_TO_NUMERIC(height_mm)) END
-- 		END AS VARCHAR)
--  	 , CAST(
-- 		CASE 
-- 		  WHEN TRY_TO_NUMERIC(depth_mm) IS NULL THEN NULL
-- 		  WHEN TRY_TO_NUMERIC(depth_mm) >= 0 THEN 
-- 		    CASE WHEN (TRY_TO_NUMERIC(depth_mm) - FLOOR(TRY_TO_NUMERIC(depth_mm))) > 0.5 THEN CEILING(TRY_TO_NUMERIC(depth_mm)) ELSE FLOOR(TRY_TO_NUMERIC(depth_mm)) END
-- 		  ELSE 
-- 		    CASE WHEN ABS(TRY_TO_NUMERIC(depth_mm) - CEILING(TRY_TO_NUMERIC(depth_mm))) > 0.5 THEN FLOOR(TRY_TO_NUMERIC(depth_mm)) ELSE CEILING(TRY_TO_NUMERIC(depth_mm)) END
-- 		END AS VARCHAR)
-- 	 , display_size
-- 	 , ram_in_mb
-- 	 , internal_storage
-- 	 , dual_sim
-- 	 , main_camera_mp
-- 	 , front_camera_mp
-- 	 , weight_gramm
-- 	 , resolution_wid
-- 	 , resolution_hig
-- 	 , battery_capacity
-- FROM ODS_GSM_ARENA_STAGE;
-- PERFORM UPDATE ODS_GSM_ARENA_STAGE
--  SET
--  	width_mm = TO_DECIMAL(width_mm, 8, 1)
--  	, height_mm =  TO_DECIMAL(height_mm, 8, 1) 
--  	, depth_mm = TO_DECIMAL(depth_mm, 8, 1) 
-- 	, display_size =  TO_DECIMAL(display_size, 6, 1) 
--  	, ram_in_mb =  TO_DECIMAL(ram_in_mb, 16, 1) 
--  	, internal_storage = TO_DECIMAL(internal_storage, 8, 0) 
--  	, main_camera_mp = TO_DECIMAL(main_camera_mp, 8, 0) 
--  	, front_camera_mp = TO_DECIMAL(front_camera_mp, 8, 0)
-- 	, weight_gramm = TO_DECIMAL(weight_gramm, 8, 1)
--  	, resolution_wid = TO_DECIMAL(resolution_wid, 8, 0)
--  	, resolution_hig = TO_DECIMAL(resolution_hig, 8, 0)
-- 	, battery_capacity = TO_DECIMAL(battery_capacity, 8, 0)
--  ;
--  
--  PERFORM UPDATE ODS_GSM_ARENA_STAGE
--  SET
--  	width_mm = CASE WHEN width_mm is null or width_mm = '' THEN '$' ELSE width_mm END
--  	, height_mm =  CASE WHEN height_mm is null or height_mm = '' THEN '$' ELSE height_mm END
--  	, depth_mm = CASE WHEN depth_mm is null or depth_mm = '' THEN '$' ELSE depth_mm END 
-- 	, display_size =  CASE WHEN display_size is null or display_size = '' THEN '$' ELSE display_size END 
--  	, ram_in_mb =  CASE WHEN ram_in_mb is null or ram_in_mb = '' THEN '$' ELSE ram_in_mb END
--  	, internal_storage = CASE WHEN internal_storage is null or internal_storage = '' THEN '$' ELSE internal_storage END
--  	, main_camera_mp = CASE WHEN main_camera_mp is null or main_camera_mp = '' THEN '$' ELSE main_camera_mp END
--  	, front_camera_mp = CASE WHEN front_camera_mp is null or front_camera_mp = '' THEN '$' ELSE front_camera_mp END
-- 	, weight_gramm = CASE WHEN weight_gramm is null or weight_gramm = '' THEN '$' ELSE weight_gramm END
--  	, resolution_wid = CASE WHEN resolution_wid is null or resolution_wid = '' THEN '$' ELSE resolution_wid END
--  	, resolution_hig = CASE WHEN resolution_hig is null or resolution_hig = '' THEN '$' ELSE resolution_hig END
-- 	, battery_capacity = CASE WHEN battery_capacity is null or battery_capacity = '' THEN '$' ELSE battery_capacity END
-- 	, dual_sim = CASE WHEN dual_sim is null or dual_sim = '' THEN '$' ELSE dual_sim END
--  ;
--  
--  
-- PERFORM TRUNCATE TABLE MP_GSMARENA_MERGE_DATA_MAPPING;
-- PERFORM INSERT INTO MP_GSMARENA_MERGE_DATA_MAPPING
-- SELECT * FROM ODS_GSM_ARENA_STAGE;
-- PERFORM TRUNCATE TABLE MP_GSMARENA_MERGE_DATA_MAPPING_KEY;
-- PERFORM INSERT INTO MP_GSMARENA_MERGE_DATA_MAPPING_KEY
-- SELECT 
-- 	brand_nm, 
-- 	model_code,
-- 	model_nm, 
-- 	mktname,
-- 	width_mm,
-- 	height_mm,
-- 	depth_mm,
-- 	display_size,
-- 	ram_in_mb,
-- 	internal_storage,
-- 	dual_sim,
-- 	main_camera_mp,
-- 	front_camera_mp,
-- 	weight_gramm,
-- 	resolution_wid,
-- 	resolution_hig,
-- 	battery_capacity,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'')) as case1,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'')) as case2,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'')) as case3,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'')) as case4,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'')) as case5,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( front_camera_mp,'')) as case6,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( ram_in_mb,'')) as case7,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( internal_storage,'')) as case8,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( battery_capacity,'')) as case9,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( dual_sim,'')) as case10,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'')) as case11,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'')) as case12,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'')) as case13,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( main_camera_mp,'')) as case14,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( front_camera_mp,'')) as case15,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( ram_in_mb,'')) as case16,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( internal_storage,'')) as case17,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( battery_capacity,'')) as case18,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( dual_sim,'')) as case19,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_wid,'')) as case20,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_hig,'')) as case21,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( main_camera_mp,'')) as case22,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( front_camera_mp,'')) as case23,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( ram_in_mb,'')) as case24,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( internal_storage,'')) as case25,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( battery_capacity,'')) as case26,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( dual_sim,'')) as case27,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( resolution_hig,'')) as case28,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( main_camera_mp,'')) as case29,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( front_camera_mp,'')) as case30,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( ram_in_mb,'')) as case31,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( internal_storage,'')) as case32,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( battery_capacity,'')) as case33,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( dual_sim,'')) as case34,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( main_camera_mp,'')) as case35,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( front_camera_mp,'')) as case36,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( ram_in_mb,'')) as case37,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( internal_storage,'')) as case38,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( battery_capacity,'')) as case39,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( dual_sim,'')) as case40,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'')) as case41,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case42,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case43,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case44,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case45,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case46,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case47,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case48,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case49,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'')) as case50,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( battery_capacity,'')) as case51,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( dual_sim,'')) as case52,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case53,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case54,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case55,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'')) as case56,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'')) as case57,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'')) as case58,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( main_camera_mp,'')) as case59,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( front_camera_mp,'')) as case60,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( ram_in_mb,'')) as case61,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( internal_storage,'')) as case62,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( battery_capacity,'')) as case63,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( dual_sim,'')) as case64,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_wid,'')) as case65,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_hig,'')) as case66,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( main_camera_mp,'')) as case67,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( front_camera_mp,'')) as case68,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( ram_in_mb,'')) as case69,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( internal_storage,'')) as case70,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( battery_capacity,'')) as case71,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( dual_sim,'')) as case72,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( resolution_hig,'')) as case73,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( main_camera_mp,'')) as case74,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( front_camera_mp,'')) as case75,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( ram_in_mb,'')) as case76,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( internal_storage,'')) as case77,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( battery_capacity,'')) as case78,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( dual_sim,'')) as case79,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( main_camera_mp,'')) as case80,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( front_camera_mp,'')) as case81,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( ram_in_mb,'')) as case82,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( internal_storage,'')) as case83,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( battery_capacity,'')) as case84,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( dual_sim,'')) as case85,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'')) as case86,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case87,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case88,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case89,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case90,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case91,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case92,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case93,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case94,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'')) as case95,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( battery_capacity,'')) as case96,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( dual_sim,'')) as case97,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case98,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case99,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case100,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_wid,'')) as case101,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_hig,'')) as case102,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( main_camera_mp,'')) as case103,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( front_camera_mp,'')) as case104,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( ram_in_mb,'')) as case105,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( internal_storage,'')) as case106,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( battery_capacity,'')) as case107,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( dual_sim,'')) as case108,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( resolution_hig,'')) as case109,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( main_camera_mp,'')) as case110,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( front_camera_mp,'')) as case111,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( ram_in_mb,'')) as case112,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( internal_storage,'')) as case113,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( battery_capacity,'')) as case114,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( dual_sim,'')) as case115,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( main_camera_mp,'')) as case116,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( front_camera_mp,'')) as case117,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( ram_in_mb,'')) as case118,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( internal_storage,'')) as case119,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( battery_capacity,'')) as case120,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( dual_sim,'')) as case121,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'')) as case122,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case123,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case124,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case125,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case126,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case127,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case128,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case129,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case130,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'')) as case131,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( battery_capacity,'')) as case132,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( dual_sim,'')) as case133,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case134,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case135,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case136,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'')) as case221,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'')) as case222,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'')) as case223,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'')) as case224,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( front_camera_mp,'')) as case225,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( ram_in_mb,'')) as case226,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( internal_storage,'')) as case227,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( battery_capacity,'')) as case228,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( dual_sim,'')) as case229,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'')) as case230,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'')) as case231,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'')) as case232,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( front_camera_mp,'')) as case233,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( ram_in_mb,'')) as case234,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( internal_storage,'')) as case235,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( battery_capacity,'')) as case236,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( dual_sim,'')) as case237,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'')) as case238,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'')) as case239,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( front_camera_mp,'')) as case240,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( ram_in_mb,'')) as case241,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( internal_storage,'')) as case242,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( battery_capacity,'')) as case243,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( dual_sim,'')) as case244,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_wid,'')) as case245,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_hig,'')) as case246,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( front_camera_mp,'')) as case247,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( ram_in_mb,'')) as case248,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( internal_storage,'')) as case249,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( battery_capacity,'')) as case250,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( dual_sim,'')) as case251,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( main_camera_mp,'')) as case252,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( front_camera_mp,'')) as case253,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( ram_in_mb,'')) as case254,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( internal_storage,'')) as case255,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( battery_capacity,'')) as case256,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( dual_sim,'')) as case257,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( front_camera_mp,'')) as case258,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( ram_in_mb,'')) as case259,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( internal_storage,'')) as case260,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( battery_capacity,'')) as case261,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( dual_sim,'')) as case262,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( main_camera_mp,'')) as case263,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( internal_storage,'')) as case264,
-- 	(COALESCE(height_mm,'') || '_' || COALESCE( battery_capacity,'')) as case265,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'')) as case266,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'')) as case267,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'')) as case268,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( main_camera_mp,'')) as case269,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( front_camera_mp,'')) as case270,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( ram_in_mb,'')) as case271,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( internal_storage,'')) as case272,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( battery_capacity,'')) as case273,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( dual_sim,'')) as case274,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( resolution_hig,'')) as case275,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( main_camera_mp,'')) as case276,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( front_camera_mp,'')) as case277,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( ram_in_mb,'')) as case278,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( internal_storage,'')) as case279,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( battery_capacity,'')) as case280,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( dual_sim,'')) as case281,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( main_camera_mp,'')) as case282,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( front_camera_mp,'')) as case283,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( ram_in_mb,'')) as case284,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( internal_storage,'')) as case285,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( battery_capacity,'')) as case286,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( dual_sim,'')) as case287,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'')) as case288,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case289,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case290,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case291,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case292,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( front_camera_mp,'')) as case293,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( ram_in_mb,'')) as case294,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( internal_storage,'')) as case295,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( battery_capacity,'')) as case296,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( dual_sim,'')) as case297,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'')) as case302,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'')) as case303,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'')) as case304,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( main_camera_mp,'')) as case305,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( front_camera_mp,'')) as case306,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( ram_in_mb,'')) as case307,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( internal_storage,'')) as case308,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( battery_capacity,'')) as case309,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( dual_sim,'')) as case310,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( resolution_wid,'')) as case311,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( resolution_hig,'')) as case312,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( main_camera_mp,'')) as case313,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( front_camera_mp,'')) as case314,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( ram_in_mb,'')) as case315,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( internal_storage,'')) as case316,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( battery_capacity,'')) as case317,
-- 	(COALESCE(width_mm,'') || '_' || COALESCE( dual_sim,'')) as case318,
-- 	(COALESCE(weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_wid,'')) as case319,
-- 	(COALESCE(weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_hig,'')) as case320,
-- 	(COALESCE(weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( main_camera_mp,'')) as case321,
-- 	(COALESCE(weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( front_camera_mp,'')) as case322,
-- 	(COALESCE(weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( ram_in_mb,'')) as case323,
-- 	(COALESCE(weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( internal_storage,'')) as case324,
-- 	(COALESCE(weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( battery_capacity,'')) as case325,
-- 	(COALESCE(weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( dual_sim,'')) as case326,
-- 	(COALESCE(weight_gramm,'') || '_' || COALESCE( resolution_wid,'')) as case327,
-- 	(COALESCE(weight_gramm,'') || '_' || COALESCE( resolution_hig,'')) as case328,
-- 	(COALESCE(weight_gramm,'') || '_' || COALESCE( main_camera_mp,'')) as case329,
-- 	(COALESCE(weight_gramm,'') || '_' || COALESCE( front_camera_mp,'')) as case330,
-- 	(COALESCE(weight_gramm,'') || '_' || COALESCE( ram_in_mb,'')) as case331,
-- 	(COALESCE(weight_gramm,'') || '_' || COALESCE( internal_storage,'')) as case332,
-- 	(COALESCE(weight_gramm,'') || '_' || COALESCE( battery_capacity,'')) as case333,
-- 	(COALESCE(weight_gramm,'') || '_' || COALESCE( dual_sim,'')) as case334,
-- 	(COALESCE(display_size,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( resolution_hig,'')) as case335,
-- 	(COALESCE(display_size,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( main_camera_mp,'')) as case336,
-- 	(COALESCE(display_size,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( front_camera_mp,'')) as case337,
-- 	(COALESCE(display_size,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( ram_in_mb,'')) as case338,
-- 	(COALESCE(display_size,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( internal_storage,'')) as case339,
-- 	(COALESCE(display_size,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( battery_capacity,'')) as case340,
-- 	(COALESCE(display_size,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( dual_sim,'')) as case341,
-- 	(COALESCE(display_size,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( main_camera_mp,'')) as case342,
-- 	(COALESCE(display_size,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( front_camera_mp,'')) as case343,
-- 	(COALESCE(display_size,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( ram_in_mb,'')) as case344,
-- 	(COALESCE(display_size,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( internal_storage,'')) as case345,
-- 	(COALESCE(display_size,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( battery_capacity,'')) as case346,
-- 	(COALESCE(display_size,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( dual_sim,'')) as case347,
-- 	(COALESCE(display_size,'') || '_' || COALESCE( main_camera_mp,'')) as case348,
-- 	(COALESCE(display_size,'') || '_' || COALESCE( front_camera_mp,'')) as case349,
-- 	(COALESCE(display_size,'') || '_' || COALESCE( ram_in_mb,'')) as case350,
-- 	(COALESCE(display_size,'') || '_' || COALESCE( internal_storage,'')) as case351,
-- 	(COALESCE(display_size,'') || '_' || COALESCE( battery_capacity,'')) as case352,
-- 	(COALESCE(display_size,'') || '_' || COALESCE( dual_sim,'')) as case353;
-- /*	
-- ---Tratamento do caractere " + " pois registros assim estão com erro na PROC PT2	
-- update OW_LAO.MP_GSMARENA_MERGE_DATA_MAPPING_KEY
--  set model_nm=replace(model_nm,' + ','+ ')
--  where model_nm like '% + %';
--  
--  update  OW_LAO.MP_GSMARENA_MERGE_DATA_MAPPING
--  set model_nm=replace(model_nm,' + ','+ ')
--  where model_nm like '% + %';
--  */
--  
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 482.1 of source string: syntax error, unexpected UNKNOWN, expecting BEGIN, Sqlstate: 42601, Position: 45617, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
DROP PROCEDURE IF EXISTS PROC_GSMARENA_MAPPING_1_0();

CREATE OR REPLACE PROCEDURE PROC_GSMARENA_MAPPING_1_0()
LANGUAGE PLvSQL AS $$
BEGIN
  PERFORM TRUNCATE TABLE ODS_GSM_ARENA_STAGE;
END;
$$;

-- CALL PROC_GSMARENA_MAPPING_1_0();
-- ERROR: Severity: ROLLBACK, Message: Table "ODS_GSM_ARENA_STAGE" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_GSMARENA_MAPPING_1_0 line 3 at static SQL, Routine: TruncateTable, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Commands/DDL.cpp, Line: 20681, Error Code: 4876, 
-- CREATE OR REPLACE PROCEDURE PROC_GSMARENA_MAPPING_1_0()
-- LANGUAGE PLvSQL AS $$
-- BEGIN
-- -- Data Clean 
-- PERFORM TRUNCATE TABLE ODS_GSM_ARENA_STAGE;
-- PERFORM INSERT INTO ODS_GSM_ARENA_STAGE
-- 	  SELECT  
-- 	 	"brand_nm"
-- 	 , "model_code"
-- 	 , "model_nm"
-- 	 , "mktcode"
-- 	 , "mktname"
-- 	 , MAX("width_mm") "width_mm"
-- 	 , MAX("height_mm") "height_mm"
-- 	 , MAX("depth_mm") "depth_mm"
-- 	 , MAX("display_size") "display_size"
-- 	 , MAX("ram_in_mb") "ram_in_mb"
-- 	 , MAX("internal_storage") "internal_storage"
-- 	 , MAX("dual_sim") "dual_sim"
-- 	 , MAX("main_camera_mp") "main_camera_mp"
-- 	 , MAX("front_camera_mp") "front_camera_mp"
-- 	 , MAX("weight_gramm") "weight_gramm"
-- 	 , MAX("resolution_wid") "resolution_wid"
-- 	 , MAX("resolution_hig") "resolution_hig"
-- 	 , MAX("battery_capacity") "battery_capacity"
-- 	 FROM (
-- 	SELECT distinct "brand" "brand_nm", "modelcode" "model_code", "modelnm" "model_nm","mktcode" "mktcode","mktnm" "mktname"
-- 		, CASE
-- 			WHEN ( UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" = 'Dimensions_width_in_MM' ) AND "value" is not null  
-- 				THEN "value"
-- 			WHEN  "displaynm" = 'Dimensions_Width'
-- 				THEN "value"
-- 		  END "width_mm"
-- 		, CASE
-- 			WHEN ( UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" = 'Dimensions_height_in_MM')  AND "value" is not null  
-- 				THEN "value"
-- 			WHEN  "displaynm" = 'Dimensions_Length'
-- 				THEN "value"
-- 		  END "height_mm"
-- 		, CASE
-- 			WHEN ( UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" = 'Dimensions_depth_in_MM' ) AND "value" is not null  
-- 				THEN "value"
-- 			WHEN  "displaynm" = 'Dimensions_Thickness'
-- 				THEN "value"
-- 		  END "depth_mm"
-- 		, CASE
-- 			WHEN ( UPPER("subcategory") LIKE '%DISPLAY SIZE%' AND "displaynm" = 'Display_Display size' )  THEN "value" 
-- 		  END "display_size"
-- 		, CASE
-- 			WHEN ( UPPER("subcategory") LIKE '%RAM%' AND "displaynm" = 'RAM_RAM Quantity' ) THEN "value" 
-- 		  END "ram_in_mb"
-- 		, CASE
-- 			WHEN ( UPPER("subcategory") LIKE '%INTERNAL%' AND "displaynm" = 'Internal storage' ) THEN "value" 
-- 		  END "internal_storage"
-- 		, CASE
-- 			WHEN ( UPPER("subcategory") LIKE '%DUAL%' AND "displaynm" = 'Cellular_Dual SIM' ) THEN "value" 
-- 		  END "dual_sim"
-- 		, CASE
-- 			WHEN ( UPPER("subcategory") LIKE '%CAMERA%' AND "displaynm" = 'Main camera_Resolution' ) THEN "value" 
-- 		  END "main_camera_mp"
-- 		, CASE
-- 			WHEN ( UPPER("subcategory") LIKE '%FRONT%' AND "displaynm" = 'Front_Resolution' ) THEN "value" 
-- 		  END "front_camera_mp"
-- 		, CASE
-- 			WHEN ( UPPER("subcategory") LIKE '%WEIGHT%' AND "displaynm" = 'Weight_Weight in Grams' ) THEN "value" 
-- 		  END "weight_gramm"
-- 		, CASE
-- 			WHEN ( UPPER("subcategory") LIKE '%RESOLUTION%' AND "displaynm" = 'Resolution_Horizontal' ) THEN "value" 
-- 		  END "resolution_wid"
-- 		, CASE
-- 			WHEN ( UPPER("subcategory") LIKE '%RESOLUTION%' AND "displaynm" = 'Resolution_Vertical' ) THEN "value" 
-- 		  END "resolution_hig"
-- 		, CASE
-- 			WHEN ( UPPER("subcategory") LIKE '%CAPACITY%' AND "displaynm" = 'Battery_Capacity' ) THEN "value" 
-- 		  END "battery_capacity"
-- 	   , CASE
-- 			WHEN ( "displaynm" = 'Availability_Date' ) THEN "value" 
-- 		  END "availability_date"
-- 		  , "etcstatus"
-- 	 FROM ODS_GSM_ARENA_TMP
-- 	 WHERE (
-- 	   ( UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" IN ('Dimensions_width_in_MM', 'Dimensions_Width') ) -- Width
-- 	 OR ( UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" IN ( 'Dimensions_height_in_MM', 'Dimensions_Length' )) -- Height
-- 	 OR ( UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" IN ( 'Dimensions_depth_in_MM', 'Dimensions_Thickness' )) --Thickness
-- 	 OR ( UPPER("subcategory") LIKE '%DISPLAY SIZE%' AND "displaynm" = 'Display_Display size' ) -- Display size
-- 	 OR ( UPPER("subcategory") LIKE '%RAM%' AND "displaynm" = 'RAM_RAM Quantity' ) -- RAM
-- 	 OR ( UPPER("subcategory") LIKE '%INTERNAL%' AND "displaynm" = 'Internal storage' ) -- Internal Storage
-- 	 OR ( UPPER("subcategory") LIKE '%DUAL%' AND "displaynm" = 'Cellular_Dual SIM' ) -- Dual SIM
-- 	 OR ( UPPER("subcategory") LIKE '%CAMERA%' AND "displaynm" = 'Main camera_Resolution' ) -- Rear Camera Resolution
-- 	 OR ( UPPER("subcategory") LIKE '%FRONT%' AND "displaynm" = 'Front_Resolution' ) -- Front Camera Resolution
-- 	 OR ( UPPER("subcategory") LIKE '%WEIGHT%' AND "displaynm" = 'Weight_Weight in Grams' ) -- Weight
-- 	 OR ( UPPER("subcategory") LIKE '%RESOLUTION%' AND "displaynm" = 'Resolution_Horizontal' ) -- Display Resolution Horizontal
-- 	 OR ( UPPER("subcategory") LIKE '%RESOLUTION%' AND "displaynm" = 'Resolution_Vertical' ) -- Display Resolution Vertical
-- 	 OR ( UPPER("subcategory") LIKE '%CAPACITY%' AND "displaynm" = 'Battery_Capacity' ) -- Battery Capacity
-- 	 OR ( "displaynm" = 'Availability_Date' ) -- Battery Capacity
-- 	) --
-- 	--AND  "initdttm" = '20200710'
-- 	AND TO_CHAR(LOAD_DATE, 'YYYY-MM-DD') IN ( SELECT MAX(TO_CHAR(LOAD_DATE, 'YYYY-MM-DD')) FROM "OW_LAO"."ODS_GSM_ARENA_TMP"  )
-- 	GROUP BY "brand", "modelcode", "modelnm","mktcode","mktnm","subcategory","displaynm", "value", "etcstatus"
-- 	) 
-- 	WHERE 1=1
-- 	GROUP BY "brand_nm", "model_code", "model_nm","mktcode", "mktname", "etcstatus"
-- 	;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: Subquery in FROM must have an alias, Sqlstate: 42601, Hint: For example, FROM (SELECT ...) [AS] foo, Position: 152, Routine: base_yyparse, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/gram.y, Line: 15782, Error Code: 4833, 
CREATE OR REPLACE PROCEDURE PROC_GSMARENA_MAPPING_1_0()
LANGUAGE PLvSQL AS $$
BEGIN
  PERFORM TRUNCATE TABLE ODS_GSM_ARENA_STAGE;
  PERFORM INSERT INTO ODS_GSM_ARENA_STAGE
  SELECT brand_nm, model_code, model_nm, mktcode, mktname,
         MAX(width_mm) AS width_mm,
         MAX(height_mm) AS height_mm,
         MAX(depth_mm) AS depth_mm,
         MAX(display_size) AS display_size,
         MAX(ram_in_mb) AS ram_in_mb,
         MAX(internal_storage) AS internal_storage,
         MAX(dual_sim) AS dual_sim,
         MAX(main_camera_mp) AS main_camera_mp,
         MAX(front_camera_mp) AS front_camera_mp,
         MAX(weight_gramm) AS weight_gramm,
         MAX(resolution_wid) AS resolution_wid,
         MAX(resolution_hig) AS resolution_hig,
         MAX(battery_capacity) AS battery_capacity
  FROM (
    SELECT DISTINCT
      "brand" AS brand_nm,
      "modelcode" AS model_code,
      "modelnm" AS model_nm,
      "mktcode" AS mktcode,
      "mktnm" AS mktname,
      CASE WHEN (UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" = 'Dimensions_width_in_MM' AND "value" IS NOT NULL)
                OR ("displaynm" = 'Dimensions_Width')
           THEN "value" END AS width_mm,
      CASE WHEN (UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" = 'Dimensions_height_in_MM' AND "value" IS NOT NULL)
                OR ("displaynm" = 'Dimensions_Length')
           THEN "value" END AS height_mm,
      CASE WHEN (UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" = 'Dimensions_depth_in_MM' AND "value" IS NOT NULL)
                OR ("displaynm" = 'Dimensions_Thickness')
           THEN "value" END AS depth_mm,
      CASE WHEN (UPPER("subcategory") LIKE '%DISPLAY SIZE%' AND "displaynm" = 'Display_Display size') THEN "value" END AS display_size,
      CASE WHEN (UPPER("subcategory") LIKE '%RAM%' AND "displaynm" = 'RAM_RAM Quantity') THEN "value" END AS ram_in_mb,
      CASE WHEN (UPPER("subcategory") LIKE '%INTERNAL%' AND "displaynm" = 'Internal storage') THEN "value" END AS internal_storage,
      CASE WHEN (UPPER("subcategory") LIKE '%DUAL%' AND "displaynm" = 'Cellular_Dual SIM') THEN "value" END AS dual_sim,
      CASE WHEN (UPPER("subcategory") LIKE '%CAMERA%' AND "displaynm" = 'Main camera_Resolution') THEN "value" END AS main_camera_mp,
      CASE WHEN (UPPER("subcategory") LIKE '%FRONT%' AND "displaynm" = 'Front_Resolution') THEN "value" END AS front_camera_mp,
      CASE WHEN (UPPER("subcategory") LIKE '%WEIGHT%' AND "displaynm" = 'Weight_Weight in Grams') THEN "value" END AS weight_gramm,
      CASE WHEN (UPPER("subcategory") LIKE '%RESOLUTION%' AND "displaynm" = 'Resolution_Horizontal') THEN "value" END AS resolution_wid,
      CASE WHEN (UPPER("subcategory") LIKE '%RESOLUTION%' AND "displaynm" = 'Resolution_Vertical') THEN "value" END AS resolution_hig,
      CASE WHEN (UPPER("subcategory") LIKE '%CAPACITY%' AND "displaynm" = 'Battery_Capacity') THEN "value" END AS battery_capacity,
      CASE WHEN ("displaynm" = 'Availability_Date') THEN "value" END AS availability_date,
      "etcstatus"
    FROM ODS_GSM_ARENA_TMP
    WHERE (
      (UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" IN ('Dimensions_width_in_MM', 'Dimensions_Width'))
      OR (UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" IN ('Dimensions_height_in_MM', 'Dimensions_Length'))
      OR (UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" IN ('Dimensions_depth_in_MM', 'Dimensions_Thickness'))
      OR (UPPER("subcategory") LIKE '%DISPLAY SIZE%' AND "displaynm" = 'Display_Display size')
      OR (UPPER("subcategory") LIKE '%RAM%' AND "displaynm" = 'RAM_RAM Quantity')
      OR (UPPER("subcategory") LIKE '%INTERNAL%' AND "displaynm" = 'Internal storage')
      OR (UPPER("subcategory") LIKE '%DUAL%' AND "displaynm" = 'Cellular_Dual SIM')
      OR (UPPER("subcategory") LIKE '%CAMERA%' AND "displaynm" = 'Main camera_Resolution')
      OR (UPPER("subcategory") LIKE '%FRONT%' AND "displaynm" = 'Front_Resolution')
      OR (UPPER("subcategory") LIKE '%WEIGHT%' AND "displaynm" = 'Weight_Weight in Grams')
      OR (UPPER("subcategory") LIKE '%RESOLUTION%' AND "displaynm" = 'Resolution_Horizontal')
      OR (UPPER("subcategory") LIKE '%RESOLUTION%' AND "displaynm" = 'Resolution_Vertical')
      OR (UPPER("subcategory") LIKE '%CAPACITY%' AND "displaynm" = 'Battery_Capacity')
      OR ("displaynm" = 'Availability_Date')
    )
    AND TO_CHAR(LOAD_DATE, 'YYYY-MM-DD') IN (
      SELECT MAX(TO_CHAR(LOAD_DATE, 'YYYY-MM-DD')) FROM "OW_LAO"."ODS_GSM_ARENA_TMP"
    )
    GROUP BY "brand", "modelcode", "modelnm", "mktcode", "mktnm", "subcategory", "displaynm", "value", "etcstatus"
  ) t
  GROUP BY brand_nm, model_code, model_nm, mktcode, mktname, etcstatus;
END;
$$;

-- CALL PROC_GSMARENA_MAPPING_1_0();
-- ERROR: Severity: ROLLBACK, Message: Table "ODS_GSM_ARENA_STAGE" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_GSMARENA_MAPPING_1_0 line 3 at static SQL, Routine: TruncateTable, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Commands/DDL.cpp, Line: 20681, Error Code: 4876, 
-- CREATE OR REPLACE PROCEDURE PROC_GSMARENA_MAPPING_1_0()
-- LANGUAGE PLvSQL AS $$
-- BEGIN
-- -- Data Clean 
-- PERFORM TRUNCATE TABLE ODS_GSM_ARENA_STAGE;
-- 
-- -- Stage insert
-- PERFORM INSERT INTO ODS_GSM_ARENA_STAGE
-- SELECT brand_nm, model_code, model_nm, mktcode, mktname,
--        MAX(width_mm), MAX(height_mm), MAX(depth_mm), MAX(display_size),
--        MAX(ram_in_mb), MAX(internal_storage), MAX(dual_sim), MAX(main_camera_mp),
--        MAX(front_camera_mp), MAX(weight_gramm), MAX(resolution_wid), MAX(resolution_hig), MAX(battery_capacity)
-- FROM (
--   SELECT DISTINCT
--     "brand" AS brand_nm,
--     "modelcode" AS model_code,
--     "modelnm" AS model_nm,
--     "mktcode" AS mktcode,
--     "mktnm" AS mktname,
--     CASE WHEN (UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" = 'Dimensions_width_in_MM' AND "value" IS NOT NULL)
--               OR ("displaynm" = 'Dimensions_Width') THEN "value" END AS width_mm,
--     CASE WHEN (UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" = 'Dimensions_height_in_MM' AND "value" IS NOT NULL)
--               OR ("displaynm" = 'Dimensions_Length') THEN "value" END AS height_mm,
--     CASE WHEN (UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" = 'Dimensions_depth_in_MM' AND "value" IS NOT NULL)
--               OR ("displaynm" = 'Dimensions_Thickness') THEN "value" END AS depth_mm,
--     CASE WHEN (UPPER("subcategory") LIKE '%DISPLAY SIZE%' AND "displaynm" = 'Display_Display size') THEN "value" END AS display_size,
--     CASE WHEN (UPPER("subcategory") LIKE '%RAM%' AND "displaynm" = 'RAM_RAM Quantity') THEN "value" END AS ram_in_mb,
--     CASE WHEN (UPPER("subcategory") LIKE '%INTERNAL%' AND "displaynm" = 'Internal storage') THEN "value" END AS internal_storage,
--     CASE WHEN (UPPER("subcategory") LIKE '%DUAL%' AND "displaynm" = 'Cellular_Dual SIM') THEN "value" END AS dual_sim,
--     CASE WHEN (UPPER("subcategory") LIKE '%CAMERA%' AND "displaynm" = 'Main camera_Resolution') THEN "value" END AS main_camera_mp,
--     CASE WHEN (UPPER("subcategory") LIKE '%FRONT%' AND "displaynm" = 'Front_Resolution') THEN "value" END AS front_camera_mp,
--     CASE WHEN (UPPER("subcategory") LIKE '%WEIGHT%' AND "displaynm" = 'Weight_Weight in Grams') THEN "value" END AS weight_gramm,
--     CASE WHEN (UPPER("subcategory") LIKE '%RESOLUTION%' AND "displaynm" = 'Resolution_Horizontal') THEN "value" END AS resolution_wid,
--     CASE WHEN (UPPER("subcategory") LIKE '%RESOLUTION%' AND "displaynm" = 'Resolution_Vertical') THEN "value" END AS resolution_hig,
--     CASE WHEN (UPPER("subcategory") LIKE '%CAPACITY%' AND "displaynm" = 'Battery_Capacity') THEN "value" END AS battery_capacity,
--     CASE WHEN ("displaynm" = 'Availability_Date') THEN "value" END AS availability_date,
--     "etcstatus"
--   FROM ODS_GSM_ARENA_TMP
--   WHERE (
--     (UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" IN ('Dimensions_width_in_MM', 'Dimensions_Width'))
--     OR (UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" IN ('Dimensions_height_in_MM', 'Dimensions_Length'))
--     OR (UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" IN ('Dimensions_depth_in_MM', 'Dimensions_Thickness'))
--     OR (UPPER("subcategory") LIKE '%DISPLAY SIZE%' AND "displaynm" = 'Display_Display size')
--     OR (UPPER("subcategory") LIKE '%RAM%' AND "displaynm" = 'RAM_RAM Quantity')
--     OR (UPPER("subcategory") LIKE '%INTERNAL%' AND "displaynm" = 'Internal storage')
--     OR (UPPER("subcategory") LIKE '%DUAL%' AND "displaynm" = 'Cellular_Dual SIM')
--     OR (UPPER("subcategory") LIKE '%CAMERA%' AND "displaynm" = 'Main camera_Resolution')
--     OR (UPPER("subcategory") LIKE '%FRONT%' AND "displaynm" = 'Front_Resolution')
--     OR (UPPER("subcategory") LIKE '%WEIGHT%' AND "displaynm" = 'Weight_Weight in Grams')
--     OR (UPPER("subcategory") LIKE '%RESOLUTION%' AND "displaynm" = 'Resolution_Horizontal')
--     OR (UPPER("subcategory") LIKE '%RESOLUTION%' AND "displaynm" = 'Resolution_Vertical')
--     OR (UPPER("subcategory") LIKE '%CAPACITY%' AND "displaynm" = 'Battery_Capacity')
--     OR ("displaynm" = 'Availability_Date')
--   )
--   AND TO_CHAR(LOAD_DATE, 'YYYY-MM-DD') IN (
--     SELECT MAX(TO_CHAR(LOAD_DATE, 'YYYY-MM-DD')) FROM "OW_LAO"."ODS_GSM_ARENA_TMP"
--   )
--   GROUP BY "brand", "modelcode", "modelnm", "mktcode", "mktnm", "subcategory", "displaynm", "value", "etcstatus"
-- ) s
-- GROUP BY brand_nm, model_code, model_nm, mktcode, mktname, etcstatus;
-- 
-- -- Normalize numeric text fields with regex
-- PERFORM UPDATE ODS_GSM_ARENA_STAGE
--  SET
--  width_mm = REGEXP_SUBSTR(UPPER(TRIM(width_mm)), '\d+(\.\d{1,2})?', 1, 1),
--  height_mm = REGEXP_SUBSTR(UPPER(TRIM(height_mm)), '\d+(\.\d{1,2})?', 1, 1),
--  depth_mm = REGEXP_SUBSTR(UPPER(TRIM(depth_mm)), '\d+(\.\d{1,2})?', 1, 1),
--  display_size = REGEXP_SUBSTR(UPPER(TRIM(display_size)), '\d+(\.\d{1,2})?', 1, 1),
--  ram_in_mb = REGEXP_SUBSTR(UPPER(TRIM(ram_in_mb)), '\d+(\.\d{1,2})?', 1, 1),
--  internal_storage = REGEXP_SUBSTR(UPPER(TRIM(internal_storage)), '\d+(\.\d{1,2})?', 1, 1),
--  main_camera_mp = REGEXP_SUBSTR(UPPER(TRIM(main_camera_mp)), '\d+(\.\d{1,2})?', 1, 1),
--  front_camera_mp = REGEXP_SUBSTR(UPPER(TRIM(front_camera_mp)), '\d+(\.\d{1,2})?', 1, 1),
--  weight_gramm = REGEXP_SUBSTR(UPPER(TRIM(weight_gramm)), '\d+(\.\d{1,2})?', 1, 1),
--  resolution_wid = REGEXP_SUBSTR(UPPER(TRIM(resolution_wid)), '\d+(\.\d{1,2})?', 1, 1),
--  resolution_hig = REGEXP_SUBSTR(UPPER(TRIM(resolution_hig)), '\d+(\.\d{1,2})?', 1, 1),
--  battery_capacity = REGEXP_SUBSTR(UPPER(TRIM(battery_capacity)), '\d+(\.\d{1,2})?', 1, 1);
-- 
-- -- Duplicate with model_code_X and rounded dimensions (half down)
-- PERFORM INSERT INTO ODS_GSM_ARENA_STAGE
--   SELECT  
--      brand_nm,
--      model_code || '_X',
--      model_nm,
--      mktcode,
--      mktname,
--      CASE WHEN TRY_TO_NUMERIC(width_mm) IS NULL THEN NULL ELSE CAST(FLOOR(TRY_TO_NUMERIC(width_mm) + 0.4999999) AS VARCHAR) END AS width_mm,
--      CASE WHEN TRY_TO_NUMERIC(height_mm) IS NULL THEN NULL ELSE CAST(FLOOR(TRY_TO_NUMERIC(height_mm) + 0.4999999) AS VARCHAR) END AS height_mm,
--      CASE WHEN TRY_TO_NUMERIC(depth_mm) IS NULL THEN NULL ELSE CAST(FLOOR(TRY_TO_NUMERIC(depth_mm) + 0.4999999) AS VARCHAR) END AS depth_mm,
--      display_size,
--      ram_in_mb,
--      internal_storage,
--      dual_sim,
--      main_camera_mp,
--      front_camera_mp,
--      weight_gramm,
--      resolution_wid,
--      resolution_hig,
--      battery_capacity
--   FROM ODS_GSM_ARENA_STAGE;
-- 
-- -- Cast to decimals as per target precision/scale
-- PERFORM UPDATE ODS_GSM_ARENA_STAGE
--  SET
--    width_mm = TO_DECIMAL(width_mm, 8, 1),
--    height_mm = TO_DECIMAL(height_mm, 8, 1),
--    depth_mm = TO_DECIMAL(depth_mm, 8, 1),
--    display_size = TO_DECIMAL(display_size, 6, 1),
--    ram_in_mb = TO_DECIMAL(ram_in_mb, 16, 1),
--    internal_storage = TO_DECIMAL(internal_storage, 8, 0),
--    main_camera_mp = TO_DECIMAL(main_camera_mp, 8, 0),
--    front_camera_mp = TO_DECIMAL(front_camera_mp, 8, 0),
--    weight_gramm = TO_DECIMAL(weight_gramm, 8, 1),
--    resolution_wid = TO_DECIMAL(resolution_wid, 8, 0),
--    resolution_hig = TO_DECIMAL(resolution_hig, 8, 0),
--    battery_capacity = TO_DECIMAL(battery_capacity, 8, 0);
-- 
-- -- Replace null/empty with '$' marker, including dual_sim
-- PERFORM UPDATE ODS_GSM_ARENA_STAGE
--  SET
--    width_mm = CASE WHEN width_mm IS NULL OR width_mm = '' THEN '$' ELSE width_mm END,
--    height_mm = CASE WHEN height_mm IS NULL OR height_mm = '' THEN '$' ELSE height_mm END,
--    depth_mm = CASE WHEN depth_mm IS NULL OR depth_mm = '' THEN '$' ELSE depth_mm END,
--    display_size = CASE WHEN display_size IS NULL OR display_size = '' THEN '$' ELSE display_size END,
--    ram_in_mb = CASE WHEN ram_in_mb IS NULL OR ram_in_mb = '' THEN '$' ELSE ram_in_mb END,
--    internal_storage = CASE WHEN internal_storage IS NULL OR internal_storage = '' THEN '$' ELSE internal_storage END,
--    main_camera_mp = CASE WHEN main_camera_mp IS NULL OR main_camera_mp = '' THEN '$' ELSE main_camera_mp END,
--    front_camera_mp = CASE WHEN front_camera_mp IS NULL OR front_camera_mp = '' THEN '$' ELSE front_camera_mp END,
--    weight_gramm = CASE WHEN weight_gramm IS NULL OR weight_gramm = '' THEN '$' ELSE weight_gramm END,
--    resolution_wid = CASE WHEN resolution_wid IS NULL OR resolution_wid = '' THEN '$' ELSE resolution_wid END,
--    resolution_hig = CASE WHEN resolution_hig IS NULL OR resolution_hig = '' THEN '$' ELSE resolution_hig END,
--    battery_capacity = CASE WHEN battery_capacity IS NULL OR battery_capacity = '' THEN '$' ELSE battery_capacity END,
--    dual_sim = CASE WHEN dual_sim IS NULL OR dual_sim = '' THEN '$' ELSE dual_sim END;
-- 
-- -- Load mapping tables
-- PERFORM TRUNCATE TABLE MP_GSMARENA_MERGE_DATA_MAPPING;
-- PERFORM INSERT INTO MP_GSMARENA_MERGE_DATA_MAPPING SELECT * FROM ODS_GSM_ARENA_STAGE;
-- 
-- PERFORM TRUNCATE TABLE MP_GSMARENA_MERGE_DATA_MAPPING_KEY;
-- PERFORM INSERT INTO MP_GSMARENA_MERGE_DATA_MAPPING_KEY
-- SELECT ...
-- FROM ODS_GSM_ARENA_STAGE;
-- 
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: Syntax error at or near ".", Sqlstate: 42601, Position: 8658, Routine: base_yyerror, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/scan.l, Line: 1056, Error Code: 4856, 
-- CALL PROC_GSMARENA_MAPPING_1_0();
-- ERROR: Severity: ROLLBACK, Message: Table "ODS_GSM_ARENA_STAGE" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_GSMARENA_MAPPING_1_0 line 3 at static SQL, Routine: TruncateTable, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Commands/DDL.cpp, Line: 20681, Error Code: 4876, 
CREATE OR REPLACE PROCEDURE PROC_GSMARENA_MAPPING_1_0()
LANGUAGE PLvSQL AS $$
BEGIN
-- Data Clean 
PERFORM TRUNCATE TABLE ODS_GSM_ARENA_STAGE;

PERFORM INSERT INTO ODS_GSM_ARENA_STAGE
  SELECT  
    brand_nm,
    model_code,
    model_nm,
    mktcode,
    mktname,
    MAX(width_mm) AS width_mm,
    MAX(height_mm) AS height_mm,
    MAX(depth_mm) AS depth_mm,
    MAX(display_size) AS display_size,
    MAX(ram_in_mb) AS ram_in_mb,
    MAX(internal_storage) AS internal_storage,
    MAX(dual_sim) AS dual_sim,
    MAX(main_camera_mp) AS main_camera_mp,
    MAX(front_camera_mp) AS front_camera_mp,
    MAX(weight_gramm) AS weight_gramm,
    MAX(resolution_wid) AS resolution_wid,
    MAX(resolution_hig) AS resolution_hig,
    MAX(battery_capacity) AS battery_capacity
  FROM (
    SELECT DISTINCT 
        "brand" AS brand_nm, 
        "modelcode" AS model_code, 
        "modelnm" AS model_nm,
        "mktcode" AS mktcode,
        "mktnm" AS mktname,
        CASE
            WHEN ( UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" = 'Dimensions_width_in_MM' AND "value" is not null) OR ("displaynm" = 'Dimensions_Width')
                THEN "value"
        END AS width_mm,
        CASE
            WHEN ( UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" = 'Dimensions_height_in_MM' AND "value" is not null) OR ("displaynm" = 'Dimensions_Length')
                THEN "value"
        END AS height_mm,
        CASE
            WHEN ( UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" = 'Dimensions_depth_in_MM' AND "value" is not null) OR ("displaynm" = 'Dimensions_Thickness')
                THEN "value"
        END AS depth_mm,
        CASE WHEN ( UPPER("subcategory") LIKE '%DISPLAY SIZE%' AND "displaynm" = 'Display_Display size' )  THEN "value" END AS display_size,
        CASE WHEN ( UPPER("subcategory") LIKE '%RAM%' AND "displaynm" = 'RAM_RAM Quantity' ) THEN "value" END AS ram_in_mb,
        CASE WHEN ( UPPER("subcategory") LIKE '%INTERNAL%' AND "displaynm" = 'Internal storage' ) THEN "value" END AS internal_storage,
        CASE WHEN ( UPPER("subcategory") LIKE '%DUAL%' AND "displaynm" = 'Cellular_Dual SIM' ) THEN "value" END AS dual_sim,
        CASE WHEN ( UPPER("subcategory") LIKE '%CAMERA%' AND "displaynm" = 'Main camera_Resolution' ) THEN "value" END AS main_camera_mp,
        CASE WHEN ( UPPER("subcategory") LIKE '%FRONT%' AND "displaynm" = 'Front_Resolution' ) THEN "value" END AS front_camera_mp,
        CASE WHEN ( UPPER("subcategory") LIKE '%WEIGHT%' AND "displaynm" = 'Weight_Weight in Grams' ) THEN "value" END AS weight_gramm,
        CASE WHEN ( UPPER("subcategory") LIKE '%RESOLUTION%' AND "displaynm" = 'Resolution_Horizontal' ) THEN "value" END AS resolution_wid,
        CASE WHEN ( UPPER("subcategory") LIKE '%RESOLUTION%' AND "displaynm" = 'Resolution_Vertical' ) THEN "value" END AS resolution_hig,
        CASE WHEN ( UPPER("subcategory") LIKE '%CAPACITY%' AND "displaynm" = 'Battery_Capacity' ) THEN "value" END AS battery_capacity,
        CASE WHEN ( "displaynm" = 'Availability_Date' ) THEN "value" END AS availability_date,
        "etcstatus"
    FROM ODS_GSM_ARENA_TMP
    WHERE (
       ( UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" IN ('Dimensions_width_in_MM', 'Dimensions_Width') )
    OR ( UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" IN ( 'Dimensions_height_in_MM', 'Dimensions_Length' ))
    OR ( UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" IN ( 'Dimensions_depth_in_MM', 'Dimensions_Thickness' ))
    OR ( UPPER("subcategory") LIKE '%DISPLAY SIZE%' AND "displaynm" = 'Display_Display size' )
    OR ( UPPER("subcategory") LIKE '%RAM%' AND "displaynm" = 'RAM_RAM Quantity' )
    OR ( UPPER("subcategory") LIKE '%INTERNAL%' AND "displaynm" = 'Internal storage' )
    OR ( UPPER("subcategory") LIKE '%DUAL%' AND "displaynm" = 'Cellular_Dual SIM' )
    OR ( UPPER("subcategory") LIKE '%CAMERA%' AND "displaynm" = 'Main camera_Resolution' )
    OR ( UPPER("subcategory") LIKE '%FRONT%' AND "displaynm" = 'Front_Resolution' )
    OR ( UPPER("subcategory") LIKE '%WEIGHT%' AND "displaynm" = 'Weight_Weight in Grams' )
    OR ( UPPER("subcategory") LIKE '%RESOLUTION%' AND "displaynm" = 'Resolution_Horizontal' )
    OR ( UPPER("subcategory") LIKE '%RESOLUTION%' AND "displaynm" = 'Resolution_Vertical' )
    OR ( UPPER("subcategory") LIKE '%CAPACITY%' AND "displaynm" = 'Battery_Capacity' )
    OR ( "displaynm" = 'Availability_Date' )
    )
    AND TO_CHAR(LOAD_DATE, 'YYYY-MM-DD') IN (
      SELECT MAX(TO_CHAR(LOAD_DATE, 'YYYY-MM-DD')) FROM "OW_LAO"."ODS_GSM_ARENA_TMP"
    )
    GROUP BY "brand", "modelcode", "modelnm","mktcode","mktnm","subcategory","displaynm", "value", "etcstatus"
  ) s
  GROUP BY brand_nm, model_code, model_nm, mktcode, mktname, etcstatus;

-- Normalize numeric text fields with regex
PERFORM UPDATE ODS_GSM_ARENA_STAGE
 SET
   width_mm = REGEXP_SUBSTR(UPPER(TRIM(width_mm)), '\d+(\.\d{1,2})?', 1, 1),
   height_mm = REGEXP_SUBSTR(UPPER(TRIM(height_mm)), '\d+(\.\d{1,2})?', 1, 1),
   depth_mm = REGEXP_SUBSTR(UPPER(TRIM(depth_mm)), '\d+(\.\d{1,2})?', 1, 1),
   display_size = REGEXP_SUBSTR(UPPER(TRIM(display_size)), '\d+(\.\d{1,2})?', 1, 1),
   ram_in_mb = REGEXP_SUBSTR(UPPER(TRIM(ram_in_mb)), '\d+(\.\d{1,2})?', 1, 1),
   internal_storage = REGEXP_SUBSTR(UPPER(TRIM(internal_storage)), '\d+(\.\d{1,2})?', 1, 1),
   main_camera_mp = REGEXP_SUBSTR(UPPER(TRIM(main_camera_mp)), '\d+(\.\d{1,2})?', 1, 1),
   front_camera_mp = REGEXP_SUBSTR(UPPER(TRIM(front_camera_mp)), '\d+(\.\d{1,2})?', 1, 1),
   weight_gramm = REGEXP_SUBSTR(UPPER(TRIM(weight_gramm)), '\d+(\.\d{1,2})?', 1, 1),
   resolution_wid = REGEXP_SUBSTR(UPPER(TRIM(resolution_wid)), '\d+(\.\d{1,2})?', 1, 1),
   resolution_hig = REGEXP_SUBSTR(UPPER(TRIM(resolution_hig)), '\d+(\.\d{1,2})?', 1, 1),
   battery_capacity = REGEXP_SUBSTR(UPPER(TRIM(battery_capacity)), '\d+(\.\d{1,2})?', 1, 1);

-- Duplicate with model_code_X and rounded dimensions (half down)
PERFORM INSERT INTO ODS_GSM_ARENA_STAGE
  SELECT  
     brand_nm,
     model_code || '_X',
     model_nm,
     mktcode,
     mktname,
     CASE WHEN width_mm IS NULL OR width_mm = '' THEN width_mm ELSE CAST(FLOOR(CAST(width_mm AS NUMERIC(18,4)) + 0.4999999) AS VARCHAR) END AS width_mm,
     CASE WHEN height_mm IS NULL OR height_mm = '' THEN height_mm ELSE CAST(FLOOR(CAST(height_mm AS NUMERIC(18,4)) + 0.4999999) AS VARCHAR) END AS height_mm,
     CASE WHEN depth_mm IS NULL OR depth_mm = '' THEN depth_mm ELSE CAST(FLOOR(CAST(depth_mm AS NUMERIC(18,4)) + 0.4999999) AS VARCHAR) END AS depth_mm,
     display_size,
     ram_in_mb,
     internal_storage,
     dual_sim,
     main_camera_mp,
     front_camera_mp,
     weight_gramm,
     resolution_wid,
     resolution_hig,
     battery_capacity
  FROM ODS_GSM_ARENA_STAGE;

-- Cast numeric strings to standardized decimal strings
PERFORM UPDATE ODS_GSM_ARENA_STAGE
 SET
   width_mm = CAST(TO_DECIMAL(width_mm, 8, 1) AS VARCHAR),
   height_mm = CAST(TO_DECIMAL(height_mm, 8, 1) AS VARCHAR),
   depth_mm = CAST(TO_DECIMAL(depth_mm, 8, 1) AS VARCHAR),
   display_size = CAST(TO_DECIMAL(display_size, 6, 1) AS VARCHAR),
   ram_in_mb = CAST(TO_DECIMAL(ram_in_mb, 16, 1) AS VARCHAR),
   internal_storage = CAST(TO_DECIMAL(internal_storage, 8, 0) AS VARCHAR),
   main_camera_mp = CAST(TO_DECIMAL(main_camera_mp, 8, 0) AS VARCHAR),
   front_camera_mp = CAST(TO_DECIMAL(front_camera_mp, 8, 0) AS VARCHAR),
   weight_gramm = CAST(TO_DECIMAL(weight_gramm, 8, 1) AS VARCHAR),
   resolution_wid = CAST(TO_DECIMAL(resolution_wid, 8, 0) AS VARCHAR),
   resolution_hig = CAST(TO_DECIMAL(resolution_hig, 8, 0) AS VARCHAR),
   battery_capacity = CAST(TO_DECIMAL(battery_capacity, 8, 0) AS VARCHAR);
 
-- Replace null/empty with '$' marker, including dual_sim
PERFORM UPDATE ODS_GSM_ARENA_STAGE
 SET
   width_mm = CASE WHEN width_mm is null or width_mm = '' THEN '$' ELSE width_mm END,
   height_mm = CASE WHEN height_mm is null or height_mm = '' THEN '$' ELSE height_mm END,
   depth_mm = CASE WHEN depth_mm is null or depth_mm = '' THEN '$' ELSE depth_mm END,
   display_size = CASE WHEN display_size is null or display_size = '' THEN '$' ELSE display_size END,
   ram_in_mb = CASE WHEN ram_in_mb is null or ram_in_mb = '' THEN '$' ELSE ram_in_mb END,
   internal_storage = CASE WHEN internal_storage is null or internal_storage = '' THEN '$' ELSE internal_storage END,
   main_camera_mp = CASE WHEN main_camera_mp is null or main_camera_mp = '' THEN '$' ELSE main_camera_mp END,
   front_camera_mp = CASE WHEN front_camera_mp is null or front_camera_mp = '' THEN '$' ELSE front_camera_mp END,
   weight_gramm = CASE WHEN weight_gramm is null or weight_gramm = '' THEN '$' ELSE weight_gramm END,
   resolution_wid = CASE WHEN resolution_wid is null or resolution_wid = '' THEN '$' ELSE resolution_wid END,
   resolution_hig = CASE WHEN resolution_hig is null or resolution_hig = '' THEN '$' ELSE resolution_hig END,
   battery_capacity = CASE WHEN battery_capacity is null or battery_capacity = '' THEN '$' ELSE battery_capacity END,
   dual_sim = CASE WHEN dual_sim is null or dual_sim = '' THEN '$' ELSE dual_sim END;
 
PERFORM TRUNCATE TABLE MP_GSMARENA_MERGE_DATA_MAPPING;
PERFORM INSERT INTO MP_GSMARENA_MERGE_DATA_MAPPING
SELECT * FROM ODS_GSM_ARENA_STAGE;

PERFORM TRUNCATE TABLE MP_GSMARENA_MERGE_DATA_MAPPING_KEY;
PERFORM INSERT INTO MP_GSMARENA_MERGE_DATA_MAPPING_KEY
SELECT 
	brand_nm, 
	model_code,
	model_nm, 
	mktname,
	width_mm,
	height_mm,
	depth_mm,
	display_size,
	ram_in_mb,
	internal_storage,
	dual_sim,
	main_camera_mp,
	front_camera_mp,
	weight_gramm,
	resolution_wid,
	resolution_hig,
	battery_capacity,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'')) as case1,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'')) as case2,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'')) as case3,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'')) as case4,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'')) as case5,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( front_camera_mp,'')) as case6,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( ram_in_mb,'')) as case7,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( internal_storage,'')) as case8,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( battery_capacity,'')) as case9,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( dual_sim,'')) as case10,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'')) as case11,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'')) as case12,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'')) as case13,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( main_camera_mp,'')) as case14,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( front_camera_mp,'')) as case15,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( ram_in_mb,'')) as case16,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( internal_storage,'')) as case17,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( battery_capacity,'')) as case18,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( dual_sim,'')) as case19,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_wid,'')) as case20,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_hig,'')) as case21,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( main_camera_mp,'')) as case22,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( front_camera_mp,'')) as case23,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( ram_in_mb,'')) as case24,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( internal_storage,'')) as case25,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( battery_capacity,'')) as case26,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( dual_sim,'')) as case27,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( resolution_hig,'')) as case28,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( main_camera_mp,'')) as case29,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( front_camera_mp,'')) as case30,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( ram_in_mb,'')) as case31,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( internal_storage,'')) as case32,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( battery_capacity,'')) as case33,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( dual_sim,'')) as case34,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( main_camera_mp,'')) as case35,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( front_camera_mp,'')) as case36,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( ram_in_mb,'')) as case37,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( internal_storage,'')) as case38,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( battery_capacity,'')) as case39,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( dual_sim,'')) as case40,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'')) as case41,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case42,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case43,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case44,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case45,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case46,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case47,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case48,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case49,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'')) as case50,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( battery_capacity,'')) as case51,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( dual_sim,'')) as case52,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case53,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case54,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case55,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'')) as case56,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'')) as case57,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'')) as case58,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( main_camera_mp,'')) as case59,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( front_camera_mp,'')) as case60,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( ram_in_mb,'')) as case61,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( internal_storage,'')) as case62,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( battery_capacity,'')) as case63,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( dual_sim,'')) as case64,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_wid,'')) as case65,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_hig,'')) as case66,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( main_camera_mp,'')) as case67,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( front_camera_mp,'')) as case68,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( ram_in_mb,'')) as case69,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( internal_storage,'')) as case70,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( battery_capacity,'')) as case71,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( dual_sim,'')) as case72,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( resolution_hig,'')) as case73,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( main_camera_mp,'')) as case74,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( front_camera_mp,'')) as case75,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( ram_in_mb,'')) as case76,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( internal_storage,'')) as case77,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( battery_capacity,'')) as case78,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( dual_sim,'')) as case79,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( main_camera_mp,'')) as case80,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( front_camera_mp,'')) as case81,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( ram_in_mb,'')) as case82,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( internal_storage,'')) as case83,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( battery_capacity,'')) as case84,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( dual_sim,'')) as case85,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'')) as case86,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case87,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case88,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case89,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case90,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case91,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case92,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case93,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case94,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'')) as case95,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( battery_capacity,'')) as case96,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( dual_sim,'')) as case97,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case98,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case99,
	(COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case100,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_wid,'')) as case101,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_hig,'')) as case102,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( main_camera_mp,'')) as case103,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( front_camera_mp,'')) as case104,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( ram_in_mb,'')) as case105,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( internal_storage,'')) as case106,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( battery_capacity,'')) as case107,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( dual_sim,'')) as case108,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( resolution_hig,'')) as case109,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( main_camera_mp,'')) as case110,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( front_camera_mp,'')) as case111,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( ram_in_mb,'')) as case112,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( internal_storage,'')) as case113,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( battery_capacity,'')) as case114,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( dual_sim,'')) as case115,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( main_camera_mp,'')) as case116,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( front_camera_mp,'')) as case117,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( ram_in_mb,'')) as case118,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( internal_storage,'')) as case119,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( battery_capacity,'')) as case120,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( dual_sim,'')) as case121,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'')) as case122,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case123,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case124,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case125,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case126,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case127,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case128,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case129,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case130,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'')) as case131,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( battery_capacity,'')) as case132,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( dual_sim,'')) as case133,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case134,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case135,
	(COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case136,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'')) as case221,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'')) as case222,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'')) as case223,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'')) as case224,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( front_camera_mp,'')) as case225,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( ram_in_mb,'')) as case226,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( internal_storage,'')) as case227,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( battery_capacity,'')) as case228,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( dual_sim,'')) as case229,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'')) as case230,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'')) as case231,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'')) as case232,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( front_camera_mp,'')) as case233,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( ram_in_mb,'')) as case234,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( internal_storage,'')) as case235,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( battery_capacity,'')) as case236,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( dual_sim,'')) as case237,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'')) as case238,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'')) as case239,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( front_camera_mp,'')) as case240,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( ram_in_mb,'')) as case241,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( internal_storage,'')) as case242,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( battery_capacity,'')) as case243,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( dual_sim,'')) as case244,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_wid,'')) as case245,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_hig,'')) as case246,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( front_camera_mp,'')) as case247,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( ram_in_mb,'')) as case248,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( internal_storage,'')) as case249,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( battery_capacity,'')) as case250,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( dual_sim,'')) as case251,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( main_camera_mp,'')) as case252,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( front_camera_mp,'')) as case253,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( ram_in_mb,'')) as case254,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( internal_storage,'')) as case255,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( battery_capacity,'')) as case256,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( dual_sim,'')) as case257,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( front_camera_mp,'')) as case258,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( ram_in_mb,'')) as case259,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( internal_storage,'')) as case260,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( battery_capacity,'')) as case261,
	(COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( dual_sim,'')) as case262,
	(COALESCE(height_mm,'') || '_' || COALESCE( main_camera_mp,'')) as case263,
	(COALESCE(height_mm,'') || '_' || COALESCE( internal_storage,'')) as case264,
	(COALESCE(height_mm,'') || '_' || COALESCE( battery_capacity,'')) as case265,
	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'')) as case266,
	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'')) as case267,
	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'')) as case268,
	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( main_camera_mp,'')) as case269,
	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( front_camera_mp,'')) as case270,
	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( ram_in_mb,'')) as case271,
	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( internal_storage,'')) as case272,
	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( battery_capacity,'')) as case273,
	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( dual_sim,'')) as case274,
	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( resolution_hig,'')) as case275,
	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( main_camera_mp,'')) as case276,
	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( front_camera_mp,'')) as case277,
	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( ram_in_mb,'')) as case278,
	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( internal_storage,'')) as case279,
	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( battery_capacity,'')) as case280,
	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( dual_sim,'')) as case281,
	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( main_camera_mp,'')) as case282,
	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( front_camera_mp,'')) as case283,
	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( ram_in_mb,'')) as case284,
	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( internal_storage,'')) as case285,
	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( battery_capacity,'')) as case286,
	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( dual_sim,'')) as case287,
	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'')) as case288,
	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case289,
	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case290,
	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case291,
	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case292,
	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( front_camera_mp,'')) as case293,
	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( ram_in_mb,'')) as case294,
	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( internal_storage,'')) as case295,
	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( battery_capacity,'')) as case296,
	(COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( dual_sim,'')) as case297,
	(COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'')) as case302,
	(COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'')) as case303,
	(COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'')) as case304,
	(COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( main_camera_mp,'')) as case305,
	(COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( front_camera_mp,'')) as case306,
	(COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( ram_in_mb,'')) as case307,
	(COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( internal_storage,'')) as case308,
	(COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( battery_capacity,'')) as case309,
	(COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( dual_sim,'')) as case310,
	(COALESCE(width_mm,'') || '_' || COALESCE( resolution_wid,'')) as case311,
	(COALESCE(width_mm,'') || '_' || COALESCE( resolution_hig,'')) as case312,
	(COALESCE(width_mm,'') || '_' || COALESCE( main_camera_mp,'')) as case313,
	(COALESCE(width_mm,'') || '_' || COALESCE( front_camera_mp,'')) as case314,
	(COALESCE(width_mm,'') || '_' || COALESCE( ram_in_mb,'')) as case315,
	(COALESCE(width_mm,'') || '_' || COALESCE( internal_storage,'')) as case316,
	(COALESCE(width_mm,'') || '_' || COALESCE( battery_capacity,'')) as case317,
	(COALESCE(width_mm,'') || '_' || COALESCE( dual_sim,'')) as case318,
	(COALESCE(weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_wid,'')) as case319,
	(COALESCE(weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_hig,'')) as case320,
	(COALESCE(weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( main_camera_mp,'')) as case321,
	(COALESCE(weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( front_camera_mp,'')) as case322,
	(COALESCE(weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( ram_in_mb,'')) as case323,
	(COALESCE(weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( internal_storage,'')) as case324,
	(COALESCE(weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( battery_capacity,'')) as case325,
	(COALESCE(weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( dual_sim,'')) as case326,
	(COALESCE(weight_gramm,'') || '_' || COALESCE( resolution_wid,'')) as case327,
	(COALESCE(weight_gramm,'') || '_' || COALESCE( resolution_hig,'')) as case328,
	(COALESCE(weight_gramm,'') || '_' || COALESCE( main_camera_mp,'')) as case329,
	(COALESCE(weight_gramm,'') || '_' || COALESCE( front_camera_mp,'')) as case330,
	(COALESCE(weight_gramm,'') || '_' || COALESCE( ram_in_mb,'')) as case331,
	(COALESCE(weight_gramm,'') || '_' || COALESCE( internal_storage,'')) as case332,
	(COALESCE(weight_gramm,'') || '_' || COALESCE( battery_capacity,'')) as case333,
	(COALESCE(weight_gramm,'') || '_' || COALESCE( dual_sim,'')) as case334,
	(COALESCE(display_size,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( resolution_hig,'')) as case335,
	(COALESCE(display_size,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( main_camera_mp,'')) as case336,
	(COALESCE(display_size,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( front_camera_mp,'')) as case337,
	(COALESCE(display_size,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( ram_in_mb,'')) as case338,
	(COALESCE(display_size,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( internal_storage,'')) as case339,
	(COALESCE(display_size,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( battery_capacity,'')) as case340,
	(COALESCE(display_size,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( dual_sim,'')) as case341,
	(COALESCE(display_size,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( main_camera_mp,'')) as case342,
	(COALESCE(display_size,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( front_camera_mp,'')) as case343,
	(COALESCE(display_size,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( ram_in_mb,'')) as case344,
	(COALESCE(display_size,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( internal_storage,'')) as case345,
	(COALESCE(display_size,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( battery_capacity,'')) as case346,
	(COALESCE(display_size,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( dual_sim,'')) as case347,
	(COALESCE(display_size,'') || '_' || COALESCE( main_camera_mp,'')) as case348,
	(COALESCE(display_size,'') || '_' || COALESCE( front_camera_mp,'')) as case349,
	(COALESCE(display_size,'') || '_' || COALESCE( ram_in_mb,'')) as case350,
	(COALESCE(display_size,'') || '_' || COALESCE( internal_storage,'')) as case351,
	(COALESCE(display_size,'') || '_' || COALESCE( battery_capacity,'')) as case352,
	(COALESCE(display_size,'') || '_' || COALESCE( dual_sim,'')) as case353,
	(COALESCE(resolution_wid,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( main_camera_mp,'')) as case646,
	(COALESCE(resolution_wid,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( front_camera_mp,'')) as case647,
	(COALESCE(resolution_wid,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( ram_in_mb,'')) as case648,
	(COALESCE(resolution_wid,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( internal_storage,'')) as case649,
	(COALESCE(resolution_wid,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( battery_capacity,'')) as case650,
	(COALESCE(resolution_wid,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( dual_sim,'')) as case651,
	(COALESCE(resolution_wid,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'')) as case661,
	(COALESCE(resolution_wid,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case662,
	(COALESCE(resolution_wid,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case663,
	(COALESCE(resolution_wid,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case664,
	(COALESCE(resolution_wid,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case665,
	(COALESCE(resolution_wid,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case666,
	(COALESCE(resolution_wid,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case667,
	(COALESCE(resolution_wid,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case668,
	(COALESCE(resolution_wid,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case669,
	(COALESCE(resolution_wid,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'')) as case670,
	(COALESCE(resolution_wid,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( battery_capacity,'')) as case671,
	(COALESCE(resolution_wid,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( dual_sim,'')) as case672,
	(COALESCE(resolution_wid,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case673,
	(COALESCE(resolution_wid,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case674,
	(COALESCE(resolution_wid,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case675,
	(COALESCE(resolution_hig,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'')) as case681,
	(COALESCE(resolution_hig,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case682,
	(COALESCE(resolution_hig,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case683,
	(COALESCE(resolution_hig,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case684,
	(COALESCE(resolution_hig,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case685,
	(COALESCE(resolution_hig,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case686,
	(COALESCE(resolution_hig,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case687,
	(COALESCE(resolution_hig,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case688,
	(COALESCE(resolution_hig,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case689,
	(COALESCE(resolution_hig,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'')) as case690,
	(COALESCE(resolution_hig,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( battery_capacity,'')) as case691,
	(COALESCE(resolution_hig,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( dual_sim,'')) as case692,
	(COALESCE(resolution_hig,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case693,
	(COALESCE(resolution_hig,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case694,
	(COALESCE(resolution_hig,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case695,
	(COALESCE(main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case701,
	(COALESCE(main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case702,
	(COALESCE(main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case703,
	(COALESCE(main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case704,
	(COALESCE(main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'')) as case705,
	(COALESCE(main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( battery_capacity,'')) as case706,
	(COALESCE(main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( dual_sim,'')) as case707,
	(COALESCE(main_camera_mp,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case708,
	(COALESCE(main_camera_mp,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case709,
	(COALESCE(main_camera_mp,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case710,
	(COALESCE(front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'')) as case711,
	(COALESCE(front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( battery_capacity,'')) as case712,
	(COALESCE(front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( dual_sim,'')) as case713,
	(COALESCE(front_camera_mp,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case714,
	(COALESCE(ram_in_mb,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case715
FROM ODS_GSM_ARENA_STAGE;

END;
$$;

-- CALL PROC_GSMARENA_MAPPING_1_0();
-- ERROR: Severity: ROLLBACK, Message: Table "ODS_GSM_ARENA_STAGE" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_GSMARENA_MAPPING_1_0 line 4 at static SQL, Routine: TruncateTable, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Commands/DDL.cpp, Line: 20681, Error Code: 4876, 
-- CALL PROC_GSMARENA_MAPPING_1_0();
-- ERROR: Severity: ROLLBACK, Message: Table "ODS_GSM_ARENA_STAGE" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_GSMARENA_MAPPING_1_0 line 4 at static SQL, Routine: TruncateTable, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Commands/DDL.cpp, Line: 20681, Error Code: 4876, 
