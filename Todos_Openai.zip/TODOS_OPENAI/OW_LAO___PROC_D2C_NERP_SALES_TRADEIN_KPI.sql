CREATE OR REPLACE PROCEDURE OW_LAO.PROC_D2C_NERP_SALES_TRADEIN_KPI()
LANGUAGE PLvSQL AS $$
BEGIN
    -- Execute trade-in procedure
    PERFORM CALL OW_LAO.PROC_D2C_NERP_SALES_TRADEIN();

    -- Drop and recreate target KPI table
    PERFORM TRUNCATE TABLE OW_LAO.TF_D2C_NERP_TRADEIN_SALES_KPI;

    PERFORM INSERT INTO OW_LAO.TF_D2C_NERP_TRADEIN_SALES_KPI
        SELECT
              PO."SOURCE"
            , PO.DATE_REF
            , PO.YYYYWW
            , PO.YYYYMM
            , PO.YYYYQQ
            , PO.SUBSIDIARY
            , PO.COUNTRY
            , PO.CURRENCY
            , PO.SKU
            , PO.PDROD_DIVISION
            , PO.PDROD_PRODUCT_GROUP
            , PO.PDROD_PRODUCT
            , PO.PROD_ATTB_1
            , PO.SEDA_BU_ESTORE
            , PO.SEDA_DIVISION_ESTORE
            , PO.SEDA_CATEGORY_ESTORE
            , PO.SEDA_FAMILY_ESTORE
            , PO.SEDA_DESC_ESTORE
            , PO.ITEM_NAME
            , PO.NAME_STORE
            , PO.CHANNEL_TYPE
            , PO.O2O_TYPE
            , PO.STATUS_PO
            , SP.STATUS
            , PO.AFFILIATE_ID_ADJUSTED
            , PO.AFFILIATE_CHANNEL
            , PO.AFFILIATE_SUB_CHANNEL
            , PO.AFFILIATE_PARTNER_LEVEL
            , PO.GLOBAL_CHANNEL
            , PO.BIZ_TYPE
            , PO.AUDIENCE_TYPE
            , SUM(PO.QTY) AS QTY
            , SUM(PO.AMOUNT_LOCAL) AS AMOUNT_LOCAL
            , SUM(PO.AMOUNT_USD) AS AMOUNT_USD
            , PO.IS_TRADE_IN
            , PO.TRADE_IN_REFID
            , PO.TRADE_IN_PRODUCT_NAME
            , PO.PRODUCT_BRAND
            , PO.IS_GTI
            , PO.CHANNEL_O2O
            , PO.PARTNER_O2O
            , PO.STORE_TYPE_O2O
            , PO.STORE_NAME_O2O
            , SUM(PO.TRADE_IN_GTI) AS TRADE_IN_GTI
            , SUM(PO.TRADE_IN_BOOST) AS TRADE_IN_BOOST
            , SUM(CAST(PO.TRADE_IN_TOTAL AS DECIMAL(18,2))) AS TRADE_IN_TOTAL
            , SUM(PO.TRADE_IN_PRODUCT_PRICE) AS TRADE_IN_PRODUCT_PRICE
            , CURRENT_TIMESTAMP AS KPI_LAST_UPDATE
        FROM OW_LAO.TF_D2C_PO_VTEX_TRADE_IN PO
        LEFT JOIN OW_MD.DIM_PO_STATUS SP
          ON UPPER(SP.STATUS_PO) = UPPER(PO.STATUS_PO)
        WHERE PO.IS_TRADE_IN = 'true'
          AND PO.STATUS_PO NOT IN ('cancel','canceled')
        GROUP BY
              PO."SOURCE"
            , PO.DATE_REF
            , PO.YYYYWW
            , PO.YYYYMM
            , PO.YYYYQQ
            , PO.SUBSIDIARY
            , PO.COUNTRY
            , PO.CURRENCY
            , PO.SKU
            , PO.PDROD_DIVISION
            , PO.PDROD_PRODUCT_GROUP
            , PO.PDROD_PRODUCT
            , PO.PROD_ATTB_1
            , PO.SEDA_BU_ESTORE
            , PO.SEDA_DIVISION_ESTORE
            , PO.SEDA_CATEGORY_ESTORE
            , PO.SEDA_FAMILY_ESTORE
            , PO.SEDA_DESC_ESTORE
            , PO.ITEM_NAME
            , PO.NAME_STORE
            , PO.CHANNEL_TYPE
            , PO.O2O_TYPE
            , PO.STATUS_PO
            , SP.STATUS
            , PO.AFFILIATE_ID_ADJUSTED
            , PO.AFFILIATE_CHANNEL
            , PO.AFFILIATE_SUB_CHANNEL
            , PO.AFFILIATE_PARTNER_LEVEL
            , PO.GLOBAL_CHANNEL
            , PO.BIZ_TYPE
            , PO.AUDIENCE_TYPE
            , PO.IS_TRADE_IN
            , PO.TRADE_IN_REFID
            , PO.TRADE_IN_PRODUCT_NAME
            , PO.PRODUCT_BRAND
            , PO.IS_GTI
            , PO.CHANNEL_O2O
            , PO.PARTNER_O2O
            , PO.STORE_TYPE_O2O
            , PO.STORE_NAME_O2O;

    PERFORM UPDATE OW_LAO.TF_D2C_NERP_TRADEIN_SALES_KPI SET
        KPI_LAST_UPDATE = (
            SELECT MAX(PO_CREATION_DATE)
            FROM OW_LAO.TF_D2C_NERP_SALES
            WHERE "SOURCE" = 'PO'
              AND SUBSIDIARY = 'SEDA'
        );

END;
$$;
