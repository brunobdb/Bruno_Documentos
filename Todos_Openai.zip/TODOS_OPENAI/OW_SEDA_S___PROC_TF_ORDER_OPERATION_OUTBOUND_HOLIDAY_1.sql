CREATE OR REPLACE PROCEDURE OW_SEDA_S.PROC_TF_ORDER_OPERATION_OUTBOUND_HOLIDAY_1()
LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM TRUNCATE TABLE "OW_SEDA_S"."TF_ORDER_OPERATION_OUTBOUND_HOLIDAY_1";

    PERFORM INSERT INTO "OW_SEDA_S"."TF_ORDER_OPERATION_OUTBOUND_HOLIDAY_1"
    SELECT
         "P"."Booking Request"
        ,"P"."DO_CONSOLIDATION"
        ,"P"."ACCESSORY"
        ,"P"."BOOKING_CONFIRM_DATE_TIME"
        ,"P"."Carrier"
        ,"P"."MANIFESTO"
        ,"P"."Ship__Shipping_Type"
        ,"P"."Plant"
        ,"P"."Distribution Ch."
        ,"P"."Delivery No."
        ,"P"."Mtl.Division"
        ,"P"."Document Date(Local)"
        ,"P"."Region"
        ,"P"."1st GI Date"
        ,"P"."P/O No."
        ,"P"."Receiving Booking Confirm"
        ,"P"."Booking Confirm"
        ,"P"."RDD"
        ,"P"."Mtl. Group"
        ,"P"."Order_Class"
        ,"P"."Source_Code"
        ,"P"."Source"
        ,"P"."Booking_Type"
        ,"P"."first_Booking_Date"
        ,"P"."Last_Booking_Date"
        ,"P"."Ship-to_Party_Code"
        ,"P"."Sold-to_Party"
        ,"P"."Ship-to_Party_Code_1"
        ,"P"."Sub_Carrier"
        ,"P"."GI_Date"
        ,"P"."First_Arrival_Date"
        ,"P"."Last_Arrival_Date"
        ,"P"."IOD_Date"
        ,"P"."Last_IOD_Registration"
        ,"P"."Gross_Vol_(CBM)"
        ,"P"."NF_Amt"
        ,"P"."UDF"
        ,"P"."Vehicle_Type"
        ,"P"."Unload_Customer_DC"
        ,"P"."Delivery_Qty_TSS"
        ,"P"."Ship-to_Party"
        ,"P"."BillTo Name"
        ,"P"."NOME2"
        ,"P"."NOME"
        ,SUM("H1"."Flag_Holidays") AS Holiday_DO_BookingReq
        ,0 AS Holiday_Req_Rec
        ,0 AS Holiday_Rec_GI
        ,0 AS Holiday_GI_IOD
        ,0 AS Holiday_DO_IOD
        ,"P"."City"
        ,"P"."Gross_Wgt"
        ,LOAD_DATE
    FROM "OW_SEDA_S"."ODS_ERP_OUTBOUND_PENTAHO1" AS P
    LEFT JOIN "OW_SEDA_S"."VW_CALENDAR_HOLYDAYS" AS H1
      ON P."Document Date(Local)" <= H1."Data"
     AND P."Booking Request" >= H1."Data"
    GROUP BY
         "P"."Booking Request"
        ,"P"."DO_CONSOLIDATION"
        ,"P"."ACCESSORY"
        ,"P"."BOOKING_CONFIRM_DATE_TIME"
        ,"P"."Carrier"
        ,"P"."MANIFESTO"
        ,"P"."Ship__Shipping_Type"
        ,"P"."Plant"
        ,"P"."Distribution Ch."
        ,"P"."Delivery No."
        ,"P"."Mtl.Division"
        ,"P"."Document Date(Local)"
        ,"P"."Region"
        ,"P"."1st GI Date"
        ,"P"."P/O No."
        ,"P"."Receiving Booking Confirm"
        ,"P"."Booking Confirm"
        ,"P"."RDD"
        ,"P"."Mtl. Group"
        ,"P"."Order_Class"
        ,"P"."Source_Code"
        ,"P"."Source"
        ,"P"."Booking_Type"
        ,"P"."first_Booking_Date"
        ,"P"."Last_Booking_Date"
        ,"P"."Ship-to_Party_Code"
        ,"P"."Sold-to_Party"
        ,"P"."Ship-to_Party_Code_1"
        ,"P"."Sub_Carrier"
        ,"P"."GI_Date"
        ,"P"."First_Arrival_Date"
        ,"P"."Last_Arrival_Date"
        ,"P"."IOD_Date"
        ,"P"."Last_IOD_Registration"
        ,"P"."Gross_Vol_(CBM)"
        ,"P"."NF_Amt"
        ,"P"."UDF"
        ,"P"."Vehicle_Type"
        ,"P"."Unload_Customer_DC"
        ,"P"."Delivery_Qty_TSS"
        ,"P"."Ship-to_Party"
        ,"P"."BillTo Name"
        ,"P"."NOME2"
        ,"P"."City"
        ,"P"."NOME"
        ,"P"."Gross_Wgt"
        ,LOAD_DATE;
END;
$$;

-- CALL OW_SEDA_S.PROC_TF_ORDER_OPERATION_OUTBOUND_HOLIDAY_1();
-- ERROR: Severity: ROLLBACK, Message: Table "TF_ORDER_OPERATION_OUTBOUND_HOLIDAY_1" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_TF_ORDER_OPERATION_OUTBOUND_HOLIDAY_1 line 3 at static SQL, Routine: TruncateTable, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Commands/DDL.cpp, Line: 20681, Error Code: 4876, 
-- CALL OW_SEDA_S.PROC_TF_ORDER_OPERATION_OUTBOUND_HOLIDAY_1();
-- ERROR: Severity: ROLLBACK, Message: Table "TF_ORDER_OPERATION_OUTBOUND_HOLIDAY_1" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_TF_ORDER_OPERATION_OUTBOUND_HOLIDAY_1 line 3 at static SQL, Routine: TruncateTable, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Commands/DDL.cpp, Line: 20681, Error Code: 4876, 
