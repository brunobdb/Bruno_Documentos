CREATE OR REPLACE PROCEDURE OW_LAO.PROC_ODS_HYBRIS_CANCELLATIONS()
LANGUAGE PLvSQL AS $$
BEGIN
    
    PERFORM DROP TABLE IF EXISTS TMP_HYBRIS_CANCELLATIONS_DEDUP;
    
    PERFORM CREATE LOCAL TEMP TABLE TMP_HYBRIS_CANCELLATIONS_DEDUP ON COMMIT PRESERVE ROWS AS (
        SELECT 
              ROW_NUMBER() OVER (
                  PARTITION BY country_cd, cart_id, line_item_id
                  ORDER BY file_generated_at DESC
              ) AS dedup
            , *
        FROM OW_LAO.RAW_HYBRIS_CANCELLATIONS a
        WHERE NOT EXISTS (
            SELECT 1
            FROM OW_LAO.ODS_HYBRIS_CANCELLATIONS aa
            WHERE aa.Country_Cd = a.Country_Cd
              AND aa.Cart_id = a.Cart_id
              AND aa.line_item_id = a.line_item_id
              AND aa.file_generated_at >= a.file_generated_at
        )
    );
    
    PERFORM DELETE FROM TMP_HYBRIS_CANCELLATIONS_DEDUP WHERE dedup <> 1;

    PERFORM MERGE INTO OW_LAO.ODS_HYBRIS_CANCELLATIONS a
    USING TMP_HYBRIS_CANCELLATIONS_DEDUP b
      ON b.Country_Cd = a.Country_Cd
     AND b.Cart_id = a.Cart_id
     AND b.line_item_id = a.line_item_id
    WHEN MATCHED THEN UPDATE SET
          a."CANCELLATION_DATE" = b."CANCELLATION_DATE"
        , a."ORDER_DATE_LOCAL" = b."ORDER_DATE_LOCAL"
        , a."PO_ID" = b."PO_ID"
        , a."CANCELLATION_STATUS" = b."CANCELLATION_STATUS"
        , a."CANCELLATION_REASON_CODE" = b."CANCELLATION_REASON_CODE"
        , a."CANCELLATION_TYPE" = b."CANCELLATION_TYPE"
        , a."CANCELLATION_REASON" = b."CANCELLATION_REASON"
        , a."QUANTITY" = b."QUANTITY"
        , a."SUBTOTAL_AMOUNT" = b."SUBTOTAL_AMOUNT"
        , a."TAXES" = b."TAXES"
        , a."SALES_PRICE_LOCAL" = b."SALES_PRICE_LOCAL"
        , a."UNIT_SALES_PRICE" = b."UNIT_SALES_PRICE"
        , a."LINE_ITEM_QUANTITY" = b."LINE_ITEM_QUANTITY"
        , a."TAXONOMY_NAME" = b."TAXONOMY_NAME"
        , a."TAXONOMY_PRODUCT_CATEGORY" = b."TAXONOMY_PRODUCT_CATEGORY"
        , a."TAXONOMY_PRODUCT_FAMILY" = b."TAXONOMY_PRODUCT_FAMILY"
        , a."PRODUCT_NAME" = b."PRODUCT_NAME"
        , a."PRODUCT_TYPE" = b."PRODUCT_TYPE"
        , a."PRODUCT_MODEL_CODE" = b."PRODUCT_MODEL_CODE"
        , a."PRODUCT_MODEL_NAME" = b."PRODUCT_MODEL_NAME"
        , a."FAMILY_ID" = b."FAMILY_ID"
        , a."SKU" = b."SKU"
        , a."EAN" = b."EAN"
        , a."ORDER_CHANNEL_CODE" = b."ORDER_CHANNEL_CODE"
        , a."PROGRAM_TYPE" = b."PROGRAM_TYPE"
        , a."STORE_ID" = b."STORE_ID"
        , a."STORE_NAME" = b."STORE_NAME"
        , a."CART_TYPE" = b."CART_TYPE"
        , a."CANCELLED_BY_AGENT" = b."CANCELLED_BY_AGENT"
        , a."CANCELLATION_ID" = b."CANCELLATION_ID"
        , a."TAXONOMY_PRODUCT_DIVISION" = b."TAXONOMY_PRODUCT_DIVISION"
        , a."FILE_NAME_FROM_FILE" = b."FILE_NAME_FROM_FILE"
        , a."LOAD_DATE" = b."LOAD_DATE"
        , a."FILE_NAME" = b."FILE_NAME"
        , a."FILE_LAST_MODIFIED_TIME" = b."FILE_LAST_MODIFIED_TIME"
        , a."FILE_NAME_SHORT" = b."FILE_NAME_SHORT"
        , a."FILE_GENERATED_AT" = b."FILE_GENERATED_AT"
        , a."UPDATED_DATETIME" = CURRENT_TIMESTAMP
    WHEN NOT MATCHED THEN INSERT VALUES (
          b."LINE_ITEM_ID"
        , b."COUNTRY_CD"
        , b."CANCELLATION_DATE"
        , b."ORDER_DATE_LOCAL"
        , b."PO_ID"
        , b."CANCELLATION_STATUS"
        , b."CANCELLATION_REASON_CODE"
        , b."CANCELLATION_TYPE"
        , b."CANCELLATION_REASON"
        , b."QUANTITY"
        , b."SUBTOTAL_AMOUNT"
        , b."TAXES"
        , b."SALES_PRICE_LOCAL"
        , b."UNIT_SALES_PRICE"
        , b."LINE_ITEM_QUANTITY"
        , b."TAXONOMY_NAME"
        , b."TAXONOMY_PRODUCT_CATEGORY"
        , b."TAXONOMY_PRODUCT_FAMILY"
        , b."PRODUCT_NAME"
        , b."PRODUCT_TYPE"
        , b."PRODUCT_MODEL_CODE"
        , b."PRODUCT_MODEL_NAME"
        , b."FAMILY_ID"
        , b."SKU"
        , b."EAN"
        , b."ORDER_CHANNEL_CODE"
        , b."PROGRAM_TYPE"
        , b."STORE_ID"
        , b."STORE_NAME"
        , b."CART_TYPE"
        , b."CANCELLED_BY_AGENT"
        , b."CANCELLATION_ID"
        , b."CART_ID"
        , b."TAXONOMY_PRODUCT_DIVISION"
        , b."FILE_NAME_FROM_FILE"
        , b."LOAD_DATE"
        , b."FILE_NAME"
        , b."FILE_LAST_MODIFIED_TIME"
        , b."FILE_NAME_SHORT"
        , NULL
        , b."FILE_GENERATED_AT"
        , NULL
    );

END;
$$;

-- CALL OW_LAO.PROC_ODS_HYBRIS_CANCELLATIONS();
-- ERROR: Severity: ERROR, Message: Either column "a" does not exist or table alias "a" is not allowed in "WHEN MATCHED THEN UPDATE SET", Sqlstate: 42602, Hint: Either fix the column name "a" or remove table alias "a" from all column names in "WHEN MATCHED THEN UPDATE SET", Where: PL/vSQL procedure PROC_ODS_HYBRIS_CANCELLATIONS line 26 at static SQL, Routine: transformVMergeStmt, File: analyze.c, Line: 3541, Error Code: 5569, 
-- CALL OW_LAO.PROC_ODS_HYBRIS_CANCELLATIONS();
-- ERROR: Severity: ERROR, Message: Either column "a" does not exist or table alias "a" is not allowed in "WHEN MATCHED THEN UPDATE SET", Sqlstate: 42602, Hint: Either fix the column name "a" or remove table alias "a" from all column names in "WHEN MATCHED THEN UPDATE SET", Where: PL/vSQL procedure PROC_ODS_HYBRIS_CANCELLATIONS line 26 at static SQL, Routine: transformVMergeStmt, File: analyze.c, Line: 3541, Error Code: 5569, 
CREATE OR REPLACE PROCEDURE OW_LAO.PROC_ODS_HYBRIS_CANCELLATIONS()
LANGUAGE PLvSQL AS $$
BEGIN
    
    PERFORM DROP TABLE IF EXISTS TMP_HYBRIS_CANCELLATIONS_DEDUP;
    
    PERFORM CREATE LOCAL TEMP TABLE TMP_HYBRIS_CANCELLATIONS_DEDUP ON COMMIT PRESERVE ROWS AS
        SELECT 
              ROW_NUMBER() OVER (
                  PARTITION BY country_cd, cart_id, line_item_id
                  ORDER BY file_generated_at DESC
              ) AS dedup
            , *
        FROM OW_LAO.RAW_HYBRIS_CANCELLATIONS a
        WHERE NOT EXISTS (
            SELECT 1
            FROM OW_LAO.ODS_HYBRIS_CANCELLATIONS aa
            WHERE aa.Country_Cd = a.Country_Cd
              AND aa.Cart_id = a.Cart_id
              AND aa.line_item_id = a.line_item_id
              AND aa.file_generated_at >= a.file_generated_at
        );
    
    PERFORM DELETE FROM TMP_HYBRIS_CANCELLATIONS_DEDUP WHERE dedup <> 1;

    PERFORM MERGE INTO OW_LAO.ODS_HYBRIS_CANCELLATIONS a
    USING TMP_HYBRIS_CANCELLATIONS_DEDUP b
      ON b.Country_Cd = a.Country_Cd
     AND b.Cart_id = a.Cart_id
     AND b.line_item_id = a.line_item_id
    WHEN MATCHED THEN UPDATE SET
          "CANCELLATION_DATE" = b."CANCELLATION_DATE"
        , "ORDER_DATE_LOCAL" = b."ORDER_DATE_LOCAL"
        , "PO_ID" = b."PO_ID"
        , "CANCELLATION_STATUS" = b."CANCELLATION_STATUS"
        , "CANCELLATION_REASON_CODE" = b."CANCELLATION_REASON_CODE"
        , "CANCELLATION_TYPE" = b."CANCELLATION_TYPE"
        , "CANCELLATION_REASON" = b."CANCELLATION_REASON"
        , "QUANTITY" = b."QUANTITY"
        , "SUBTOTAL_AMOUNT" = b."SUBTOTAL_AMOUNT"
        , "TAXES" = b."TAXES"
        , "SALES_PRICE_LOCAL" = b."SALES_PRICE_LOCAL"
        , "UNIT_SALES_PRICE" = b."UNIT_SALES_PRICE"
        , "LINE_ITEM_QUANTITY" = b."LINE_ITEM_QUANTITY"
        , "TAXONOMY_NAME" = b."TAXONOMY_NAME"
        , "TAXONOMY_PRODUCT_CATEGORY" = b."TAXONOMY_PRODUCT_CATEGORY"
        , "TAXONOMY_PRODUCT_FAMILY" = b."TAXONOMY_PRODUCT_FAMILY"
        , "PRODUCT_NAME" = b."PRODUCT_NAME"
        , "PRODUCT_TYPE" = b."PRODUCT_TYPE"
        , "PRODUCT_MODEL_CODE" = b."PRODUCT_MODEL_CODE"
        , "PRODUCT_MODEL_NAME" = b."PRODUCT_MODEL_NAME"
        , "FAMILY_ID" = b."FAMILY_ID"
        , "SKU" = b."SKU"
        , "EAN" = b."EAN"
        , "ORDER_CHANNEL_CODE" = b."ORDER_CHANNEL_CODE"
        , "PROGRAM_TYPE" = b."PROGRAM_TYPE"
        , "STORE_ID" = b."STORE_ID"
        , "STORE_NAME" = b."STORE_NAME"
        , "CART_TYPE" = b."CART_TYPE"
        , "CANCELLED_BY_AGENT" = b."CANCELLED_BY_AGENT"
        , "CANCELLATION_ID" = b."CANCELLATION_ID"
        , "TAXONOMY_PRODUCT_DIVISION" = b."TAXONOMY_PRODUCT_DIVISION"
        , "FILE_NAME_FROM_FILE" = b."FILE_NAME_FROM_FILE"
        , "LOAD_DATE" = b."LOAD_DATE"
        , "FILE_NAME" = b."FILE_NAME"
        , "FILE_LAST_MODIFIED_TIME" = b."FILE_LAST_MODIFIED_TIME"
        , "FILE_NAME_SHORT" = b."FILE_NAME_SHORT"
        , "FILE_GENERATED_AT" = b."FILE_GENERATED_AT"
        , "UPDATED_DATETIME" = CURRENT_TIMESTAMP
    WHEN NOT MATCHED THEN INSERT VALUES (
          b."LINE_ITEM_ID"
        , b."COUNTRY_CD"
        , b."CANCELLATION_DATE"
        , b."ORDER_DATE_LOCAL"
        , b."PO_ID"
        , b."CANCELLATION_STATUS"
        , b."CANCELLATION_REASON_CODE"
        , b."CANCELLATION_TYPE"
        , b."CANCELLATION_REASON"
        , b."QUANTITY"
        , b."SUBTOTAL_AMOUNT"
        , b."TAXES"
        , b."SALES_PRICE_LOCAL"
        , b."UNIT_SALES_PRICE"
        , b."LINE_ITEM_QUANTITY"
        , b."TAXONOMY_NAME"
        , b."TAXONOMY_PRODUCT_CATEGORY"
        , b."TAXONOMY_PRODUCT_FAMILY"
        , b."PRODUCT_NAME"
        , b."PRODUCT_TYPE"
        , b."PRODUCT_MODEL_CODE"
        , b."PRODUCT_MODEL_NAME"
        , b."FAMILY_ID"
        , b."SKU"
        , b."EAN"
        , b."ORDER_CHANNEL_CODE"
        , b."PROGRAM_TYPE"
        , b."STORE_ID"
        , b."STORE_NAME"
        , b."CART_TYPE"
        , b."CANCELLED_BY_AGENT"
        , b."CANCELLATION_ID"
        , b."CART_ID"
        , b."TAXONOMY_PRODUCT_DIVISION"
        , b."FILE_NAME_FROM_FILE"
        , b."LOAD_DATE"
        , b."FILE_NAME"
        , b."FILE_LAST_MODIFIED_TIME"
        , b."FILE_NAME_SHORT"
        , NULL
        , b."FILE_GENERATED_AT"
        , NULL
    );

END;
$$;

-- CALL OW_LAO.PROC_ODS_HYBRIS_CANCELLATIONS();
-- ERROR: Severity: ERROR, Message: Column "ID" is of type int but expression is of type varchar, Sqlstate: 42804, Hint: You will need to rewrite or cast the expression, Where: PL/vSQL procedure PROC_ODS_HYBRIS_CANCELLATIONS line 25 at static SQL, Routine: updateTargetListEntry, File: parse_target.c, Line: 853, Error Code: 2631, 
-- CALL OW_LAO.PROC_ODS_HYBRIS_CANCELLATIONS();
-- ERROR: Severity: ERROR, Message: Column "ID" is of type int but expression is of type varchar, Sqlstate: 42804, Hint: You will need to rewrite or cast the expression, Where: PL/vSQL procedure PROC_ODS_HYBRIS_CANCELLATIONS line 25 at static SQL, Routine: updateTargetListEntry, File: parse_target.c, Line: 853, Error Code: 2631, 
SELECT column_name, data_type, ordinal_position
FROM v_catalog.columns
WHERE table_schema = 'OW_LAO' AND table_name = 'ODS_HYBRIS_CANCELLATIONS'
ORDER BY ordinal_position;
-- column_name | data_type | ordinal_position
-- ------------+-----------+-----------------
-- ID | int | 1
-- LINE_ITEM_ID | varchar(255) | 2
-- COUNTRY_CD | varchar(255) | 3
-- CANCELLATION_DATE | varchar(255) | 4
-- ORDER_DATE_LOCAL | varchar(255) | 5
-- PO_ID | varchar(255) | 6
-- CANCELLATION_STATUS | varchar(255) | 7
-- CANCELLATION_REASON_CODE | varchar(255) | 8
-- CANCELLATION_TYPE | varchar(255) | 9
-- CANCELLATION_REASON | varchar(255) | 10
-- QUANTITY | int | 11
-- SUBTOTAL_AMOUNT | numeric(34,0) | 12
-- TAXES | numeric(34,0) | 13
-- SALES_PRICE_LOCAL | numeric(34,0) | 14
-- UNIT_SALES_PRICE | numeric(34,0) | 15
-- LINE_ITEM_QUANTITY | int | 16
-- TAXONOMY_NAME | varchar(255) | 17
-- TAXONOMY_PRODUCT_CATEGORY | varchar(255) | 18
-- TAXONOMY_PRODUCT_FAMILY | varchar(255) | 19
-- PRODUCT_NAME | varchar(255) | 20
-- PRODUCT_TYPE | varchar(255) | 21
-- PRODUCT_MODEL_CODE | varchar(255) | 22
-- PRODUCT_MODEL_NAME | varchar(255) | 23
-- FAMILY_ID | varchar(255) | 24
-- SKU | varchar(255) | 25
-- EAN | varchar(255) | 26
-- ORDER_CHANNEL_CODE | varchar(255) | 27
-- PROGRAM_TYPE | varchar(255) | 28
-- STORE_ID | varchar(255) | 29
-- STORE_NAME | varchar(255) | 30
-- CART_TYPE | varchar(255) | 31
-- CANCELLED_BY_AGENT | varchar(255) | 32
-- CANCELLATION_ID | varchar(255) | 33
-- CART_ID | varchar(255) | 34
-- TAXONOMY_PRODUCT_DIVISION | varchar(255) | 35
-- FILE_NAME_FROM_FILE | varchar(255) | 36
-- LOAD_DATE | timestamp | 37
-- FILE_NAME | varchar(2000) | 38
-- FILE_LAST_MODIFIED_TIME | varchar(255) | 39
-- FILE_NAME_SHORT | varchar(255) | 40
-- INSERTED_DATE | timestamp | 41
-- FILE_GENERATED_AT | timestamp | 42
-- UPDATED_DATETIME | timestamp | 43

SELECT table_schema, table_name FROM v_catalog.tables WHERE table_name ILIKE '%HYBRIS_CANCELLATIONS%';
-- table_schema | table_name
-- -------------+-----------
-- OW_LAO | ODS_HYBRIS_CANCELLATIONS
-- OW_LAO | RAW_HYBRIS_CANCELLATIONS

CREATE OR REPLACE PROCEDURE OW_LAO.PROC_ODS_HYBRIS_CANCELLATIONS()
LANGUAGE PLvSQL AS $$
BEGIN
    
    PERFORM DROP TABLE IF EXISTS TMP_HYBRIS_CANCELLATIONS_DEDUP;
    
    PERFORM CREATE LOCAL TEMP TABLE TMP_HYBRIS_CANCELLATIONS_DEDUP ON COMMIT PRESERVE ROWS AS
        SELECT 
              ROW_NUMBER() OVER (
                  PARTITION BY country_cd, cart_id, line_item_id
                  ORDER BY file_generated_at DESC
              ) AS dedup
            , *
        FROM OW_LAO.RAW_HYBRIS_CANCELLATIONS a
        WHERE NOT EXISTS (
            SELECT 1
            FROM OW_LAO.ODS_HYBRIS_CANCELLATIONS aa
            WHERE aa.Country_Cd = a.Country_Cd
              AND aa.Cart_id = a.Cart_id
              AND aa.line_item_id = a.line_item_id
              AND aa.file_generated_at >= a.file_generated_at
        );
    
    PERFORM DELETE FROM TMP_HYBRIS_CANCELLATIONS_DEDUP WHERE dedup <> 1;

    PERFORM MERGE INTO OW_LAO.ODS_HYBRIS_CANCELLATIONS a
    USING TMP_HYBRIS_CANCELLATIONS_DEDUP b
      ON b.Country_Cd = a.Country_Cd
     AND b.Cart_id = a.Cart_id
     AND b.line_item_id = a.line_item_id
    WHEN MATCHED THEN UPDATE SET
          "CANCELLATION_DATE" = b."CANCELLATION_DATE"
        , "ORDER_DATE_LOCAL" = b."ORDER_DATE_LOCAL"
        , "PO_ID" = b."PO_ID"
        , "CANCELLATION_STATUS" = b."CANCELLATION_STATUS"
        , "CANCELLATION_REASON_CODE" = b."CANCELLATION_REASON_CODE"
        , "CANCELLATION_TYPE" = b."CANCELLATION_TYPE"
        , "CANCELLATION_REASON" = b."CANCELLATION_REASON"
        , "QUANTITY" = b."QUANTITY"
        , "SUBTOTAL_AMOUNT" = b."SUBTOTAL_AMOUNT"
        , "TAXES" = b."TAXES"
        , "SALES_PRICE_LOCAL" = b."SALES_PRICE_LOCAL"
        , "UNIT_SALES_PRICE" = b."UNIT_SALES_PRICE"
        , "LINE_ITEM_QUANTITY" = b."LINE_ITEM_QUANTITY"
        , "TAXONOMY_NAME" = b."TAXONOMY_NAME"
        , "TAXONOMY_PRODUCT_CATEGORY" = b."TAXONOMY_PRODUCT_CATEGORY"
        , "TAXONOMY_PRODUCT_FAMILY" = b."TAXONOMY_PRODUCT_FAMILY"
        , "PRODUCT_NAME" = b."PRODUCT_NAME"
        , "PRODUCT_TYPE" = b."PRODUCT_TYPE"
        , "PRODUCT_MODEL_CODE" = b."PRODUCT_MODEL_CODE"
        , "PRODUCT_MODEL_NAME" = b."PRODUCT_MODEL_NAME"
        , "FAMILY_ID" = b."FAMILY_ID"
        , "SKU" = b."SKU"
        , "EAN" = b."EAN"
        , "ORDER_CHANNEL_CODE" = b."ORDER_CHANNEL_CODE"
        , "PROGRAM_TYPE" = b."PROGRAM_TYPE"
        , "STORE_ID" = b."STORE_ID"
        , "STORE_NAME" = b."STORE_NAME"
        , "CART_TYPE" = b."CART_TYPE"
        , "CANCELLED_BY_AGENT" = b."CANCELLED_BY_AGENT"
        , "CANCELLATION_ID" = b."CANCELLATION_ID"
        , "TAXONOMY_PRODUCT_DIVISION" = b."TAXONOMY_PRODUCT_DIVISION"
        , "FILE_NAME_FROM_FILE" = b."FILE_NAME_FROM_FILE"
        , "LOAD_DATE" = b."LOAD_DATE"
        , "FILE_NAME" = b."FILE_NAME"
        , "FILE_LAST_MODIFIED_TIME" = b."FILE_LAST_MODIFIED_TIME"
        , "FILE_NAME_SHORT" = b."FILE_NAME_SHORT"
        , "FILE_GENERATED_AT" = b."FILE_GENERATED_AT"
        , "UPDATED_DATETIME" = CURRENT_TIMESTAMP
    WHEN NOT MATCHED THEN INSERT (
          "LINE_ITEM_ID"
        , "COUNTRY_CD"
        , "CANCELLATION_DATE"
        , "ORDER_DATE_LOCAL"
        , "PO_ID"
        , "CANCELLATION_STATUS"
        , "CANCELLATION_REASON_CODE"
        , "CANCELLATION_TYPE"
        , "CANCELLATION_REASON"
        , "QUANTITY"
        , "SUBTOTAL_AMOUNT"
        , "TAXES"
        , "SALES_PRICE_LOCAL"
        , "UNIT_SALES_PRICE"
        , "LINE_ITEM_QUANTITY"
        , "TAXONOMY_NAME"
        , "TAXONOMY_PRODUCT_CATEGORY"
        , "TAXONOMY_PRODUCT_FAMILY"
        , "PRODUCT_NAME"
        , "PRODUCT_TYPE"
        , "PRODUCT_MODEL_CODE"
        , "PRODUCT_MODEL_NAME"
        , "FAMILY_ID"
        , "SKU"
        , "EAN"
        , "ORDER_CHANNEL_CODE"
        , "PROGRAM_TYPE"
        , "STORE_ID"
        , "STORE_NAME"
        , "CART_TYPE"
        , "CANCELLED_BY_AGENT"
        , "CANCELLATION_ID"
        , "CART_ID"
        , "TAXONOMY_PRODUCT_DIVISION"
        , "FILE_NAME_FROM_FILE"
        , "LOAD_DATE"
        , "FILE_NAME"
        , "FILE_LAST_MODIFIED_TIME"
        , "FILE_NAME_SHORT"
        , "CREATED_DATETIME"
        , "FILE_GENERATED_AT"
        , "UPDATED_DATETIME"
    ) VALUES (
          b."LINE_ITEM_ID"
        , b."COUNTRY_CD"
        , b."CANCELLATION_DATE"
        , b."ORDER_DATE_LOCAL"
        , b."PO_ID"
        , b."CANCELLATION_STATUS"
        , b."CANCELLATION_REASON_CODE"
        , b."CANCELLATION_TYPE"
        , b."CANCELLATION_REASON"
        , b."QUANTITY"
        , b."SUBTOTAL_AMOUNT"
        , b."TAXES"
        , b."SALES_PRICE_LOCAL"
        , b."UNIT_SALES_PRICE"
        , b."LINE_ITEM_QUANTITY"
        , b."TAXONOMY_NAME"
        , b."TAXONOMY_PRODUCT_CATEGORY"
        , b."TAXONOMY_PRODUCT_FAMILY"
        , b."PRODUCT_NAME"
        , b."PRODUCT_TYPE"
        , b."PRODUCT_MODEL_CODE"
        , b."PRODUCT_MODEL_NAME"
        , b."FAMILY_ID"
        , b."SKU"
        , b."EAN"
        , b."ORDER_CHANNEL_CODE"
        , b."PROGRAM_TYPE"
        , b."STORE_ID"
        , b."STORE_NAME"
        , b."CART_TYPE"
        , b."CANCELLED_BY_AGENT"
        , b."CANCELLATION_ID"
        , b."CART_ID"
        , b."TAXONOMY_PRODUCT_DIVISION"
        , b."FILE_NAME_FROM_FILE"
        , b."LOAD_DATE"
        , b."FILE_NAME"
        , b."FILE_LAST_MODIFIED_TIME"
        , b."FILE_NAME_SHORT"
        , NULL
        , b."FILE_GENERATED_AT"
        , NULL
    );

END;
$$;

-- CALL OW_LAO.PROC_ODS_HYBRIS_CANCELLATIONS();
-- ERROR: Severity: ERROR, Message: Column "CREATED_DATETIME" does not exist, Sqlstate: 42703, Where: PL/vSQL procedure PROC_ODS_HYBRIS_CANCELLATIONS line 25 at static SQL, Routine: attnameAttNum, File: parse_relation.c, Line: 2773, Error Code: 2624, 
-- CALL OW_LAO.PROC_ODS_HYBRIS_CANCELLATIONS();
-- ERROR: Severity: ERROR, Message: Column "CREATED_DATETIME" does not exist, Sqlstate: 42703, Where: PL/vSQL procedure PROC_ODS_HYBRIS_CANCELLATIONS line 25 at static SQL, Routine: attnameAttNum, File: parse_relation.c, Line: 2773, Error Code: 2624, 
SELECT * FROM OW_LAO.ODS_HYBRIS_CANCELLATIONS LIMIT 0;
-- ID | LINE_ITEM_ID | COUNTRY_CD | CANCELLATION_DATE | ORDER_DATE_LOCAL | PO_ID | CANCELLATION_STATUS | CANCELLATION_REASON_CODE | CANCELLATION_TYPE | CANCELLATION_REASON | QUANTITY | SUBTOTAL_AMOUNT | TAXES | SALES_PRICE_LOCAL | UNIT_SALES_PRICE | LINE_ITEM_QUANTITY | TAXONOMY_NAME | TAXONOMY_PRODUCT_CATEGORY | TAXONOMY_PRODUCT_FAMILY | PRODUCT_NAME | PRODUCT_TYPE | PRODUCT_MODEL_CODE | PRODUCT_MODEL_NAME | FAMILY_ID | SKU | EAN | ORDER_CHANNEL_CODE | PROGRAM_TYPE | STORE_ID | STORE_NAME | CART_TYPE | CANCELLED_BY_AGENT | CANCELLATION_ID | CART_ID | TAXONOMY_PRODUCT_DIVISION | FILE_NAME_FROM_FILE | LOAD_DATE | FILE_NAME | FILE_LAST_MODIFIED_TIME | FILE_NAME_SHORT | INSERTED_DATE | FILE_GENERATED_AT | UPDATED_DATETIME
-- ---+--------------+------------+-------------------+------------------+-------+---------------------+--------------------------+-------------------+---------------------+----------+-----------------+-------+-------------------+------------------+--------------------+---------------+---------------------------+-------------------------+--------------+--------------+--------------------+--------------------+-----------+-----+-----+--------------------+--------------+----------+------------+-----------+--------------------+-----------------+---------+---------------------------+---------------------+-----------+-----------+-------------------------+-----------------+---------------+-------------------+-----------------

-- SELECT column_name, data_type, is_nullable, default_expression, ordinal_position
-- FROM v_catalog.columns
-- WHERE table_schema = 'OW_LAO' AND table_name = 'ODS_HYBRIS_CANCELLATIONS'
-- ORDER BY ordinal_position;
-- ERROR: Severity: ERROR, Message: Column "default_expression" does not exist, Sqlstate: 42703, Routine: transformSQLColumnRef, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Optimizer/OptUtil/ExprUtil.cpp, Line: 7401, Error Code: 2624, 
SELECT column_name, data_type, is_nullable, ordinal_position
FROM v_catalog.columns
WHERE table_schema = 'OW_LAO' AND table_name = 'ODS_HYBRIS_CANCELLATIONS'
ORDER BY ordinal_position;
-- column_name | data_type | is_nullable | ordinal_position
-- ------------+-----------+-------------+-----------------
-- ID | int | True | 1
-- LINE_ITEM_ID | varchar(255) | False | 2
-- COUNTRY_CD | varchar(255) | False | 3
-- CANCELLATION_DATE | varchar(255) | True | 4
-- ORDER_DATE_LOCAL | varchar(255) | True | 5
-- PO_ID | varchar(255) | True | 6
-- CANCELLATION_STATUS | varchar(255) | True | 7
-- CANCELLATION_REASON_CODE | varchar(255) | True | 8
-- CANCELLATION_TYPE | varchar(255) | True | 9
-- CANCELLATION_REASON | varchar(255) | True | 10
-- QUANTITY | int | True | 11
-- SUBTOTAL_AMOUNT | numeric(34,0) | True | 12
-- TAXES | numeric(34,0) | True | 13
-- SALES_PRICE_LOCAL | numeric(34,0) | True | 14
-- UNIT_SALES_PRICE | numeric(34,0) | True | 15
-- LINE_ITEM_QUANTITY | int | True | 16
-- TAXONOMY_NAME | varchar(255) | True | 17
-- TAXONOMY_PRODUCT_CATEGORY | varchar(255) | True | 18
-- TAXONOMY_PRODUCT_FAMILY | varchar(255) | True | 19
-- PRODUCT_NAME | varchar(255) | True | 20
-- PRODUCT_TYPE | varchar(255) | True | 21
-- PRODUCT_MODEL_CODE | varchar(255) | True | 22
-- PRODUCT_MODEL_NAME | varchar(255) | True | 23
-- FAMILY_ID | varchar(255) | True | 24
-- SKU | varchar(255) | True | 25
-- EAN | varchar(255) | True | 26
-- ORDER_CHANNEL_CODE | varchar(255) | True | 27
-- PROGRAM_TYPE | varchar(255) | True | 28
-- STORE_ID | varchar(255) | True | 29
-- STORE_NAME | varchar(255) | True | 30
-- CART_TYPE | varchar(255) | True | 31
-- CANCELLED_BY_AGENT | varchar(255) | True | 32
-- CANCELLATION_ID | varchar(255) | True | 33
-- CART_ID | varchar(255) | False | 34
-- TAXONOMY_PRODUCT_DIVISION | varchar(255) | True | 35
-- FILE_NAME_FROM_FILE | varchar(255) | True | 36
-- LOAD_DATE | timestamp | True | 37
-- FILE_NAME | varchar(2000) | True | 38
-- FILE_LAST_MODIFIED_TIME | varchar(255) | True | 39
-- FILE_NAME_SHORT | varchar(255) | True | 40
-- INSERTED_DATE | timestamp | True | 41
-- FILE_GENERATED_AT | timestamp | True | 42
-- UPDATED_DATETIME | timestamp | True | 43

CREATE OR REPLACE PROCEDURE OW_LAO.PROC_ODS_HYBRIS_CANCELLATIONS()
LANGUAGE PLvSQL AS $$
BEGIN
    
    PERFORM DROP TABLE IF EXISTS TMP_HYBRIS_CANCELLATIONS_DEDUP;

    PERFORM CREATE LOCAL TEMP TABLE TMP_HYBRIS_CANCELLATIONS_DEDUP ON COMMIT PRESERVE ROWS AS
        SELECT 
              ROW_NUMBER() OVER (
                  PARTITION BY country_cd, cart_id, line_item_id
                  ORDER BY file_generated_at DESC
              ) AS dedup
            , *
        FROM OW_LAO.RAW_HYBRIS_CANCELLATIONS a
        WHERE NOT EXISTS (
            SELECT 1
            FROM OW_LAO.ODS_HYBRIS_CANCELLATIONS aa
            WHERE aa.Country_Cd = a.Country_Cd
              AND aa.Cart_id = a.Cart_id
              AND aa.line_item_id = a.line_item_id
              AND aa.file_generated_at >= a.file_generated_at
        );

    PERFORM DELETE FROM TMP_HYBRIS_CANCELLATIONS_DEDUP WHERE dedup <> 1;

    PERFORM MERGE INTO OW_LAO.ODS_HYBRIS_CANCELLATIONS a
    USING TMP_HYBRIS_CANCELLATIONS_DEDUP b
      ON b.Country_Cd = a.Country_Cd
     AND b.Cart_id = a.Cart_id
     AND b.line_item_id = a.line_item_id
    WHEN MATCHED THEN UPDATE SET
          "CANCELLATION_DATE" = b."CANCELLATION_DATE"
        , "ORDER_DATE_LOCAL" = b."ORDER_DATE_LOCAL"
        , "PO_ID" = b."PO_ID"
        , "CANCELLATION_STATUS" = b."CANCELLATION_STATUS"
        , "CANCELLATION_REASON_CODE" = b."CANCELLATION_REASON_CODE"
        , "CANCELLATION_TYPE" = b."CANCELLATION_TYPE"
        , "CANCELLATION_REASON" = b."CANCELLATION_REASON"
        , "QUANTITY" = b."QUANTITY"
        , "SUBTOTAL_AMOUNT" = b."SUBTOTAL_AMOUNT"
        , "TAXES" = b."TAXES"
        , "SALES_PRICE_LOCAL" = b."SALES_PRICE_LOCAL"
        , "UNIT_SALES_PRICE" = b."UNIT_SALES_PRICE"
        , "LINE_ITEM_QUANTITY" = b."LINE_ITEM_QUANTITY"
        , "TAXONOMY_NAME" = b."TAXONOMY_NAME"
        , "TAXONOMY_PRODUCT_CATEGORY" = b."TAXONOMY_PRODUCT_CATEGORY"
        , "TAXONOMY_PRODUCT_FAMILY" = b."TAXONOMY_PRODUCT_FAMILY"
        , "PRODUCT_NAME" = b."PRODUCT_NAME"
        , "PRODUCT_TYPE" = b."PRODUCT_TYPE"
        , "PRODUCT_MODEL_CODE" = b."PRODUCT_MODEL_CODE"
        , "PRODUCT_MODEL_NAME" = b."PRODUCT_MODEL_NAME"
        , "FAMILY_ID" = b."FAMILY_ID"
        , "SKU" = b."SKU"
        , "EAN" = b."EAN"
        , "ORDER_CHANNEL_CODE" = b."ORDER_CHANNEL_CODE"
        , "PROGRAM_TYPE" = b."PROGRAM_TYPE"
        , "STORE_ID" = b."STORE_ID"
        , "STORE_NAME" = b."STORE_NAME"
        , "CART_TYPE" = b."CART_TYPE"
        , "CANCELLED_BY_AGENT" = b."CANCELLED_BY_AGENT"
        , "CANCELLATION_ID" = b."CANCELLATION_ID"
        , "TAXONOMY_PRODUCT_DIVISION" = b."TAXONOMY_PRODUCT_DIVISION"
        , "FILE_NAME_FROM_FILE" = b."FILE_NAME_FROM_FILE"
        , "LOAD_DATE" = b."LOAD_DATE"
        , "FILE_NAME" = b."FILE_NAME"
        , "FILE_LAST_MODIFIED_TIME" = b."FILE_LAST_MODIFIED_TIME"
        , "FILE_NAME_SHORT" = b."FILE_NAME_SHORT"
        , "FILE_GENERATED_AT" = b."FILE_GENERATED_AT"
        , "UPDATED_DATETIME" = CURRENT_TIMESTAMP
    WHEN NOT MATCHED THEN INSERT (
          "LINE_ITEM_ID"
        , "COUNTRY_CD"
        , "CANCELLATION_DATE"
        , "ORDER_DATE_LOCAL"
        , "PO_ID"
        , "CANCELLATION_STATUS"
        , "CANCELLATION_REASON_CODE"
        , "CANCELLATION_TYPE"
        , "CANCELLATION_REASON"
        , "QUANTITY"
        , "SUBTOTAL_AMOUNT"
        , "TAXES"
        , "SALES_PRICE_LOCAL"
        , "UNIT_SALES_PRICE"
        , "LINE_ITEM_QUANTITY"
        , "TAXONOMY_NAME"
        , "TAXONOMY_PRODUCT_CATEGORY"
        , "TAXONOMY_PRODUCT_FAMILY"
        , "PRODUCT_NAME"
        , "PRODUCT_TYPE"
        , "PRODUCT_MODEL_CODE"
        , "PRODUCT_MODEL_NAME"
        , "FAMILY_ID"
        , "SKU"
        , "EAN"
        , "ORDER_CHANNEL_CODE"
        , "PROGRAM_TYPE"
        , "STORE_ID"
        , "STORE_NAME"
        , "CART_TYPE"
        , "CANCELLED_BY_AGENT"
        , "CANCELLATION_ID"
        , "CART_ID"
        , "TAXONOMY_PRODUCT_DIVISION"
        , "FILE_NAME_FROM_FILE"
        , "LOAD_DATE"
        , "FILE_NAME"
        , "FILE_LAST_MODIFIED_TIME"
        , "FILE_NAME_SHORT"
        , "INSERTED_DATE"
        , "FILE_GENERATED_AT"
        , "UPDATED_DATETIME"
    ) VALUES (
          b."LINE_ITEM_ID"
        , b."COUNTRY_CD"
        , b."CANCELLATION_DATE"
        , b."ORDER_DATE_LOCAL"
        , b."PO_ID"
        , b."CANCELLATION_STATUS"
        , b."CANCELLATION_REASON_CODE"
        , b."CANCELLATION_TYPE"
        , b."CANCELLATION_REASON"
        , b."QUANTITY"
        , b."SUBTOTAL_AMOUNT"
        , b."TAXES"
        , b."SALES_PRICE_LOCAL"
        , b."UNIT_SALES_PRICE"
        , b."LINE_ITEM_QUANTITY"
        , b."TAXONOMY_NAME"
        , b."TAXONOMY_PRODUCT_CATEGORY"
        , b."TAXONOMY_PRODUCT_FAMILY"
        , b."PRODUCT_NAME"
        , b."PRODUCT_TYPE"
        , b."PRODUCT_MODEL_CODE"
        , b."PRODUCT_MODEL_NAME"
        , b."FAMILY_ID"
        , b."SKU"
        , b."EAN"
        , b."ORDER_CHANNEL_CODE"
        , b."PROGRAM_TYPE"
        , b."STORE_ID"
        , b."STORE_NAME"
        , b."CART_TYPE"
        , b."CANCELLED_BY_AGENT"
        , b."CANCELLATION_ID"
        , b."CART_ID"
        , b."TAXONOMY_PRODUCT_DIVISION"
        , b."FILE_NAME_FROM_FILE"
        , b."LOAD_DATE"
        , b."FILE_NAME"
        , b."FILE_LAST_MODIFIED_TIME"
        , b."FILE_NAME_SHORT"
        , NULL
        , b."FILE_GENERATED_AT"
        , NULL
    );

END;
$$;

CALL OW_LAO.PROC_ODS_HYBRIS_CANCELLATIONS();
-- PROC_ODS_HYBRIS_CANCELLATIONS
-- -----------------------------
-- 0

