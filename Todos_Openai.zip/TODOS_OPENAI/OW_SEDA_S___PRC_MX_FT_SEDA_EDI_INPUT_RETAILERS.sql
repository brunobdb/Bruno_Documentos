-- CREATE OR REPLACE PROCEDURE OW_SEDA_S.PRC_MX_FT_SEDA_EDI_INPUT_RETAILERS(WEEKNUM_REF INT)
-- LANGUAGE PLvSQL AS $$
-- DECLARE 
--   v_sql VARCHAR(65000);
--   rec RECORD;
-- BEGIN
--   FOR rec IN 
--     SELECT DISTINCT account 
--     FROM OW_SEDA_S.EDI_DATA_RAW 
--     WHERE WEEK = WEEKNUM_REF
--   LOOP
--     v_sql := 'CALL OW_SEDA_S.PRC_MX_FT_SEDA_EDI_INPUT(' || CAST(WEEKNUM_REF AS VARCHAR(20)) || ', ''' || REPLACE(rec.account, '''', '''''') || ''')';
--     PERFORM EXECUTE IMMEDIATE v_sql;
--   END LOOP;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 7.5-10 of source string: syntax error, unexpected SELECT, expecting EXECUTE or CURSOR or QUERY or RANGE, Sqlstate: 42601, Position: 184, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
-- CREATE OR REPLACE PROCEDURE OW_SEDA_S.PRC_MX_FT_SEDA_EDI_INPUT_RETAILERS(WEEKNUM_REF INT)
-- LANGUAGE PLvSQL AS $$
-- DECLARE 
--   v_sql VARCHAR(65000);
--   rec RECORD;
-- BEGIN
--   FOR rec IN QUERY 
--     SELECT DISTINCT account 
--     FROM OW_SEDA_S.EDI_DATA_RAW 
--     WHERE WEEK = WEEKNUM_REF
--   LOOP
--     v_sql := 'CALL OW_SEDA_S.PRC_MX_FT_SEDA_EDI_INPUT(' || CAST(WEEKNUM_REF AS VARCHAR(20)) || ', ''' || REPLACE(rec.account, '''', '''''') || ''')';
--     PERFORM EXECUTE IMMEDIATE v_sql;
--   END LOOP;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: The RECORD type is not yet supported, Sqlstate: 0A000, Position: 152, Routine: validateAssignableType, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Validator.cpp, Line: 354, Error Code: 10335, 
CREATE OR REPLACE PROCEDURE OW_SEDA_S.PRC_MX_FT_SEDA_EDI_INPUT_RETAILERS(WEEKNUM_REF INT)
LANGUAGE PLvSQL AS $$
DECLARE 
  v_account VARCHAR(512);
BEGIN
  FOR v_account IN QUERY 
    SELECT DISTINCT account 
    FROM OW_SEDA_S.EDI_DATA_RAW 
    WHERE WEEK = WEEKNUM_REF
  LOOP
    PERFORM CALL OW_SEDA_S.PRC_MX_FT_SEDA_EDI_INPUT(WEEKNUM_REF, v_account);
  END LOOP;
END;
$$;

CALL OW_SEDA_S.PRC_MX_FT_SEDA_EDI_INPUT_RETAILERS(202401);
-- PRC_MX_FT_SEDA_EDI_INPUT_RETAILERS
-- ----------------------------------
-- 0

