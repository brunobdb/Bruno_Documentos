-- CREATE OR REPLACE PROCEDURE ow_lao.proc_monitoring_bi_lao_proccess_vtex_seda_global_bi()
-- LANGUAGE PLvSQL AS $$
-- DECLARE
--     timestamp_filter TIMESTAMP := NULL;
--     proccess VARCHAR(255) := 'GlobalBI';
-- BEGIN
--     SELECT TIMESTAMPADD(SECOND, -3600, CURRENT_TIMESTAMP) INTO timestamp_filter;
-- 
--     SELECT 'u_prj_ecom.ods_feed_vtex_ssg_br_shop_sales_order'  AS dataSource
--          , proccess                                            AS proccess
--          , a.order_id                                          AS referencia
--          , COUNT(1)                                            AS quantity
--       FROM u_prj_ecom.raw_vtex_ssg_br_shop_sales_order a
--      WHERE a.creation_timestamp >= TIMESTAMPADD(DAY, -30, CURRENT_DATE)
--        AND a.creation_timestamp >= TIMESTAMP '2024-07-15 00:00:00'
--        AND a.created_at         <= timestamp_filter
--        AND NOT EXISTS(                        
--                 SELECT 1
--                   FROM u_prj_ecom_synapcom.ft_ecom_order bb
--                  WHERE bb.external_order_id = a.order_id
--            )
--        AND NOT EXISTS(
--                 SELECT 1
--                   FROM ow_lao.monitoring_bi_lao_proccess cc
--                  WHERE cc.processo_nome = proccess
--                    AND cc.origem_nome   = 'u_prj_ecom.ods_feed_vtex_ssg_br_shop_sales_order'
--                    AND cc.referencia    = a.order_id
--                    AND cc.status_nome   = 'Em analise'
--            )
--   GROUP BY a.order_id
--   
--      UNION ALL
-- 
--     SELECT 'u_prj_ecom.raw_vtex_ssg_br_epp2_sales_order'  AS dataSource
--          , proccess                                       AS proccess
--          , a.seller_order_id                              AS referencia
--          , COUNT(1)                                       AS quantity
--       FROM u_prj_ecom.raw_vtex_ssg_br_epp2_sales_order a
--      WHERE a.creation_timestamp >= TIMESTAMPADD(DAY, -30, CURRENT_DATE)
--        AND a.creation_timestamp >= TIMESTAMP '2024-07-15 00:00:00'
--        AND a.created_at         <= timestamp_filter
--        AND NOT EXISTS(                        
--                 SELECT 1
--                   FROM u_prj_ecom_synapcom.ft_ecom_order bb
--                  WHERE bb.external_order_id = a.seller_order_id
--            )
--        AND NOT EXISTS(
--                 SELECT 1
--                   FROM ow_lao.monitoring_bi_lao_proccess cc
--                  WHERE cc.processo_nome = proccess
--                    AND cc.origem_nome   = 'u_prj_ecom.raw_vtex_ssg_br_epp2_sales_order'
--                    AND cc.referencia    = a.seller_order_id
--                    AND cc.status_nome   = 'Em analise'
--            )    
--   GROUP BY a.seller_order_id;    
--   
-- END
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 54.29 of source string: syntax error, unexpected ;, expecting INTO, Sqlstate: 42601, Position: 2605, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
CREATE OR REPLACE PROCEDURE ow_lao.proc_monitoring_bi_lao_proccess_vtex_seda_global_bi()
LANGUAGE PLvSQL AS $$
DECLARE
    timestamp_filter TIMESTAMP := NULL;
    proccess VARCHAR(255) := 'GlobalBI';
BEGIN
    SELECT TIMESTAMPADD(SECOND, -3600, CURRENT_TIMESTAMP) INTO timestamp_filter;

    PERFORM DROP TABLE IF EXISTS tmp_proc_monitoring_bi_result;

    PERFORM CREATE LOCAL TEMPORARY TABLE tmp_proc_monitoring_bi_result ON COMMIT PRESERVE ROWS AS
    SELECT 'u_prj_ecom.ods_feed_vtex_ssg_br_shop_sales_order'  AS dataSource
         , proccess                                            AS proccess
         , a.order_id                                          AS referencia
         , COUNT(1)                                            AS quantity
      FROM u_prj_ecom.raw_vtex_ssg_br_shop_sales_order a
     WHERE a.creation_timestamp >= TIMESTAMPADD(DAY, -30, CURRENT_DATE)
       AND a.creation_timestamp >= DATE '2024-07-15'
       AND a.created_at         <= timestamp_filter
       AND NOT EXISTS(                        
                SELECT 1
                  FROM u_prj_ecom_synapcom.ft_ecom_order bb
                 WHERE bb.external_order_id = a.order_id
           )
       AND NOT EXISTS(
                SELECT 1
                  FROM ow_lao.monitoring_bi_lao_proccess cc
                 WHERE cc.processo_nome = proccess
                   AND cc.origem_nome   = 'u_prj_ecom.ods_feed_vtex_ssg_br_shop_sales_order'
                   AND cc.referencia    = a.order_id
                   AND cc.status_nome   = 'Em analise'
           )
  GROUP BY a.order_id
  
     UNION ALL

    SELECT 'u_prj_ecom.raw_vtex_ssg_br_epp2_sales_order'  AS dataSource
         , proccess                                       AS proccess
         , a.seller_order_id                              AS referencia
         , COUNT(1)                                       AS quantity
      FROM u_prj_ecom.raw_vtex_ssg_br_epp2_sales_order a
     WHERE a.creation_timestamp >= TIMESTAMPADD(DAY, -30, CURRENT_DATE)
       AND a.creation_timestamp >= DATE '2024-07-15'
       AND a.created_at         <= timestamp_filter
       AND NOT EXISTS(                        
                SELECT 1
                  FROM u_prj_ecom_synapcom.ft_ecom_order bb
                 WHERE bb.external_order_id = a.seller_order_id
           )
       AND NOT EXISTS(
                SELECT 1
                  FROM ow_lao.monitoring_bi_lao_proccess cc
                 WHERE cc.processo_nome = proccess
                   AND cc.origem_nome   = 'u_prj_ecom.raw_vtex_ssg_br_epp2_sales_order'
                   AND cc.referencia    = a.seller_order_id
                   AND cc.status_nome   = 'Em analise'
           )    
  GROUP BY a.seller_order_id;
  
END
$$;

-- CALL ow_lao.proc_monitoring_bi_lao_proccess_vtex_seda_global_bi();
-- ERROR: Severity: ERROR, Message: Relation "u_prj_ecom_synapcom.ft_ecom_order" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_monitoring_bi_lao_proccess_vtex_seda_global_bi line 10 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
-- CALL ow_lao.proc_monitoring_bi_lao_proccess_vtex_seda_global_bi();
-- ERROR: Severity: ERROR, Message: Relation "u_prj_ecom_synapcom.ft_ecom_order" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_monitoring_bi_lao_proccess_vtex_seda_global_bi line 10 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
