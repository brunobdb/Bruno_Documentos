CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_control_tower_table_items_exclusives_update()
 LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM UPDATE ow_lao.ods_sales_control_tower_table a
       SET ITEM_EXCLUSIVE = 1
      FROM OW_LAO.ODS_LAO_PRODUCT_EXCLUSIVES_ITEMS b
     WHERE b.ITEM_EXCLUSIVES  = a.po_sku
       AND b.SUBSIDIARY = a.SUBSIDIARY
       AND a.ITEM_EXCLUSIVE = 0
       AND a.PO_DATE BETWEEN b.DATE_START AND b.DATE_END
       AND b.ACTIVE = TRUE;
END;
$$;

-- CALL OW_LAO.proc_ods_control_tower_table_items_exclusives_update();
-- ERROR: Severity: ERROR, Message: Column "b.ACTIVE" does not exist, Sqlstate: 42703, Where: PL/vSQL procedure proc_ods_control_tower_table_items_exclusives_update line 3 at static SQL, Routine: undefinedSchemaObjectErrorMsg, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Optimizer/OptUtil/ExprUtil.cpp, Line: 7179, Error Code: 2624, 
-- CALL OW_LAO.proc_ods_control_tower_table_items_exclusives_update();
-- ERROR: Severity: ERROR, Message: Column "b.ACTIVE" does not exist, Sqlstate: 42703, Where: PL/vSQL procedure proc_ods_control_tower_table_items_exclusives_update line 3 at static SQL, Routine: undefinedSchemaObjectErrorMsg, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Optimizer/OptUtil/ExprUtil.cpp, Line: 7179, Error Code: 2624, 
SELECT column_name, data_type FROM v_catalog.columns WHERE table_schema='OW_LAO' AND table_name='ODS_LAO_PRODUCT_EXCLUSIVES_ITEMS' ORDER BY ordinal_position;
-- column_name | data_type
-- ------------+----------
-- INSERTED_TIMESTAMP | timestamp
-- UPDATED_TIMESTAMP | timestamp
-- ITEM_EXCLUSIVES | varchar(150)
-- SUBSIDIARY | varchar(20)
-- DATE_START | timestamp
-- DATE_END | timestamp
-- FILE_NAME | varchar(100)

CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_control_tower_table_items_exclusives_update()
 LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM UPDATE ow_lao.ods_sales_control_tower_table a
       SET ITEM_EXCLUSIVE = 1
      FROM OW_LAO.ODS_LAO_PRODUCT_EXCLUSIVES_ITEMS b
     WHERE b.ITEM_EXCLUSIVES  = a.po_sku
       AND b.SUBSIDIARY = a.SUBSIDIARY
       AND a.ITEM_EXCLUSIVE = 0
       AND a.PO_DATE BETWEEN b.DATE_START AND b.DATE_END
       AND b."ACTIVE" = TRUE;
END;
$$;

-- CALL OW_LAO.proc_ods_control_tower_table_items_exclusives_update();
-- ERROR: Severity: ERROR, Message: Column "b.ACTIVE" does not exist, Sqlstate: 42703, Where: PL/vSQL procedure proc_ods_control_tower_table_items_exclusives_update line 3 at static SQL, Routine: undefinedSchemaObjectErrorMsg, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Optimizer/OptUtil/ExprUtil.cpp, Line: 7179, Error Code: 2624, 
-- CALL OW_LAO.proc_ods_control_tower_table_items_exclusives_update();
-- ERROR: Severity: ERROR, Message: Column "b.ACTIVE" does not exist, Sqlstate: 42703, Where: PL/vSQL procedure proc_ods_control_tower_table_items_exclusives_update line 3 at static SQL, Routine: undefinedSchemaObjectErrorMsg, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Optimizer/OptUtil/ExprUtil.cpp, Line: 7179, Error Code: 2624, 
SELECT table_name, column_name, data_type FROM v_catalog.columns WHERE table_schema ILIKE 'OW_LAO' AND table_name ILIKE 'ODS_LAO_PRODUCT_EXCLUSIVES_ITEMS' ORDER BY table_name, ordinal_position;
-- table_name | column_name | data_type
-- -----------+-------------+----------
-- ODS_LAO_PRODUCT_EXCLUSIVES_ITEMS | INSERTED_TIMESTAMP | timestamp
-- ODS_LAO_PRODUCT_EXCLUSIVES_ITEMS | UPDATED_TIMESTAMP | timestamp
-- ODS_LAO_PRODUCT_EXCLUSIVES_ITEMS | ITEM_EXCLUSIVES | varchar(150)
-- ODS_LAO_PRODUCT_EXCLUSIVES_ITEMS | SUBSIDIARY | varchar(20)
-- ODS_LAO_PRODUCT_EXCLUSIVES_ITEMS | DATE_START | timestamp
-- ODS_LAO_PRODUCT_EXCLUSIVES_ITEMS | DATE_END | timestamp
-- ODS_LAO_PRODUCT_EXCLUSIVES_ITEMS | FILE_NAME | varchar(100)

SELECT * FROM OW_LAO.ODS_LAO_PRODUCT_EXCLUSIVES_ITEMS LIMIT 0;
-- INSERTED_TIMESTAMP | UPDATED_TIMESTAMP | ITEM_EXCLUSIVES | SUBSIDIARY | DATE_START | DATE_END | FILE_NAME
-- -------------------+-------------------+-----------------+------------+------------+----------+----------

SELECT column_name FROM v_catalog.columns WHERE table_schema='OW_LAO' AND table_name='ODS_SALES_CONTROL_TOWER_TABLE' ORDER BY ordinal_position;
-- column_name
-- -----------
-- PO_DATE
-- PODATE_YEAR
-- PODATE_MONTH
-- COUNTRY
-- SAMSUNG_CARE_ORDER
-- SAMSUNG_CARE
-- SAMSUNG_CARE_ELIGIBILITY
-- TRADE_IN
-- TRADE_IN_ELIGIBILITY
-- COSTUMER_CODE_ID_NAME
-- PO_ORDERID
-- SELLER_PO_ORDERID
-- PAYMENT_CARD_BRAND
-- PAYMENT_TYPE
-- INSTALLMENT
-- INSTALLMENT_ELIGIBILITY
-- PO_CANCELATION_REASON
-- PO_PRODUCTGROUP
-- PO_CODE_SALES_CHANNEL
-- PO_COSTUMER_ID
-- PO_SITECODE
-- PO_INTERNAL_STATUS
-- PO_INVOICENUMBER
-- PO_CAMPAIN_TAGS
-- PO_CAMPAIN
-- PO_COUPON
-- PO_MEDIUM
-- PO_SRC
-- PO_UTMI_CAMPAING
-- PO_SEQUENCE_ORDERID
-- PO_PRODNAME
-- PO_SKU
-- PO_SELLER_ID
-- PO_SELLER_NAME
-- PO_STATUS
-- CLIENT_SUBSIDIARY_ID
-- SUBSIDIARY
-- CURRENCY
-- PO_TRADEPOLICY
-- PO_VENDORTYPE
-- CHANNEL
-- BIZ_TYPE
-- AUDIENCE_TYPE
-- PO_STORENAME
-- CLIENT_ACQUIRER_MESSAGE
-- PO_LASTUPDATE_DATE_HOUR
-- PO_ORDERQTY
-- PO_QTY
-- PO_ITEMDISCOUNT_LOCALCURR
-- PO_ITEMDISCOUNT_USD
-- PO_PRICE_LOCALCURR
-- PO_PRICE_USD
-- PO_PLATAFORM_DATASOURCE
-- PO_SOURCE_INSERT_DATE
-- PO_SOURCE_LAST_UPDATE_DATE
-- PO_INSERT_DATE
-- PO_LAST_UPDATE_DATE
-- SO_IDCODE
-- SOLDTO_PARTY
-- SOLDTO_NAME
-- NERP_SKU
-- NERP_SKU_DESCRIPTION
-- NERP_SKU_DIVISION
-- NERP_NETPRICE
-- NERP_NETVALUE
-- NERP_COST
-- NERP_MARGINRATE
-- NERP_CURRENCY
-- SO_DATE_KST
-- NERP_COUNTRYCODE
-- NERP_DISTCHANNEL
-- NERP_PLANT
-- NERP_STORAGELOCATION
-- NERP_ACCOUNTCODE
-- NERP_ACCOUNTNAME
-- NERP_ID_GSCM
-- NERP_GC_NAME
-- NERP_AP1_CODE
-- NERP_AP1_NAME
-- NERP_AP2_CODE
-- NERP_AP2_NAME
-- NERP_DELIVERYCODE
-- NERP_DELIVERUQTY
-- NERP_BILLINGQTY
-- NERP_BILLINGDATE
-- NERP_MATERIAL_GROUP
-- SO_DATE
-- DO_DATE
-- 1GI_DATE
-- BILLING_DATE_LOCAL
-- FINAL_DATE
-- EBI_ORDERID
-- CLIENT_DEVICETYPE
-- WEEK
-- EBI_PO_DATE
-- EBI_PRODUCT_CATEGORY
-- EBI_PRODUCT_SUBCATEGORY
-- EBI_PRODUCT_FAMILY
-- EBI_PRODUCT_SERIES
-- EBI_PRODUCT_NAME
-- EBI_STATUS
-- EBI_PAYMENT_METHOD
-- EBI_PAYMENT_PROVIDER
-- EBI_TRADE_IN_ELIGIBLE
-- EBI_TRADE_IN_ORDER
-- EBI_EIP_ELIGIBLE
-- EBI_EIP_ORDER
-- EBI_EUP_ELIGIBLE
-- EBI_EUP_ORDER
-- EBI_SCPLUS_ELIGIBLE
-- EBI_SCPLUS_ORDER
-- EBI_TARIFF_ELIGIBLE
-- EBI_TARIFF_ORDER
-- EBI_GROSSREVENUE
-- EBI_NETREVENUE
-- EBI_GROSSORDER
-- EBI_NETORDER
-- EBI_NETQTY
-- EBI_GROSSQTY
-- EBI_CANCELAMT
-- EBI_CANCELQTY
-- EBI_RETURNEDAMT
-- EBI_RETURNED_QTY
-- DELIVERY_NO
-- CITY
-- REGION
-- DISTRICT
-- DATE_TORETRIVE
-- DATE_RETRIVED
-- VOLUME
-- WEIGHT
-- SHIPPING_TYPE
-- DATE_DELIVERED
-- STORAGE_LOCATION
-- FINAL_ETA_DATE
-- DELIVEY_DATE
-- SERIAL_NUMBER_CODE
-- DELIVERY_EXTIMETED_DATE
-- DELIVERY_CARRIER
-- POSTAL
-- INSETED_DATETIME
-- UPDATED_DATETIME
-- NERP_LAST_UPDATE_DATE
-- PO_PAYMENT_REMARK
-- NERP_OUTBOUND_LAST_UPDATE_DATE
-- EBI_LAST_UPDATE_DATE
-- PO_HOUR
-- PO_TOTALPRICE_LOCAL
-- PO_TOTALPRICE_USD
-- PO_TOTALPRICE
-- PO_TOTALTAX
-- COSTUMERTYPE
-- PO_ORDERSID
-- PO_PAYMENTPROVIDER
-- PO_PAYMENTDATE
-- PO_STORE_ID
-- PO_STORE_NAME
-- CLIENT_TRADE_IN_EXCHANGE_BRAND
-- TRADE_IN_DISCOUNT
-- CLIENT_TRADE_IN_EXCHANGE_MODEL
-- PO_DEVICETYPE
-- PO_ADDED_SERVICES
-- PO_EXTERNAL_SERVICE_TYPE
-- TRADE_IN_DISCOUNT_DETAILS
-- EBI_SKU
-- EBI_CHANNEL
-- EBI_BIZ_TYPE
-- PRODUCT
-- PRODUCT_FAMILY
-- PRODUCT_GROUP
-- DIVISION
-- NET_REVENUE
-- NET_REVENUE_LOCAL
-- ACCESS_CODE
-- PO_SOURCE_PAYMENT_LAST_UPDATE_DATE
-- PO_PAYMENT_GATEWAY
-- PARTNER_LEVEL
-- PO_SKU_KIT
-- PO_PRODNAME_KIT
-- IS_KIT
-- WARRANTY
-- WARRANTY_ELIGIBILITY
-- COUNTRY_CD
-- PRODUCT_CATEGORY
-- BIZ_TYPE_EBI_HQ
-- GLOBAL_CHANNEL_EBI_HQ
-- ITEM_EXCLUSIVE
-- PREMIUMPRODUCT
-- PARTNER_LEVEL_CODE
-- UNIQUE_ID
-- ID
-- CRP
-- SHIPPING_METHOD
-- PO_TIMESTAMP
-- SPI
-- DELIVERY_MODE
-- PO_MOBILE_OS
-- CUSTOMER_TYPE
-- INSTALLMENT_AMOUNT
-- EPROMOTER

CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_control_tower_table_items_exclusives_update()
 LANGUAGE PLvSQL AS $$
DECLARE
    has_active BOOLEAN;
BEGIN
    SELECT COUNT(*) > 0
      INTO has_active
      FROM v_catalog.columns
     WHERE table_schema = 'OW_LAO'
       AND table_name = 'ODS_LAO_PRODUCT_EXCLUSIVES_ITEMS'
       AND column_name = 'ACTIVE';

    IF has_active THEN
        PERFORM UPDATE ow_lao.ods_sales_control_tower_table a
               SET ITEM_EXCLUSIVE = 1
              FROM OW_LAO.ODS_LAO_PRODUCT_EXCLUSIVES_ITEMS b
             WHERE b.ITEM_EXCLUSIVES  = a.po_sku
               AND b.SUBSIDIARY = a.SUBSIDIARY
               AND a.ITEM_EXCLUSIVE = 0
               AND a.PO_DATE BETWEEN b.DATE_START AND b.DATE_END
               AND b.ACTIVE = TRUE;
    ELSE
        PERFORM UPDATE ow_lao.ods_sales_control_tower_table a
               SET ITEM_EXCLUSIVE = 1
              FROM OW_LAO.ODS_LAO_PRODUCT_EXCLUSIVES_ITEMS b
             WHERE b.ITEM_EXCLUSIVES  = a.po_sku
               AND b.SUBSIDIARY = a.SUBSIDIARY
               AND a.ITEM_EXCLUSIVE = 0
               AND a.PO_DATE BETWEEN b.DATE_START AND b.DATE_END;
    END IF;
END;
$$;

CALL OW_LAO.proc_ods_control_tower_table_items_exclusives_update();
-- proc_ods_control_tower_table_items_exclusives_update
-- ----------------------------------------------------
-- 0

