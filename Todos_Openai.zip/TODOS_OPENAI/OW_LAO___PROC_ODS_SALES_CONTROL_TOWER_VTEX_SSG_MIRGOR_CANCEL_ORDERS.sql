CREATE OR REPLACE PROCEDURE ow_lao.proc_ods_sales_control_tower_vtex_ssg_mirgor_cancel_orders()
LANGUAGE PLvSQL AS $$
BEGIN
    -- Create temp table structure if not exists, then truncate
    PERFORM CREATE LOCAL TEMPORARY TABLE IF NOT EXISTS stg_vtex_order_seasa_mirgor_cancel_filter ON COMMIT PRESERVE ROWS AS
    SELECT a.id, a.po_orderid, a.po_sku, a.po_status
      FROM ow_lao.ods_sales_control_tower_table a
      WHERE 1=0;

    PERFORM TRUNCATE TABLE stg_vtex_order_seasa_mirgor_cancel_filter;

    -- Initial load
    PERFORM INSERT INTO stg_vtex_order_seasa_mirgor_cancel_filter (id, po_orderid, po_sku, po_status)
    SELECT a.id
         , a.po_orderid
         , a.po_sku
         , a.po_status
      FROM ow_lao.ods_sales_control_tower_table          a
      JOIN u_prj_ecom.stg_vtex_order_seasa_mirgor_cancel b
        ON b.ref_id_cut = a.po_sku
       AND b.order_id   = CASE 
                              WHEN INSTR(a.po_orderid, '-') = 4 THEN SUBSTR(a.po_orderid, 5, LENGTH(a.po_orderid) - 7)
                              WHEN INSTR(a.po_orderid, '-') > 4 THEN SUBSTR(a.po_orderid, 1, LENGTH(a.po_orderid) - 3)
                              ELSE a.po_orderid
                          END
     WHERE a.po_status               <> 'Cancelled'
       AND LOWER(a.po_seller_id)     LIKE '%mirgor%'
       AND a.client_subsidiary_id    = 1
       AND a.po_plataform_datasource IN ('u_prj_ecom.raw_vtex_ssg_ar_sales_order', 'u_prj_ecom.ft_ecom_order');

    -- Additional rows based on order-only match and uniqueness criteria
    PERFORM INSERT INTO stg_vtex_order_seasa_mirgor_cancel_filter (id, po_orderid, po_sku, po_status)
    SELECT DISTINCT
           a.id
         , a.po_orderid
         , a.po_sku
         , a.po_status
      FROM ow_lao.ods_sales_control_tower_table          a
      JOIN u_prj_ecom.stg_vtex_order_seasa_mirgor_cancel b
        ON b.order_id   = CASE 
                              WHEN INSTR(a.po_orderid, '-') = 4 THEN SUBSTR(a.po_orderid, 5, LENGTH(a.po_orderid) - 7)
                              WHEN INSTR(a.po_orderid, '-') > 4 THEN SUBSTR(a.po_orderid, 1, LENGTH(a.po_orderid) - 3)
                              ELSE a.po_orderid
                          END
     WHERE a.po_status               <> 'Cancelled'
       AND LOWER(a.po_seller_id)     LIKE '%mirgor%'
       AND a.client_subsidiary_id    = 1
       AND a.po_plataform_datasource IN ('u_prj_ecom.raw_vtex_ssg_ar_sales_order', 'u_prj_ecom.ft_ecom_order')
       AND NOT EXISTS (
            SELECT 1
              FROM stg_vtex_order_seasa_mirgor_cancel_filter aa
             WHERE aa.po_orderid = a.po_orderid
       )
       AND EXISTS (
            SELECT po_orderid
              FROM ow_lao.ods_sales_control_tower_table bb
             WHERE bb.po_orderid = a.po_orderid
             GROUP BY po_orderid
            HAVING COUNT(1) = 1
       );

    -- Update matching rows to Cancelled
    PERFORM UPDATE ow_lao.ods_sales_control_tower_table a
       SET po_status = 'Cancelled'
         , updated_datetime = CURRENT_TIMESTAMP
      FROM stg_vtex_order_seasa_mirgor_cancel_filter b
     WHERE b.id = a.id;

END;
$$;

-- CALL ow_lao.proc_ods_sales_control_tower_vtex_ssg_mirgor_cancel_orders();
-- ERROR: Severity: ERROR, Message: Relation "u_prj_ecom.stg_vtex_order_seasa_mirgor_cancel" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ods_sales_control_tower_vtex_ssg_mirgor_cancel_orders line 12 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
-- CALL ow_lao.proc_ods_sales_control_tower_vtex_ssg_mirgor_cancel_orders();
-- ERROR: Severity: ERROR, Message: Relation "u_prj_ecom.stg_vtex_order_seasa_mirgor_cancel" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ods_sales_control_tower_vtex_ssg_mirgor_cancel_orders line 12 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
