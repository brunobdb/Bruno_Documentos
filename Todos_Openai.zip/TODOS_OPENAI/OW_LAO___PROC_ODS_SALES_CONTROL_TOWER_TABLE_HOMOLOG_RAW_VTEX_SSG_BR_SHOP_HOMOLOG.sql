CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_sales_control_tower_table_homolog_raw_vtex_ssg_br_shop_homolog()
LANGUAGE PLvSQL AS $$
BEGIN

  PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop ON COMMIT PRESERVE ROWS AS (
    select cast(a.creation_timestamp as date)   as po_date
         , EXTRACT(year FROM a.creation_timestamp)           as podate_year
         , EXTRACT(month FROM a.creation_timestamp)          as podate_month
         , 'Brazil'                             as country
         , 0                                    as samsung_care_order
         , 0                                    as samsung_care
         , 0                                    as samsung_care_eligibility
         , 0                                    as trade_in
         , 0                                    as trade_in_eligibility
         , 0                                    as trade_up
         , 0                                    as trade_up_eligibility
         , a.affiliate_id                       as costumer_code_id_name
         , a.order_id                           as po_orderid
         , a.seller_order_id                    as seller_po_orderid
         , cast(null as varchar(3000))          as payment_card_brand
         , cast(null as varchar(3000))          as payment_type
         , 0                                    as installment
         , null                                 as installment_eligibility
         , a.cancellation_reason                as po_cancelation_reason
         , c.product_group_1                    as po_productgroup
         , a.sales_channel                      as po_code_sales_channel
         , null                                 as po_costumer_id
         , a.hostname                           as po_sitecode
         , a.status                             as po_internal_status
         , null                                 as po_invoicenumber
         , a.marketing_tags                     as po_campain_tags
         , a.utm_campaign                       as po_campain
         , a.coupon                             as po_coupon
         , a.utm_medium                         as po_medium
         , a.utm_source                         as po_src
         , a.utmi_campaign                      as po_utmi_campaing
         , a.sequence                           as po_sequence_orderid
         , b.name                               as po_prodname
         , coalesce(
                b.ref_id
              , b.name
           )                                    as po_sku
         , a.seller_id                          as po_seller_id
         , a.seller_name                        as po_seller_name
         , d.status                             as po_status
         , 6                                    as client_subsidiary_id
         , 'SEDA'                               as subsidiary
         , 'BRL'                                as currency
         , null                                 as po_tradepolicy
         , a.origin                             as po_vendortype       
         , cast(null as varchar(255))           as channel
         , cast(null as varchar(255))           as biz_type
         , cast(null as varchar(255))           as audience_type
         , cast(null as varchar(255))           as po_storename
         , cast(null as varchar(255))           as client_acquirer_message
         , a.updated_at                         as po_lastupdate_date_hour
         , 0                                    as po_orderqty
         , sum(b.quantity)                      as po_qty
         , sum(b.price 
                - b.selling_price) / 100.00     as po_itemdiscount_localcurr
         , 0                                    as po_itemdiscount_usd
         , sum(b.price / 100.00)                as po_price_localcurr
         , 0                                    as po_price_usd
         , 'u_prj_ecom.raw_vtex_ssg_br_shop_sales_order'  
                                                as po_plataform_datasource   
         , a.created_at                         as po_source_insert_date
         , a.updated_at                         as po_source_last_update_date
         , current_timestamp                    as po_insert_date
         , null                                 as po_last_update_date
         , cast(null as varchar(3000))          as po_payment_remark
         , cast(a.creation_timestamp as time)   as po_hour 
         , 0                                    as po_totalprice_usd
         , 0                                    as po_totalprice_local
         , cast(null as varchar(255))           as po_devicetype
         , cast('' as varchar(255))             as po_sku_kit
         , cast('' as varchar(255))             as po_prodname_kit
         , cast(0.00 as decimal(18,2))          as po_price_localcurr_kit
         , cast(0.00 as decimal(18,2))          as po_itemdiscount_localcurr_kit
         , false                                as is_kit 
         , 'BRA'                                as country_cd
         , cast(null as varchar(255))           as biz_type_ebi_hq
         , cast(null as varchar(255))           as global_channel_ebi_hq
         , e.selected_sla                       as delivery_mode
      from u_prj_ecom.raw_vtex_ssg_br_shop_sales_order             a
      join u_prj_ecom.raw_vtex_ssg_br_shop_sales_order_item        b on b.order_id      = a.order_id
 left join ow_md.dim_product                                       c on c.sku           = b.ref_id
 left join ow_lao.dim_ods_sales_control_tower_table_status_mapping d on d.status_origin = coalesce(a.status, 'incomplete')
 left join u_prj_ecom.raw_vtex_ssg_br_shop_sales_order_shipping    e on e.order_id      = a.order_id
                                                                    and e.item_index    = b.item_index
     where 1 = 1 
        AND b.quantity IS NOT NULL 
       and a.creation_timestamp >= TIMESTAMP '2025-01-01 00:00:00'
       and not exists(
                select 1
                  from u_prj_ecom.raw_vtex_ssg_br_shop_sales_order_item_components bb
                 where bb.order_id  = a.order_id
                   and bb.unique_id = b.unique_id
           )
       and not exists(                        
                select 1
                  from ow_lao.ods_sales_control_tower_table_homolog aa
                 where aa.po_orderid                  = a.order_id
                   and aa.po_sku                      = b.ref_id
                   and aa.country                     = 'Brazil'
                   and aa.po_internal_status          = coalesce(a.status, 'incomplete')
                   and aa.po_source_last_update_date >= CAST(a.updated_at AS TIMESTAMP)
           )
  group by a.creation_timestamp
         , a.creation_date
         , a.affiliate_id                       
         , a.order_id                  
         , a.seller_order_id                    
         , a.cancellation_reason                
         , c.product_group_1                    
         , a.sales_channel                  
         , a.hostname                           
         , a.status                             
         , a.marketing_tags                  
         , a.utm_campaign                   
         , a.coupon                     
         , a.utm_medium                     
         , a.utm_source
         , a.utmi_campaign                  
         , a.sequence                     
         , b.name                       
         , b.ref_id
         , a.seller_id                          
         , a.seller_name                        
         , d.status                             
         , a.created_at                   
         , a.updated_at      
         , a.origin
         , e.selected_sla
  );
  
  PERFORM INSERT INTO tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop
  (
    select cast(a.creation_timestamp as date)   as po_date
         , EXTRACT(year FROM a.creation_timestamp)           as podate_year
         , EXTRACT(month FROM a.creation_timestamp)          as podate_month
         , 'Brazil'                             as country
         , 0                                    as samsung_care_order
         , 0                                    as samsung_care
         , 0                                    as samsung_care_eligibility
         , 0                                    as trade_in
         , 0                                    as trade_in_eligibility
         , 0                                    as trade_up
         , 0                                    as trade_up_eligibility
         , a.affiliate_id                       as costumer_code_id_name
         , a.order_id                           as po_orderid
         , a.seller_order_id                    as seller_po_orderid
         , cast(null as varchar(3000))          as payment_card_brand
         , cast(null as varchar(3000))          as payment_type
         , 0                                    as installment
         , null                                 as installment_eligibility
         , a.cancellation_reason                as po_cancelation_reason
         , d.product_group_1                    as po_productgroup
         , a.sales_channel                      as po_code_sales_channel
         , null                                 as po_costumer_id
         , a.hostname                           as po_sitecode
         , a.status                             as po_internal_status
         , null                                 as po_invoicenumber
         , a.marketing_tags                     as po_campain_tags
         , a.utm_campaign                       as po_campain
         , a.coupon                             as po_coupon
         , a.utm_medium                         as po_medium
         , a.utm_source                         as po_src
         , a.utmi_campaign                      as po_utmi_campaing
         , a.sequence                           as po_sequence_orderid
         , c.name                               as po_prodname
         , coalesce(
                c.ref_id
              , c.name
           )                                    as po_sku
         , a.seller_id                          as po_seller_id
         , a.seller_name                        as po_seller_name
         , e.status                             as po_status
         , 6                                    as client_subsidiary_id
         , 'SEDA'                               as subsidiary
         , 'BRL'                                as currency
         , null                                 as po_tradepolicy
         , a.origin                             as po_vendortype       
         , null                                 as channel
         , null                                 as biz_type
         , null                                 as audience_type
         , null                                 as po_storename
         , null                                 as client_acquirer_message
         , a.updated_at                         as po_lastupdate_date_hour
         , 0                                    as po_orderqty
         , sum(c.quantity)                      as po_qty
         , sum(c.price 
                - c.selling_price) / 100.00     as po_itemdiscount_localcurr
         , 0                                    as po_itemdiscount_usd
         , sum(c.price / 100.00)                as po_price_localcurr
         , 0                                    as po_price_usd
         , 'u_prj_ecom.raw_vtex_ssg_br_shop_sales_order'  
                                                as po_plataform_datasource   
         , a.created_at                         as po_source_insert_date
         , a.updated_at                         as po_source_last_update_date
         , current_timestamp                    as po_insert_date
         , null                                 as po_last_update_date
         , cast(null as varchar(3000))          as po_payment_remark
         , cast(a.creation_timestamp as time)   as po_hour 
         , 0                                    as po_totalprice_usd
         , 0                                    as po_totalprice_local
         , null                                 as po_devicetype
         , coalesce(
                      b.ref_id
                    , b.name
           )                                    as po_sku_kit
         , b.name                               as po_prodname_kit
         , sum(b.selling_price) / 100.00        as po_price_localcurr_kit
         , sum(b.price 
                - b.selling_price) / 100.00     as po_itemdiscount_localcurr_kit
         , true                                 as is_kit
         , 'BRA'                                as country_cd
         , null                                  as biz_type_ebi_hq
         , null                                  as global_channel_ebi_hq
         , f.selected_sla                       as delivery_mode
      from u_prj_ecom.raw_vtex_ssg_br_shop_sales_order                 a
      join u_prj_ecom.raw_vtex_ssg_br_shop_sales_order_item            b on b.order_id      = a.order_id
      join u_prj_ecom.raw_vtex_ssg_br_shop_sales_order_item_components c on c.order_id      = a.order_id
                                                                        and c.unique_id     = b.unique_id
 left join ow_md.dim_product                                           d on d.sku           = b.ref_id
 left join ow_lao.dim_ods_sales_control_tower_table_status_mapping     e on e.status_origin = coalesce(a.status, 'incomplete')
 left join u_prj_ecom.raw_vtex_ssg_br_shop_sales_order_shipping        f on f.order_id      = a.order_id
                                                                        and f.item_index    = b.item_index
     where 1 = 1
         AND b.quantity IS NOT NULL
       and a.creation_timestamp >= TIMESTAMP '2025-01-01 00:00:00'
       and not exists(                        
                        select 1
                          from ow_lao.ods_sales_control_tower_table_homolog aa
                         where aa.po_orderid                  = a.order_id
                           and aa.po_sku                      = c.ref_id
                           and aa.country                     = 'Brazil'
                           and aa.po_internal_status          = coalesce(a.status, 'incomplete')
                           and aa.po_sku_kit                  = b.ref_id
                           and aa.po_source_last_update_date >= CAST(a.updated_at AS TIMESTAMP)
           )
  group by a.creation_timestamp
         , a.affiliate_id                       
         , a.order_id                  
         , a.seller_order_id                    
         , a.cancellation_reason                
         , d.product_group_1                    
         , a.sales_channel                  
         , a.hostname                           
         , a.status                             
         , a.marketing_tags                  
         , a.utm_campaign                   
         , a.coupon                     
         , a.utm_medium                     
         , a.utm_source
         , a.utmi_campaign                  
         , a.sequence                     
         , c.name                       
         , c.ref_id
         , a.seller_id                          
         , a.seller_name                        
         , e.status                             
         , a.created_at                   
         , a.updated_at      
         , a.origin  
         , b.ref_id
         , b.price
         , b.name
         , f.selected_sla
  );
  
  -- Samsung Care
  PERFORM UPDATE tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop
     SET samsung_care = 1
   WHERE UPPER(po_prodname) LIKE UPPER('%samsung care%');

  -- Payments temp table
  PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop_payments ON COMMIT PRESERVE ROWS AS (
    select a.po_orderid
         , max(a.installments)                as installment
         , LISTAGG(a.brand     USING PARAMETERS separator='|')           as payment_card_brand
         , LISTAGG(a.payment_type USING PARAMETERS separator='|')    as payment_type
         , LISTAGG(
              a.payment_type || ':' || a.brand || ':' || CAST(a.value / 100.00 AS VARCHAR(50)) || ':' || CAST(a.installments AS VARCHAR(20))
              USING PARAMETERS separator='|'
           )                                    as po_payment_remark
      from (   
                  select distinct
                         x.po_orderid
                       , case coalesce(b.payment_group, '')
                              when '' then ''
                              else coalesce(b.payment_system_name, '')
                         end                                   as brand
                       , coalesce(b.payment_group      , '')   as payment_type
                       , b.value
                       , COALESCE(b.installments, 1) as installments
                    from tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop x  
                    join u_prj_ecom.raw_vtex_ssg_br_shop_sales_order_payment b on b.order_id = x.po_orderid
           ) a
  group by a.po_orderid
  );

  PERFORM UPDATE tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop a
     SET installment        = b.installment
       , payment_card_brand = b.payment_card_brand
       , payment_type       = b.payment_type
       , po_payment_remark  = b.po_payment_remark
    FROM tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop_payments b
   WHERE b.po_orderid = a.po_orderid;

  -- Aggregations
  PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop_agg ON COMMIT PRESERVE ROWS AS (
    select country
         , po_orderid
         , sum(po_qty)                    as po_orderqty
         , sum(po_price_localcurr)        as po_totalprice_local
         , sum(po_itemdiscount_localcurr) as po_itemdiscount_localcurr
      from tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop   
  group by country
         , po_orderid           
  );

  PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop_sku_agg ON COMMIT PRESERVE ROWS AS (
    select country
         , po_orderid
         , po_sku
         , sum(po_qty)                    as po_orderqty
         , sum(po_price_localcurr)        as po_totalprice_local
         , sum(po_itemdiscount_localcurr) as po_itemdiscount_localcurr
      from tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop   
  group by country
         , po_orderid   
         , po_sku        
  );

  PERFORM UPDATE tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop a
     SET po_orderqty               = b.po_orderqty
       , po_totalprice_local       = (c.po_totalprice_local - c.po_itemdiscount_localcurr) * c.po_orderqty
       , po_price_localcurr        = (c.po_totalprice_local - c.po_itemdiscount_localcurr) * c.po_orderqty
       , po_itemdiscount_localcurr = c.po_itemdiscount_localcurr                           * c.po_orderqty
    FROM tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop_agg     b
    JOIN tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop_sku_agg c ON c.country    = a.country
                                                                          AND c.po_orderid = a.po_orderid
                                                                          AND c.po_sku     = a.po_sku
   WHERE b.country    = a.country
     AND b.po_orderid = a.po_orderid;

  -- Currency conversion
  PERFORM UPDATE tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop a
     SET po_itemdiscount_usd = COALESCE (a.po_itemdiscount_localcurr / CAST(b.exchange_rate AS DECIMAL(18,6)),0)
       , po_price_usd        = COALESCE (a.po_price_localcurr        / CAST(b.exchange_rate AS DECIMAL(18,6)),0)
       , po_totalprice_usd   = COALESCE (a.po_totalprice_local       / CAST(b.exchange_rate AS DECIMAL(18,6)),0)
    FROM ow_lao.ft_ap2_exchange_rate b
   WHERE b.valid_from  = CAST(TIMESTAMPADD(DAY, -1, a.po_date) AS DATE)
     AND b.to_currency = a.currency;

  -- Sales channel enrichment
  PERFORM UPDATE tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop a
     SET channel               = b.global_channel
       , biz_type              = b.biz_type
       , audience_type         = b.audience_type
       , po_storename          = b.partner_level
       , biz_type_ebi_hq       = b.biz_type_ebi
       , global_channel_ebi_hq = b.global_channel_ebi
    FROM ow_md.sales_channel b
   WHERE lower(b.country)            = lower(a.country)
     AND b.sales_channel             = a.po_code_sales_channel
     AND COALESCE(b.affiliate_id,'') = COALESCE(a.costumer_code_id_name,'')
     AND a.client_subsidiary_id in (6)
     AND lower(b.plataform_type) = 'vtex'
     AND COALESCE(b.has_store_id, 'N') = 'N';

  PERFORM UPDATE tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop a
     SET channel               = b.global_channel
       , biz_type              = b.biz_type
       , audience_type         = b.audience_type
       , po_storename          = b.partner_level
       , biz_type_ebi_hq       = b.biz_type_ebi
       , global_channel_ebi_hq = b.global_channel_ebi
    FROM ow_md.sales_channel b
   WHERE lower(b.country)            = lower(a.country)
     AND b.sales_channel             = a.po_code_sales_channel
     AND a.client_subsidiary_id in (6)
     AND a.po_code_sales_channel IN ('62','65','22');

  PERFORM UPDATE tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop a
     SET a.channel               = 'eStore'
       , a.biz_type              = 'B2C' 
       , a.audience_type         = 'Store+' 
       , a.po_storename          = 'Store+' 
       , a.biz_type_ebi_hq       = 'B2C'
       , a.global_channel_ebi_hq = 'eStore'
    FROM "U_PRJ_ECOM"."VIEW_ECOM_ENDLESS_AISLE_REPORT" b
   WHERE b."order_id"    = a.po_orderid
     AND a.client_subsidiary_id in (6);

  -- app samsung
  PERFORM UPDATE tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop
     SET po_devicetype = 'MOBILEAPP'
   WHERE po_storename in ('App Samsung','App IOS','App Android')
     AND client_subsidiary_id = 6;

  -- default po_device_type   
  PERFORM UPDATE tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop
     SET po_devicetype = 'Web'
   WHERE po_devicetype is null
     AND client_subsidiary_id = 6;

  -- Control tower MERGE
  PERFORM MERGE INTO ow_lao.ods_sales_control_tower_table_homolog        a
  USING tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop b
     ON b.po_orderid = a.po_orderid
    AND b.po_sku     = a.po_sku
    AND b.country    = a.country
    AND b.po_sku_kit = a.po_sku_kit
  WHEN MATCHED THEN UPDATE SET  
                               po_date                    = b.po_date
                             , po_hour                    = b.po_hour
                             , podate_year                = b.podate_year
                             , podate_month               = b.podate_month
                             , samsung_care_order         = b.samsung_care_order
                             , samsung_care               = b.samsung_care
                             , samsung_care_eligibility   = b.samsung_care_eligibility
                             , trade_in                   = b.trade_in
                             , trade_in_eligibility       = b.trade_in_eligibility
                             , costumer_code_id_name      = b.costumer_code_id_name
                             , seller_po_orderid          = b.seller_po_orderid
                             , payment_card_brand         = b.payment_card_brand
                             , payment_type               = b.payment_type
                             , installment                = b.installment
                             , installment_eligibility    = b.installment_eligibility
                             , po_cancelation_reason      = b.po_cancelation_reason
                             , po_productgroup            = b.po_productgroup
                             , po_code_sales_channel      = b.po_code_sales_channel
                             , po_costumer_id             = b.po_costumer_id
                             , po_sitecode                = b.po_sitecode
                             , po_internal_status         = b.po_internal_status
                             , po_invoicenumber           = b.po_invoicenumber
                             , po_campain_tags            = b.po_campain_tags
                             , po_campain                 = b.po_campain
                             , po_coupon                  = b.po_coupon
                             , po_medium                  = b.po_medium
                             , po_src                     = b.po_src
                             , po_utmi_campaing           = b.po_utmi_campaing
                             , po_prodname                = b.po_prodname
                             , po_seller_id               = b.po_seller_id
                             , po_seller_name             = b.po_seller_name
                             , po_status                  = b.po_status
                             , client_subsidiary_id       = b.client_subsidiary_id
                             , subsidiary                 = b.subsidiary
                             , currency                   = b.currency
                             , po_tradepolicy             = b.po_tradepolicy
                             , po_vendortype              = b.po_vendortype
                             , channel                    = b.channel
                             , biz_type                   = b.biz_type
                             , audience_type              = b.audience_type
                             , po_storename               = b.po_storename
                             , client_acquirer_message    = b.client_acquirer_message
                             , po_lastupdate_date_hour    = b.po_lastupdate_date_hour
                             , po_orderqty                = b.po_orderqty
                             , po_qty                     = b.po_qty
                             , po_itemdiscount_localcurr  = b.po_itemdiscount_localcurr
                             , po_itemdiscount_usd        = b.po_itemdiscount_usd
                             , po_price_localcurr         = b.po_price_localcurr
                             , po_price_usd               = b.po_price_usd
                             , po_plataform_datasource    = b.po_plataform_datasource
                             , po_source_insert_date      = b.po_source_insert_date
                             , po_source_last_update_date = b.po_source_last_update_date
                             , po_insert_date             = b.po_insert_date
                             , po_last_update_date        = b.po_last_update_date
                             , po_payment_remark          = b.po_payment_remark
                             , po_totalprice_usd          = b.po_totalprice_usd
                             , po_totalprice_local        = b.po_totalprice_local
                             , po_devicetype              = b.po_devicetype
                             , updated_datetime           = current_timestamp
                             , po_sku_kit                 = b.po_sku_kit  
                             , po_prodname_kit            = b.po_prodname_kit           
                             , is_kit                     = b.is_kit
                             , country_cd                 = b.country_cd  
                             , biz_type_ebi_hq            = b.biz_type_ebi_hq 
                             , global_channel_ebi_hq      = b.global_channel_ebi_hq
                             , delivery_mode              = b.delivery_mode
  WHEN NOT MATCHED THEN INSERT(
                                   po_date
                                 , po_hour
                                 , podate_year
                                 , podate_month
                                 , country
                                 , samsung_care_order
                                 , samsung_care
                                 , samsung_care_eligibility
                                 , trade_in
                                 , trade_in_eligibility
                                 , costumer_code_id_name
                                 , po_orderid
                                 , seller_po_orderid
                                 , payment_card_brand
                                 , payment_type
                                 , installment
                                 , installment_eligibility
                                 , po_cancelation_reason
                                 , po_productgroup
                                 , po_code_sales_channel
                                 , po_costumer_id
                                 , po_sitecode
                                 , po_internal_status
                                 , po_invoicenumber
                                 , po_campain_tags
                                 , po_campain
                                 , po_coupon
                                 , po_medium
                                 , po_src
                                 , po_utmi_campaing
                                 , po_sequence_orderid
                                 , po_prodname
                                 , po_sku
                                 , po_seller_id
                                 , po_seller_name
                                 , po_status
                                 , client_subsidiary_id
                                 , subsidiary
                                 , currency
                                 , po_tradepolicy
                                 , po_vendortype
                                 , channel
                                 , biz_type
                                 , audience_type
                                 , po_storename
                                 , client_acquirer_message
                                 , po_lastupdate_date_hour
                                 , po_orderqty
                                 , po_qty
                                 , po_itemdiscount_localcurr
                                 , po_itemdiscount_usd
                                 , po_price_localcurr
                                 , po_price_usd
                                 , po_plataform_datasource
                                 , po_source_insert_date
                                 , po_source_last_update_date
                                 , po_insert_date
                                 , po_last_update_date
                                 , po_payment_remark   
                                 , po_totalprice_usd
                                 , po_totalprice_local    
                                 , po_devicetype    
                                 , po_sku_kit                   
                                 , po_prodname_kit              
                                 , is_kit    
                                 , country_cd
                                 , biz_type_ebi_hq              
                                 , global_channel_ebi_hq  
                                 , delivery_mode
                         )
                         VALUES(
                                   b.po_date
                                 , b.po_hour
                                 , b.podate_year
                                 , b.podate_month
                                 , b.country
                                 , b.samsung_care_order
                                 , b.samsung_care
                                 , b.samsung_care_eligibility
                                 , b.trade_in
                                 , b.trade_in_eligibility
                                 , b.costumer_code_id_name
                                 , b.po_orderid
                                 , b.seller_po_orderid
                                 , b.payment_card_brand
                                 , b.payment_type
                                 , b.installment
                                 , b.installment_eligibility
                                 , b.po_cancelation_reason
                                 , b.po_productgroup
                                 , b.po_code_sales_channel
                                 , b.po_costumer_id
                                 , b.po_sitecode
                                 , b.po_internal_status
                                 , b.po_invoicenumber
                                 , b.po_campain_tags
                                 , b.po_campain
                                 , b.po_coupon
                                 , b.po_medium
                                 , b.po_src
                                 , b.po_utmi_campaing
                                 , b.po_sequence_orderid
                                 , b.po_prodname
                                 , b.po_sku
                                 , b.po_seller_id
                                 , b.po_seller_name
                                 , b.po_status
                                 , b.client_subsidiary_id
                                 , b.subsidiary
                                 , b.currency
                                 , b.po_tradepolicy
                                 , b.po_vendortype
                                 , b.channel
                                 , b.biz_type
                                 , b.audience_type
                                 , b.po_storename
                                 , b.client_acquirer_message
                                 , b.po_lastupdate_date_hour
                                 , b.po_orderqty
                                 , b.po_qty
                                 , b.po_itemdiscount_localcurr
                                 , b.po_itemdiscount_usd
                                 , b.po_price_localcurr
                                 , b.po_price_usd
                                 , b.po_plataform_datasource
                                 , b.po_source_insert_date
                                 , b.po_source_last_update_date
                                 , b.po_insert_date
                                 , b.po_last_update_date
                                 , b.po_payment_remark   
                                 , b.po_totalprice_usd
                                 , b.po_totalprice_local                              
                                 , b.po_devicetype
                                 , b.po_sku_kit                   
                                 , b.po_prodname_kit              
                                 , b.is_kit 
                                 , b.country_cd 
                                 , b.biz_type_ebi_hq                 
                                 , b.global_channel_ebi_hq  
                                 , b.delivery_mode
                         );

END;
$$;

-- CALL OW_LAO.proc_ods_sales_control_tower_table_homolog_raw_vtex_ssg_br_shop_homolog();
-- ERROR: Severity: ERROR, Message: Relation "ow_md.dim_product" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ods_sales_control_tower_table_homolog_raw_vtex_ssg_br_shop_homolog line 4 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
-- CALL OW_LAO.proc_ods_sales_control_tower_table_homolog_raw_vtex_ssg_br_shop_homolog();
-- ERROR: Severity: ERROR, Message: Relation "ow_md.dim_product" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ods_sales_control_tower_table_homolog_raw_vtex_ssg_br_shop_homolog line 4 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
