CREATE OR REPLACE PROCEDURE ow_lao.proc_ods_sales_payments_sela_details()
LANGUAGE PLvSQL AS $$
BEGIN
    
    PERFORM CREATE LOCAL TEMPORARY TABLE temp_sela_subsidiaries_region_mapping ON COMMIT PRESERVE ROWS AS (
        SELECT 8  ::INT AS subsidiary_id, 'Paraguay'           ::VARCHAR AS api_account, '45'::VARCHAR AS store_id, 'Regional'::VARCHAR AS api_group UNION ALL
        SELECT 17 ::INT,          'Miami-USA'         ::VARCHAR,           '8'::VARCHAR,              'Regional'::VARCHAR UNION ALL
        SELECT 7  ::INT,          'MyEmployees'       ::VARCHAR,           '9'::VARCHAR,              'Regional'::VARCHAR UNION ALL
        SELECT 7  ::INT,          'Panama'            ::VARCHAR,          '44'::VARCHAR,              'Regional'::VARCHAR UNION ALL
        SELECT 13 ::INT,          'Nicaragua'         ::VARCHAR,          '13'::VARCHAR,              'Regional'::VARCHAR UNION ALL
        SELECT 7  ::INT,          'CRBN'              ::VARCHAR,          '15'::VARCHAR,              'Regional'::VARCHAR UNION ALL
        SELECT 7  ::INT,          'Offers'            ::VARCHAR,          '16'::VARCHAR,              'Regional'::VARCHAR UNION ALL
        SELECT 18 ::INT,          'Puerto Rico'       ::VARCHAR,          '17'::VARCHAR,              'Regional'::VARCHAR UNION ALL
        SELECT 7  ::INT,          'Mybenefits PA'     ::VARCHAR,          '22'::VARCHAR,              'Regional'::VARCHAR UNION ALL
        SELECT 7  ::INT,          'Alianzas'          ::VARCHAR,          '34'::VARCHAR,              'Regional'::VARCHAR UNION ALL
        SELECT 12 ::INT,          'Dominican Republic'::VARCHAR,          '35'::VARCHAR,              'Regional'::VARCHAR UNION ALL
        SELECT 12 ::INT,          'Mybenefits DR'     ::VARCHAR,          '42'::VARCHAR,              'Regional'::VARCHAR UNION ALL
        SELECT 10 ::INT,          'Guatemala'         ::VARCHAR,           '6'::VARCHAR,                   'NCA'::VARCHAR UNION ALL
        SELECT 15 ::INT,          'El Salvador'       ::VARCHAR,          '20'::VARCHAR,                   'NCA'::VARCHAR UNION ALL
        SELECT 14 ::INT,          'Honduras'          ::VARCHAR,          '21'::VARCHAR,                   'NCA'::VARCHAR UNION ALL
        SELECT 10 ::INT,          'EPP Guatemala'     ::VARCHAR,          '26'::VARCHAR,                   'NCA'::VARCHAR UNION ALL
        SELECT 10 ::INT,          'Employees NCA'     ::VARCHAR,          '27'::VARCHAR,                   'NCA'::VARCHAR UNION ALL
        SELECT 15 ::INT,          'EPP El Salvador'   ::VARCHAR,          '29'::VARCHAR,                   'NCA'::VARCHAR UNION ALL
        SELECT 14 ::INT,          'EPP Honduras'      ::VARCHAR,          '41'::VARCHAR,                   'NCA'::VARCHAR UNION ALL
        SELECT 19 ::INT,          'Costa Rica'        ::VARCHAR,          '43'::VARCHAR,                   'NCA'::VARCHAR UNION ALL  
        SELECT 11 ::INT,          'Employees ECU'     ::VARCHAR,          '45'::VARCHAR,                   'NCA'::VARCHAR UNION ALL
        SELECT 11 ::INT,          'Ecuador'           ::VARCHAR,          '43'::VARCHAR,                   'ECU'::VARCHAR UNION ALL 
        SELECT 11 ::INT,          'Ecuador Benefits'  ::VARCHAR,          '44'::VARCHAR,                   'ECU'::VARCHAR
    );

    PERFORM CREATE LOCAL TEMPORARY TABLE temp_sales_payments_sela_prepare ON COMMIT PRESERVE ROWS AS (
        SELECT 
               a.created_at                                                        AS insert_timestamp
             , c.po_date                                                           AS po_date 
             , c.podate_month                                                      AS po_month 
             , c.podate_year                                                       AS po_year 
             , EXTRACT(HOUR FROM c.po_date)                                        AS po_hour
             , c.country                                                           AS pay_subsidiary 
             , a.response_code                                                     AS pay_code 
             , CAST(NULL AS VARCHAR(255))                                          AS pay_id 
             , CAST(a.reponse_timestamp AS DATE)                                   AS pay_date 
             , EXTRACT(MONTH FROM CAST(a.reponse_timestamp AS DATE))               AS pay_month 
             , EXTRACT(YEAR  FROM CAST(a.reponse_timestamp AS DATE))               AS pay_year 
             , EXTRACT(HOUR  FROM CAST(a.reponse_timestamp AS TIMESTAMP))          AS pay_hour 
             , COALESCE(a.reponse_status, '')                                      AS pay_status 
             , a.response_message                                                  AS pay_detail 
             , CAST(NULL AS VARCHAR(255))                                          AS pay_gateway_code 
             , CAST(NULL AS VARCHAR(255))                                          AS payment_type 
             , a.payment_method                                                    AS pay_gateway 
             , c.po_price_localcurr                                                AS revenue_local 
             , c.po_orderid                                                        AS pay_orderid 
             , c.po_sitecode                                                       AS pay_storename 
             , CAST(NULL AS VARCHAR(255))                                          AS postoretype 
             , c.po_devicetype                                                     AS po_devicetype 
             , COALESCE(c.po_status, '')                                           AS po_status 
             , CAST(NULL AS VARCHAR(255))                                          AS order_status_type 
             , c.currency                                                          AS currency 
             , CAST(NULL AS TIMESTAMP)                                             AS po_order_lastmodifydate 
             , c.po_storename                                                      AS postorename 
             , c.channel                                                           AS channel 
             , c.biz_type                                                          AS biz_type 
             , c.audience_type                                                     AS audience_type 
             , c.subsidiary                                                        AS subsidiary 
             , a.reponse_amount                                                    AS pe_amount
             , po_price_usd                                                        AS revenu_usd
             , c.po_orderid                                                        AS po_orderid 
             , CAST('' AS VARCHAR(255))                                            AS pay_action 
             , CAST('' AS VARCHAR(255))                                            AS pay_result 
             , CAST('' AS VARCHAR(1000))                                           AS pay_description 
             , a.response_message                                                  AS pay_message
             , c.po_status                                                         AS po_status_ct
             , CAST(NULL AS VARCHAR(255))                                          AS funnel_status
             , c.po_orderid                                                        AS orderid_log
             , c.po_internal_status                                                AS po_internal_status
             , CAST('' AS VARCHAR(255))                                            AS po_payment_type
             , c.po_paymentprovider                                                
             , c.payment_card_brand
             , COALESCE(a.reponse_timestamp, a.created_at)                         AS datasource_origin_timestamp
             , 'ow_lao.raw_sela_sales_orders_cancelations_reason'                  AS po_plataform_datasource
             , CAST(NULL AS VARCHAR(255))                                          AS pay_gateway_status
             , CAST(NULL AS VARCHAR(255))                                          AS po_payment_type_status 
             , ROW_NUMBER() OVER (
                    PARTITION BY c.country, c.po_sitecode, c.po_orderid
                    ORDER BY COALESCE(a.reponse_timestamp, a.created_at) DESC
               )                                                                   AS dedup
        FROM ow_lao.raw_sela_sales_orders_cancelations_reason a
        JOIN temp_sela_subsidiaries_region_mapping          b 
          ON b.api_group = a.api_group
         AND b.store_id  = a.store_id
        JOIN ow_lao.ods_sales_control_tower_table           c 
          ON c.po_orderid           = a.order_id
         AND c.client_subsidiary_id = b.subsidiary_id
        WHERE 1 = 1
    );

    PERFORM DELETE FROM temp_sales_payments_sela_prepare WHERE dedup <> 1;

    PERFORM UPDATE temp_sales_payments_sela_prepare a
       SET funnel_status = b.status
      FROM ow_lao.DIM_PAYMENT_FUNNEL_STATUS_MAPPING b
     WHERE b.pay_status      = a.pay_status
       AND b.po_status       = a.po_status
       AND b.pay_description = a.pay_description
       AND b.data_source     = a.po_plataform_datasource
       AND b.active = TRUE;

    PERFORM UPDATE temp_sales_payments_sela_prepare a
       SET pay_gateway_status = b.gateway
      FROM ow_lao.dim_payment_pay_gateway_mapping b
     WHERE b.data_source = a.po_plataform_datasource
       AND b.pay_gateway = a.pay_gateway
       AND b.active = TRUE;

    PERFORM UPDATE temp_sales_payments_sela_prepare a
       SET po_payment_type_status = b.payment_mode
      FROM ow_lao.dim_payment_type_mapping b
     WHERE b.data_source  = a.po_plataform_datasource
       AND b.payment_type = a.payment_type
       AND b.active = TRUE;

    PERFORM MERGE INTO ow_lao.ods_payment_funnel_sela_homolog a
    USING temp_sales_payments_sela_prepare b
       ON b.pay_orderid    = a.pay_orderid
      AND b.pay_subsidiary = a.pay_subsidiary
    WHEN MATCHED THEN UPDATE SET
           po_date = b.po_date 
         , po_month = b.po_month 
         , po_year = b.po_year 
         , po_hour = b.po_hour 
         , pay_subsidiary = b.pay_subsidiary 
         , pay_code = b.pay_code 
         , pay_id = b.pay_id 
         , pay_date = b.pay_date 
         , pay_month = b.pay_month 
         , pay_year = b.pay_year 
         , pay_hour = b.pay_hour 
         , pay_status = b.pay_status 
         , pay_detail = b.pay_detail 
         , pay_gateway_code = b.pay_gateway_code 
         , payment_type = b.payment_type 
         , pay_gateway = b.pay_gateway 
         , revenue_local = b.revenue_local 
         , pay_orderid = b.pay_orderid 
         , pay_storename = b.pay_storename 
         , postoretype = b.postoretype 
         , po_devicetype = b.po_devicetype 
         , po_status = b.po_status 
         , order_status_type = b.order_status_type 
         , currency = b.currency 
         , po_order_lastmodifydate = b.po_order_lastmodifydate 
         , postorename = b.postorename 
         , channel = b.channel 
         , biz_type = b.biz_type 
         , audience_type = b.audience_type 
         , subsidiary = b.subsidiary 
         , pe_amount= b.pe_amount
         , revenu_usd= b.revenu_usd
         , po_orderid = b.po_orderid 
         , pay_action = b.pay_action 
         , pay_result = b.pay_result 
         , pay_description = b.pay_description 
         , pay_message = b.pay_message 
         , po_internal_status= b.po_internal_status
         , po_payment_type= b.po_payment_type
         , po_paymentprovider= b.po_paymentprovider
         , payment_card_brand= b.payment_card_brand
         , po_status_ct = b.po_status_ct 
         , funnel_status = b.funnel_status
         , updated_timestamp = CURRENT_TIMESTAMP
         , PAY_GATEWAY_STATUS = b.PAY_GATEWAY_STATUS
         , PO_PAYMENT_TYPE_STATUS = b.PO_PAYMENT_TYPE_STATUS
         , PO_PLATAFORM_DATASOURCE = b.PO_PLATAFORM_DATASOURCE
         , datasource_origin_timestamp = b.datasource_origin_timestamp
    WHEN NOT MATCHED THEN INSERT (
           po_date 
         , po_month 
         , po_year 
         , po_hour 
         , pay_subsidiary 
         , pay_code 
         , pay_id 
         , pay_date 
         , pay_month 
         , pay_year 
         , pay_hour 
         , pay_status 
         , pay_detail 
         , pay_gateway_code 
         , payment_type 
         , pay_gateway 
         , revenue_local 
         , pay_orderid 
         , pay_storename 
         , postoretype 
         , po_devicetype 
         , po_status 
         , order_status_type 
         , currency 
         , po_order_lastmodifydate 
         , postorename 
         , channel 
         , biz_type 
         , audience_type 
         , subsidiary 
         , pe_amount
         , revenu_usd
         , po_orderid 
         , pay_action 
         , pay_result 
         , pay_description 
         , pay_message 
         , po_internal_status
         , po_payment_type
         , po_paymentprovider
         , payment_card_brand
         , po_status_ct   
         , funnel_status 
         , PAY_GATEWAY_STATUS
         , PO_PAYMENT_TYPE_STATUS
         , PO_PLATAFORM_DATASOURCE
         , datasource_origin_timestamp
    ) VALUES (
           b.po_date 
         , b.po_month 
         , b.po_year 
         , b.po_hour 
         , b.pay_subsidiary 
         , b.pay_code 
         , b.pay_id 
         , b.pay_date 
         , b.pay_month 
         , b.pay_year 
         , b.pay_hour 
         , b.pay_status 
         , b.pay_detail 
         , b.pay_gateway_code 
         , b.payment_type 
         , b.pay_gateway 
         , b.revenue_local 
         , b.pay_orderid 
         , b.pay_storename 
         , b.postoretype 
         , b.po_devicetype 
         , b.po_status 
         , b.order_status_type 
         , b.currency 
         , b.po_order_lastmodifydate 
         , b.postorename 
         , b.channel 
         , b.biz_type 
         , b.audience_type 
         , b.subsidiary 
         , b.pe_amount
         , b.revenu_usd
         , b.po_orderid 
         , b.pay_action 
         , b.pay_result 
         , b.pay_description 
         , b.pay_message 
         , b.po_internal_status
         , b.po_payment_type
         , b.po_paymentprovider
         , b.payment_card_brand
         , b.po_status_ct 
         , b.funnel_status
         , b.PAY_GATEWAY_STATUS
         , b.PO_PAYMENT_TYPE_STATUS
         , b.PO_PLATAFORM_DATASOURCE
         , b.datasource_origin_timestamp
    );

END;
$$;

-- CALL ow_lao.proc_ods_sales_payments_sela_details();
-- ERROR: Severity: ERROR, Message: Relation "ow_lao.raw_sela_sales_orders_cancelations_reason" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ods_sales_payments_sela_details line 30 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
-- CALL ow_lao.proc_ods_sales_payments_sela_details();
-- ERROR: Severity: ERROR, Message: Relation "ow_lao.raw_sela_sales_orders_cancelations_reason" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ods_sales_payments_sela_details line 30 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
