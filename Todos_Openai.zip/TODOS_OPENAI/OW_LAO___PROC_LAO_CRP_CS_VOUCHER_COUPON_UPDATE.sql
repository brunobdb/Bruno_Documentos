CREATE OR REPLACE PROCEDURE OW_LAO.PROC_LAO_CRP_CS_VOUCHER_COUPON_UPDATE()
LANGUAGE PLvSQL AS $$
BEGIN 
    PERFORM MERGE INTO OW_LAO.DIM_LAO_CRP_CS_VOUCHER_COUPON A
    USING OW_LAO.RAW_LAO_CRP_CS_VOUCHER_COUPON B
      ON A.SUBSIDIARY = B.SUBSIDIARY
     AND A.VOUCHER_COUPON = B.VOUCHER_COUPON
    WHEN MATCHED AND (A.ACTIVE = FALSE OR A.ACTIVE IS NULL)
      THEN UPDATE SET
        UPDATED_TIMESTAMP = CURRENT_TIMESTAMP,
        ACTIVE = TRUE,
        REPROCESSING = TRUE
    WHEN NOT MATCHED THEN
      INSERT (
        SUBSIDIARY,
        VOUCHER_COUPON,
        CRP,
        ACTIVE,
        REPROCESSING
      )
      VALUES (
        B.SUBSIDIARY,
        B.VOUCHER_COUPON,
        2,
        TRUE,
        TRUE
      );

    PERFORM UPDATE OW_LAO.DIM_LAO_CRP_CS_VOUCHER_COUPON A
       SET ACTIVE = FALSE,
           REPROCESSING = FALSE,
           UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
     WHERE NOT EXISTS (
             SELECT 1
               FROM OW_LAO.RAW_LAO_CRP_CS_VOUCHER_COUPON B
              WHERE A.SUBSIDIARY = B.SUBSIDIARY
                AND A.VOUCHER_COUPON = B.VOUCHER_COUPON
           )
       AND ACTIVE = TRUE;
END
$$;

-- CALL OW_LAO.PROC_LAO_CRP_CS_VOUCHER_COUPON_UPDATE();
-- ERROR: Severity: ERROR, Message: Cannot set a NOT NULL column (ID) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure PROC_LAO_CRP_CS_VOUCHER_COUPON_UPDATE line 3 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3216, Error Code: 2502, 
-- CALL OW_LAO.PROC_LAO_CRP_CS_VOUCHER_COUPON_UPDATE();
-- ERROR: Severity: ERROR, Message: Cannot set a NOT NULL column (ID) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure PROC_LAO_CRP_CS_VOUCHER_COUPON_UPDATE line 3 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3216, Error Code: 2502, 
-- SELECT column_name, data_type, is_nullable, default_value FROM v_catalog.columns 
-- WHERE table_schema = 'OW_LAO' AND table_name = 'DIM_LAO_CRP_CS_VOUCHER_COUPON'
-- ORDER BY ordinal_position;
-- ERROR: Severity: ERROR, Message: Column "default_value" does not exist, Sqlstate: 42703, Routine: transformSQLColumnRef, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Optimizer/OptUtil/ExprUtil.cpp, Line: 7401, Error Code: 2624, 
SELECT column_name, data_type, is_nullable FROM v_catalog.columns 
WHERE table_schema = 'OW_LAO' AND table_name = 'DIM_LAO_CRP_CS_VOUCHER_COUPON'
ORDER BY ordinal_position;
-- column_name | data_type | is_nullable
-- ------------+-----------+------------
-- ID | int | False
-- SUBSIDIARY | varchar(255) | True
-- VOUCHER_COUPON | varchar(255) | True
-- INSERTED_TIMESTAMP | timestamp | True
-- UPDATED_TIMESTAMP | timestamp | True
-- CRP | int | True
-- ACTIVE | boolean | True
-- REPROCESSING | boolean | True

SELECT sequence_schema, sequence_name FROM v_catalog.sequences WHERE sequence_schema = 'OW_LAO';
-- sequence_schema | sequence_name
-- ----------------+--------------

SELECT column_name, data_type, is_nullable, column_default FROM v_catalog.columns 
WHERE table_schema = 'OW_LAO' AND table_name = 'DIM_LAO_CRP_CS_VOUCHER_COUPON'
ORDER BY ordinal_position;
-- column_name | data_type | is_nullable | column_default
-- ------------+-----------+-------------+---------------
-- ID | int | False | 
-- SUBSIDIARY | varchar(255) | True | 
-- VOUCHER_COUPON | varchar(255) | True | 
-- INSERTED_TIMESTAMP | timestamp | True | 
-- UPDATED_TIMESTAMP | timestamp | True | 
-- CRP | int | True | 
-- ACTIVE | boolean | True | 
-- REPROCESSING | boolean | True | 

CREATE OR REPLACE PROCEDURE OW_LAO.PROC_LAO_CRP_CS_VOUCHER_COUPON_UPDATE()
LANGUAGE PLvSQL AS $$
BEGIN 
    -- Activate existing matches
    PERFORM UPDATE OW_LAO.DIM_LAO_CRP_CS_VOUCHER_COUPON A
       SET UPDATED_TIMESTAMP = CURRENT_TIMESTAMP,
           ACTIVE = TRUE,
           REPROCESSING = TRUE
     WHERE (A.ACTIVE = FALSE OR A.ACTIVE IS NULL)
       AND EXISTS (
             SELECT 1
               FROM OW_LAO.RAW_LAO_CRP_CS_VOUCHER_COUPON B
              WHERE A.SUBSIDIARY = B.SUBSIDIARY
                AND A.VOUCHER_COUPON = B.VOUCHER_COUPON
           );

    -- Insert new records with generated IDs
    PERFORM INSERT INTO OW_LAO.DIM_LAO_CRP_CS_VOUCHER_COUPON
        (ID, SUBSIDIARY, VOUCHER_COUPON, CRP, ACTIVE, REPROCESSING)
    SELECT
        (SELECT COALESCE(MAX(ID), 0) FROM OW_LAO.DIM_LAO_CRP_CS_VOUCHER_COUPON)
          + ROW_NUMBER() OVER (ORDER BY B.SUBSIDIARY, B.VOUCHER_COUPON) AS ID,
        B.SUBSIDIARY,
        B.VOUCHER_COUPON,
        2,
        TRUE,
        TRUE
    FROM OW_LAO.RAW_LAO_CRP_CS_VOUCHER_COUPON B
    LEFT JOIN OW_LAO.DIM_LAO_CRP_CS_VOUCHER_COUPON A
      ON A.SUBSIDIARY = B.SUBSIDIARY
     AND A.VOUCHER_COUPON = B.VOUCHER_COUPON
    WHERE A.ID IS NULL;

    -- Deactivate those no longer present
    PERFORM UPDATE OW_LAO.DIM_LAO_CRP_CS_VOUCHER_COUPON A
       SET ACTIVE = FALSE,
           REPROCESSING = FALSE,
           UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
     WHERE ACTIVE = TRUE
       AND NOT EXISTS (
             SELECT 1
               FROM OW_LAO.RAW_LAO_CRP_CS_VOUCHER_COUPON B
              WHERE A.SUBSIDIARY = B.SUBSIDIARY
                AND A.VOUCHER_COUPON = B.VOUCHER_COUPON
           );
END
$$;

CALL OW_LAO.PROC_LAO_CRP_CS_VOUCHER_COUPON_UPDATE();
-- PROC_LAO_CRP_CS_VOUCHER_COUPON_UPDATE
-- -------------------------------------
-- 0

