-- CREATE OR REPLACE PROCEDURE OW_LAO.HOMOLOG_PROC_SALES_CAMPAIGN(
--     IN CONSULTA VARCHAR(40),
--     IN CAMPAIGN_TAG VARCHAR(400)
-- ) 
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--     IF CONSULTA = 'EXEC_UPDATE_CAMPAIGN_NAME' THEN
--     BEGIN
--         -- Limpa tabela de atualização
--         PERFORM TRUNCATE TABLE OW_LAO.TMP_UPDATE_CAMPAIGN_NAME;
-- 
--         -- Recolhe os id's das campanhas modificadas
--         PERFORM INSERT INTO OW_LAO.TMP_UPDATE_CAMPAIGN_NAME
--         SELECT 
--             ID_CAMPAIGN
--         FROM (
--             SELECT 
--                 A.CAMPAIGN_TAG,
--                 A.SUBSIDIARY,
--                 A.DIVISION,
--                 A.BIZ_TYPE,
--                 A.PO_DEVICETYPE,
--                 A.INITIAL_DATE,
--                 A.FINAL_DATE,
--                 A.PRODUCT,
--                 A.PRODUCT_GROUP,
--                 A.PO_SKU,
--                 A.ID_CAMPAIGN,
--                 B.CAMPAIGN_TAG AS TAG_DELETE
--             FROM OW_LAO.DIM_CAMPAIGN_NAME A
--             FULL OUTER JOIN OW_LAO.TMP_CAMPAIGN_NAME B
--               ON COALESCE(A.CAMPAIGN_TAG,'')              = COALESCE(B.CAMPAIGN_TAG,'')
--              AND COALESCE(A.SUBSIDIARY,'')               = COALESCE(B.SUBSIDIARY,'')
--              AND COALESCE(A.PO_DEVICETYPE,'')            = COALESCE(B.PO_DEVICETYPE,'')
--              AND COALESCE(TO_CHAR(A.INITIAL_DATE,'YYYY-MM-DD'),'') = COALESCE(TO_CHAR(B.INITIAL_DATE,'YYYY-MM-DD'),'')
--              AND COALESCE(TO_CHAR(A.FINAL_DATE,'YYYY-MM-DD'),'')   = COALESCE(TO_CHAR(B.FINAL_DATE,'YYYY-MM-DD'),'')
--              AND COALESCE(A.DIVISION,'')                 = COALESCE(B.DIVISION,'')
--              AND COALESCE(A.BIZ_TYPE,'')                 = COALESCE(B.BIZ_TYPE,'')
--              AND COALESCE(A.PRODUCT,'')                  = COALESCE(B.PRODUCT,'')
--              AND COALESCE(A.PRODUCT_GROUP,'')            = COALESCE(B.PRODUCT_GROUP,'')
--              AND COALESCE(A.PO_SKU,'')                   = COALESCE(B.PO_SKU,'')
--              AND COALESCE(A.AUDIENCE_TYPE,'')            = COALESCE(B.AUDIENCE_TYPE,'')
--             WHERE A.CAMPAIGN_TAG IS NOT NULL
--         ) AS TBL
--         WHERE TAG_DELETE IS NULL;
-- 
--         -- Limpa tabelas tmp
--         PERFORM DELETE FROM OW_LAO.TMP_SALES_CAMPAIGN 
--          WHERE ID_CAMPAIGN IN (SELECT ID_CAMPAIGN FROM OW_LAO.TMP_UPDATE_CAMPAIGN_NAME);
-- 
--         -- Limpa tabelas dimensões
--         PERFORM DELETE FROM OW_LAO.DIM_CAMPAIGN_NAME 
--          WHERE ID_CAMPAIGN IN (SELECT ID_CAMPAIGN FROM OW_LAO.TMP_UPDATE_CAMPAIGN_NAME);
-- 
--         -- atualização de novas campanhas e campanhas modificadas
--         PERFORM INSERT INTO OW_LAO.DIM_CAMPAIGN_NAME(
--             CAMPAIGN_TAG,SUBSIDIARY,DIVISION,BIZ_TYPE,PO_DEVICETYPE,INITIAL_DATE,FINAL_DATE,PRODUCT,PRODUCT_GROUP,PO_SKU,AUDIENCE_TYPE)
--         SELECT 
--             B.CAMPAIGN_TAG,
--             B.SUBSIDIARY,
--             B.DIVISION,
--             B.BIZ_TYPE,
--             B.PO_DEVICETYPE,
--             B.INITIAL_DATE,
--             B.FINAL_DATE,
--             B.PRODUCT,
--             B.PRODUCT_GROUP,
--             B.PO_SKU,
--             B.AUDIENCE_TYPE
--         FROM OW_LAO.DIM_CAMPAIGN_NAME A
--         FULL OUTER JOIN OW_LAO.TMP_CAMPAIGN_NAME B
--           ON COALESCE(A.CAMPAIGN_TAG,'')              = COALESCE(B.CAMPAIGN_TAG,'')
--          AND COALESCE(A.SUBSIDIARY,'')               = COALESCE(B.SUBSIDIARY,'')
--          AND COALESCE(A.PO_DEVICETYPE,'')            = COALESCE(B.PO_DEVICETYPE,'')
--          AND COALESCE(TO_CHAR(A.INITIAL_DATE,'YYYY-MM-DD'),'') = COALESCE(TO_CHAR(B.INITIAL_DATE,'YYYY-MM-DD'),'')
--          AND COALESCE(TO_CHAR(A.FINAL_DATE,'YYYY-MM-DD'),'')   = COALESCE(TO_CHAR(B.FINAL_DATE,'YYYY-MM-DD'),'')
--          AND COALESCE(A.DIVISION,'')                 = COALESCE(B.DIVISION,'')
--          AND COALESCE(A.BIZ_TYPE,'')                 = COALESCE(B.BIZ_TYPE,'')
--          AND COALESCE(A.PRODUCT,'')                  = COALESCE(B.PRODUCT,'')
--          AND COALESCE(A.PRODUCT_GROUP,'')            = COALESCE(B.PRODUCT_GROUP,'')
--          AND COALESCE(A.PO_SKU,'')                   = COALESCE(B.PO_SKU,'')
--          AND COALESCE(A.AUDIENCE_TYPE,'')            = COALESCE(B.AUDIENCE_TYPE,'')
--         WHERE B.CAMPAIGN_TAG IS NOT NULL
--           AND A.ID_CAMPAIGN IS NULL;
-- 
--         -- Limpa tabela de atualização
--         PERFORM TRUNCATE TABLE OW_LAO.TMP_UPDATE_CAMPAIGN_NAME;
-- 
--         -- Atualiza datas de LY
--         PERFORM UPDATE OW_LAO.DIM_CAMPAIGN_NAME AS A
--         SET
--             INITIAL_DATE_LY = TIMESTAMPADD(DAY, 
--                                 CASE WHEN EXTRACT(DOY FROM TO_DATE(EXTRACT(YEAR FROM A.INITIAL_DATE)::VARCHAR || '-12-31','YYYY-MM-DD')) = 366
--                                      THEN COALESCE(B.YEAR, C.YEAR)
--                                      ELSE COALESCE(B.LEAP_YEAR, C.LEAP_YEAR)
--                                 END,
--                                 A.INITIAL_DATE),
--             FINAL_DATE_LY   = TIMESTAMPADD(DAY, 
--                                 CASE WHEN EXTRACT(DOY FROM TO_DATE(EXTRACT(YEAR FROM A.FINAL_DATE)::VARCHAR || '-12-31','YYYY-MM-DD')) = 366
--                                      THEN COALESCE(B.YEAR, C.YEAR)
--                                      ELSE COALESCE(B.LEAP_YEAR, C.LEAP_YEAR)
--                                 END,
--                                 A.FINAL_DATE)
--         FROM OW_LAO.DIM_CAMPAIGN_NAME A
--         LEFT JOIN OW_LAO.DIM_CAMPAIGN_NAME_RULE B ON A.CAMPAIGN_TAG = B.CAMPAIGN_TAG
--         LEFT JOIN OW_LAO.DIM_CAMPAIGN_NAME_RULE C ON C.CAMPAIGN_TAG = 'ALL';
--     END;
-- 
--     ELSIF CONSULTA = 'EXEC_TMP_SALES_CAMPAIGN' THEN
--     BEGIN
--         -- Apaga da tabela de campanhas dados que não existem mais na control tower
--         PERFORM DELETE FROM OW_LAO.TMP_SALES_CAMPAIGN A
--         WHERE CAMPAIGN_TAG = CAMPAIGN_TAG
--           AND NOT EXISTS (
--                 SELECT 1
--                 FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE B
--                 WHERE A.ID = B.ID
--             );
-- 
--         -- Processo de período atual e anterior
--         PERFORM TRUNCATE TABLE OW_LAO.TMP_CAMPAIGN_NAME_PREVIOUS_YEAR;
-- 
--         PERFORM INSERT INTO OW_LAO.TMP_CAMPAIGN_NAME_PREVIOUS_YEAR
--         SELECT * FROM (
--             SELECT 
--                 CAMPAIGN_TAG, SUBSIDIARY, DIVISION, BIZ_TYPE, PO_DEVICETYPE, 
--                 INITIAL_DATE_LY,
--                 TIMESTAMPADD(DAY,
--                     DATEDIFF('day', INITIAL_DATE, CASE WHEN CURRENT_DATE >= FINAL_DATE THEN FINAL_DATE ELSE CURRENT_DATE END),
--                     INITIAL_DATE_LY) AS FINAL_DATE,
--                 PRODUCT, PRODUCT_GROUP, PO_SKU, ID_CAMPAIGN, AUDIENCE_TYPE,
--                 DATEDIFF('day', INITIAL_DATE, CASE WHEN CURRENT_DATE >= FINAL_DATE THEN FINAL_DATE ELSE CURRENT_DATE END) + 1 AS CAMPAIGN_DAY,
--                 TRUE AS PREVIOUS_YEAR
--             FROM OW_LAO.DIM_CAMPAIGN_NAME
--             UNION ALL
--             SELECT 
--                 CAMPAIGN_TAG, SUBSIDIARY, DIVISION, BIZ_TYPE, PO_DEVICETYPE, INITIAL_DATE, FINAL_DATE, PRODUCT, PRODUCT_GROUP, PO_SKU, ID_CAMPAIGN, AUDIENCE_TYPE,
--                 DATEDIFF('day', INITIAL_DATE, FINAL_DATE) + 1 AS CAMPAIGN_DAY,
--                 FALSE AS PREVIOUS_YEAR
--             FROM OW_LAO.DIM_CAMPAIGN_NAME
--         ) A
--         WHERE CAMPAIGN_TAG = CAMPAIGN_TAG;
-- 
--         -- Tabela temporária para atualização
--         PERFORM CREATE LOCAL TEMPORARY TABLE TMP_SALES_CAMPAIGN_UPDATE ON COMMIT PRESERVE ROWS AS (
--             SELECT DISTINCT 
--                 A.ID,
--                 CASE WHEN A.SUBSIDIARY LIKE 'SELA%' THEN 'SELA' ELSE A.SUBSIDIARY END AS SUBSIDIARY,
--                 A.PO_DATE,
--                 A.PODATE_MONTH,
--                 A.PODATE_YEAR,
--                 A.PO_ORDERID,
--                 A.PO_DEVICETYPE,
--                 A.PO_SKU,
--                 A.DIVISION,
--                 A.PRODUCT,
--                 A.PRODUCT_GROUP,
--                 A.PRODUCT_FAMILY,
--                 A.PO_STORENAME,
--                 A.BIZ_TYPE,
--                 A.AUDIENCE_TYPE,
--                 A.EBI_NETREVENUE,
--                 A.PO_TOTALPRICE_USD,
--                 A.NET_REVENUE,
--                 A.PO_QTY,
--                 DATEDIFF('day', B.INITIAL_DATE, A.PO_DATE) + 1 AS CAMPAIGN_DAY,
--                 B.CAMPAIGN_TAG,
--                 GREATEST(
--                     COALESCE(A.UPDATED_DATETIME, A.INSETED_DATETIME),
--                     COALESCE(A.EBI_LAST_UPDATE_DATE, A.INSETED_DATETIME),
--                     COALESCE(A.PO_LASTUPDATE_DATE_HOUR, A.INSETED_DATETIME),
--                     COALESCE(A.PO_SOURCE_LAST_UPDATE_DATE, A.INSETED_DATETIME),
--                     COALESCE(A.PO_SOURCE_PAYMENT_LAST_UPDATE_DATE, A.INSETED_DATETIME)
--                 ) AS DT_UPDATE,
--                 B.ID_CAMPAIGN,
--                 A.PO_STATUS,
--                 A.PRODUCT_CATEGORY,
--                 B.PREVIOUS_YEAR,
--                 ROW_NUMBER() OVER (
--                     PARTITION BY ID, CAMPAIGN_TAG
--                     ORDER BY ID
--                 ) AS DEDUP
--             FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A
--             JOIN OW_LAO.TMP_CAMPAIGN_NAME_PREVIOUS_YEAR B
--               ON A.PO_DATE BETWEEN B.INITIAL_DATE AND B.FINAL_DATE
--              AND (B.SUBSIDIARY IS NULL OR (CASE WHEN A.SUBSIDIARY LIKE 'SELA%' THEN 'SELA' ELSE A.SUBSIDIARY END) = B.SUBSIDIARY)
--              AND (B.DIVISION IS NULL OR A.DIVISION = B.DIVISION)
--              AND (B.BIZ_TYPE IS NULL OR A.BIZ_TYPE = B.BIZ_TYPE)
--              AND (B.PO_DEVICETYPE IS NULL OR A.PO_DEVICETYPE = B.PO_DEVICETYPE)
--              AND (B.PRODUCT IS NULL OR A.PRODUCT = B.PRODUCT)
--              AND (B.PRODUCT_GROUP IS NULL OR A.PRODUCT_GROUP = B.PRODUCT_GROUP)
--              AND (B.PO_SKU IS NULL OR A.PO_SKU = B.PO_SKU)
--              AND (B.AUDIENCE_TYPE IS NULL OR A.AUDIENCE_TYPE = B.AUDIENCE_TYPE)
--             WHERE B.CAMPAIGN_DAY >= 1
--               AND NOT EXISTS (
--                     SELECT 1
--                     FROM OW_LAO.TMP_SALES_CAMPAIGN C
--                     WHERE (A.ID = C.ID AND B.ID_CAMPAIGN = C.ID_CAMPAIGN)
--                       AND GREATEST(
--                             COALESCE(A.UPDATED_DATETIME, A.INSETED_DATETIME),
--                             COALESCE(A.EBI_LAST_UPDATE_DATE, A.INSETED_DATETIME),
--                             COALESCE(A.PO_LASTUPDATE_DATE_HOUR, A.INSETED_DATETIME),
--                             COALESCE(A.PO_SOURCE_LAST_UPDATE_DATE, A.INSETED_DATETIME),
--                             COALESCE(A.PO_SOURCE_PAYMENT_LAST_UPDATE_DATE, A.INSETED_DATETIME)
--                         ) = C.DT_UPDATE
--                 )
--         );
-- 
--         -- Merge de atualização
--         PERFORM MERGE INTO OW_LAO.TMP_SALES_CAMPAIGN A
--         USING TMP_SALES_CAMPAIGN_UPDATE B
--         ON A.ID = B.ID AND A.ID_CAMPAIGN = B.ID_CAMPAIGN
--         WHEN MATCHED THEN UPDATE SET
--             ID = B.ID,
--             SUBSIDIARY = B.SUBSIDIARY,
--             PO_DATE = B.PO_DATE,
--             PODATE_MONTH = B.PODATE_MONTH,
--             PODATE_YEAR = B.PODATE_YEAR,
--             PO_ORDERID = B.PO_ORDERID,
--             PO_DEVICETYPE = B.PO_DEVICETYPE,
--             PO_SKU = B.PO_SKU,
--             DIVISION = B.DIVISION,
--             PRODUCT = B.PRODUCT,
--             PRODUCT_GROUP = B.PRODUCT_GROUP,
--             PRODUCT_FAMILY = B.PRODUCT_FAMILY,
--             PO_STORENAME = B.PO_STORENAME,
--             BIZ_TYPE = B.BIZ_TYPE,
--             AUDIENCE_TYPE = B.AUDIENCE_TYPE,
--             EBI_NETREVENUE = B.EBI_NETREVENUE,
--             PO_TOTALPRICE_USD = B.PO_TOTALPRICE_USD,
--             NET_REVENUE = B.NET_REVENUE,
--             PO_QTY = B.PO_QTY,
--             CAMPAIGN_DAY = B.CAMPAIGN_DAY,
--             CAMPAIGN_TAG = B.CAMPAIGN_TAG,
--             DT_UPDATE = B.DT_UPDATE,
--             ID_CAMPAIGN = B.ID_CAMPAIGN,
--             PO_STATUS = B.PO_STATUS,
--             PRODUCT_CATEGORY = B.PRODUCT_CATEGORY,
--             PREVIOUS_YEAR = B.PREVIOUS_YEAR,
--             DEDUP = B.DEDUP
--         WHEN NOT MATCHED THEN INSERT (
--             ID, SUBSIDIARY, PO_DATE, PODATE_MONTH, PODATE_YEAR, PO_ORDERID, PO_DEVICETYPE, PO_SKU, DIVISION, PRODUCT, PRODUCT_GROUP, PRODUCT_FAMILY, PO_STORENAME,
--             BIZ_TYPE, AUDIENCE_TYPE, EBI_NETREVENUE, PO_TOTALPRICE_USD, NET_REVENUE, PO_QTY, CAMPAIGN_DAY, CAMPAIGN_TAG, DT_UPDATE, ID_CAMPAIGN, PO_STATUS,
--             PRODUCT_CATEGORY, PREVIOUS_YEAR, DEDUP
--         ) VALUES (
--             B.ID, B.SUBSIDIARY, B.PO_DATE, B.PODATE_MONTH, B.PODATE_YEAR, B.PO_ORDERID, B.PO_DEVICETYPE, B.PO_SKU, B.DIVISION, B.PRODUCT, B.PRODUCT_GROUP,
--             B.PRODUCT_FAMILY, B.PO_STORENAME, B.BIZ_TYPE, B.AUDIENCE_TYPE, B.EBI_NETREVENUE, B.PO_TOTALPRICE_USD, B.NET_REVENUE, B.PO_QTY, B.CAMPAIGN_DAY,
--             B.CAMPAIGN_TAG, B.DT_UPDATE, B.ID_CAMPAIGN, B.PO_STATUS, B.PRODUCT_CATEGORY, B.PREVIOUS_YEAR, B.DEDUP
--         );
-- 
--         PERFORM DROP TABLE IF EXISTS TMP_SALES_CAMPAIGN_UPDATE;
--     END;
-- 
--     ELSIF CONSULTA = 'EXEC_ODS_SALES_CAMPAIGN' THEN
--     BEGIN
--         -- Deleta dados de campanhas alteradas ou apagadas
--         PERFORM DELETE FROM OW_LAO.ODS_SALES_CAMPAIGN A
--         WHERE NOT EXISTS (
--             SELECT 1
--             FROM OW_LAO.TMP_SALES_CAMPAIGN B
--             WHERE A.ID = B.ID
--               AND A.ID_CAMPAIGN = B.ID_CAMPAIGN
--               AND A.DT_UPDATE = B.DT_UPDATE
--         );
-- 
--         -- Dados novos/atualizados para ODS
--         PERFORM CREATE LOCAL TEMPORARY TABLE ODS_SALES_CAMPAIGN_UPDATE ON COMMIT PRESERVE ROWS AS (
--             SELECT DISTINCT 
--                 A.ID,
--                 A.SUBSIDIARY,
--                 A.PO_DATE,
--                 A.PODATE_MONTH,
--                 A.PODATE_YEAR,
--                 A.PO_ORDERID,
--                 A.PO_DEVICETYPE,
--                 A.PO_SKU,
--                 A.DIVISION,
--                 A.PRODUCT,
--                 A.PRODUCT_GROUP,
--                 A.PRODUCT_FAMILY,
--                 A.PO_STORENAME,
--                 CASE WHEN A.PO_DEVICETYPE = 'MOBILEAPP' THEN 'APP' ELSE A.BIZ_TYPE END AS BIZ_TYPE,
--                 A.AUDIENCE_TYPE,
--                 A.EBI_NETREVENUE,
--                 A.PO_TOTALPRICE_USD,
--                 A.NET_REVENUE,
--                 A.PO_QTY,
--                 A.CAMPAIGN_DAY,
--                 A.CAMPAIGN_TAG,
--                 A.DT_UPDATE,
--                 A.PO_STATUS,
--                 A.PRODUCT_CATEGORY,
--                 A.PREVIOUS_YEAR,
--                 A.ID_CAMPAIGN
--             FROM OW_LAO.TMP_SALES_CAMPAIGN A
--             WHERE DEDUP = 1
--               AND NOT EXISTS (
--                     SELECT 1
--                     FROM OW_LAO.ODS_SALES_CAMPAIGN B
--                     WHERE A.ID = B.ID
--                       AND A.ID_CAMPAIGN = B.ID_CAMPAIGN
--                       AND A.DT_UPDATE = B.DT_UPDATE
--                 )
--         );
-- 
--         -- Merge para ODS
--         PERFORM MERGE INTO OW_LAO.ODS_SALES_CAMPAIGN A
--         USING ODS_SALES_CAMPAIGN_UPDATE B
--         ON A.ID = B.ID AND A.ID_CAMPAIGN = B.ID_CAMPAIGN
--         WHEN MATCHED THEN UPDATE SET
--             ID = B.ID,
--             SUBSIDIARY = B.SUBSIDIARY,
--             PO_DATE = B.PO_DATE,
--             PODATE_MONTH = B.PODATE_MONTH,
--             PODATE_YEAR = B.PODATE_YEAR,
--             PO_ORDERID = B.PO_ORDERID,
--             PO_DEVICETYPE = B.PO_DEVICETYPE,
--             PO_SKU = B.PO_SKU,
--             DIVISION = B.DIVISION,
--             PRODUCT = B.PRODUCT,
--             PRODUCT_GROUP = B.PRODUCT_GROUP,
--             PRODUCT_FAMILY = B.PRODUCT_FAMILY,
--             PO_STORENAME = B.PO_STORENAME,
--             BIZ_TYPE = B.BIZ_TYPE,
--             AUDIENCE_TYPE = B.AUDIENCE_TYPE,
--             EBI_NETREVENUE = B.EBI_NETREVENUE,
--             PO_TOTALPRICE_USD = B.PO_TOTALPRICE_USD,
--             NET_REVENUE = B.NET_REVENUE,
--             PO_QTY = B.PO_QTY,
--             CAMPAIGN_DAY = B.CAMPAIGN_DAY,
--             CAMPAIGN_TAG = B.CAMPAIGN_TAG,
--             DT_UPDATE = B.DT_UPDATE,
--             PO_STATUS = B.PO_STATUS,
--             PRODUCT_CATEGORY = B.PRODUCT_CATEGORY,
--             PREVIOUS_YEAR = B.PREVIOUS_YEAR,
--             ID_CAMPAIGN = B.ID_CAMPAIGN
--         WHEN NOT MATCHED THEN INSERT (
--             ID, SUBSIDIARY, PO_DATE, PODATE_MONTH, PODATE_YEAR, PO_ORDERID, PO_DEVICETYPE, PO_SKU, DIVISION, PRODUCT, PRODUCT_GROUP, PRODUCT_FAMILY,
--             PO_STORENAME, BIZ_TYPE, AUDIENCE_TYPE, EBI_NETREVENUE, PO_TOTALPRICE_USD, NET_REVENUE, PO_QTY, CAMPAIGN_DAY, CAMPAIGN_TAG, DT_UPDATE, PO_STATUS,
--             PRODUCT_CATEGORY, PREVIOUS_YEAR, ID_CAMPAIGN
--         ) VALUES (
--             B.ID, B.SUBSIDIARY, B.PO_DATE, B.PODATE_MONTH, B.PODATE_YEAR, B.PO_ORDERID, B.PO_DEVICETYPE, B.PO_SKU, B.DIVISION, B.PRODUCT, B.PRODUCT_GROUP,
--             B.PRODUCT_FAMILY, B.PO_STORENAME, B.BIZ_TYPE, B.AUDIENCE_TYPE, B.EBI_NETREVENUE, B.PO_TOTALPRICE_USD, B.NET_REVENUE, B.PO_QTY, B.CAMPAIGN_DAY,
--             B.CAMPAIGN_TAG, B.DT_UPDATE, B.PO_STATUS, B.PRODUCT_CATEGORY, B.PREVIOUS_YEAR, B.ID_CAMPAIGN
--         );
-- 
--         PERFORM DROP TABLE IF EXISTS ODS_SALES_CAMPAIGN_UPDATE;
--     END;
-- 
--     ELSE
--     BEGIN
--         NULL; -- No-op
--     END;
--     END IF;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: Syntax error at or near "A", Sqlstate: 42601, Position: 5584, Routine: base_yyerror, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/scan.l, Line: 1056, Error Code: 4856, 
-- CREATE OR REPLACE PROCEDURE OW_LAO.HOMOLOG_PROC_SALES_CAMPAIGN(
--     IN CONSULTA VARCHAR(40),
--     IN CAMPAIGN_TAG VARCHAR(400)
-- ) 
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--     IF CONSULTA = 'EXEC_UPDATE_CAMPAIGN_NAME' THEN
--     BEGIN
--         PERFORM TRUNCATE TABLE OW_LAO.TMP_UPDATE_CAMPAIGN_NAME;
-- 
--         PERFORM INSERT INTO OW_LAO.TMP_UPDATE_CAMPAIGN_NAME
--         SELECT ID_CAMPAIGN
--         FROM (
--             SELECT 
--                 A.CAMPAIGN_TAG,
--                 A.SUBSIDIARY,
--                 A.DIVISION,
--                 A.BIZ_TYPE,
--                 A.PO_DEVICETYPE,
--                 A.INITIAL_DATE,
--                 A.FINAL_DATE,
--                 A.PRODUCT,
--                 A.PRODUCT_GROUP,
--                 A.PO_SKU,
--                 A.ID_CAMPAIGN,
--                 B.CAMPAIGN_TAG AS TAG_DELETE
--             FROM OW_LAO.DIM_CAMPAIGN_NAME A
--             FULL OUTER JOIN OW_LAO.TMP_CAMPAIGN_NAME B
--               ON COALESCE(A.CAMPAIGN_TAG,'')              = COALESCE(B.CAMPAIGN_TAG,'')
--              AND COALESCE(A.SUBSIDIARY,'')               = COALESCE(B.SUBSIDIARY,'')
--              AND COALESCE(A.PO_DEVICETYPE,'')            = COALESCE(B.PO_DEVICETYPE,'')
--              AND COALESCE(TO_CHAR(A.INITIAL_DATE,'YYYY-MM-DD'),'') = COALESCE(TO_CHAR(B.INITIAL_DATE,'YYYY-MM-DD'),'')
--              AND COALESCE(TO_CHAR(A.FINAL_DATE,'YYYY-MM-DD'),'')   = COALESCE(TO_CHAR(B.FINAL_DATE,'YYYY-MM-DD'),'')
--              AND COALESCE(A.DIVISION,'')                 = COALESCE(B.DIVISION,'')
--              AND COALESCE(A.BIZ_TYPE,'')                 = COALESCE(B.BIZ_TYPE,'')
--              AND COALESCE(A.PRODUCT,'')                  = COALESCE(B.PRODUCT,'')
--              AND COALESCE(A.PRODUCT_GROUP,'')            = COALESCE(B.PRODUCT_GROUP,'')
--              AND COALESCE(A.PO_SKU,'')                   = COALESCE(B.PO_SKU,'')
--              AND COALESCE(A.AUDIENCE_TYPE,'')            = COALESCE(B.AUDIENCE_TYPE,'')
--             WHERE A.CAMPAIGN_TAG IS NOT NULL
--         ) AS TBL
--         WHERE TAG_DELETE IS NULL;
-- 
--         PERFORM DELETE FROM OW_LAO.TMP_SALES_CAMPAIGN 
--          WHERE ID_CAMPAIGN IN (SELECT ID_CAMPAIGN FROM OW_LAO.TMP_UPDATE_CAMPAIGN_NAME);
-- 
--         PERFORM DELETE FROM OW_LAO.DIM_CAMPAIGN_NAME 
--          WHERE ID_CAMPAIGN IN (SELECT ID_CAMPAIGN FROM OW_LAO.TMP_UPDATE_CAMPAIGN_NAME);
-- 
--         PERFORM INSERT INTO OW_LAO.DIM_CAMPAIGN_NAME(
--             CAMPAIGN_TAG,SUBSIDIARY,DIVISION,BIZ_TYPE,PO_DEVICETYPE,INITIAL_DATE,FINAL_DATE,PRODUCT,PRODUCT_GROUP,PO_SKU,AUDIENCE_TYPE)
--         SELECT 
--             B.CAMPAIGN_TAG,
--             B.SUBSIDIARY,
--             B.DIVISION,
--             B.BIZ_TYPE,
--             B.PO_DEVICETYPE,
--             B.INITIAL_DATE,
--             B.FINAL_DATE,
--             B.PRODUCT,
--             B.PRODUCT_GROUP,
--             B.PO_SKU,
--             B.AUDIENCE_TYPE
--         FROM OW_LAO.DIM_CAMPAIGN_NAME A
--         FULL OUTER JOIN OW_LAO.TMP_CAMPAIGN_NAME B
--           ON COALESCE(A.CAMPAIGN_TAG,'')              = COALESCE(B.CAMPAIGN_TAG,'')
--          AND COALESCE(A.SUBSIDIARY,'')               = COALESCE(B.SUBSIDIARY,'')
--          AND COALESCE(A.PO_DEVICETYPE,'')            = COALESCE(B.PO_DEVICETYPE,'')
--          AND COALESCE(TO_CHAR(A.INITIAL_DATE,'YYYY-MM-DD'),'') = COALESCE(TO_CHAR(B.INITIAL_DATE,'YYYY-MM-DD'),'')
--          AND COALESCE(TO_CHAR(A.FINAL_DATE,'YYYY-MM-DD'),'')   = COALESCE(TO_CHAR(B.FINAL_DATE,'YYYY-MM-DD'),'')
--          AND COALESCE(A.DIVISION,'')                 = COALESCE(B.DIVISION,'')
--          AND COALESCE(A.BIZ_TYPE,'')                 = COALESCE(B.BIZ_TYPE,'')
--          AND COALESCE(A.PRODUCT,'')                  = COALESCE(B.PRODUCT,'')
--          AND COALESCE(A.PRODUCT_GROUP,'')            = COALESCE(B.PRODUCT_GROUP,'')
--          AND COALESCE(A.PO_SKU,'')                   = COALESCE(B.PO_SKU,'')
--          AND COALESCE(A.AUDIENCE_TYPE,'')            = COALESCE(B.AUDIENCE_TYPE,'')
--         WHERE B.CAMPAIGN_TAG IS NOT NULL
--           AND A.ID_CAMPAIGN IS NULL;
-- 
--         PERFORM TRUNCATE TABLE OW_LAO.TMP_UPDATE_CAMPAIGN_NAME;
-- 
--         PERFORM UPDATE OW_LAO.DIM_CAMPAIGN_NAME A
--         SET
--             INITIAL_DATE_LY = TIMESTAMPADD(DAY, 
--                                 CASE WHEN EXTRACT(DOY FROM TO_DATE(EXTRACT(YEAR FROM A.INITIAL_DATE)::VARCHAR || '-12-31','YYYY-MM-DD')) = 366
--                                      THEN COALESCE(B.YEAR, C.YEAR)
--                                      ELSE COALESCE(B.LEAP_YEAR, C.LEAP_YEAR)
--                                 END,
--                                 A.INITIAL_DATE),
--             FINAL_DATE_LY   = TIMESTAMPADD(DAY, 
--                                 CASE WHEN EXTRACT(DOY FROM TO_DATE(EXTRACT(YEAR FROM A.FINAL_DATE)::VARCHAR || '-12-31','YYYY-MM-DD')) = 366
--                                      THEN COALESCE(B.YEAR, C.YEAR)
--                                      ELSE COALESCE(B.LEAP_YEAR, C.LEAP_YEAR)
--                                 END,
--                                 A.FINAL_DATE)
--         FROM OW_LAO.DIM_CAMPAIGN_NAME_RULE B
--         LEFT JOIN OW_LAO.DIM_CAMPAIGN_NAME_RULE C ON C.CAMPAIGN_TAG = 'ALL'
--         WHERE A.CAMPAIGN_TAG = B.CAMPAIGN_TAG;
--     END;
-- 
--     ELSIF CONSULTA = 'EXEC_TMP_SALES_CAMPAIGN' THEN
--     BEGIN
--         PERFORM DELETE FROM OW_LAO.TMP_SALES_CAMPAIGN A
--         WHERE A.CAMPAIGN_TAG = CAMPAIGN_TAG
--           AND NOT EXISTS (
--                 SELECT 1
--                 FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE B
--                 WHERE A.ID = B.ID
--             );
-- 
--         PERFORM TRUNCATE TABLE OW_LAO.TMP_CAMPAIGN_NAME_PREVIOUS_YEAR;
-- 
--         PERFORM INSERT INTO OW_LAO.TMP_CAMPAIGN_NAME_PREVIOUS_YEAR
--         SELECT * FROM (
--             SELECT 
--                 CAMPAIGN_TAG, SUBSIDIARY, DIVISION, BIZ_TYPE, PO_DEVICETYPE, 
--                 INITIAL_DATE_LY,
--                 TIMESTAMPADD(DAY,
--                     DATEDIFF('day', INITIAL_DATE, CASE WHEN CURRENT_DATE >= FINAL_DATE THEN FINAL_DATE ELSE CURRENT_DATE END),
--                     INITIAL_DATE_LY) AS FINAL_DATE,
--                 PRODUCT, PRODUCT_GROUP, PO_SKU, ID_CAMPAIGN, AUDIENCE_TYPE,
--                 DATEDIFF('day', INITIAL_DATE, CASE WHEN CURRENT_DATE >= FINAL_DATE THEN FINAL_DATE ELSE CURRENT_DATE END) + 1 AS CAMPAIGN_DAY,
--                 TRUE AS PREVIOUS_YEAR
--             FROM OW_LAO.DIM_CAMPAIGN_NAME
--             UNION ALL
--             SELECT 
--                 CAMPAIGN_TAG, SUBSIDIARY, DIVISION, BIZ_TYPE, PO_DEVICETYPE, INITIAL_DATE, FINAL_DATE, PRODUCT, PRODUCT_GROUP, PO_SKU, ID_CAMPAIGN, AUDIENCE_TYPE,
--                 DATEDIFF('day', INITIAL_DATE, FINAL_DATE) + 1 AS CAMPAIGN_DAY,
--                 FALSE AS PREVIOUS_YEAR
--             FROM OW_LAO.DIM_CAMPAIGN_NAME
--         ) A
--         WHERE A.CAMPAIGN_TAG = CAMPAIGN_TAG;
-- 
--         PERFORM CREATE LOCAL TEMPORARY TABLE TMP_SALES_CAMPAIGN_UPDATE ON COMMIT PRESERVE ROWS AS (
--             SELECT DISTINCT 
--                 A.ID,
--                 CASE WHEN A.SUBSIDIARY LIKE 'SELA%' THEN 'SELA' ELSE A.SUBSIDIARY END AS SUBSIDIARY,
--                 A.PO_DATE,
--                 A.PODATE_MONTH,
--                 A.PODATE_YEAR,
--                 A.PO_ORDERID,
--                 A.PO_DEVICETYPE,
--                 A.PO_SKU,
--                 A.DIVISION,
--                 A.PRODUCT,
--                 A.PRODUCT_GROUP,
--                 A.PRODUCT_FAMILY,
--                 A.PO_STORENAME,
--                 A.BIZ_TYPE,
--                 A.AUDIENCE_TYPE,
--                 A.EBI_NETREVENUE,
--                 A.PO_TOTALPRICE_USD,
--                 A.NET_REVENUE,
--                 A.PO_QTY,
--                 DATEDIFF('day', B.INITIAL_DATE, A.PO_DATE) + 1 AS CAMPAIGN_DAY,
--                 B.CAMPAIGN_TAG,
--                 GREATEST(
--                     COALESCE(A.UPDATED_DATETIME, A.INSETED_DATETIME),
--                     COALESCE(A.EBI_LAST_UPDATE_DATE, A.INSETED_DATETIME),
--                     COALESCE(A.PO_LASTUPDATE_DATE_HOUR, A.INSETED_DATETIME),
--                     COALESCE(A.PO_SOURCE_LAST_UPDATE_DATE, A.INSETED_DATETIME),
--                     COALESCE(A.PO_SOURCE_PAYMENT_LAST_UPDATE_DATE, A.INSETED_DATETIME)
--                 ) AS DT_UPDATE,
--                 B.ID_CAMPAIGN,
--                 A.PO_STATUS,
--                 A.PRODUCT_CATEGORY,
--                 B.PREVIOUS_YEAR,
--                 ROW_NUMBER() OVER (
--                     PARTITION BY ID, CAMPAIGN_TAG
--                     ORDER BY ID
--                 ) AS DEDUP
--             FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A
--             JOIN OW_LAO.TMP_CAMPAIGN_NAME_PREVIOUS_YEAR B
--               ON A.PO_DATE BETWEEN B.INITIAL_DATE AND B.FINAL_DATE
--              AND (B.SUBSIDIARY IS NULL OR (CASE WHEN A.SUBSIDIARY LIKE 'SELA%' THEN 'SELA' ELSE A.SUBSIDIARY END) = B.SUBSIDIARY)
--              AND (B.DIVISION IS NULL OR A.DIVISION = B.DIVISION)
--              AND (B.BIZ_TYPE IS NULL OR A.BIZ_TYPE = B.BIZ_TYPE)
--              AND (B.PO_DEVICETYPE IS NULL OR A.PO_DEVICETYPE = B.PO_DEVICETYPE)
--              AND (B.PRODUCT IS NULL OR A.PRODUCT = B.PRODUCT)
--              AND (B.PRODUCT_GROUP IS NULL OR A.PRODUCT_GROUP = B.PRODUCT_GROUP)
--              AND (B.PO_SKU IS NULL OR A.PO_SKU = B.PO_SKU)
--              AND (B.AUDIENCE_TYPE IS NULL OR A.AUDIENCE_TYPE = B.AUDIENCE_TYPE)
--             WHERE B.CAMPAIGN_DAY >= 1
--               AND NOT EXISTS (
--                     SELECT 1
--                     FROM OW_LAO.TMP_SALES_CAMPAIGN C
--                     WHERE (A.ID = C.ID AND B.ID_CAMPAIGN = C.ID_CAMPAIGN)
--                       AND GREATEST(
--                             COALESCE(A.UPDATED_DATETIME, A.INSETED_DATETIME),
--                             COALESCE(A.EBI_LAST_UPDATE_DATE, A.INSETED_DATETIME),
--                             COALESCE(A.PO_LASTUPDATE_DATE_HOUR, A.INSETED_DATETIME),
--                             COALESCE(A.PO_SOURCE_LAST_UPDATE_DATE, A.INSETED_DATETIME),
--                             COALESCE(A.PO_SOURCE_PAYMENT_LAST_UPDATE_DATE, A.INSETED_DATETIME)
--                         ) = C.DT_UPDATE
--                 )
--         );
-- 
--         PERFORM MERGE INTO OW_LAO.TMP_SALES_CAMPAIGN A
--         USING TMP_SALES_CAMPAIGN_UPDATE B
--         ON A.ID = B.ID AND A.ID_CAMPAIGN = B.ID_CAMPAIGN
--         WHEN MATCHED THEN UPDATE SET
--             ID = B.ID,
--             SUBSIDIARY = B.SUBSIDIARY,
--             PO_DATE = B.PO_DATE,
--             PODATE_MONTH = B.PODATE_MONTH,
--             PODATE_YEAR = B.PODATE_YEAR,
--             PO_ORDERID = B.PO_ORDERID,
--             PO_DEVICETYPE = B.PO_DEVICETYPE,
--             PO_SKU = B.PO_SKU,
--             DIVISION = B.DIVISION,
--             PRODUCT = B.PRODUCT,
--             PRODUCT_GROUP = B.PRODUCT_GROUP,
--             PRODUCT_FAMILY = B.PRODUCT_FAMILY,
--             PO_STORENAME = B.PO_STORENAME,
--             BIZ_TYPE = B.BIZ_TYPE,
--             AUDIENCE_TYPE = B.AUDIENCE_TYPE,
--             EBI_NETREVENUE = B.EBI_NETREVENUE,
--             PO_TOTALPRICE_USD = B.PO_TOTALPRICE_USD,
--             NET_REVENUE = B.NET_REVENUE,
--             PO_QTY = B.PO_QTY,
--             CAMPAIGN_DAY = B.CAMPAIGN_DAY,
--             CAMPAIGN_TAG = B.CAMPAIGN_TAG,
--             DT_UPDATE = B.DT_UPDATE,
--             ID_CAMPAIGN = B.ID_CAMPAIGN,
--             PO_STATUS = B.PO_STATUS,
--             PRODUCT_CATEGORY = B.PRODUCT_CATEGORY,
--             PREVIOUS_YEAR = B.PREVIOUS_YEAR,
--             DEDUP = B.DEDUP
--         WHEN NOT MATCHED THEN INSERT (
--             ID, SUBSIDIARY, PO_DATE, PODATE_MONTH, PODATE_YEAR, PO_ORDERID, PO_DEVICETYPE, PO_SKU, DIVISION, PRODUCT, PRODUCT_GROUP, PRODUCT_FAMILY, PO_STORENAME,
--             BIZ_TYPE, AUDIENCE_TYPE, EBI_NETREVENUE, PO_TOTALPRICE_USD, NET_REVENUE, PO_QTY, CAMPAIGN_DAY, CAMPAIGN_TAG, DT_UPDATE, ID_CAMPAIGN, PO_STATUS,
--             PRODUCT_CATEGORY, PREVIOUS_YEAR, DEDUP
--         ) VALUES (
--             B.ID, B.SUBSIDIARY, B.PO_DATE, B.PODATE_MONTH, B.PODATE_YEAR, B.PO_ORDERID, B.PO_DEVICETYPE, B.PO_SKU, B.DIVISION, B.PRODUCT, B.PRODUCT_GROUP,
--             B.PRODUCT_FAMILY, B.PO_STORENAME, B.BIZ_TYPE, B.AUDIENCE_TYPE, B.EBI_NETREVENUE, B.PO_TOTALPRICE_USD, B.NET_REVENUE, B.PO_QTY, B.CAMPAIGN_DAY,
--             B.CAMPAIGN_TAG, B.DT_UPDATE, B.ID_CAMPAIGN, B.PO_STATUS, B.PRODUCT_CATEGORY, B.PREVIOUS_YEAR, B.DEDUP
--         );
-- 
--         PERFORM DROP TABLE IF EXISTS TMP_SALES_CAMPAIGN_UPDATE;
--     END;
-- 
--     ELSIF CONSULTA = 'EXEC_ODS_SALES_CAMPAIGN' THEN
--     BEGIN
--         PERFORM DELETE FROM OW_LAO.ODS_SALES_CAMPAIGN A
--         WHERE NOT EXISTS (
--             SELECT 1
--             FROM OW_LAO.TMP_SALES_CAMPAIGN B
--             WHERE A.ID = B.ID
--               AND A.ID_CAMPAIGN = B.ID_CAMPAIGN
--               AND A.DT_UPDATE = B.DT_UPDATE
--         );
-- 
--         PERFORM CREATE LOCAL TEMPORARY TABLE ODS_SALES_CAMPAIGN_UPDATE ON COMMIT PRESERVE ROWS AS (
--             SELECT DISTINCT 
--                 A.ID,
--                 A.SUBSIDIARY,
--                 A.PO_DATE,
--                 A.PODATE_MONTH,
--                 A.PODATE_YEAR,
--                 A.PO_ORDERID,
--                 A.PO_DEVICETYPE,
--                 A.PO_SKU,
--                 A.DIVISION,
--                 A.PRODUCT,
--                 A.PRODUCT_GROUP,
--                 A.PRODUCT_FAMILY,
--                 A.PO_STORENAME,
--                 CASE WHEN A.PO_DEVICETYPE = 'MOBILEAPP' THEN 'APP' ELSE A.BIZ_TYPE END AS BIZ_TYPE,
--                 A.AUDIENCE_TYPE,
--                 A.EBI_NETREVENUE,
--                 A.PO_TOTALPRICE_USD,
--                 A.NET_REVENUE,
--                 A.PO_QTY,
--                 A.CAMPAIGN_DAY,
--                 A.CAMPAIGN_TAG,
--                 A.DT_UPDATE,
--                 A.PO_STATUS,
--                 A.PRODUCT_CATEGORY,
--                 A.PREVIOUS_YEAR,
--                 A.ID_CAMPAIGN 
--             FROM OW_LAO.TMP_SALES_CAMPAIGN A
--             WHERE DEDUP = 1  
--               AND NOT EXISTS (
--                     SELECT 1
--                     FROM OW_LAO.ODS_SALES_CAMPAIGN B
--                     WHERE A.ID = B.ID
--                       AND A.ID_CAMPAIGN = B.ID_CAMPAIGN
--                       AND A.DT_UPDATE = B.DT_UPDATE
--                 )
--         );
-- 
--         PERFORM MERGE INTO OW_LAO.ODS_SALES_CAMPAIGN A
--         USING ODS_SALES_CAMPAIGN_UPDATE B 
--         ON A.ID = B.ID AND A.ID_CAMPAIGN = B.ID_CAMPAIGN  
--         WHEN MATCHED THEN UPDATE SET 
--             ID = B.ID,
--             SUBSIDIARY = B.SUBSIDIARY,
--             PO_DATE = B.PO_DATE,
--             PODATE_MONTH = B.PODATE_MONTH,
--             PODATE_YEAR = B.PODATE_YEAR,
--             PO_ORDERID = B.PO_ORDERID,
--             PO_DEVICETYPE = B.PO_DEVICETYPE,
--             PO_SKU = B.PO_SKU,
--             DIVISION = B.DIVISION,
--             PRODUCT = B.PRODUCT,
--             PRODUCT_GROUP = B.PRODUCT_GROUP,
--             PRODUCT_FAMILY = B.PRODUCT_FAMILY,
--             PO_STORENAME = B.PO_STORENAME,
--             BIZ_TYPE = B.BIZ_TYPE,
--             AUDIENCE_TYPE = B.AUDIENCE_TYPE,
--             EBI_NETREVENUE = B.EBI_NETREVENUE,
--             PO_TOTALPRICE_USD = B.PO_TOTALPRICE_USD,
--             NET_REVENUE = B.NET_REVENUE,
--             PO_QTY = B.PO_QTY,
--             CAMPAIGN_DAY = B.CAMPAIGN_DAY,
--             CAMPAIGN_TAG = B.CAMPAIGN_TAG,
--             DT_UPDATE = B.DT_UPDATE,
--             PO_STATUS = B.PO_STATUS,
--             PRODUCT_CATEGORY = B.PRODUCT_CATEGORY,
--             PREVIOUS_YEAR = B.PREVIOUS_YEAR,
--             ID_CAMPAIGN = B.ID_CAMPAIGN 
--         WHEN NOT MATCHED THEN INSERT(
--             ID,
--             SUBSIDIARY,
--             PO_DATE,
--             PODATE_MONTH,
--             PODATE_YEAR,
--             PO_ORDERID,
--             PO_DEVICETYPE,
--             PO_SKU,
--             DIVISION,
--             PRODUCT,
--             PRODUCT_GROUP,
--             PRODUCT_FAMILY,
--             PO_STORENAME,
--             BIZ_TYPE,
--             AUDIENCE_TYPE,
--             EBI_NETREVENUE,
--             PO_TOTALPRICE_USD,
--             NET_REVENUE,
--             PO_QTY,
--             CAMPAIGN_DAY,
--             CAMPAIGN_TAG,
--             DT_UPDATE,
--             PO_STATUS,
--             PRODUCT_CATEGORY,
--             PREVIOUS_YEAR,
--             ID_CAMPAIGN 
--         )
--         VALUES(
--             B.ID,
--             B.SUBSIDIARY,
--             B.PO_DATE,
--             B.PODATE_MONTH,
--             B.PODATE_YEAR,
--             B.PO_ORDERID,
--             B.PO_DEVICETYPE,
--             B.PO_SKU,
--             B.DIVISION,
--             B.PRODUCT,
--             B.PRODUCT_GROUP,
--             B.PRODUCT_FAMILY,
--             B.PO_STORENAME,
--             B.BIZ_TYPE,
--             B.AUDIENCE_TYPE,
--             B.EBI_NETREVENUE,
--             B.PO_TOTALPRICE_USD,
--             B.NET_REVENUE,
--             B.PO_QTY,
--             B.CAMPAIGN_DAY,
--             B.CAMPAIGN_TAG,
--             B.DT_UPDATE,
--             B.PO_STATUS,
--             B.PRODUCT_CATEGORY,
--             B.PREVIOUS_YEAR,
--             B.ID_CAMPAIGN 
--         );
--         
--         PERFORM DROP TABLE IF EXISTS ODS_SALES_CAMPAIGN_UPDATE;
--     END;
-- 
--     ELSE
--     BEGIN
--         NULL;
--     END;
--     END IF;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: Syntax error at or near "A", Sqlstate: 42601, Position: 5149, Routine: base_yyerror, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/scan.l, Line: 1056, Error Code: 4856, 
-- CREATE OR REPLACE PROCEDURE OW_LAO.HOMOLOG_PROC_SALES_CAMPAIGN(
--     IN CONSULTA VARCHAR(40),
--     IN CAMPAIGN_TAG VARCHAR(400)
-- ) 
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--     IF CONSULTA = 'EXEC_UPDATE_CAMPAIGN_NAME' THEN
--     BEGIN
--         PERFORM TRUNCATE TABLE OW_LAO.TMP_UPDATE_CAMPAIGN_NAME;
-- 
--         PERFORM INSERT INTO OW_LAO.TMP_UPDATE_CAMPAIGN_NAME
--         SELECT ID_CAMPAIGN
--         FROM (
--             SELECT 
--                 A.CAMPAIGN_TAG,
--                 A.SUBSIDIARY,
--                 A.DIVISION,
--                 A.BIZ_TYPE,
--                 A.PO_DEVICETYPE,
--                 A.INITIAL_DATE,
--                 A.FINAL_DATE,
--                 A.PRODUCT,
--                 A.PRODUCT_GROUP,
--                 A.PO_SKU,
--                 A.ID_CAMPAIGN,
--                 B.CAMPAIGN_TAG AS TAG_DELETE
--             FROM OW_LAO.DIM_CAMPAIGN_NAME A
--             FULL OUTER JOIN OW_LAO.TMP_CAMPAIGN_NAME B
--               ON COALESCE(A.CAMPAIGN_TAG,'')              = COALESCE(B.CAMPAIGN_TAG,'')
--              AND COALESCE(A.SUBSIDIARY,'')               = COALESCE(B.SUBSIDIARY,'')
--              AND COALESCE(A.PO_DEVICETYPE,'')            = COALESCE(B.PO_DEVICETYPE,'')
--              AND COALESCE(TO_CHAR(A.INITIAL_DATE,'YYYY-MM-DD'),'') = COALESCE(TO_CHAR(B.INITIAL_DATE,'YYYY-MM-DD'),'')
--              AND COALESCE(TO_CHAR(A.FINAL_DATE,'YYYY-MM-DD'),'')   = COALESCE(TO_CHAR(B.FINAL_DATE,'YYYY-MM-DD'),'')
--              AND COALESCE(A.DIVISION,'')                 = COALESCE(B.DIVISION,'')
--              AND COALESCE(A.BIZ_TYPE,'')                 = COALESCE(B.BIZ_TYPE,'')
--              AND COALESCE(A.PRODUCT,'')                  = COALESCE(B.PRODUCT,'')
--              AND COALESCE(A.PRODUCT_GROUP,'')            = COALESCE(B.PRODUCT_GROUP,'')
--              AND COALESCE(A.PO_SKU,'')                   = COALESCE(B.PO_SKU,'')
--              AND COALESCE(A.AUDIENCE_TYPE,'')            = COALESCE(B.AUDIENCE_TYPE,'')
--             WHERE A.CAMPAIGN_TAG IS NOT NULL
--         ) AS TBL
--         WHERE TAG_DELETE IS NULL;
-- 
--         PERFORM DELETE FROM OW_LAO.TMP_SALES_CAMPAIGN 
--          WHERE ID_CAMPAIGN IN (SELECT ID_CAMPAIGN FROM OW_LAO.TMP_UPDATE_CAMPAIGN_NAME);
-- 
--         PERFORM DELETE FROM OW_LAO.DIM_CAMPAIGN_NAME 
--          WHERE ID_CAMPAIGN IN (SELECT ID_CAMPAIGN FROM OW_LAO.TMP_UPDATE_CAMPAIGN_NAME);
-- 
--         PERFORM INSERT INTO OW_LAO.DIM_CAMPAIGN_NAME(
--             CAMPAIGN_TAG,SUBSIDIARY,DIVISION,BIZ_TYPE,PO_DEVICETYPE,INITIAL_DATE,FINAL_DATE,PRODUCT,PRODUCT_GROUP,PO_SKU,AUDIENCE_TYPE)
--         SELECT 
--             B.CAMPAIGN_TAG,
--             B.SUBSIDIARY,
--             B.DIVISION,
--             B.BIZ_TYPE,
--             B.PO_DEVICETYPE,
--             B.INITIAL_DATE,
--             B.FINAL_DATE,
--             B.PRODUCT,
--             B.PRODUCT_GROUP,
--             B.PO_SKU,
--             B.AUDIENCE_TYPE
--         FROM OW_LAO.DIM_CAMPAIGN_NAME A
--         FULL OUTER JOIN OW_LAO.TMP_CAMPAIGN_NAME B
--           ON COALESCE(A.CAMPAIGN_TAG,'')              = COALESCE(B.CAMPAIGN_TAG,'')
--          AND COALESCE(A.SUBSIDIARY,'')               = COALESCE(B.SUBSIDIARY,'')
--          AND COALESCE(A.PO_DEVICETYPE,'')            = COALESCE(B.PO_DEVICETYPE,'')
--          AND COALESCE(TO_CHAR(A.INITIAL_DATE,'YYYY-MM-DD'),'') = COALESCE(TO_CHAR(B.INITIAL_DATE,'YYYY-MM-DD'),'')
--          AND COALESCE(TO_CHAR(A.FINAL_DATE,'YYYY-MM-DD'),'')   = COALESCE(TO_CHAR(B.FINAL_DATE,'YYYY-MM-DD'),'')
--          AND COALESCE(A.DIVISION,'')                 = COALESCE(B.DIVISION,'')
--          AND COALESCE(A.BIZ_TYPE,'')                 = COALESCE(B.BIZ_TYPE,'')
--          AND COALESCE(A.PRODUCT,'')                  = COALESCE(B.PRODUCT,'')
--          AND COALESCE(A.PRODUCT_GROUP,'')            = COALESCE(B.PRODUCT_GROUP,'')
--          AND COALESCE(A.PO_SKU,'')                   = COALESCE(B.PO_SKU,'')
--          AND COALESCE(A.AUDIENCE_TYPE,'')            = COALESCE(B.AUDIENCE_TYPE,'')
--         WHERE B.CAMPAIGN_TAG IS NOT NULL
--           AND A.ID_CAMPAIGN IS NULL;
-- 
--         PERFORM TRUNCATE TABLE OW_LAO.TMP_UPDATE_CAMPAIGN_NAME;
-- 
--         UPDATE OW_LAO.DIM_CAMPAIGN_NAME
--         SET
--             INITIAL_DATE_LY = TIMESTAMPADD(DAY, 
--                                 CASE WHEN EXTRACT(DOY FROM (DATE_TRUNC('year', OW_LAO.DIM_CAMPAIGN_NAME.INITIAL_DATE) + INTERVAL '1 year' - INTERVAL '1 day')) = 366
--                                      THEN COALESCE(B."YEAR", C."YEAR")
--                                      ELSE COALESCE(B."LEAP_YEAR", C."LEAP_YEAR")
--                                 END,
--                                 OW_LAO.DIM_CAMPAIGN_NAME.INITIAL_DATE),
--             FINAL_DATE_LY   = TIMESTAMPADD(DAY, 
--                                 CASE WHEN EXTRACT(DOY FROM (DATE_TRUNC('year', OW_LAO.DIM_CAMPAIGN_NAME.FINAL_DATE) + INTERVAL '1 year' - INTERVAL '1 day')) = 366
--                                      THEN COALESCE(B."YEAR", C."YEAR")
--                                      ELSE COALESCE(B."LEAP_YEAR", C."LEAP_YEAR")
--                                 END,
--                                 OW_LAO.DIM_CAMPAIGN_NAME.FINAL_DATE)
--         FROM OW_LAO.DIM_CAMPAIGN_NAME_RULE B
--         LEFT JOIN OW_LAO.DIM_CAMPAIGN_NAME_RULE C ON C.CAMPAIGN_TAG = 'ALL'
--         WHERE OW_LAO.DIM_CAMPAIGN_NAME.CAMPAIGN_TAG = B.CAMPAIGN_TAG;
--     END;
-- 
--     ELSIF CONSULTA = 'EXEC_TMP_SALES_CAMPAIGN' THEN
--     BEGIN
--         PERFORM DELETE FROM OW_LAO.TMP_SALES_CAMPAIGN A
--         WHERE A.CAMPAIGN_TAG = CAMPAIGN_TAG
--           AND NOT EXISTS (
--                 SELECT 1
--                 FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE B
--                 WHERE A.ID = B.ID
--             );
-- 
--         PERFORM TRUNCATE TABLE OW_LAO.TMP_CAMPAIGN_NAME_PREVIOUS_YEAR;
-- 
--         PERFORM INSERT INTO OW_LAO.TMP_CAMPAIGN_NAME_PREVIOUS_YEAR
--         SELECT * FROM (
--             SELECT 
--                 CAMPAIGN_TAG, SUBSIDIARY, DIVISION, BIZ_TYPE, PO_DEVICETYPE, 
--                 INITIAL_DATE_LY,
--                 TIMESTAMPADD(DAY,
--                     DATEDIFF('day', INITIAL_DATE, CASE WHEN CURRENT_DATE >= FINAL_DATE THEN FINAL_DATE ELSE CURRENT_DATE END),
--                     INITIAL_DATE_LY) AS FINAL_DATE,
--                 PRODUCT, PRODUCT_GROUP, PO_SKU, ID_CAMPAIGN, AUDIENCE_TYPE,
--                 DATEDIFF('day', INITIAL_DATE, CASE WHEN CURRENT_DATE >= FINAL_DATE THEN FINAL_DATE ELSE CURRENT_DATE END) + 1 AS CAMPAIGN_DAY,
--                 TRUE AS PREVIOUS_YEAR
--             FROM OW_LAO.DIM_CAMPAIGN_NAME
--             UNION ALL
--             SELECT 
--                 CAMPAIGN_TAG, SUBSIDIARY, DIVISION, BIZ_TYPE, PO_DEVICETYPE, INITIAL_DATE, FINAL_DATE, PRODUCT, PRODUCT_GROUP, PO_SKU, ID_CAMPAIGN, AUDIENCE_TYPE,
--                 DATEDIFF('day', INITIAL_DATE, FINAL_DATE) + 1 AS CAMPAIGN_DAY,
--                 FALSE AS PREVIOUS_YEAR
--             FROM OW_LAO.DIM_CAMPAIGN_NAME
--         ) A
--         WHERE A.CAMPAIGN_TAG = CAMPAIGN_TAG;
-- 
--         PERFORM CREATE LOCAL TEMPORARY TABLE TMP_SALES_CAMPAIGN_UPDATE ON COMMIT PRESERVE ROWS AS (
--             SELECT DISTINCT 
--                 A.ID,
--                 CASE WHEN A.SUBSIDIARY LIKE 'SELA%' THEN 'SELA' ELSE A.SUBSIDIARY END AS SUBSIDIARY,
--                 A.PO_DATE,
--                 A.PODATE_MONTH,
--                 A.PODATE_YEAR,
--                 A.PO_ORDERID,
--                 A.PO_DEVICETYPE,
--                 A.PO_SKU,
--                 A.DIVISION,
--                 A.PRODUCT,
--                 A.PRODUCT_GROUP,
--                 A.PRODUCT_FAMILY,
--                 A.PO_STORENAME,
--                 A.BIZ_TYPE,
--                 A.AUDIENCE_TYPE,
--                 A.EBI_NETREVENUE,
--                 A.PO_TOTALPRICE_USD,
--                 A.NET_REVENUE,
--                 A.PO_QTY,
--                 DATEDIFF('day', B.INITIAL_DATE, A.PO_DATE) + 1 AS CAMPAIGN_DAY,
--                 B.CAMPAIGN_TAG,
--                 GREATEST(
--                     COALESCE(A.UPDATED_DATETIME, A.INSETED_DATETIME),
--                     COALESCE(A.EBI_LAST_UPDATE_DATE, A.INSETED_DATETIME),
--                     COALESCE(A.PO_LASTUPDATE_DATE_HOUR, A.INSETED_DATETIME),
--                     COALESCE(A.PO_SOURCE_LAST_UPDATE_DATE, A.INSETED_DATETIME),
--                     COALESCE(A.PO_SOURCE_PAYMENT_LAST_UPDATE_DATE, A.INSETED_DATETIME)
--                 ) AS DT_UPDATE,
--                 B.ID_CAMPAIGN,
--                 A.PO_STATUS,
--                 A.PRODUCT_CATEGORY,
--                 B.PREVIOUS_YEAR,
--                 ROW_NUMBER() OVER (
--                     PARTITION BY ID, CAMPAIGN_TAG
--                     ORDER BY ID
--                 ) AS DEDUP
--             FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A
--             JOIN OW_LAO.TMP_CAMPAIGN_NAME_PREVIOUS_YEAR B
--               ON A.PO_DATE BETWEEN B.INITIAL_DATE AND B.FINAL_DATE
--              AND (B.SUBSIDIARY IS NULL OR (CASE WHEN A.SUBSIDIARY LIKE 'SELA%' THEN 'SELA' ELSE A.SUBSIDIARY END) = B.SUBSIDIARY)
--              AND (B.DIVISION IS NULL OR A.DIVISION = B.DIVISION)
--              AND (B.BIZ_TYPE IS NULL OR A.BIZ_TYPE = B.BIZ_TYPE)
--              AND (B.PO_DEVICETYPE IS NULL OR A.PO_DEVICETYPE = B.PO_DEVICETYPE)
--              AND (B.PRODUCT IS NULL OR A.PRODUCT = B.PRODUCT)
--              AND (B.PRODUCT_GROUP IS NULL OR A.PRODUCT_GROUP = B.PRODUCT_GROUP)
--              AND (B.PO_SKU IS NULL OR A.PO_SKU = B.PO_SKU)
--              AND (B.AUDIENCE_TYPE IS NULL OR A.AUDIENCE_TYPE = B.AUDIENCE_TYPE)
--             WHERE B.CAMPAIGN_DAY >= 1
--               AND NOT EXISTS (
--                     SELECT 1
--                     FROM OW_LAO.TMP_SALES_CAMPAIGN C
--                     WHERE (A.ID = C.ID AND B.ID_CAMPAIGN = C.ID_CAMPAIGN)
--                       AND GREATEST(
--                             COALESCE(A.UPDATED_DATETIME, A.INSETED_DATETIME),
--                             COALESCE(A.EBI_LAST_UPDATE_DATE, A.INSETED_DATETIME),
--                             COALESCE(A.PO_LASTUPDATE_DATE_HOUR, A.INSETED_DATETIME),
--                             COALESCE(A.PO_SOURCE_LAST_UPDATE_DATE, A.INSETED_DATETIME),
--                             COALESCE(A.PO_SOURCE_PAYMENT_LAST_UPDATE_DATE, A.INSETED_DATETIME)
--                         ) = C.DT_UPDATE
--                 )
--         );
-- 
--         MERGE INTO OW_LAO.TMP_SALES_CAMPAIGN A
--         USING TMP_SALES_CAMPAIGN_UPDATE B
--         ON A.ID = B.ID AND A.ID_CAMPAIGN = B.ID_CAMPAIGN
--         WHEN MATCHED THEN UPDATE SET
--             ID = B.ID,
--             SUBSIDIARY = B.SUBSIDIARY,
--             PO_DATE = B.PO_DATE,
--             PODATE_MONTH = B.PODATE_MONTH,
--             PODATE_YEAR = B.PODATE_YEAR,
--             PO_ORDERID = B.PO_ORDERID,
--             PO_DEVICETYPE = B.PO_DEVICETYPE,
--             PO_SKU = B.PO_SKU,
--             DIVISION = B.DIVISION,
--             PRODUCT = B.PRODUCT,
--             PRODUCT_GROUP = B.PRODUCT_GROUP,
--             PRODUCT_FAMILY = B.PRODUCT_FAMILY,
--             PO_STORENAME = B.PO_STORENAME,
--             BIZ_TYPE = B.BIZ_TYPE,
--             AUDIENCE_TYPE = B.AUDIENCE_TYPE,
--             EBI_NETREVENUE = B.EBI_NETREVENUE,
--             PO_TOTALPRICE_USD = B.PO_TOTALPRICE_USD,
--             NET_REVENUE = B.NET_REVENUE,
--             PO_QTY = B.PO_QTY,
--             CAMPAIGN_DAY = B.CAMPAIGN_DAY,
--             CAMPAIGN_TAG = B.CAMPAIGN_TAG,
--             DT_UPDATE = B.DT_UPDATE,
--             ID_CAMPAIGN = B.ID_CAMPAIGN,
--             PO_STATUS = B.PO_STATUS,
--             PRODUCT_CATEGORY = B.PRODUCT_CATEGORY,
--             PREVIOUS_YEAR = B.PREVIOUS_YEAR,
--             DEDUP = B.DEDUP
--         WHEN NOT MATCHED THEN INSERT (
--             ID, SUBSIDIARY, PO_DATE, PODATE_MONTH, PODATE_YEAR, PO_ORDERID, PO_DEVICETYPE, PO_SKU, DIVISION, PRODUCT, PRODUCT_GROUP, PRODUCT_FAMILY, PO_STORENAME,
--             BIZ_TYPE, AUDIENCE_TYPE, EBI_NETREVENUE, PO_TOTALPRICE_USD, NET_REVENUE, PO_QTY, CAMPAIGN_DAY, CAMPAIGN_TAG, DT_UPDATE, ID_CAMPAIGN, PO_STATUS,
--             PRODUCT_CATEGORY, PREVIOUS_YEAR, DEDUP
--         ) VALUES (
--             B.ID, B.SUBSIDIARY, B.PO_DATE, B.PODATE_MONTH, B.PODATE_YEAR, B.PO_ORDERID, B.PO_DEVICETYPE, B.PO_SKU, B.DIVISION, B.PRODUCT, B.PRODUCT_GROUP,
--             B.PRODUCT_FAMILY, B.PO_STORENAME, B.BIZ_TYPE, B.AUDIENCE_TYPE, B.EBI_NETREVENUE, B.PO_TOTALPRICE_USD, B.NET_REVENUE, B.PO_QTY, B.CAMPAIGN_DAY,
--             B.CAMPAIGN_TAG, B.DT_UPDATE, B.ID_CAMPAIGN, B.PO_STATUS, B.PRODUCT_CATEGORY, B.PREVIOUS_YEAR, B.DEDUP
--         );
-- 
--         PERFORM DROP TABLE IF EXISTS TMP_SALES_CAMPAIGN_UPDATE;
--     END;
-- 
--     ELSIF CONSULTA = 'EXEC_ODS_SALES_CAMPAIGN' THEN
--     BEGIN
--         PERFORM DELETE FROM OW_LAO.ODS_SALES_CAMPAIGN A
--         WHERE NOT EXISTS (
--             SELECT 1
--             FROM OW_LAO.TMP_SALES_CAMPAIGN B
--             WHERE A.ID = B.ID
--               AND A.ID_CAMPAIGN = B.ID_CAMPAIGN
--               AND A.DT_UPDATE = B.DT_UPDATE
--         );
-- 
--         PERFORM CREATE LOCAL TEMPORARY TABLE ODS_SALES_CAMPAIGN_UPDATE ON COMMIT PRESERVE ROWS AS (
--             SELECT DISTINCT 
--                 A.ID,
--                 A.SUBSIDIARY,
--                 A.PO_DATE,
--                 A.PODATE_MONTH,
--                 A.PODATE_YEAR,
--                 A.PO_ORDERID,
--                 A.PO_DEVICETYPE,
--                 A.PO_SKU,
--                 A.DIVISION,
--                 A.PRODUCT,
--                 A.PRODUCT_GROUP,
--                 A.PRODUCT_FAMILY,
--                 A.PO_STORENAME,
--                 CASE WHEN A.PO_DEVICETYPE = 'MOBILEAPP' THEN 'APP' ELSE A.BIZ_TYPE END AS BIZ_TYPE,
--                 A.AUDIENCE_TYPE,
--                 A.EBI_NETREVENUE,
--                 A.PO_TOTALPRICE_USD,
--                 A.NET_REVENUE,
--                 A.PO_QTY,
--                 A.CAMPAIGN_DAY,
--                 A.CAMPAIGN_TAG,
--                 A.DT_UPDATE,
--                 A.PO_STATUS,
--                 A.PRODUCT_CATEGORY,
--                 A.PREVIOUS_YEAR,
--                 A.ID_CAMPAIGN 
--             FROM OW_LAO.TMP_SALES_CAMPAIGN A
--             WHERE DEDUP = 1  
--               AND NOT EXISTS (
--                     SELECT 1
--                     FROM OW_LAO.ODS_SALES_CAMPAIGN B
--                     WHERE A.ID = B.ID
--                       AND A.ID_CAMPAIGN = B.ID_CAMPAIGN
--                       AND A.DT_UPDATE = B.DT_UPDATE
--                 )
--         );
-- 
--         MERGE INTO OW_LAO.ODS_SALES_CAMPAIGN A
--         USING ODS_SALES_CAMPAIGN_UPDATE B 
--         ON A.ID = B.ID AND A.ID_CAMPAIGN = B.ID_CAMPAIGN  
--         WHEN MATCHED THEN UPDATE SET 
--             ID = B.ID,
--             SUBSIDIARY = B.SUBSIDIARY,
--             PO_DATE = B.PO_DATE,
--             PODATE_MONTH = B.PODATE_MONTH,
--             PODATE_YEAR = B.PODATE_YEAR,
--             PO_ORDERID = B.PO_ORDERID,
--             PO_DEVICETYPE = B.PO_DEVICETYPE,
--             PO_SKU = B.PO_SKU,
--             DIVISION = B.DIVISION,
--             PRODUCT = B.PRODUCT,
--             PRODUCT_GROUP = B.PRODUCT_GROUP,
--             PRODUCT_FAMILY = B.PRODUCT_FAMILY,
--             PO_STORENAME = B.PO_STORENAME,
--             BIZ_TYPE = B.BIZ_TYPE,
--             AUDIENCE_TYPE = B.AUDIENCE_TYPE,
--             EBI_NETREVENUE = B.EBI_NETREVENUE,
--             PO_TOTALPRICE_USD = B.PO_TOTALPRICE_USD,
--             NET_REVENUE = B.NET_REVENUE,
--             PO_QTY = B.PO_QTY,
--             CAMPAIGN_DAY = B.CAMPAIGN_DAY,
--             CAMPAIGN_TAG = B.CAMPAIGN_TAG,
--             DT_UPDATE = B.DT_UPDATE,
--             PO_STATUS = B.PO_STATUS,
--             PRODUCT_CATEGORY = B.PRODUCT_CATEGORY,
--             PREVIOUS_YEAR = B.PREVIOUS_YEAR,
--             ID_CAMPAIGN = B.ID_CAMPAIGN 
--         WHEN NOT MATCHED THEN INSERT(
--             ID,
--             SUBSIDIARY,
--             PO_DATE,
--             PODATE_MONTH,
--             PODATE_YEAR,
--             PO_ORDERID,
--             PO_DEVICETYPE,
--             PO_SKU,
--             DIVISION,
--             PRODUCT,
--             PRODUCT_GROUP,
--             PRODUCT_FAMILY,
--             PO_STORENAME,
--             BIZ_TYPE,
--             AUDIENCE_TYPE,
--             EBI_NETREVENUE,
--             PO_TOTALPRICE_USD,
--             NET_REVENUE,
--             PO_QTY,
--             CAMPAIGN_DAY,
--             CAMPAIGN_TAG,
--             DT_UPDATE,
--             PO_STATUS,
--             PRODUCT_CATEGORY,
--             PREVIOUS_YEAR,
--             ID_CAMPAIGN 
--         )
--         VALUES(
--             B.ID,
--             B.SUBSIDIARY,
--             B.PO_DATE,
--             B.PODATE_MONTH,
--             B.PODATE_YEAR,
--             B.PO_ORDERID,
--             B.PO_DEVICETYPE,
--             B.PO_SKU,
--             B.DIVISION,
--             B.PRODUCT,
--             B.PRODUCT_GROUP,
--             B.PRODUCT_FAMILY,
--             B.PO_STORENAME,
--             B.BIZ_TYPE,
--             B.AUDIENCE_TYPE,
--             B.EBI_NETREVENUE,
--             B.PO_TOTALPRICE_USD,
--             B.NET_REVENUE,
--             B.PO_QTY,
--             B.CAMPAIGN_DAY,
--             B.CAMPAIGN_TAG,
--             B.DT_UPDATE,
--             B.PO_STATUS,
--             B.PRODUCT_CATEGORY,
--             B.PREVIOUS_YEAR,
--             B.ID_CAMPAIGN 
--         );
--         
--         PERFORM DROP TABLE IF EXISTS ODS_SALES_CAMPAIGN_UPDATE;
--     END;
-- 
--     ELSE
--     BEGIN
--         NULL;
--     END;
--     END IF;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 94.69 of source string: syntax error, unexpected ;, expecting INTO, Sqlstate: 42601, Position: 5140, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
-- CREATE OR REPLACE PROCEDURE OW_LAO.HOMOLOG_PROC_SALES_CAMPAIGN(
--     IN CONSULTA VARCHAR(40),
--     IN CAMPAIGN_TAG VARCHAR(400)
-- )
-- LANGUAGE PLvSQL AS $$
-- DECLARE
--     v_consulta VARCHAR(40) := CONSULTA;
--     v_campaign_tag VARCHAR(400) := CAMPAIGN_TAG;
-- BEGIN
--     IF v_consulta = 'EXEC_UPDATE_CAMPAIGN_NAME' THEN
--         PERFORM TRUNCATE TABLE OW_LAO.TMP_UPDATE_CAMPAIGN_NAME;
-- 
--         PERFORM INSERT INTO OW_LAO.TMP_UPDATE_CAMPAIGN_NAME
--         SELECT ID_CAMPAIGN
--         FROM (
--             SELECT 
--                 A.CAMPAIGN_TAG,
--                 A.SUBSIDIARY,
--                 A.DIVISION,
--                 A.BIZ_TYPE,
--                 A.PO_DEVICETYPE,
--                 A.INITIAL_DATE,
--                 A.FINAL_DATE,
--                 A.PRODUCT,
--                 A.PRODUCT_GROUP,
--                 A.PO_SKU,
--                 A.ID_CAMPAIGN,
--                 B.CAMPAIGN_TAG AS TAG_DELETE
--             FROM OW_LAO.DIM_CAMPAIGN_NAME A
--             FULL OUTER JOIN OW_LAO.TMP_CAMPAIGN_NAME B
--               ON COALESCE(A.CAMPAIGN_TAG,'')              = COALESCE(B.CAMPAIGN_TAG,'')
--              AND COALESCE(A.SUBSIDIARY,'')               = COALESCE(B.SUBSIDIARY,'')
--              AND COALESCE(A.PO_DEVICETYPE,'')            = COALESCE(B.PO_DEVICETYPE,'')
--              AND COALESCE(TO_CHAR(A.INITIAL_DATE,'YYYY-MM-DD'),'') = COALESCE(TO_CHAR(B.INITIAL_DATE,'YYYY-MM-DD'),'')
--              AND COALESCE(TO_CHAR(A.FINAL_DATE,'YYYY-MM-DD'),'')   = COALESCE(TO_CHAR(B.FINAL_DATE,'YYYY-MM-DD'),'')
--              AND COALESCE(A.DIVISION,'')                 = COALESCE(B.DIVISION,'')
--              AND COALESCE(A.BIZ_TYPE,'')                 = COALESCE(B.BIZ_TYPE,'')
--              AND COALESCE(A.PRODUCT,'')                  = COALESCE(B.PRODUCT,'')
--              AND COALESCE(A.PRODUCT_GROUP,'')            = COALESCE(B.PRODUCT_GROUP,'')
--              AND COALESCE(A.PO_SKU,'')                   = COALESCE(B.PO_SKU,'')
--              AND COALESCE(A.AUDIENCE_TYPE,'')            = COALESCE(B.AUDIENCE_TYPE,'')
--             WHERE A.CAMPAIGN_TAG IS NOT NULL
--         ) AS TBL
--         WHERE TAG_DELETE IS NULL;
-- 
--         PERFORM DELETE FROM OW_LAO.TMP_SALES_CAMPAIGN 
--          WHERE ID_CAMPAIGN IN (SELECT ID_CAMPAIGN FROM OW_LAO.TMP_UPDATE_CAMPAIGN_NAME);
-- 
--         PERFORM DELETE FROM OW_LAO.DIM_CAMPAIGN_NAME 
--          WHERE ID_CAMPAIGN IN (SELECT ID_CAMPAIGN FROM OW_LAO.TMP_UPDATE_CAMPAIGN_NAME);
-- 
--         PERFORM INSERT INTO OW_LAO.DIM_CAMPAIGN_NAME(
--             CAMPAIGN_TAG,SUBSIDIARY,DIVISION,BIZ_TYPE,PO_DEVICETYPE,INITIAL_DATE,FINAL_DATE,PRODUCT,PRODUCT_GROUP,PO_SKU,AUDIENCE_TYPE)
--         SELECT 
--             B.CAMPAIGN_TAG,
--             B.SUBSIDIARY,
--             B.DIVISION,
--             B.BIZ_TYPE,
--             B.PO_DEVICETYPE,
--             B.INITIAL_DATE,
--             B.FINAL_DATE,
--             B.PRODUCT,
--             B.PRODUCT_GROUP,
--             B.PO_SKU,
--             B.AUDIENCE_TYPE
--         FROM OW_LAO.DIM_CAMPAIGN_NAME A
--         FULL OUTER JOIN OW_LAO.TMP_CAMPAIGN_NAME B
--           ON COALESCE(A.CAMPAIGN_TAG,'')              = COALESCE(B.CAMPAIGN_TAG,'')
--          AND COALESCE(A.SUBSIDIARY,'')               = COALESCE(B.SUBSIDIARY,'')
--          AND COALESCE(A.PO_DEVICETYPE,'')            = COALESCE(B.PO_DEVICETYPE,'')
--          AND COALESCE(TO_CHAR(A.INITIAL_DATE,'YYYY-MM-DD'),'') = COALESCE(TO_CHAR(B.INITIAL_DATE,'YYYY-MM-DD'),'')
--          AND COALESCE(TO_CHAR(A.FINAL_DATE,'YYYY-MM-DD'),'')   = COALESCE(TO_CHAR(B.FINAL_DATE,'YYYY-MM-DD'),'')
--          AND COALESCE(A.DIVISION,'')                 = COALESCE(B.DIVISION,'')
--          AND COALESCE(A.BIZ_TYPE,'')                 = COALESCE(B.BIZ_TYPE,'')
--          AND COALESCE(A.PRODUCT,'')                  = COALESCE(B.PRODUCT,'')
--          AND COALESCE(A.PRODUCT_GROUP,'')            = COALESCE(B.PRODUCT_GROUP,'')
--          AND COALESCE(A.PO_SKU,'')                   = COALESCE(B.PO_SKU,'')
--          AND COALESCE(A.AUDIENCE_TYPE,'')            = COALESCE(B.AUDIENCE_TYPE,'')
--         WHERE B.CAMPAIGN_TAG IS NOT NULL
--           AND A.ID_CAMPAIGN IS NULL;
-- 
--         PERFORM TRUNCATE TABLE OW_LAO.TMP_UPDATE_CAMPAIGN_NAME;
-- 
--         PERFORM UPDATE OW_LAO.DIM_CAMPAIGN_NAME dcn
--         SET
--             INITIAL_DATE_LY = TIMESTAMPADD(DAY, 
--                                 CASE WHEN EXTRACT(DOY FROM (DATE_TRUNC('year', dcn.INITIAL_DATE) + INTERVAL '1 year' - INTERVAL '1 day')) = 366
--                                      THEN COALESCE(rule_tag."YEAR", rule_all."YEAR")
--                                      ELSE COALESCE(rule_tag."LEAP_YEAR", rule_all."LEAP_YEAR")
--                                 END,
--                                 dcn.INITIAL_DATE),
--             FINAL_DATE_LY   = TIMESTAMPADD(DAY, 
--                                 CASE WHEN EXTRACT(DOY FROM (DATE_TRUNC('year', dcn.FINAL_DATE) + INTERVAL '1 year' - INTERVAL '1 day')) = 366
--                                      THEN COALESCE(rule_tag."YEAR", rule_all."YEAR")
--                                      ELSE COALESCE(rule_tag."LEAP_YEAR", rule_all."LEAP_YEAR")
--                                 END,
--                                 dcn.FINAL_DATE)
--         FROM OW_LAO.DIM_CAMPAIGN_NAME_RULE rule_tag
--         LEFT JOIN OW_LAO.DIM_CAMPAIGN_NAME_RULE rule_all ON rule_all.CAMPAIGN_TAG = 'ALL'
--         WHERE dcn.CAMPAIGN_TAG = rule_tag.CAMPAIGN_TAG;
-- 
--     ELSIF v_consulta = 'EXEC_TMP_SALES_CAMPAIGN' THEN
--         PERFORM DELETE FROM OW_LAO.TMP_SALES_CAMPAIGN A
--         WHERE A.CAMPAIGN_TAG = v_campaign_tag
--           AND NOT EXISTS (
--                 SELECT 1
--                 FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE B
--                 WHERE A.ID = B.ID
--             );
-- 
--         PERFORM TRUNCATE TABLE OW_LAO.TMP_CAMPAIGN_NAME_PREVIOUS_YEAR;
-- 
--         PERFORM INSERT INTO OW_LAO.TMP_CAMPAIGN_NAME_PREVIOUS_YEAR
--         SELECT * FROM (
--             SELECT 
--                 CAMPAIGN_TAG, SUBSIDIARY, DIVISION, BIZ_TYPE, PO_DEVICETYPE, 
--                 INITIAL_DATE_LY,
--                 TIMESTAMPADD(DAY,
--                     DATEDIFF('day', INITIAL_DATE, CASE WHEN CURRENT_DATE >= FINAL_DATE THEN FINAL_DATE ELSE CURRENT_DATE END),
--                     INITIAL_DATE_LY) AS FINAL_DATE,
--                 PRODUCT, PRODUCT_GROUP, PO_SKU, ID_CAMPAIGN, AUDIENCE_TYPE,
--                 DATEDIFF('day', INITIAL_DATE, CASE WHEN CURRENT_DATE >= FINAL_DATE THEN FINAL_DATE ELSE CURRENT_DATE END) + 1 AS CAMPAIGN_DAY,
--                 TRUE AS PREVIOUS_YEAR
--             FROM OW_LAO.DIM_CAMPAIGN_NAME
--             UNION ALL
--             SELECT 
--                 CAMPAIGN_TAG, SUBSIDIARY, DIVISION, BIZ_TYPE, PO_DEVICETYPE, INITIAL_DATE, FINAL_DATE, PRODUCT, PRODUCT_GROUP, PO_SKU, ID_CAMPAIGN, AUDIENCE_TYPE,
--                 DATEDIFF('day', INITIAL_DATE, FINAL_DATE) + 1 AS CAMPAIGN_DAY,
--                 FALSE AS PREVIOUS_YEAR
--             FROM OW_LAO.DIM_CAMPAIGN_NAME
--         ) A
--         WHERE A.CAMPAIGN_TAG = v_campaign_tag;
-- 
--         PERFORM CREATE LOCAL TEMPORARY TABLE TMP_SALES_CAMPAIGN_UPDATE ON COMMIT PRESERVE ROWS AS (
--             SELECT DISTINCT 
--                 A.ID,
--                 CASE WHEN A.SUBSIDIARY LIKE 'SELA%' THEN 'SELA' ELSE A.SUBSIDIARY END AS SUBSIDIARY,
--                 A.PO_DATE,
--                 A.PODATE_MONTH,
--                 A.PODATE_YEAR,
--                 A.PO_ORDERID,
--                 A.PO_DEVICETYPE,
--                 A.PO_SKU,
--                 A.DIVISION,
--                 A.PRODUCT,
--                 A.PRODUCT_GROUP,
--                 A.PRODUCT_FAMILY,
--                 A.PO_STORENAME,
--                 A.BIZ_TYPE,
--                 A.AUDIENCE_TYPE,
--                 A.EBI_NETREVENUE,
--                 A.PO_TOTALPRICE_USD,
--                 A.NET_REVENUE,
--                 A.PO_QTY,
--                 DATEDIFF('day', B.INITIAL_DATE, A.PO_DATE) + 1 AS CAMPAIGN_DAY,
--                 B.CAMPAIGN_TAG,
--                 GREATEST(
--                     COALESCE(A.UPDATED_DATETIME, A.INSETED_DATETIME),
--                     COALESCE(A.EBI_LAST_UPDATE_DATE, A.INSETED_DATETIME),
--                     COALESCE(A.PO_LASTUPDATE_DATE_HOUR, A.INSETED_DATETIME),
--                     COALESCE(A.PO_SOURCE_LAST_UPDATE_DATE, A.INSETED_DATETIME),
--                     COALESCE(A.PO_SOURCE_PAYMENT_LAST_UPDATE_DATE, A.INSETED_DATETIME)
--                 ) AS DT_UPDATE,
--                 B.ID_CAMPAIGN,
--                 A.PO_STATUS,
--                 A.PRODUCT_CATEGORY,
--                 B.PREVIOUS_YEAR,
--                 ROW_NUMBER() OVER (
--                     PARTITION BY ID, CAMPAIGN_TAG
--                     ORDER BY ID
--                 ) AS DEDUP
--             FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A
--             JOIN OW_LAO.TMP_CAMPAIGN_NAME_PREVIOUS_YEAR B
--               ON A.PO_DATE BETWEEN B.INITIAL_DATE AND B.FINAL_DATE
--              AND (B.SUBSIDIARY IS NULL OR (CASE WHEN A.SUBSIDIARY LIKE 'SELA%' THEN 'SELA' ELSE A.SUBSIDIARY END) = B.SUBSIDIARY)
--              AND (B.DIVISION IS NULL OR A.DIVISION = B.DIVISION)
--              AND (B.BIZ_TYPE IS NULL OR A.BIZ_TYPE = B.BIZ_TYPE)
--              AND (B.PO_DEVICETYPE IS NULL OR A.PO_DEVICETYPE = B.PO_DEVICETYPE)
--              AND (B.PRODUCT IS NULL OR A.PRODUCT = B.PRODUCT)
--              AND (B.PRODUCT_GROUP IS NULL OR A.PRODUCT_GROUP = B.PRODUCT_GROUP)
--              AND (B.PO_SKU IS NULL OR A.PO_SKU = B.PO_SKU)
--              AND (B.AUDIENCE_TYPE IS NULL OR A.AUDIENCE_TYPE = B.AUDIENCE_TYPE)
--             WHERE B.CAMPAIGN_DAY >= 1
--               AND NOT EXISTS (
--                     SELECT 1
--                     FROM OW_LAO.TMP_SALES_CAMPAIGN C
--                     WHERE (A.ID = C.ID AND B.ID_CAMPAIGN = C.ID_CAMPAIGN)
--                       AND GREATEST(
--                             COALESCE(A.UPDATED_DATETIME, A.INSETED_DATETIME),
--                             COALESCE(A.EBI_LAST_UPDATE_DATE, A.INSETED_DATETIME),
--                             COALESCE(A.PO_LASTUPDATE_DATE_HOUR, A.INSETED_DATETIME),
--                             COALESCE(A.PO_SOURCE_LAST_UPDATE_DATE, A.INSETED_DATETIME),
--                             COALESCE(A.PO_SOURCE_PAYMENT_LAST_UPDATE_DATE, A.INSETED_DATETIME)
--                         ) = C.DT_UPDATE
--                 )
--         );
-- 
--         PERFORM MERGE INTO OW_LAO.TMP_SALES_CAMPAIGN tgt
--         USING TMP_SALES_CAMPAIGN_UPDATE src
--         ON tgt.ID = src.ID AND tgt.ID_CAMPAIGN = src.ID_CAMPAIGN
--         WHEN MATCHED THEN UPDATE SET 
--             ID = src.ID,
--             SUBSIDIARY = src.SUBSIDIARY,
--             PO_DATE = src.PO_DATE,
--             PODATE_MONTH = src.PODATE_MONTH,
--             PODATE_YEAR = src.PODATE_YEAR,
--             PO_ORDERID = src.PO_ORDERID,
--             PO_DEVICETYPE = src.PO_DEVICETYPE,
--             PO_SKU = src.PO_SKU,
--             DIVISION = src.DIVISION,
--             PRODUCT = src.PRODUCT,
--             PRODUCT_GROUP = src.PRODUCT_GROUP,
--             PRODUCT_FAMILY = src.PRODUCT_FAMILY,
--             PO_STORENAME = src.PO_STORENAME,
--             BIZ_TYPE = src.BIZ_TYPE,
--             AUDIENCE_TYPE = src.AUDIENCE_TYPE,
--             EBI_NETREVENUE = src.EBI_NETREVENUE,
--             PO_TOTALPRICE_USD = src.PO_TOTALPRICE_USD,
--             NET_REVENUE = src.NET_REVENUE,
--             PO_QTY = src.PO_QTY,
--             CAMPAIGN_DAY = src.CAMPAIGN_DAY,
--             CAMPAIGN_TAG = src.CAMPAIGN_TAG,
--             DT_UPDATE = src.DT_UPDATE,
--             ID_CAMPAIGN = src.ID_CAMPAIGN,
--             PO_STATUS = src.PO_STATUS,
--             PRODUCT_CATEGORY = src.PRODUCT_CATEGORY,
--             PREVIOUS_YEAR = src.PREVIOUS_YEAR,
--             DEDUP = src.DEDUP
--         WHEN NOT MATCHED THEN INSERT (
--             ID, SUBSIDIARY, PO_DATE, PODATE_MONTH, PODATE_YEAR, PO_ORDERID, PO_DEVICETYPE, PO_SKU, DIVISION, PRODUCT, PRODUCT_GROUP, PRODUCT_FAMILY, PO_STORENAME,
--             BIZ_TYPE, AUDIENCE_TYPE, EBI_NETREVENUE, PO_TOTALPRICE_USD, NET_REVENUE, PO_QTY, CAMPAIGN_DAY, CAMPAIGN_TAG, DT_UPDATE, ID_CAMPAIGN, PO_STATUS,
--             PRODUCT_CATEGORY, PREVIOUS_YEAR, DEDUP
--         ) VALUES (
--             src.ID, src.SUBSIDIARY, src.PO_DATE, src.PODATE_MONTH, src.PODATE_YEAR, src.PO_ORDERID, src.PO_DEVICETYPE, src.PO_SKU, src.DIVISION, src.PRODUCT, src.PRODUCT_GROUP,
--             src.PRODUCT_FAMILY, src.PO_STORENAME, src.BIZ_TYPE, src.AUDIENCE_TYPE, src.EBI_NETREVENUE, src.PO_TOTALPRICE_USD, src.NET_REVENUE, src.PO_QTY, src.CAMPAIGN_DAY,
--             src.CAMPAIGN_TAG, src.DT_UPDATE, src.ID_CAMPAIGN, src.PO_STATUS, src.PRODUCT_CATEGORY, src.PREVIOUS_YEAR, src.DEDUP
--         );
-- 
--         PERFORM DROP TABLE IF EXISTS TMP_SALES_CAMPAIGN_UPDATE;
-- 
--     ELSIF v_consulta = 'EXEC_ODS_SALES_CAMPAIGN' THEN
--         PERFORM DELETE FROM OW_LAO.ODS_SALES_CAMPAIGN A
--         WHERE NOT EXISTS (
--             SELECT 1
--             FROM OW_LAO.TMP_SALES_CAMPAIGN B
--             WHERE A.ID = B.ID
--               AND A.ID_CAMPAIGN = B.ID_CAMPAIGN
--               AND A.DT_UPDATE = B.DT_UPDATE
--         );
-- 
--         PERFORM CREATE LOCAL TEMPORARY TABLE ODS_SALES_CAMPAIGN_UPDATE ON COMMIT PRESERVE ROWS AS (
--             SELECT DISTINCT 
--                 A.ID,
--                 A.SUBSIDIARY,
--                 A.PO_DATE,
--                 A.PODATE_MONTH,
--                 A.PODATE_YEAR,
--                 A.PO_ORDERID,
--                 A.PO_DEVICETYPE,
--                 A.PO_SKU,
--                 A.DIVISION,
--                 A.PRODUCT,
--                 A.PRODUCT_GROUP,
--                 A.PRODUCT_FAMILY,
--                 A.PO_STORENAME,
--                 CASE WHEN A.PO_DEVICETYPE = 'MOBILEAPP' THEN 'APP' ELSE A.BIZ_TYPE END AS BIZ_TYPE,
--                 A.AUDIENCE_TYPE,
--                 A.EBI_NETREVENUE,
--                 A.PO_TOTALPRICE_USD,
--                 A.NET_REVENUE,
--                 A.PO_QTY,
--                 A.CAMPAIGN_DAY,
--                 A.CAMPAIGN_TAG,
--                 A.DT_UPDATE,
--                 A.PO_STATUS,
--                 A.PRODUCT_CATEGORY,
--                 A.PREVIOUS_YEAR,
--                 A.ID_CAMPAIGN 
--             FROM OW_LAO.TMP_SALES_CAMPAIGN A
--             WHERE DEDUP = 1  
--               AND NOT EXISTS (
--                     SELECT 1
--                     FROM OW_LAO.ODS_SALES_CAMPAIGN B
--                     WHERE A.ID = B.ID
--                       AND A.ID_CAMPAIGN = B.ID_CAMPAIGN
--                       AND A.DT_UPDATE = B.DT_UPDATE
--                 )
--         );
-- 
--         PERFORM MERGE INTO OW_LAO.ODS_SALES_CAMPAIGN tgt
--         USING ODS_SALES_CAMPAIGN_UPDATE src 
--         ON tgt.ID = src.ID AND tgt.ID_CAMPAIGN = src.ID_CAMPAIGN  
--         WHEN MATCHED THEN UPDATE SET 
--             ID = src.ID,
--             SUBSIDIARY = src.SUBSIDIARY,
--             PO_DATE = src.PO_DATE,
--             PODATE_MONTH = src.PODATE_MONTH,
--             PODATE_YEAR = src.PODATE_YEAR,
--             PO_ORDERID = src.PO_ORDERID,
--             PO_DEVICETYPE = src.PO_DEVICETYPE,
--             PO_SKU = src.PO_SKU,
--             DIVISION = src.DIVISION,
--             PRODUCT = src.PRODUCT,
--             PRODUCT_GROUP = src.PRODUCT_GROUP,
--             PRODUCT_FAMILY = src.PRODUCT_FAMILY,
--             PO_STORENAME = src.PO_STORENAME,
--             BIZ_TYPE = src.BIZ_TYPE,
--             AUDIENCE_TYPE = src.AUDIENCE_TYPE,
--             EBI_NETREVENUE = src.EBI_NETREVENUE,
--             PO_TOTALPRICE_USD = src.PO_TOTALPRICE_USD,
--             NET_REVENUE = src.NET_REVENUE,
--             PO_QTY = src.PO_QTY,
--             CAMPAIGN_DAY = src.CAMPAIGN_DAY,
--             CAMPAIGN_TAG = src.CAMPAIGN_TAG,
--             DT_UPDATE = src.DT_UPDATE,
--             PO_STATUS = src.PO_STATUS,
--             PRODUCT_CATEGORY = src.PRODUCT_CATEGORY,
--             PREVIOUS_YEAR = src.PREVIOUS_YEAR,
--             ID_CAMPAIGN = src.ID_CAMPAIGN 
--         WHEN NOT MATCHED THEN INSERT(
--             ID,
--             SUBSIDIARY,
--             PO_DATE,
--             PODATE_MONTH,
--             PODATE_YEAR,
--             PO_ORDERID,
--             PO_DEVICETYPE,
--             PO_SKU,
--             DIVISION,
--             PRODUCT,
--             PRODUCT_GROUP,
--             PRODUCT_FAMILY,
--             PO_STORENAME,
--             BIZ_TYPE,
--             AUDIENCE_TYPE,
--             EBI_NETREVENUE,
--             PO_TOTALPRICE_USD,
--             NET_REVENUE,
--             PO_QTY,
--             CAMPAIGN_DAY,
--             CAMPAIGN_TAG,
--             DT_UPDATE,
--             PO_STATUS,
--             PRODUCT_CATEGORY,
--             PREVIOUS_YEAR,
--             ID_CAMPAIGN 
--         )
--         VALUES(
--             src.ID,
--             src.SUBSIDIARY,
--             src.PO_DATE,
--             src.PODATE_MONTH,
--             src.PODATE_YEAR,
--             src.PO_ORDERID,
--             src.PO_DEVICETYPE,
--             src.PO_SKU,
--             src.DIVISION,
--             src.PRODUCT,
--             src.PRODUCT_GROUP,
--             src.PRODUCT_FAMILY,
--             src.PO_STORENAME,
--             src.BIZ_TYPE,
--             src.AUDIENCE_TYPE,
--             src.EBI_NETREVENUE,
--             src.PO_TOTALPRICE_USD,
--             src.NET_REVENUE,
--             src.PO_QTY,
--             src.CAMPAIGN_DAY,
--             src.CAMPAIGN_TAG,
--             src.DT_UPDATE,
--             src.PO_STATUS,
--             src.PRODUCT_CATEGORY,
--             src.PREVIOUS_YEAR,
--             src.ID_CAMPAIGN 
--         );
--         
--         PERFORM DROP TABLE IF EXISTS ODS_SALES_CAMPAIGN_UPDATE;
--     ELSE
--         NULL;
--     END IF;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: Syntax error at or near "A", Sqlstate: 42601, Position: 5330, Routine: base_yyerror, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/scan.l, Line: 1056, Error Code: 4856, 
-- CREATE OR REPLACE PROCEDURE OW_LAO.HOMOLOG_PROC_SALES_CAMPAIGN(
--     IN CONSULTA VARCHAR(40),
--     IN CAMPAIGN_TAG VARCHAR(400)
-- )
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--     IF CONSULTA = 'EXEC_UPDATE_CAMPAIGN_NAME' THEN
--         PERFORM TRUNCATE TABLE OW_LAO.TMP_UPDATE_CAMPAIGN_NAME;
-- 
--         PERFORM INSERT INTO OW_LAO.TMP_UPDATE_CAMPAIGN_NAME
--         SELECT ID_CAMPAIGN
--         FROM (
--             SELECT 
--                 A.CAMPAIGN_TAG,
--                 A.SUBSIDIARY,
--                 A.DIVISION,
--                 A.BIZ_TYPE,
--                 A.PO_DEVICETYPE,
--                 A.INITIAL_DATE,
--                 A.FINAL_DATE,
--                 A.PRODUCT,
--                 A.PRODUCT_GROUP,
--                 A.PO_SKU,
--                 A.ID_CAMPAIGN,
--                 B.CAMPAIGN_TAG AS TAG_DELETE
--             FROM OW_LAO.DIM_CAMPAIGN_NAME A
--             FULL OUTER JOIN OW_LAO.TMP_CAMPAIGN_NAME B
--               ON COALESCE(A.CAMPAIGN_TAG,'')              = COALESCE(B.CAMPAIGN_TAG,'')
--              AND COALESCE(A.SUBSIDIARY,'')               = COALESCE(B.SUBSIDIARY,'')
--              AND COALESCE(A.PO_DEVICETYPE,'')            = COALESCE(B.PO_DEVICETYPE,'')
--              AND COALESCE(TO_CHAR(A.INITIAL_DATE,'YYYY-MM-DD'),'') = COALESCE(TO_CHAR(B.INITIAL_DATE,'YYYY-MM-DD'),'')
--              AND COALESCE(TO_CHAR(A.FINAL_DATE,'YYYY-MM-DD'),'')   = COALESCE(TO_CHAR(B.FINAL_DATE,'YYYY-MM-DD'),'')
--              AND COALESCE(A.DIVISION,'')                 = COALESCE(B.DIVISION,'')
--              AND COALESCE(A.BIZ_TYPE,'')                 = COALESCE(B.BIZ_TYPE,'')
--              AND COALESCE(A.PRODUCT,'')                  = COALESCE(B.PRODUCT,'')
--              AND COALESCE(A.PRODUCT_GROUP,'')            = COALESCE(B.PRODUCT_GROUP,'')
--              AND COALESCE(A.PO_SKU,'')                   = COALESCE(B.PO_SKU,'')
--              AND COALESCE(A.AUDIENCE_TYPE,'')            = COALESCE(B.AUDIENCE_TYPE,'')
--             WHERE A.CAMPAIGN_TAG IS NOT NULL
--         ) AS TBL
--         WHERE TAG_DELETE IS NULL;
-- 
--         PERFORM DELETE FROM OW_LAO.TMP_SALES_CAMPAIGN 
--          WHERE ID_CAMPAIGN IN (SELECT ID_CAMPAIGN FROM OW_LAO.TMP_UPDATE_CAMPAIGN_NAME);
-- 
--         PERFORM DELETE FROM OW_LAO.DIM_CAMPAIGN_NAME 
--          WHERE ID_CAMPAIGN IN (SELECT ID_CAMPAIGN FROM OW_LAO.TMP_UPDATE_CAMPAIGN_NAME);
-- 
--         PERFORM INSERT INTO OW_LAO.DIM_CAMPAIGN_NAME(
--             CAMPAIGN_TAG,SUBSIDIARY,DIVISION,BIZ_TYPE,PO_DEVICETYPE,INITIAL_DATE,FINAL_DATE,PRODUCT,PRODUCT_GROUP,PO_SKU,AUDIENCE_TYPE)
--         SELECT 
--             B.CAMPAIGN_TAG,
--             B.SUBSIDIARY,
--             B.DIVISION,
--             B.BIZ_TYPE,
--             B.PO_DEVICETYPE,
--             B.INITIAL_DATE,
--             B.FINAL_DATE,
--             B.PRODUCT,
--             B.PRODUCT_GROUP,
--             B.PO_SKU,
--             B.AUDIENCE_TYPE
--         FROM OW_LAO.DIM_CAMPAIGN_NAME A
--         FULL OUTER JOIN OW_LAO.TMP_CAMPAIGN_NAME B
--           ON COALESCE(A.CAMPAIGN_TAG,'')              = COALESCE(B.CAMPAIGN_TAG,'')
--          AND COALESCE(A.SUBSIDIARY,'')               = COALESCE(B.SUBSIDIARY,'')
--          AND COALESCE(A.PO_DEVICETYPE,'')            = COALESCE(B.PO_DEVICETYPE,'')
--          AND COALESCE(TO_CHAR(A.INITIAL_DATE,'YYYY-MM-DD'),'') = COALESCE(TO_CHAR(B.INITIAL_DATE,'YYYY-MM-DD'),'')
--          AND COALESCE(TO_CHAR(A.FINAL_DATE,'YYYY-MM-DD'),'')   = COALESCE(TO_CHAR(B.FINAL_DATE,'YYYY-MM-DD'),'')
--          AND COALESCE(A.DIVISION,'')                 = COALESCE(B.DIVISION,'')
--          AND COALESCE(A.BIZ_TYPE,'')                 = COALESCE(B.BIZ_TYPE,'')
--          AND COALESCE(A.PRODUCT,'')                  = COALESCE(B.PRODUCT,'')
--          AND COALESCE(A.PRODUCT_GROUP,'')            = COALESCE(B.PRODUCT_GROUP,'')
--          AND COALESCE(A.PO_SKU,'')                   = COALESCE(B.PO_SKU,'')
--          AND COALESCE(A.AUDIENCE_TYPE,'')            = COALESCE(B.AUDIENCE_TYPE,'')
--         WHERE B.CAMPAIGN_TAG IS NOT NULL
--           AND A.ID_CAMPAIGN IS NULL;
-- 
--         PERFORM TRUNCATE TABLE OW_LAO.TMP_UPDATE_CAMPAIGN_NAME;
-- 
--         PERFORM UPDATE OW_LAO.DIM_CAMPAIGN_NAME d
--         SET
--             INITIAL_DATE_LY = TIMESTAMPADD(DAY, 
--                                 CASE WHEN EXTRACT(DOY FROM (DATE_TRUNC('year', d.INITIAL_DATE) + INTERVAL '1 year' - INTERVAL '1 day')) = 366
--                                      THEN COALESCE(rt."YEAR", ra."YEAR")
--                                      ELSE COALESCE(rt."LEAP_YEAR", ra."LEAP_YEAR")
--                                 END,
--                                 d.INITIAL_DATE),
--             FINAL_DATE_LY   = TIMESTAMPADD(DAY, 
--                                 CASE WHEN EXTRACT(DOY FROM (DATE_TRUNC('year', d.FINAL_DATE) + INTERVAL '1 year' - INTERVAL '1 day')) = 366
--                                      THEN COALESCE(rt."YEAR", ra."YEAR")
--                                      ELSE COALESCE(rt."LEAP_YEAR", ra."LEAP_YEAR")
--                                 END,
--                                 d.FINAL_DATE)
--         FROM OW_LAO.DIM_CAMPAIGN_NAME_RULE rt
--         LEFT JOIN OW_LAO.DIM_CAMPAIGN_NAME_RULE ra ON ra.CAMPAIGN_TAG = 'ALL'
--         WHERE d.CAMPAIGN_TAG = rt.CAMPAIGN_TAG;
-- 
--     ELSIF CONSULTA = 'EXEC_TMP_SALES_CAMPAIGN' THEN
--         PERFORM DELETE FROM OW_LAO.TMP_SALES_CAMPAIGN A
--         WHERE A.CAMPAIGN_TAG = CAMPAIGN_TAG
--           AND NOT EXISTS (
--                 SELECT 1
--                 FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE B
--                 WHERE A.ID = B.ID
--             );
-- 
--         PERFORM TRUNCATE TABLE OW_LAO.TMP_CAMPAIGN_NAME_PREVIOUS_YEAR;
-- 
--         PERFORM INSERT INTO OW_LAO.TMP_CAMPAIGN_NAME_PREVIOUS_YEAR
--         SELECT * FROM (
--             SELECT 
--                 CAMPAIGN_TAG, SUBSIDIARY, DIVISION, BIZ_TYPE, PO_DEVICETYPE, 
--                 INITIAL_DATE_LY,
--                 TIMESTAMPADD(DAY,
--                     DATEDIFF('day', INITIAL_DATE, CASE WHEN CURRENT_DATE >= FINAL_DATE THEN FINAL_DATE ELSE CURRENT_DATE END),
--                     INITIAL_DATE_LY) AS FINAL_DATE,
--                 PRODUCT, PRODUCT_GROUP, PO_SKU, ID_CAMPAIGN, AUDIENCE_TYPE,
--                 DATEDIFF('day', INITIAL_DATE, CASE WHEN CURRENT_DATE >= FINAL_DATE THEN FINAL_DATE ELSE CURRENT_DATE END) + 1 AS CAMPAIGN_DAY,
--                 TRUE AS PREVIOUS_YEAR
--             FROM OW_LAO.DIM_CAMPAIGN_NAME
--             UNION ALL
--             SELECT 
--                 CAMPAIGN_TAG, SUBSIDIARY, DIVISION, BIZ_TYPE, PO_DEVICETYPE, INITIAL_DATE, FINAL_DATE, PRODUCT, PRODUCT_GROUP, PO_SKU, ID_CAMPAIGN, AUDIENCE_TYPE,
--                 DATEDIFF('day', INITIAL_DATE, FINAL_DATE) + 1 AS CAMPAIGN_DAY,
--                 FALSE AS PREVIOUS_YEAR
--             FROM OW_LAO.DIM_CAMPAIGN_NAME
--         ) A
--         WHERE A.CAMPAIGN_TAG = CAMPAIGN_TAG;
-- 
--         PERFORM CREATE LOCAL TEMPORARY TABLE TMP_SALES_CAMPAIGN_UPDATE ON COMMIT PRESERVE ROWS AS
--         SELECT DISTINCT 
--             A.ID,
--             CASE WHEN A.SUBSIDIARY LIKE 'SELA%' THEN 'SELA' ELSE A.SUBSIDIARY END AS SUBSIDIARY,
--             A.PO_DATE,
--             A.PODATE_MONTH,
--             A.PODATE_YEAR,
--             A.PO_ORDERID,
--             A.PO_DEVICETYPE,
--             A.PO_SKU,
--             A.DIVISION,
--             A.PRODUCT,
--             A.PRODUCT_GROUP,
--             A.PRODUCT_FAMILY,
--             A.PO_STORENAME,
--             A.BIZ_TYPE,
--             A.AUDIENCE_TYPE,
--             A.EBI_NETREVENUE,
--             A.PO_TOTALPRICE_USD,
--             A.NET_REVENUE,
--             A.PO_QTY,
--             DATEDIFF('day', B.INITIAL_DATE, A.PO_DATE) + 1 AS CAMPAIGN_DAY,
--             B.CAMPAIGN_TAG,
--             GREATEST(
--                 COALESCE(A.UPDATED_DATETIME, A.INSETED_DATETIME),
--                 COALESCE(A.EBI_LAST_UPDATE_DATE, A.INSETED_DATETIME),
--                 COALESCE(A.PO_LASTUPDATE_DATE_HOUR, A.INSETED_DATETIME),
--                 COALESCE(A.PO_SOURCE_LAST_UPDATE_DATE, A.INSETED_DATETIME),
--                 COALESCE(A.PO_SOURCE_PAYMENT_LAST_UPDATE_DATE, A.INSETED_DATETIME)
--             ) AS DT_UPDATE,
--             B.ID_CAMPAIGN,
--             A.PO_STATUS,
--             A.PRODUCT_CATEGORY,
--             B.PREVIOUS_YEAR,
--             ROW_NUMBER() OVER (
--                 PARTITION BY ID, CAMPAIGN_TAG
--                 ORDER BY ID
--             ) AS DEDUP
--         FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A
--         JOIN OW_LAO.TMP_CAMPAIGN_NAME_PREVIOUS_YEAR B
--           ON A.PO_DATE BETWEEN B.INITIAL_DATE AND B.FINAL_DATE
--          AND (B.SUBSIDIARY IS NULL OR (CASE WHEN A.SUBSIDIARY LIKE 'SELA%' THEN 'SELA' ELSE A.SUBSIDIARY END) = B.SUBSIDIARY)
--          AND (B.DIVISION IS NULL OR A.DIVISION = B.DIVISION)
--          AND (B.BIZ_TYPE IS NULL OR A.BIZ_TYPE = B.BIZ_TYPE)
--          AND (B.PO_DEVICETYPE IS NULL OR A.PO_DEVICETYPE = B.PO_DEVICETYPE)
--          AND (B.PRODUCT IS NULL OR A.PRODUCT = B.PRODUCT)
--          AND (B.PRODUCT_GROUP IS NULL OR A.PRODUCT_GROUP = B.PRODUCT_GROUP)
--          AND (B.PO_SKU IS NULL OR A.PO_SKU = B.PO_SKU)
--          AND (B.AUDIENCE_TYPE IS NULL OR A.AUDIENCE_TYPE = B.AUDIENCE_TYPE)
--         WHERE B.CAMPAIGN_DAY >= 1
--           AND NOT EXISTS (
--                 SELECT 1
--                 FROM OW_LAO.TMP_SALES_CAMPAIGN C
--                 WHERE (A.ID = C.ID AND B.ID_CAMPAIGN = C.ID_CAMPAIGN)
--                   AND GREATEST(
--                         COALESCE(A.UPDATED_DATETIME, A.INSETED_DATETIME),
--                         COALESCE(A.EBI_LAST_UPDATE_DATE, A.INSETED_DATETIME),
--                         COALESCE(A.PO_LASTUPDATE_DATE_HOUR, A.INSETED_DATETIME),
--                         COALESCE(A.PO_SOURCE_LAST_UPDATE_DATE, A.INSETED_DATETIME),
--                         COALESCE(A.PO_SOURCE_PAYMENT_LAST_UPDATE_DATE, A.INSETED_DATETIME)
--                     ) = C.DT_UPDATE
--             );
-- 
--         MERGE INTO OW_LAO.TMP_SALES_CAMPAIGN
--         USING TMP_SALES_CAMPAIGN_UPDATE src
--         ON TMP_SALES_CAMPAIGN.ID = src.ID AND TMP_SALES_CAMPAIGN.ID_CAMPAIGN = src.ID_CAMPAIGN
--         WHEN MATCHED THEN UPDATE SET
--             ID = src.ID,
--             SUBSIDIARY = src.SUBSIDIARY,
--             PO_DATE = src.PO_DATE,
--             PODATE_MONTH = src.PODATE_MONTH,
--             PODATE_YEAR = src.PODATE_YEAR,
--             PO_ORDERID = src.PO_ORDERID,
--             PO_DEVICETYPE = src.PO_DEVICETYPE,
--             PO_SKU = src.PO_SKU,
--             DIVISION = src.DIVISION,
--             PRODUCT = src.PRODUCT,
--             PRODUCT_GROUP = src.PRODUCT_GROUP,
--             PRODUCT_FAMILY = src.PRODUCT_FAMILY,
--             PO_STORENAME = src.PO_STORENAME,
--             BIZ_TYPE = src.BIZ_TYPE,
--             AUDIENCE_TYPE = src.AUDIENCE_TYPE,
--             EBI_NETREVENUE = src.EBI_NETREVENUE,
--             PO_TOTALPRICE_USD = src.PO_TOTALPRICE_USD,
--             NET_REVENUE = src.NET_REVENUE,
--             PO_QTY = src.PO_QTY,
--             CAMPAIGN_DAY = src.CAMPAIGN_DAY,
--             CAMPAIGN_TAG = src.CAMPAIGN_TAG,
--             DT_UPDATE = src.DT_UPDATE,
--             ID_CAMPAIGN = src.ID_CAMPAIGN,
--             PO_STATUS = src.PO_STATUS,
--             PRODUCT_CATEGORY = src.PRODUCT_CATEGORY,
--             PREVIOUS_YEAR = src.PREVIOUS_YEAR,
--             DEDUP = src.DEDUP
--         WHEN NOT MATCHED THEN INSERT (
--             ID, SUBSIDIARY, PO_DATE, PODATE_MONTH, PODATE_YEAR, PO_ORDERID, PO_DEVICETYPE, PO_SKU, DIVISION, PRODUCT, PRODUCT_GROUP, PRODUCT_FAMILY, PO_STORENAME,
--             BIZ_TYPE, AUDIENCE_TYPE, EBI_NETREVENUE, PO_TOTALPRICE_USD, NET_REVENUE, PO_QTY, CAMPAIGN_DAY, CAMPAIGN_TAG, DT_UPDATE, ID_CAMPAIGN, PO_STATUS,
--             PRODUCT_CATEGORY, PREVIOUS_YEAR, DEDUP
--         ) VALUES (
--             src.ID, src.SUBSIDIARY, src.PO_DATE, src.PODATE_MONTH, src.PODATE_YEAR, src.PO_ORDERID, src.PO_DEVICETYPE, src.PO_SKU, src.DIVISION, src.PRODUCT, src.PRODUCT_GROUP,
--             src.PRODUCT_FAMILY, src.PO_STORENAME, src.BIZ_TYPE, src.AUDIENCE_TYPE, src.EBI_NETREVENUE, src.PO_TOTALPRICE_USD, src.NET_REVENUE, src.PO_QTY, src.CAMPAIGN_DAY,
--             src.CAMPAIGN_TAG, src.DT_UPDATE, src.ID_CAMPAIGN, src.PO_STATUS, src.PRODUCT_CATEGORY, src.PREVIOUS_YEAR, src.DEDUP
--         );
-- 
--         PERFORM DROP TABLE IF EXISTS TMP_SALES_CAMPAIGN_UPDATE;
-- 
--     ELSIF CONSULTA = 'EXEC_ODS_SALES_CAMPAIGN' THEN
--         PERFORM DELETE FROM OW_LAO.ODS_SALES_CAMPAIGN A
--         WHERE NOT EXISTS (
--             SELECT 1
--             FROM OW_LAO.TMP_SALES_CAMPAIGN B
--             WHERE A.ID = B.ID
--               AND A.ID_CAMPAIGN = B.ID_CAMPAIGN
--               AND A.DT_UPDATE = B.DT_UPDATE
--         );
-- 
--         PERFORM CREATE LOCAL TEMPORARY TABLE ODS_SALES_CAMPAIGN_UPDATE ON COMMIT PRESERVE ROWS AS
--         SELECT DISTINCT 
--             A.ID,
--             A.SUBSIDIARY,
--             A.PO_DATE,
--             A.PODATE_MONTH,
--             A.PODATE_YEAR,
--             A.PO_ORDERID,
--             A.PO_DEVICETYPE,
--             A.PO_SKU,
--             A.DIVISION,
--             A.PRODUCT,
--             A.PRODUCT_GROUP,
--             A.PRODUCT_FAMILY,
--             A.PO_STORENAME,
--             CASE WHEN A.PO_DEVICETYPE = 'MOBILEAPP' THEN 'APP' ELSE A.BIZ_TYPE END AS BIZ_TYPE,
--             A.AUDIENCE_TYPE,
--             A.EBI_NETREVENUE,
--             A.PO_TOTALPRICE_USD,
--             A.NET_REVENUE,
--             A.PO_QTY,
--             A.CAMPAIGN_DAY,
--             A.CAMPAIGN_TAG,
--             A.DT_UPDATE,
--             A.PO_STATUS,
--             A.PRODUCT_CATEGORY,
--             A.PREVIOUS_YEAR,
--             A.ID_CAMPAIGN 
--         FROM OW_LAO.TMP_SALES_CAMPAIGN A
--         WHERE DEDUP = 1  
--           AND NOT EXISTS (
--                 SELECT 1
--                 FROM OW_LAO.ODS_SALES_CAMPAIGN B
--                 WHERE A.ID = B.ID
--                   AND A.ID_CAMPAIGN = B.ID_CAMPAIGN
--                   AND A.DT_UPDATE = B.DT_UPDATE
--             );
-- 
--         MERGE INTO OW_LAO.ODS_SALES_CAMPAIGN
--         USING ODS_SALES_CAMPAIGN_UPDATE src 
--         ON ODS_SALES_CAMPAIGN.ID = src.ID AND ODS_SALES_CAMPAIGN.ID_CAMPAIGN = src.ID_CAMPAIGN  
--         WHEN MATCHED THEN UPDATE SET 
--             ID = src.ID,
--             SUBSIDIARY = src.SUBSIDIARY,
--             PO_DATE = src.PO_DATE,
--             PODATE_MONTH = src.PODATE_MONTH,
--             PODATE_YEAR = src.PODATE_YEAR,
--             PO_ORDERID = src.PO_ORDERID,
--             PO_DEVICETYPE = src.PO_DEVICETYPE,
--             PO_SKU = src.PO_SKU,
--             DIVISION = src.DIVISION,
--             PRODUCT = src.PRODUCT,
--             PRODUCT_GROUP = src.PRODUCT_GROUP,
--             PRODUCT_FAMILY = src.PRODUCT_FAMILY,
--             PO_STORENAME = src.PO_STORENAME,
--             BIZ_TYPE = src.BIZ_TYPE,
--             AUDIENCE_TYPE = src.AUDIENCE_TYPE,
--             EBI_NETREVENUE = src.EBI_NETREVENUE,
--             PO_TOTALPRICE_USD = src.PO_TOTALPRICE_USD,
--             NET_REVENUE = src.NET_REVENUE,
--             PO_QTY = src.PO_QTY,
--             CAMPAIGN_DAY = src.CAMPAIGN_DAY,
--             CAMPAIGN_TAG = src.CAMPAIGN_TAG,
--             DT_UPDATE = src.DT_UPDATE,
--             PO_STATUS = src.PO_STATUS,
--             PRODUCT_CATEGORY = src.PRODUCT_CATEGORY,
--             PREVIOUS_YEAR = src.PREVIOUS_YEAR,
--             ID_CAMPAIGN = src.ID_CAMPAIGN 
--         WHEN NOT MATCHED THEN INSERT(
--             ID,
--             SUBSIDIARY,
--             PO_DATE,
--             PODATE_MONTH,
--             PODATE_YEAR,
--             PO_ORDERID,
--             PO_DEVICETYPE,
--             PO_SKU,
--             DIVISION,
--             PRODUCT,
--             PRODUCT_GROUP,
--             PRODUCT_FAMILY,
--             PO_STORENAME,
--             BIZ_TYPE,
--             AUDIENCE_TYPE,
--             EBI_NETREVENUE,
--             PO_TOTALPRICE_USD,
--             NET_REVENUE,
--             PO_QTY,
--             CAMPAIGN_DAY,
--             CAMPAIGN_TAG,
--             DT_UPDATE,
--             PO_STATUS,
--             PRODUCT_CATEGORY,
--             PREVIOUS_YEAR,
--             ID_CAMPAIGN 
--         )
--         VALUES(
--             src.ID,
--             src.SUBSIDIARY,
--             src.PO_DATE,
--             src.PODATE_MONTH,
--             src.PODATE_YEAR,
--             src.PO_ORDERID,
--             src.PO_DEVICETYPE,
--             src.PO_SKU,
--             src.DIVISION,
--             src.PRODUCT,
--             src.PRODUCT_GROUP,
--             src.PRODUCT_FAMILY,
--             src.PO_STORENAME,
--             src.BIZ_TYPE,
--             src.AUDIENCE_TYPE,
--             src.EBI_NETREVENUE,
--             src.PO_TOTALPRICE_USD,
--             src.NET_REVENUE,
--             src.PO_QTY,
--             src.CAMPAIGN_DAY,
--             src.CAMPAIGN_TAG,
--             src.DT_UPDATE,
--             src.PO_STATUS,
--             src.PRODUCT_CATEGORY,
--             src.PREVIOUS_YEAR,
--             src.ID_CAMPAIGN 
--         );
--         
--         PERFORM DROP TABLE IF EXISTS ODS_SALES_CAMPAIGN_UPDATE;
--     ELSE
--         NULL;
--     END IF;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 190.15-18 of source string: syntax error, unexpected INTO, expecting := or <-, Sqlstate: 42601, Position: 9507, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
-- CREATE OR REPLACE PROCEDURE OW_LAO.HOMOLOG_PROC_SALES_CAMPAIGN(
--     IN CONSULTA VARCHAR(40),
--     IN CAMPAIGN_TAG VARCHAR(400)
-- )
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--     IF CONSULTA = 'EXEC_UPDATE_CAMPAIGN_NAME' THEN
--         PERFORM TRUNCATE TABLE OW_LAO.TMP_UPDATE_CAMPAIGN_NAME;
-- 
--         PERFORM INSERT INTO OW_LAO.TMP_UPDATE_CAMPAIGN_NAME
--         SELECT ID_CAMPAIGN
--         FROM (
--             SELECT 
--                 A.CAMPAIGN_TAG,
--                 A.SUBSIDIARY,
--                 A.DIVISION,
--                 A.BIZ_TYPE,
--                 A.PO_DEVICETYPE,
--                 A.INITIAL_DATE,
--                 A.FINAL_DATE,
--                 A.PRODUCT,
--                 A.PRODUCT_GROUP,
--                 A.PO_SKU,
--                 A.ID_CAMPAIGN,
--                 B.CAMPAIGN_TAG AS TAG_DELETE
--             FROM OW_LAO.DIM_CAMPAIGN_NAME A
--             FULL OUTER JOIN OW_LAO.TMP_CAMPAIGN_NAME B
--               ON COALESCE(A.CAMPAIGN_TAG,'')              = COALESCE(B.CAMPAIGN_TAG,'')
--              AND COALESCE(A.SUBSIDIARY,'')               = COALESCE(B.SUBSIDIARY,'')
--              AND COALESCE(A.PO_DEVICETYPE,'')            = COALESCE(B.PO_DEVICETYPE,'')
--              AND COALESCE(TO_CHAR(A.INITIAL_DATE,'YYYY-MM-DD'),'') = COALESCE(TO_CHAR(B.INITIAL_DATE,'YYYY-MM-DD'),'')
--              AND COALESCE(TO_CHAR(A.FINAL_DATE,'YYYY-MM-DD'),'')   = COALESCE(TO_CHAR(B.FINAL_DATE,'YYYY-MM-DD'),'')
--              AND COALESCE(A.DIVISION,'')                 = COALESCE(B.DIVISION,'')
--              AND COALESCE(A.BIZ_TYPE,'')                 = COALESCE(B.BIZ_TYPE,'')
--              AND COALESCE(A.PRODUCT,'')                  = COALESCE(B.PRODUCT,'')
--              AND COALESCE(A.PRODUCT_GROUP,'')            = COALESCE(B.PRODUCT_GROUP,'')
--              AND COALESCE(A.PO_SKU,'')                   = COALESCE(B.PO_SKU,'')
--              AND COALESCE(A.AUDIENCE_TYPE,'')            = COALESCE(B.AUDIENCE_TYPE,'')
--             WHERE A.CAMPAIGN_TAG IS NOT NULL
--         ) AS TBL
--         WHERE TAG_DELETE IS NULL;
-- 
--         PERFORM DELETE FROM OW_LAO.TMP_SALES_CAMPAIGN 
--          WHERE ID_CAMPAIGN IN (SELECT ID_CAMPAIGN FROM OW_LAO.TMP_UPDATE_CAMPAIGN_NAME);
-- 
--         PERFORM DELETE FROM OW_LAO.DIM_CAMPAIGN_NAME 
--          WHERE ID_CAMPAIGN IN (SELECT ID_CAMPAIGN FROM OW_LAO.TMP_UPDATE_CAMPAIGN_NAME);
-- 
--         PERFORM INSERT INTO OW_LAO.DIM_CAMPAIGN_NAME(
--             CAMPAIGN_TAG,SUBSIDIARY,DIVISION,BIZ_TYPE,PO_DEVICETYPE,INITIAL_DATE,FINAL_DATE,PRODUCT,PRODUCT_GROUP,PO_SKU,AUDIENCE_TYPE)
--         SELECT 
--             B.CAMPAIGN_TAG,
--             B.SUBSIDIARY,
--             B.DIVISION,
--             B.BIZ_TYPE,
--             B.PO_DEVICETYPE,
--             B.INITIAL_DATE,
--             B.FINAL_DATE,
--             B.PRODUCT,
--             B.PRODUCT_GROUP,
--             B.PO_SKU,
--             B.AUDIENCE_TYPE
--         FROM OW_LAO.DIM_CAMPAIGN_NAME A
--         FULL OUTER JOIN OW_LAO.TMP_CAMPAIGN_NAME B
--           ON COALESCE(A.CAMPAIGN_TAG,'')              = COALESCE(B.CAMPAIGN_TAG,'')
--          AND COALESCE(A.SUBSIDIARY,'')               = COALESCE(B.SUBSIDIARY,'')
--          AND COALESCE(A.PO_DEVICETYPE,'')            = COALESCE(B.PO_DEVICETYPE,'')
--          AND COALESCE(TO_CHAR(A.INITIAL_DATE,'YYYY-MM-DD'),'') = COALESCE(TO_CHAR(B.INITIAL_DATE,'YYYY-MM-DD'),'')
--          AND COALESCE(TO_CHAR(A.FINAL_DATE,'YYYY-MM-DD'),'')   = COALESCE(TO_CHAR(B.FINAL_DATE,'YYYY-MM-DD'),'')
--          AND COALESCE(A.DIVISION,'')                 = COALESCE(B.DIVISION,'')
--          AND COALESCE(A.BIZ_TYPE,'')                 = COALESCE(B.BIZ_TYPE,'')
--          AND COALESCE(A.PRODUCT,'')                  = COALESCE(B.PRODUCT,'')
--          AND COALESCE(A.PRODUCT_GROUP,'')            = COALESCE(B.PRODUCT_GROUP,'')
--          AND COALESCE(A.PO_SKU,'')                   = COALESCE(B.PO_SKU,'')
--          AND COALESCE(A.AUDIENCE_TYPE,'')            = COALESCE(B.AUDIENCE_TYPE,'')
--         WHERE B.CAMPAIGN_TAG IS NOT NULL
--           AND A.ID_CAMPAIGN IS NULL;
-- 
--         PERFORM TRUNCATE TABLE OW_LAO.TMP_UPDATE_CAMPAIGN_NAME;
-- 
--         PERFORM UPDATE OW_LAO.DIM_CAMPAIGN_NAME d
--         SET
--             INITIAL_DATE_LY = TIMESTAMPADD(DAY, 
--                                 CASE WHEN EXTRACT(DOY FROM (DATE_TRUNC('year', d.INITIAL_DATE) + INTERVAL '1 year' - INTERVAL '1 day')) = 366
--                                      THEN COALESCE(rt."YEAR", ra."YEAR")
--                                      ELSE COALESCE(rt."LEAP_YEAR", ra."LEAP_YEAR")
--                                 END,
--                                 d.INITIAL_DATE),
--             FINAL_DATE_LY   = TIMESTAMPADD(DAY, 
--                                 CASE WHEN EXTRACT(DOY FROM (DATE_TRUNC('year', d.FINAL_DATE) + INTERVAL '1 year' - INTERVAL '1 day')) = 366
--                                      THEN COALESCE(rt."YEAR", ra."YEAR")
--                                      ELSE COALESCE(rt."LEAP_YEAR", ra."LEAP_YEAR")
--                                 END,
--                                 d.FINAL_DATE)
--         FROM OW_LAO.DIM_CAMPAIGN_NAME_RULE rt
--         LEFT JOIN OW_LAO.DIM_CAMPAIGN_NAME_RULE ra ON ra.CAMPAIGN_TAG = 'ALL'
--         WHERE d.CAMPAIGN_TAG = rt.CAMPAIGN_TAG;
-- 
--     ELSIF CONSULTA = 'EXEC_TMP_SALES_CAMPAIGN' THEN
--         PERFORM DELETE FROM OW_LAO.TMP_SALES_CAMPAIGN A
--         WHERE A.CAMPAIGN_TAG = CAMPAIGN_TAG
--           AND NOT EXISTS (
--                 SELECT 1
--                 FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE B
--                 WHERE A.ID = B.ID
--             );
-- 
--         PERFORM TRUNCATE TABLE OW_LAO.TMP_CAMPAIGN_NAME_PREVIOUS_YEAR;
-- 
--         PERFORM INSERT INTO OW_LAO.TMP_CAMPAIGN_NAME_PREVIOUS_YEAR
--         SELECT * FROM (
--             SELECT 
--                 CAMPAIGN_TAG, SUBSIDIARY, DIVISION, BIZ_TYPE, PO_DEVICETYPE, 
--                 INITIAL_DATE_LY,
--                 TIMESTAMPADD(DAY,
--                     DATEDIFF('day', INITIAL_DATE, CASE WHEN CURRENT_DATE >= FINAL_DATE THEN FINAL_DATE ELSE CURRENT_DATE END),
--                     INITIAL_DATE_LY) AS FINAL_DATE,
--                 PRODUCT, PRODUCT_GROUP, PO_SKU, ID_CAMPAIGN, AUDIENCE_TYPE,
--                 DATEDIFF('day', INITIAL_DATE, CASE WHEN CURRENT_DATE >= FINAL_DATE THEN FINAL_DATE ELSE CURRENT_DATE END) + 1 AS CAMPAIGN_DAY,
--                 TRUE AS PREVIOUS_YEAR
--             FROM OW_LAO.DIM_CAMPAIGN_NAME
--             UNION ALL
--             SELECT 
--                 CAMPAIGN_TAG, SUBSIDIARY, DIVISION, BIZ_TYPE, PO_DEVICETYPE, INITIAL_DATE, FINAL_DATE, PRODUCT, PRODUCT_GROUP, PO_SKU, ID_CAMPAIGN, AUDIENCE_TYPE,
--                 DATEDIFF('day', INITIAL_DATE, FINAL_DATE) + 1 AS CAMPAIGN_DAY,
--                 FALSE AS PREVIOUS_YEAR
--             FROM OW_LAO.DIM_CAMPAIGN_NAME
--         ) A
--         WHERE A.CAMPAIGN_TAG = CAMPAIGN_TAG;
-- 
--         PERFORM DROP TABLE IF EXISTS TMP_SALES_CAMPAIGN_UPDATE;
--         PERFORM CREATE LOCAL TEMPORARY TABLE TMP_SALES_CAMPAIGN_UPDATE ON COMMIT PRESERVE ROWS AS
--         SELECT DISTINCT 
--             A.ID,
--             CASE WHEN A.SUBSIDIARY LIKE 'SELA%' THEN 'SELA' ELSE A.SUBSIDIARY END AS SUBSIDIARY,
--             A.PO_DATE,
--             A.PODATE_MONTH,
--             A.PODATE_YEAR,
--             A.PO_ORDERID,
--             A.PO_DEVICETYPE,
--             A.PO_SKU,
--             A.DIVISION,
--             A.PRODUCT,
--             A.PRODUCT_GROUP,
--             A.PRODUCT_FAMILY,
--             A.PO_STORENAME,
--             A.BIZ_TYPE,
--             A.AUDIENCE_TYPE,
--             A.EBI_NETREVENUE,
--             A.PO_TOTALPRICE_USD,
--             A.NET_REVENUE,
--             A.PO_QTY,
--             DATEDIFF('day', B.INITIAL_DATE, A.PO_DATE) + 1 AS CAMPAIGN_DAY,
--             B.CAMPAIGN_TAG,
--             GREATEST(
--                 COALESCE(A.UPDATED_DATETIME, A.INSETED_DATETIME),
--                 COALESCE(A.EBI_LAST_UPDATE_DATE, A.INSETED_DATETIME),
--                 COALESCE(A.PO_LASTUPDATE_DATE_HOUR, A.INSETED_DATETIME),
--                 COALESCE(A.PO_SOURCE_LAST_UPDATE_DATE, A.INSETED_DATETIME),
--                 COALESCE(A.PO_SOURCE_PAYMENT_LAST_UPDATE_DATE, A.INSETED_DATETIME)
--             ) AS DT_UPDATE,
--             B.ID_CAMPAIGN,
--             A.PO_STATUS,
--             A.PRODUCT_CATEGORY,
--             B.PREVIOUS_YEAR,
--             ROW_NUMBER() OVER (
--                 PARTITION BY ID, CAMPAIGN_TAG
--                 ORDER BY ID
--             ) AS DEDUP
--         FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A
--         JOIN OW_LAO.TMP_CAMPAIGN_NAME_PREVIOUS_YEAR B
--           ON A.PO_DATE BETWEEN B.INITIAL_DATE AND B.FINAL_DATE
--          AND (B.SUBSIDIARY IS NULL OR (CASE WHEN A.SUBSIDIARY LIKE 'SELA%' THEN 'SELA' ELSE A.SUBSIDIARY END) = B.SUBSIDIARY)
--          AND (B.DIVISION IS NULL OR A.DIVISION = B.DIVISION)
--          AND (B.BIZ_TYPE IS NULL OR A.BIZ_TYPE = B.BIZ_TYPE)
--          AND (B.PO_DEVICETYPE IS NULL OR A.PO_DEVICETYPE = B.PO_DEVICETYPE)
--          AND (B.PRODUCT IS NULL OR A.PRODUCT = B.PRODUCT)
--          AND (B.PRODUCT_GROUP IS NULL OR A.PRODUCT_GROUP = B.PRODUCT_GROUP)
--          AND (B.PO_SKU IS NULL OR A.PO_SKU = B.PO_SKU)
--          AND (B.AUDIENCE_TYPE IS NULL OR A.AUDIENCE_TYPE = B.AUDIENCE_TYPE)
--         WHERE B.CAMPAIGN_DAY >= 1
--           AND NOT EXISTS (
--                 SELECT 1
--                 FROM OW_LAO.TMP_SALES_CAMPAIGN C
--                 WHERE (A.ID = C.ID AND B.ID_CAMPAIGN = C.ID_CAMPAIGN)
--                   AND GREATEST(
--                         COALESCE(A.UPDATED_DATETIME, A.INSETED_DATETIME),
--                         COALESCE(A.EBI_LAST_UPDATE_DATE, A.INSETED_DATETIME),
--                         COALESCE(A.PO_LASTUPDATE_DATE_HOUR, A.INSETED_DATETIME),
--                         COALESCE(A.PO_SOURCE_LAST_UPDATE_DATE, A.INSETED_DATETIME),
--                         COALESCE(A.PO_SOURCE_PAYMENT_LAST_UPDATE_DATE, A.INSETED_DATETIME)
--                     ) = C.DT_UPDATE
--             );
-- 
--         -- Update existing rows
--         PERFORM UPDATE OW_LAO.TMP_SALES_CAMPAIGN t
--         SET 
--             ID = s.ID,
--             SUBSIDIARY = s.SUBSIDIARY,
--             PO_DATE = s.PO_DATE,
--             PODATE_MONTH = s.PODATE_MONTH,
--             PODATE_YEAR = s.PODATE_YEAR,
--             PO_ORDERID = s.PO_ORDERID,
--             PO_DEVICETYPE = s.PO_DEVICETYPE,
--             PO_SKU = s.PO_SKU,
--             DIVISION = s.DIVISION,
--             PRODUCT = s.PRODUCT,
--             PRODUCT_GROUP = s.PRODUCT_GROUP,
--             PRODUCT_FAMILY = s.PRODUCT_FAMILY,
--             PO_STORENAME = s.PO_STORENAME,
--             BIZ_TYPE = s.BIZ_TYPE,
--             AUDIENCE_TYPE = s.AUDIENCE_TYPE,
--             EBI_NETREVENUE = s.EBI_NETREVENUE,
--             PO_TOTALPRICE_USD = s.PO_TOTALPRICE_USD,
--             NET_REVENUE = s.NET_REVENUE,
--             PO_QTY = s.PO_QTY,
--             CAMPAIGN_DAY = s.CAMPAIGN_DAY,
--             CAMPAIGN_TAG = s.CAMPAIGN_TAG,
--             DT_UPDATE = s.DT_UPDATE,
--             ID_CAMPAIGN = s.ID_CAMPAIGN,
--             PO_STATUS = s.PO_STATUS,
--             PRODUCT_CATEGORY = s.PRODUCT_CATEGORY,
--             PREVIOUS_YEAR = s.PREVIOUS_YEAR,
--             DEDUP = s.DEDUP
--         FROM TMP_SALES_CAMPAIGN_UPDATE s
--         WHERE t.ID = s.ID AND t.ID_CAMPAIGN = s.ID_CAMPAIGN;
-- 
--         -- Insert new rows
--         PERFORM INSERT INTO OW_LAO.TMP_SALES_CAMPAIGN (
--             ID, SUBSIDIARY, PO_DATE, PODATE_MONTH, PODATE_YEAR, PO_ORDERID, PO_DEVICETYPE, PO_SKU, DIVISION, PRODUCT, PRODUCT_GROUP, PRODUCT_FAMILY, PO_STORENAME,
--             BIZ_TYPE, AUDIENCE_TYPE, EBI_NETREVENUE, PO_TOTALPRICE_USD, NET_REVENUE, PO_QTY, CAMPAIGN_DAY, CAMPAIGN_TAG, DT_UPDATE, ID_CAMPAIGN, PO_STATUS,
--             PRODUCT_CATEGORY, PREVIOUS_YEAR, DEDUP)
--         SELECT 
--             s.ID, s.SUBSIDIARY, s.PO_DATE, s.PODATE_MONTH, s.PODATE_YEAR, s.PO_ORDERID, s.PO_DEVICETYPE, s.PO_SKU, s.DIVISION, s.PRODUCT, s.PRODUCT_GROUP,
--             s.PRODUCT_FAMILY, s.PO_STORENAME, s.BIZ_TYPE, s.AUDIENCE_TYPE, s.EBI_NETREVENUE, s.PO_TOTALPRICE_USD, s.NET_REVENUE, s.PO_QTY, s.CAMPAIGN_DAY,
--             s.CAMPAIGN_TAG, s.DT_UPDATE, s.ID_CAMPAIGN, s.PO_STATUS, s.PRODUCT_CATEGORY, s.PREVIOUS_YEAR, s.DEDUP
--         FROM TMP_SALES_CAMPAIGN_UPDATE s
--         LEFT JOIN OW_LAO.TMP_SALES_CAMPAIGN t
--           ON t.ID = s.ID AND t.ID_CAMPAIGN = s.ID_CAMPAIGN
--         WHERE t.ID IS NULL;
-- 
--         PERFORM DROP TABLE IF EXISTS TMP_SALES_CAMPAIGN_UPDATE;
-- 
--     ELSIF CONSULTA = 'EXEC_ODS_SALES_CAMPAIGN' THEN
--         -- Delete removed/changed rows
--         PERFORM DELETE FROM OW_LAO.ODS_SALES_CAMPAIGN A
--         WHERE NOT EXISTS (
--             SELECT 1
--             FROM OW_LAO.TMP_SALES_CAMPAIGN B
--             WHERE A.ID = B.ID
--               AND A.ID_CAMPAIGN = B.ID_CAMPAIGN
--               AND A.DT_UPDATE = B.DT_UPDATE
--         );
-- 
--         PERFORM DROP TABLE IF EXISTS ODS_SALES_CAMPAIGN_UPDATE;
--         PERFORM CREATE LOCAL TEMPORARY TABLE ODS_SALES_CAMPAIGN_UPDATE ON COMMIT PRESERVE ROWS AS
--         SELECT DISTINCT 
--             A.ID,
--             A.SUBSIDIARY,
--             A.PO_DATE,
--             A.PODATE_MONTH,
--             A.PODATE_YEAR,
--             A.PO_ORDERID,
--             A.PO_DEVICETYPE,
--             A.PO_SKU,
--             A.DIVISION,
--             A.PRODUCT,
--             A.PRODUCT_GROUP,
--             A.PRODUCT_FAMILY,
--             A.PO_STORENAME,
--             CASE WHEN A.PO_DEVICETYPE = 'MOBILEAPP' THEN 'APP' ELSE A.BIZ_TYPE END AS BIZ_TYPE,
--             A.AUDIENCE_TYPE,
--             A.EBI_NETREVENUE,
--             A.PO_TOTALPRICE_USD,
--             A.NET_REVENUE,
--             A.PO_QTY,
--             A.CAMPAIGN_DAY,
--             A.CAMPAIGN_TAG,
--             A.DT_UPDATE,
--             A.PO_STATUS,
--             A.PRODUCT_CATEGORY,
--             A.PREVIOUS_YEAR,
--             A.ID_CAMPAIGN 
--         FROM OW_LAO.TMP_SALES_CAMPAIGN A
--         WHERE DEDUP = 1  
--           AND NOT EXISTS (
--                 SELECT 1
--                 FROM OW_LAO.ODS_SALES_CAMPAIGN B
--                 WHERE A.ID = B.ID
--                   AND A.ID_CAMPAIGN = B.ID_CAMPAIGN
--                   AND A.DT_UPDATE = B.DT_UPDATE
--             );
-- 
--         -- Update existing rows
--         PERFORM UPDATE OW_LAO.ODS_SALES_CAMPAIGN t
--         SET 
--             ID = s.ID,
--             SUBSIDIARY = s.SUBSIDIARY,
--             PO_DATE = s.PO_DATE,
--             PODATE_MONTH = s.PODATE_MONTH,
--             PODATE_YEAR = s.PODATE_YEAR,
--             PO_ORDERID = s.PO_ORDERID,
--             PO_DEVICETYPE = s.PO_DEVICETYPE,
--             PO_SKU = s.PO_SKU,
--             DIVISION = s.DIVISION,
--             PRODUCT = s.PRODUCT,
--             PRODUCT_GROUP = s.PRODUCT_GROUP,
--             PRODUCT_FAMILY = s.PRODUCT_FAMILY,
--             PO_STORENAME = s.PO_STORENAME,
--             BIZ_TYPE = s.BIZ_TYPE,
--             AUDIENCE_TYPE = s.AUDIENCE_TYPE,
--             EBI_NETREVENUE = s.EBI_NETREVENUE,
--             PO_TOTALPRICE_USD = s.PO_TOTALPRICE_USD,
--             NET_REVENUE = s.NET_REVENUE,
--             PO_QTY = s.PO_QTY,
--             CAMPAIGN_DAY = s.CAMPAIGN_DAY,
--             CAMPAIGN_TAG = s.CAMPAIGN_TAG,
--             DT_UPDATE = s.DT_UPDATE,
--             PO_STATUS = s.PO_STATUS,
--             PRODUCT_CATEGORY = s.PRODUCT_CATEGORY,
--             PREVIOUS_YEAR = s.PREVIOUS_YEAR,
--             ID_CAMPAIGN = s.ID_CAMPAIGN
--         FROM ODS_SALES_CAMPAIGN_UPDATE s
--         WHERE t.ID = s.ID AND t.ID_CAMPAIGN = s.ID_CAMPAIGN;
-- 
--         -- Insert new rows
--         PERFORM INSERT INTO OW_LAO.ODS_SALES_CAMPAIGN (
--             ID, SUBSIDIARY, PO_DATE, PODATE_MONTH, PODATE_YEAR, PO_ORDERID, PO_DEVICETYPE, PO_SKU, DIVISION, PRODUCT, PRODUCT_GROUP, PRODUCT_FAMILY,
--             PO_STORENAME, BIZ_TYPE, AUDIENCE_TYPE, EBI_NETREVENUE, PO_TOTALPRICE_USD, NET_REVENUE, PO_QTY, CAMPAIGN_DAY, CAMPAIGN_TAG, DT_UPDATE, PO_STATUS,
--             PRODUCT_CATEGORY, PREVIOUS_YEAR, ID_CAMPAIGN)
--         SELECT 
--             s.ID, s.SUBSIDIARY, s.PO_DATE, s.PODATE_MONTH, s.PODATE_YEAR, s.PO_ORDERID, s.PO_DEVICETYPE, s.PO_SKU, s.DIVISION, s.PRODUCT, s.PRODUCT_GROUP,
--             s.PRODUCT_FAMILY, s.PO_STORENAME, s.BIZ_TYPE, s.AUDIENCE_TYPE, s.EBI_NETREVENUE, s.PO_TOTALPRICE_USD, s.NET_REVENUE, s.PO_QTY, s.CAMPAIGN_DAY,
--             s.CAMPAIGN_TAG, s.DT_UPDATE, s.PO_STATUS, s.PRODUCT_CATEGORY, s.PREVIOUS_YEAR, s.ID_CAMPAIGN
--         FROM ODS_SALES_CAMPAIGN_UPDATE s
--         LEFT JOIN OW_LAO.ODS_SALES_CAMPAIGN t
--           ON t.ID = s.ID AND t.ID_CAMPAIGN = s.ID_CAMPAIGN
--         WHERE t.ID IS NULL;
-- 
--         PERFORM DROP TABLE IF EXISTS ODS_SALES_CAMPAIGN_UPDATE;
-- 
--     ELSE
--         SELECT 'Procedimento não declaro' AS CONSULTA;
--     END IF;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 339.55 of source string: syntax error, unexpected ;, expecting INTO, Sqlstate: 42601, Position: 16032, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
-- CREATE OR REPLACE PROCEDURE OW_LAO.HOMOLOG_PROC_SALES_CAMPAIGN(
--     IN CONSULTA VARCHAR(40),
--     IN CAMPAIGN_TAG VARCHAR(400)
-- )
-- LANGUAGE PLvSQL AS $$
-- DECLARE
--     v_consulta      VARCHAR(40) := CONSULTA;
--     v_campaign_tag  VARCHAR(400) := CAMPAIGN_TAG;
-- BEGIN
--     IF v_consulta = 'EXEC_UPDATE_CAMPAIGN_NAME' THEN
--         PERFORM TRUNCATE TABLE OW_LAO.TMP_UPDATE_CAMPAIGN_NAME;
-- 
--         PERFORM INSERT INTO OW_LAO.TMP_UPDATE_CAMPAIGN_NAME
--         SELECT ID_CAMPAIGN
--         FROM (
--             SELECT 
--                 A.CAMPAIGN_TAG,
--                 A.SUBSIDIARY,
--                 A.DIVISION,
--                 A.BIZ_TYPE,
--                 A.PO_DEVICETYPE,
--                 A.INITIAL_DATE,
--                 A.FINAL_DATE,
--                 A.PRODUCT,
--                 A.PRODUCT_GROUP,
--                 A.PO_SKU,
--                 A.ID_CAMPAIGN,
--                 B.CAMPAIGN_TAG AS TAG_DELETE
--             FROM OW_LAO.DIM_CAMPAIGN_NAME A
--             FULL OUTER JOIN OW_LAO.TMP_CAMPAIGN_NAME B
--               ON COALESCE(A.CAMPAIGN_TAG,'')              = COALESCE(B.CAMPAIGN_TAG,'')
--              AND COALESCE(A.SUBSIDIARY,'')               = COALESCE(B.SUBSIDIARY,'')
--              AND COALESCE(A.PO_DEVICETYPE,'')            = COALESCE(B.PO_DEVICETYPE,'')
--              AND COALESCE(TO_CHAR(A.INITIAL_DATE,'YYYY-MM-DD'),'') = COALESCE(TO_CHAR(B.INITIAL_DATE,'YYYY-MM-DD'),'')
--              AND COALESCE(TO_CHAR(A.FINAL_DATE,'YYYY-MM-DD'),'')   = COALESCE(TO_CHAR(B.FINAL_DATE,'YYYY-MM-DD'),'')
--              AND COALESCE(A.DIVISION,'')                 = COALESCE(B.DIVISION,'')
--              AND COALESCE(A.BIZ_TYPE,'')                 = COALESCE(B.BIZ_TYPE,'')
--              AND COALESCE(A.PRODUCT,'')                  = COALESCE(B.PRODUCT,'')
--              AND COALESCE(A.PRODUCT_GROUP,'')            = COALESCE(B.PRODUCT_GROUP,'')
--              AND COALESCE(A.PO_SKU,'')                   = COALESCE(B.PO_SKU,'')
--              AND COALESCE(A.AUDIENCE_TYPE,'')            = COALESCE(B.AUDIENCE_TYPE,'')
--             WHERE A.CAMPAIGN_TAG IS NOT NULL
--         ) AS TBL
--         WHERE TAG_DELETE IS NULL;
-- 
--         PERFORM DELETE FROM OW_LAO.TMP_SALES_CAMPAIGN 
--          WHERE ID_CAMPAIGN IN (SELECT ID_CAMPAIGN FROM OW_LAO.TMP_UPDATE_CAMPAIGN_NAME);
-- 
--         PERFORM DELETE FROM OW_LAO.DIM_CAMPAIGN_NAME 
--          WHERE ID_CAMPAIGN IN (SELECT ID_CAMPAIGN FROM OW_LAO.TMP_UPDATE_CAMPAIGN_NAME);
-- 
--         PERFORM INSERT INTO OW_LAO.DIM_CAMPAIGN_NAME(
--             CAMPAIGN_TAG,SUBSIDIARY,DIVISION,BIZ_TYPE,PO_DEVICETYPE,INITIAL_DATE,FINAL_DATE,PRODUCT,PRODUCT_GROUP,PO_SKU,AUDIENCE_TYPE)
--         SELECT 
--             B.CAMPAIGN_TAG,
--             B.SUBSIDIARY,
--             B.DIVISION,
--             B.BIZ_TYPE,
--             B.PO_DEVICETYPE,
--             B.INITIAL_DATE,
--             B.FINAL_DATE,
--             B.PRODUCT,
--             B.PRODUCT_GROUP,
--             B.PO_SKU,
--             B.AUDIENCE_TYPE
--         FROM OW_LAO.DIM_CAMPAIGN_NAME A
--         FULL OUTER JOIN OW_LAO.TMP_CAMPAIGN_NAME B
--           ON COALESCE(A.CAMPAIGN_TAG,'')              = COALESCE(B.CAMPAIGN_TAG,'')
--          AND COALESCE(A.SUBSIDIARY,'')               = COALESCE(B.SUBSIDIARY,'')
--          AND COALESCE(A.PO_DEVICETYPE,'')            = COALESCE(B.PO_DEVICETYPE,'')
--          AND COALESCE(TO_CHAR(A.INITIAL_DATE,'YYYY-MM-DD'),'') = COALESCE(TO_CHAR(B.INITIAL_DATE,'YYYY-MM-DD'),'')
--          AND COALESCE(TO_CHAR(A.FINAL_DATE,'YYYY-MM-DD'),'')   = COALESCE(TO_CHAR(B.FINAL_DATE,'YYYY-MM-DD'),'')
--          AND COALESCE(A.DIVISION,'')                 = COALESCE(B.DIVISION,'')
--          AND COALESCE(A.BIZ_TYPE,'')                 = COALESCE(B.BIZ_TYPE,'')
--          AND COALESCE(A.PRODUCT,'')                  = COALESCE(B.PRODUCT,'')
--          AND COALESCE(A.PRODUCT_GROUP,'')            = COALESCE(B.PRODUCT_GROUP,'')
--          AND COALESCE(A.PO_SKU,'')                   = COALESCE(B.PO_SKU,'')
--          AND COALESCE(A.AUDIENCE_TYPE,'')            = COALESCE(B.AUDIENCE_TYPE,'')
--         WHERE B.CAMPAIGN_TAG IS NOT NULL
--           AND A.ID_CAMPAIGN IS NULL;
-- 
--         PERFORM TRUNCATE TABLE OW_LAO.TMP_UPDATE_CAMPAIGN_NAME;
-- 
--         PERFORM UPDATE OW_LAO.DIM_CAMPAIGN_NAME d
--         SET
--             INITIAL_DATE_LY = TIMESTAMPADD(DAY, 
--                                 CASE WHEN EXTRACT(DOY FROM (DATE_TRUNC('year', d.INITIAL_DATE) + INTERVAL '1 year' - INTERVAL '1 day')) = 366
--                                      THEN COALESCE(rt."YEAR", ra."YEAR")
--                                      ELSE COALESCE(rt."LEAP_YEAR", ra."LEAP_YEAR")
--                                 END,
--                                 d.INITIAL_DATE),
--             FINAL_DATE_LY   = TIMESTAMPADD(DAY, 
--                                 CASE WHEN EXTRACT(DOY FROM (DATE_TRUNC('year', d.FINAL_DATE) + INTERVAL '1 year' - INTERVAL '1 day')) = 366
--                                      THEN COALESCE(rt."YEAR", ra."YEAR")
--                                      ELSE COALESCE(rt."LEAP_YEAR", ra."LEAP_YEAR")
--                                 END,
--                                 d.FINAL_DATE)
--         FROM OW_LAO.DIM_CAMPAIGN_NAME_RULE rt
--         LEFT JOIN OW_LAO.DIM_CAMPAIGN_NAME_RULE ra ON ra.CAMPAIGN_TAG = 'ALL'
--         WHERE d.CAMPAIGN_TAG = rt.CAMPAIGN_TAG;
-- 
--     ELSIF v_consulta = 'EXEC_TMP_SALES_CAMPAIGN' THEN
--         PERFORM DELETE FROM OW_LAO.TMP_SALES_CAMPAIGN A
--         WHERE A.CAMPAIGN_TAG = v_campaign_tag
--           AND NOT EXISTS (
--                 SELECT 1
--                 FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE B
--                 WHERE A.ID = B.ID
--             );
-- 
--         PERFORM TRUNCATE TABLE OW_LAO.TMP_CAMPAIGN_NAME_PREVIOUS_YEAR;
-- 
--         PERFORM INSERT INTO OW_LAO.TMP_CAMPAIGN_NAME_PREVIOUS_YEAR
--         SELECT * FROM (
--             SELECT 
--                 CAMPAIGN_TAG, SUBSIDIARY, DIVISION, BIZ_TYPE, PO_DEVICETYPE, 
--                 INITIAL_DATE_LY,
--                 TIMESTAMPADD(DAY,
--                     DATEDIFF('day', INITIAL_DATE, CASE WHEN CURRENT_DATE >= FINAL_DATE THEN FINAL_DATE ELSE CURRENT_DATE END),
--                     INITIAL_DATE_LY) AS FINAL_DATE,
--                 PRODUCT, PRODUCT_GROUP, PO_SKU, ID_CAMPAIGN, AUDIENCE_TYPE,
--                 DATEDIFF('day', INITIAL_DATE, CASE WHEN CURRENT_DATE >= FINAL_DATE THEN FINAL_DATE ELSE CURRENT_DATE END) + 1 AS CAMPAIGN_DAY,
--                 TRUE AS PREVIOUS_YEAR
--             FROM OW_LAO.DIM_CAMPAIGN_NAME
--             UNION ALL
--             SELECT 
--                 CAMPAIGN_TAG, SUBSIDIARY, DIVISION, BIZ_TYPE, PO_DEVICETYPE, INITIAL_DATE, FINAL_DATE, PRODUCT, PRODUCT_GROUP, PO_SKU, ID_CAMPAIGN, AUDIENCE_TYPE,
--                 DATEDIFF('day', INITIAL_DATE, FINAL_DATE) + 1 AS CAMPAIGN_DAY,
--                 FALSE AS PREVIOUS_YEAR
--             FROM OW_LAO.DIM_CAMPAIGN_NAME
--         ) A
--         WHERE A.CAMPAIGN_TAG = v_campaign_tag;
-- 
--         PERFORM DROP TABLE IF EXISTS TMP_SALES_CAMPAIGN_UPDATE;
--         PERFORM CREATE LOCAL TEMPORARY TABLE TMP_SALES_CAMPAIGN_UPDATE ON COMMIT PRESERVE ROWS AS
--         SELECT DISTINCT 
--             A.ID,
--             CASE WHEN A.SUBSIDIARY LIKE 'SELA%' THEN 'SELA' ELSE A.SUBSIDIARY END AS SUBSIDIARY,
--             A.PO_DATE,
--             A.PODATE_MONTH,
--             A.PODATE_YEAR,
--             A.PO_ORDERID,
--             A.PO_DEVICETYPE,
--             A.PO_SKU,
--             A.DIVISION,
--             A.PRODUCT,
--             A.PRODUCT_GROUP,
--             A.PRODUCT_FAMILY,
--             A.PO_STORENAME,
--             A.BIZ_TYPE,
--             A.AUDIENCE_TYPE,
--             A.EBI_NETREVENUE,
--             A.PO_TOTALPRICE_USD,
--             A.NET_REVENUE,
--             A.PO_QTY,
--             DATEDIFF('day', B.INITIAL_DATE, A.PO_DATE) + 1 AS CAMPAIGN_DAY,
--             B.CAMPAIGN_TAG,
--             GREATEST(
--                 COALESCE(A.UPDATED_DATETIME, A.INSETED_DATETIME),
--                 COALESCE(A.EBI_LAST_UPDATE_DATE, A.INSETED_DATETIME),
--                 COALESCE(A.PO_LASTUPDATE_DATE_HOUR, A.INSETED_DATETIME),
--                 COALESCE(A.PO_SOURCE_LAST_UPDATE_DATE, A.INSETED_DATETIME),
--                 COALESCE(A.PO_SOURCE_PAYMENT_LAST_UPDATE_DATE, A.INSETED_DATETIME)
--             ) AS DT_UPDATE,
--             B.ID_CAMPAIGN,
--             A.PO_STATUS,
--             A.PRODUCT_CATEGORY,
--             B.PREVIOUS_YEAR,
--             ROW_NUMBER() OVER (
--                 PARTITION BY ID, CAMPAIGN_TAG
--                 ORDER BY ID
--             ) AS DEDUP
--         FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A
--         JOIN OW_LAO.TMP_CAMPAIGN_NAME_PREVIOUS_YEAR B
--           ON A.PO_DATE BETWEEN B.INITIAL_DATE AND B.FINAL_DATE
--          AND (B.SUBSIDIARY IS NULL OR (CASE WHEN A.SUBSIDIARY LIKE 'SELA%' THEN 'SELA' ELSE A.SUBSIDIARY END) = B.SUBSIDIARY)
--          AND (B.DIVISION IS NULL OR A.DIVISION = B.DIVISION)
--          AND (B.BIZ_TYPE IS NULL OR A.BIZ_TYPE = B.BIZ_TYPE)
--          AND (B.PO_DEVICETYPE IS NULL OR A.PO_DEVICETYPE = B.PO_DEVICETYPE)
--          AND (B.PRODUCT IS NULL OR A.PRODUCT = B.PRODUCT)
--          AND (B.PRODUCT_GROUP IS NULL OR A.PRODUCT_GROUP = B.PRODUCT_GROUP)
--          AND (B.PO_SKU IS NULL OR A.PO_SKU = B.PO_SKU)
--          AND (B.AUDIENCE_TYPE IS NULL OR A.AUDIENCE_TYPE = B.AUDIENCE_TYPE)
--         WHERE B.CAMPAIGN_DAY >= 1
--           AND NOT EXISTS (
--                 SELECT 1
--                 FROM OW_LAO.TMP_SALES_CAMPAIGN C
--                 WHERE (A.ID = C.ID AND B.ID_CAMPAIGN = C.ID_CAMPAIGN)
--                   AND GREATEST(
--                         COALESCE(A.UPDATED_DATETIME, A.INSETED_DATETIME),
--                         COALESCE(A.EBI_LAST_UPDATE_DATE, A.INSETED_DATETIME),
--                         COALESCE(A.PO_LASTUPDATE_DATE_HOUR, A.INSETED_DATETIME),
--                         COALESCE(A.PO_SOURCE_LAST_UPDATE_DATE, A.INSETED_DATETIME),
--                         COALESCE(A.PO_SOURCE_PAYMENT_LAST_UPDATE_DATE, A.INSETED_DATETIME)
--                     ) = C.DT_UPDATE
--             );
-- 
--         -- Update existing rows
--         PERFORM UPDATE OW_LAO.TMP_SALES_CAMPAIGN t
--         SET 
--             ID = s.ID,
--             SUBSIDIARY = s.SUBSIDIARY,
--             PO_DATE = s.PO_DATE,
--             PODATE_MONTH = s.PODATE_MONTH,
--             PODATE_YEAR = s.PODATE_YEAR,
--             PO_ORDERID = s.PO_ORDERID,
--             PO_DEVICETYPE = s.PO_DEVICETYPE,
--             PO_SKU = s.PO_SKU,
--             DIVISION = s.DIVISION,
--             PRODUCT = s.PRODUCT,
--             PRODUCT_GROUP = s.PRODUCT_GROUP,
--             PRODUCT_FAMILY = s.PRODUCT_FAMILY,
--             PO_STORENAME = s.PO_STORENAME,
--             BIZ_TYPE = s.BIZ_TYPE,
--             AUDIENCE_TYPE = s.AUDIENCE_TYPE,
--             EBI_NETREVENUE = s.EBI_NETREVENUE,
--             PO_TOTALPRICE_USD = s.PO_TOTALPRICE_USD,
--             NET_REVENUE = s.NET_REVENUE,
--             PO_QTY = s.PO_QTY,
--             CAMPAIGN_DAY = s.CAMPAIGN_DAY,
--             CAMPAIGN_TAG = s.CAMPAIGN_TAG,
--             DT_UPDATE = s.DT_UPDATE,
--             ID_CAMPAIGN = s.ID_CAMPAIGN,
--             PO_STATUS = s.PO_STATUS,
--             PRODUCT_CATEGORY = s.PRODUCT_CATEGORY,
--             PREVIOUS_YEAR = s.PREVIOUS_YEAR,
--             DEDUP = s.DEDUP
--         FROM TMP_SALES_CAMPAIGN_UPDATE s
--         WHERE t.ID = s.ID AND t.ID_CAMPAIGN = s.ID_CAMPAIGN;
-- 
--         -- Insert new rows
--         PERFORM INSERT INTO OW_LAO.TMP_SALES_CAMPAIGN (
--             ID, SUBSIDIARY, PO_DATE, PODATE_MONTH, PODATE_YEAR, PO_ORDERID, PO_DEVICETYPE, PO_SKU, DIVISION, PRODUCT, PRODUCT_GROUP, PRODUCT_FAMILY, PO_STORENAME,
--             BIZ_TYPE, AUDIENCE_TYPE, EBI_NETREVENUE, PO_TOTALPRICE_USD, NET_REVENUE, PO_QTY, CAMPAIGN_DAY, CAMPAIGN_TAG, DT_UPDATE, ID_CAMPAIGN, PO_STATUS,
--             PRODUCT_CATEGORY, PREVIOUS_YEAR, DEDUP)
--         SELECT 
--             s.ID, s.SUBSIDIARY, s.PO_DATE, s.PODATE_MONTH, s.PODATE_YEAR, s.PO_ORDERID, s.PO_DEVICETYPE, s.PO_SKU, s.DIVISION, s.PRODUCT, s.PRODUCT_GROUP,
--             s.PRODUCT_FAMILY, s.PO_STORENAME, s.BIZ_TYPE, s.AUDIENCE_TYPE, s.EBI_NETREVENUE, s.PO_TOTALPRICE_USD, s.NET_REVENUE, s.PO_QTY, s.CAMPAIGN_DAY,
--             s.CAMPAIGN_TAG, s.DT_UPDATE, s.ID_CAMPAIGN, s.PO_STATUS, s.PRODUCT_CATEGORY, s.PREVIOUS_YEAR, s.DEDUP
--         FROM TMP_SALES_CAMPAIGN_UPDATE s
--         LEFT JOIN OW_LAO.TMP_SALES_CAMPAIGN t
--           ON t.ID = s.ID AND t.ID_CAMPAIGN = s.ID_CAMPAIGN
--         WHERE t.ID IS NULL;
-- 
--         PERFORM DROP TABLE IF EXISTS TMP_SALES_CAMPAIGN_UPDATE;
-- 
--     ELSIF v_consulta = 'EXEC_ODS_SALES_CAMPAIGN' THEN
--         -- Delete removed/changed rows
--         PERFORM DELETE FROM OW_LAO.ODS_SALES_CAMPAIGN A
--         WHERE NOT EXISTS (
--             SELECT 1
--             FROM OW_LAO.TMP_SALES_CAMPAIGN B
--             WHERE A.ID = B.ID
--               AND A.ID_CAMPAIGN = B.ID_CAMPAIGN
--               AND A.DT_UPDATE = B.DT_UPDATE
--         );
-- 
--         PERFORM DROP TABLE IF EXISTS ODS_SALES_CAMPAIGN_UPDATE;
--         PERFORM CREATE LOCAL TEMPORARY TABLE ODS_SALES_CAMPAIGN_UPDATE ON COMMIT PRESERVE ROWS AS
--         SELECT DISTINCT 
--             A.ID,
--             A.SUBSIDIARY,
--             A.PO_DATE,
--             A.PODATE_MONTH,
--             A.PODATE_YEAR,
--             A.PO_ORDERID,
--             A.PO_DEVICETYPE,
--             A.PO_SKU,
--             A.DIVISION,
--             A.PRODUCT,
--             A.PRODUCT_GROUP,
--             A.PRODUCT_FAMILY,
--             A.PO_STORENAME,
--             CASE WHEN A.PO_DEVICETYPE = 'MOBILEAPP' THEN 'APP' ELSE A.BIZ_TYPE END AS BIZ_TYPE,
--             A.AUDIENCE_TYPE,
--             A.EBI_NETREVENUE,
--             A.PO_TOTALPRICE_USD,
--             A.NET_REVENUE,
--             A.PO_QTY,
--             A.CAMPAIGN_DAY,
--             A.CAMPAIGN_TAG,
--             A.DT_UPDATE,
--             A.PO_STATUS,
--             A.PRODUCT_CATEGORY,
--             A.PREVIOUS_YEAR,
--             A.ID_CAMPAIGN 
--         FROM OW_LAO.TMP_SALES_CAMPAIGN A
--         WHERE DEDUP = 1  
--           AND NOT EXISTS (
--                 SELECT 1
--                 FROM OW_LAO.ODS_SALES_CAMPAIGN B
--                 WHERE A.ID = B.ID
--                   AND A.ID_CAMPAIGN = B.ID_CAMPAIGN
--                   AND A.DT_UPDATE = B.DT_UPDATE
--             );
-- 
--         -- Update existing rows
--         PERFORM UPDATE OW_LAO.ODS_SALES_CAMPAIGN t
--         SET 
--             ID = s.ID,
--             SUBSIDIARY = s.SUBSIDIARY,
--             PO_DATE = s.PO_DATE,
--             PODATE_MONTH = s.PODATE_MONTH,
--             PODATE_YEAR = s.PODATE_YEAR,
--             PO_ORDERID = s.PO_ORDERID,
--             PO_DEVICETYPE = s.PO_DEVICETYPE,
--             PO_SKU = s.PO_SKU,
--             DIVISION = s.DIVISION,
--             PRODUCT = s.PRODUCT,
--             PRODUCT_GROUP = s.PRODUCT_GROUP,
--             PRODUCT_FAMILY = s.PRODUCT_FAMILY,
--             PO_STORENAME = s.PO_STORENAME,
--             BIZ_TYPE = s.BIZ_TYPE,
--             AUDIENCE_TYPE = s.AUDIENCE_TYPE,
--             EBI_NETREVENUE = s.EBI_NETREVENUE,
--             PO_TOTALPRICE_USD = s.PO_TOTALPRICE_USD,
--             NET_REVENUE = s.NET_REVENUE,
--             PO_QTY = s.PO_QTY,
--             CAMPAIGN_DAY = s.CAMPAIGN_DAY,
--             CAMPAIGN_TAG = s.CAMPAIGN_TAG,
--             DT_UPDATE = s.DT_UPDATE,
--             PO_STATUS = s.PO_STATUS,
--             PRODUCT_CATEGORY = s.PRODUCT_CATEGORY,
--             PREVIOUS_YEAR = s.PREVIOUS_YEAR,
--             ID_CAMPAIGN = s.ID_CAMPAIGN
--         FROM ODS_SALES_CAMPAIGN_UPDATE s
--         WHERE t.ID = s.ID AND t.ID_CAMPAIGN = s.ID_CAMPAIGN;
-- 
--         -- Insert new rows
--         PERFORM INSERT INTO OW_LAO.ODS_SALES_CAMPAIGN (
--             ID, SUBSIDIARY, PO_DATE, PODATE_MONTH, PODATE_YEAR, PO_ORDERID, PO_DEVICETYPE, PO_SKU, DIVISION, PRODUCT, PRODUCT_GROUP, PRODUCT_FAMILY,
--             PO_STORENAME, BIZ_TYPE, AUDIENCE_TYPE, EBI_NETREVENUE, PO_TOTALPRICE_USD, NET_REVENUE, PO_QTY, CAMPAIGN_DAY, CAMPAIGN_TAG, DT_UPDATE, PO_STATUS,
--             PRODUCT_CATEGORY, PREVIOUS_YEAR, ID_CAMPAIGN)
--         SELECT 
--             s.ID, s.SUBSIDIARY, s.PO_DATE, s.PODATE_MONTH, s.PODATE_YEAR, s.PO_ORDERID, s.PO_DEVICETYPE, s.PO_SKU, s.DIVISION, s.PRODUCT, s.PRODUCT_GROUP,
--             s.PRODUCT_FAMILY, s.PO_STORENAME, s.BIZ_TYPE, s.AUDIENCE_TYPE, s.EBI_NETREVENUE, s.PO_TOTALPRICE_USD, s.NET_REVENUE, s.PO_QTY, s.CAMPAIGN_DAY,
--             s.CAMPAIGN_TAG, s.DT_UPDATE, s.PO_STATUS, s.PRODUCT_CATEGORY, s.PREVIOUS_YEAR, s.ID_CAMPAIGN
--         FROM ODS_SALES_CAMPAIGN_UPDATE s
--         LEFT JOIN OW_LAO.ODS_SALES_CAMPAIGN t
--           ON t.ID = s.ID AND t.ID_CAMPAIGN = s.ID_CAMPAIGN
--         WHERE t.ID IS NULL;
-- 
--         PERFORM DROP TABLE IF EXISTS ODS_SALES_CAMPAIGN_UPDATE;
--     END IF;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: Syntax error at or near "A", Sqlstate: 42601, Position: 5252, Routine: base_yyerror, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/scan.l, Line: 1056, Error Code: 4856, 
CREATE OR REPLACE PROCEDURE OW_LAO._test_min()
LANGUAGE PLvSQL AS $$
BEGIN
  PERFORM INSERT INTO OW_LAO.TMP_UPDATE_CAMPAIGN_NAME
  SELECT ID_CAMPAIGN
  FROM (
    SELECT A.ID_CAMPAIGN, B.CAMPAIGN_TAG AS TAG_DELETE
    FROM OW_LAO.DIM_CAMPAIGN_NAME A
    FULL OUTER JOIN OW_LAO.TMP_CAMPAIGN_NAME B
      ON COALESCE(A.CAMPAIGN_TAG,'') = COALESCE(B.CAMPAIGN_TAG,'')
  ) t
  WHERE TAG_DELETE IS NULL;
END;
$$;

-- CALL OW_LAO._test_min();
-- ERROR: Severity: ERROR, Message: Relation "OW_LAO.DIM_CAMPAIGN_NAME" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure _test_min line 3 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
CREATE OR REPLACE PROCEDURE OW_LAO.HOMOLOG_PROC_SALES_CAMPAIGN(
    IN CONSULTA VARCHAR(40),
    IN CAMPAIGN_TAG VARCHAR(400)
)
LANGUAGE PLvSQL AS $$
DECLARE
  v_campaign_tag VARCHAR(400) := CAMPAIGN_TAG;
BEGIN
  IF CONSULTA = 'EXEC_UPDATE_CAMPAIGN_NAME' THEN
    PERFORM TRUNCATE TABLE OW_LAO.TMP_UPDATE_CAMPAIGN_NAME;

    PERFORM INSERT INTO OW_LAO.TMP_UPDATE_CAMPAIGN_NAME
    SELECT ID_CAMPAIGN
    FROM (
      SELECT 
        A.CAMPAIGN_TAG,
        A.SUBSIDIARY,
        A.DIVISION,
        A.BIZ_TYPE,
        A.PO_DEVICETYPE,
        A.INITIAL_DATE,
        A.FINAL_DATE,
        A.PRODUCT,
        A.PRODUCT_GROUP,
        A.PO_SKU,
        A.ID_CAMPAIGN,
        B.CAMPAIGN_TAG AS TAG_DELETE
      FROM OW_LAO.DIM_CAMPAIGN_NAME A
      FULL OUTER JOIN OW_LAO.TMP_CAMPAIGN_NAME B
        ON COALESCE(A.CAMPAIGN_TAG,'') = COALESCE(B.CAMPAIGN_TAG,'')
       AND COALESCE(A.SUBSIDIARY,'') = COALESCE(B.SUBSIDIARY,'')
       AND COALESCE(A.PO_DEVICETYPE,'') = COALESCE(B.PO_DEVICETYPE,'')
       AND COALESCE(TO_CHAR(A.INITIAL_DATE,'YYYY-MM-DD'),'') = COALESCE(TO_CHAR(B.INITIAL_DATE,'YYYY-MM-DD'),'')
       AND COALESCE(TO_CHAR(A.FINAL_DATE,'YYYY-MM-DD'),'') = COALESCE(TO_CHAR(B.FINAL_DATE,'YYYY-MM-DD'),'')
       AND COALESCE(A.DIVISION,'') = COALESCE(B.DIVISION,'')
       AND COALESCE(A.BIZ_TYPE,'') = COALESCE(B.BIZ_TYPE,'')
       AND COALESCE(A.PRODUCT,'') = COALESCE(B.PRODUCT,'')
       AND COALESCE(A.PRODUCT_GROUP,'') = COALESCE(B.PRODUCT_GROUP,'')
       AND COALESCE(A.PO_SKU,'') = COALESCE(B.PO_SKU,'')
       AND COALESCE(A.AUDIENCE_TYPE,'') = COALESCE(B.AUDIENCE_TYPE,'')
      WHERE A.CAMPAIGN_TAG IS NOT NULL
    ) t
    WHERE TAG_DELETE IS NULL;

    PERFORM DELETE FROM OW_LAO.TMP_SALES_CAMPAIGN
     WHERE ID_CAMPAIGN IN (SELECT ID_CAMPAIGN FROM OW_LAO.TMP_UPDATE_CAMPAIGN_NAME);

    PERFORM DELETE FROM OW_LAO.DIM_CAMPAIGN_NAME
     WHERE ID_CAMPAIGN IN (SELECT ID_CAMPAIGN FROM OW_LAO.TMP_UPDATE_CAMPAIGN_NAME);

    PERFORM INSERT INTO OW_LAO.DIM_CAMPAIGN_NAME(
      CAMPAIGN_TAG,SUBSIDIARY,DIVISION,BIZ_TYPE,PO_DEVICETYPE,INITIAL_DATE,FINAL_DATE,PRODUCT,PRODUCT_GROUP,PO_SKU,AUDIENCE_TYPE)
    SELECT 
      B.CAMPAIGN_TAG,
      B.SUBSIDIARY,
      B.DIVISION,
      B.BIZ_TYPE,
      B.PO_DEVICETYPE,
      B.INITIAL_DATE,
      B.FINAL_DATE,
      B.PRODUCT,
      B.PRODUCT_GROUP,
      B.PO_SKU,
      B.AUDIENCE_TYPE
    FROM OW_LAO.DIM_CAMPAIGN_NAME A
    FULL OUTER JOIN OW_LAO.TMP_CAMPAIGN_NAME B
      ON COALESCE(A.CAMPAIGN_TAG,'') = COALESCE(B.CAMPAIGN_TAG,'')
     AND COALESCE(A.SUBSIDIARY,'') = COALESCE(B.SUBSIDIARY,'')
     AND COALESCE(A.PO_DEVICETYPE,'') = COALESCE(B.PO_DEVICETYPE,'')
     AND COALESCE(TO_CHAR(A.INITIAL_DATE,'YYYY-MM-DD'),'') = COALESCE(TO_CHAR(B.INITIAL_DATE,'YYYY-MM-DD'),'')
     AND COALESCE(TO_CHAR(A.FINAL_DATE,'YYYY-MM-DD'),'') = COALESCE(TO_CHAR(B.FINAL_DATE,'YYYY-MM-DD'),'')
     AND COALESCE(A.DIVISION,'') = COALESCE(B.DIVISION,'')
     AND COALESCE(A.BIZ_TYPE,'') = COALESCE(B.BIZ_TYPE,'')
     AND COALESCE(A.PRODUCT,'') = COALESCE(B.PRODUCT,'')
     AND COALESCE(A.PRODUCT_GROUP,'') = COALESCE(B.PRODUCT_GROUP,'')
     AND COALESCE(A.PO_SKU,'') = COALESCE(B.PO_SKU,'')
     AND COALESCE(A.AUDIENCE_TYPE,'') = COALESCE(B.AUDIENCE_TYPE,'')
    WHERE B.CAMPAIGN_TAG IS NOT NULL
      AND A.ID_CAMPAIGN IS NULL;

    PERFORM TRUNCATE TABLE OW_LAO.TMP_UPDATE_CAMPAIGN_NAME;

    PERFORM UPDATE OW_LAO.DIM_CAMPAIGN_NAME
    SET
      INITIAL_DATE_LY = TIMESTAMPADD(DAY,
        CASE WHEN EXTRACT(DOY FROM (DATE_TRUNC('year', OW_LAO.DIM_CAMPAIGN_NAME.INITIAL_DATE) + INTERVAL '1 year' - INTERVAL '1 day')) = 366
             THEN COALESCE(rt."YEAR", ra."YEAR")
             ELSE COALESCE(rt."LEAP_YEAR", ra."LEAP_YEAR") END,
        OW_LAO.DIM_CAMPAIGN_NAME.INITIAL_DATE),
      FINAL_DATE_LY = TIMESTAMPADD(DAY,
        CASE WHEN EXTRACT(DOY FROM (DATE_TRUNC('year', OW_LAO.DIM_CAMPAIGN_NAME.FINAL_DATE) + INTERVAL '1 year' - INTERVAL '1 day')) = 366
             THEN COALESCE(rt."YEAR", ra."YEAR")
             ELSE COALESCE(rt."LEAP_YEAR", ra."LEAP_YEAR") END,
        OW_LAO.DIM_CAMPAIGN_NAME.FINAL_DATE)
    FROM OW_LAO.DIM_CAMPAIGN_NAME_RULE rt
    LEFT JOIN OW_LAO.DIM_CAMPAIGN_NAME_RULE ra ON ra.CAMPAIGN_TAG = 'ALL'
    WHERE OW_LAO.DIM_CAMPAIGN_NAME.CAMPAIGN_TAG = rt.CAMPAIGN_TAG;

  ELSIF CONSULTA = 'EXEC_TMP_SALES_CAMPAIGN' THEN
    PERFORM DELETE FROM OW_LAO.TMP_SALES_CAMPAIGN
    WHERE CAMPAIGN_TAG = v_campaign_tag
      AND NOT EXISTS (
        SELECT 1
        FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE b
        WHERE OW_LAO.TMP_SALES_CAMPAIGN.ID = b.ID
      );

    PERFORM TRUNCATE TABLE OW_LAO.TMP_CAMPAIGN_NAME_PREVIOUS_YEAR;

    PERFORM INSERT INTO OW_LAO.TMP_CAMPAIGN_NAME_PREVIOUS_YEAR
    SELECT * FROM (
      SELECT 
        CAMPAIGN_TAG, SUBSIDIARY, DIVISION, BIZ_TYPE, PO_DEVICETYPE,
        INITIAL_DATE_LY,
        TIMESTAMPADD(DAY,
          DATEDIFF('day', INITIAL_DATE, CASE WHEN CURRENT_DATE >= FINAL_DATE THEN FINAL_DATE ELSE CURRENT_DATE END),
          INITIAL_DATE_LY) AS FINAL_DATE,
        PRODUCT, PRODUCT_GROUP, PO_SKU, ID_CAMPAIGN, AUDIENCE_TYPE,
        DATEDIFF('day', INITIAL_DATE, CASE WHEN CURRENT_DATE >= FINAL_DATE THEN FINAL_DATE ELSE CURRENT_DATE END) + 1 AS CAMPAIGN_DAY,
        TRUE AS PREVIOUS_YEAR
      FROM OW_LAO.DIM_CAMPAIGN_NAME
      UNION ALL
      SELECT 
        CAMPAIGN_TAG, SUBSIDIARY, DIVISION, BIZ_TYPE, PO_DEVICETYPE,
        INITIAL_DATE, FINAL_DATE, PRODUCT, PRODUCT_GROUP, PO_SKU, ID_CAMPAIGN, AUDIENCE_TYPE,
        DATEDIFF('day', INITIAL_DATE, FINAL_DATE) + 1 AS CAMPAIGN_DAY,
        FALSE AS PREVIOUS_YEAR
      FROM OW_LAO.DIM_CAMPAIGN_NAME
    ) a
    WHERE a.CAMPAIGN_TAG = v_campaign_tag;

    PERFORM DROP TABLE IF EXISTS TMP_SALES_CAMPAIGN_UPDATE;
    PERFORM CREATE LOCAL TEMPORARY TABLE TMP_SALES_CAMPAIGN_UPDATE ON COMMIT PRESERVE ROWS AS
    SELECT DISTINCT 
      a.ID,
      CASE WHEN a.SUBSIDIARY LIKE 'SELA%' THEN 'SELA' ELSE a.SUBSIDIARY END AS SUBSIDIARY,
      a.PO_DATE,
      a.PODATE_MONTH,
      a.PODATE_YEAR,
      a.PO_ORDERID,
      a.PO_DEVICETYPE,
      a.PO_SKU,
      a.DIVISION,
      a.PRODUCT,
      a.PRODUCT_GROUP,
      a.PRODUCT_FAMILY,
      a.PO_STORENAME,
      a.BIZ_TYPE,
      a.AUDIENCE_TYPE,
      a.EBI_NETREVENUE,
      a.PO_TOTALPRICE_USD,
      a.NET_REVENUE,
      a.PO_QTY,
      DATEDIFF('day', b.INITIAL_DATE, a.PO_DATE) + 1 AS CAMPAIGN_DAY,
      b.CAMPAIGN_TAG,
      GREATEST(
        COALESCE(a.UPDATED_DATETIME, a.INSETED_DATETIME),
        COALESCE(a.EBI_LAST_UPDATE_DATE, a.INSETED_DATETIME),
        COALESCE(a.PO_LASTUPDATE_DATE_HOUR, a.INSETED_DATETIME),
        COALESCE(a.PO_SOURCE_LAST_UPDATE_DATE, a.INSETED_DATETIME),
        COALESCE(a.PO_SOURCE_PAYMENT_LAST_UPDATE_DATE, a.INSETED_DATETIME)
      ) AS DT_UPDATE,
      b.ID_CAMPAIGN,
      a.PO_STATUS,
      a.PRODUCT_CATEGORY,
      b.PREVIOUS_YEAR,
      ROW_NUMBER() OVER (PARTITION BY ID, CAMPAIGN_TAG ORDER BY ID) AS DEDUP
    FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE a
    JOIN OW_LAO.TMP_CAMPAIGN_NAME_PREVIOUS_YEAR b
      ON a.PO_DATE BETWEEN b.INITIAL_DATE AND b.FINAL_DATE
     AND (b.SUBSIDIARY IS NULL OR (CASE WHEN a.SUBSIDIARY LIKE 'SELA%' THEN 'SELA' ELSE a.SUBSIDIARY END) = b.SUBSIDIARY)
     AND (b.DIVISION IS NULL OR a.DIVISION = b.DIVISION)
     AND (b.BIZ_TYPE IS NULL OR a.BIZ_TYPE = b.BIZ_TYPE)
     AND (b.PO_DEVICETYPE IS NULL OR a.PO_DEVICETYPE = b.PO_DEVICETYPE)
     AND (b.PRODUCT IS NULL OR a.PRODUCT = b.PRODUCT)
     AND (b.PRODUCT_GROUP IS NULL OR a.PRODUCT_GROUP = b.PRODUCT_GROUP)
     AND (b.PO_SKU IS NULL OR a.PO_SKU = b.PO_SKU)
     AND (b.AUDIENCE_TYPE IS NULL OR a.AUDIENCE_TYPE = b.AUDIENCE_TYPE)
    WHERE b.CAMPAIGN_DAY >= 1
      AND NOT EXISTS (
        SELECT 1
        FROM OW_LAO.TMP_SALES_CAMPAIGN c
        WHERE (a.ID = c.ID AND b.ID_CAMPAIGN = c.ID_CAMPAIGN)
          AND GREATEST(
            COALESCE(a.UPDATED_DATETIME, a.INSETED_DATETIME),
            COALESCE(a.EBI_LAST_UPDATE_DATE, a.INSETED_DATETIME),
            COALESCE(a.PO_LASTUPDATE_DATE_HOUR, a.INSETED_DATETIME),
            COALESCE(a.PO_SOURCE_LAST_UPDATE_DATE, a.INSETED_DATETIME),
            COALESCE(a.PO_SOURCE_PAYMENT_LAST_UPDATE_DATE, a.INSETED_DATETIME)
          ) = c.DT_UPDATE
      );

    PERFORM UPDATE OW_LAO.TMP_SALES_CAMPAIGN
    SET 
      ID = s.ID,
      SUBSIDIARY = s.SUBSIDIARY,
      PO_DATE = s.PO_DATE,
      PODATE_MONTH = s.PODATE_MONTH,
      PODATE_YEAR = s.PODATE_YEAR,
      PO_ORDERID = s.PO_ORDERID,
      PO_DEVICETYPE = s.PO_DEVICETYPE,
      PO_SKU = s.PO_SKU,
      DIVISION = s.DIVISION,
      PRODUCT = s.PRODUCT,
      PRODUCT_GROUP = s.PRODUCT_GROUP,
      PRODUCT_FAMILY = s.PRODUCT_FAMILY,
      PO_STORENAME = s.PO_STORENAME,
      BIZ_TYPE = s.BIZ_TYPE,
      AUDIENCE_TYPE = s.AUDIENCE_TYPE,
      EBI_NETREVENUE = s.EBI_NETREVENUE,
      PO_TOTALPRICE_USD = s.PO_TOTALPRICE_USD,
      NET_REVENUE = s.NET_REVENUE,
      PO_QTY = s.PO_QTY,
      CAMPAIGN_DAY = s.CAMPAIGN_DAY,
      CAMPAIGN_TAG = s.CAMPAIGN_TAG,
      DT_UPDATE = s.DT_UPDATE,
      ID_CAMPAIGN = s.ID_CAMPAIGN,
      PO_STATUS = s.PO_STATUS,
      PRODUCT_CATEGORY = s.PRODUCT_CATEGORY,
      PREVIOUS_YEAR = s.PREVIOUS_YEAR,
      DEDUP = s.DEDUP
    FROM TMP_SALES_CAMPAIGN_UPDATE s
    WHERE OW_LAO.TMP_SALES_CAMPAIGN.ID = s.ID AND OW_LAO.TMP_SALES_CAMPAIGN.ID_CAMPAIGN = s.ID_CAMPAIGN;

    PERFORM INSERT INTO OW_LAO.TMP_SALES_CAMPAIGN (
      ID, SUBSIDIARY, PO_DATE, PODATE_MONTH, PODATE_YEAR, PO_ORDERID, PO_DEVICETYPE, PO_SKU, DIVISION, PRODUCT, PRODUCT_GROUP, PRODUCT_FAMILY, PO_STORENAME,
      BIZ_TYPE, AUDIENCE_TYPE, EBI_NETREVENUE, PO_TOTALPRICE_USD, NET_REVENUE, PO_QTY, CAMPAIGN_DAY, CAMPAIGN_TAG, DT_UPDATE, ID_CAMPAIGN, PO_STATUS,
      PRODUCT_CATEGORY, PREVIOUS_YEAR, DEDUP)
    SELECT 
      s.ID, s.SUBSIDIARY, s.PO_DATE, s.PODATE_MONTH, s.PODATE_YEAR, s.PO_ORDERID, s.PO_DEVICETYPE, s.PO_SKU, s.DIVISION, s.PRODUCT, s.PRODUCT_GROUP,
      s.PRODUCT_FAMILY, s.PO_STORENAME, s.BIZ_TYPE, s.AUDIENCE_TYPE, s.EBI_NETREVENUE, s.PO_TOTALPRICE_USD, s.NET_REVENUE, s.PO_QTY, s.CAMPAIGN_DAY,
      s.CAMPAIGN_TAG, s.DT_UPDATE, s.ID_CAMPAIGN, s.PO_STATUS, s.PRODUCT_CATEGORY, s.PREVIOUS_YEAR, s.DEDUP
    FROM TMP_SALES_CAMPAIGN_UPDATE s
    LEFT JOIN OW_LAO.TMP_SALES_CAMPAIGN t
      ON t.ID = s.ID AND t.ID_CAMPAIGN = s.ID_CAMPAIGN
    WHERE t.ID IS NULL;

    PERFORM DROP TABLE IF EXISTS TMP_SALES_CAMPAIGN_UPDATE;

  ELSIF CONSULTA = 'EXEC_ODS_SALES_CAMPAIGN' THEN
    PERFORM DELETE FROM OW_LAO.ODS_SALES_CAMPAIGN
    WHERE NOT EXISTS (
      SELECT 1
      FROM OW_LAO.TMP_SALES_CAMPAIGN b
      WHERE OW_LAO.ODS_SALES_CAMPAIGN.ID = b.ID
        AND OW_LAO.ODS_SALES_CAMPAIGN.ID_CAMPAIGN = b.ID_CAMPAIGN
        AND OW_LAO.ODS_SALES_CAMPAIGN.DT_UPDATE = b.DT_UPDATE
    );

    PERFORM DROP TABLE IF EXISTS ODS_SALES_CAMPAIGN_UPDATE;
    PERFORM CREATE LOCAL TEMPORARY TABLE ODS_SALES_CAMPAIGN_UPDATE ON COMMIT PRESERVE ROWS AS
    SELECT DISTINCT 
      a.ID,
      a.SUBSIDIARY,
      a.PO_DATE,
      a.PODATE_MONTH,
      a.PODATE_YEAR,
      a.PO_ORDERID,
      a.PO_DEVICETYPE,
      a.PO_SKU,
      a.DIVISION,
      a.PRODUCT,
      a.PRODUCT_GROUP,
      a.PRODUCT_FAMILY,
      a.PO_STORENAME,
      CASE WHEN a.PO_DEVICETYPE = 'MOBILEAPP' THEN 'APP' ELSE a.BIZ_TYPE END AS BIZ_TYPE,
      a.AUDIENCE_TYPE,
      a.EBI_NETREVENUE,
      a.PO_TOTALPRICE_USD,
      a.NET_REVENUE,
      a.PO_QTY,
      a.CAMPAIGN_DAY,
      a.CAMPAIGN_TAG,
      a.DT_UPDATE,
      a.PO_STATUS,
      a.PRODUCT_CATEGORY,
      a.PREVIOUS_YEAR,
      a.ID_CAMPAIGN
    FROM OW_LAO.TMP_SALES_CAMPAIGN a
    WHERE DEDUP = 1
      AND NOT EXISTS (
        SELECT 1
        FROM OW_LAO.ODS_SALES_CAMPAIGN b
        WHERE a.ID = b.ID
          AND a.ID_CAMPAIGN = b.ID_CAMPAIGN
          AND a.DT_UPDATE = b.DT_UPDATE
      );

    PERFORM UPDATE OW_LAO.ODS_SALES_CAMPAIGN
    SET 
      ID = s.ID,
      SUBSIDIARY = s.SUBSIDIARY,
      PO_DATE = s.PO_DATE,
      PODATE_MONTH = s.PODATE_MONTH,
      PODATE_YEAR = s.PODATE_YEAR,
      PO_ORDERID = s.PO_ORDERID,
      PO_DEVICETYPE = s.PO_DEVICETYPE,
      PO_SKU = s.PO_SKU,
      DIVISION = s.DIVISION,
      PRODUCT = s.PRODUCT,
      PRODUCT_GROUP = s.PRODUCT_GROUP,
      PRODUCT_FAMILY = s.PRODUCT_FAMILY,
      PO_STORENAME = s.PO_STORENAME,
      BIZ_TYPE = s.BIZ_TYPE,
      AUDIENCE_TYPE = s.AUDIENCE_TYPE,
      EBI_NETREVENUE = s.EBI_NETREVENUE,
      PO_TOTALPRICE_USD = s.PO_TOTALPRICE_USD,
      NET_REVENUE = s.NET_REVENUE,
      PO_QTY = s.PO_QTY,
      CAMPAIGN_DAY = s.CAMPAIGN_DAY,
      CAMPAIGN_TAG = s.CAMPAIGN_TAG,
      DT_UPDATE = s.DT_UPDATE,
      PO_STATUS = s.PO_STATUS,
      PRODUCT_CATEGORY = s.PRODUCT_CATEGORY,
      PREVIOUS_YEAR = s.PREVIOUS_YEAR,
      ID_CAMPAIGN = s.ID_CAMPAIGN
    FROM ODS_SALES_CAMPAIGN_UPDATE s
    WHERE OW_LAO.ODS_SALES_CAMPAIGN.ID = s.ID AND OW_LAO.ODS_SALES_CAMPAIGN.ID_CAMPAIGN = s.ID_CAMPAIGN;

    PERFORM INSERT INTO OW_LAO.ODS_SALES_CAMPAIGN (
      ID, SUBSIDIARY, PO_DATE, PODATE_MONTH, PODATE_YEAR, PO_ORDERID, PO_DEVICETYPE, PO_SKU, DIVISION, PRODUCT, PRODUCT_GROUP, PRODUCT_FAMILY,
      PO_STORENAME, BIZ_TYPE, AUDIENCE_TYPE, EBI_NETREVENUE, PO_TOTALPRICE_USD, NET_REVENUE, PO_QTY, CAMPAIGN_DAY, CAMPAIGN_TAG, DT_UPDATE, PO_STATUS,
      PRODUCT_CATEGORY, PREVIOUS_YEAR, ID_CAMPAIGN)
    SELECT 
      s.ID, s.SUBSIDIARY, s.PO_DATE, s.PODATE_MONTH, s.PODATE_YEAR, s.PO_ORDERID, s.PO_DEVICETYPE, s.PO_SKU, s.DIVISION, s.PRODUCT, s.PRODUCT_GROUP,
      s.PRODUCT_FAMILY, s.PO_STORENAME, s.BIZ_TYPE, s.AUDIENCE_TYPE, s.EBI_NETREVENUE, s.PO_TOTALPRICE_USD, s.NET_REVENUE, s.PO_QTY, s.CAMPAIGN_DAY,
      s.CAMPAIGN_TAG, s.DT_UPDATE, s.PO_STATUS, s.PRODUCT_CATEGORY, s.PREVIOUS_YEAR, s.ID_CAMPAIGN
    FROM ODS_SALES_CAMPAIGN_UPDATE s
    LEFT JOIN OW_LAO.ODS_SALES_CAMPAIGN t
      ON t.ID = s.ID AND t.ID_CAMPAIGN = s.ID_CAMPAIGN
    WHERE t.ID IS NULL;

    PERFORM DROP TABLE IF EXISTS ODS_SALES_CAMPAIGN_UPDATE;
  END IF;
END;
$$;

-- CALL OW_LAO.HOMOLOG_PROC_SALES_CAMPAIGN('EXEC_UPDATE_CAMPAIGN_NAME', NULL);
-- ERROR: Severity: ERROR, Message: Relation "OW_LAO.DIM_CAMPAIGN_NAME" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure HOMOLOG_PROC_SALES_CAMPAIGN line 8 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
