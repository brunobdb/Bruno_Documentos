-- CREATE OR REPLACE PROCEDURE OW_LAO.PROC_SALES_CAMPAIGN_DAILY_CHECK()
-- LANGUAGE PLvSQL AS $$
-- DECLARE
--     CAMPAIGN_ACTIVE BOOLEAN;
-- BEGIN
--     -- Determine if any campaign is active today
--     SELECT CASE WHEN MAX(CAMPAIGN_TAG) IS NULL THEN FALSE ELSE TRUE END
--       INTO CAMPAIGN_ACTIVE
--       FROM OW_LAO.DIM_CAMPAIGN_NAME A
--      WHERE CURRENT_DATE BETWEEN A.INITIAL_DATE AND A.FINAL_DATE;
-- 
--     IF CAMPAIGN_ACTIVE = FALSE THEN
--         SELECT DISTINCT 
--             CASE 
--                 WHEN CAST(MAX(A.DT_UPDATE) AS DATE) = CURRENT_DATE THEN 2
--                 ELSE 3
--             END AS MONITORING_EXECUTION_RESULT_STATUS,
--             CASE 
--                 WHEN CAST(MAX(A.DT_UPDATE) AS DATE) = CURRENT_DATE THEN 'OK'
--                 ELSE 'NOT OK'
--             END AS VALUE
--         FROM OW_LAO.ODS_SALES_CAMPAIGN A;
-- 
--     ELSIF CAMPAIGN_ACTIVE = TRUE THEN
--         SELECT DISTINCT 
--             CASE 
--                 WHEN SUM(B.NET_REVENUE) > 0 OR SUM(B.PO_QTY) > 0 THEN 2
--                 ELSE 3
--             END AS MONITORING_EXECUTION_RESULT_STATUS,
--             CASE 
--                 WHEN SUM(B.NET_REVENUE) > 0 OR SUM(B.PO_QTY) > 0 THEN 'OK'
--                 ELSE 'NOT OK'
--             END AS VALUE
--         FROM OW_LAO.DIM_CAMPAIGN_NAME A
--         LEFT JOIN OW_LAO.ODS_SALES_CAMPAIGN B 
--                ON A.CAMPAIGN_TAG = B.CAMPAIGN_TAG 
--        WHERE CURRENT_DATE BETWEEN A.INITIAL_DATE AND A.FINAL_DATE 
--          AND CAST(B.PO_DATE AS DATE) = CURRENT_DATE
--        HAVING 
--             CASE 
--                 WHEN SUM(B.NET_REVENUE) > 0 OR SUM(B.PO_QTY) > 0 THEN 'OK'
--                 ELSE 'NOT OK'
--             END = 'NOT OK';
--     END IF;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 21.41 of source string: syntax error, unexpected ;, expecting INTO, Sqlstate: 42601, Position: 808, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
CREATE OR REPLACE PROCEDURE OW_LAO.PROC_SALES_CAMPAIGN_DAILY_CHECK()
LANGUAGE PLvSQL AS $$
DECLARE
    CAMPAIGN_ACTIVE BOOLEAN;
BEGIN
    -- Determine if any campaign is active today
    SELECT CASE WHEN MAX(CAMPAIGN_TAG) IS NULL THEN FALSE ELSE TRUE END
      INTO CAMPAIGN_ACTIVE
      FROM OW_LAO.DIM_CAMPAIGN_NAME A
     WHERE CURRENT_DATE BETWEEN A.INITIAL_DATE AND A.FINAL_DATE;

    IF CAMPAIGN_ACTIVE = FALSE THEN
        PERFORM SELECT DISTINCT 
            CASE 
                WHEN CAST(MAX(A.DT_UPDATE) AS DATE) = CURRENT_DATE THEN 2
                ELSE 3
            END AS MONITORING_EXECUTION_RESULT_STATUS,
            CASE 
                WHEN CAST(MAX(A.DT_UPDATE) AS DATE) = CURRENT_DATE THEN 'OK'
                ELSE 'NOT OK'
            END AS VALUE
        FROM OW_LAO.ODS_SALES_CAMPAIGN A;

    ELSIF CAMPAIGN_ACTIVE = TRUE THEN
        PERFORM SELECT DISTINCT 
            CASE 
                WHEN SUM(B.NET_REVENUE) > 0 OR SUM(B.PO_QTY) > 0 THEN 2
                ELSE 3
            END AS MONITORING_EXECUTION_RESULT_STATUS,
            CASE 
                WHEN SUM(B.NET_REVENUE) > 0 OR SUM(B.PO_QTY) > 0 THEN 'OK'
                ELSE 'NOT OK'
            END AS VALUE
        FROM OW_LAO.DIM_CAMPAIGN_NAME A
        LEFT JOIN OW_LAO.ODS_SALES_CAMPAIGN B 
               ON A.CAMPAIGN_TAG = B.CAMPAIGN_TAG 
       WHERE CURRENT_DATE BETWEEN A.INITIAL_DATE AND A.FINAL_DATE 
         AND CAST(B.PO_DATE AS DATE) = CURRENT_DATE
       HAVING 
            CASE 
                WHEN SUM(B.NET_REVENUE) > 0 OR SUM(B.PO_QTY) > 0 THEN 'OK'
                ELSE 'NOT OK'
            END = 'NOT OK';
    END IF;
END;
$$;

-- CALL OW_LAO.PROC_SALES_CAMPAIGN_DAILY_CHECK();
-- ERROR: Severity: ERROR, Message: Relation "OW_LAO.DIM_CAMPAIGN_NAME" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_SALES_CAMPAIGN_DAILY_CHECK line 6 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
-- CALL OW_LAO.PROC_SALES_CAMPAIGN_DAILY_CHECK();
-- ERROR: Severity: ERROR, Message: Relation "OW_LAO.DIM_CAMPAIGN_NAME" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_SALES_CAMPAIGN_DAILY_CHECK line 6 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
