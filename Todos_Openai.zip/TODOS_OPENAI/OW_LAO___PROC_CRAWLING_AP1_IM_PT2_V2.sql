-- CREATE OR REPLACE PROCEDURE PROC_CRAWLING_AP1_IM_PT2_V2()
-- LANGUAGE PLvSQL AS $$
-- BEGIN
-- -- Etapa 5
--   PERFORM TRUNCATE TABLE TF_CRAWLING_AP1_IM_6;
--   
--   PERFORM INSERT INTO TF_CRAWLING_AP1_IM_6
--   SELECT 
--     model_nm AS rsn_modelnm,
--     CAST(idxbyrsnmodelnm AS INTEGER) AS idxbyrsnmodelnm,
--     model_code,
--     pa_model_nm,
--     cnt AS mapping_cnt,
--     mapping_point,
--     ROUND((CAST(mapping_point AS NUMERIC)/90869)*100, 2) AS p_percent,
--     fix_ranking
--   FROM (
--     SELECT 
--       a.*,
--       ROW_NUMBER() OVER (
--         PARTITION BY model_nm, idxbyrsnmodelnm 
--         ORDER BY regex_rank DESC, compare_value ASC, mapping_point DESC, cnt DESC, model_code ASC
--       ) AS fix_ranking
--     FROM (
--       SELECT 
--         model_nm,
--         idxbyrsnmodelnm,
--         model_code,
--         pa_model_nm,
--         pa_mktname,
--         cnt,
--         mapping_point,
--         rsnNm_compare,
--         paNm_compare,
--         CASE WHEN rsnNm_compare = paNm_compare THEN 1 ELSE 2 END AS compare_value,
--         regex_rank
--       FROM (
--         SELECT
--           SUBSTRING_REGEXPR('[A-Z][0-9][0-9]' IN TRIM(UPPER(model_nm)) FROM 1 OCCURRENCE 1) AS rsnNm_compare,
--           SUBSTRING_REGEXPR('[A-Z][0-9][0-9]' IN TRIM(UPPER(pa_mktname)) FROM 1 OCCURRENCE 1) AS paNm_compare,
--           model_nm,
--           idxbyrsnmodelnm,
--           model_code,
--           pa_model_nm,
--           pa_mktname,
--           COUNT(model_code) AS cnt,
--           SUM(
--             CASE WHEN combine_type = 'case1' THEN 9087 ELSE 0 END +
--             CASE WHEN combine_type = 'case5' THEN 18174 ELSE 0 END +
--             CASE WHEN combine_type = 'case6' THEN 18174 ELSE 0 END +
--             CASE WHEN combine_type = 'case7' THEN 18174 ELSE 0 END +
--             CASE WHEN combine_type = 'case8' THEN 18174 ELSE 0 END +
--             CASE WHEN combine_type = 'case14' THEN 699 ELSE 0 END +
--             CASE WHEN combine_type = 'case15' THEN 699 ELSE 0 END +
--             CASE WHEN combine_type = 'case16' THEN 699 ELSE 0 END +
--             CASE WHEN combine_type = 'case17' THEN 699 ELSE 0 END +
--             CASE WHEN combine_type = 'case59' THEN 699 ELSE 0 END +
--             CASE WHEN combine_type = 'case60' THEN 699 ELSE 0 END +
--             CASE WHEN combine_type = 'case61' THEN 699 ELSE 0 END +
--             CASE WHEN combine_type = 'case62' THEN 699 ELSE 0 END +
--             CASE WHEN combine_type = 'case224' THEN 699 ELSE 0 END +
--             CASE WHEN combine_type = 'case225' THEN 699 ELSE 0 END +
--             CASE WHEN combine_type = 'case226' THEN 699 ELSE 0 END +
--             CASE WHEN combine_type = 'case227' THEN 699 ELSE 0 END +
--             CASE WHEN combine_type LIKE 'case%' THEN 1 ELSE 0 END
--           ) AS mapping_point,
--           (
--             (CASE WHEN REGEXP_LIKE(TRIM(LOWER(REPLACE(model_nm,' ',''))), TRIM(pa_model_nm_regex_1)) THEN 5 ELSE 0 END) +
--             (CASE WHEN REGEXP_LIKE(TRIM(LOWER(REPLACE(model_nm,' ',''))), TRIM(pa_model_nm_regex_2)) THEN 10 ELSE 0 END) +
--             (CASE WHEN REGEXP_LIKE(TRIM(LOWER(REPLACE(model_nm,' ',''))), TRIM(pa_model_nm_regex_3)) THEN 10 ELSE 0 END) +
--             (CASE WHEN REGEXP_LIKE(TRIM(LOWER(REPLACE(model_nm,' ',''))), TRIM(pa_model_nm_regex_4)) THEN 5 ELSE 0 END) +
--             (CASE WHEN REGEXP_LIKE(SUBSTRING_REGEXPR('\b\d{1}(g)\b' IN REPLACE(LOWER(model_nm),' ','')), TRIM(pa_model_nm_regex_5)) THEN 1 ELSE 0 END) +
--             (CASE WHEN REGEXP_LIKE(TRIM(LOWER(REPLACE(model_nm,' ',''))), TRIM(pa_model_nm_regex_6)) THEN 3 ELSE 0 END)
--           ) AS regex_rank
--         FROM TF_CRAWLING_AP1_IM_5
--         GROUP BY 
--           model_nm, idxbyrsnmodelnm, model_code, pa_model_nm, pa_mktname,
--           pa_model_nm_regex_1, pa_model_nm_regex_2, pa_model_nm_regex_3, pa_model_nm_regex_4, pa_model_nm_regex_5, pa_model_nm_regex_6
--       ) v
--     ) a
--   ) v
--   WHERE mapping_point >= 0;
-- 
-- -- Etapa 6
--   PERFORM TRUNCATE TABLE TF_CRAWLING_AP1_IM_7;
--   PERFORM INSERT INTO TF_CRAWLING_AP1_IM_7
--   SELECT 
--     rsn_modelnm,
--     idxbyrsnmodelnm,
--     model_code,
--     pa_model_nm AS phonearena_modelnm,
--     mapping_cnt,
--     mapping_point,
--     p_percent,
--     mp_agv,
--     final_ranking
--   FROM  (
--     SELECT *, ROW_NUMBER() OVER (PARTITION BY rsn_modelnm ORDER BY mp_agv DESC, mapping_point DESC) AS final_ranking 
--     FROM (
--       SELECT *, ROUND(AVG(mapping_point) OVER (PARTITION BY rsn_modelnm, model_code), 1) AS mp_agv
--       FROM TF_CRAWLING_AP1_IM_6
--       WHERE fix_ranking = 1
--     ) v
--   ) b;
--   
-- -- Etapa 7
--   PERFORM TRUNCATE TABLE TF_CRAWLING_AP1_IM_8;
--   PERFORM INSERT INTO TF_CRAWLING_AP1_IM_8
--   SELECT 
--     b.model_code AS pa_model_code,
--     c.brand_nm AS pa_brand_nm,
--     c.mktcode AS pa_mktcode,
--     c.mktname AS pa_mktname,
--     c.model_nm AS pa_model_nm,
--     a.*
--   FROM TF_CRAWLING_AP1_IM_2 a
--   INNER JOIN TF_CRAWLING_AP1_IM_7 b
--     ON a.model_nm = b.rsn_modelnm AND a.idxbyrsnmodelnm = b.idxbyrsnmodelnm
--   INNER JOIN MP_GSMARENA_MERGE_DATA_MAPPING c
--     ON b.model_code = c.model_code
--    AND a.BRAND_NM = c.BRAND_NM;
-- 
-- -- Etapa 8
--   PERFORM TRUNCATE TABLE TF_CRAWLING_AP1_IM_9;
--   PERFORM INSERT INTO TF_CRAWLING_AP1_IM_9
--     SELECT * FROM TF_CRAWLING_AP1_IM_8;
--   
--   PERFORM MERGE INTO TF_CRAWLING_AP1_IM_9 O
--   USING MP_GSMARENA_MERGE_DATA_A_MINMODELCODE M 
--   ON REPLACE(O.pa_brand_nm,' ','') = M.trim_brand_nm
--    AND REPLACE(O.pa_mktname,' ','') = M.trim_mktname
--    AND REPLACE(O.pa_model_nm,' ','') = M.trim_model_nm
--   WHEN MATCHED THEN UPDATE 
--     SET pa_model_code = M.min_model_code,
--         pa_mktcode = M.min_mktcode;
-- 
--   PERFORM TRUNCATE TABLE TF_CRAWLING_AP1_IM_10;
--   PERFORM INSERT INTO TF_CRAWLING_AP1_IM_10
--     SELECT * FROM TF_CRAWLING_AP1_IM_9;
-- 
--   PERFORM MERGE INTO TF_CRAWLING_AP1_IM_10 O
--   USING (
--     SELECT MIN(pa_model_code) AS pa_model_code, pa_mktcode, pa_brand_nm, pa_model_nm
--     FROM (SELECT DISTINCT pa_model_code, pa_mktcode, pa_brand_nm, pa_model_nm FROM TF_CRAWLING_AP1_IM_10) v
--     GROUP BY pa_mktcode, pa_brand_nm, pa_model_nm
--     HAVING COUNT(1) > 1
--   ) k
--   ON o.pa_mktcode = k.pa_mktcode 
--   AND o.pa_brand_nm = k.pa_brand_nm 
--   AND o.pa_model_nm = k.pa_model_nm
--   WHEN MATCHED THEN UPDATE 
--     SET pa_model_code = k.pa_model_code;
-- 
-- -- Etapa 9
--   PERFORM TRUNCATE TABLE TF_CRAWLING_AP1_IM_11;
--   PERFORM INSERT INTO TF_CRAWLING_AP1_IM_11
--   SELECT
--     pa_model_code AS model_code,
--     UPPER(TRIM(INITCAP(pa_brand_nm))) AS brand_nm,
--     pa_mktcode AS mktcode,
--     pa_mktname AS mktname,
--     pa_model_nm AS model_nm,
--     subsidiary,
--     country,
--     country_code,
--     UPPER(TRIM(site_company_name)) AS site_company_name,
--     site_nm,
--     site_url,
--     site_page,
--     site_position,
--     site_price_currency,
--     CASE WHEN site_rating = '' THEN NULL ELSE TO_DECIMAL(site_rating, 8, 1) END AS site_rating,
--     CASE WHEN site_rating_amount = '' THEN NULL ELSE TO_DECIMAL(site_rating_amount, 8, 0) END AS site_rating_amount,
--     CASE WHEN site_rating_scale = '' THEN NULL ELSE TO_DECIMAL(site_rating_scale, 8, 0) END AS site_rating_scale,
--     TO_TIMESTAMP(refer_date, 'YYYY-MM-DD HH24:MI') AS refer_date,
--     price_unit,
--     ROUND(MAX(price_local_base), 2) AS price_local_base,
--     ROUND(MAX(price_local_act), 2) AS price_local_act,
--     ROUND(MAX(price_local_down), 2) AS price_local_down,
--     ROUND(MAX(price_local_monthly), 2) AS price_local_monthly,
--     ROUND(MAX(price_local_months), 2) AS price_local_months,
--     'Y' AS update_flg,
--     CURRENT_TIMESTAMP
--   FROM (
--     SELECT
--       pa_model_code,
--       pa_brand_nm,
--       pa_mktcode,
--       pa_mktname,
--       pa_model_nm,
--       subsidiary,
--       country,
--       country_code,
--       site_company_name,
--       site_nm,
--       site_url,
--       site_page,
--       site_position,
--       site_price_currency,
--       site_rating,
--       site_rating_amount,
--       site_rating_scale,
--       refer_date,
--       price_unit,
--       AVG(TO_DECIMAL(TRIM(price_local_base), 8, 2)) AS price_local_base,
--       0 AS price_local_act,
--       0 AS price_local_down,
--       0 AS price_local_monthly,
--       0 AS price_local_months
--     FROM (
--       SELECT
--         CASE WHEN t_cnt/2 = base_row_num THEN 'Y' 
--              WHEN t_cnt/2 + 1 = base_row_num THEN 'Y' 
--         END AS flg, 
--         *
--       FROM (
--         SELECT 
--           ROW_NUMBER() OVER (
--             PARTITION BY a.pa_model_code, a.pa_brand_nm, a.pa_mktcode, a.pa_mktname, a.pa_model_nm, a.country, a.country_code,
--                          a.site_nm, a.subsidiary, a.country, a.country_code, a.site_company_name, a.site_nm, a.site_url, a.site_page,
--                          a.site_position, a.site_price_currency, a.site_rating, a.site_rating_amount, a.site_rating_scale,
--                          a.refer_date, a.price_unit 
--             ORDER BY price_local_base ASC
--           ) AS base_row_num,
--           b.t_cnt,
--           a.*
--         FROM (
--           SELECT * FROM TF_CRAWLING_AP1_IM_10
--         ) a
--         , (
--           SELECT 
--             pa_model_code,
--             pa_brand_nm,
--             pa_mktcode,
--             pa_mktname,
--             pa_model_nm,
--             subsidiary,
--             country,
--             country_code,
--             site_company_name,
--             site_nm,
--             site_url,
--             site_page,
--             site_position,
--             site_price_currency,
--             site_rating,
--             site_rating_amount,
--             site_rating_scale,
--             refer_date,
--             price_unit,
--             COUNT(1) AS t_cnt
--           FROM TF_CRAWLING_AP1_IM_10
--           GROUP BY pa_model_code, pa_brand_nm, pa_mktcode, pa_mktname, pa_model_nm,
--                    subsidiary, country, country_code, site_company_name, site_nm, site_url, site_page, site_position,
--                    site_price_currency, site_rating, site_rating_amount, site_rating_scale, refer_date, price_unit
--         ) b
--         WHERE a.pa_model_code = b.pa_model_code
--           AND a.pa_brand_nm = b.pa_brand_nm
--           AND a.pa_mktcode = b.pa_mktcode
--           AND a.pa_mktname = b.pa_mktname
--           AND a.pa_model_nm = b.pa_model_nm
--           AND a.subsidiary = b.subsidiary
--           AND a.country = b.country 
--           AND a.country_code = b.country_code 
--           AND a.site_company_name = b.site_company_name 
--           AND a.site_nm = b.site_nm 
--           AND a.site_url = b.site_url 
--           AND a.site_page = b.site_page 
--           AND a.site_position = b.site_position 
--           AND a.site_price_currency = b.site_price_currency 
--           AND a.site_rating = b.site_rating 
--           AND a.site_rating_amount = b.site_rating_amount 
--           AND a.site_rating_scale = b.site_rating_scale 
--           AND a.refer_date = b.refer_date
--           AND a.price_unit = b.price_unit
--       ) g
--     ) v
--     GROUP BY pa_model_code, pa_brand_nm, pa_mktcode, pa_mktname, pa_model_nm,
--              subsidiary, country, country_code, site_company_name, site_nm, site_url, site_page, site_position,
--              site_price_currency, site_rating, site_rating_amount, site_rating_scale, refer_date, price_unit
--     
--     UNION ALL
--     
--     SELECT
--       pa_model_code,
--       pa_brand_nm,
--       pa_mktcode,
--       pa_mktname,
--       pa_model_nm,
--       subsidiary,
--       country,
--       country_code,
--       site_company_name,
--       site_nm,
--       site_url,
--       site_page,
--       site_position,
--       site_price_currency,
--       site_rating,
--       site_rating_amount,
--       site_rating_scale,
--       refer_date,
--       price_unit,
--       0 AS price_local_base,
--       AVG(TO_DECIMAL(TRIM(price_local_act), 8, 2)) AS price_local_act,
--       0 AS price_local_down,
--       0 AS price_local_monthly,
--       0 AS price_local_months
--     FROM (
--       SELECT
--         CASE WHEN t_cnt/2 = act_row_num THEN 'Y' 
--              WHEN t_cnt/2 + 1 = act_row_num THEN 'Y' 
--         END AS flg, 
--         *
--       FROM (
--         SELECT 
--           ROW_NUMBER() OVER (
--             PARTITION BY a.pa_model_code, a.pa_brand_nm, a.pa_mktcode, a.pa_mktname, a.pa_model_nm, a.country, a.country_code,
--                          a.site_nm, a.subsidiary, a.country, a.country_code, a.site_company_name, a.site_nm, a.site_url, a.site_page,
--                          a.site_position, a.site_price_currency, a.site_rating, a.site_rating_amount, a.site_rating_scale,
--                          a.refer_date, a.price_unit 
--             ORDER BY price_local_act ASC
--           ) AS act_row_num,
--           b.t_cnt,
--           a.*
--         FROM (
--           SELECT * FROM TF_CRAWLING_AP1_IM_10
--         ) a
--         , (
--           SELECT 
--             pa_model_code,
--             pa_brand_nm,
--             pa_mktcode,
--             pa_mktname,
--             pa_model_nm,
--             subsidiary,
--             country,
--             country_code,
--             site_company_name,
--             site_nm,
--             site_url,
--             site_page,
--             site_position,
--             site_price_currency,
--             site_rating,
--             site_rating_amount,
--             site_rating_scale,
--             refer_date,
--             price_unit,
--             COUNT(1) AS t_cnt
--           FROM TF_CRAWLING_AP1_IM_10
--           GROUP BY pa_model_code, pa_brand_nm, pa_mktcode, pa_mktname, pa_model_nm,
--                    subsidiary, country, country_code, site_company_name, site_nm, site_url, site_page, site_position,
--                    site_price_currency, site_rating, site_rating_amount, site_rating_scale, refer_date, price_unit
--         ) b
--         WHERE a.pa_model_code = b.pa_model_code
--           AND a.pa_brand_nm = b.pa_brand_nm
--           AND a.pa_mktcode = b.pa_mktcode
--           AND a.pa_mktname = b.pa_mktname
--           AND a.pa_model_nm = b.pa_model_nm
--           AND a.subsidiary = b.subsidiary
--           AND a.country = b.country 
--           AND a.country_code = b.country_code 
--           AND a.site_company_name = b.site_company_name 
--           AND a.site_nm = b.site_nm 
--           AND a.site_url = b.site_url 
--           AND a.site_page = b.site_page 
--           AND a.site_position = b.site_position 
--           AND a.site_price_currency = b.site_price_currency 
--           AND a.site_rating = b.site_rating 
--           AND a.site_rating_amount = b.site_rating_amount 
--           AND a.site_rating_scale = b.site_rating_scale 
--           AND a.refer_date = b.refer_date
--           AND a.price_unit = b.price_unit
--       ) g
--     ) v
--     GROUP BY pa_model_code, pa_brand_nm, pa_mktcode, pa_mktname, pa_model_nm,
--              subsidiary, country, country_code, site_company_name, site_nm, site_url, site_page, site_position,
--              site_price_currency, site_rating, site_rating_amount, site_rating_scale, refer_date, price_unit
--   ) s 
--   GROUP BY pa_model_code, pa_brand_nm, pa_mktcode, pa_mktname, pa_model_nm,
--            subsidiary, country, country_code, site_company_name, site_nm, site_url, site_page, site_position,
--            site_price_currency, site_rating, site_rating_amount, site_rating_scale, refer_date, price_unit;
-- 
-- -- Etapa 10
--   PERFORM TRUNCATE TABLE TF_CRAWLING_AP1_IM_12;
--   PERFORM INSERT INTO TF_CRAWLING_AP1_IM_12
--   (
--     "MODEL_CODE",
--     "BRAND_NM",
--     "MKTCODE",
--     "MKTNAME",
--     "MODEL_NM",
--     "SUBSIDIARY",
--     "COUNTRY",
--     "COUNTRY_CODE",
--     "SITE_COMPANY_NAME",
--     "SITE_NM",
--     "SITE_URL",
--     "SITE_PAGE",
--     "SITE_POSITION",
--     "SITE_PRICE_CURRENCY",
--     "SITE_RATING",
--     "SITE_RATING_AMOUNT",
--     "SITE_RATING_SCALE",
--     "REFER_DATE",
--     "PRICE_UNIT",
--     "PRICE_LOCAL_BASE",
--     "PRICE_LOCAL_ACT",
--     "PRICE_LOCAL_DOWN",
--     "PRICE_LOCAL_MONTHLY",
--     "PRICE_LOCAL_MONTHS",
--     "UPDATE_FLG",
--     "PROCESS_DATETIME",
--     "FROM_CURRENCY",
--     "TO_CURRENCY",
--     "VALID_FROM",
--     "EXCHANGE_RATE",
--     "MKT_SEGMENT",
--     "PRICE_UNIT_USD",
--     "PRICE_LOCAL_BASE_USD",
--     "PRICE_LOCAL_ACT_USD",
--     "PRICE_LOCAL_DOWN_USD",
--     "PRICE_LOCAL_MONTHLY_USD",
--     "PRICE_LOCAL_MONTHS_USD",
--     "VENDOR",
--     "MEDIAN_UNIT_PRICE_USD",
--     "REFER_WEEK",
--     "REFER_WEEK_T",
--     "REFER_YEAR"
--   )
--   SELECT 
--     VW_PRICE."MODEL_CODE",
--     VW_PRICE."BRAND_NM",
--     VW_PRICE."MKTCODE",
--     VW_PRICE."MKTNAME",
--     VW_PRICE."MODEL_NM",
--     VW_PRICE."SUBSIDIARY",
--     VW_PRICE."COUNTRY",
--     VW_PRICE."COUNTRY_CODE",
--     VW_PRICE."SITE_COMPANY_NAME",
--     VW_PRICE."SITE_NM",
--     VW_PRICE."SITE_URL",
--     VW_PRICE."SITE_PAGE",
--     VW_PRICE."SITE_POSITION",
--     VW_PRICE."SITE_PRICE_CURRENCY",
--     VW_PRICE."SITE_RATING",
--     VW_PRICE."SITE_RATING_AMOUNT",
--     VW_PRICE."SITE_RATING_SCALE",
--     VW_PRICE."REFER_DATE",
--     VW_PRICE."PRICE_UNIT",
--     VW_PRICE."PRICE_LOCAL_BASE",
--     VW_PRICE."PRICE_LOCAL_ACT",
--     VW_PRICE."PRICE_LOCAL_DOWN",
--     VW_PRICE."PRICE_LOCAL_MONTHLY",
--     VW_PRICE."PRICE_LOCAL_MONTHS",
--     VW_PRICE."UPDATE_FLG",
--     VW_PRICE."PROCESS_DATETIME",
--     VW_PRICE."FROM_CURRENCY",
--     VW_PRICE."TO_CURRENCY",
--     VW_PRICE."VALID_FROM",
--     VW_PRICE."EXCHANGE_RATE",
--     VW_PRICE."MKT_SEGMENT",
--     VW_PRICE."PRICE_UNIT_USD",
--     VW_PRICE."PRICE_LOCAL_BASE_USD",
--     VW_PRICE."PRICE_LOCAL_ACT_USD",
--     VW_PRICE."PRICE_LOCAL_DOWN_USD",
--     VW_PRICE."PRICE_LOCAL_MONTHLY_USD",
--     VW_PRICE."PRICE_LOCAL_MONTHS_USD",
--     UPPER(VENDOR.VENDOR),
--     MEDIAN.MEDIAN,
--     NULL AS REFER_WEEK,
--     NULL AS REFER_WEEK_T,
--     NULL AS REFER_YEAR
--   FROM VW_CRAWLING_ONLINE_PRICE VW_PRICE
--   LEFT JOIN (
--     SELECT COUNT(1), PROD_HREF, VENDOR
--     FROM OW_LAO.ODS_CRAWLING_AP1_IM_PRODUCT_DETAIL
--     WHERE VENDOR <> '' AND VENDOR IS NOT NULL 
--     GROUP BY PROD_HREF, VENDOR 
--     HAVING COUNT(1) = 1
--   ) VENDOR ON VENDOR.PROD_HREF = VW_PRICE.SITE_URL
--   LEFT JOIN (
--     SELECT ROUND(MEDIAN(PRICE_UNIT_USD), 2) AS MEDIAN, COUNTRY, MKTNAME
--     FROM OW_LAO.VW_CRAWLING_ONLINE_PRICE 
--     GROUP BY COUNTRY, MKTNAME
--   ) MEDIAN ON MEDIAN.COUNTRY = VW_PRICE."COUNTRY" AND MEDIAN.MKTNAME = VW_PRICE."MKTNAME";
-- 
-- --################################CARGA DAS FATOS################################
-- --################################
--   PERFORM DELETE FROM FT_CRAWLING_ONLINE_PRICE_DISPLAY_SHARE
--   WHERE TO_CHAR("REFER_DATE", 'YYYY-MM-DD') BETWEEN TO_CHAR(TIMESTAMPADD(DAY, -15, CURRENT_DATE), 'YYYY-MM-DD') AND TO_CHAR(CURRENT_DATE, 'YYYY-MM-DD');
-- 
--   PERFORM INSERT INTO FT_CRAWLING_ONLINE_PRICE_DISPLAY_SHARE
--     SELECT * FROM VW_CRAWLING_ONLINE_PRICE_DISPLAY_SHARE;
-- 
-- --################################
--   PERFORM DELETE FROM FT_CRAWLING_ONLINE_PRICE_SEGMENT
--   WHERE TO_CHAR("REFER_DATE", 'YYYY-MM-DD') BETWEEN TO_CHAR(TIMESTAMPADD(DAY, -15, CURRENT_DATE), 'YYYY-MM-DD') AND TO_CHAR(CURRENT_DATE, 'YYYY-MM-DD');
-- 
--   PERFORM INSERT INTO FT_CRAWLING_ONLINE_PRICE_SEGMENT
--     SELECT * FROM TF_CRAWLING_AP1_IM_12;
-- 
--   PERFORM UPDATE OW_LAO.FT_CRAWLING_ONLINE_PRICE_SEGMENT F
--   SET
--     REFER_WEEK = (SELECT DISTINCT YYYYWW FROM OW_MD.DIM_CALENDAR D WHERE TO_CHAR(F.REFER_DATE,'YYYY-MM-DD') = TO_CHAR(D.YYYYMMDD,'YYYY-MM-DD')),
--     REFER_WEEK_T = (SELECT DISTINCT 'W' || RIGHT(YYYYWW, 2) FROM OW_MD.DIM_CALENDAR D WHERE TO_CHAR(F.REFER_DATE,'YYYY-MM-DD') = TO_CHAR(D.YYYYMMDD,'YYYY-MM-DD')),
--     REFER_YEAR = (SELECT DISTINCT YYYY FROM OW_MD.DIM_CALENDAR D WHERE TO_CHAR(F.REFER_DATE,'YYYY-MM-DD') = TO_CHAR(D.YYYYMMDD,'YYYY-MM-DD'))
--   WHERE 
--     REFER_WEEK IS NULL;
-- 
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: Syntax error at or near "TRIM", Sqlstate: 42601, Position: 1066, Routine: base_yyerror, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/scan.l, Line: 1056, Error Code: 4856, 
CREATE OR REPLACE PROCEDURE PROC_CRAWLING_AP1_IM_PT2_V2()
LANGUAGE PLvSQL AS $$
BEGIN
-- Etapa 5
  PERFORM TRUNCATE TABLE TF_CRAWLING_AP1_IM_6;
  
  PERFORM INSERT INTO TF_CRAWLING_AP1_IM_6
  SELECT 
    model_nm AS rsn_modelnm,
    CAST(idxbyrsnmodelnm AS INTEGER) AS idxbyrsnmodelnm,
    model_code,
    pa_model_nm,
    cnt AS mapping_cnt,
    mapping_point,
    ROUND((CAST(mapping_point AS NUMERIC)/90869)*100, 2) AS p_percent,
    fix_ranking
  FROM (
    SELECT 
      a.*,
      ROW_NUMBER() OVER (
        PARTITION BY model_nm, idxbyrsnmodelnm 
        ORDER BY regex_rank DESC, compare_value ASC, mapping_point DESC, cnt DESC, model_code ASC
      ) AS fix_ranking
    FROM (
      SELECT 
        model_nm,
        idxbyrsnmodelnm,
        model_code,
        pa_model_nm,
        pa_mktname,
        cnt,
        mapping_point,
        rsnNm_compare,
        paNm_compare,
        CASE WHEN rsnNm_compare = paNm_compare THEN 1 ELSE 2 END AS compare_value,
        regex_rank
      FROM (
        SELECT
          REGEXP_SUBSTR(TRIM(UPPER(model_nm)), '[A-Z][0-9][0-9]', 1, 1, 'c') AS rsnNm_compare,
          REGEXP_SUBSTR(TRIM(UPPER(pa_mktname)), '[A-Z][0-9][0-9]', 1, 1, 'c') AS paNm_compare,
          model_nm,
          idxbyrsnmodelnm,
          model_code,
          pa_model_nm,
          pa_mktname,
          COUNT(model_code) AS cnt,
          SUM(
            CASE WHEN combine_type = 'case1' THEN 9087 ELSE 0 END +
            CASE WHEN combine_type = 'case5' THEN 18174 ELSE 0 END +
            CASE WHEN combine_type = 'case6' THEN 18174 ELSE 0 END +
            CASE WHEN combine_type = 'case7' THEN 18174 ELSE 0 END +
            CASE WHEN combine_type = 'case8' THEN 18174 ELSE 0 END +
            CASE WHEN combine_type = 'case14' THEN 699 ELSE 0 END +
            CASE WHEN combine_type = 'case15' THEN 699 ELSE 0 END +
            CASE WHEN combine_type = 'case16' THEN 699 ELSE 0 END +
            CASE WHEN combine_type = 'case17' THEN 699 ELSE 0 END +
            CASE WHEN combine_type = 'case59' THEN 699 ELSE 0 END +
            CASE WHEN combine_type = 'case60' THEN 699 ELSE 0 END +
            CASE WHEN combine_type = 'case61' THEN 699 ELSE 0 END +
            CASE WHEN combine_type = 'case62' THEN 699 ELSE 0 END +
            CASE WHEN combine_type = 'case224' THEN 699 ELSE 0 END +
            CASE WHEN combine_type = 'case225' THEN 699 ELSE 0 END +
            CASE WHEN combine_type = 'case226' THEN 699 ELSE 0 END +
            CASE WHEN combine_type = 'case227' THEN 699 ELSE 0 END +
            CASE WHEN combine_type LIKE 'case%' THEN 1 ELSE 0 END
          ) AS mapping_point,
          (
            (CASE WHEN REGEXP_LIKE(TRIM(LOWER(REPLACE(model_nm,' ',''))), TRIM(pa_model_nm_regex_1)) THEN 5 ELSE 0 END) +
            (CASE WHEN REGEXP_LIKE(TRIM(LOWER(REPLACE(model_nm,' ',''))), TRIM(pa_model_nm_regex_2)) THEN 10 ELSE 0 END) +
            (CASE WHEN REGEXP_LIKE(TRIM(LOWER(REPLACE(model_nm,' ',''))), TRIM(pa_model_nm_regex_3)) THEN 10 ELSE 0 END) +
            (CASE WHEN REGEXP_LIKE(TRIM(LOWER(REPLACE(model_nm,' ',''))), TRIM(pa_model_nm_regex_4)) THEN 5 ELSE 0 END) +
            (CASE WHEN REGEXP_LIKE(REGEXP_SUBSTR(REPLACE(LOWER(model_nm),' ',''), '\\b\\d{1}(g)\\b', 1, 1, 'c'), TRIM(pa_model_nm_regex_5)) THEN 1 ELSE 0 END) +
            (CASE WHEN REGEXP_LIKE(TRIM(LOWER(REPLACE(model_nm,' ',''))), TRIM(pa_model_nm_regex_6)) THEN 3 ELSE 0 END)
          ) AS regex_rank
        FROM TF_CRAWLING_AP1_IM_5
        GROUP BY 
          model_nm, idxbyrsnmodelnm, model_code, pa_model_nm, pa_mktname,
          pa_model_nm_regex_1, pa_model_nm_regex_2, pa_model_nm_regex_3, pa_model_nm_regex_4, pa_model_nm_regex_5, pa_model_nm_regex_6
      ) v
    ) a
  ) v
  WHERE mapping_point >= 0;

-- Etapa 6
  PERFORM TRUNCATE TABLE TF_CRAWLING_AP1_IM_7;
  PERFORM INSERT INTO TF_CRAWLING_AP1_IM_7
  SELECT 
    rsn_modelnm,
    idxbyrsnmodelnm,
    model_code,
    pa_model_nm AS phonearena_modelnm,
    mapping_cnt,
    mapping_point,
    p_percent,
    mp_agv,
    final_ranking
  FROM  (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY rsn_modelnm ORDER BY mp_agv DESC, mapping_point DESC) AS final_ranking 
    FROM (
      SELECT *, ROUND(AVG(mapping_point) OVER (PARTITION BY rsn_modelnm, model_code), 1) AS mp_agv
      FROM TF_CRAWLING_AP1_IM_6
      WHERE fix_ranking = 1
    ) v
  ) b;
  
-- Etapa 7
  PERFORM TRUNCATE TABLE TF_CRAWLING_AP1_IM_8;
  PERFORM INSERT INTO TF_CRAWLING_AP1_IM_8
  SELECT 
    b.model_code AS pa_model_code,
    c.brand_nm AS pa_brand_nm,
    c.mktcode AS pa_mktcode,
    c.mktname AS pa_mktname,
    c.model_nm AS pa_model_nm,
    a.*
  FROM TF_CRAWLING_AP1_IM_2 a
  INNER JOIN TF_CRAWLING_AP1_IM_7 b
    ON a.model_nm = b.rsn_modelnm AND a.idxbyrsnmodelnm = b.idxbyrsnmodelnm
  INNER JOIN MP_GSMARENA_MERGE_DATA_MAPPING c
    ON b.model_code = c.model_code
   AND a.BRAND_NM = c.BRAND_NM;

-- Etapa 8
  PERFORM TRUNCATE TABLE TF_CRAWLING_AP1_IM_9;
  PERFORM INSERT INTO TF_CRAWLING_AP1_IM_9
    SELECT * FROM TF_CRAWLING_AP1_IM_8;
  
  PERFORM MERGE INTO TF_CRAWLING_AP1_IM_9 O
  USING MP_GSMARENA_MERGE_DATA_A_MINMODELCODE M 
  ON REPLACE(O.pa_brand_nm,' ','') = M.trim_brand_nm
   AND REPLACE(O.pa_mktname,' ','') = M.trim_mktname
   AND REPLACE(O.pa_model_nm,' ','') = M.trim_model_nm
  WHEN MATCHED THEN UPDATE 
    SET pa_model_code = M.min_model_code,
        pa_mktcode = M.min_mktcode;

  PERFORM TRUNCATE TABLE TF_CRAWLING_AP1_IM_10;
  PERFORM INSERT INTO TF_CRAWLING_AP1_IM_10
    SELECT * FROM TF_CRAWLING_AP1_IM_9;

  PERFORM MERGE INTO TF_CRAWLING_AP1_IM_10 O
  USING (
    SELECT MIN(pa_model_code) AS pa_model_code, pa_mktcode, pa_brand_nm, pa_model_nm
    FROM (SELECT DISTINCT pa_model_code, pa_mktcode, pa_brand_nm, pa_model_nm FROM TF_CRAWLING_AP1_IM_10) v
    GROUP BY pa_mktcode, pa_brand_nm, pa_model_nm
    HAVING COUNT(1) > 1
  ) k
  ON o.pa_mktcode = k.pa_mktcode 
  AND o.pa_brand_nm = k.pa_brand_nm 
  AND o.pa_model_nm = k.pa_model_nm
  WHEN MATCHED THEN UPDATE 
    SET pa_model_code = k.pa_model_code;

-- Etapa 9
  PERFORM TRUNCATE TABLE TF_CRAWLING_AP1_IM_11;
  PERFORM INSERT INTO TF_CRAWLING_AP1_IM_11
  SELECT
    pa_model_code AS model_code,
    UPPER(TRIM(INITCAP(pa_brand_nm))) AS brand_nm,
    pa_mktcode AS mktcode,
    pa_mktname AS mktname,
    pa_model_nm AS model_nm,
    subsidiary,
    country,
    country_code,
    UPPER(TRIM(site_company_name)) AS site_company_name,
    site_nm,
    site_url,
    site_page,
    site_position,
    site_price_currency,
    CASE WHEN site_rating = '' THEN NULL ELSE TO_DECIMAL(site_rating, 8, 1) END AS site_rating,
    CASE WHEN site_rating_amount = '' THEN NULL ELSE TO_DECIMAL(site_rating_amount, 8, 0) END AS site_rating_amount,
    CASE WHEN site_rating_scale = '' THEN NULL ELSE TO_DECIMAL(site_rating_scale, 8, 0) END AS site_rating_scale,
    TO_TIMESTAMP(refer_date, 'YYYY-MM-DD HH24:MI') AS refer_date,
    price_unit,
    ROUND(MAX(price_local_base), 2) AS price_local_base,
    ROUND(MAX(price_local_act), 2) AS price_local_act,
    ROUND(MAX(price_local_down), 2) AS price_local_down,
    ROUND(MAX(price_local_monthly), 2) AS price_local_monthly,
    ROUND(MAX(price_local_months), 2) AS price_local_months,
    'Y' AS update_flg,
    CURRENT_TIMESTAMP
  FROM (
    SELECT
      pa_model_code,
      pa_brand_nm,
      pa_mktcode,
      pa_mktname,
      pa_model_nm,
      subsidiary,
      country,
      country_code,
      site_company_name,
      site_nm,
      site_url,
      site_page,
      site_position,
      site_price_currency,
      site_rating,
      site_rating_amount,
      site_rating_scale,
      refer_date,
      price_unit,
      AVG(TO_DECIMAL(TRIM(price_local_base), 8, 2)) AS price_local_base,
      0 AS price_local_act,
      0 AS price_local_down,
      0 AS price_local_monthly,
      0 AS price_local_months
    FROM (
      SELECT
        CASE WHEN t_cnt/2 = base_row_num THEN 'Y' 
             WHEN t_cnt/2 + 1 = base_row_num THEN 'Y' 
        END AS flg, 
        *
      FROM (
        SELECT 
          ROW_NUMBER() OVER (
            PARTITION BY a.pa_model_code, a.pa_brand_nm, a.pa_mktcode, a.pa_mktname, a.pa_model_nm, a.country, a.country_code,
                         a.site_nm, a.subsidiary, a.country, a.country_code, a.site_company_name, a.site_nm, a.site_url, a.site_page,
                         a.site_position, a.site_price_currency, a.site_rating, a.site_rating_amount, a.site_rating_scale,
                         a.refer_date, a.price_unit 
            ORDER BY price_local_base ASC
          ) AS base_row_num,
          b.t_cnt,
          a.*
        FROM (
          SELECT * FROM TF_CRAWLING_AP1_IM_10
        ) a
        , (
          SELECT 
            pa_model_code,
            pa_brand_nm,
            pa_mktcode,
            pa_mktname,
            pa_model_nm,
            subsidiary,
            country,
            country_code,
            site_company_name,
            site_nm,
            site_url,
            site_page,
            site_position,
            site_price_currency,
            site_rating,
            site_rating_amount,
            site_rating_scale,
            refer_date,
            price_unit,
            COUNT(1) AS t_cnt
          FROM TF_CRAWLING_AP1_IM_10
          GROUP BY pa_model_code, pa_brand_nm, pa_mktcode, pa_mktname, pa_model_nm,
                   subsidiary, country, country_code, site_company_name, site_nm, site_url, site_page, site_position,
                   site_price_currency, site_rating, site_rating_amount, site_rating_scale, refer_date, price_unit
        ) b
        WHERE a.pa_model_code = b.pa_model_code
          AND a.pa_brand_nm = b.pa_brand_nm
          AND a.pa_mktcode = b.pa_mktcode
          AND a.pa_mktname = b.pa_mktname
          AND a.pa_model_nm = b.pa_model_nm
          AND a.subsidiary = b.subsidiary
          AND a.country = b.country 
          AND a.country_code = b.country_code 
          AND a.site_company_name = b.site_company_name 
          AND a.site_nm = b.site_nm 
          AND a.site_url = b.site_url 
          AND a.site_page = b.site_page 
          AND a.site_position = b.site_position 
          AND a.site_price_currency = b.site_price_currency 
          AND a.site_rating = b.site_rating 
          AND a.site_rating_amount = b.site_rating_amount 
          AND a.site_rating_scale = b.site_rating_scale 
          AND a.refer_date = b.refer_date
          AND a.price_unit = b.price_unit
      ) g
    ) v
    GROUP BY pa_model_code, pa_brand_nm, pa_mktcode, pa_mktname, pa_model_nm,
             subsidiary, country, country_code, site_company_name, site_nm, site_url, site_page, site_position,
             site_price_currency, site_rating, site_rating_amount, site_rating_scale, refer_date, price_unit
    
    UNION ALL
    
    SELECT
      pa_model_code,
      pa_brand_nm,
      pa_mktcode,
      pa_mktname,
      pa_model_nm,
      subsidiary,
      country,
      country_code,
      site_company_name,
      site_nm,
      site_url,
      site_page,
      site_position,
      site_price_currency,
      site_rating,
      site_rating_amount,
      site_rating_scale,
      refer_date,
      price_unit,
      0 AS price_local_base,
      AVG(TO_DECIMAL(TRIM(price_local_act), 8, 2)) AS price_local_act,
      0 AS price_local_down,
      0 AS price_local_monthly,
      0 AS price_local_months
    FROM (
      SELECT
        CASE WHEN t_cnt/2 = act_row_num THEN 'Y' 
             WHEN t_cnt/2 + 1 = act_row_num THEN 'Y' 
        END AS flg, 
        *
      FROM (
        SELECT 
          ROW_NUMBER() OVER (
            PARTITION BY a.pa_model_code, a.pa_brand_nm, a.pa_mktcode, a.pa_mktname, a.pa_model_nm, a.country, a.country_code,
                         a.site_nm, a.subsidiary, a.country, a.country_code, a.site_company_name, a.site_nm, a.site_url, a.site_page,
                         a.site_position, a.site_price_currency, a.site_rating, a.site_rating_amount, a.site_rating_scale,
                         a.refer_date, a.price_unit 
            ORDER BY price_local_act ASC
          ) AS act_row_num,
          b.t_cnt,
          a.*
        FROM (
          SELECT * FROM TF_CRAWLING_AP1_IM_10
        ) a
        , (
          SELECT 
            pa_model_code,
            pa_brand_nm,
            pa_mktcode,
            pa_mktname,
            pa_model_nm,
            subsidiary,
            country,
            country_code,
            site_company_name,
            site_nm,
            site_url,
            site_page,
            site_position,
            site_price_currency,
            site_rating,
            site_rating_amount,
            site_rating_scale,
            refer_date,
            price_unit,
            COUNT(1) AS t_cnt
          FROM TF_CRAWLING_AP1_IM_10
          GROUP BY pa_model_code, pa_brand_nm, pa_mktcode, pa_mktname, pa_model_nm,
                   subsidiary, country, country_code, site_company_name, site_nm, site_url, site_page, site_position,
                   site_price_currency, site_rating, site_rating_amount, site_rating_scale, refer_date, price_unit
        ) b
        WHERE a.pa_model_code = b.pa_model_code
          AND a.pa_brand_nm = b.pa_brand_nm
          AND a.pa_mktcode = b.pa_mktcode
          AND a.pa_mktname = b.pa_mktname
          AND a.pa_model_nm = b.pa_model_nm
          AND a.subsidiary = b.subsidiary
          AND a.country = b.country 
          AND a.country_code = b.country_code 
          AND a.site_company_name = b.site_company_name 
          AND a.site_nm = b.site_nm 
          AND a.site_url = b.site_url 
          AND a.site_page = b.site_page 
          AND a.site_position = b.site_position 
          AND a.site_price_currency = b.site_price_currency 
          AND a.site_rating = b.site_rating 
          AND a.site_rating_amount = b.site_rating_amount 
          AND a.site_rating_scale = b.site_rating_scale 
          AND a.refer_date = b.refer_date
          AND a.price_unit = b.price_unit
      ) g
    ) v
    GROUP BY pa_model_code, pa_brand_nm, pa_mktcode, pa_mktname, pa_model_nm,
             subsidiary, country, country_code, site_company_name, site_nm, site_url, site_page, site_position,
             site_price_currency, site_rating, site_rating_amount, site_rating_scale, refer_date, price_unit
  ) s 
  GROUP BY pa_model_code, pa_brand_nm, pa_mktcode, pa_mktname, pa_model_nm,
           subsidiary, country, country_code, site_company_name, site_nm, site_url, site_page, site_position,
           site_price_currency, site_rating, site_rating_amount, site_rating_scale, refer_date, price_unit;

-- Etapa 10
  PERFORM TRUNCATE TABLE TF_CRAWLING_AP1_IM_12;
  PERFORM INSERT INTO TF_CRAWLING_AP1_IM_12
  (
    "MODEL_CODE",
    "BRAND_NM",
    "MKTCODE",
    "MKTNAME",
    "MODEL_NM",
    "SUBSIDIARY",
    "COUNTRY",
    "COUNTRY_CODE",
    "SITE_COMPANY_NAME",
    "SITE_NM",
    "SITE_URL",
    "SITE_PAGE",
    "SITE_POSITION",
    "SITE_PRICE_CURRENCY",
    "SITE_RATING",
    "SITE_RATING_AMOUNT",
    "SITE_RATING_SCALE",
    "REFER_DATE",
    "PRICE_UNIT",
    "PRICE_LOCAL_BASE",
    "PRICE_LOCAL_ACT",
    "PRICE_LOCAL_DOWN",
    "PRICE_LOCAL_MONTHLY",
    "PRICE_LOCAL_MONTHS",
    "UPDATE_FLG",
    "PROCESS_DATETIME",
    "FROM_CURRENCY",
    "TO_CURRENCY",
    "VALID_FROM",
    "EXCHANGE_RATE",
    "MKT_SEGMENT",
    "PRICE_UNIT_USD",
    "PRICE_LOCAL_BASE_USD",
    "PRICE_LOCAL_ACT_USD",
    "PRICE_LOCAL_DOWN_USD",
    "PRICE_LOCAL_MONTHLY_USD",
    "PRICE_LOCAL_MONTHS_USD",
    "VENDOR",
    "MEDIAN_UNIT_PRICE_USD",
    "REFER_WEEK",
    "REFER_WEEK_T",
    "REFER_YEAR"
  )
  SELECT 
    VW_PRICE."MODEL_CODE",
    VW_PRICE."BRAND_NM",
    VW_PRICE."MKTCODE",
    VW_PRICE."MKTNAME",
    VW_PRICE."MODEL_NM",
    VW_PRICE."SUBSIDIARY",
    VW_PRICE."COUNTRY",
    VW_PRICE."COUNTRY_CODE",
    VW_PRICE."SITE_COMPANY_NAME",
    VW_PRICE."SITE_NM",
    VW_PRICE."SITE_URL",
    VW_PRICE."SITE_PAGE",
    VW_PRICE."SITE_POSITION",
    VW_PRICE."SITE_PRICE_CURRENCY",
    VW_PRICE."SITE_RATING",
    VW_PRICE."SITE_RATING_AMOUNT",
    VW_PRICE."SITE_RATING_SCALE",
    VW_PRICE."REFER_DATE",
    VW_PRICE."PRICE_UNIT",
    VW_PRICE."PRICE_LOCAL_BASE",
    VW_PRICE."PRICE_LOCAL_ACT",
    VW_PRICE."PRICE_LOCAL_DOWN",
    VW_PRICE."PRICE_LOCAL_MONTHLY",
    VW_PRICE."PRICE_LOCAL_MONTHS",
    VW_PRICE."UPDATE_FLG",
    VW_PRICE."PROCESS_DATETIME",
    VW_PRICE."FROM_CURRENCY",
    VW_PRICE."TO_CURRENCY",
    VW_PRICE."VALID_FROM",
    VW_PRICE."EXCHANGE_RATE",
    VW_PRICE."MKT_SEGMENT",
    VW_PRICE."PRICE_UNIT_USD",
    VW_PRICE."PRICE_LOCAL_BASE_USD",
    VW_PRICE."PRICE_LOCAL_ACT_USD",
    VW_PRICE."PRICE_LOCAL_DOWN_USD",
    VW_PRICE."PRICE_LOCAL_MONTHLY_USD",
    VW_PRICE."PRICE_LOCAL_MONTHS_USD",
    UPPER(VENDOR.VENDOR),
    MEDIAN.MEDIAN,
    NULL AS REFER_WEEK,
    NULL AS REFER_WEEK_T,
    NULL AS REFER_YEAR
  FROM VW_CRAWLING_ONLINE_PRICE VW_PRICE
  LEFT JOIN (
    SELECT COUNT(1), PROD_HREF, VENDOR
    FROM OW_LAO.ODS_CRAWLING_AP1_IM_PRODUCT_DETAIL
    WHERE VENDOR <> '' AND VENDOR IS NOT NULL 
    GROUP BY PROD_HREF, VENDOR 
    HAVING COUNT(1) = 1
  ) VENDOR ON VENDOR.PROD_HREF = VW_PRICE.SITE_URL
  LEFT JOIN (
    SELECT ROUND(MEDIAN(PRICE_UNIT_USD), 2) AS MEDIAN, COUNTRY, MKTNAME
    FROM OW_LAO.VW_CRAWLING_ONLINE_PRICE 
    GROUP BY COUNTRY, MKTNAME
  ) MEDIAN ON MEDIAN.COUNTRY = VW_PRICE."COUNTRY" AND MEDIAN.MKTNAME = VW_PRICE."MKTNAME";

--################################CARGA DAS FATOS################################
--################################
  PERFORM DELETE FROM FT_CRAWLING_ONLINE_PRICE_DISPLAY_SHARE
  WHERE TO_CHAR("REFER_DATE", 'YYYY-MM-DD') BETWEEN TO_CHAR(TIMESTAMPADD(DAY, -15, CURRENT_DATE), 'YYYY-MM-DD') AND TO_CHAR(CURRENT_DATE, 'YYYY-MM-DD');

  PERFORM INSERT INTO FT_CRAWLING_ONLINE_PRICE_DISPLAY_SHARE
    SELECT * FROM VW_CRAWLING_ONLINE_PRICE_DISPLAY_SHARE;

--################################
  PERFORM DELETE FROM FT_CRAWLING_ONLINE_PRICE_SEGMENT
  WHERE TO_CHAR("REFER_DATE", 'YYYY-MM-DD') BETWEEN TO_CHAR(TIMESTAMPADD(DAY, -15, CURRENT_DATE), 'YYYY-MM-DD') AND TO_CHAR(CURRENT_DATE, 'YYYY-MM-DD');

  PERFORM INSERT INTO FT_CRAWLING_ONLINE_PRICE_SEGMENT
    SELECT * FROM TF_CRAWLING_AP1_IM_12;

  PERFORM UPDATE OW_LAO.FT_CRAWLING_ONLINE_PRICE_SEGMENT F
  SET
    REFER_WEEK = (SELECT DISTINCT YYYYWW FROM OW_MD.DIM_CALENDAR D WHERE TO_CHAR(F.REFER_DATE,'YYYY-MM-DD') = TO_CHAR(D.YYYYMMDD,'YYYY-MM-DD')),
    REFER_WEEK_T = (SELECT DISTINCT 'W' || RIGHT(CAST(YYYYWW AS VARCHAR), 2) FROM OW_MD.DIM_CALENDAR D WHERE TO_CHAR(F.REFER_DATE,'YYYY-MM-DD') = TO_CHAR(D.YYYYMMDD,'YYYY-MM-DD')),
    REFER_YEAR = (SELECT DISTINCT YYYY FROM OW_MD.DIM_CALENDAR D WHERE TO_CHAR(F.REFER_DATE,'YYYY-MM-DD') = TO_CHAR(D.YYYYMMDD,'YYYY-MM-DD'))
  WHERE 
    REFER_WEEK IS NULL;

END;
$$;

-- CALL PROC_CRAWLING_AP1_IM_PT2_V2();
-- ERROR: Severity: ROLLBACK, Message: Table "TF_CRAWLING_AP1_IM_6" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_CRAWLING_AP1_IM_PT2_V2 line 4 at static SQL, Routine: TruncateTable, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Commands/DDL.cpp, Line: 20681, Error Code: 4876, 
-- CALL PROC_CRAWLING_AP1_IM_PT2_V2();
-- ERROR: Severity: ROLLBACK, Message: Table "TF_CRAWLING_AP1_IM_6" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_CRAWLING_AP1_IM_PT2_V2 line 4 at static SQL, Routine: TruncateTable, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Commands/DDL.cpp, Line: 20681, Error Code: 4876, 
