CREATE OR REPLACE PROCEDURE OW_LAO.PROC_PAYMENT_FUNNEL_GATEWAY_STATUS_MAP()
LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM MERGE INTO OW_LAO.DIM_PAYMENT_PAY_GATEWAY_MAPPING AS A
    USING OW_LAO.TMP_PAYMENT_PAY_GATEWAY AS B
    ON A.PAY_GATEWAY = B.PAY_GATEWAY AND A.DATA_SOURCE = B.DATA_SOURCE
    WHEN MATCHED AND (A.GATEWAY <> B.GATEWAY OR COALESCE(A.ACTIVE, FALSE) = FALSE) THEN UPDATE SET
        GATEWAY = B.GATEWAY,
        UPDATED_TIMESTAMP = CURRENT_TIMESTAMP,
        ACTIVE = TRUE,
        REPROCESSING = TRUE
    WHEN NOT MATCHED THEN INSERT (
        DATA_SOURCE,
        PAY_GATEWAY,
        GATEWAY,
        ACTIVE,
        REPROCESSING
    ) VALUES (
        B.DATA_SOURCE,
        B.PAY_GATEWAY,
        B.GATEWAY,
        TRUE,
        TRUE
    );

    PERFORM UPDATE OW_LAO.DIM_PAYMENT_PAY_GATEWAY_MAPPING AS A
    SET ACTIVE = FALSE,
        REPROCESSING = TRUE,
        UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
    WHERE ACTIVE = TRUE
      AND NOT EXISTS (
          SELECT 1
          FROM OW_LAO.TMP_PAYMENT_PAY_GATEWAY B
          WHERE A.DATA_SOURCE = B.DATA_SOURCE
            AND A.PAY_GATEWAY = B.PAY_GATEWAY
            AND A.GATEWAY = B.GATEWAY
      );

    PERFORM UPDATE OW_LAO.ODS_PAYMENT_FUNNEL AS A
    SET PAY_GATEWAY_STATUS = NULL,
        UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
    FROM OW_LAO.DIM_PAYMENT_PAY_GATEWAY_MAPPING B
    WHERE B.DATA_SOURCE = A.PO_PLATAFORM_DATASOURCE
      AND B.PAY_GATEWAY = A.PAY_GATEWAY
      AND B.ACTIVE = FALSE
      AND B.REPROCESSING = TRUE;

    PERFORM UPDATE OW_LAO.ODS_PAYMENT_FUNNEL AS A
    SET PAY_GATEWAY_STATUS = B.GATEWAY,
        UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
    FROM OW_LAO.DIM_PAYMENT_PAY_GATEWAY_MAPPING B
    WHERE B.DATA_SOURCE = A.PO_PLATAFORM_DATASOURCE
      AND B.PAY_GATEWAY = A.PAY_GATEWAY
      AND B.ACTIVE = TRUE
      AND B.REPROCESSING = TRUE;

    PERFORM UPDATE OW_LAO.DIM_PAYMENT_PAY_GATEWAY_MAPPING
    SET REPROCESSING = FALSE
    WHERE REPROCESSING = TRUE;
END;
$$;

-- CALL OW_LAO.PROC_PAYMENT_FUNNEL_GATEWAY_STATUS_MAP();
-- ERROR: Severity: ERROR, Message: Cannot set a NOT NULL column (ID) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure PROC_PAYMENT_FUNNEL_GATEWAY_STATUS_MAP line 3 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3216, Error Code: 2502, 
-- CALL OW_LAO.PROC_PAYMENT_FUNNEL_GATEWAY_STATUS_MAP();
-- ERROR: Severity: ERROR, Message: Cannot set a NOT NULL column (ID) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure PROC_PAYMENT_FUNNEL_GATEWAY_STATUS_MAP line 3 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3216, Error Code: 2502, 
-- SELECT column_name, data_type, is_identity, default_expression, is_nullable
-- FROM v_catalog.columns
-- WHERE table_schema = 'OW_LAO' AND table_name = 'DIM_PAYMENT_PAY_GATEWAY_MAPPING'
-- ORDER BY ordinal_position;
-- ERROR: Severity: ERROR, Message: Column "default_expression" does not exist, Sqlstate: 42703, Routine: transformSQLColumnRef, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Optimizer/OptUtil/ExprUtil.cpp, Line: 7401, Error Code: 2624, 
SELECT column_name, data_type, is_identity, is_nullable
FROM v_catalog.columns
WHERE table_schema = 'OW_LAO' AND table_name = 'DIM_PAYMENT_PAY_GATEWAY_MAPPING'
ORDER BY ordinal_position;
-- column_name | data_type | is_identity | is_nullable
-- ------------+-----------+-------------+------------
-- ID | int | False | False
-- INSERTED_TIMESTAMP | timestamp | False | True
-- UPDATED_TIMESTAMP | timestamp | False | True
-- DATA_SOURCE | varchar(100) | False | False
-- PAY_GATEWAY | varchar(255) | False | True
-- GATEWAY | varchar(255) | False | True
-- ACTIVE | boolean | False | True
-- REPROCESSING | boolean | False | True

-- SELECT GET_DDL('TABLE','OW_LAO.DIM_PAYMENT_PAY_GATEWAY_MAPPING');
-- ERROR: Severity: ERROR, Message: Function GET_DDL(unknown, unknown) does not exist, or permission is denied for GET_DDL(unknown, unknown), Sqlstate: 42883, Hint: No function matches the given name and argument types. You may need to add explicit type casts, Routine: throwErrorFunctionDoesNotMatch, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/ParseFunc.cpp, Line: 4559, Error Code: 3457, 
SELECT table_schema, table_name FROM v_catalog.tables WHERE LOWER(table_schema)='ow_lao' AND LOWER(table_name)='dim_payment_pay_gateway_mapping';
-- table_schema | table_name
-- -------------+-----------
-- OW_LAO | DIM_PAYMENT_PAY_GATEWAY_MAPPING

CREATE OR REPLACE PROCEDURE OW_LAO.PROC_PAYMENT_FUNNEL_GATEWAY_STATUS_MAP()
LANGUAGE PLvSQL AS $$
BEGIN
    -- Update existing mappings where gateway changed or previously inactive/null
    PERFORM UPDATE OW_LAO.DIM_PAYMENT_PAY_GATEWAY_MAPPING A
    SET GATEWAY = B.GATEWAY,
        UPDATED_TIMESTAMP = CURRENT_TIMESTAMP,
        ACTIVE = TRUE,
        REPROCESSING = TRUE
    FROM OW_LAO.TMP_PAYMENT_PAY_GATEWAY B
    WHERE A.PAY_GATEWAY = B.PAY_GATEWAY
      AND A.DATA_SOURCE = B.DATA_SOURCE
      AND (A.GATEWAY <> B.GATEWAY OR COALESCE(A.ACTIVE, FALSE) = FALSE);

    -- Insert new mappings; generate numeric IDs based on current max + row_number
    PERFORM INSERT INTO OW_LAO.DIM_PAYMENT_PAY_GATEWAY_MAPPING (
        ID, DATA_SOURCE, PAY_GATEWAY, GATEWAY, ACTIVE, REPROCESSING
    )
    SELECT 
        COALESCE((SELECT MAX(ID) FROM OW_LAO.DIM_PAYMENT_PAY_GATEWAY_MAPPING),0)
        + ROW_NUMBER() OVER (ORDER BY B.DATA_SOURCE, B.PAY_GATEWAY) AS ID,
        B.DATA_SOURCE,
        B.PAY_GATEWAY,
        B.GATEWAY,
        TRUE,
        TRUE
    FROM OW_LAO.TMP_PAYMENT_PAY_GATEWAY B
    LEFT JOIN OW_LAO.DIM_PAYMENT_PAY_GATEWAY_MAPPING A
      ON A.PAY_GATEWAY = B.PAY_GATEWAY
     AND A.DATA_SOURCE = B.DATA_SOURCE
    WHERE A.PAY_GATEWAY IS NULL;

    -- Deactivate mappings removed from source
    PERFORM UPDATE OW_LAO.DIM_PAYMENT_PAY_GATEWAY_MAPPING A
    SET ACTIVE = FALSE,
        REPROCESSING = TRUE,
        UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
    WHERE ACTIVE = TRUE
      AND NOT EXISTS (
          SELECT 1
          FROM OW_LAO.TMP_PAYMENT_PAY_GATEWAY B
          WHERE A.DATA_SOURCE = B.DATA_SOURCE
            AND A.PAY_GATEWAY = B.PAY_GATEWAY
            AND A.GATEWAY = B.GATEWAY
      );

    -- Nullify gateway status in ODS where mapping was deactivated and flagged for reprocessing
    PERFORM UPDATE OW_LAO.ODS_PAYMENT_FUNNEL A
    SET PAY_GATEWAY_STATUS = NULL,
        UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
    FROM OW_LAO.DIM_PAYMENT_PAY_GATEWAY_MAPPING B
    WHERE B.DATA_SOURCE = A.PO_PLATAFORM_DATASOURCE
      AND B.PAY_GATEWAY = A.PAY_GATEWAY
      AND B.ACTIVE = FALSE
      AND B.REPROCESSING = TRUE;

    -- Update ODS with current active gateway where flagged for reprocessing
    PERFORM UPDATE OW_LAO.ODS_PAYMENT_FUNNEL A
    SET PAY_GATEWAY_STATUS = B.GATEWAY,
        UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
    FROM OW_LAO.DIM_PAYMENT_PAY_GATEWAY_MAPPING B
    WHERE B.DATA_SOURCE = A.PO_PLATAFORM_DATASOURCE
      AND B.PAY_GATEWAY = A.PAY_GATEWAY
      AND B.ACTIVE = TRUE
      AND B.REPROCESSING = TRUE;

    -- Clear reprocessing flags
    PERFORM UPDATE OW_LAO.DIM_PAYMENT_PAY_GATEWAY_MAPPING
    SET REPROCESSING = FALSE
    WHERE REPROCESSING = TRUE;
END;
$$;

CALL OW_LAO.PROC_PAYMENT_FUNNEL_GATEWAY_STATUS_MAP();
-- PROC_PAYMENT_FUNNEL_GATEWAY_STATUS_MAP
-- --------------------------------------
-- 0

