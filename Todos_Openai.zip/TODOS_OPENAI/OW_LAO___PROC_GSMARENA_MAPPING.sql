CREATE OR REPLACE PROCEDURE PROC_GSMARENA_MAPPING()
LANGUAGE PLvSQL AS $$
BEGIN
  
  PERFORM TRUNCATE TABLE ODS_GSM_ARENA_STAGE;
  
  PERFORM INSERT INTO ODS_GSM_ARENA_STAGE
  SELECT  
       "brand_nm"
     , "model_code"
     , "model_nm"
     , "mktcode"
     , "mktname"
     , MAX(CASE WHEN TRIM("width_mm") = '-' THEN NULL ELSE CAST(REGEXP_SUBSTR("width_mm", '\\d+(\\.\\d{1,2})?') AS DOUBLE PRECISION) END) AS "width_mm"
     , MAX(CASE WHEN TRIM("height_mm") = '-' THEN NULL ELSE CAST(REGEXP_SUBSTR("height_mm", '\\d+(\\.\\d{1,2})?') AS DOUBLE PRECISION) END) AS "height_mm"
     , MAX(CASE WHEN TRIM("depth_mm") = '-' THEN NULL ELSE CAST(REGEXP_SUBSTR("depth_mm", '\\d+(\\.\\d{1,2})?') AS DOUBLE PRECISION) END) AS "depth_mm"
     , MAX("display_size") AS "display_size"
     , MAX("ram_in_mb") AS "ram_in_mb"
     , MAX("internal_storage") AS "internal_storage"
     , MAX("dual_sim") AS "dual_sim"
     , MAX("main_camera_mp") AS "main_camera_mp"
     , MAX("front_camera_mp") AS "front_camera_mp"
     , MAX("weight_gramm") AS "weight_gramm"
     , MAX("resolution_wid") AS "resolution_wid"
     , MAX("resolution_hig") AS "resolution_hig"
     , MAX("battery_capacity") AS "battery_capacity"
  FROM (
    SELECT DISTINCT 
           "brand" AS "brand_nm"
         , "modelcode" AS "model_code"
         , "modelnm" AS "model_nm"
         , "mktcode" AS "mktcode"
         , "mktnm" AS "mktname"
         , CASE
             WHEN ( UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" = 'Dimensions_width_in_MM' ) AND "value" IS NOT NULL THEN "value"
             WHEN  "displaynm" = 'Dimensions_Width' THEN "value"
           END AS "width_mm"
         , CASE
             WHEN ( UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" = 'Dimensions_height_in_MM') AND "value" IS NOT NULL THEN "value"
             WHEN  "displaynm" = 'Dimensions_Length' THEN "value"
           END AS "height_mm"
         , CASE
             WHEN ( UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" = 'Dimensions_depth_in_MM' ) AND "value" IS NOT NULL THEN "value"
             WHEN  "displaynm" = 'Dimensions_Thickness' THEN "value"
           END AS "depth_mm"
         , CASE WHEN ( UPPER("subcategory") LIKE '%DISPLAY SIZE%' AND "displaynm" IN ('Display_Display size','(Display) Size') ) THEN "value" END AS "display_size"
         , CASE WHEN ( UPPER("subcategory") LIKE '%RAM%' AND "displaynm" IN ('RAM_RAM Quantity','(Performance) RAM') ) THEN "value" END AS "ram_in_mb"
         , CASE WHEN ( UPPER("subcategory") LIKE '%INTERNAL%' AND "displaynm" IN ('Internal storage' ,'(Performance) Storage')) THEN "value" END AS "internal_storage"
         , CASE WHEN ( UPPER("subcategory") LIKE '%DUAL%' AND "displaynm" = 'Cellular_Dual SIM' ) THEN "value" END AS "dual_sim"
         , CASE WHEN ( UPPER("subcategory") LIKE '%CAMERA%' AND "displaynm" IN ('Main camera_Resolution','(Camera) Rear Main Resol.') ) THEN "value" END AS "main_camera_mp"
         , CASE WHEN ( UPPER("subcategory") LIKE '%FRONT%' AND "displaynm" IN ('Front_Resolution','(Camera) Front Resolution') ) THEN "value" END AS "front_camera_mp"
         , CASE WHEN ( UPPER("subcategory") LIKE '%WEIGHT%' AND "displaynm" IN ('Weight_Weight in Grams','(Design) Weight (g)') ) THEN "value" END AS "weight_gramm"
         , CASE WHEN ( UPPER("subcategory") LIKE '%RESOLUTION%' AND "displaynm" IN ('Resolution_Horizontal','(Display) Resolution H') ) THEN "value" END AS "resolution_wid"
         , CASE WHEN ( UPPER("subcategory") LIKE '%RESOLUTION%' AND "displaynm" IN ('Resolution_Vertical','(Display) Resolution V') ) THEN "value" END AS "resolution_hig"
         , CASE WHEN ( UPPER("subcategory") LIKE '%CAPACITY%' AND "displaynm" IN ('Battery_Capacity','(Performance) Battery Capa.') ) THEN "value" END AS "battery_capacity"
         , CASE WHEN ( "displaynm" = 'Availability_Date' ) THEN "value" END AS "availability_date"
         , "etcstatus"
    FROM ODS_GSM_ARENA_TMP
    WHERE (
       ( UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" IN ('Dimensions_width_in_MM', 'Dimensions_Width') )
    OR ( UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" IN ('Dimensions_height_in_MM', 'Dimensions_Length') )
    OR ( UPPER("subcategory") LIKE '%DIMENSION%' AND "displaynm" IN ('Dimensions_depth_in_MM', 'Dimensions_Thickness') )
    OR ( UPPER("subcategory") LIKE '%DISPLAY SIZE%' AND "displaynm" IN ('Display_Display size','(Display) Size') )
    OR ( UPPER("subcategory") LIKE '%RAM%' AND "displaynm" IN ('RAM_RAM Quantity','(Performance) RAM') )
    OR ( UPPER("subcategory") LIKE '%INTERNAL%' AND "displaynm" IN ('Internal storage' ,'(Performance) Storage') )
    OR ( UPPER("subcategory") LIKE '%DUAL%' AND "displaynm" = 'Cellular_Dual SIM' )
    OR ( UPPER("subcategory") LIKE '%CAMERA%' AND "displaynm" IN ('Main camera_Resolution','(Camera) Rear Main Resol.') )
    OR ( UPPER("subcategory") LIKE '%FRONT%' AND "displaynm" IN ('Front_Resolution','(Camera) Front Resolution') )
    OR ( UPPER("subcategory") LIKE '%WEIGHT%' AND "displaynm" IN ('Weight_Weight in Grams','(Design) Weight (g)') )
    OR ( UPPER("subcategory") LIKE '%RESOLUTION%' AND "displaynm" IN ('Resolution_Horizontal','(Display) Resolution H') )
    OR ( UPPER("subcategory") LIKE '%RESOLUTION%' AND "displaynm" IN ('Resolution_Vertical','(Display) Resolution V') )
    OR ( UPPER("subcategory") LIKE '%CAPACITY%' AND "displaynm" IN ('Battery_Capacity','(Performance) Battery Capa.') )
    OR ( "displaynm" = 'Availability_Date' )
    )
    AND TO_CHAR(LOAD_DATE, 'YYYY-MM-DD') IN (
        SELECT MAX(TO_CHAR(LOAD_DATE, 'YYYY-MM-DD')) FROM "OW_LAO"."ODS_GSM_ARENA_TMP"
    )
    GROUP BY "brand", "modelcode", "modelnm","mktcode","mktnm","subcategory","displaynm", "value", "etcstatus"
  ) s
  WHERE 1=1
  GROUP BY "brand_nm", "model_code", "model_nm","mktcode", "mktname", "etcstatus";

  PERFORM UPDATE ODS_GSM_ARENA_STAGE
   SET
     width_mm = REGEXP_SUBSTR(UPPER(TRIM(width_mm)), '\\d+(\\.\\d{1,2})?', 1, 1)
   , height_mm = REGEXP_SUBSTR(UPPER(TRIM(height_mm)), '\\d+(\\.\\d{1,2})?', 1, 1)
   , depth_mm = REGEXP_SUBSTR(UPPER(TRIM(depth_mm)), '\\d+(\\.\\d{1,2})?', 1, 1)
   , display_size = REGEXP_SUBSTR(UPPER(TRIM(display_size)), '\\d+(\\.\\d{1,2})?', 1, 1)
   , ram_in_mb = REGEXP_SUBSTR(UPPER(TRIM(ram_in_mb)), '\\d+(\\.\\d{1,2})?', 1, 1)
   , internal_storage = REGEXP_SUBSTR(UPPER(TRIM(internal_storage)), '\\d+(\\.\\d{1,2})?', 1, 1)
   , main_camera_mp = REGEXP_SUBSTR(UPPER(TRIM(main_camera_mp)), '\\d+(\\.\\d{1,2})?', 1, 1)
   , front_camera_mp = REGEXP_SUBSTR(UPPER(TRIM(front_camera_mp)), '\\d+(\\.\\d{1,2})?', 1, 1)
   , weight_gramm = REGEXP_SUBSTR(UPPER(TRIM(weight_gramm)), '\\d+(\\.\\d{1,2})?', 1, 1)
   , resolution_wid = REGEXP_SUBSTR(UPPER(TRIM(resolution_wid)), '\\d+(\\.\\d{1,2})?', 1, 1)
   , resolution_hig = REGEXP_SUBSTR(UPPER(TRIM(resolution_hig)), '\\d+(\\.\\d{1,2})?', 1, 1)
   , battery_capacity = REGEXP_SUBSTR(UPPER(TRIM(battery_capacity)), '\\d+(\\.\\d{1,2})?', 1, 1)
  ;

  PERFORM INSERT INTO ODS_GSM_ARENA_STAGE
  SELECT  
     brand_nm
   , CONCAT(model_code, '_X')
   , model_nm
   , mktcode
   , mktname
   , TO_CHAR( SIGN(TO_FLOAT(width_mm)) * FLOOR(ABS(TO_FLOAT(width_mm)) + 0.5 - CASE WHEN ABS(TO_FLOAT(width_mm)) - FLOOR(ABS(TO_FLOAT(width_mm))) = 0.5 THEN 1 ELSE 0 END) ) AS width_mm
   , TO_CHAR( SIGN(TO_FLOAT(height_mm)) * FLOOR(ABS(TO_FLOAT(height_mm)) + 0.5 - CASE WHEN ABS(TO_FLOAT(height_mm)) - FLOOR(ABS(TO_FLOAT(height_mm))) = 0.5 THEN 1 ELSE 0 END) ) AS height_mm
   , TO_CHAR( SIGN(TO_FLOAT(depth_mm)) * FLOOR(ABS(TO_FLOAT(depth_mm)) + 0.5 - CASE WHEN ABS(TO_FLOAT(depth_mm)) - FLOOR(ABS(TO_FLOAT(depth_mm))) = 0.5 THEN 1 ELSE 0 END) ) AS depth_mm
   , display_size
   , ram_in_mb
   , internal_storage
   , dual_sim
   , main_camera_mp
   , front_camera_mp
   , weight_gramm
   , resolution_wid
   , resolution_hig
   , battery_capacity
  FROM ODS_GSM_ARENA_STAGE;

  PERFORM UPDATE ODS_GSM_ARENA_STAGE
   SET
      width_mm = TO_CHAR(CAST(NULLIF(width_mm,'') AS NUMERIC(8,1)))
    , height_mm = TO_CHAR(CAST(NULLIF(height_mm,'') AS NUMERIC(8,1)))
    , depth_mm = TO_CHAR(CAST(NULLIF(depth_mm,'') AS NUMERIC(8,1)))
    , display_size = TO_CHAR(CAST(NULLIF(display_size,'') AS NUMERIC(6,1)))
    , ram_in_mb = TO_CHAR(CAST(NULLIF(ram_in_mb,'') AS NUMERIC(16,1)))
    , internal_storage = TO_CHAR(CAST(NULLIF(internal_storage,'') AS NUMERIC(8,0)))
    , main_camera_mp = TO_CHAR(CAST(NULLIF(main_camera_mp,'') AS NUMERIC(8,0)))
    , front_camera_mp = TO_CHAR(CAST(NULLIF(front_camera_mp,'') AS NUMERIC(8,0)))
    , weight_gramm = TO_CHAR(CAST(NULLIF(weight_gramm,'') AS NUMERIC(8,1)))
    , resolution_wid = TO_CHAR(CAST(NULLIF(resolution_wid,'') AS NUMERIC(8,0)))
    , resolution_hig = TO_CHAR(CAST(NULLIF(resolution_hig,'') AS NUMERIC(8,0)))
    , battery_capacity = TO_CHAR(CAST(NULLIF(battery_capacity,'') AS NUMERIC(8,0)));

  PERFORM UPDATE ODS_GSM_ARENA_STAGE
   SET
      width_mm = CASE WHEN width_mm IS NULL OR width_mm = '' THEN '$' ELSE width_mm END
    , height_mm = CASE WHEN height_mm IS NULL OR height_mm = '' THEN '$' ELSE height_mm END
    , depth_mm = CASE WHEN depth_mm IS NULL OR depth_mm = '' THEN '$' ELSE depth_mm END 
    , display_size = CASE WHEN display_size IS NULL OR display_size = '' THEN '$' ELSE display_size END 
    , ram_in_mb = CASE WHEN ram_in_mb IS NULL OR ram_in_mb = '' THEN '$' ELSE ram_in_mb END
    , internal_storage = CASE WHEN internal_storage IS NULL OR internal_storage = '' THEN '$' ELSE internal_storage END
    , main_camera_mp = CASE WHEN main_camera_mp IS NULL OR main_camera_mp = '' THEN '$' ELSE main_camera_mp END
    , front_camera_mp = CASE WHEN front_camera_mp IS NULL OR front_camera_mp = '' THEN '$' ELSE front_camera_mp END
    , weight_gramm = CASE WHEN weight_gramm IS NULL OR weight_gramm = '' THEN '$' ELSE weight_gramm END
    , resolution_wid = CASE WHEN resolution_wid IS NULL OR resolution_wid = '' THEN '$' ELSE resolution_wid END
    , resolution_hig = CASE WHEN resolution_hig IS NULL OR resolution_hig = '' THEN '$' ELSE resolution_hig END
    , battery_capacity = CASE WHEN battery_capacity IS NULL OR battery_capacity = '' THEN '$' ELSE battery_capacity END
    , dual_sim = CASE WHEN dual_sim IS NULL OR dual_sim = '' THEN '$' ELSE dual_sim END
  ;

  PERFORM TRUNCATE TABLE MP_GSMARENA_MERGE_DATA_MAPPING;
  PERFORM INSERT INTO MP_GSMARENA_MERGE_DATA_MAPPING
  SELECT * FROM ODS_GSM_ARENA_STAGE;

  PERFORM TRUNCATE TABLE MP_GSMARENA_MERGE_DATA_MAPPING_KEY;
  PERFORM INSERT INTO MP_GSMARENA_MERGE_DATA_MAPPING_KEY
  SELECT 
    brand_nm, 
    model_code,
    model_nm, 
    mktname,
    width_mm,
    height_mm,
    depth_mm,
    display_size,
    ram_in_mb,
    internal_storage,
    dual_sim,
    main_camera_mp,
    front_camera_mp,
    weight_gramm,
    resolution_wid,
    resolution_hig,
    battery_capacity,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'')) as case1,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'')) as case2,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'')) as case3,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'')) as case4,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'')) as case5,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( front_camera_mp,'')) as case6,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( ram_in_mb,'')) as case7,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( internal_storage,'')) as case8,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( battery_capacity,'')) as case9,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( dual_sim,'')) as case10,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'')) as case11,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'')) as case12,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'')) as case13,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( main_camera_mp,'')) as case14,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( front_camera_mp,'')) as case15,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( ram_in_mb,'')) as case16,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( internal_storage,'')) as case17,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( battery_capacity,'')) as case18,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( dual_sim,'')) as case19,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_wid,'')) as case20,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_hig,'')) as case21,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( main_camera_mp,'')) as case22,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( front_camera_mp,'')) as case23,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( ram_in_mb,'')) as case24,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( internal_storage,'')) as case25,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( battery_capacity,'')) as case26,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( dual_sim,'')) as case27,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( resolution_hig,'')) as case28,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( main_camera_mp,'')) as case29,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( front_camera_mp,'')) as case30,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( ram_in_mb,'')) as case31,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( internal_storage,'')) as case32,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( battery_capacity,'')) as case33,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( dual_sim,'')) as case34,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( main_camera_mp,'')) as case35,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( front_camera_mp,'')) as case36,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( ram_in_mb,'')) as case37,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( internal_storage,'')) as case38,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( battery_capacity,'')) as case39,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( dual_sim,'')) as case40,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'')) as case41,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case42,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case43,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case44,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case45,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case46,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case47,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case48,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case49,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'')) as case50,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( battery_capacity,'')) as case51,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( dual_sim,'')) as case52,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case53,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case54,
    (COALESCE(height_mm,'') || '_' || COALESCE( width_mm,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case55,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'')) as case56,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'')) as case57,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'')) as case58,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( main_camera_mp,'')) as case59,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( front_camera_mp,'')) as case60,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( ram_in_mb,'')) as case61,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( internal_storage,'')) as case62,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( battery_capacity,'')) as case63,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( dual_sim,'')) as case64,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_wid,'')) as case65,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_hig,'')) as case66,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( main_camera_mp,'')) as case67,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( front_camera_mp,'')) as case68,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( ram_in_mb,'')) as case69,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( internal_storage,'')) as case70,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( battery_capacity,'')) as case71,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( dual_sim,'')) as case72,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( resolution_hig,'')) as case73,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( main_camera_mp,'')) as case74,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( front_camera_mp,'')) as case75,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( ram_in_mb,'')) as case76,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( internal_storage,'')) as case77,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( battery_capacity,'')) as case78,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( dual_sim,'')) as case79,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( main_camera_mp,'')) as case80,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( front_camera_mp,'')) as case81,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( ram_in_mb,'')) as case82,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( internal_storage,'')) as case83,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( battery_capacity,'')) as case84,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( dual_sim,'')) as case85,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'')) as case86,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case87,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case88,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case89,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case90,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case91,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case92,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case93,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case94,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'')) as case95,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( battery_capacity,'')) as case96,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( dual_sim,'')) as case97,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case98,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case99,
    (COALESCE(height_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case100,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_wid,'')) as case101,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_hig,'')) as case102,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( main_camera_mp,'')) as case103,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( front_camera_mp,'')) as case104,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( ram_in_mb,'')) as case105,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( internal_storage,'')) as case106,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( battery_capacity,'')) as case107,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( dual_sim,'')) as case108,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( resolution_hig,'')) as case109,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( main_camera_mp,'')) as case110,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( front_camera_mp,'')) as case111,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( ram_in_mb,'')) as case112,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( internal_storage,'')) as case113,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( battery_capacity,'')) as case114,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( dual_sim,'')) as case115,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( main_camera_mp,'')) as case116,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( front_camera_mp,'')) as case117,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( ram_in_mb,'')) as case118,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( internal_storage,'')) as case119,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( battery_capacity,'')) as case120,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( dual_sim,'')) as case121,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'')) as case122,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case123,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case124,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case125,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case126,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case127,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case128,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case129,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case130,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'')) as case131,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( battery_capacity,'')) as case132,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( dual_sim,'')) as case133,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case134,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case135,
    (COALESCE(height_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case136,
    (COALESCE(height_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( resolution_hig,'')) as case137,
    (COALESCE(height_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( main_camera_mp,'')) as case138,
    (COALESCE(height_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( front_camera_mp,'')) as case139,
    (COALESCE(height_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( ram_in_mb,'')) as case140,
    (COALESCE(height_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( internal_storage,'')) as case141,
    (COALESCE(height_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( battery_capacity,'')) as case142,
    (COALESCE(height_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( dual_sim,'')) as case143,
    (COALESCE(height_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( main_camera_mp,'')) as case144,
    (COALESCE(height_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( front_camera_mp,'')) as case145,
    (COALESCE(height_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( ram_in_mb,'')) as case146,
    (COALESCE(height_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( internal_storage,'')) as case147,
    (COALESCE(height_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( battery_capacity,'')) as case148,
    (COALESCE(height_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( dual_sim,'')) as case149,
    (COALESCE(height_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'')) as case150,
    (COALESCE(height_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case151,
    (COALESCE(height_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case152,
    (COALESCE(height_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case153,
    (COALESCE(height_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case154,
    (COALESCE(height_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case155,
    (COALESCE(height_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case156,
    (COALESCE(height_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case157,
    (COALESCE(height_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case158,
    (COALESCE(height_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'')) as case159,
    (COALESCE(height_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( battery_capacity,'')) as case160,
    (COALESCE(height_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( dual_sim,'')) as case161,
    (COALESCE(height_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case162,
    (COALESCE(height_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case163,
    (COALESCE(height_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case164,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( main_camera_mp,'')) as case165,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( front_camera_mp,'')) as case166,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( ram_in_mb,'')) as case167,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( internal_storage,'')) as case168,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( battery_capacity,'')) as case169,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( dual_sim,'')) as case170,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'')) as case171,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case172,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case173,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case174,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case175,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case176,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case177,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case178,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case179,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'')) as case180,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( battery_capacity,'')) as case181,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( dual_sim,'')) as case182,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case183,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case184,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case185,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'')) as case186,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case187,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case188,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case189,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case190,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case191,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case192,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case193,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case194,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'')) as case195,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( battery_capacity,'')) as case196,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( dual_sim,'')) as case197,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case198,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case199,
    (COALESCE(height_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case200,
    (COALESCE(height_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case201,
    (COALESCE(height_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case202,
    (COALESCE(height_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case203,
    (COALESCE(height_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case204,
    (COALESCE(height_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'')) as case205,
    (COALESCE(height_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( battery_capacity,'')) as case206,
    (COALESCE(height_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( dual_sim,'')) as case207,
    (COALESCE(height_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case208,
    (COALESCE(height_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case209,
    (COALESCE(height_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case210,
    (COALESCE(height_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'')) as case211,
    (COALESCE(height_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( battery_capacity,'')) as case212,
    (COALESCE(height_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( dual_sim,'')) as case213,
    (COALESCE(height_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case214,
    (COALESCE(height_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case215,
    (COALESCE(height_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case216,
    (COALESCE(height_mm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case217,
    (COALESCE(height_mm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case218,
    (COALESCE(height_mm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case219,
    (COALESCE(height_mm,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case220,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'')) as case221,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'')) as case222,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'')) as case223,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( main_camera_mp,'')) as case224,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( front_camera_mp,'')) as case225,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( ram_in_mb,'')) as case226,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( internal_storage,'')) as case227,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( battery_capacity,'')) as case228,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( dual_sim,'')) as case229,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_wid,'')) as case230,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_hig,'')) as case231,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( main_camera_mp,'')) as case232,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( front_camera_mp,'')) as case233,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( ram_in_mb,'')) as case234,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( internal_storage,'')) as case235,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( battery_capacity,'')) as case236,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( dual_sim,'')) as case237,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( resolution_hig,'')) as case238,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( main_camera_mp,'')) as case239,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( front_camera_mp,'')) as case240,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( ram_in_mb,'')) as case241,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( internal_storage,'')) as case242,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( battery_capacity,'')) as case243,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( dual_sim,'')) as case244,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( main_camera_mp,'')) as case245,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( front_camera_mp,'')) as case246,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( ram_in_mb,'')) as case247,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( internal_storage,'')) as case248,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( battery_capacity,'')) as case249,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( dual_sim,'')) as case250,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'')) as case251,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case252,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case253,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case254,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case255,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case256,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case257,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case258,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case259,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'')) as case260,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( battery_capacity,'')) as case261,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( dual_sim,'')) as case262,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case263,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case264,
    (COALESCE(width_mm,'') || '_' || COALESCE( depth_mm,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case265,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_wid,'')) as case266,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_hig,'')) as case267,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( main_camera_mp,'')) as case268,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( front_camera_mp,'')) as case269,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( ram_in_mb,'')) as case270,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( internal_storage,'')) as case271,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( battery_capacity,'')) as case272,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( dual_sim,'')) as case273,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( resolution_hig,'')) as case274,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( main_camera_mp,'')) as case275,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( front_camera_mp,'')) as case276,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( ram_in_mb,'')) as case277,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( internal_storage,'')) as case278,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( battery_capacity,'')) as case279,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( dual_sim,'')) as case280,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( main_camera_mp,'')) as case281,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( front_camera_mp,'')) as case282,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( ram_in_mb,'')) as case283,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( internal_storage,'')) as case284,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( battery_capacity,'')) as case285,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( dual_sim,'')) as case286,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'')) as case287,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case288,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case289,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case290,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case291,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case292,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case293,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case294,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case295,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'')) as case296,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( battery_capacity,'')) as case297,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( dual_sim,'')) as case298,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case299,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case300,
    (COALESCE(width_mm,'') || '_' || COALESCE( weight_gramm,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case301,
    (COALESCE(width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( resolution_hig,'')) as case302,
    (COALESCE(width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( main_camera_mp,'')) as case303,
    (COALESCE(width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( front_camera_mp,'')) as case304,
    (COALESCE(width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( ram_in_mb,'')) as case305,
    (COALESCE(width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( internal_storage,'')) as case306,
    (COALESCE(width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( battery_capacity,'')) as case307,
    (COALESCE(width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_wid,'') || '_' || COALESCE( dual_sim,'')) as case308,
    (COALESCE(width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( main_camera_mp,'')) as case309,
    (COALESCE(width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( front_camera_mp,'')) as case310,
    (COALESCE(width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( ram_in_mb,'')) as case311,
    (COALESCE(width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( internal_storage,'')) as case312,
    (COALESCE(width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( battery_capacity,'')) as case313,
    (COALESCE(width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( dual_sim,'')) as case314,
    (COALESCE(width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'')) as case315,
    (COALESCE(width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case316,
    (COALESCE(width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case317,
    (COALESCE(width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case318,
    (COALESCE(width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case319,
    (COALESCE(width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case320,
    (COALESCE(width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case321,
    (COALESCE(width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case322,
    (COALESCE(width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case323,
    (COALESCE(width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'')) as case324,
    (COALESCE(width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( battery_capacity,'')) as case325,
    (COALESCE(width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( dual_sim,'')) as case326,
    (COALESCE(width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case327,
    (COALESCE(width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case328,
    (COALESCE(width_mm,'') || '_' || COALESCE( display_size,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case329,
    (COALESCE(resolution_wid,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'')) as case330,
    (COALESCE(resolution_wid,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case331,
    (COALESCE(resolution_wid,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case332,
    (COALESCE(resolution_wid,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case333,
    (COALESCE(resolution_wid,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case334,
    (COALESCE(resolution_wid,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case335,
    (COALESCE(resolution_wid,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case336,
    (COALESCE(resolution_wid,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case337,
    (COALESCE(resolution_wid,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case338,
    (COALESCE(resolution_wid,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'')) as case339,
    (COALESCE(resolution_wid,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( battery_capacity,'')) as case340,
    (COALESCE(resolution_wid,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( dual_sim,'')) as case341,
    (COALESCE(resolution_wid,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case342,
    (COALESCE(resolution_wid,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case343,
    (COALESCE(resolution_wid,'') || '_' || COALESCE( resolution_hig,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case344,
    (COALESCE(resolution_wid,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case345,
    (COALESCE(resolution_wid,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'')) as case346,
    (COALESCE(resolution_wid,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( battery_capacity,'')) as case347,
    (COALESCE(resolution_wid,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( dual_sim,'')) as case348,
    (COALESCE(resolution_wid,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case349,
    (COALESCE(resolution_wid,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case350,
    (COALESCE(resolution_wid,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case351,
    (COALESCE(resolution_wid,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'')) as case352,
    (COALESCE(resolution_wid,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( battery_capacity,'')) as case353,
    (COALESCE(resolution_wid,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( dual_sim,'')) as case354,
    (COALESCE(resolution_wid,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case355,
    (COALESCE(resolution_wid,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case356,
    (COALESCE(resolution_wid,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case357,
    (COALESCE(resolution_wid,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case358,
    (COALESCE(resolution_wid,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case359,
    (COALESCE(resolution_wid,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case360,
    (COALESCE(resolution_wid,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case361,
    (COALESCE(resolution_hig,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'')) as case362,
    (COALESCE(resolution_hig,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( internal_storage,'')) as case363,
    (COALESCE(resolution_hig,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( battery_capacity,'')) as case364,
    (COALESCE(resolution_hig,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( dual_sim,'')) as case365,
    (COALESCE(resolution_hig,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'')) as case366,
    (COALESCE(resolution_hig,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( battery_capacity,'')) as case367,
    (COALESCE(resolution_hig,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( dual_sim,'')) as case368,
    (COALESCE(resolution_hig,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case369,
    (COALESCE(resolution_hig,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case370,
    (COALESCE(resolution_hig,'') || '_' || COALESCE( main_camera_mp,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case371,
    (COALESCE(resolution_hig,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'')) as case372,
    (COALESCE(resolution_hig,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( battery_capacity,'')) as case373,
    (COALESCE(resolution_hig,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( dual_sim,'')) as case374,
    (COALESCE(resolution_hig,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case375,
    (COALESCE(resolution_hig,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case376,
    (COALESCE(resolution_hig,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case377,
    (COALESCE(resolution_hig,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case378,
    (COALESCE(resolution_hig,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case379,
    (COALESCE(resolution_hig,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case380,
    (COALESCE(resolution_hig,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case381,
    (COALESCE(main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'')) as case382,
    (COALESCE(main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( battery_capacity,'')) as case383,
    (COALESCE(main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( dual_sim,'')) as case384,
    (COALESCE(main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case385,
    (COALESCE(main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case386,
    (COALESCE(main_camera_mp,'') || '_' || COALESCE( front_camera_mp,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case387,
    (COALESCE(main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case388,
    (COALESCE(main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case389,
    (COALESCE(main_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case390,
    (COALESCE(main_camera_mp,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case391,
    (COALESCE(front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case392,
    (COALESCE(front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case393,
    (COALESCE(front_camera_mp,'') || '_' || COALESCE( ram_in_mb,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case394,
    (COALESCE(front_camera_mp,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case395,
    (COALESCE(front_camera_mp,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case396,
    (COALESCE(front_camera_mp,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case397,
    (COALESCE(ram_in_mb,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( battery_capacity,'')) as case398,
    (COALESCE(ram_in_mb,'') || '_' || COALESCE( internal_storage,'') || '_' || COALESCE( dual_sim,'')) as case399,
    (COALESCE(ram_in_mb,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case400,
    (COALESCE(internal_storage,'') || '_' || COALESCE( battery_capacity,'') || '_' || COALESCE( dual_sim,'')) as case401
  FROM ODS_GSM_ARENA_STAGE;

END;
$$;

-- CALL PROC_GSMARENA_MAPPING();
-- ERROR: Severity: ROLLBACK, Message: Table "ODS_GSM_ARENA_STAGE" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_GSMARENA_MAPPING line 4 at static SQL, Routine: TruncateTable, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Commands/DDL.cpp, Line: 20681, Error Code: 4876, 
-- CALL PROC_GSMARENA_MAPPING();
-- ERROR: Severity: ROLLBACK, Message: Table "ODS_GSM_ARENA_STAGE" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_GSMARENA_MAPPING line 4 at static SQL, Routine: TruncateTable, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Commands/DDL.cpp, Line: 20681, Error Code: 4876, 
