CREATE OR REPLACE PROCEDURE OW_LAO.PROC_D2C_VTEX_PROMOTION_PROCESS()
LANGUAGE PLvSQL AS $$
DECLARE
  p_DATE_INI DATE; 
  p_DATE_INICIAL DATE := DATE '2024-07-01';
  p_DATE_FINAL DATE := DATE '2024-08-01';
  i INT := 0;
BEGIN
  WHILE p_DATE_INICIAL <= p_DATE_FINAL LOOP
    i := i + 1;
    p_DATE_INI := TIMESTAMPADD(DAY, i * 7, p_DATE_INICIAL);
    PERFORM CALL OW_LAO.PROC_D2C_VTEX_PROMOTION(p_DATE_INI, TIMESTAMPADD(DAY, 7, p_DATE_INI));
    p_DATE_INICIAL := TIMESTAMPADD(DAY, i * 7, p_DATE_INICIAL);
  END LOOP;
END;
$$;

-- CALL OW_LAO.PROC_D2C_VTEX_PROMOTION_PROCESS();
-- ERROR: Severity: ERROR, Message: Function OW_LAO.PROC_D2C_VTEX_PROMOTION(date, timestamp) does not exist, or permission is denied for OW_LAO.PROC_D2C_VTEX_PROMOTION(date, timestamp), Sqlstate: 42883, Hint: No function matches the given name and argument types. You may need to add explicit type casts, Where: PL/vSQL procedure PROC_D2C_VTEX_PROMOTION_PROCESS line 11 at static SQL, Routine: throwErrorFunctionDoesNotMatch, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/ParseFunc.cpp, Line: 4559, Error Code: 3457, 
-- CALL OW_LAO.PROC_D2C_VTEX_PROMOTION_PROCESS();
-- ERROR: Severity: ERROR, Message: Function OW_LAO.PROC_D2C_VTEX_PROMOTION(date, timestamp) does not exist, or permission is denied for OW_LAO.PROC_D2C_VTEX_PROMOTION(date, timestamp), Sqlstate: 42883, Hint: No function matches the given name and argument types. You may need to add explicit type casts, Where: PL/vSQL procedure PROC_D2C_VTEX_PROMOTION_PROCESS line 11 at static SQL, Routine: throwErrorFunctionDoesNotMatch, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/ParseFunc.cpp, Line: 4559, Error Code: 3457, 
CREATE OR REPLACE PROCEDURE OW_LAO.PROC_D2C_VTEX_PROMOTION_PROCESS()
LANGUAGE PLvSQL AS $$
DECLARE
  p_DATE_INI DATE; 
  p_DATE_INICIAL DATE := DATE '2024-07-01';
  p_DATE_FINAL DATE := DATE '2024-08-01';
  i INT := 0;
BEGIN
  WHILE p_DATE_INICIAL <= p_DATE_FINAL LOOP
    i := i + 1;
    p_DATE_INI := (TIMESTAMPADD(DAY, i * 7, p_DATE_INICIAL))::DATE;
    PERFORM CALL OW_LAO.PROC_D2C_VTEX_PROMOTION(p_DATE_INI, (TIMESTAMPADD(DAY, 7, p_DATE_INI))::DATE);
    p_DATE_INICIAL := (TIMESTAMPADD(DAY, i * 7, p_DATE_INICIAL))::DATE;
  END LOOP;
END;
$$;

-- CALL OW_LAO.PROC_D2C_VTEX_PROMOTION_PROCESS();
-- ERROR: Severity: ERROR, Message: Function OW_LAO.PROC_D2C_VTEX_PROMOTION(date, date) does not exist, or permission is denied for OW_LAO.PROC_D2C_VTEX_PROMOTION(date, date), Sqlstate: 42883, Hint: No function matches the given name and argument types. You may need to add explicit type casts, Where: PL/vSQL procedure PROC_D2C_VTEX_PROMOTION_PROCESS line 11 at static SQL, Routine: throwErrorFunctionDoesNotMatch, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/ParseFunc.cpp, Line: 4559, Error Code: 3457, 
-- CALL OW_LAO.PROC_D2C_VTEX_PROMOTION_PROCESS();
-- ERROR: Severity: ERROR, Message: Function OW_LAO.PROC_D2C_VTEX_PROMOTION(date, date) does not exist, or permission is denied for OW_LAO.PROC_D2C_VTEX_PROMOTION(date, date), Sqlstate: 42883, Hint: No function matches the given name and argument types. You may need to add explicit type casts, Where: PL/vSQL procedure PROC_D2C_VTEX_PROMOTION_PROCESS line 11 at static SQL, Routine: throwErrorFunctionDoesNotMatch, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/ParseFunc.cpp, Line: 4559, Error Code: 3457, 
-- SELECT schema_name, procedure_name, argument_data_types
-- FROM v_catalog.procedures
-- WHERE procedure_name ILIKE 'PROC_D2C_VTEX_PROMOTION%';
-- ERROR: Severity: ERROR, Message: Relation "v_catalog.procedures" does not exist, Sqlstate: 42V01, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
