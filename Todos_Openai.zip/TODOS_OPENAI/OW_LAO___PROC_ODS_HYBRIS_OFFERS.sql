CREATE OR REPLACE PROCEDURE OW_LAO.PROC_ODS_HYBRIS_OFFERS()
LANGUAGE PLvSQL AS $$
BEGIN
  PERFORM MERGE INTO OW_LAO.ODS_HYBRIS_OFFERS a
  USING (
      SELECT * FROM (
          SELECT ROW_NUMBER() OVER(
                     PARTITION BY country_cd, order_id, line_item_id, offer_id
                     ORDER BY file_generated_at DESC
                 ) AS dedup,
                 a.*
            FROM OW_LAO.RAW_HYBRIS_OFFERS a
           WHERE NOT EXISTS (
                     SELECT 1
                       FROM OW_LAO.ODS_HYBRIS_OFFERS aa
                      WHERE aa.country_cd = a.country_cd
                        AND aa.order_id = a.order_id
                        AND aa.line_item_id = a.line_item_id
                        AND aa.offer_id = a.offer_id
                        AND aa.file_generated_at >= a.file_generated_at
                 )
      ) s
      WHERE s.dedup = 1
  ) b
  ON b.country_cd = a.country_cd
 AND b.order_id = a.order_id
 AND b.line_item_id = a.line_item_id
 AND b.offer_id = a.offer_id
  WHEN MATCHED THEN UPDATE SET
                                     a."LEVEL" = b."LEVEL"
                                   , a."ORDER_ID" = b."ORDER_ID"
                                   , a."COUNTRY_CD" = b."COUNTRY_CD"
                                   , a."ORDER_TIME_UTC" = b."ORDER_TIME_UTC"
                                   , a."ORDER_TIME_LOCAL" = b."ORDER_TIME_LOCAL"
                                   , a."EPP_PLAN_NAME" = b."EPP_PLAN_NAME"
                                   , a."CUSTOMER_LOGIN_ID" = b."CUSTOMER_LOGIN_ID"
                                   , a."CUSTOMER_EMAIL_ID" = b."CUSTOMER_EMAIL_ID"
                                   , a."CUSTOMER_MOBILE_NUMBER" = b."CUSTOMER_MOBILE_NUMBER"
                                   , a."CUSTOMER_USERID_TYPE" = b."CUSTOMER_USERID_TYPE"
                                   , a."PLATFORM" = b."PLATFORM"
                                   , a."ORDER_STATUS" = b."ORDER_STATUS"
                                   , a."ORDER_FRAUD_STATUS" = b."ORDER_FRAUD_STATUS"
                                   , a."LINE_ITEM_STATUS" = b."LINE_ITEM_STATUS"
                                   , a."ORDER_CLONED_FROM" = b."ORDER_CLONED_FROM"
                                   , a."ORDER_CHANNEL_CODE" = b."ORDER_CHANNEL_CODE"
                                   , a."PO_ID" = b."PO_ID"
                                   , a."SALES_APP" = b."SALES_APP"
                                   , a."LINE_ITEM_ID" = b."LINE_ITEM_ID"
                                   , a."SKU_MEMORY" = b."SKU_MEMORY"
                                   , a."PRODUCT_FAMILY" = b."PRODUCT_FAMILY"
                                   , a."PRODUCT_CATEGORY" = b."PRODUCT_CATEGORY"
                                   , a."COLOR" = b."COLOR"
                                   , a."PRODUCT_NAME" = b."PRODUCT_NAME"
                                   , a."PRODUCT_TYPE" = b."PRODUCT_TYPE"
                                   , a."PRODUCT_MODEL_CODE" = b."PRODUCT_MODEL_CODE"
                                   , a."PRODUCT_MODEL_NAME" = b."PRODUCT_MODEL_NAME"
                                   , a."SHORT_DESCRIPTION" = b."SHORT_DESCRIPTION"
                                   , a."LONG_DESCRIPTION" = b."LONG_DESCRIPTION"
                                   , a."FAMILY_ID" = b."FAMILY_ID"
                                   , a."SKU" = b."SKU"
                                   , a."EAN" = b."EAN"
                                   , a."IS_ASSURANT_SKU" = b."IS_ASSURANT_SKU"
                                   , a."IS_ACCESSORY" = b."IS_ACCESSORY"
                                   , a."IS_FINANCING_ELIGIBLE" = b."IS_FINANCING_ELIGIBLE"
                                   , a."IS_FLAGSHIP" = b."IS_FLAGSHIP"
                                   , a."TXN_SALES_AMOUNT" = b."TXN_SALES_AMOUNT"
                                   , a."TXN_SALE_CURRENCY" = b."TXN_SALE_CURRENCY"
                                   , a."TXN_OFFER_DISCOUNT_AMOUNT" = b."TXN_OFFER_DISCOUNT_AMOUNT"
                                   , a."COUPON_CODE" = b."COUPON_CODE"
                                   , a."CAMPAIGN_ID" = b."CAMPAIGN_ID"
                                   , a."OFFER_ID" = b."OFFER_ID"
                                   , a."OFFER_NAME" = b."OFFER_NAME"
                                   , a."OFFER_TYPE" = b."OFFER_TYPE"
                                   , a."OFFER_START_DATE" = b."OFFER_START_DATE"
                                   , a."OFFER_END_DATE" = b."OFFER_END_DATE"
                                   , a."SALES_PITCH" = b."SALES_PITCH"
                                   , a."OFFER_STATUS" = b."OFFER_STATUS"
                                   , a."COUNTRY_GROUP" = b."COUNTRY_GROUP"
                                   , a."PROGRAM_TYPE" = b."PROGRAM_TYPE"
                                   , a."STORE_ID" = b."STORE_ID"
                                   , a."STORE_NAME" = b."STORE_NAME"
                                   , a."STORE_TYPE" = b."STORE_TYPE"
                                   , a."ORDER_TYPE" = b."ORDER_TYPE"
                                   , a."ORDER_SALE_AMOUNT" = b."ORDER_SALE_AMOUNT"
                                   , a."TAXONOMY_PRODUCT_DIVISION_2_DIGIT" = b."TAXONOMY_PRODUCT_DIVISION_2_DIGIT"
                                   , a."FILE_NAME_FROM_FILE" = b."FILE_NAME_FROM_FILE"
                                   , a."LOAD_DATE" = b."LOAD_DATE"
                                   , a."FILE_NAME" = b."FILE_NAME"
                                   , a."FILE_LAST_MODIFIED_TIME" = b."FILE_LAST_MODIFIED_TIME"
                                   , a."FILE_NAME_SHORT" = b."FILE_NAME_SHORT"
                                   , a."FILE_GENERATED_AT" = b."FILE_GENERATED_AT"
                                   , a."UPDATED_DATETIME" = CURRENT_TIMESTAMP
  WHEN NOT MATCHED THEN INSERT VALUES (
                                       b."LEVEL"
                                     , b."ORDER_ID"
                                     , b."COUNTRY_CD"
                                     , b."ORDER_TIME_UTC"
                                     , b."ORDER_TIME_LOCAL"
                                     , b."EPP_PLAN_NAME"
                                     , b."CUSTOMER_LOGIN_ID"
                                     , b."CUSTOMER_EMAIL_ID"
                                     , b."CUSTOMER_MOBILE_NUMBER"
                                     , b."CUSTOMER_USERID_TYPE"
                                     , b."PLATFORM"
                                     , b."ORDER_STATUS"
                                     , b."ORDER_FRAUD_STATUS"
                                     , b."LINE_ITEM_STATUS"
                                     , b."ORDER_CLONED_FROM"
                                     , b."ORDER_CHANNEL_CODE"
                                     , b."PO_ID"
                                     , b."SALES_APP"
                                     , b."LINE_ITEM_ID"
                                     , b."SKU_MEMORY"
                                     , b."PRODUCT_FAMILY"
                                     , b."PRODUCT_CATEGORY"
                                     , b."COLOR"
                                     , b."PRODUCT_NAME"
                                     , b."PRODUCT_TYPE"
                                     , b."PRODUCT_MODEL_CODE"
                                     , b."PRODUCT_MODEL_NAME"
                                     , b."SHORT_DESCRIPTION"
                                     , b."LONG_DESCRIPTION"
                                     , b."FAMILY_ID"
                                     , b."SKU"
                                     , b."EAN"
                                     , b."IS_ASSURANT_SKU"
                                     , b."IS_ACCESSORY"
                                     , b."IS_FINANCING_ELIGIBLE"
                                     , b."IS_FLAGSHIP"
                                     , b."TXN_SALES_AMOUNT"
                                     , b."TXN_SALE_CURRENCY"
                                     , b."TXN_OFFER_DISCOUNT_AMOUNT"
                                     , b."COUPON_CODE"
                                     , b."CAMPAIGN_ID"
                                     , b."OFFER_ID"
                                     , b."OFFER_NAME"
                                     , b."OFFER_TYPE"
                                     , b."OFFER_START_DATE"
                                     , b."OFFER_END_DATE"
                                     , b."SALES_PITCH"
                                     , b."OFFER_STATUS"
                                     , b."COUNTRY_GROUP"
                                     , b."PROGRAM_TYPE"
                                     , b."STORE_ID"
                                     , b."STORE_NAME"
                                     , b."STORE_TYPE"
                                     , b."ORDER_TYPE"
                                     , b."ORDER_SALE_AMOUNT"
                                     , b."TAXONOMY_PRODUCT_DIVISION_2_DIGIT"
                                     , b."FILE_NAME_FROM_FILE"
                                     , b."LOAD_DATE"
                                     , b."FILE_NAME"
                                     , b."FILE_LAST_MODIFIED_TIME"
                                     , b."FILE_NAME_SHORT"
                                     , CURRENT_TIMESTAMP
                                     , b."FILE_GENERATED_AT"
                                     , NULL
  );
END;
$$;

-- CALL OW_LAO.PROC_ODS_HYBRIS_OFFERS();
-- ERROR: Severity: ERROR, Message: Either column "a" does not exist or table alias "a" is not allowed in "WHEN MATCHED THEN UPDATE SET", Sqlstate: 42602, Hint: Either fix the column name "a" or remove table alias "a" from all column names in "WHEN MATCHED THEN UPDATE SET", Where: PL/vSQL procedure PROC_ODS_HYBRIS_OFFERS line 3 at static SQL, Routine: transformVMergeStmt, File: analyze.c, Line: 3541, Error Code: 5569, 
-- CALL OW_LAO.PROC_ODS_HYBRIS_OFFERS();
-- ERROR: Severity: ERROR, Message: Either column "a" does not exist or table alias "a" is not allowed in "WHEN MATCHED THEN UPDATE SET", Sqlstate: 42602, Hint: Either fix the column name "a" or remove table alias "a" from all column names in "WHEN MATCHED THEN UPDATE SET", Where: PL/vSQL procedure PROC_ODS_HYBRIS_OFFERS line 3 at static SQL, Routine: transformVMergeStmt, File: analyze.c, Line: 3541, Error Code: 5569, 
CREATE OR REPLACE PROCEDURE OW_LAO.PROC_ODS_HYBRIS_OFFERS()
LANGUAGE PLvSQL AS $$
BEGIN
  PERFORM MERGE INTO OW_LAO.ODS_HYBRIS_OFFERS
  USING (
      SELECT * FROM (
          SELECT ROW_NUMBER() OVER(
                     PARTITION BY country_cd, order_id, line_item_id, offer_id
                     ORDER BY file_generated_at DESC
                 ) AS dedup,
                 a.*
            FROM OW_LAO.RAW_HYBRIS_OFFERS a
           WHERE NOT EXISTS (
                     SELECT 1
                       FROM OW_LAO.ODS_HYBRIS_OFFERS aa
                      WHERE aa.country_cd = a.country_cd
                        AND aa.order_id = a.order_id
                        AND aa.line_item_id = a.line_item_id
                        AND aa.offer_id = a.offer_id
                        AND aa.file_generated_at >= a.file_generated_at
                 )
      ) s
      WHERE s.dedup = 1
  ) b
  ON b.country_cd = ODS_HYBRIS_OFFERS.country_cd
 AND b.order_id = ODS_HYBRIS_OFFERS.order_id
 AND b.line_item_id = ODS_HYBRIS_OFFERS.line_item_id
 AND b.offer_id = ODS_HYBRIS_OFFERS.offer_id
  WHEN MATCHED THEN UPDATE SET
                                     "LEVEL" = b."LEVEL"
                                   , "ORDER_ID" = b."ORDER_ID"
                                   , "COUNTRY_CD" = b."COUNTRY_CD"
                                   , "ORDER_TIME_UTC" = b."ORDER_TIME_UTC"
                                   , "ORDER_TIME_LOCAL" = b."ORDER_TIME_LOCAL"
                                   , "EPP_PLAN_NAME" = b."EPP_PLAN_NAME"
                                   , "CUSTOMER_LOGIN_ID" = b."CUSTOMER_LOGIN_ID"
                                   , "CUSTOMER_EMAIL_ID" = b."CUSTOMER_EMAIL_ID"
                                   , "CUSTOMER_MOBILE_NUMBER" = b."CUSTOMER_MOBILE_NUMBER"
                                   , "CUSTOMER_USERID_TYPE" = b."CUSTOMER_USERID_TYPE"
                                   , "PLATFORM" = b."PLATFORM"
                                   , "ORDER_STATUS" = b."ORDER_STATUS"
                                   , "ORDER_FRAUD_STATUS" = b."ORDER_FRAUD_STATUS"
                                   , "LINE_ITEM_STATUS" = b."LINE_ITEM_STATUS"
                                   , "ORDER_CLONED_FROM" = b."ORDER_CLONED_FROM"
                                   , "ORDER_CHANNEL_CODE" = b."ORDER_CHANNEL_CODE"
                                   , "PO_ID" = b."PO_ID"
                                   , "SALES_APP" = b."SALES_APP"
                                   , "LINE_ITEM_ID" = b."LINE_ITEM_ID"
                                   , "SKU_MEMORY" = b."SKU_MEMORY"
                                   , "PRODUCT_FAMILY" = b."PRODUCT_FAMILY"
                                   , "PRODUCT_CATEGORY" = b."PRODUCT_CATEGORY"
                                   , "COLOR" = b."COLOR"
                                   , "PRODUCT_NAME" = b."PRODUCT_NAME"
                                   , "PRODUCT_TYPE" = b."PRODUCT_TYPE"
                                   , "PRODUCT_MODEL_CODE" = b."PRODUCT_MODEL_CODE"
                                   , "PRODUCT_MODEL_NAME" = b."PRODUCT_MODEL_NAME"
                                   , "SHORT_DESCRIPTION" = b."SHORT_DESCRIPTION"
                                   , "LONG_DESCRIPTION" = b."LONG_DESCRIPTION"
                                   , "FAMILY_ID" = b."FAMILY_ID"
                                   , "SKU" = b."SKU"
                                   , "EAN" = b."EAN"
                                   , "IS_ASSURANT_SKU" = b."IS_ASSURANT_SKU"
                                   , "IS_ACCESSORY" = b."IS_ACCESSORY"
                                   , "IS_FINANCING_ELIGIBLE" = b."IS_FINANCING_ELIGIBLE"
                                   , "IS_FLAGSHIP" = b."IS_FLAGSHIP"
                                   , "TXN_SALES_AMOUNT" = b."TXN_SALES_AMOUNT"
                                   , "TXN_SALE_CURRENCY" = b."TXN_SALE_CURRENCY"
                                   , "TXN_OFFER_DISCOUNT_AMOUNT" = b."TXN_OFFER_DISCOUNT_AMOUNT"
                                   , "COUPON_CODE" = b."COUPON_CODE"
                                   , "CAMPAIGN_ID" = b."CAMPAIGN_ID"
                                   , "OFFER_ID" = b."OFFER_ID"
                                   , "OFFER_NAME" = b."OFFER_NAME"
                                   , "OFFER_TYPE" = b."OFFER_TYPE"
                                   , "OFFER_START_DATE" = b."OFFER_START_DATE"
                                   , "OFFER_END_DATE" = b."OFFER_END_DATE"
                                   , "SALES_PITCH" = b."SALES_PITCH"
                                   , "OFFER_STATUS" = b."OFFER_STATUS"
                                   , "COUNTRY_GROUP" = b."COUNTRY_GROUP"
                                   , "PROGRAM_TYPE" = b."PROGRAM_TYPE"
                                   , "STORE_ID" = b."STORE_ID"
                                   , "STORE_NAME" = b."STORE_NAME"
                                   , "STORE_TYPE" = b."STORE_TYPE"
                                   , "ORDER_TYPE" = b."ORDER_TYPE"
                                   , "ORDER_SALE_AMOUNT" = b."ORDER_SALE_AMOUNT"
                                   , "TAXONOMY_PRODUCT_DIVISION_2_DIGIT" = b."TAXONOMY_PRODUCT_DIVISION_2_DIGIT"
                                   , "FILE_NAME_FROM_FILE" = b."FILE_NAME_FROM_FILE"
                                   , "LOAD_DATE" = b."LOAD_DATE"
                                   , "FILE_NAME" = b."FILE_NAME"
                                   , "FILE_LAST_MODIFIED_TIME" = b."FILE_LAST_MODIFIED_TIME"
                                   , "FILE_NAME_SHORT" = b."FILE_NAME_SHORT"
                                   , "FILE_GENERATED_AT" = b."FILE_GENERATED_AT"
                                   , "UPDATED_DATETIME" = CURRENT_TIMESTAMP
  WHEN NOT MATCHED THEN INSERT VALUES (
                                       b."LEVEL"
                                     , b."ORDER_ID"
                                     , b."COUNTRY_CD"
                                     , b."ORDER_TIME_UTC"
                                     , b."ORDER_TIME_LOCAL"
                                     , b."EPP_PLAN_NAME"
                                     , b."CUSTOMER_LOGIN_ID"
                                     , b."CUSTOMER_EMAIL_ID"
                                     , b."CUSTOMER_MOBILE_NUMBER"
                                     , b."CUSTOMER_USERID_TYPE"
                                     , b."PLATFORM"
                                     , b."ORDER_STATUS"
                                     , b."ORDER_FRAUD_STATUS"
                                     , b."LINE_ITEM_STATUS"
                                     , b."ORDER_CLONED_FROM"
                                     , b."ORDER_CHANNEL_CODE"
                                     , b."PO_ID"
                                     , b."SALES_APP"
                                     , b."LINE_ITEM_ID"
                                     , b."SKU_MEMORY"
                                     , b."PRODUCT_FAMILY"
                                     , b."PRODUCT_CATEGORY"
                                     , b."COLOR"
                                     , b."PRODUCT_NAME"
                                     , b."PRODUCT_TYPE"
                                     , b."PRODUCT_MODEL_CODE"
                                     , b."PRODUCT_MODEL_NAME"
                                     , b."SHORT_DESCRIPTION"
                                     , b."LONG_DESCRIPTION"
                                     , b."FAMILY_ID"
                                     , b."SKU"
                                     , b."EAN"
                                     , b."IS_ASSURANT_SKU"
                                     , b."IS_ACCESSORY"
                                     , b."IS_FINANCING_ELIGIBLE"
                                     , b."IS_FLAGSHIP"
                                     , b."TXN_SALES_AMOUNT"
                                     , b."TXN_SALE_CURRENCY"
                                     , b."TXN_OFFER_DISCOUNT_AMOUNT"
                                     , b."COUPON_CODE"
                                     , b."CAMPAIGN_ID"
                                     , b."OFFER_ID"
                                     , b."OFFER_NAME"
                                     , b."OFFER_TYPE"
                                     , b."OFFER_START_DATE"
                                     , b."OFFER_END_DATE"
                                     , b."SALES_PITCH"
                                     , b."OFFER_STATUS"
                                     , b."COUNTRY_GROUP"
                                     , b."PROGRAM_TYPE"
                                     , b."STORE_ID"
                                     , b."STORE_NAME"
                                     , b."STORE_TYPE"
                                     , b."ORDER_TYPE"
                                     , b."ORDER_SALE_AMOUNT"
                                     , b."TAXONOMY_PRODUCT_DIVISION_2_DIGIT"
                                     , b."FILE_NAME_FROM_FILE"
                                     , b."LOAD_DATE"
                                     , b."FILE_NAME"
                                     , b."FILE_LAST_MODIFIED_TIME"
                                     , b."FILE_NAME_SHORT"
                                     , CURRENT_TIMESTAMP
                                     , b."FILE_GENERATED_AT"
                                     , NULL
  );
END;
$$;

-- CALL OW_LAO.PROC_ODS_HYBRIS_OFFERS();
-- ERROR: Severity: ERROR, Message: Column "ID" is of type int but expression is of type varchar, Sqlstate: 42804, Hint: You will need to rewrite or cast the expression, Where: PL/vSQL procedure PROC_ODS_HYBRIS_OFFERS line 3 at static SQL, Routine: updateTargetListEntry, File: parse_target.c, Line: 853, Error Code: 2631, 
-- CALL OW_LAO.PROC_ODS_HYBRIS_OFFERS();
-- ERROR: Severity: ERROR, Message: Column "ID" is of type int but expression is of type varchar, Sqlstate: 42804, Hint: You will need to rewrite or cast the expression, Where: PL/vSQL procedure PROC_ODS_HYBRIS_OFFERS line 3 at static SQL, Routine: updateTargetListEntry, File: parse_target.c, Line: 853, Error Code: 2631, 
SELECT column_name, data_type, ordinal_position FROM v_catalog.columns WHERE table_schema='OW_LAO' AND table_name='ODS_HYBRIS_OFFERS' ORDER BY ordinal_position;
-- column_name | data_type | ordinal_position
-- ------------+-----------+-----------------
-- ID | int | 1
-- LEVEL | varchar(255) | 2
-- ORDER_ID | varchar(255) | 3
-- COUNTRY_CD | varchar(255) | 4
-- ORDER_TIME_UTC | varchar(255) | 5
-- ORDER_TIME_LOCAL | varchar(255) | 6
-- EPP_PLAN_NAME | varchar(255) | 7
-- CUSTOMER_LOGIN_ID | varchar(255) | 8
-- CUSTOMER_EMAIL_ID | varchar(255) | 9
-- CUSTOMER_MOBILE_NUMBER | varchar(255) | 10
-- CUSTOMER_USERID_TYPE | varchar(255) | 11
-- PLATFORM | varchar(255) | 12
-- ORDER_STATUS | varchar(255) | 13
-- ORDER_FRAUD_STATUS | varchar(255) | 14
-- LINE_ITEM_STATUS | varchar(255) | 15
-- ORDER_CLONED_FROM | boolean | 16
-- ORDER_CHANNEL_CODE | varchar(255) | 17
-- PO_ID | varchar(255) | 18
-- SALES_APP | varchar(255) | 19
-- LINE_ITEM_ID | varchar(255) | 20
-- SKU_MEMORY | varchar(255) | 21
-- PRODUCT_FAMILY | varchar(255) | 22
-- PRODUCT_CATEGORY | varchar(255) | 23
-- COLOR | varchar(255) | 24
-- PRODUCT_NAME | varchar(255) | 25
-- PRODUCT_TYPE | varchar(255) | 26
-- PRODUCT_MODEL_CODE | varchar(255) | 27
-- PRODUCT_MODEL_NAME | varchar(255) | 28
-- SHORT_DESCRIPTION | varchar(1000) | 29
-- LONG_DESCRIPTION | varchar(3000) | 30
-- FAMILY_ID | varchar(255) | 31
-- SKU | varchar(255) | 32
-- EAN | varchar(255) | 33
-- IS_ASSURANT_SKU | boolean | 34
-- IS_ACCESSORY | boolean | 35
-- IS_FINANCING_ELIGIBLE | boolean | 36
-- IS_FLAGSHIP | boolean | 37
-- TXN_SALES_AMOUNT | numeric(34,0) | 38
-- TXN_SALE_CURRENCY | varchar(255) | 39
-- TXN_OFFER_DISCOUNT_AMOUNT | numeric(34,0) | 40
-- COUPON_CODE | varchar(255) | 41
-- CAMPAIGN_ID | varchar(255) | 42
-- OFFER_ID | varchar(255) | 43
-- OFFER_NAME | varchar(255) | 44
-- OFFER_TYPE | varchar(255) | 45
-- OFFER_START_DATE | varchar(255) | 46
-- OFFER_END_DATE | varchar(255) | 47
-- SALES_PITCH | varchar(5000) | 48
-- OFFER_STATUS | varchar(255) | 49
-- COUNTRY_GROUP | varchar(255) | 50
-- PROGRAM_TYPE | varchar(255) | 51
-- STORE_ID | varchar(255) | 52
-- STORE_NAME | varchar(255) | 53
-- STORE_TYPE | varchar(255) | 54
-- ORDER_TYPE | varchar(255) | 55
-- ORDER_SALE_AMOUNT | numeric(34,0) | 56
-- TAXONOMY_PRODUCT_DIVISION_2_DIGIT | varchar(255) | 57
-- FILE_NAME_FROM_FILE | varchar(255) | 58
-- LOAD_DATE | timestamp | 59
-- FILE_NAME | varchar(2000) | 60
-- FILE_LAST_MODIFIED_TIME | varchar(255) | 61
-- FILE_NAME_SHORT | varchar(255) | 62
-- INSERTED_DATE | timestamp | 63
-- FILE_GENERATED_AT | timestamp | 64
-- UPDATED_DATETIME | timestamp | 65

SELECT table_schema, table_name FROM v_catalog.tables WHERE LOWER(table_schema)='ow_lao' AND LOWER(table_name)='ods_hybris_offers';
-- table_schema | table_name
-- -------------+-----------
-- OW_LAO | ODS_HYBRIS_OFFERS

CREATE OR REPLACE PROCEDURE OW_LAO.PROC_ODS_HYBRIS_OFFERS()
LANGUAGE PLvSQL AS $$
BEGIN
  PERFORM MERGE INTO OW_LAO.ODS_HYBRIS_OFFERS
  USING (
      SELECT * FROM (
          SELECT ROW_NUMBER() OVER(
                     PARTITION BY country_cd, order_id, line_item_id, offer_id
                     ORDER BY file_generated_at DESC
                 ) AS dedup,
                 a.*
            FROM OW_LAO.RAW_HYBRIS_OFFERS a
           WHERE NOT EXISTS (
                     SELECT 1
                       FROM OW_LAO.ODS_HYBRIS_OFFERS aa
                      WHERE aa.country_cd = a.country_cd
                        AND aa.order_id = a.order_id
                        AND aa.line_item_id = a.line_item_id
                        AND aa.offer_id = a.offer_id
                        AND aa.file_generated_at >= a.file_generated_at
                 )
      ) s
      WHERE s.dedup = 1
  ) b
  ON b.country_cd = ODS_HYBRIS_OFFERS.country_cd
 AND b.order_id = ODS_HYBRIS_OFFERS.order_id
 AND b.line_item_id = ODS_HYBRIS_OFFERS.line_item_id
 AND b.offer_id = ODS_HYBRIS_OFFERS.offer_id
  WHEN MATCHED THEN UPDATE SET
                                     "LEVEL" = b."LEVEL"
                                   , "ORDER_ID" = b."ORDER_ID"
                                   , "COUNTRY_CD" = b."COUNTRY_CD"
                                   , "ORDER_TIME_UTC" = b."ORDER_TIME_UTC"
                                   , "ORDER_TIME_LOCAL" = b."ORDER_TIME_LOCAL"
                                   , "EPP_PLAN_NAME" = b."EPP_PLAN_NAME"
                                   , "CUSTOMER_LOGIN_ID" = b."CUSTOMER_LOGIN_ID"
                                   , "CUSTOMER_EMAIL_ID" = b."CUSTOMER_EMAIL_ID"
                                   , "CUSTOMER_MOBILE_NUMBER" = b."CUSTOMER_MOBILE_NUMBER"
                                   , "CUSTOMER_USERID_TYPE" = b."CUSTOMER_USERID_TYPE"
                                   , "PLATFORM" = b."PLATFORM"
                                   , "ORDER_STATUS" = b."ORDER_STATUS"
                                   , "ORDER_FRAUD_STATUS" = b."ORDER_FRAUD_STATUS"
                                   , "LINE_ITEM_STATUS" = b."LINE_ITEM_STATUS"
                                   , "ORDER_CLONED_FROM" = b."ORDER_CLONED_FROM"
                                   , "ORDER_CHANNEL_CODE" = b."ORDER_CHANNEL_CODE"
                                   , "PO_ID" = b."PO_ID"
                                   , "SALES_APP" = b."SALES_APP"
                                   , "LINE_ITEM_ID" = b."LINE_ITEM_ID"
                                   , "SKU_MEMORY" = b."SKU_MEMORY"
                                   , "PRODUCT_FAMILY" = b."PRODUCT_FAMILY"
                                   , "PRODUCT_CATEGORY" = b."PRODUCT_CATEGORY"
                                   , "COLOR" = b."COLOR"
                                   , "PRODUCT_NAME" = b."PRODUCT_NAME"
                                   , "PRODUCT_TYPE" = b."PRODUCT_TYPE"
                                   , "PRODUCT_MODEL_CODE" = b."PRODUCT_MODEL_CODE"
                                   , "PRODUCT_MODEL_NAME" = b."PRODUCT_MODEL_NAME"
                                   , "SHORT_DESCRIPTION" = b."SHORT_DESCRIPTION"
                                   , "LONG_DESCRIPTION" = b."LONG_DESCRIPTION"
                                   , "FAMILY_ID" = b."FAMILY_ID"
                                   , "SKU" = b."SKU"
                                   , "EAN" = b."EAN"
                                   , "IS_ASSURANT_SKU" = b."IS_ASSURANT_SKU"
                                   , "IS_ACCESSORY" = b."IS_ACCESSORY"
                                   , "IS_FINANCING_ELIGIBLE" = b."IS_FINANCING_ELIGIBLE"
                                   , "IS_FLAGSHIP" = b."IS_FLAGSHIP"
                                   , "TXN_SALES_AMOUNT" = b."TXN_SALES_AMOUNT"
                                   , "TXN_SALE_CURRENCY" = b."TXN_SALE_CURRENCY"
                                   , "TXN_OFFER_DISCOUNT_AMOUNT" = b."TXN_OFFER_DISCOUNT_AMOUNT"
                                   , "COUPON_CODE" = b."COUPON_CODE"
                                   , "CAMPAIGN_ID" = b."CAMPAIGN_ID"
                                   , "OFFER_ID" = b."OFFER_ID"
                                   , "OFFER_NAME" = b."OFFER_NAME"
                                   , "OFFER_TYPE" = b."OFFER_TYPE"
                                   , "OFFER_START_DATE" = b."OFFER_START_DATE"
                                   , "OFFER_END_DATE" = b."OFFER_END_DATE"
                                   , "SALES_PITCH" = b."SALES_PITCH"
                                   , "OFFER_STATUS" = b."OFFER_STATUS"
                                   , "COUNTRY_GROUP" = b."COUNTRY_GROUP"
                                   , "PROGRAM_TYPE" = b."PROGRAM_TYPE"
                                   , "STORE_ID" = b."STORE_ID"
                                   , "STORE_NAME" = b."STORE_NAME"
                                   , "STORE_TYPE" = b."STORE_TYPE"
                                   , "ORDER_TYPE" = b."ORDER_TYPE"
                                   , "ORDER_SALE_AMOUNT" = b."ORDER_SALE_AMOUNT"
                                   , "TAXONOMY_PRODUCT_DIVISION_2_DIGIT" = b."TAXONOMY_PRODUCT_DIVISION_2_DIGIT"
                                   , "FILE_NAME_FROM_FILE" = b."FILE_NAME_FROM_FILE"
                                   , "LOAD_DATE" = b."LOAD_DATE"
                                   , "FILE_NAME" = b."FILE_NAME"
                                   , "FILE_LAST_MODIFIED_TIME" = b."FILE_LAST_MODIFIED_TIME"
                                   , "FILE_NAME_SHORT" = b."FILE_NAME_SHORT"
                                   , "FILE_GENERATED_AT" = b."FILE_GENERATED_AT"
                                   , "UPDATED_DATETIME" = CURRENT_TIMESTAMP
  WHEN NOT MATCHED THEN INSERT (
                                       "LEVEL"
                                     , "ORDER_ID"
                                     , "COUNTRY_CD"
                                     , "ORDER_TIME_UTC"
                                     , "ORDER_TIME_LOCAL"
                                     , "EPP_PLAN_NAME"
                                     , "CUSTOMER_LOGIN_ID"
                                     , "CUSTOMER_EMAIL_ID"
                                     , "CUSTOMER_MOBILE_NUMBER"
                                     , "CUSTOMER_USERID_TYPE"
                                     , "PLATFORM"
                                     , "ORDER_STATUS"
                                     , "ORDER_FRAUD_STATUS"
                                     , "LINE_ITEM_STATUS"
                                     , "ORDER_CLONED_FROM"
                                     , "ORDER_CHANNEL_CODE"
                                     , "PO_ID"
                                     , "SALES_APP"
                                     , "LINE_ITEM_ID"
                                     , "SKU_MEMORY"
                                     , "PRODUCT_FAMILY"
                                     , "PRODUCT_CATEGORY"
                                     , "COLOR"
                                     , "PRODUCT_NAME"
                                     , "PRODUCT_TYPE"
                                     , "PRODUCT_MODEL_CODE"
                                     , "PRODUCT_MODEL_NAME"
                                     , "SHORT_DESCRIPTION"
                                     , "LONG_DESCRIPTION"
                                     , "FAMILY_ID"
                                     , "SKU"
                                     , "EAN"
                                     , "IS_ASSURANT_SKU"
                                     , "IS_ACCESSORY"
                                     , "IS_FINANCING_ELIGIBLE"
                                     , "IS_FLAGSHIP"
                                     , "TXN_SALES_AMOUNT"
                                     , "TXN_SALE_CURRENCY"
                                     , "TXN_OFFER_DISCOUNT_AMOUNT"
                                     , "COUPON_CODE"
                                     , "CAMPAIGN_ID"
                                     , "OFFER_ID"
                                     , "OFFER_NAME"
                                     , "OFFER_TYPE"
                                     , "OFFER_START_DATE"
                                     , "OFFER_END_DATE"
                                     , "SALES_PITCH"
                                     , "OFFER_STATUS"
                                     , "COUNTRY_GROUP"
                                     , "PROGRAM_TYPE"
                                     , "STORE_ID"
                                     , "STORE_NAME"
                                     , "STORE_TYPE"
                                     , "ORDER_TYPE"
                                     , "ORDER_SALE_AMOUNT"
                                     , "TAXONOMY_PRODUCT_DIVISION_2_DIGIT"
                                     , "FILE_NAME_FROM_FILE"
                                     , "LOAD_DATE"
                                     , "FILE_NAME"
                                     , "FILE_LAST_MODIFIED_TIME"
                                     , "FILE_NAME_SHORT"
                                     , "UPDATED_DATETIME"
                                     , "FILE_GENERATED_AT"
  ) VALUES (
                                       b."LEVEL"
                                     , b."ORDER_ID"
                                     , b."COUNTRY_CD"
                                     , b."ORDER_TIME_UTC"
                                     , b."ORDER_TIME_LOCAL"
                                     , b."EPP_PLAN_NAME"
                                     , b."CUSTOMER_LOGIN_ID"
                                     , b."CUSTOMER_EMAIL_ID"
                                     , b."CUSTOMER_MOBILE_NUMBER"
                                     , b."CUSTOMER_USERID_TYPE"
                                     , b."PLATFORM"
                                     , b."ORDER_STATUS"
                                     , b."ORDER_FRAUD_STATUS"
                                     , b."LINE_ITEM_STATUS"
                                     , b."ORDER_CLONED_FROM"
                                     , b."ORDER_CHANNEL_CODE"
                                     , b."PO_ID"
                                     , b."SALES_APP"
                                     , b."LINE_ITEM_ID"
                                     , b."SKU_MEMORY"
                                     , b."PRODUCT_FAMILY"
                                     , b."PRODUCT_CATEGORY"
                                     , b."COLOR"
                                     , b."PRODUCT_NAME"
                                     , b."PRODUCT_TYPE"
                                     , b."PRODUCT_MODEL_CODE"
                                     , b."PRODUCT_MODEL_NAME"
                                     , b."SHORT_DESCRIPTION"
                                     , b."LONG_DESCRIPTION"
                                     , b."FAMILY_ID"
                                     , b."SKU"
                                     , b."EAN"
                                     , b."IS_ASSURANT_SKU"
                                     , b."IS_ACCESSORY"
                                     , b."IS_FINANCING_ELIGIBLE"
                                     , b."IS_FLAGSHIP"
                                     , b."TXN_SALES_AMOUNT"
                                     , b."TXN_SALE_CURRENCY"
                                     , b."TXN_OFFER_DISCOUNT_AMOUNT"
                                     , b."COUPON_CODE"
                                     , b."CAMPAIGN_ID"
                                     , b."OFFER_ID"
                                     , b."OFFER_NAME"
                                     , b."OFFER_TYPE"
                                     , b."OFFER_START_DATE"
                                     , b."OFFER_END_DATE"
                                     , b."SALES_PITCH"
                                     , b."OFFER_STATUS"
                                     , b."COUNTRY_GROUP"
                                     , b."PROGRAM_TYPE"
                                     , b."STORE_ID"
                                     , b."STORE_NAME"
                                     , b."STORE_TYPE"
                                     , b."ORDER_TYPE"
                                     , b."ORDER_SALE_AMOUNT"
                                     , b."TAXONOMY_PRODUCT_DIVISION_2_DIGIT"
                                     , b."FILE_NAME_FROM_FILE"
                                     , b."LOAD_DATE"
                                     , b."FILE_NAME"
                                     , b."FILE_LAST_MODIFIED_TIME"
                                     , b."FILE_NAME_SHORT"
                                     , CURRENT_TIMESTAMP
                                     , b."FILE_GENERATED_AT"
  );
END;
$$;

CALL OW_LAO.PROC_ODS_HYBRIS_OFFERS();
-- PROC_ODS_HYBRIS_OFFERS
-- ----------------------
-- 0

