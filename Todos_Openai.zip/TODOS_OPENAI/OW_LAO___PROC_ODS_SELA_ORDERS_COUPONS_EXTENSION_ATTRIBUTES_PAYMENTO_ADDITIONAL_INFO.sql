CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_sela_orders_coupons_extension_attributes_paymento_additional_info()
LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM MERGE INTO OW_LAO.ods_sela_orders_coupons_extension_attributes_paymento_additional_info a
          USING OW_LAO.stg_sela_orders_coupons_extension_attributes_paymento_additional_info b
            ON b.store_id      = a.store_id
           AND b.subsidiary_id = a.subsidiary_id
           AND b.account       = a.account
           AND b.entity_id     = a.entity_id
           AND HASH_SHA256(COALESCE(b.key,'0'), COALESCE(b.value,'0')) = a.guid
    WHEN MATCHED THEN UPDATE
        SET updated_timestamp = CURRENT_TIMESTAMP
          , key   = b.key
          , value = b.value
    WHEN NOT MATCHED THEN INSERT (
          updated_timestamp
        , key
        , value
        , store_id
        , entity_id
        , subsidiary_id
        , account
        , guid
    )
    VALUES (
          CURRENT_TIMESTAMP
        , b.key
        , b.value
        , b.store_id
        , b.entity_id
        , b.subsidiary_id
        , b.account
        , HASH_SHA256(COALESCE(b.key,'0'), COALESCE(b.value,'0'))
    );
END;
$$;

-- CALL OW_LAO.proc_ods_sela_orders_coupons_extension_attributes_paymento_additional_info();
-- ERROR: Severity: ERROR, Message: Relation "OW_LAO.stg_sela_orders_coupons_extension_attributes_paymento_additional_info" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ods_sela_orders_coupons_extension_attributes_paymento_additional_info line 3 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
-- CALL OW_LAO.proc_ods_sela_orders_coupons_extension_attributes_paymento_additional_info();
-- ERROR: Severity: ERROR, Message: Relation "OW_LAO.stg_sela_orders_coupons_extension_attributes_paymento_additional_info" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ods_sela_orders_coupons_extension_attributes_paymento_additional_info line 3 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
