CREATE OR REPLACE PROCEDURE OW_LAO.PROC_ODS_ECOM_ORDERS_B5Q5()
 LANGUAGE PLvSQL AS $$
BEGIN
 
  PERFORM INSERT INTO "OW_LAO"."ODS_ECOM_ORDERS_B5Q5"
  SELECT 
  "SUB" ,
  "Order Nr.",
  "Creation Date" ,
  "SITE" ,
  "Order Status" ,
  "Product ID" ,
  "B5Q5 SKU" ,
  "Product QTY" ,
  "Price per Unit USD",
  "Total Amount USD" ,
  "Promotion Code" ,
  "Trade in" ,
  "Trade up" ,
  "SC+" ,
  "MODEL" ,
  "MEMORY_STORAGE" ,
  "COLOR" ,
  "CHANNEL" ,
  "BIZTYPE" ,
  "AUDIENCE_TYPE" ,
  "Partner Level" ,
  "STATUS",
  "Exclusive Model?" ,
  "Day of PreOrder" ,
  "YEAR" ,
  Load_Date ,
  Last_Update,
  "FILE_NAME"
     FROM  "OW_LAO"."ODS_ECOM_ORDERS_B5Q5_HYBRIS" HY
   WHERE  1=1
     AND HY."Order Nr." IS NOT NULL
     AND HY."Order Nr."  NOT IN (SELECT DISTINCT "Order Nr." FROM  "OW_LAO"."ODS_ECOM_ORDERS_B5Q5" sog WHERE sog."Order Nr." = HY."Order Nr."  );
 
  PERFORM UPDATE "OW_LAO"."ODS_ECOM_ORDERS_B5Q5" AS so
  SET  
    "SITE"= tmp."SITE",
    "Order Status" = tmp."Order Status",
    "B5Q5 SKU" = tmp."B5Q5 SKU",
    "Promotion Code"= tmp."Promotion Code",
    "Trade in"  = tmp."Trade in" ,
    "Trade up"  = tmp."Trade up" ,
    "SC+"  = tmp."SC+",
    "MODEL"   = tmp."MODEL" ,
    "MEMORY_STORAGE"   = tmp."MEMORY_STORAGE" ,
    "COLOR"  = tmp."COLOR",
    "CHANNEL"  = tmp."CHANNEL",
    "BIZTYPE"  = tmp."BIZTYPE",
    "AUDIENCE_TYPE"  = tmp."AUDIENCE_TYPE",
    "Partner Level"  = tmp."Partner Level",
    "STATUS"  = tmp."STATUS",
    "Exclusive Model?"  = tmp."Exclusive Model?",
    "Day of PreOrder"  = tmp."Day of PreOrder",
    "YEAR"  = tmp."YEAR",
    Last_Update  = tmp.Last_Update,
    "FILE_NAME"  = tmp."FILE_NAME"
  FROM (
    SELECT DISTINCT
      "SUB" ,
      "Order Nr.",
      "Product ID",
      "SITE",
      "Order Status" ,
      "B5Q5 SKU" ,
      "Promotion Code",
      "Trade in"   ,
      "Trade up"   ,
      "SC+"  ,
      "MODEL" ,
      "MEMORY_STORAGE",
      "COLOR",
      "CHANNEL",
      "BIZTYPE",
      "AUDIENCE_TYPE",
      "Partner Level",
      "STATUS",
      "Exclusive Model?",
      "Day of PreOrder",
      "YEAR",
      Last_Update,
      "FILE_NAME"
    FROM   "OW_LAO"."ODS_ECOM_ORDERS_B5Q5_HYBRIS"
    WHERE 1=1
  ) AS tmp
  WHERE so."Order Nr." = tmp."Order Nr." AND so."Product ID" = tmp."Product ID" AND so."SUB" = tmp."SUB"  AND so."Order Status" <> tmp."Order Status";
  
  PERFORM UPDATE "OW_LAO"."ODS_ECOM_ORDERS_B5Q5" AS so
  SET  
    "SITE"= tmp."SITE",
    "Order Status" = tmp."Order Status",
    "B5Q5 SKU" = tmp."B5Q5 SKU",
    "Promotion Code"= tmp."Promotion Code",
    "Trade in"  = tmp."Trade in" ,
    "Trade up"  = tmp."Trade up" ,
    "SC+"  = tmp."SC+",
    "MODEL"   = tmp."MODEL" ,
    "MEMORY_STORAGE"   = tmp."MEMORY_STORAGE" ,
    "COLOR"  = tmp."COLOR",
    "CHANNEL"  = tmp."CHANNEL",
    "BIZTYPE"  = tmp."BIZTYPE",
    "AUDIENCE_TYPE"  = tmp."AUDIENCE_TYPE",
    "Partner Level"  = tmp."Partner Level",
    "STATUS"  = tmp."STATUS",
    "Exclusive Model?"  = tmp."Exclusive Model?",
    "Day of PreOrder"  = tmp."Day of PreOrder",
    "YEAR"  = tmp."YEAR",
    Last_Update  = tmp.Last_Update,
    "FILE_NAME"  = tmp."FILE_NAME"
  FROM (
    SELECT DISTINCT
      "SUB" ,
      "Order Nr.",
      "Product ID",
      "SITE",
      "Order Status" ,
      "B5Q5 SKU" ,
      "Promotion Code",
      "Trade in"   ,
      "Trade up"   ,
      "SC+"  ,
      "MODEL" ,
      "MEMORY_STORAGE",
      "COLOR",
      "CHANNEL",
      "BIZTYPE",
      "AUDIENCE_TYPE",
      "Partner Level",
      "STATUS",
      "Exclusive Model?",
      "Day of PreOrder",
      "YEAR",
      Last_Update,
      "FILE_NAME"
    FROM   "OW_LAO"."ODS_ECOM_ORDERS_B5Q5_HYBRIS"
    WHERE 1=1
  ) AS tmp
  WHERE so."Order Nr." = tmp."Order Nr." AND so."Product ID" = tmp."Product ID" AND so."SUB" = tmp."SUB"  AND so."STATUS" <> tmp."STATUS";
  
  PERFORM INSERT INTO "OW_LAO"."ODS_ECOM_ORDERS_B5Q5"
  SELECT 
  "SUB" ,
  "Order Nr.",
  "Creation Date" ,
  "SITE" ,
  "Order Status" ,
  "Product ID" ,
  "B5Q5 SKU" ,
  "Product QTY" ,
  "Price per Unit USD",
  "Total Amount USD" ,
  "Promotion Code" ,
  "Trade in" ,
  "Trade up" ,
  "SC+" ,
  "MODEL" ,
  "MEMORY_STORAGE" ,
  "COLOR" ,
  "CHANNEL" ,
  "BIZTYPE" ,
  "AUDIENCE_TYPE" ,
  "Partner Level" ,
  "STATUS",
  "Exclusive Model?" ,
  "Day of PreOrder" ,
  "YEAR" ,
  Load_Date ,
  Last_Update,
  NULL AS "FILE_NAME"
     FROM  "OW_LAO"."VIEW_ECOM_ORDERS_B5Q5_VTEX" VW
   WHERE  1=1
     AND VW."Order Nr." IS NOT NULL
     AND VW."Order Nr."  NOT IN (SELECT DISTINCT "Order Nr." FROM "OW_LAO"."ODS_ECOM_ORDERS_B5Q5" sog WHERE sog."Order Nr." = VW."Order Nr."  );
 
  PERFORM UPDATE "OW_LAO"."ODS_ECOM_ORDERS_B5Q5" AS so
  SET  
    "SITE"= tmp."SITE",
    "Order Status" = tmp."Order Status",
    "B5Q5 SKU" = tmp."B5Q5 SKU",
    "Promotion Code"= tmp."Promotion Code",
    "Trade in"  = tmp."Trade in" ,
    "Trade up"  = tmp."Trade up" ,
    "SC+"  = tmp."SC+",
    "MODEL"   = tmp."MODEL" ,
    "MEMORY_STORAGE"   = tmp."MEMORY_STORAGE" ,
    "COLOR"  = tmp."COLOR",
    "CHANNEL"  = tmp."CHANNEL",
    "BIZTYPE"  = tmp."BIZTYPE",
    "AUDIENCE_TYPE"  = tmp."AUDIENCE_TYPE",
    "Partner Level"  = tmp."Partner Level",
    "STATUS"  = tmp."STATUS",
    "Exclusive Model?"  = tmp."Exclusive Model?",
    "Day of PreOrder"  = tmp."Day of PreOrder",
    "YEAR"  = tmp."YEAR",
    Last_Update  = tmp.Last_Update
  FROM (
    SELECT DISTINCT
      "SUB" ,
      "Order Nr.",
      "Product ID",
      "SITE",
      "Order Status" ,
      "B5Q5 SKU" ,
      "Promotion Code",
      "Trade in"   ,
      "Trade up"   ,
      "SC+"  ,
      "MODEL" ,
      "MEMORY_STORAGE",
      "COLOR",
      "CHANNEL",
      "BIZTYPE",
      "AUDIENCE_TYPE",
      "Partner Level",
      "STATUS",
      "Exclusive Model?",
      "Day of PreOrder",
      "YEAR",
      Last_Update
    FROM   "OW_LAO"."VIEW_ECOM_ORDERS_B5Q5_VTEX"
    WHERE 1=1
  ) AS tmp
  WHERE so."Order Nr." = tmp."Order Nr." AND so."Product ID" = tmp."Product ID" AND so."SUB" = tmp."SUB" AND so."Order Status" <> tmp."Order Status";
  
  PERFORM UPDATE "OW_LAO"."ODS_ECOM_ORDERS_B5Q5" AS so
  SET  
    "SITE"= tmp."SITE",
    "Order Status" = tmp."Order Status",
    "B5Q5 SKU" = tmp."B5Q5 SKU",
    "Promotion Code"= tmp."Promotion Code",
    "Trade in"  = tmp."Trade in" ,
    "Trade up"  = tmp."Trade up" ,
    "SC+"  = tmp."SC+",
    "MODEL"   = tmp."MODEL" ,
    "MEMORY_STORAGE"   = tmp."MEMORY_STORAGE" ,
    "COLOR"  = tmp."COLOR",
    "CHANNEL"  = tmp."CHANNEL",
    "BIZTYPE"  = tmp."BIZTYPE",
    "AUDIENCE_TYPE"  = tmp."AUDIENCE_TYPE",
    "Partner Level"  = tmp."Partner Level",
    "STATUS"  = tmp."STATUS",
    "Exclusive Model?"  = tmp."Exclusive Model?",
    "Day of PreOrder"  = tmp."Day of PreOrder",
    "YEAR"  = tmp."YEAR",
    Last_Update  = tmp.Last_Update
  FROM (
    SELECT DISTINCT
      "SUB" ,
      "Order Nr.",
      "Product ID",
      "SITE",
      "Order Status" ,
      "B5Q5 SKU" ,
      "Promotion Code",
      "Trade in"   ,
      "Trade up"   ,
      "SC+"  ,
      "MODEL" ,
      "MEMORY_STORAGE",
      "COLOR",
      "CHANNEL",
      "BIZTYPE",
      "AUDIENCE_TYPE",
      "Partner Level",
      "STATUS",
      "Exclusive Model?",
      "Day of PreOrder",
      "YEAR",
      Last_Update
    FROM   "OW_LAO"."VIEW_ECOM_ORDERS_B5Q5_VTEX"
    WHERE 1=1
  ) AS tmp
  WHERE so."Order Nr." = tmp."Order Nr." AND so."Product ID" = tmp."Product ID" AND so."SUB" = tmp."SUB" AND so."STATUS" <> tmp."STATUS";
END;
$$;

-- CALL OW_LAO.PROC_ODS_ECOM_ORDERS_B5Q5();
-- ERROR: Severity: ERROR, Message: Table "OW_LAO.ODS_ECOM_ORDERS_B5Q5" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_ODS_ECOM_ORDERS_B5Q5 line 4 at static SQL, Routine: throwErrInvalidTab, File: analyze.c, Line: 3378, Error Code: 4883, 
-- CALL OW_LAO.PROC_ODS_ECOM_ORDERS_B5Q5();
-- ERROR: Severity: ERROR, Message: Table "OW_LAO.ODS_ECOM_ORDERS_B5Q5" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_ODS_ECOM_ORDERS_B5Q5 line 4 at static SQL, Routine: throwErrInvalidTab, File: analyze.c, Line: 3378, Error Code: 4883, 
