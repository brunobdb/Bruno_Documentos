CREATE OR REPLACE PROCEDURE OW_LAO.PROC_CRAWLING_AP1_RETRY_PRODUCTS()
LANGUAGE PLvSQL AS $$
BEGIN
  PERFORM UPDATE OW_LAO.CRAWLER_PROCESS_LIST
  SET last_run_date = TIMESTAMPADD(DAY, -1, CURRENT_DATE)
  WHERE "key" IN (
    SELECT "key" FROM OW_LAO.VM_CRAWLING_MONITORING_EXTRACT_NULL
    WHERE "key" NOT IN (
      SELECT "key" FROM OW_LAO.VM_CRAWLING_MONITORING_PRICE_EXECUTION_QUEUE
    )
  );
END;
$$;

-- CALL OW_LAO.PROC_CRAWLING_AP1_RETRY_PRODUCTS();
-- ERROR: Severity: ERROR, Message: Relation "OW_LAO.VM_CRAWLING_MONITORING_EXTRACT_NULL" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_CRAWLING_AP1_RETRY_PRODUCTS line 3 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
-- CALL OW_LAO.PROC_CRAWLING_AP1_RETRY_PRODUCTS();
-- ERROR: Severity: ERROR, Message: Relation "OW_LAO.VM_CRAWLING_MONITORING_EXTRACT_NULL" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_CRAWLING_AP1_RETRY_PRODUCTS line 3 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
