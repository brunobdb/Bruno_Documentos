CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_sela_sales_coupons_items()
LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM MERGE INTO ow_lao.ods_sela_sales_coupons_items a
    USING ow_lao.stg_sela_sales_coupons_items b
      ON b.subsidiary_id = a.subsidiary_id
     AND b.account       = a.account
     AND b.entity_id     = a.entity_id
     AND b.item_id       = a.item_id
    WHEN MATCHED THEN UPDATE SET
         updated_timestamp = CURRENT_TIMESTAMP
       , parent_applied_rule_ids = b.parent_applied_rule_ids
       , amount_refunded = b.amount_refunded
       , applied_rule_ids = b.applied_rule_ids
       , base_amount_refunded = b.base_amount_refunded
       , base_discount_amount = b.base_discount_amount
       , base_discount_invoiced = b.base_discount_invoiced
       , base_discount_refunded = b.base_discount_refunded
       , base_discount_tax_compensation_amount = b.base_discount_tax_compensation_amount
       , base_discount_tax_compensation_invoiced = b.base_discount_tax_compensation_invoiced
       , base_discount_tax_compensation_refunded = b.base_discount_tax_compensation_refunded
       , base_original_price = b.base_original_price
       , base_price = b.base_price
       , base_price_incl_tax = b.base_price_incl_tax
       , base_row_invoiced = b.base_row_invoiced
       , base_row_total = b.base_row_total
       , base_row_total_incl_tax = b.base_row_total_incl_tax
       , base_tax_amount = b.base_tax_amount
       , base_tax_invoiced = b.base_tax_invoiced
       , base_tax_refunded = b.base_tax_refunded
       , created_at = b.created_at
       , discount_amount = b.discount_amount
       , discount_invoiced = b.discount_invoiced
       , discount_percent = b.discount_percent
       , discount_refunded = b.discount_refunded
       , free_shipping = b.free_shipping
       , discount_tax_compensation_amount = b.discount_tax_compensation_amount
       , discount_tax_compensation_invoiced = b.discount_tax_compensation_invoiced
       , discount_tax_compensation_refunded = b.discount_tax_compensation_refunded
       , is_qty_decimal = b.is_qty_decimal
       , is_virtual = b.is_virtual
       , name = b.name
       , no_discount = b.no_discount
       , order_id = b.order_id
       , original_price = b.original_price
       , price = b.price
       , price_incl_tax = b.price_incl_tax
       , product_id = b.product_id
       , product_type = b.product_type
       , qty_canceled = b.qty_canceled
       , qty_invoiced = b.qty_invoiced
       , qty_ordered = b.qty_ordered
       , qty_refunded = b.qty_refunded
       , qty_shipped = b.qty_shipped
       , quote_item_id = b.quote_item_id
       , row_invoiced = b.row_invoiced
       , row_total = b.row_total
       , row_total_incl_tax = b.row_total_incl_tax
       , row_weight = b.row_weight
       , sku = b.sku
       , items_store_id = b.items_store_id
       , tax_amount = b.tax_amount
       , tax_invoiced = b.tax_invoiced
       , tax_percent = b.tax_percent
       , tax_refunded = b.tax_refunded
       , updated_at = b.updated_at
       , weee_tax_applied = b.weee_tax_applied
       , weight = b.weight
       , product_option_extension_attributes_config = b.product_option_extension_attributes_config
    WHEN NOT MATCHED THEN INSERT (
         updated_timestamp
       , entity_id
       , subsidiary_id
       , account
       , parent_applied_rule_ids
       , amount_refunded
       , applied_rule_ids
       , base_amount_refunded
       , base_discount_amount
       , base_discount_invoiced
       , base_discount_refunded
       , base_discount_tax_compensation_amount
       , base_discount_tax_compensation_invoiced
       , base_discount_tax_compensation_refunded
       , base_original_price
       , base_price
       , base_price_incl_tax
       , base_row_invoiced
       , base_row_total
       , base_row_total_incl_tax
       , base_tax_amount
       , base_tax_invoiced
       , base_tax_refunded
       , created_at
       , discount_amount
       , discount_invoiced
       , discount_percent
       , discount_refunded
       , free_shipping
       , discount_tax_compensation_amount
       , discount_tax_compensation_invoiced
       , discount_tax_compensation_refunded
       , is_qty_decimal
       , is_virtual
       , item_id
       , name
       , no_discount
       , order_id
       , original_price
       , price
       , price_incl_tax
       , product_id
       , product_type
       , qty_canceled
       , qty_invoiced
       , qty_ordered
       , qty_refunded
       , qty_shipped
       , quote_item_id
       , row_invoiced
       , row_total
       , row_total_incl_tax
       , row_weight
       , sku
       , items_store_id
       , tax_amount
       , tax_invoiced
       , tax_percent
       , tax_refunded
       , updated_at
       , weee_tax_applied
       , weight
       , product_option_extension_attributes_config
    ) VALUES (
         CURRENT_TIMESTAMP
       , b.entity_id
       , b.subsidiary_id
       , b.account
       , b.parent_applied_rule_ids
       , b.amount_refunded
       , b.applied_rule_ids
       , b.base_amount_refunded
       , b.base_discount_amount
       , b.base_discount_invoiced
       , b.base_discount_refunded
       , b.base_discount_tax_compensation_amount
       , b.base_discount_tax_compensation_invoiced
       , b.base_discount_tax_compensation_refunded
       , b.base_original_price
       , b.base_price
       , b.base_price_incl_tax
       , b.base_row_invoiced
       , b.base_row_total
       , b.base_row_total_incl_tax
       , b.base_tax_amount
       , b.base_tax_invoiced
       , b.base_tax_refunded
       , b.created_at
       , b.discount_amount
       , b.discount_invoiced
       , b.discount_percent
       , b.discount_refunded
       , b.free_shipping
       , b.discount_tax_compensation_amount
       , b.discount_tax_compensation_invoiced
       , b.discount_tax_compensation_refunded
       , b.is_qty_decimal
       , b.is_virtual
       , b.item_id
       , b.name
       , b.no_discount
       , b.order_id
       , b.original_price
       , b.price
       , b.price_incl_tax
       , b.product_id
       , b.product_type
       , b.qty_canceled
       , b.qty_invoiced
       , b.qty_ordered
       , b.qty_refunded
       , b.qty_shipped
       , b.quote_item_id
       , b.row_invoiced
       , b.row_total
       , b.row_total_incl_tax
       , b.row_weight
       , b.sku
       , b.items_store_id
       , b.tax_amount
       , b.tax_invoiced
       , b.tax_percent
       , b.tax_refunded
       , b.updated_at
       , b.weee_tax_applied
       , b.weight
       , b.product_option_extension_attributes_config
    );
END;
$$;

-- CALL OW_LAO.proc_ods_sela_sales_coupons_items();
-- ERROR: Severity: ERROR, Message: Relation "ow_lao.stg_sela_sales_coupons_items" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ods_sela_sales_coupons_items line 3 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
-- CALL OW_LAO.proc_ods_sela_sales_coupons_items();
-- ERROR: Severity: ERROR, Message: Relation "ow_lao.stg_sela_sales_coupons_items" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ods_sela_sales_coupons_items line 3 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
