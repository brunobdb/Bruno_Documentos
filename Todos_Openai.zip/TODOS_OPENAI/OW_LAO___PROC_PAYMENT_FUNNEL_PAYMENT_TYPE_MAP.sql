CREATE OR REPLACE PROCEDURE OW_LAO.PROC_PAYMENT_FUNNEL_PAYMENT_TYPE_MAP()
LANGUAGE PLvSQL AS $$
BEGIN
    -- Upsert new/changed mappings from temp into dimension
    PERFORM MERGE INTO OW_LAO.DIM_PAYMENT_TYPE_MAPPING A
    USING OW_LAO.TMP_PAYMENT_PAYMENT_TYPE B
      ON A.PAYMENT_TYPE = B.PAYMENT_TYPE
     AND A.DATA_SOURCE  = B.DATA_SOURCE
    WHEN MATCHED AND (
          NVL(A.PAYMENT_MODE,'~') <> NVL(B.PAYMENT_MODE,'~')
          OR COALESCE(A.ACTIVE, FALSE) = FALSE
    ) THEN UPDATE SET
          PAYMENT_MODE      = B.PAYMENT_MODE,
          UPDATED_TIMESTAMP = CURRENT_TIMESTAMP,
          ACTIVE            = TRUE,
          REPROCESSING      = TRUE
    WHEN NOT MATCHED THEN INSERT (
          DATA_SOURCE,
          PAYMENT_TYPE,
          PAYMENT_MODE,
          ACTIVE,
          REPROCESSING
    ) VALUES (
          B.DATA_SOURCE,
          B.PAYMENT_TYPE,
          B.PAYMENT_MODE,
          TRUE,
          TRUE
    );

    -- Deactivate mappings not present anymore in the temp source
    PERFORM UPDATE OW_LAO.DIM_PAYMENT_TYPE_MAPPING A
       SET ACTIVE = FALSE,
           REPROCESSING = FALSE,
           UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
     WHERE ACTIVE = TRUE
       AND NOT EXISTS (
             SELECT 1
               FROM OW_LAO.TMP_PAYMENT_PAYMENT_TYPE B
              WHERE A.DATA_SOURCE  = B.DATA_SOURCE
                AND A.PAYMENT_TYPE = B.PAYMENT_TYPE
                AND NVL(A.PAYMENT_MODE,'~') = NVL(B.PAYMENT_MODE,'~')
           );

    -- Nullify mapping in ODS where mapping was deactivated and flagged to reprocess
    PERFORM UPDATE OW_LAO.ODS_PAYMENT_FUNNEL A
       SET PO_PAYMENT_TYPE_STATUS = NULL,
           UPDATED_TIMESTAMP      = CURRENT_TIMESTAMP
      FROM OW_LAO.DIM_PAYMENT_TYPE_MAPPING B
     WHERE B.DATA_SOURCE = A.PO_PLATAFORM_DATASOURCE
       AND B.PAYMENT_TYPE = A.PAYMENT_TYPE
       AND B.ACTIVE = FALSE
       AND B.REPROCESSING = TRUE;

    -- Apply updated mappings to ODS where reprocessing is required
    PERFORM UPDATE OW_LAO.ODS_PAYMENT_FUNNEL A
       SET PO_PAYMENT_TYPE_STATUS = B.PAYMENT_MODE,
           UPDATED_TIMESTAMP      = CURRENT_TIMESTAMP
      FROM OW_LAO.DIM_PAYMENT_TYPE_MAPPING B
     WHERE B.DATA_SOURCE = A.PO_PLATAFORM_DATASOURCE
       AND B.PAYMENT_TYPE = A.PAYMENT_TYPE
       AND B.ACTIVE = TRUE
       AND B.REPROCESSING = TRUE;

    -- Clear reprocessing flags
    PERFORM UPDATE OW_LAO.DIM_PAYMENT_TYPE_MAPPING
       SET REPROCESSING = FALSE
     WHERE REPROCESSING = TRUE;
END;
$$;

-- CALL OW_LAO.PROC_PAYMENT_FUNNEL_PAYMENT_TYPE_MAP();
-- ERROR: Severity: ERROR, Message: Cannot set a NOT NULL column (ID) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure PROC_PAYMENT_FUNNEL_PAYMENT_TYPE_MAP line 4 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3216, Error Code: 2502, 
-- CALL OW_LAO.PROC_PAYMENT_FUNNEL_PAYMENT_TYPE_MAP();
-- ERROR: Severity: ERROR, Message: Cannot set a NOT NULL column (ID) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure PROC_PAYMENT_FUNNEL_PAYMENT_TYPE_MAP line 4 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3216, Error Code: 2502, 
SELECT column_name, data_type, is_nullable, column_default FROM v_catalog.columns WHERE table_schema='OW_LAO' AND table_name='DIM_PAYMENT_TYPE_MAPPING' ORDER BY ordinal_position;
-- column_name | data_type | is_nullable | column_default
-- ------------+-----------+-------------+---------------
-- ID | int | False | 
-- INSERTED_TIMESTAMP | timestamp | True | 
-- UPDATED_TIMESTAMP | timestamp | True | 
-- DATA_SOURCE | varchar(100) | False | 
-- PAYMENT_TYPE | varchar(255) | True | 
-- PAYMENT_MODE | varchar(255) | True | 
-- ACTIVE | boolean | True | 
-- REPROCESSING | boolean | True | 

CREATE OR REPLACE PROCEDURE OW_LAO.PROC_PAYMENT_FUNNEL_PAYMENT_TYPE_MAP()
LANGUAGE PLvSQL AS $$
BEGIN
    -- Update existing mappings that changed or are inactive
    PERFORM UPDATE OW_LAO.DIM_PAYMENT_TYPE_MAPPING A
       SET PAYMENT_MODE      = B.PAYMENT_MODE,
           UPDATED_TIMESTAMP = CURRENT_TIMESTAMP,
           ACTIVE            = TRUE,
           REPROCESSING      = TRUE
      FROM OW_LAO.TMP_PAYMENT_PAYMENT_TYPE B
     WHERE A.PAYMENT_TYPE = B.PAYMENT_TYPE
       AND A.DATA_SOURCE  = B.DATA_SOURCE
       AND (
            NVL(A.PAYMENT_MODE,'~') <> NVL(B.PAYMENT_MODE,'~')
            OR COALESCE(A.ACTIVE, FALSE) = FALSE
       );

    -- Insert new mappings not present in dimension, generating IDs sequentially
    PERFORM INSERT INTO OW_LAO.DIM_PAYMENT_TYPE_MAPPING
           (ID, DATA_SOURCE, PAYMENT_TYPE, PAYMENT_MODE, ACTIVE, REPROCESSING)
    WITH maxid AS (
        SELECT COALESCE(MAX(ID),0) AS m FROM OW_LAO.DIM_PAYMENT_TYPE_MAPPING
    ), to_insert AS (
        SELECT B.DATA_SOURCE, B.PAYMENT_TYPE, B.PAYMENT_MODE,
               ROW_NUMBER() OVER (ORDER BY B.DATA_SOURCE, B.PAYMENT_TYPE) AS rn
          FROM OW_LAO.TMP_PAYMENT_PAYMENT_TYPE B
          LEFT JOIN OW_LAO.DIM_PAYMENT_TYPE_MAPPING A
            ON A.DATA_SOURCE = B.DATA_SOURCE
           AND A.PAYMENT_TYPE = B.PAYMENT_TYPE
         WHERE A.ID IS NULL
    )
    SELECT m.m + t.rn AS ID,
           t.DATA_SOURCE,
           t.PAYMENT_TYPE,
           t.PAYMENT_MODE,
           TRUE AS ACTIVE,
           TRUE AS REPROCESSING
      FROM to_insert t CROSS JOIN maxid m;

    -- Deactivate mappings not present anymore in the temp source
    PERFORM UPDATE OW_LAO.DIM_PAYMENT_TYPE_MAPPING A
       SET ACTIVE = FALSE,
           REPROCESSING = FALSE,
           UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
     WHERE ACTIVE = TRUE
       AND NOT EXISTS (
             SELECT 1
               FROM OW_LAO.TMP_PAYMENT_PAYMENT_TYPE B
              WHERE A.DATA_SOURCE  = B.DATA_SOURCE
                AND A.PAYMENT_TYPE = B.PAYMENT_TYPE
                AND NVL(A.PAYMENT_MODE,'~') = NVL(B.PAYMENT_MODE,'~')
           );

    -- Nullify mapping in ODS where mapping was deactivated and flagged to reprocess
    PERFORM UPDATE OW_LAO.ODS_PAYMENT_FUNNEL A
       SET PO_PAYMENT_TYPE_STATUS = NULL,
           UPDATED_TIMESTAMP      = CURRENT_TIMESTAMP
      FROM OW_LAO.DIM_PAYMENT_TYPE_MAPPING B
     WHERE B.DATA_SOURCE = A.PO_PLATAFORM_DATASOURCE
       AND B.PAYMENT_TYPE = A.PAYMENT_TYPE
       AND B.ACTIVE = FALSE
       AND B.REPROCESSING = TRUE;

    -- Apply updated mappings to ODS where reprocessing is required
    PERFORM UPDATE OW_LAO.ODS_PAYMENT_FUNNEL A
       SET PO_PAYMENT_TYPE_STATUS = B.PAYMENT_MODE,
           UPDATED_TIMESTAMP      = CURRENT_TIMESTAMP
      FROM OW_LAO.DIM_PAYMENT_TYPE_MAPPING B
     WHERE B.DATA_SOURCE = A.PO_PLATAFORM_DATASOURCE
       AND B.PAYMENT_TYPE = A.PAYMENT_TYPE
       AND B.ACTIVE = TRUE
       AND B.REPROCESSING = TRUE;

    -- Clear reprocessing flags
    PERFORM UPDATE OW_LAO.DIM_PAYMENT_TYPE_MAPPING
       SET REPROCESSING = FALSE
     WHERE REPROCESSING = TRUE;
END;
$$;

CALL OW_LAO.PROC_PAYMENT_FUNNEL_PAYMENT_TYPE_MAP();
-- PROC_PAYMENT_FUNNEL_PAYMENT_TYPE_MAP
-- ------------------------------------
-- 0

