-- CREATE OR REPLACE PROCEDURE ow_lao.proc_ods_exchange_rate_homolog()
-- LANGUAGE PLvSQL AS $$
-- DECLARE
--   load_date_newest DATE;
--   load_date_not_exists BOOLEAN;
-- BEGIN
--  
--   SELECT MAX(a.load_date)
--     INTO load_date_newest
--     FROM ow_lao.ods_erp_exchange_rate a
--    WHERE "Exchange Rate Type" = 'M';
-- 
--   SELECT CASE WHEN EXISTS (
--            SELECT 1 FROM ow_lao.ft_ap2_exchange_rate_homolog b WHERE b.load_date = load_date_newest
--          ) THEN TRUE ELSE FALSE END
--     INTO load_date_not_exists;
--           
--   IF load_date_not_exists = FALSE THEN
--     
--     PERFORM DROP TABLE IF EXISTS ODS_ERP_EXCHANGE_RATE_TEMP;
--     PERFORM CREATE LOCAL TEMPORARY TABLE ODS_ERP_EXCHANGE_RATE_TEMP ON COMMIT PRESERVE ROWS (
--       from_currency VARCHAR(255),
--       to_currency VARCHAR(255),
--       valid_from DATE,
--       exchange_rate NUMERIC(38,10),
--       load_date DATE,
--       process_status VARCHAR(256),
--       comment_status VARCHAR(256),
--       dedup INT
--     );
--                     
--     PERFORM INSERT INTO ODS_ERP_EXCHANGE_RATE_TEMP (from_currency, to_currency, valid_from, exchange_rate, load_date, process_status, comment_status, dedup)
--     SELECT DISTINCT
--            "From currency"                                        AS from_currency
--          , "To-currency"                                          AS to_currency
--          , TO_DATE(REPLACE("Valid from", '.', '-'))               AS valid_from
--          , CAST(REPLACE("Exchange Rate", ',', '') AS NUMERIC(38,10)) AS exchange_rate
--          , load_date                                               AS load_date
--          , NULL                                                    AS process_status
--          , NULL                                                    AS comment_status  
--          , ROW_NUMBER() OVER(
--                PARTITION BY "From currency", "To-currency", REPLACE("Valid from", '.', '-')
--                ORDER BY load_date DESC
--            )                                                       AS dedup
--       FROM ow_lao.ods_erp_exchange_rate
--      WHERE "Exchange Rate Type" = 'M'
--        AND "Exchange Rate" IS NOT NULL
--        AND load_date = load_date_newest;   
--                      
--     PERFORM DELETE FROM ODS_ERP_EXCHANGE_RATE_TEMP WHERE dedup <> 1;
--                  
--     PERFORM MERGE INTO ow_lao.ft_ap2_exchange_rate_homolog a
--          USING ODS_ERP_EXCHANGE_RATE_TEMP         b 
--             ON b.from_currency = a.from_currency
--            AND b.to_currency   = a.to_currency
--            AND b.valid_from    = a.valid_from
--      WHEN MATCHED THEN 
--        UPDATE SET a.load_date         = b.load_date
--                 , a.exchange_rate     = b.exchange_rate  
--                 , a.process_status    = b.process_status
--                 , a.comment_status    = b.comment_status
--                 , a.updated_timestamp = CURRENT_TIMESTAMP
--      WHEN NOT MATCHED THEN 
--        INSERT(  from_currency
--               , to_currency
--               , valid_from
--               , load_date
--               , exchange_rate
--               , process_status
--               , comment_status
--             )
--        VALUES(  b.from_currency
--               , b.to_currency
--               , b.valid_from
--               , b.load_date
--               , b.exchange_rate
--               , b.process_status
--               , b.comment_status
--             );
--   END IF;             
--           
--   PERFORM DROP TABLE IF EXISTS ODS_ERP_EXCHANGE_RATE_DEFAULT;
--   PERFORM CREATE LOCAL TEMPORARY TABLE ODS_ERP_EXCHANGE_RATE_DEFAULT ON COMMIT PRESERVE ROWS
--        (        
--                valid_from    DATE
--              , from_currency VARCHAR(255)
--              , to_currency   VARCHAR(255)
--              , exchange_rate NUMERIC(38,10) DEFAULT 0.00
--         );
--          
--   PERFORM INSERT INTO ODS_ERP_EXCHANGE_RATE_DEFAULT (valid_from, from_currency, to_currency, exchange_rate)
--   SELECT a.YYYYMMDD                          AS valid_from
--        , b."From currency"                   AS from_currency
--        , b."To-currency"                     AS to_currency
--        , CAST(0.00 AS NUMERIC(38,10))        AS exchange_rate
--     FROM ow_md.dim_calendar           a
--     JOIN ow_lao.ods_erp_exchange_rate b ON 1 = 1
--    WHERE a.YYYYMMDD BETWEEN TIMESTAMPADD(DAY, -30, CURRENT_DATE)
--                         AND CURRENT_DATE
--      AND b."Exchange Rate Type" = 'M'
--      AND b."Exchange Rate" IS NOT NULL
--      AND NOT EXISTS(
--                    SELECT 1
--                      FROM ow_lao.ft_ap2_exchange_rate_homolog aa
--                     WHERE aa.valid_from    = a.YYYYMMDD
--                       AND aa.from_currency = b."From currency"
--                       AND aa.to_currency   = b."To-currency"
--               )
-- GROUP BY a.YYYYMMDD, b."From currency", b."To-currency"; 
--                 
--   PERFORM INSERT INTO ODS_ERP_EXCHANGE_RATE_DEFAULT (valid_from, from_currency, to_currency, exchange_rate)
--   SELECT a.YYYYMMDD                          AS valid_from
--        , b.from_currency                     AS from_currency
--        , b.to_currency                       AS to_currency
--        , CAST(0.00 AS NUMERIC(38,10))        AS exchange_rate
--     FROM ow_md.dim_calendar                  a
--     JOIN ow_lao.ft_ap2_exchange_rate_homolog b ON 1 = 1
--    WHERE a.YYYYMMDD BETWEEN TIMESTAMPADD(DAY, -30, CURRENT_DATE)
--                         AND CURRENT_DATE
--      AND NOT EXISTS(
--                    SELECT 1
--                      FROM ODS_ERP_EXCHANGE_RATE_DEFAULT aa
--                     WHERE aa.valid_from    = a.YYYYMMDD
--                       AND aa.from_currency = b.from_currency
--                       AND aa.to_currency   = b.to_currency
--               )
--      AND NOT EXISTS(
--                    SELECT 1
--                      FROM ow_lao.ft_ap2_exchange_rate_homolog aa
--                     WHERE aa.valid_from    = a.YYYYMMDD
--                       AND aa.from_currency = b.from_currency
--                       AND aa.to_currency   = b.to_currency
--               )
-- GROUP BY a.YYYYMMDD, b.from_currency, b.to_currency;                
--         
--   PERFORM DROP TABLE IF EXISTS ODS_ERP_EXCHANGE_RATE_LAST_VALID_FROM_VALUE;
--   PERFORM CREATE LOCAL TEMPORARY TABLE ODS_ERP_EXCHANGE_RATE_LAST_VALID_FROM_VALUE ON COMMIT PRESERVE ROWS
--        (        
--                valid_from    DATE
--              , from_currency VARCHAR(255)
--              , to_currency   VARCHAR(255)
--              , exchange_rate NUMERIC(38,10) DEFAULT 0.00
--         );      
--         
--   PERFORM INSERT INTO ODS_ERP_EXCHANGE_RATE_LAST_VALID_FROM_VALUE (valid_from, from_currency, to_currency, exchange_rate)
--   SELECT MAX(b.valid_from)
--        , a.from_currency
--        , a.to_currency
--        , CAST(0.00 AS NUMERIC(38,10))
--     FROM ODS_ERP_EXCHANGE_RATE_DEFAULT      a
--     JOIN ow_lao.ft_ap2_exchange_rate_homolog b ON b.from_currency = a.from_currency
--                                               AND b.to_currency   = a.to_currency
-- GROUP BY a.from_currency, a.to_currency;                                                        
--                     
--   PERFORM UPDATE ODS_ERP_EXCHANGE_RATE_DEFAULT a
--      SET exchange_rate = c.exchange_rate
--     FROM ODS_ERP_EXCHANGE_RATE_LAST_VALID_FROM_VALUE b
--     JOIN ow_lao.ft_ap2_exchange_rate_homolog          c ON c.from_currency = a.from_currency
--                                                        AND c.to_currency   = a.to_currency
--                                                        AND c.valid_from    = b.valid_from
--    WHERE b.from_currency = a.from_currency
--      AND b.to_currency   = a.to_currency;
--                                                                      
--   PERFORM INSERT INTO ow_lao.ft_ap2_exchange_rate_homolog(
--          from_currency
--        , to_currency
--        , valid_from
--        , exchange_rate
--        , process_status
--        , comment_status
--   )
--   SELECT from_currency
--        , to_currency
--        , valid_from
--        , exchange_rate
--        , 'ADJUSTMENT'     AS process_status
--        , 'Null on GERP'   AS comment_status
--     FROM ODS_ERP_EXCHANGE_RATE_DEFAULT;          
--  
-- END
-- $$;
-- ERROR: Severity: ROLLBACK, Message: Syntax error at or near "(", Sqlstate: 42601, Position: 697, Routine: base_yyerror, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/scan.l, Line: 1056, Error Code: 4856, 
CREATE OR REPLACE PROCEDURE ow_lao.proc_ods_exchange_rate_homolog()
LANGUAGE PLvSQL AS $$
DECLARE
  load_date_newest DATE;
  cnt INT;
BEGIN
 
  SELECT MAX(a.load_date)
    INTO load_date_newest
    FROM ow_lao.ods_erp_exchange_rate a
   WHERE "Exchange Rate Type" = 'M';

  SELECT COUNT(1)
    INTO cnt
    FROM ow_lao.ft_ap2_exchange_rate_homolog b
   WHERE b.load_date = load_date_newest;
          
  IF cnt = 0 THEN
    
    PERFORM DROP TABLE IF EXISTS ODS_ERP_EXCHANGE_RATE_TEMP;
    PERFORM CREATE LOCAL TEMPORARY TABLE ODS_ERP_EXCHANGE_RATE_TEMP ON COMMIT PRESERVE ROWS AS
      SELECT CAST(NULL AS VARCHAR(255)) AS from_currency,
             CAST(NULL AS VARCHAR(255)) AS to_currency,
             CAST(NULL AS DATE)         AS valid_from,
             CAST(NULL AS NUMERIC(38,10)) AS exchange_rate,
             CAST(NULL AS DATE)         AS load_date,
             CAST(NULL AS VARCHAR(256)) AS process_status,
             CAST(NULL AS VARCHAR(256)) AS comment_status,
             CAST(NULL AS INT)          AS dedup
      WHERE 1=0;
                    
    PERFORM INSERT INTO ODS_ERP_EXCHANGE_RATE_TEMP (from_currency, to_currency, valid_from, exchange_rate, load_date, process_status, comment_status, dedup)
    SELECT DISTINCT
           "From currency"                                        AS from_currency
         , "To-currency"                                          AS to_currency
         , TO_DATE(REPLACE("Valid from", '.', '-'))               AS valid_from
         , CAST(REPLACE("Exchange Rate", ',', '') AS NUMERIC(38,10)) AS exchange_rate
         , load_date                                               AS load_date
         , NULL                                                    AS process_status
         , NULL                                                    AS comment_status  
         , ROW_NUMBER() OVER(
               PARTITION BY "From currency", "To-currency", REPLACE("Valid from", '.', '-')
               ORDER BY load_date DESC
           )                                                       AS dedup
      FROM ow_lao.ods_erp_exchange_rate
     WHERE "Exchange Rate Type" = 'M'
       AND "Exchange Rate" IS NOT NULL
       AND load_date = load_date_newest;   
                     
    PERFORM DELETE FROM ODS_ERP_EXCHANGE_RATE_TEMP WHERE dedup <> 1;
                 
    PERFORM MERGE INTO ow_lao.ft_ap2_exchange_rate_homolog a
         USING ODS_ERP_EXCHANGE_RATE_TEMP         b 
            ON b.from_currency = a.from_currency
           AND b.to_currency   = a.to_currency
           AND b.valid_from    = a.valid_from
     WHEN MATCHED THEN 
       UPDATE SET a.load_date         = b.load_date
                , a.exchange_rate     = b.exchange_rate  
                , a.process_status    = b.process_status
                , a.comment_status    = b.comment_status
                , a.updated_timestamp = CURRENT_TIMESTAMP
     WHEN NOT MATCHED THEN 
       INSERT(  from_currency
              , to_currency
              , valid_from
              , load_date
              , exchange_rate
              , process_status
              , comment_status
            )
       VALUES(  b.from_currency
              , b.to_currency
              , b.valid_from
              , b.load_date
              , b.exchange_rate
              , b.process_status
              , b.comment_status
            );
  END IF;             
          
  PERFORM DROP TABLE IF EXISTS ODS_ERP_EXCHANGE_RATE_DEFAULT;
  PERFORM CREATE LOCAL TEMPORARY TABLE ODS_ERP_EXCHANGE_RATE_DEFAULT ON COMMIT PRESERVE ROWS AS
       SELECT CAST(NULL AS DATE)          AS valid_from,
              CAST(NULL AS VARCHAR(255))  AS from_currency,
              CAST(NULL AS VARCHAR(255))  AS to_currency,
              CAST(0.00 AS NUMERIC(38,10)) AS exchange_rate
       WHERE 1=0;
         
  PERFORM INSERT INTO ODS_ERP_EXCHANGE_RATE_DEFAULT (valid_from, from_currency, to_currency, exchange_rate)
  SELECT a.YYYYMMDD                          AS valid_from
       , b."From currency"                   AS from_currency
       , b."To-currency"                     AS to_currency
       , CAST(0.00 AS NUMERIC(38,10))        AS exchange_rate
    FROM ow_md.dim_calendar           a
    JOIN ow_lao.ods_erp_exchange_rate b ON 1 = 1
   WHERE a.YYYYMMDD BETWEEN TIMESTAMPADD(DAY, -30, CURRENT_DATE)
                        AND CURRENT_DATE
     AND b."Exchange Rate Type" = 'M'
     AND b."Exchange Rate" IS NOT NULL
     AND NOT EXISTS(
                   SELECT 1
                     FROM ow_lao.ft_ap2_exchange_rate_homolog aa
                    WHERE aa.valid_from    = a.YYYYMMDD
                      AND aa.from_currency = b."From currency"
                      AND aa.to_currency   = b."To-currency"
              )
GROUP BY a.YYYYMMDD, b."From currency", b."To-currency"; 
                
  PERFORM INSERT INTO ODS_ERP_EXCHANGE_RATE_DEFAULT (valid_from, from_currency, to_currency, exchange_rate)
  SELECT a.YYYYMMDD                          AS valid_from
       , b.from_currency                     AS from_currency
       , b.to_currency                       AS to_currency
       , CAST(0.00 AS NUMERIC(38,10))        AS exchange_rate
    FROM ow_md.dim_calendar                  a
    JOIN ow_lao.ft_ap2_exchange_rate_homolog b ON 1 = 1
   WHERE a.YYYYMMDD BETWEEN TIMESTAMPADD(DAY, -30, CURRENT_DATE)
                        AND CURRENT_DATE
     AND NOT EXISTS(
                   SELECT 1
                     FROM ODS_ERP_EXCHANGE_RATE_DEFAULT aa
                    WHERE aa.valid_from    = a.YYYYMMDD
                      AND aa.from_currency = b.from_currency
                      AND aa.to_currency   = b.to_currency
              )
     AND NOT EXISTS(
                   SELECT 1
                     FROM ow_lao.ft_ap2_exchange_rate_homolog aa
                    WHERE aa.valid_from    = a.YYYYMMDD
                      AND aa.from_currency = b.from_currency
                      AND aa.to_currency   = b.to_currency
              )
GROUP BY a.YYYYMMDD, b.from_currency, b.to_currency;                
        
  PERFORM DROP TABLE IF EXISTS ODS_ERP_EXCHANGE_RATE_LAST_VALID_FROM_VALUE;
  PERFORM CREATE LOCAL TEMPORARY TABLE ODS_ERP_EXCHANGE_RATE_LAST_VALID_FROM_VALUE ON COMMIT PRESERVE ROWS AS
       SELECT CAST(NULL AS DATE)          AS valid_from,
              CAST(NULL AS VARCHAR(255))  AS from_currency,
              CAST(NULL AS VARCHAR(255))  AS to_currency,
              CAST(0.00 AS NUMERIC(38,10)) AS exchange_rate
       WHERE 1=0;      
        
  PERFORM INSERT INTO ODS_ERP_EXCHANGE_RATE_LAST_VALID_FROM_VALUE (valid_from, from_currency, to_currency, exchange_rate)
  SELECT MAX(b.valid_from)
       , a.from_currency
       , a.to_currency
       , CAST(0.00 AS NUMERIC(38,10))
    FROM ODS_ERP_EXCHANGE_RATE_DEFAULT      a
    JOIN ow_lao.ft_ap2_exchange_rate_homolog b ON b.from_currency = a.from_currency
                                              AND b.to_currency   = a.to_currency
GROUP BY a.from_currency, a.to_currency;                                                        
                    
  PERFORM UPDATE ODS_ERP_EXCHANGE_RATE_DEFAULT a
     SET exchange_rate = c.exchange_rate
    FROM ODS_ERP_EXCHANGE_RATE_LAST_VALID_FROM_VALUE b
    JOIN ow_lao.ft_ap2_exchange_rate_homolog          c ON c.from_currency = a.from_currency
                                                       AND c.to_currency   = a.to_currency
                                                       AND c.valid_from    = b.valid_from
   WHERE b.from_currency = a.from_currency
     AND b.to_currency   = a.to_currency;
                                                                     
  PERFORM INSERT INTO ow_lao.ft_ap2_exchange_rate_homolog(
         from_currency
       , to_currency
       , valid_from
       , exchange_rate
       , process_status
       , comment_status
  )
  SELECT from_currency
       , to_currency
       , valid_from
       , exchange_rate
       , 'ADJUSTMENT'     AS process_status
       , 'Null on GERP'   AS comment_status
    FROM ODS_ERP_EXCHANGE_RATE_DEFAULT;          
 
END
$$;

-- CALL ow_lao.proc_ods_exchange_rate_homolog();
-- ERROR: Severity: ERROR, Message: Relation "ow_lao.ft_ap2_exchange_rate_homolog" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ods_exchange_rate_homolog line 12 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
-- CALL ow_lao.proc_ods_exchange_rate_homolog();
-- ERROR: Severity: ERROR, Message: Relation "ow_lao.ft_ap2_exchange_rate_homolog" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ods_exchange_rate_homolog line 12 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
