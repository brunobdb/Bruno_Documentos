CREATE OR REPLACE PROCEDURE OW_LAO.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_outbound_update_homolog()
 LANGUAGE PLvSQL AS $$
BEGIN
  PERFORM
  UPDATE ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown a
     SET delivery_no                    = b.delivery_no
       , city                           = b.city
       , region                         = b.region
       , district                       = b.district
       , date_toretrive                 = b.planned_gi
       , date_retrived                  = b."1ST_GI_DATE"
       , volume                         = b.volume
       , weight                         = b.weight
       , shipping_type                  = b.shipping_type
       , date_delivered                 = b.rdd
       , storage_location               = b.storage_location
       , final_eta_date                 = b.final_eta
       , delivey_date                   = b.epod_date
       , serial_number_code             = b.ean
       , delivery_extimeted_date        = b.delivery_date
       , delivery_carrier               = b.transporter_name
       , nerp_outbound_last_update_date = b.load_date
       , updated_datetime               = CURRENT_TIMESTAMP
    FROM ow_lao.ods_nerp_zllej50090_outbound_tracking b
   WHERE b.delivery_no = a.nerp_deliverycode
     AND b.material = a.nerp_sku
     AND (a.nerp_outbound_last_update_date < b.load_date OR a.nerp_outbound_last_update_date IS NULL);
END;
$$;

-- CALL OW_LAO.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_outbound_update_homolog();
-- ERROR: Severity: ERROR, Message: Column "final_eta_date" is of type date but expression is of type varchar, Sqlstate: 42804, Hint: You will need to rewrite or cast the expression, Where: PL/vSQL procedure tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_outbound_update_homolog line 4 at static SQL, Routine: updateTargetListEntry, File: parse_target.c, Line: 853, Error Code: 2631, 
-- CALL OW_LAO.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_outbound_update_homolog();
-- ERROR: Severity: ERROR, Message: Column "final_eta_date" is of type date but expression is of type varchar, Sqlstate: 42804, Hint: You will need to rewrite or cast the expression, Where: PL/vSQL procedure tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_outbound_update_homolog line 4 at static SQL, Routine: updateTargetListEntry, File: parse_target.c, Line: 853, Error Code: 2631, 
SELECT column_name, data_type FROM v_catalog.columns WHERE table_schema='ow_lao' AND table_name='tmp_ecommerce_sales_control_tower_table_bundles_breakdown' ORDER BY ordinal_position;
-- column_name | data_type
-- ------------+----------

CREATE OR REPLACE PROCEDURE OW_LAO.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_outbound_update_homolog()
 LANGUAGE PLvSQL AS $$
BEGIN
  PERFORM
  UPDATE ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown a
     SET delivery_no                    = b.delivery_no
       , city                           = b.city
       , region                         = b.region
       , district                       = b.district
       , date_toretrive                 = CAST(b.planned_gi AS DATE)
       , date_retrived                  = CAST(b."1ST_GI_DATE" AS DATE)
       , volume                         = b.volume
       , weight                         = b.weight
       , shipping_type                  = b.shipping_type
       , date_delivered                 = CAST(b.rdd AS DATE)
       , storage_location               = b.storage_location
       , final_eta_date                 = CAST(b.final_eta AS DATE)
       , delivey_date                   = CAST(b.epod_date AS DATE)
       , serial_number_code             = b.ean
       , delivery_extimeted_date        = CAST(b.delivery_date AS DATE)
       , delivery_carrier               = b.transporter_name
       , nerp_outbound_last_update_date = b.load_date
       , updated_datetime               = CURRENT_TIMESTAMP
    FROM ow_lao.ods_nerp_zllej50090_outbound_tracking b
   WHERE b.delivery_no = a.nerp_deliverycode
     AND b.material = a.nerp_sku
     AND (a.nerp_outbound_last_update_date < b.load_date OR a.nerp_outbound_last_update_date IS NULL);
END;
$$;

CALL OW_LAO.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_outbound_update_homolog();
-- tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_outbound_update_homolog
-- --------------------------------------------------------------------------------------
-- 0

