CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_sales_control_tower_table_visuar()
LANGUAGE PLvSQL AS $$
BEGIN

  PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_orders_visuar_prepare ON COMMIT PRESERVE ROWS AS (
    SELECT 
        a.fecha_de_emision_del_movimiento_formated        AS po_date,
        EXTRACT(MONTH FROM a.fecha_de_emision_del_movimiento_formated) AS po_month,
        EXTRACT(YEAR  FROM a.fecha_de_emision_del_movimiento_formated) AS po_year,
        b.country                                         AS country,
        b.subsidiary                                      AS subsidiary,
        b.currency                                        AS currency,
        COALESCE(a.updated_timestamp, a.inserted_timestamp) AS po_lastupdate_date_hour,
        COALESCE(a.updated_timestamp, a.inserted_timestamp) AS po_source_last_update_date,
        a.numero                                          AS po_orderid,
        a.razon_social                                    AS po_seller_name,
        a.descripcion_producto                            AS po_prodname,
        a.canal_de_venta_com                              AS po_store_name,
        CAST(NULL AS VARCHAR(255))                        AS po_storename,
        CAST(NULL AS VARCHAR(255))                        AS channel,
        CAST(NULL AS VARCHAR(255))                        AS biz_type,
        CAST(NULL AS VARCHAR(255))                        AS audience_type,
        a.status                                          AS po_status,
        a.status                                          AS po_internal_status,
        a.reference_code                                  AS po_sku,
        ABS(a.cantidad_real)                              AS po_qty,
        0                                                 AS po_orderqty,
        a.total_bonificado                                AS po_itemdiscount_localcurr,
        CAST(0.00 AS DECIMAL)                             AS po_itemdiscount_usd,
        CAST(REPLACE(monto_sin_impuestos, ',', '') AS DECIMAL) AS po_price_localcurr,
        CAST(0.00 AS DECIMAL)                             AS po_price_usd,
        'ow_lao.ods_orders_visuar'                        AS po_plataform_datasource,
        a.inserted_timestamp                              AS po_source_insert_date,
        CAST(0.00 AS DECIMAL)                             AS po_totalprice_usd,
        CAST(0.00 AS DECIMAL)                             AS po_totalprice_local,
        a.id                                              AS po_plataform_datasource_order_id,
        CAST(NULL AS VARCHAR(255))                        AS po_devicetype,
        ''                                                AS po_sku_kit,
        ''                                                AS po_prodname_kit,
        CAST(0.00 AS DECIMAL)                             AS po_price_localcurr_kit,
        CAST(0.00 AS DECIMAL)                             AS po_itemdiscount_localcurr_kit,
        FALSE                                             AS is_kit,
        'ARG'                                             AS country_cd,
        CAST(NULL AS VARCHAR(3))                          AS biz_type_ebi_hq,
        CAST(NULL AS VARCHAR(3))                          AS global_channel_ebi_hq,
        1                                                 AS installment,
        b.id                                              AS client_subsidiary_id,
        'visuar'                                          AS po_sitecode,
        CAST(NULL AS VARCHAR(255))                        AS customer_type,
        CAST(NULL AS VARCHAR(255))                        AS po_mobile_os
    FROM ow_lao.ods_orders_visuar a
    JOIN u_prj_ecom.dim_subsidiary b ON b.id = 1
    WHERE NOT EXISTS (
      SELECT 1
      FROM ow_lao.ods_sales_control_tower_table aa
      WHERE aa.po_orderid           = a.numero
        AND aa.po_sku               = a.reference_code
        AND aa.po_status            = a.status
        AND aa.client_subsidiary_id = 1
        AND aa.po_sitecode          = 'visuar'
    )
  );

  PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_orders_visuar_prepare_agg ON COMMIT PRESERVE ROWS AS (
    SELECT 
        country,
        po_orderid,
        SUM(po_qty)             AS po_orderqty,
        SUM(po_price_localcurr) AS po_totalprice_local
    FROM tmp_ods_orders_visuar_prepare
    GROUP BY country, po_orderid
  );

  PERFORM CREATE LOCAL TEMPORARY TABLE tmp_ods_orders_visuar_prepare_sku_agg ON COMMIT PRESERVE ROWS AS (
    SELECT 
        country,
        po_orderid,
        po_sku,
        SUM(po_qty)                    AS po_orderqty,
        SUM(po_price_localcurr)        AS po_totalprice_local,
        SUM(po_itemdiscount_localcurr) AS po_itemdiscount_localcurr
    FROM tmp_ods_orders_visuar_prepare
    GROUP BY country, po_orderid, po_sku
  );

  PERFORM UPDATE tmp_ods_orders_visuar_prepare a
    SET po_orderqty         = b.po_orderqty,
        po_totalprice_local = (c.po_totalprice_local * c.po_orderqty) - c.po_itemdiscount_localcurr
  FROM tmp_ods_orders_visuar_prepare_agg b
  JOIN tmp_ods_orders_visuar_prepare_sku_agg c
    ON c.country = a.country
   AND c.po_orderid = a.po_orderid
   AND c.po_sku = a.po_sku
  WHERE b.country = a.country
    AND b.po_orderid = a.po_orderid;

  PERFORM UPDATE tmp_ods_orders_visuar_prepare a
    SET po_itemdiscount_usd = a.po_itemdiscount_localcurr / CAST(b.exchange_rate AS DECIMAL),
        po_price_usd        = a.po_price_localcurr        / CAST(b.exchange_rate AS DECIMAL),
        po_totalprice_usd   = a.po_totalprice_local       / CAST(b.exchange_rate AS DECIMAL)
  FROM ow_lao.ft_ap2_exchange_rate b
  WHERE b.valid_from  = TIMESTAMPADD(DAY, -1, a.po_date)
    AND b.to_currency = a.currency;

  PERFORM UPDATE tmp_ods_orders_visuar_prepare a
    SET channel               = b.global_channel,
        biz_type              = b.biz_type,
        audience_type         = b.audience_type,
        biz_type_ebi_hq       = b.biz_type_ebi,
        global_channel_ebi_hq = b.global_channel_ebi,
        po_storename          = b.partner_level,
        customer_type         = b.customer_type,
        po_mobile_os          = b.po_mobile_os
  FROM ow_md.sales_channel b
  WHERE LOWER(b.country)    = LOWER(a.country)
    AND LOWER(b.identifier) = LOWER(a.po_store_name)
    AND a.client_subsidiary_id = 1
    AND LOWER(b.plataform_type) = 'visuar';

  PERFORM UPDATE tmp_ods_orders_visuar_prepare
     SET po_devicetype = 'MOBILEAPP'
   WHERE po_sitecode = 'samsungarapp'
     AND client_subsidiary_id = 1;

  PERFORM UPDATE tmp_ods_orders_visuar_prepare
     SET po_devicetype = 'Web'
   WHERE po_devicetype IS NULL;

  PERFORM UPDATE tmp_ods_orders_visuar_prepare
     SET global_channel_ebi_hq = '3PD',
         biz_type_ebi_hq       = 'B2C'
   WHERE global_channel_ebi_hq IS NULL;

  PERFORM UPDATE tmp_ods_orders_visuar_prepare
     SET channel       = 'eStore',
         biz_type      = '3PD',
         audience_type = '3PD'
   WHERE channel IS NULL;

  PERFORM MERGE INTO ow_lao.ods_sales_control_tower_table a
  USING tmp_ods_orders_visuar_prepare b
     ON b.po_orderid  = a.po_orderid
    AND b.po_sku      = a.po_sku
    AND b.country     = a.country
    AND b.po_sku_kit  = a.po_sku_kit
    AND b.po_sitecode = a.po_sitecode
  WHEN MATCHED THEN UPDATE SET
       po_date                         = b.po_date,
       podate_month                    = b.po_month,
       podate_year                     = b.po_year,
       country                         = b.country,
       subsidiary                      = b.subsidiary,
       currency                        = b.currency,
       po_lastupdate_date_hour         = b.po_lastupdate_date_hour,
       po_source_last_update_date      = b.po_source_last_update_date,
       po_orderid                      = b.po_orderid,
       po_seller_name                  = b.po_seller_name,
       po_prodname                     = b.po_prodname,
       po_store_name                   = b.po_store_name,
       po_storename                    = b.po_storename,
       channel                         = b.channel,
       biz_type                        = b.biz_type,
       audience_type                   = b.audience_type,
       po_status                       = b.po_status,
       po_internal_status              = b.po_internal_status,
       po_sku                          = b.po_sku,
       po_qty                          = b.po_qty,
       po_orderqty                     = b.po_orderqty,
       po_itemdiscount_localcurr       = b.po_itemdiscount_localcurr,
       po_itemdiscount_usd             = b.po_itemdiscount_usd,
       po_price_localcurr              = b.po_price_localcurr,
       po_price_usd                    = b.po_price_usd,
       po_plataform_datasource         = b.po_plataform_datasource,
       po_source_insert_date           = b.po_source_insert_date,
       po_totalprice_usd               = b.po_totalprice_usd,
       po_totalprice_local             = b.po_totalprice_local,
       po_devicetype                   = b.po_devicetype,
       po_sku_kit                      = b.po_sku_kit,
       po_prodname_kit                 = b.po_prodname_kit,
       is_kit                          = b.is_kit,
       country_cd                      = b.country_cd,
       biz_type_ebi_hq                 = b.biz_type_ebi_hq,
       global_channel_ebi_hq           = b.global_channel_ebi_hq,
       customer_type                   = b.customer_type,
       po_mobile_os                    = b.po_mobile_os,
       installment                     = b.installment,
       updated_datetime                = CURRENT_TIMESTAMP
  WHEN NOT MATCHED THEN INSERT (
       po_date,
       podate_month,
       podate_year,
       country,
       subsidiary,
       currency,
       po_lastupdate_date_hour,
       po_source_last_update_date,
       po_orderid,
       po_seller_name,
       po_prodname,
       po_store_name,
       po_storename,
       channel,
       biz_type,
       audience_type,
       po_status,
       po_internal_status,
       po_sku,
       po_qty,
       po_orderqty,
       po_itemdiscount_localcurr,
       po_itemdiscount_usd,
       po_price_localcurr,
       po_price_usd,
       po_plataform_datasource,
       po_source_insert_date,
       po_totalprice_usd,
       po_totalprice_local,
       po_devicetype,
       po_sku_kit,
       po_prodname_kit,
       is_kit,
       country_cd,
       biz_type_ebi_hq,
       global_channel_ebi_hq,
       installment,
       samsung_care_order,
       samsung_care_eligibility,
       trade_in_eligibility,
       client_subsidiary_id,
       po_sitecode,
       customer_type,
       po_mobile_os
  ) VALUES (
       b.po_date,
       b.po_month,
       b.po_year,
       b.country,
       b.subsidiary,
       b.currency,
       b.po_lastupdate_date_hour,
       b.po_source_last_update_date,
       b.po_orderid,
       b.po_seller_name,
       b.po_prodname,
       b.po_store_name,
       b.po_storename,
       b.channel,
       b.biz_type,
       b.audience_type,
       b.po_status,
       b.po_internal_status,
       b.po_sku,
       b.po_qty,
       b.po_orderqty,
       b.po_itemdiscount_localcurr,
       b.po_itemdiscount_usd,
       b.po_price_localcurr,
       b.po_price_usd,
       b.po_plataform_datasource,
       b.po_source_insert_date,
       b.po_totalprice_usd,
       b.po_totalprice_local,
       b.po_devicetype,
       b.po_sku_kit,
       b.po_prodname_kit,
       b.is_kit,
       b.country_cd,
       b.biz_type_ebi_hq,
       b.global_channel_ebi_hq,
       b.installment,
       0,
       0,
       0,
       b.client_subsidiary_id,
       b.po_sitecode,
       b.customer_type,
       b.po_mobile_os
  );

END;
$$;

-- CALL OW_LAO.proc_ods_sales_control_tower_table_visuar();
-- ERROR: Severity: ERROR, Message: Relation "a" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ods_sales_control_tower_table_visuar line 85 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4345, Error Code: 4566, 
-- CALL OW_LAO.proc_ods_sales_control_tower_table_visuar();
-- ERROR: Severity: ERROR, Message: Relation "a" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ods_sales_control_tower_table_visuar line 85 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4345, Error Code: 4566, 
