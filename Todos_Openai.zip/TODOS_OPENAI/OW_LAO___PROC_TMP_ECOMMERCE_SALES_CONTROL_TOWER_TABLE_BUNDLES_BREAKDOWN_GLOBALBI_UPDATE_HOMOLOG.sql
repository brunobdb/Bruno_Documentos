CREATE OR REPLACE PROCEDURE OW_LAO.proc_tmp_ecommerce_sales_control_tower_table_bundles_breakdown_globalbi_update_homolog()
LANGUAGE PLvSQL AS $$
BEGIN
       PERFORM UPDATE ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown a
          SET ebi_orderid             = b.po_id
            , client_devicetype       = b.device_type
            , week                    = b.week
            , ebi_po_date             = b.order_date
            , ebi_product_category    = b.product_category
            , ebi_product_subcategory = b.product_sub_category
            , ebi_product_family      = b.product_family
            , ebi_product_series      = b.product_series
            , ebi_product_name        = b.product_name
            , ebi_status              = b.line_item_status
            , ebi_payment_method      = b.payment_method_name
            , ebi_payment_provider    = b.payment_provider
            , ebi_trade_in_eligible   = CASE WHEN LOWER(b.trade_in_eligible) = LOWER('true') THEN 1 ELSE 0 END
            , ebi_trade_in_order      = CASE WHEN LOWER(b.trade_in_order   ) = LOWER('true') THEN 1 ELSE 0 END
            , ebi_eip_eligible        = CASE WHEN LOWER(b.eip_eligible     ) = LOWER('true') THEN 1 ELSE 0 END
            , ebi_eip_order           = CASE WHEN LOWER(b.eip_order        ) = LOWER('true') THEN 1 ELSE 0 END
            , ebi_eup_eligible        = CASE WHEN LOWER(b.eup_eligible     ) = LOWER('true') THEN 1 ELSE 0 END
            , ebi_eup_order           = CASE WHEN LOWER(b.eup_order        ) = LOWER('true') THEN 1 ELSE 0 END
            , ebi_scplus_eligible     = CASE WHEN LOWER(b.scplus__eligible ) = LOWER('true') THEN 1 ELSE 0 END
            , ebi_scplus_order        = CASE WHEN LOWER(b.scplus_order     ) = LOWER('true') THEN 1 ELSE 0 END
            , ebi_tariff_eligible     = CASE WHEN LOWER(b.tariff_eligible  ) = LOWER('true') THEN 1 ELSE 0 END
            , ebi_tariff_order        = CASE WHEN LOWER(b.tariff_order     ) = LOWER('true') THEN 1 ELSE 0 END
            , ebi_grossrevenue        = b.transaction_gross_revenue
            , ebi_netrevenue          = b.transaction_net_revenue
            , ebi_grossorder          = b.gross_orders
            , ebi_netorder            = b.net_orders
            , ebi_netqty              = b.net_quantity
            , ebi_grossqty            = b.gross_quantity
            , ebi_cancelamt           = b.cancelled_amount
            , ebi_cancelqty           = b.cancelled_quantity
            , ebi_returnedamt         = b.returned_amount
            , ebi_returned_qty        = b.returned_quantity
            , ebi_sku                 = b.sku
            , ebi_channel             = b.channel
            , ebi_biz_type            = b.biz_type
            , ebi_last_update_date    = b.load_date
            , updated_datetime        = CURRENT_TIMESTAMP
         FROM ow_lao.ods_global_bi_sales b
        WHERE b.po_id   = a.po_orderid
          AND b.sku     = a.po_sku
          AND b.country = a.country
          AND (a.ebi_last_update_date < b.load_date OR a.ebi_last_update_date IS NULL);
END;
$$;

CALL OW_LAO.proc_tmp_ecommerce_sales_control_tower_table_bundles_breakdown_globalbi_update_homolog();
-- proc_tmp_ecommerce_sales_control_tower_table_bundles_breakdown_globalbi_update_homolog
-- --------------------------------------------------------------------------------------
-- 0

