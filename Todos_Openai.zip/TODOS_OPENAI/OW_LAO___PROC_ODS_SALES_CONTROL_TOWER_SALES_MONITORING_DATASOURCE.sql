-- CREATE OR REPLACE PROCEDURE ow_lao.proc_ods_sales_control_tower_sales_monitoring_datasource()
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--     
--     PERFORM CREATE LOCAL TEMP TABLE temp_ecommerce_orders ON COMMIT PRESERVE ROWS AS (
--         SELECT 
--             MAX(COALESCE(t.po_source_last_update_date, t.po_source_insert_date)) AS last_data,
--             'ods_sales_control_tower_table' AS origin,
--             CASE 
--                 WHEN t.subsidiary LIKE 'SELA%' THEN 'SELA' 
--                 ELSE t.subsidiary 
--             END AS subsidiary,
--             CASE 
--                 WHEN COALESCE(t.po_source_last_update_date, t.po_source_insert_date) >= TIMESTAMPADD(SECOND, -7200, CURRENT_TIMESTAMP) THEN 'OK'
--                 WHEN t.subsidiary LIKE 'SELA%'
--                      AND CAST(t.po_source_last_update_date AS DATE) >= TIMESTAMPADD(DAY, -1, CURRENT_DATE) THEN 'OK'
--                 ELSE 'NOT OK'
--             END AS status,
--             t.country
--         FROM ow_lao.ods_sales_control_tower_table t
--         JOIN (
--             SELECT 
--                 subsidiary, 
--                 country,
--                 MAX(po_source_last_update_date) AS po_source_last_update_date
--             FROM ow_lao.ods_sales_control_tower_table
--             WHERE CAST(po_source_last_update_date AS DATE) BETWEEN TIMESTAMPADD(DAY, -10, CURRENT_DATE) AND CURRENT_DATE
--               AND country <> 'Uruguay'
--             GROUP BY subsidiary, country
--         ) m
--           ON m.subsidiary = t.subsidiary
--          AND m.country = t.country
--          AND m.po_source_last_update_date = t.po_source_last_update_date
--         WHERE t.po_plataform_datasource NOT IN ('ow_lao.ods_global_bi_sales', 'u_prj_ecom_synapcom.ft_ecom_order')
--         GROUP BY 
--             CASE 
--                 WHEN t.subsidiary LIKE 'SELA%' THEN 'SELA' 
--                 ELSE t.subsidiary 
--             END,
--             t.country,
--             CASE 
--                 WHEN COALESCE(t.po_source_last_update_date, t.po_source_insert_date) >= TIMESTAMPADD(SECOND, -7200, CURRENT_TIMESTAMP) THEN 'OK'
--                 WHEN t.subsidiary LIKE 'SELA%'
--                      AND CAST(t.po_source_last_update_date AS DATE) >= TIMESTAMPADD(DAY, -1, CURRENT_DATE) THEN 'OK'
--                 ELSE 'NOT OK'
--             END
--     ); 
-- 
--     PERFORM CREATE LOCAL TEMP TABLE temp_complementary_data ON COMMIT PRESERVE ROWS AS (
--         SELECT 
--             MAX(nerp_last_update_date) AS sales_order_tracking_timestamp,
--             CASE
--                 WHEN TIMESTAMPDIFF(SECOND, MAX(nerp_last_update_date), CURRENT_TIMESTAMP) / 60 <= 60 THEN 'OK'
--                 ELSE 'NOT OK'
--             END AS sales_order_tracking_status,
--             MAX(nerp_outbound_last_update_date) AS outbound_timestamp,
--             CASE
--                 WHEN TIMESTAMPDIFF(SECOND, MAX(nerp_outbound_last_update_date), CURRENT_TIMESTAMP) / 60 <= 60 THEN 'OK'
--                 ELSE 'NOT OK'
--             END AS outbound_status,
--             MAX(ebi_last_update_date) AS global_bi_timestamp,
--             CASE
--                 WHEN TIMESTAMPDIFF(SECOND, MAX(ebi_last_update_date), CURRENT_TIMESTAMP) / 60 <= 1440 THEN 'OK'
--                 ELSE 'NOT OK'
--             END AS global_bi_status,
--             MAX(po_source_payment_last_update_date) AS payment_timestamp,
--             CASE
--                 WHEN TIMESTAMPDIFF(SECOND, MAX(po_source_payment_last_update_date), CURRENT_TIMESTAMP) / 60 <= 60 THEN 'OK'
--                 ELSE 'NOT OK'
--             END AS payment_status,
--             NULL::VARCHAR AS country,
--             NULL::VARCHAR AS subsidiary
--         FROM ow_lao.ods_sales_control_tower_table
--     );   
-- 
--     PERFORM CREATE LOCAL TEMP TABLE temp_sales_control_tower_sales_check_ds ON COMMIT PRESERVE ROWS AS (
--         SELECT 
--             CASE element_number 
--                 WHEN 1 THEN 'sales order tracking'
--                 WHEN 2 THEN 'outbound'
--                 WHEN 3 THEN 'global bi files'
--                 WHEN 4 THEN 'payments'
--             END AS origin,
--             CASE element_number 
--                 WHEN 1 THEN sales_order_tracking_status
--                 WHEN 2 THEN outbound_status
--                 WHEN 3 THEN global_bi_status
--                 WHEN 4 THEN payment_status
--             END AS status,
--             CASE element_number 
--                 WHEN 1 THEN sales_order_tracking_timestamp
--                 WHEN 2 THEN outbound_timestamp
--                 WHEN 3 THEN global_bi_timestamp
--                 WHEN 4 THEN payment_timestamp
--             END AS last_data,
--             country,
--             subsidiary
--         FROM temp_complementary_data
--         CROSS JOIN (
--             SELECT 1 AS element_number
--             UNION ALL SELECT 2
--             UNION ALL SELECT 3
--             UNION ALL SELECT 4
--         ) AS seq
--         UNION ALL
--         SELECT 
--             origin,
--             status,
--             last_data,
--             country,
--             subsidiary
--         FROM temp_ecommerce_orders
--     );
--     
--     PERFORM DELETE FROM temp_sales_control_tower_sales_check_ds WHERE origin = 'sales order tracking';
--     
--     SELECT *
--       FROM (
--                 SELECT 3 AS monitoring_execution_result_status,
--                        LISTAGG(CONCAT(origin, COALESCE('(' || country || ')', ''))) USING PARAMETERS delimiter = '/' AS value
--                   FROM temp_sales_control_tower_sales_check_ds a
--                  WHERE a.status = 'NOT OK'
--                  
--                  UNION
--                  
--                 SELECT 2 AS monitoring_execution_result_status,
--                        'OK' AS value
--                   FROM temp_sales_control_tower_sales_check_ds a
--                  WHERE NOT EXISTS(
--                                      SELECT 1
--                                        FROM temp_sales_control_tower_sales_check_ds aa
--                                       WHERE aa.status = 'NOT OK'
--                        )
--        ) a
--      WHERE value IS NOT NULL;
--      
-- END
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 134.29 of source string: syntax error, unexpected ;, expecting INTO, Sqlstate: 42601, Position: 5830, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
CREATE OR REPLACE PROCEDURE ow_lao.proc_ods_sales_control_tower_sales_monitoring_datasource()
LANGUAGE PLvSQL AS $$
BEGIN
    
    PERFORM CREATE LOCAL TEMP TABLE temp_ecommerce_orders ON COMMIT PRESERVE ROWS AS
    SELECT 
        MAX(COALESCE(t.po_source_last_update_date, t.po_source_insert_date)) AS last_data,
        'ods_sales_control_tower_table' AS origin,
        CASE 
            WHEN t.subsidiary LIKE 'SELA%' THEN 'SELA' 
            ELSE t.subsidiary 
        END AS subsidiary,
        CASE 
            WHEN COALESCE(t.po_source_last_update_date, t.po_source_insert_date) >= TIMESTAMPADD(SECOND, -7200, CURRENT_TIMESTAMP) THEN 'OK'
            WHEN t.subsidiary LIKE 'SELA%'
                 AND CAST(t.po_source_last_update_date AS DATE) >= TIMESTAMPADD(DAY, -1, CURRENT_DATE) THEN 'OK'
            ELSE 'NOT OK'
        END AS status,
        t.country
    FROM ow_lao.ods_sales_control_tower_table t
    WHERE t.po_plataform_datasource NOT IN ('ow_lao.ods_global_bi_sales', 'u_prj_ecom_synapcom.ft_ecom_order')
      AND (t.subsidiary, t.country, t.po_source_last_update_date) IN (
            SELECT subsidiary, country, MAX(po_source_last_update_date)
            FROM ow_lao.ods_sales_control_tower_table
            WHERE CAST(po_source_last_update_date AS DATE) BETWEEN TIMESTAMPADD(DAY, -10, CURRENT_DATE) AND CURRENT_DATE
              AND country <> 'Uruguay'
            GROUP BY subsidiary, country
      )
    GROUP BY 
        CASE 
            WHEN t.subsidiary LIKE 'SELA%' THEN 'SELA' 
            ELSE t.subsidiary 
        END,
        t.country,
        CASE 
            WHEN COALESCE(t.po_source_last_update_date, t.po_source_insert_date) >= TIMESTAMPADD(SECOND, -7200, CURRENT_TIMESTAMP) THEN 'OK'
            WHEN t.subsidiary LIKE 'SELA%'
                 AND CAST(t.po_source_last_update_date AS DATE) >= TIMESTAMPADD(DAY, -1, CURRENT_DATE) THEN 'OK'
            ELSE 'NOT OK'
        END
    ; 

    PERFORM CREATE LOCAL TEMP TABLE temp_complementary_data ON COMMIT PRESERVE ROWS AS
    SELECT 
        MAX(nerp_last_update_date) AS sales_order_tracking_timestamp,
        CASE
            WHEN DATEDIFF('second', MAX(nerp_last_update_date), CURRENT_TIMESTAMP) / 60 <= 60 THEN 'OK'
            ELSE 'NOT OK'
        END AS sales_order_tracking_status,
        MAX(nerp_outbound_last_update_date) AS outbound_timestamp,
        CASE
            WHEN DATEDIFF('second', MAX(nerp_outbound_last_update_date), CURRENT_TIMESTAMP) / 60 <= 60 THEN 'OK'
            ELSE 'NOT OK'
        END AS outbound_status,
        MAX(ebi_last_update_date) AS global_bi_timestamp,
        CASE
            WHEN DATEDIFF('second', MAX(ebi_last_update_date), CURRENT_TIMESTAMP) / 60 <= 1440 THEN 'OK'
            ELSE 'NOT OK'
        END AS global_bi_status,
        MAX(po_source_payment_last_update_date) AS payment_timestamp,
        CASE
            WHEN DATEDIFF('second', MAX(po_source_payment_last_update_date), CURRENT_TIMESTAMP) / 60 <= 60 THEN 'OK'
            ELSE 'NOT OK'
        END AS payment_status,
        NULL::VARCHAR AS country,
        NULL::VARCHAR AS subsidiary
    FROM ow_lao.ods_sales_control_tower_table
    ;   

    PERFORM CREATE LOCAL TEMP TABLE temp_sales_control_tower_sales_check_ds ON COMMIT PRESERVE ROWS AS
    SELECT 
        CASE seq.element_number 
            WHEN 1 THEN 'sales order tracking'
            WHEN 2 THEN 'outbound'
            WHEN 3 THEN 'global bi files'
            WHEN 4 THEN 'payments'
        END AS origin,
        CASE seq.element_number 
            WHEN 1 THEN c.sales_order_tracking_status
            WHEN 2 THEN c.outbound_status
            WHEN 3 THEN c.global_bi_status
            WHEN 4 THEN c.payment_status
        END AS status,
        CASE seq.element_number 
            WHEN 1 THEN c.sales_order_tracking_timestamp
            WHEN 2 THEN c.outbound_timestamp
            WHEN 3 THEN c.global_bi_timestamp
            WHEN 4 THEN c.payment_timestamp
        END AS last_data,
        c.country,
        c.subsidiary
    FROM temp_complementary_data c
    CROSS JOIN (
        SELECT 1 AS element_number
        UNION ALL SELECT 2
        UNION ALL SELECT 3
        UNION ALL SELECT 4
    ) AS seq
    UNION ALL
    SELECT 
        origin,
        status,
        last_data,
        country,
        subsidiary
    FROM temp_ecommerce_orders
    ;
    
    PERFORM DELETE FROM temp_sales_control_tower_sales_check_ds WHERE origin = 'sales order tracking';

    PERFORM CREATE LOCAL TEMP TABLE temp_result_monitoring ON COMMIT PRESERVE ROWS AS
    SELECT *
      FROM (
                SELECT 3 AS monitoring_execution_result_status,
                       LISTAGG(origin || COALESCE('(' || country || ')', '') USING PARAMETERS delimiter = '/') AS value
                  FROM temp_sales_control_tower_sales_check_ds a
                 WHERE a.status = 'NOT OK'
                 
                 UNION ALL
                 
                SELECT 2 AS monitoring_execution_result_status,
                       'OK' AS value
                  FROM temp_sales_control_tower_sales_check_ds a
                 WHERE NOT EXISTS(
                                     SELECT 1
                                       FROM temp_sales_control_tower_sales_check_ds aa
                                      WHERE aa.status = 'NOT OK'
                       )
       ) a
     WHERE value IS NOT NULL
    ;
     
END
$$;

CALL ow_lao.proc_ods_sales_control_tower_sales_monitoring_datasource();
-- proc_ods_sales_control_tower_sales_monitoring_datasource
-- --------------------------------------------------------
-- 0

