CREATE OR REPLACE PROCEDURE U_PRJ_ECOM.PROC_RAW_VTEX_SEASA_TRADEIN_FEED_HOMOLOG()
LANGUAGE PLvSQL AS $$
BEGIN

  -- Create temporary staging table
  PERFORM CREATE LOCAL TEMPORARY TABLE TMP_VTEX_SEASA_TRADEIN_FEED ON COMMIT PRESERVE ROWS AS
  SELECT 
     a.ORDER_ID,
     a.CREATION_DATE,
     a.HOSTNAME,
     a.UNIQUE_ID AS UNIQUEID,
     a.SKU_ID AS SKUID,
     a.PRODUCT_ID AS PRODUCTID,
     a.EAN,
     a.REF_ID AS REFID,
     a.DEVICE_BRAND AS BRAND_DEVICE,
     a.DEVICE_MODEL AS MODEL_DEVICE,
     CAST(a.DEVICE_VALUE AS NUMERIC)/100 AS TRADE_IN_DISCOUNT_DEVICE,
     CURRENT_TIMESTAMP AS INSERT_DATE, 
     CURRENT_TIMESTAMP AS LAST_UPDATE_DATE
  FROM (
    -- Device 1
    SELECT
        it.order_id,
        so.CREATION_TIMESTAMP AS CREATION_DATE,
        so.HOSTNAME,
        it.UNIQUE_ID,
        it.SKU_ID,
        it.REF_ID AS REF_ID,
        it.PRODUCT_ID,
        it.EAN,
        MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.bonoTotal') AS bonoTotal,
        MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.device1.type') AS device_type,
        MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.device1.brand') AS device_brand,
        MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.device1.value') AS device_value,
        MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.device1.model') AS device_model,
        CASE WHEN MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.device1') IS NULL THEN 0 ELSE 1 END AS tradein
    FROM U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER_ITEM it
    LEFT JOIN U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER so ON it.ORDER_ID = so.ORDER_ID
    WHERE it.attachments IS NOT NULL

    UNION ALL

    -- Device 2
    SELECT
        it.order_id,
        so.CREATION_TIMESTAMP AS CREATION_DATE,
        so.HOSTNAME,
        it.UNIQUE_ID,
        it.SKU_ID,
        it.REF_ID AS REF_ID,
        it.PRODUCT_ID,
        it.EAN,
        MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.bonoTotal') AS bonoTotal,
        MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.device2.type') AS device_type,
        MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.device2.brand') AS device_brand,
        MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.device2.value') AS device_value,
        MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.device2.model') AS device_model,
        CASE WHEN MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.device2') IS NULL THEN 0 ELSE 1 END AS tradein
    FROM U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER_ITEM it
    LEFT JOIN U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER so ON it.ORDER_ID = so.ORDER_ID
    WHERE it.attachments IS NOT NULL
  ) a
  WHERE a.TRADEIN = 1
    AND a.CREATION_DATE IS NOT NULL
    AND NOT EXISTS (
      SELECT 1
      FROM U_PRJ_ECOM.RAW_VTEX_SEASA_TRADEIN_FEED aa
      WHERE aa.ORDER_ID = a.ORDER_ID
        AND aa.REFID    = a.REF_ID
    );

  -- Insert into raw, avoiding duplicates again
  PERFORM INSERT INTO U_PRJ_ECOM.RAW_VTEX_SEASA_TRADEIN_FEED (
    SELECT DISTINCT 
      ORDER_ID,
      CREATION_DATE,
      HOSTNAME,
      UNIQUEID,
      SKUID,
      PRODUCTID,
      EAN,
      REFID,
      BRAND_DEVICE,
      MODEL_DEVICE,
      TRADE_IN_DISCOUNT_DEVICE,
      INSERT_DATE,
      LAST_UPDATE_DATE
    FROM TMP_VTEX_SEASA_TRADEIN_FEED tmp
    WHERE tmp.ORDER_ID IS NOT NULL
      AND NOT EXISTS (
        SELECT 1
        FROM U_PRJ_ECOM.RAW_VTEX_SEASA_TRADEIN_FEED aa
        WHERE aa.ORDER_ID = tmp.ORDER_ID
          AND aa.REFID    = tmp.REFID
      )
  );

  -- Drop temp table
  PERFORM DROP TABLE IF EXISTS TMP_VTEX_SEASA_TRADEIN_FEED;

END;
$$;

-- CALL U_PRJ_ECOM.PROC_RAW_VTEX_SEASA_TRADEIN_FEED_HOMOLOG();
-- ERROR: Severity: ERROR, Message: Column "BRAND_DEVICE" is of type varchar but expression is of type long varchar, Sqlstate: 42804, Hint: You will need to rewrite or cast the expression, Where: PL/vSQL procedure PROC_RAW_VTEX_SEASA_TRADEIN_FEED_HOMOLOG line 97 at static SQL, Routine: updateTargetListEntry, File: parse_target.c, Line: 853, Error Code: 2631, 
-- CALL U_PRJ_ECOM.PROC_RAW_VTEX_SEASA_TRADEIN_FEED_HOMOLOG();
-- ERROR: Severity: ERROR, Message: Column "BRAND_DEVICE" is of type varchar but expression is of type long varchar, Sqlstate: 42804, Hint: You will need to rewrite or cast the expression, Where: PL/vSQL procedure PROC_RAW_VTEX_SEASA_TRADEIN_FEED_HOMOLOG line 97 at static SQL, Routine: updateTargetListEntry, File: parse_target.c, Line: 853, Error Code: 2631, 
CREATE OR REPLACE PROCEDURE U_PRJ_ECOM.PROC_RAW_VTEX_SEASA_TRADEIN_FEED_HOMOLOG()
LANGUAGE PLvSQL AS $$
BEGIN

  -- Create temporary staging table
  PERFORM CREATE LOCAL TEMPORARY TABLE TMP_VTEX_SEASA_TRADEIN_FEED ON COMMIT PRESERVE ROWS AS
  SELECT 
     a.ORDER_ID,
     a.CREATION_DATE,
     a.HOSTNAME,
     a.UNIQUE_ID AS UNIQUEID,
     a.SKU_ID AS SKUID,
     a.PRODUCT_ID AS PRODUCTID,
     a.EAN,
     a.REF_ID AS REFID,
     a.DEVICE_BRAND AS BRAND_DEVICE,
     a.DEVICE_MODEL AS MODEL_DEVICE,
     (CAST(a.DEVICE_VALUE AS NUMERIC))/100 AS TRADE_IN_DISCOUNT_DEVICE,
     CURRENT_TIMESTAMP AS INSERT_DATE, 
     CURRENT_TIMESTAMP AS LAST_UPDATE_DATE
  FROM (
    -- Device 1
    SELECT
        it.order_id,
        so.CREATION_TIMESTAMP AS CREATION_DATE,
        so.HOSTNAME,
        it.UNIQUE_ID,
        it.SKU_ID,
        it.REF_ID AS REF_ID,
        it.PRODUCT_ID,
        it.EAN,
        MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.bonoTotal') AS bonoTotal,
        MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.device1.type') AS device_type,
        MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.device1.brand') AS device_brand,
        MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.device1.value') AS device_value,
        MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.device1.model') AS device_model,
        CASE WHEN MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.device1') IS NULL THEN 0 ELSE 1 END AS tradein
    FROM U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER_ITEM it
    LEFT JOIN U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER so ON it.ORDER_ID = so.ORDER_ID
    WHERE it.attachments IS NOT NULL

    UNION ALL

    -- Device 2
    SELECT
        it.order_id,
        so.CREATION_TIMESTAMP AS CREATION_DATE,
        so.HOSTNAME,
        it.UNIQUE_ID,
        it.SKU_ID,
        it.REF_ID AS REF_ID,
        it.PRODUCT_ID,
        it.EAN,
        MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.bonoTotal') AS bonoTotal,
        MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.device2.type') AS device_type,
        MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.device2.brand') AS device_brand,
        MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.device2.value') AS device_value,
        MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.device2.model') AS device_model,
        CASE WHEN MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.device2') IS NULL THEN 0 ELSE 1 END AS tradein
    FROM U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER_ITEM it
    LEFT JOIN U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER so ON it.ORDER_ID = so.ORDER_ID
    WHERE it.attachments IS NOT NULL
  ) a
  WHERE a.TRADEIN = 1
    AND a.CREATION_DATE IS NOT NULL
    AND NOT EXISTS (
      SELECT 1
      FROM U_PRJ_ECOM.RAW_VTEX_SEASA_TRADEIN_FEED aa
      WHERE aa.ORDER_ID = a.ORDER_ID
        AND aa.REFID    = a.REF_ID
    );

  -- Insert into raw, avoiding duplicates again, cast long varchar to varchar
  PERFORM INSERT INTO U_PRJ_ECOM.RAW_VTEX_SEASA_TRADEIN_FEED (
    SELECT DISTINCT 
      ORDER_ID,
      CREATION_DATE,
      HOSTNAME,
      UNIQUEID,
      SKUID,
      PRODUCTID,
      EAN,
      REFID,
      SUBSTR(BRAND_DEVICE,1,65000) AS BRAND_DEVICE,
      SUBSTR(MODEL_DEVICE,1,65000) AS MODEL_DEVICE,
      TRADE_IN_DISCOUNT_DEVICE,
      INSERT_DATE,
      LAST_UPDATE_DATE
    FROM TMP_VTEX_SEASA_TRADEIN_FEED tmp
    WHERE tmp.ORDER_ID IS NOT NULL
      AND NOT EXISTS (
        SELECT 1
        FROM U_PRJ_ECOM.RAW_VTEX_SEASA_TRADEIN_FEED aa
        WHERE aa.ORDER_ID = tmp.ORDER_ID
          AND aa.REFID    = tmp.REFID
      )
  );

  -- Drop temp table
  PERFORM DROP TABLE IF EXISTS TMP_VTEX_SEASA_TRADEIN_FEED;

END;
$$;

-- CALL U_PRJ_ECOM.PROC_RAW_VTEX_SEASA_TRADEIN_FEED_HOMOLOG();
-- ERROR: Severity: ERROR, Message: Column "BRAND_DEVICE" is of type varchar but expression is of type long varchar, Sqlstate: 42804, Hint: You will need to rewrite or cast the expression, Where: PL/vSQL procedure PROC_RAW_VTEX_SEASA_TRADEIN_FEED_HOMOLOG line 97 at static SQL, Routine: updateTargetListEntry, File: parse_target.c, Line: 853, Error Code: 2631, 
-- CALL U_PRJ_ECOM.PROC_RAW_VTEX_SEASA_TRADEIN_FEED_HOMOLOG();
-- ERROR: Severity: ERROR, Message: Column "BRAND_DEVICE" is of type varchar but expression is of type long varchar, Sqlstate: 42804, Hint: You will need to rewrite or cast the expression, Where: PL/vSQL procedure PROC_RAW_VTEX_SEASA_TRADEIN_FEED_HOMOLOG line 97 at static SQL, Routine: updateTargetListEntry, File: parse_target.c, Line: 853, Error Code: 2631, 
CREATE OR REPLACE PROCEDURE U_PRJ_ECOM.PROC_RAW_VTEX_SEASA_TRADEIN_FEED_HOMOLOG()
LANGUAGE PLvSQL AS $$
BEGIN

  -- Create temporary staging table
  PERFORM CREATE LOCAL TEMPORARY TABLE TMP_VTEX_SEASA_TRADEIN_FEED ON COMMIT PRESERVE ROWS AS
  SELECT 
     a.ORDER_ID,
     a.CREATION_DATE,
     a.HOSTNAME,
     a.UNIQUE_ID AS UNIQUEID,
     a.SKU_ID AS SKUID,
     a.PRODUCT_ID AS PRODUCTID,
     a.EAN,
     a.REF_ID AS REFID,
     a.DEVICE_BRAND AS BRAND_DEVICE,
     a.DEVICE_MODEL AS MODEL_DEVICE,
     (CAST(a.DEVICE_VALUE AS NUMERIC))/100 AS TRADE_IN_DISCOUNT_DEVICE,
     CURRENT_TIMESTAMP AS INSERT_DATE, 
     CURRENT_TIMESTAMP AS LAST_UPDATE_DATE
  FROM (
    -- Device 1
    SELECT
        it.order_id,
        so.CREATION_TIMESTAMP AS CREATION_DATE,
        so.HOSTNAME,
        it.UNIQUE_ID,
        it.SKU_ID,
        it.REF_ID AS REF_ID,
        it.PRODUCT_ID,
        it.EAN,
        MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.bonoTotal') AS bonoTotal,
        MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.device1.type') AS device_type,
        MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.device1.brand') AS device_brand,
        MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.device1.value') AS device_value,
        MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.device1.model') AS device_model,
        CASE WHEN MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.device1') IS NULL THEN 0 ELSE 1 END AS tradein
    FROM U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER_ITEM it
    LEFT JOIN U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER so ON it.ORDER_ID = so.ORDER_ID
    WHERE it.attachments IS NOT NULL

    UNION ALL

    -- Device 2
    SELECT
        it.order_id,
        so.CREATION_TIMESTAMP AS CREATION_DATE,
        so.HOSTNAME,
        it.UNIQUE_ID,
        it.SKU_ID,
        it.REF_ID AS REF_ID,
        it.PRODUCT_ID,
        it.EAN,
        MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.bonoTotal') AS bonoTotal,
        MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.device2.type') AS device_type,
        MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.device2.brand') AS device_brand,
        MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.device2.value') AS device_value,
        MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.device2.model') AS device_model,
        CASE WHEN MAPLOOKUP(MAPJSONEXTRACTOR(
            REPLACE(REPLACE(REPLACE(it.attachments, '\\', ''), '"{', '{'), '}"', '}')
        ), 'content.TradeIn.device2') IS NULL THEN 0 ELSE 1 END AS tradein
    FROM U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER_ITEM it
    LEFT JOIN U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER so ON it.ORDER_ID = so.ORDER_ID
    WHERE it.attachments IS NOT NULL
  ) a
  WHERE a.TRADEIN = 1
    AND a.CREATION_DATE IS NOT NULL
    AND NOT EXISTS (
      SELECT 1
      FROM U_PRJ_ECOM.RAW_VTEX_SEASA_TRADEIN_FEED aa
      WHERE aa.ORDER_ID = a.ORDER_ID
        AND aa.REFID    = a.REF_ID
    );

  -- Insert into raw, avoiding duplicates again, cast long varchar to varchar
  PERFORM INSERT INTO U_PRJ_ECOM.RAW_VTEX_SEASA_TRADEIN_FEED (
    SELECT DISTINCT 
      ORDER_ID,
      CREATION_DATE,
      HOSTNAME,
      UNIQUEID,
      SKUID,
      PRODUCTID,
      EAN,
      REFID,
      CAST(SUBSTR(BRAND_DEVICE,1,65000) AS VARCHAR(65000)) AS BRAND_DEVICE,
      CAST(SUBSTR(MODEL_DEVICE,1,65000) AS VARCHAR(65000)) AS MODEL_DEVICE,
      TRADE_IN_DISCOUNT_DEVICE,
      INSERT_DATE,
      LAST_UPDATE_DATE
    FROM TMP_VTEX_SEASA_TRADEIN_FEED tmp
    WHERE tmp.ORDER_ID IS NOT NULL
      AND NOT EXISTS (
        SELECT 1
        FROM U_PRJ_ECOM.RAW_VTEX_SEASA_TRADEIN_FEED aa
        WHERE aa.ORDER_ID = tmp.ORDER_ID
          AND aa.REFID    = tmp.REFID
      )
  );

  -- Drop temp table
  PERFORM DROP TABLE IF EXISTS TMP_VTEX_SEASA_TRADEIN_FEED;

END;
$$;

CALL U_PRJ_ECOM.PROC_RAW_VTEX_SEASA_TRADEIN_FEED_HOMOLOG();
-- PROC_RAW_VTEX_SEASA_TRADEIN_FEED_HOMOLOG
-- ----------------------------------------
-- 0

