-- CREATE OR REPLACE PROCEDURE OW_LAO.PROC_SALES_CAMPAIGN_PBI_V3(
-- 	IN CONSULTA VARCHAR(40),
-- 	IN DT_START TIMESTAMP
-- ) LANGUAGE PLvSQL AS $$
-- BEGIN
-- 	IF CONSULTA = 'CAMPAIGN_SALES' THEN	
-- 	BEGIN
-- 		PERFORM TRUNCATE TABLE OW_LAO.TMP_CAMPAIGN_CUT;
-- 		PERFORM INSERT INTO OW_LAO.TMP_CAMPAIGN_CUT 
-- 		SELECT 
-- 			A.CAMPAIGN_TAG,
-- 			A.SUBSIDIARY,
-- 			MIN(A.CAMPAIGN_DAY) 	AS CAMPAIGN_TAG_START, 
-- 			MAX(A.CAMPAIGN_DAY) 	AS CAMPAIGN_TAG_END
-- 		FROM 
-- 			OW_LAO.ODS_SALES_CAMPAIGN  A
-- 		WHERE 
-- 			(A.PO_STATUS = 'Approved' OR (A.SUBSIDIARY = 'SELA' AND A.PO_STATUS = 'Pending')) 
-- 			AND A.PREVIOUS_YEAR = FALSE  
-- 			AND CAST(A.PO_DATE AS DATE) >= CAST(DT_START AS DATE)
-- 		GROUP BY 
-- 			A.CAMPAIGN_TAG,
-- 			A.SUBSIDIARY;
-- 
-- 		SELECT 
-- 			*
-- 		FROM 
-- 			OW_LAO.ODS_SALES_CAMPAIGN  A
-- 		WHERE 
-- 			(A.PO_STATUS = 'Approved' OR (A.SUBSIDIARY = 'SELA' AND A.PO_STATUS = 'Pending')) 
-- 			AND A.PREVIOUS_YEAR = TRUE 
-- 			AND EXISTS (
-- 				SELECT 
-- 					1 
-- 				FROM 
-- 					OW_LAO.TMP_CAMPAIGN_CUT B
-- 				WHERE 
-- 					A.CAMPAIGN_TAG 		= B.CAMPAIGN_TAG 
-- 					AND A.SUBSIDIARY	= B.SUBSIDIARY 
-- 					AND A.CAMPAIGN_DAY BETWEEN B.CAMPAIGN_TAG_START AND B.CAMPAIGN_TAG_END
-- 			)
-- 		UNION ALL
-- 		SELECT 
-- 			* 
-- 		FROM 
-- 		  	OW_LAO.ODS_SALES_CAMPAIGN  
-- 		WHERE  
-- 		  	(PO_STATUS = 'Approved' OR (SUBSIDIARY = 'SELA' AND PO_STATUS = 'Pending')) 
-- 		  	AND PREVIOUS_YEAR = FALSE  
-- 		  	AND CAST(PO_DATE AS DATE) >= CAST(DT_START AS DATE);				
-- 	END;
-- 	ELSEIF CONSULTA = 'DIM_CAMPAIGN_NAME_REGISTER' THEN	
-- 	BEGIN
-- 		WITH campaign_cte AS (
-- 		    SELECT
-- 		        CAMPAIGN_TAG,
-- 		        SUBSIDIARY AS Samsung_Sub,
-- 		        CASE
-- 		            WHEN BIZ_TYPE IS NULL OR BIZ_TYPE = '' THEN 'all'
-- 		            ELSE UPPER(BIZ_TYPE)
-- 		        END AS business,
-- 		        CASE
-- 		            WHEN PO_DEVICETYPE IS NULL OR PO_DEVICETYPE = '' THEN 'all'
-- 		            ELSE LOWER(PO_DEVICETYPE)
-- 		        END AS device,
-- 		        division,
-- 		        INITIAL_DATE,
-- 		        FINAL_DATE,
-- 		        product,
-- 		        product_group,
-- 		        po_sku,
-- 		        id_campaign,
-- 		        audience_type
-- 		    FROM
-- 		        OW_LAO.DIM_CAMPAIGN_NAME AS campaign
-- 		),
-- 		expanded_campaign AS (
-- 		    SELECT
-- 		        CAMPAIGN_TAG,
-- 		        Samsung_Sub,
-- 		        'SMB' AS business,
-- 		        'app' AS device,
-- 		        division,
-- 		        INITIAL_DATE,
-- 		        FINAL_DATE,
-- 		        product,
-- 		        product_group,
-- 		        po_sku,
-- 		        id_campaign,
-- 		        audience_type
-- 		    FROM campaign_cte
-- 		    WHERE business = 'all' AND device = 'all'
-- 		   
-- 		    UNION ALL
-- 		   
-- 		    SELECT
-- 		        CAMPAIGN_TAG,
-- 		        Samsung_Sub,
-- 		        'SMB' AS business,
-- 		        'web' AS device,
-- 		        division,
-- 		        INITIAL_DATE,
-- 		        FINAL_DATE,
-- 		        product,
-- 		        product_group,
-- 		        po_sku,
-- 		        id_campaign,
-- 		        audience_type
-- 		    FROM campaign_cte
-- 		    WHERE business = 'all' AND device = 'all'
-- 		
-- 		    UNION ALL
-- 		
-- 		    SELECT
-- 		        CAMPAIGN_TAG,
-- 		        Samsung_Sub,
-- 		        'B2C' AS business,
-- 		        'app' AS device,
-- 		        division,
-- 		        INITIAL_DATE,
-- 		        FINAL_DATE,
-- 		        product,
-- 		        product_group,
-- 		        po_sku,
-- 		        id_campaign,
-- 		        audience_type
-- 		    FROM campaign_cte
-- 		    WHERE business = 'all' AND device = 'all'
-- 		   
-- 		    UNION ALL
-- 		   
-- 		    SELECT
-- 		        CAMPAIGN_TAG,
-- 		        Samsung_Sub,
-- 		        'B2C' AS business,
-- 		        'web' AS device,
-- 		        division,
-- 		        INITIAL_DATE,
-- 		        FINAL_DATE,
-- 		        product,
-- 		        product_group,
-- 		        po_sku,
-- 		        id_campaign,
-- 		        audience_type
-- 		    FROM campaign_cte
-- 		    WHERE business = 'all' AND device = 'all'
-- 		   
-- 		    UNION ALL
-- 		
-- 		    SELECT
-- 		        CAMPAIGN_TAG,
-- 		        Samsung_Sub,
-- 		        'EPP' AS business,
-- 		        'app' AS device,
-- 		        division,
-- 		        INITIAL_DATE,
-- 		        FINAL_DATE,
-- 		        product,
-- 		        product_group,
-- 		        po_sku,
-- 		        id_campaign,
-- 		        audience_type
-- 		    FROM campaign_cte
-- 		    WHERE business = 'all' AND device = 'all'
-- 		   
-- 		    UNION ALL
-- 		   
-- 		    SELECT
-- 		        CAMPAIGN_TAG,
-- 		        Samsung_Sub,
-- 		        'EPP' AS business,
-- 		        'web' AS device,
-- 		        division,
-- 		        INITIAL_DATE,
-- 		        FINAL_DATE,
-- 		        product,
-- 		        product_group,
-- 		        po_sku,
-- 		        id_campaign,
-- 		        audience_type
-- 		    FROM campaign_cte
-- 		    WHERE business = 'all' AND device = 'all'
-- 		),
-- 		business_only_expansion AS (
-- 		    SELECT
-- 		        CAMPAIGN_TAG,
-- 		        Samsung_Sub,
-- 		        'SMB' AS business,
-- 		        device,
-- 		        division,
-- 		        INITIAL_DATE,
-- 		        FINAL_DATE,
-- 		        product,
-- 		        product_group,
-- 		        po_sku,
-- 		        id_campaign,
-- 		        audience_type
-- 		    FROM campaign_cte
-- 		    WHERE business = 'all' AND device != 'all'
-- 		
-- 		    UNION ALL
-- 		
-- 		    SELECT
-- 		        CAMPAIGN_TAG,
-- 		        Samsung_Sub,
-- 		        'B2C' AS business,
-- 		        device,
-- 		        division,
-- 		        INITIAL_DATE,
-- 		        FINAL_DATE,
-- 		        product,
-- 		        product_group,
-- 		        po_sku,
-- 		        id_campaign,
-- 		        audience_type
-- 		    FROM campaign_cte
-- 		    WHERE business = 'all' AND device != 'all'
-- 		   
-- 		    UNION ALL
-- 		   
-- 		    SELECT
-- 		        CAMPAIGN_TAG,
-- 		        Samsung_Sub,
-- 		        'EPP' AS business,
-- 		        device,
-- 		        division,
-- 		        INITIAL_DATE,
-- 		        FINAL_DATE,
-- 		        product,
-- 		        product_group,
-- 		        po_sku,
-- 		        id_campaign,
-- 		        audience_type
-- 		    FROM campaign_cte
-- 		    WHERE business = 'all' AND device != 'all'
-- 		),
-- 		device_only_expansion AS (
-- 		    SELECT
-- 		        CAMPAIGN_TAG,
-- 		        Samsung_Sub,
-- 		        business,
-- 		        'app' AS device,
-- 		        division,
-- 		        INITIAL_DATE,
-- 		        FINAL_DATE,
-- 		        product,
-- 		        product_group,
-- 		        po_sku,
-- 		        id_campaign,
-- 		        audience_type
-- 		    FROM campaign_cte
-- 		    WHERE business != 'all' AND device = 'all'
-- 		
-- 		    UNION ALL
-- 		
-- 		    SELECT
-- 		        CAMPAIGN_TAG,
-- 		        Samsung_Sub,
-- 		        business,
-- 		        'web' AS device,
-- 		        division,
-- 		        INITIAL_DATE,
-- 		        FINAL_DATE,
-- 		        product,
-- 		        product_group,
-- 		        po_sku,
-- 		        id_campaign,
-- 		        audience_type
-- 		    FROM campaign_cte
-- 		    WHERE business != 'all' AND device = 'all'
-- 		),
-- 		final_expansion AS (
-- 		    SELECT * FROM campaign_cte WHERE business != 'all' AND device != 'all'
-- 		    UNION ALL
-- 		    SELECT * FROM expanded_campaign
-- 		    UNION ALL
-- 		    SELECT * FROM business_only_expansion
-- 		    UNION ALL
-- 		    SELECT * FROM device_only_expansion
-- 		)
-- 		SELECT
-- 		    fe.*,
-- 		    cal.yyyymmdd AS campaign_date
-- 		FROM final_expansion fe
-- 		JOIN ow_md.dim_calendar cal
-- 		    ON cal.yyyymmdd BETWEEN fe.INITIAL_DATE AND fe.FINAL_DATE;		
-- 	END;
-- 	ELSE
-- 		SELECT 'Procedimento não declaro' AS CONSULTA;		
-- 	END IF;
-- END
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 47.57 of source string: syntax error, unexpected ;, expecting INTO, Sqlstate: 42601, Position: 1375, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
CREATE OR REPLACE PROCEDURE OW_LAO.PROC_SALES_CAMPAIGN_PBI_V3(
	IN CONSULTA VARCHAR(40),
	IN DT_START TIMESTAMP
) LANGUAGE PLvSQL AS $$
BEGIN
	IF CONSULTA = 'CAMPAIGN_SALES' THEN	
	BEGIN
		PERFORM TRUNCATE TABLE OW_LAO.TMP_CAMPAIGN_CUT;
		PERFORM INSERT INTO OW_LAO.TMP_CAMPAIGN_CUT 
		SELECT 
			A.CAMPAIGN_TAG,
			A.SUBSIDIARY,
			MIN(A.CAMPAIGN_DAY) AS CAMPAIGN_TAG_START, 
			MAX(A.CAMPAIGN_DAY) AS CAMPAIGN_TAG_END
		FROM 
			OW_LAO.ODS_SALES_CAMPAIGN A
		WHERE 
			(A.PO_STATUS = 'Approved' OR (A.SUBSIDIARY = 'SELA' AND A.PO_STATUS = 'Pending')) 
			AND A.PREVIOUS_YEAR = TRUEFALSEFALSE  
			AND CAST(A.PO_DATE AS DATE) >= CAST(DT_START AS DATE)
		GROUP BY 
			A.CAMPAIGN_TAG,
			A.SUBSIDIARY;

		PERFORM CREATE LOCAL TEMP TABLE TMP_SALES_CAMPAIGN_PBI_V3_RESULT ON COMMIT PRESERVE ROWS AS
		SELECT 
			*
		FROM 
			OW_LAO.ODS_SALES_CAMPAIGN A
		WHERE 
			(A.PO_STATUS = 'Approved' OR (A.SUBSIDIARY = 'SELA' AND A.PO_STATUS = 'Pending')) 
			AND A.PREVIOUS_YEAR = TRUE 
			AND EXISTS (
				SELECT 
					1 
				FROM 
					OW_LAO.TMP_CAMPAIGN_CUT B
				WHERE 
					A.CAMPAIGN_TAG = B.CAMPAIGN_TAG 
					AND A.SUBSIDIARY = B.SUBSIDIARY 
					AND A.CAMPAIGN_DAY BETWEEN B.CAMPAIGN_TAG_START AND B.CAMPAIGN_TAG_END
			)
		UNION ALL
		SELECT 
			* 
		FROM 
			OW_LAO.ODS_SALES_CAMPAIGN  
		WHERE  
			(PO_STATUS = 'Approved' OR (SUBSIDIARY = 'SELA' AND PO_STATUS = 'Pending')) 
			AND PREVIOUS_YEAR = FALSE  
			AND CAST(PO_DATE AS DATE) >= CAST(DT_START AS DATE);				
	END;
	ELSEIF CONSULTA = 'DIM_CAMPAIGN_NAME_REGISTER' THEN	
	BEGIN
		PERFORM CREATE LOCAL TEMP TABLE TMP_SALES_CAMPAIGN_PBI_V3_RESULT ON COMMIT PRESERVE ROWS AS
		WITH campaign_cte AS (
		    SELECT
		        CAMPAIGN_TAG,
		        SUBSIDIARY AS Samsung_Sub,
		        CASE
		            WHEN BIZ_TYPE IS NULL OR BIZ_TYPE = '' THEN 'all'
		            ELSE UPPER(BIZ_TYPE)
		        END AS business,
		        CASE
		            WHEN PO_DEVICETYPE IS NULL OR PO_DEVICETYPE = '' THEN 'all'
		            ELSE LOWER(PO_DEVICETYPE)
		        END AS device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM
		        OW_LAO.DIM_CAMPAIGN_NAME AS campaign
		),
		expanded_campaign AS (
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        'SMB' AS business,
		        'app' AS device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business = 'all' AND device = 'all'
		   
		    UNION ALL
		   
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        'SMB' AS business,
		        'web' AS device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business = 'all' AND device = 'all'
		
		    UNION ALL
		
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        'B2C' AS business,
		        'app' AS device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business = 'all' AND device = 'all'
		   
		    UNION ALL
		   
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        'B2C' AS business,
		        'web' AS device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business = 'all' AND device = 'all'
		   
		    UNION ALL
		
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        'EPP' AS business,
		        'app' AS device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business = 'all' AND device = 'all'
		   
		    UNION ALL
		   
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        'EPP' AS business,
		        'web' AS device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business = 'all' AND device = 'all'
		),
		business_only_expansion AS (
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        'SMB' AS business,
		        device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business = 'all' AND device != 'all'
		
		    UNION ALL
		
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        'B2C' AS business,
		        device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business = 'all' AND device != 'all'
		   
		    UNION ALL
		   
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        'EPP' AS business,
		        device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business = 'all' AND device != 'all'
		),
		device_only_expansion AS (
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        business,
		        'app' AS device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business != 'all' AND device = 'all'
		
		    UNION ALL
		
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        business,
		        'web' AS device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business != 'all' AND device = 'all'
		),
		final_expansion AS (
		    SELECT * FROM campaign_cte WHERE business != 'all' AND device != 'all'
		    UNION ALL
		    SELECT * FROM expanded_campaign
		    UNION ALL
		    SELECT * FROM business_only_expansion
		    UNION ALL
		    SELECT * FROM device_only_expansion
		)
		SELECT
		    fe.*,
		    cal.yyyymmdd AS campaign_date
		FROM final_expansion fe
		JOIN ow_md.dim_calendar cal
		    ON cal.yyyymmdd BETWEEN fe.INITIAL_DATE AND fe.FINAL_DATE;		
	END;
	ELSE
		PERFORM CREATE LOCAL TEMP TABLE TMP_SALES_CAMPAIGN_PBI_V3_RESULT ON COMMIT PRESERVE ROWS AS
		SELECT 'Procedimento não declaro' AS CONSULTA;		
	END IF;
END
$$;

-- CALL OW_LAO.PROC_SALES_CAMPAIGN_PBI_V3('CAMPAIGN_SALES', CURRENT_TIMESTAMP);
-- ERROR: Severity: ERROR, Message: Column "TRUEFALSEFALSE" does not exist, Sqlstate: 42703, Where: PL/vSQL procedure PROC_SALES_CAMPAIGN_PBI_V3 line 6 at static SQL, Routine: transformSQLColumnRef, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Optimizer/OptUtil/ExprUtil.cpp, Line: 7401, Error Code: 2624, 
CREATE OR REPLACE PROCEDURE OW_LAO.PROC_SALES_CAMPAIGN_PBI_V3(
	IN CONSULTA VARCHAR(40),
	IN DT_START TIMESTAMP
) LANGUAGE PLvSQL AS $$
BEGIN
	IF CONSULTA = 'CAMPAIGN_SALES' THEN	
	BEGIN
		PERFORM TRUNCATE TABLE OW_LAO.TMP_CAMPAIGN_CUT;
		PERFORM INSERT INTO OW_LAO.TMP_CAMPAIGN_CUT 
		SELECT 
			A.CAMPAIGN_TAG,
			A.SUBSIDIARY,
			MIN(A.CAMPAIGN_DAY) AS CAMPAIGN_TAG_START, 
			MAX(A.CAMPAIGN_DAY) AS CAMPAIGN_TAG_END
		FROM 
			OW_LAO.ODS_SALES_CAMPAIGN A
		WHERE 
			(A.PO_STATUS = 'Approved' OR (A.SUBSIDIARY = 'SELA' AND A.PO_STATUS = 'Pending')) 
			AND A.PREVIOUS_YEAR = FALSE  
			AND CAST(A.PO_DATE AS DATE) >= CAST(DT_START AS DATE)
		GROUP BY 
			A.CAMPAIGN_TAG,
			A.SUBSIDIARY;

		PERFORM DROP TABLE IF EXISTS TMP_SALES_CAMPAIGN_PBI_V3_RESULT;
		PERFORM CREATE LOCAL TEMP TABLE TMP_SALES_CAMPAIGN_PBI_V3_RESULT ON COMMIT PRESERVE ROWS AS
		SELECT 
			*
		FROM 
			OW_LAO.ODS_SALES_CAMPAIGN A
		WHERE 
			(A.PO_STATUS = 'Approved' OR (A.SUBSIDIARY = 'SELA' AND A.PO_STATUS = 'Pending')) 
			AND A.PREVIOUS_YEAR = TRUE 
			AND EXISTS (
				SELECT 1 
				FROM OW_LAO.TMP_CAMPAIGN_CUT B
				WHERE A.CAMPAIGN_TAG = B.CAMPAIGN_TAG 
					AND A.SUBSIDIARY = B.SUBSIDIARY 
					AND A.CAMPAIGN_DAY BETWEEN B.CAMPAIGN_TAG_START AND B.CAMPAIGN_TAG_END
			)
		UNION ALL
		SELECT 
			* 
		FROM 
			OW_LAO.ODS_SALES_CAMPAIGN  
		WHERE  
			(PO_STATUS = 'Approved' OR (SUBSIDIARY = 'SELA' AND PO_STATUS = 'Pending')) 
			AND PREVIOUS_YEAR = FALSE  
			AND CAST(PO_DATE AS DATE) >= CAST(DT_START AS DATE);				
	END;
	ELSEIF CONSULTA = 'DIM_CAMPAIGN_NAME_REGISTER' THEN	
	BEGIN
		PERFORM DROP TABLE IF EXISTS TMP_SALES_CAMPAIGN_PBI_V3_RESULT;
		PERFORM CREATE LOCAL TEMP TABLE TMP_SALES_CAMPAIGN_PBI_V3_RESULT ON COMMIT PRESERVE ROWS AS
		WITH campaign_cte AS (
		    SELECT
		        CAMPAIGN_TAG,
		        SUBSIDIARY AS Samsung_Sub,
		        CASE
		            WHEN BIZ_TYPE IS NULL OR BIZ_TYPE = '' THEN 'all'
		            ELSE UPPER(BIZ_TYPE)
		        END AS business,
		        CASE
		            WHEN PO_DEVICETYPE IS NULL OR PO_DEVICETYPE = '' THEN 'all'
		            ELSE LOWER(PO_DEVICETYPE)
		        END AS device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM
		        OW_LAO.DIM_CAMPAIGN_NAME AS campaign
		),
		expanded_campaign AS (
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        'SMB' AS business,
		        'app' AS device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business = 'all' AND device = 'all'
		   
		    UNION ALL
		   
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        'SMB' AS business,
		        'web' AS device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business = 'all' AND device = 'all'
		
		    UNION ALL
		
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        'B2C' AS business,
		        'app' AS device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business = 'all' AND device = 'all'
		   
		    UNION ALL
		   
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        'B2C' AS business,
		        'web' AS device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business = 'all' AND device = 'all'
		   
		    UNION ALL
		
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        'EPP' AS business,
		        'app' AS device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business = 'all' AND device = 'all'
		   
		    UNION ALL
		   
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        'EPP' AS business,
		        'web' AS device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business = 'all' AND device = 'all'
		),
		business_only_expansion AS (
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        'SMB' AS business,
		        device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business = 'all' AND device != 'all'
		
		    UNION ALL
		
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        'B2C' AS business,
		        device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business = 'all' AND device != 'all'
		   
		    UNION ALL
		   
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        'EPP' AS business,
		        device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business = 'all' AND device != 'all'
		),
		device_only_expansion AS (
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        business,
		        'app' AS device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business != 'all' AND device = 'all'
		
		    UNION ALL
		
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        business,
		        'web' AS device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business != 'all' AND device = 'all'
		),
		final_expansion AS (
		    SELECT * FROM campaign_cte WHERE business != 'all' AND device != 'all'
		    UNION ALL
		    SELECT * FROM expanded_campaign
		    UNION ALL
		    SELECT * FROM business_only_expansion
		    UNION ALL
		    SELECT * FROM device_only_expansion
		)
		SELECT
		    fe.*,
		    cal.yyyymmdd AS campaign_date
		FROM final_expansion fe
		JOIN ow_md.dim_calendar cal
		    ON cal.yyyymmdd BETWEEN fe.INITIAL_DATE AND fe.FINAL_DATE;		
	END;
	ELSE
		PERFORM DROP TABLE IF EXISTS TMP_SALES_CAMPAIGN_PBI_V3_RESULT;
		PERFORM CREATE LOCAL TEMP TABLE TMP_SALES_CAMPAIGN_PBI_V3_RESULT ON COMMIT PRESERVE ROWS AS
		SELECT 'Procedimento não declaro' AS CONSULTA;		
	END IF;
END
$$;

CALL OW_LAO.PROC_SALES_CAMPAIGN_PBI_V3('CAMPAIGN_SALES', CURRENT_TIMESTAMP);
-- PROC_SALES_CAMPAIGN_PBI_V3
-- --------------------------
-- 0

