CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_lao_premium_products_table_from_gscm_update()
LANGUAGE PLvSQL AS $$
BEGIN
    
    PERFORM CREATE TABLE IF NOT EXISTS OW_LAO.TMP_ods_lao_product_premium_items_GSCM_PREMIUM_MODELS AS
        SELECT *
        FROM OW_LAO.ODS_GSCM_PREMIUM_MODELS
        WHERE 1=0;
        
    PERFORM TRUNCATE TABLE OW_LAO.TMP_ods_lao_product_premium_items_GSCM_PREMIUM_MODELS;

    PERFORM INSERT INTO OW_LAO.TMP_ods_lao_product_premium_items_GSCM_PREMIUM_MODELS
        SELECT *
          FROM OW_LAO.ODS_GSCM_PREMIUM_MODELS
         WHERE load_date >= TIMESTAMPADD(DAY, -1, CURRENT_DATE);

    PERFORM MERGE INTO OW_LAO.ODS_LAO_PRODUCT_PREMIUM_ITEMS                          O
        USING OW_LAO.TMP_ods_lao_product_premium_items_GSCM_PREMIUM_MODELS  M ON O.ITEM  = M.ITEM
                                                                             AND O.AP2   = M.AP2
                                                                             AND O.PLAN  = M.PLAN
                                                                             AND O."MONTH" = M."MONTH"
          WHEN MATCHED
          THEN UPDATE 
                  SET AP2               = M.AP2 
                    , PRODUCT_GRP       = M.PRODUCT_GRP 
                    , PRODUCT           = M.PRODUCT
                    , ITEM              = M.ITEM
                    , PLAN              = M.PLAN
                    , CATEGORY          = M.CATEGORY
                    , "MONTH"           = M."MONTH"
                    , VALUE             = M.VALUE 
                    , FILE_ROW_NUMBER   = M.FILE_ROW_NUMBER
                    , FILE_NAME         = M.FILE_NAME
                    , UPDATED_TIMESTAMP = CURRENT_TIMESTAMP
          WHEN NOT MATCHED THEN INSERT (
                                         AP2 
                                       , PRODUCT_GRP 
                                       , PRODUCT
                                       , ITEM
                                       , PLAN
                                       , CATEGORY
                                       , "MONTH"
                                       , VALUE 
                                       , FILE_ROW_NUMBER
                                       , FILE_NAME
                                 )
                                VALUES (
                                         M.AP2 
                                       , M.PRODUCT_GRP 
                                       , M.PRODUCT
                                       , M.ITEM
                                       , M.PLAN
                                       , M.CATEGORY
                                       , M."MONTH"
                                       , M.VALUE 
                                       , M.FILE_ROW_NUMBER
                                       , M.FILE_NAME
                                        
                                );
END
$$;

CALL OW_LAO.proc_ods_lao_premium_products_table_from_gscm_update();
-- proc_ods_lao_premium_products_table_from_gscm_update
-- ----------------------------------------------------
-- 0

