CREATE OR REPLACE PROCEDURE ow_lao.raw_vtex_payments_generate()
LANGUAGE PLvSQL AS $$
BEGIN
    PERFORM INSERT INTO "OW_LAO"."RAW_VTEX_PAYMENTS" (
           "KEY_ID",
           "KEY_TRANSACTION_ID",
           "PAYMENT_ID",
           "SOURCE",
           "STATUS",
           "DATE",
           "MESSAGE",
           "TICKS",
           "BATCH_ID",
           "ACCOUNT",
           "FILE_NAME"
    )
    SELECT DISTINCT
           a."KEY_ID",
           a."KEY_TRANSACTION_ID",
           a."PAYMENT_ID",
           a."SOURCE",
           a."STATUS",
           a."DATE",
           a."MESSAGE",
           a."TICKS",
           a."BATCH_ID",
           a."ACCOUNT",
           a."FILE_NAME"
      FROM ow_lao.STG_VTEX_PAYMENTS a
     WHERE NOT EXISTS (
                 SELECT 1
                   FROM "OW_LAO"."RAW_VTEX_PAYMENTS" aa
                  WHERE aa."KEY_ID" = a."KEY_ID"
           )
     ORDER BY a."BATCH_ID", a."FILE_NAME";
END;
$$;

-- CALL ow_lao.raw_vtex_payments_generate();
-- ERROR: Severity: ERROR, Message: Relation "ow_lao.STG_VTEX_PAYMENTS" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure raw_vtex_payments_generate line 3 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
-- CALL ow_lao.raw_vtex_payments_generate();
-- ERROR: Severity: ERROR, Message: Relation "ow_lao.STG_VTEX_PAYMENTS" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure raw_vtex_payments_generate line 3 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4341, Error Code: 4568, 
