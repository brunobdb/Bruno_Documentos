CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_sales_control_tower_table_nerp_update()
 LANGUAGE PLvSQL AS $$
BEGIN
      
      PERFORM DROP TABLE IF EXISTS temp_ods_sales_control_tower_table_nerp_update_filter;
    
      PERFORM CREATE LOCAL TEMPORARY TABLE temp_ods_sales_control_tower_table_nerp_update_filter ON COMMIT PRESERVE ROWS
        AS ( 
            select distinct
                   a.po_sequence_orderid    as id
                 , a.po_sku
                 , b.sales_org
                 , a.currency
                 , a.country
                 , a.po_status
                 , a.po_orderid
                 , cast(a.po_date as date)  as po_date
                 , 1                        as filterType
              from ow_lao.ods_sales_control_tower_table            a
              join ow_md.dim_subsidiary                            b on lower(b.country) = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking c on c.customer_po    = a.po_sequence_orderid
                                                                    and c.material       = a.po_sku
                                                                    and c.sales_org      = b.sales_org
             where nerp_last_update_date < c.last_modification_file
                or nerp_last_update_date is null 
             
             union all    
                     
            select distinct
                   a.po_ordersid            as id
                 , a.po_sku
                 , b.sales_org
                 , a.currency
                 , a.country
                 , a.po_status
                 , a.po_orderid
                 , cast(a.po_date as date)  as po_date
                 , 2                        as filterType
              from ow_lao.ods_sales_control_tower_table            a
              join ow_md.dim_subsidiary                            b on lower(b.country) = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking c on c.sales_document = a.po_ordersid
                                                                    and c.material       = a.po_sku
                                                                    and c.sales_org      = b.sales_org
             where nerp_last_update_date < c.last_modification_file
                or nerp_last_update_date is null
             
             union all    
                     
            select distinct
                   a.po_orderid             as id
                 , a.po_sku
                 , b.sales_org
                 , a.currency
                 , a.country
                 , a.po_status
                 , a.po_orderid
                 , cast(a.po_date as date)  as po_date
                 , 3                        as filterType
              from ow_lao.ods_sales_control_tower_table            a
              join ow_md.dim_subsidiary                            b on lower(b.country) = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking c on c.customer_po    = a.po_orderid
                                                                    and c.material       = a.po_sku
                                                                    and c.sales_org      = b.sales_org
             where nerp_last_update_date < c.last_modification_file
                or nerp_last_update_date is null   
        );
        
      PERFORM TRUNCATE TABLE ow_lao.temp_ods_sales_control_tower_table_nerp_update;
  -- Type 1 and 3      
      PERFORM INSERT INTO ow_lao.temp_ods_sales_control_tower_table_nerp_update            
            select a.id
                 , a.po_orderid
                 , a.po_sku
                 , c.sales_document
                 , c.sold_to_party
                 , c.name
                 , c.material
                 , c.item_descr
                 , c.item_division
                 , case when d.exchange_rate is null then 0.00 else CAST(REPLACE(e.so_net_price, ',', '') AS NUMERIC(18,6)) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as so_net_price   
                 , 0.00                                                                                                                                      as so_net_value
                 , case when d.exchange_rate is null then 0.00 else  CAST(REPLACE(c.cost       , ',', '') AS NUMERIC(18,6)) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as cost
                 , CAST(REPLACE(c.margin_rate , ',', '') AS NUMERIC(18,6)) as margin_rate
                 , c.so_curr
                 , c.so_create_on
                 , c.sales_org
                 , c.distr_channel
                 , c.plant
                 , c.stor_loc
                 , c.account_code
                 , c.account_name
                 , c.gc_id_gscm
                 , c.gc_name
                 , c.ap1_code
                 , c.ap1_name
                 , c.ap2_code
                 , c.ap2_name
                 , c.delivery
                 , 0                                                                  as delivery_qty_base
                 , c.billed_qty_base
                 , c.billing_date
                 , c.material_group
                 , c.so_local_create_on_d
                 , c.do_local_create_on_d
                 , c."1ST_GI_LOCAL_CREATE"
                 , c.billing_local_create
                 , c.final_sch_date
                 , max(e.last_modification_file)                                      as last_modification_file
                 , a.filterType
                 , 'Returned'                                                         as po_status
              from temp_ods_sales_control_tower_table_nerp_update_filter a
              join ow_md.dim_subsidiary                                         b on lower(b.country)    = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c on c.customer_po       = a.id
                                                                                 and c.material          = a.po_sku
                                                                                 and c.sales_org         = b.sales_org
                                                                                 and c.delivery_qty_base < 0  
         left join ow_lao.ft_ap2_exchange_rate                                  d on d.valid_from        = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE))
                                                                                 and d.to_currency       = a.currency
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e on e.customer_po       = a.id
                                                                                 and e.material          = a.po_sku
                                                                                 and e.sales_org         = b.sales_org
                                                                                 and e.delivery_qty_base >= 0
             where a.filterType in (1, 3)
               and (c.delivery_qty_base + e.delivery_qty_base) <= 0
          group by a.id
                 , a.po_orderid
                 , a.po_sku
                 , c.sales_document
                 , c.sold_to_party
                 , c.name
                 , c.material
                 , c.item_descr
                 , c.item_division
                 , case when d.exchange_rate is null then 0.00 else CAST(REPLACE(e.so_net_price, ',', '') AS NUMERIC(18,6)) / CAST(d.exchange_rate AS NUMERIC(18,6)) end
                 , case when d.exchange_rate is null then 0.00 else  CAST(REPLACE(c.cost       , ',', '') AS NUMERIC(18,6)) / CAST(d.exchange_rate AS NUMERIC(18,6)) end
                 , CAST(REPLACE(c.margin_rate , ',', '') AS NUMERIC(18,6))
                 , c.so_curr
                 , c.so_create_on
                 , c.sales_org
                 , c.distr_channel
                 , c.plant
                 , c.stor_loc
                 , c.account_code
                 , c.account_name
                 , c.gc_id_gscm
                 , c.gc_name
                 , c.ap1_code
                 , c.ap1_name
                 , c.ap2_code
                 , c.ap2_name
                 , c.delivery
                 , c.billed_qty_base
                 , c.billing_date
                 , c.material_group
                 , c.so_local_create_on_d
                 , c.do_local_create_on_d
                 , c."1ST_GI_LOCAL_CREATE"
                 , c.billing_local_create
                 , c.final_sch_date
                 , a.filterType;    
               
                  
      PERFORM INSERT INTO ow_lao.temp_ods_sales_control_tower_table_nerp_update            
            select a.id
                 , a.po_orderid
                 , a.po_sku
                 , e.sales_document
                 , e.sold_to_party
                 , e.name
                 , e.material
                 , e.item_descr
                 , e.item_division
                 , case when d.exchange_rate is null then 0.00 else (CAST(REPLACE(e.so_net_price, ',', '') AS NUMERIC(18,6))                                                    ) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as so_net_price   
                 , case when d.exchange_rate is null then 0.00 else (CAST(REPLACE(c.so_net_value, ',', '') AS NUMERIC(18,6)) + CAST(REPLACE(e.so_net_value, ',', '') AS NUMERIC(18,6))) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as so_net_value
                 , case when d.exchange_rate is null then 0.00 else  CAST(REPLACE(c.cost        , ',', '') AS NUMERIC(18,6))                                                      / CAST(d.exchange_rate AS NUMERIC(18,6)) end as cost
                 , CAST(REPLACE(c.margin_rate , ',', '') AS NUMERIC(18,6)) as margin_rate
                 , e.so_curr
                 , e.so_create_on
                 , e.sales_org
                 , e.distr_channel
                 , e.plant
                 , e.stor_loc
                 , e.account_code
                 , e.account_name
                 , e.gc_id_gscm
                 , e.gc_name
                 , e.ap1_code
                 , e.ap1_name
                 , e.ap2_code
                 , e.ap2_name
                 , e.delivery
                 , c.delivery_qty_base + e.delivery_qty_base        as delivery_qty_base
                 , e.billed_qty_base
                 , e.billing_date
                 , e.material_group
                 , e.so_local_create_on_d
                 , e.do_local_create_on_d
                 , e."1ST_GI_LOCAL_CREATE"
                 , e.billing_local_create
                 , e.final_sch_date
                 , e.last_modification_file
                 , a.filterType
                 , a.po_status
              from temp_ods_sales_control_tower_table_nerp_update_filter a
              join ow_md.dim_subsidiary                                         b on lower(b.country)    = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c on c.customer_po       = a.id
                                                                                 and c.material          = a.po_sku
                                                                                 and c.sales_org         = b.sales_org
                                                                                 and c.delivery_qty_base < 0  
         left join ow_lao.ft_ap2_exchange_rate                                  d on d.valid_from        = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE))
                                                                                 and d.to_currency       = a.currency
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e on e.customer_po       = a.id
                                                                                 and e.material          = a.po_sku
                                                                                 and e.sales_org         = b.sales_org
                                                                                 and e.delivery_qty_base >= 0
             where a.filterType in (1, 3)
               and (c.delivery_qty_base + e.delivery_qty_base) > 0;
               
      PERFORM INSERT INTO ow_lao.temp_ods_sales_control_tower_table_nerp_update  
            select a.id
                 , a.po_orderid
                 , a.po_sku
                 , c.sales_document
                 , c.sold_to_party
                 , c.name
                 , c.material
                 , c.item_descr
                 , c.item_division
                 , case when d.exchange_rate is null then 0.00 else abs(CAST(REPLACE(c.so_net_price, ',', '') AS NUMERIC(18,6))) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as so_net_price
                 , case when d.exchange_rate is null then 0.00 else abs(CAST(REPLACE(c.so_net_value, ',', '') AS NUMERIC(18,6))) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as so_net_value
                 , case when d.exchange_rate is null then 0.00 else CAST(REPLACE(c.cost            , ',', '') AS NUMERIC(18,6))  / CAST(d.exchange_rate AS NUMERIC(18,6)) end as cost
                 , CAST(REPLACE(c.margin_rate , ',', '') AS NUMERIC(18,6))                                                                                              as margin_rate
                 , c.so_curr
                 , c.so_create_on
                 , c.sales_org
                 , c.distr_channel
                 , c.plant
                 , c.stor_loc
                 , c.account_code
                 , c.account_name
                 , c.gc_id_gscm
                 , c.gc_name
                 , c.ap1_code
                 , c.ap1_name
                 , c.ap2_code
                 , c.ap2_name
                 , c.delivery
                 , abs(c.delivery_qty_base)                                      as delivery_qty_base
                 , c.billed_qty_base
                 , c.billing_date
                 , c.material_group
                 , c.so_local_create_on_d
                 , c.do_local_create_on_d
                 , c."1ST_GI_LOCAL_CREATE"
                 , c.billing_local_create
                 , c.final_sch_date
                 , c.last_modification_file
                 , a.filterType
                 , case when c.delivery_qty_base < 0 then 'Returned' else a.po_status end as po_status
              from temp_ods_sales_control_tower_table_nerp_update_filter a
              join ow_md.dim_subsidiary                                         b on lower(b.country)    = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c on c.customer_po       = a.id
                                                                                 and c.material          = a.po_sku
                                                                                 and c.sales_org         = b.sales_org
         left join ow_lao.ft_ap2_exchange_rate                                  d on d.valid_from        = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE))
                                                                                 and d.to_currency       = a.currency
             where a.filterType in (1, 3)
               and not exists(
                        select 1
                          from ow_lao.temp_ods_sales_control_tower_table_nerp_update aa
                         where c.customer_po       = aa.id
                           and c.material          = aa.po_sku
                           and c.sales_org         = aa.sales_org
                           and a.filterType        = aa.filterType
                   );
                   
  -- Type 2       
      PERFORM INSERT INTO ow_lao.temp_ods_sales_control_tower_table_nerp_update            
            select a.id
                 , a.po_orderid
                 , a.po_sku
                 , c.sales_document
                 , c.sold_to_party
                 , c.name
                 , c.material
                 , c.item_descr
                 , c.item_division
                 , case when d.exchange_rate is null then 0.00 else CAST(REPLACE(e.so_net_price, ',', '') AS NUMERIC(18,6)) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as so_net_price   
                 , 0.00                                                              as so_net_value
                 , case when d.exchange_rate is null then 0.00 else  CAST(REPLACE(c.cost       , ',', '') AS NUMERIC(18,6)) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as cost
                 , CAST(REPLACE(c.margin_rate , ',', '') AS NUMERIC(18,6)) as margin_rate
                 , c.so_curr
                 , c.so_create_on
                 , c.sales_org
                 , c.distr_channel
                 , c.plant
                 , c.stor_loc
                 , c.account_code
                 , c.account_name
                 , c.gc_id_gscm
                 , c.gc_name
                 , c.ap1_code
                 , c.ap1_name
                 , c.ap2_code
                 , c.ap2_name
                 , c.delivery
                 , 0                                                                  as delivery_qty_base
                 , c.billed_qty_base
                 , c.billing_date
                 , c.material_group
                 , c.so_local_create_on_d
                 , c.do_local_create_on_d
                 , c."1ST_GI_LOCAL_CREATE"
                 , c.billing_local_create
                 , c.final_sch_date
                 , max(e.last_modification_file)                                      as last_modification_file
                 , a.filterType
                 , 'Returned'                                                         as po_status
              from temp_ods_sales_control_tower_table_nerp_update_filter a
              join ow_md.dim_subsidiary                                         b on lower(b.country)    = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c on c.sales_document    = a.id
                                                                                 and c.material          = a.po_sku
                                                                                 and c.sales_org         = b.sales_org
                                                                                 and c.delivery_qty_base < 0  
         left join ow_lao.ft_ap2_exchange_rate                                  d on d.valid_from        = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE))
                                                                                 and d.to_currency       = a.currency
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e on e.sales_document    = a.id
                                                                                 and e.material          = a.po_sku
                                                                                 and e.sales_org         = b.sales_org
                                                                                 and e.delivery_qty_base >= 0
             where a.filterType in (2)
               and (c.delivery_qty_base + e.delivery_qty_base) <= 0
          group by a.id
                 , a.po_orderid
                 , a.po_sku
                 , c.sales_document
                 , c.sold_to_party
                 , c.name
                 , c.material
                 , c.item_descr
                 , c.item_division
                 , case when d.exchange_rate is null then 0.00 else CAST(REPLACE(e.so_net_price, ',', '') AS NUMERIC(18,6)) / CAST(d.exchange_rate AS NUMERIC(18,6)) end
                 , case when d.exchange_rate is null then 0.00 else  CAST(REPLACE(c.cost       , ',', '') AS NUMERIC(18,6)) / CAST(d.exchange_rate AS NUMERIC(18,6)) end
                 , CAST(REPLACE(c.margin_rate , ',', '') AS NUMERIC(18,6))
                 , c.so_curr
                 , c.so_create_on
                 , c.sales_org
                 , c.distr_channel
                 , c.plant
                 , c.stor_loc
                 , c.account_code
                 , c.account_name
                 , c.gc_id_gscm
                 , c.gc_name
                 , c.ap1_code
                 , c.ap1_name
                 , c.ap2_code
                 , c.ap2_name
                 , c.delivery
                 , c.billed_qty_base
                 , c.billing_date
                 , c.material_group
                 , c.so_local_create_on_d
                 , c.do_local_create_on_d
                 , c."1ST_GI_LOCAL_CREATE"
                 , c.billing_local_create
                 , c.final_sch_date
                 , a.filterType;       
               
                  
      PERFORM INSERT INTO ow_lao.temp_ods_sales_control_tower_table_nerp_update            
            select a.id
                 , a.po_orderid
                 , a.po_sku
                 , e.sales_document
                 , e.sold_to_party
                 , e.name
                 , e.material
                 , e.item_descr
                 , e.item_division
                 , case when d.exchange_rate is null then 0.00 else (CAST(REPLACE(e.so_net_price, ',', '') AS NUMERIC(18,6))                                                    ) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as so_net_price   
                 , case when d.exchange_rate is null then 0.00 else (CAST(REPLACE(c.so_net_value, ',', '') AS NUMERIC(18,6)) + CAST(REPLACE(e.so_net_value, ',', '') AS NUMERIC(18,6))) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as so_net_value
                 , case when d.exchange_rate is null then 0.00 else  CAST(REPLACE(c.cost        , ',', '') AS NUMERIC(18,6))                                                      / CAST(d.exchange_rate AS NUMERIC(18,6)) end as cost
                 , CAST(REPLACE(c.margin_rate , ',', '') AS NUMERIC(18,6)) as margin_rate
                 , e.so_curr
                 , e.so_create_on
                 , e.sales_org
                 , e.distr_channel
                 , e.plant
                 , e.stor_loc
                 , e.account_code
                 , e.account_name
                 , e.gc_id_gscm
                 , e.gc_name
                 , e.ap1_code
                 , e.ap1_name
                 , e.ap2_code
                 , e.ap2_name
                 , e.delivery
                 , c.delivery_qty_base + e.delivery_qty_base        as delivery_qty_base
                 , e.billed_qty_base
                 , e.billing_date
                 , e.material_group
                 , e.so_local_create_on_d
                 , e.do_local_create_on_d
                 , e."1ST_GI_LOCAL_CREATE"
                 , e.billing_local_create
                 , e.final_sch_date
                 , e.last_modification_file
                 , a.filterType
                 , a.po_status
              from temp_ods_sales_control_tower_table_nerp_update_filter a
              join ow_md.dim_subsidiary                                         b on lower(b.country)    = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c on c.sales_document    = a.id
                                                                                 and c.material          = a.po_sku
                                                                                 and c.sales_org         = b.sales_org
                                                                                 and c.delivery_qty_base < 0  
         left join ow_lao.ft_ap2_exchange_rate                                  d on d.valid_from        = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE))
                                                                                 and d.to_currency       = a.currency
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e on e.sales_document    = a.id
                                                                                 and e.material          = a.po_sku
                                                                                 and e.sales_org         = b.sales_org
                                                                                 and e.delivery_qty_base >= 0
             where a.filterType in (2)
               and (c.delivery_qty_base + e.delivery_qty_base) > 0;
               
      PERFORM INSERT INTO ow_lao.temp_ods_sales_control_tower_table_nerp_update  
            select a.id
                 , a.po_orderid
                 , a.po_sku
                 , c.sales_document
                 , c.sold_to_party
                 , c.name
                 , c.material
                 , c.item_descr
                 , c.item_division
                 , case when d.exchange_rate is null then 0.00 else abs(CAST(REPLACE(c.so_net_price, ',', '') AS NUMERIC(18,6))) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as so_net_price
                 , case when d.exchange_rate is null then 0.00 else abs(CAST(REPLACE(c.so_net_value, ',', '') AS NUMERIC(18,6))) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as so_net_value
                 , case when d.exchange_rate is null then 0.00 else abs(CAST(REPLACE(c.cost        , ',', '') AS NUMERIC(18,6))) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as cost
                 , CAST(REPLACE(c.margin_rate , ',', '') AS NUMERIC(18,6))                                                                                              as margin_rate
                 , c.so_curr
                 , c.so_create_on
                 , c.sales_org
                 , c.distr_channel
                 , c.plant
                 , c.stor_loc
                 , c.account_code
                 , c.account_name
                 , c.gc_id_gscm
                 , c.gc_name
                 , c.ap1_code
                 , c.ap1_name
                 , c.ap2_code
                 , c.ap2_name
                 , c.delivery
                 , abs(c.delivery_qty_base)                                                as delivery_qty_base
                 , c.billed_qty_base
                 , c.billing_date
                 , c.material_group
                 , c.so_local_create_on_d
                 , c.do_local_create_on_d
                 , c."1ST_GI_LOCAL_CREATE"
                 , c.billing_local_create
                 , c.final_sch_date
                 , c.last_modification_file
                 , a.filterType
                 , case when c.delivery_qty_base < 0 then 'Returned' else a.po_status end as po_status
              from temp_ods_sales_control_tower_table_nerp_update_filter a
              join ow_md.dim_subsidiary                                         b on lower(b.country)    = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c on c.sales_document    = a.id
                                                                                 and c.material          = a.po_sku
                                                                                 and c.sales_org         = b.sales_org
         left join ow_lao.ft_ap2_exchange_rate                                  d on d.valid_from        = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE))
                                                                                 and d.to_currency       = a.currency
             where a.filterType in (2)
               and not exists(
                        select 1
                          from ow_lao.temp_ods_sales_control_tower_table_nerp_update aa
                         where c.sales_document    = aa.id
                           and c.material          = aa.po_sku
                           and c.sales_org         = aa.sales_org
                           and a.filterType        = aa.filterType
                   );           
                   
      PERFORM UPDATE ow_lao.ods_sales_control_tower_table            a
           SET so_idcode             = c.sales_document
             , po_status             = c.po_status
             , soldto_party          = c.sold_to_party
             , soldto_name           = c.name
             , nerp_sku              = c.material
             , nerp_sku_description  = c.item_descr
             , nerp_sku_division     = c.item_division
             , nerp_netprice         = case when c.so_net_price < 0 then 0 else c.so_net_price end
             , nerp_netvalue         = case when c.so_net_value < 0 then 0 else c.so_net_value end
             , nerp_cost             = c.cost
             , nerp_marginrate       = c.margin_rate
             , nerp_currency         = c.so_curr
             , so_date_kst           = c.so_create_on
             , nerp_countrycode      = c.sales_org
             , nerp_distchannel      = c.distr_channel
             , nerp_plant            = c.plant
             , nerp_storagelocation  = c.stor_loc
             , nerp_accountcode      = c.account_code
             , nerp_accountname      = c.account_name
             , nerp_id_gscm          = c.gc_id_gscm
             , nerp_gc_name          = c.gc_name
             , nerp_ap1_code         = c.ap1_code
             , nerp_ap1_name         = c.ap1_name
             , nerp_ap2_code         = c.ap2_code
             , nerp_ap2_name         = c.ap2_name
             , nerp_deliverycode     = c.delivery
             , nerp_deliveruqty      = c.delivery_qty_base
             , nerp_billingqty       = c.billed_qty_base
             , nerp_billingdate      = c.billing_date
             , nerp_material_group   = c.material_group
             , so_date               = c.so_local_create_on_d
             , do_date               = c.do_local_create_on_d
             , "1GI_DATE"            = c."1ST_GI_LOCAL_CREATE"
             , billing_date_local    = c.billing_local_create
             , final_date            = c.final_sch_date
             , nerp_last_update_date = c.last_modification_file
             , updated_datetime      = current_timestamp
        FROM ow_md.dim_subsidiary                                  b 
        JOIN ow_lao.temp_ods_sales_control_tower_table_nerp_update c ON c.po_orderid     = a.po_orderid
                                                                      AND c.material       = a.po_sku
                                                                      AND c.sales_org      = b.sales_org
   LEFT JOIN ow_lao.ft_ap2_exchange_rate                           d ON d.valid_from     = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE))
                                                                      AND d.to_currency    = a.currency
       WHERE (a.nerp_last_update_date < c.last_modification_file OR a.nerp_last_update_date IS NULL)
         AND lower(b.country) = lower(a.country);
         
END
$$;

-- CALL OW_LAO.proc_ods_sales_control_tower_table_nerp_update();
-- ERROR: Severity: ERROR, Message: Operator does not exist: timestamp < varchar, Sqlstate: 42883, Hint: No operator matches the given name and argument type(s). You may need to add explicit type casts, Where: PL/vSQL procedure proc_ods_sales_control_tower_table_nerp_update line 6 at static SQL, Routine: op_error, File: parse_oper.c, Line: 608, Error Code: 4286, 
-- CALL OW_LAO.proc_ods_sales_control_tower_table_nerp_update();
-- ERROR: Severity: ERROR, Message: Operator does not exist: timestamp < varchar, Sqlstate: 42883, Hint: No operator matches the given name and argument type(s). You may need to add explicit type casts, Where: PL/vSQL procedure proc_ods_sales_control_tower_table_nerp_update line 6 at static SQL, Routine: op_error, File: parse_oper.c, Line: 608, Error Code: 4286, 
CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_sales_control_tower_table_nerp_update()
 LANGUAGE PLvSQL AS $$
BEGIN
      
      PERFORM DROP TABLE IF EXISTS temp_ods_sales_control_tower_table_nerp_update_filter;
    
      PERFORM CREATE LOCAL TEMPORARY TABLE temp_ods_sales_control_tower_table_nerp_update_filter ON COMMIT PRESERVE ROWS
        AS ( 
            select distinct
                   a.po_sequence_orderid    as id
                 , a.po_sku
                 , b.sales_org
                 , a.currency
                 , a.country
                 , a.po_status
                 , a.po_orderid
                 , cast(a.po_date as date)  as po_date
                 , 1                        as filterType
              from ow_lao.ods_sales_control_tower_table            a
              join ow_md.dim_subsidiary                            b on lower(b.country) = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking c on c.customer_po    = a.po_sequence_orderid
                                                                    and c.material       = a.po_sku
                                                                    and c.sales_org      = b.sales_org
             where a.nerp_last_update_date < CAST(c.last_modification_file AS TIMESTAMP)
                or a.nerp_last_update_date is null 
             
             union all    
                     
            select distinct
                   a.po_ordersid            as id
                 , a.po_sku
                 , b.sales_org
                 , a.currency
                 , a.country
                 , a.po_status
                 , a.po_orderid
                 , cast(a.po_date as date)  as po_date
                 , 2                        as filterType
              from ow_lao.ods_sales_control_tower_table            a
              join ow_md.dim_subsidiary                            b on lower(b.country) = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking c on c.sales_document = a.po_ordersid
                                                                    and c.material       = a.po_sku
                                                                    and c.sales_org      = b.sales_org
             where a.nerp_last_update_date < CAST(c.last_modification_file AS TIMESTAMP)
                or a.nerp_last_update_date is null
             
             union all    
                     
            select distinct
                   a.po_orderid             as id
                 , a.po_sku
                 , b.sales_org
                 , a.currency
                 , a.country
                 , a.po_status
                 , a.po_orderid
                 , cast(a.po_date as date)  as po_date
                 , 3                        as filterType
              from ow_lao.ods_sales_control_tower_table            a
              join ow_md.dim_subsidiary                            b on lower(b.country) = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking c on c.customer_po    = a.po_orderid
                                                                    and c.material       = a.po_sku
                                                                    and c.sales_org      = b.sales_org
             where a.nerp_last_update_date < CAST(c.last_modification_file AS TIMESTAMP)
                or a.nerp_last_update_date is null   
        );
        
      PERFORM TRUNCATE TABLE ow_lao.temp_ods_sales_control_tower_table_nerp_update;
  -- Type 1 and 3      
      PERFORM INSERT INTO ow_lao.temp_ods_sales_control_tower_table_nerp_update            
            select a.id
                 , a.po_orderid
                 , a.po_sku
                 , c.sales_document
                 , c.sold_to_party
                 , c.name
                 , c.material
                 , c.item_descr
                 , c.item_division
                 , case when d.exchange_rate is null then 0.00 else CAST(REPLACE(e.so_net_price, ',', '') AS NUMERIC(18,6)) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as so_net_price   
                 , 0.00                                                                                                                                      as so_net_value
                 , case when d.exchange_rate is null then 0.00 else  CAST(REPLACE(c.cost       , ',', '') AS NUMERIC(18,6)) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as cost
                 , CAST(REPLACE(c.margin_rate , ',', '') AS NUMERIC(18,6)) as margin_rate
                 , c.so_curr
                 , c.so_create_on
                 , c.sales_org
                 , c.distr_channel
                 , c.plant
                 , c.stor_loc
                 , c.account_code
                 , c.account_name
                 , c.gc_id_gscm
                 , c.gc_name
                 , c.ap1_code
                 , c.ap1_name
                 , c.ap2_code
                 , c.ap2_name
                 , c.delivery
                 , 0                                                                  as delivery_qty_base
                 , c.billed_qty_base
                 , c.billing_date
                 , c.material_group
                 , c.so_local_create_on_d
                 , c.do_local_create_on_d
                 , c."1ST_GI_LOCAL_CREATE"
                 , c.billing_local_create
                 , c.final_sch_date
                 , MAX(CAST(e.last_modification_file AS TIMESTAMP))                   as last_modification_file
                 , a.filterType
                 , 'Returned'                                                         as po_status
              from temp_ods_sales_control_tower_table_nerp_update_filter a
              join ow_md.dim_subsidiary                                         b on lower(b.country)    = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c on c.customer_po       = a.id
                                                                                 and c.material          = a.po_sku
                                                                                 and c.sales_org         = b.sales_org
                                                                                 and c.delivery_qty_base < 0  
         left join ow_lao.ft_ap2_exchange_rate                                  d on d.valid_from        = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE))
                                                                                 and d.to_currency       = a.currency
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e on e.customer_po       = a.id
                                                                                 and e.material          = a.po_sku
                                                                                 and e.sales_org         = b.sales_org
                                                                                 and e.delivery_qty_base >= 0
             where a.filterType in (1, 3)
               and (c.delivery_qty_base + e.delivery_qty_base) <= 0
          group by a.id
                 , a.po_orderid
                 , a.po_sku
                 , c.sales_document
                 , c.sold_to_party
                 , c.name
                 , c.material
                 , c.item_descr
                 , c.item_division
                 , case when d.exchange_rate is null then 0.00 else CAST(REPLACE(e.so_net_price, ',', '') AS NUMERIC(18,6)) / CAST(d.exchange_rate AS NUMERIC(18,6)) end
                 , case when d.exchange_rate is null then 0.00 else  CAST(REPLACE(c.cost       , ',', '') AS NUMERIC(18,6)) / CAST(d.exchange_rate AS NUMERIC(18,6)) end
                 , CAST(REPLACE(c.margin_rate , ',', '') AS NUMERIC(18,6))
                 , c.so_curr
                 , c.so_create_on
                 , c.sales_org
                 , c.distr_channel
                 , c.plant
                 , c.stor_loc
                 , c.account_code
                 , c.account_name
                 , c.gc_id_gscm
                 , c.gc_name
                 , c.ap1_code
                 , c.ap1_name
                 , c.ap2_code
                 , c.ap2_name
                 , c.delivery
                 , c.billed_qty_base
                 , c.billing_date
                 , c.material_group
                 , c.so_local_create_on_d
                 , c.do_local_create_on_d
                 , c."1ST_GI_LOCAL_CREATE"
                 , c.billing_local_create
                 , c.final_sch_date
                 , a.filterType;    
               
                  
      PERFORM INSERT INTO ow_lao.temp_ods_sales_control_tower_table_nerp_update            
            select a.id
                 , a.po_orderid
                 , a.po_sku
                 , e.sales_document
                 , e.sold_to_party
                 , e.name
                 , e.material
                 , e.item_descr
                 , e.item_division
                 , case when d.exchange_rate is null then 0.00 else (CAST(REPLACE(e.so_net_price, ',', '') AS NUMERIC(18,6))                                                    ) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as so_net_price   
                 , case when d.exchange_rate is null then 0.00 else (CAST(REPLACE(c.so_net_value, ',', '') AS NUMERIC(18,6)) + CAST(REPLACE(e.so_net_value, ',', '') AS NUMERIC(18,6))) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as so_net_value
                 , case when d.exchange_rate is null then 0.00 else  CAST(REPLACE(c.cost        , ',', '') AS NUMERIC(18,6))                                                      / CAST(d.exchange_rate AS NUMERIC(18,6)) end as cost
                 , CAST(REPLACE(c.margin_rate , ',', '') AS NUMERIC(18,6)) as margin_rate
                 , e.so_curr
                 , e.so_create_on
                 , e.sales_org
                 , e.distr_channel
                 , e.plant
                 , e.stor_loc
                 , e.account_code
                 , e.account_name
                 , e.gc_id_gscm
                 , e.gc_name
                 , e.ap1_code
                 , e.ap1_name
                 , e.ap2_code
                 , e.ap2_name
                 , e.delivery
                 , c.delivery_qty_base + e.delivery_qty_base        as delivery_qty_base
                 , e.billed_qty_base
                 , e.billing_date
                 , e.material_group
                 , e.so_local_create_on_d
                 , e.do_local_create_on_d
                 , e."1ST_GI_LOCAL_CREATE"
                 , e.billing_local_create
                 , e.final_sch_date
                 , CAST(e.last_modification_file AS TIMESTAMP)
                 , a.filterType
                 , a.po_status
              from temp_ods_sales_control_tower_table_nerp_update_filter a
              join ow_md.dim_subsidiary                                         b on lower(b.country)    = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c on c.customer_po       = a.id
                                                                                 and c.material          = a.po_sku
                                                                                 and c.sales_org         = b.sales_org
                                                                                 and c.delivery_qty_base < 0  
         left join ow_lao.ft_ap2_exchange_rate                                  d on d.valid_from        = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE))
                                                                                 and d.to_currency       = a.currency
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e on e.customer_po       = a.id
                                                                                 and e.material          = a.po_sku
                                                                                 and e.sales_org         = b.sales_org
                                                                                 and e.delivery_qty_base >= 0
             where a.filterType in (1, 3)
               and (c.delivery_qty_base + e.delivery_qty_base) > 0;
               
      PERFORM INSERT INTO ow_lao.temp_ods_sales_control_tower_table_nerp_update  
            select a.id
                 , a.po_orderid
                 , a.po_sku
                 , c.sales_document
                 , c.sold_to_party
                 , c.name
                 , c.material
                 , c.item_descr
                 , c.item_division
                 , case when d.exchange_rate is null then 0.00 else abs(CAST(REPLACE(c.so_net_price, ',', '') AS NUMERIC(18,6))) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as so_net_price
                 , case when d.exchange_rate is null then 0.00 else abs(CAST(REPLACE(c.so_net_value, ',', '') AS NUMERIC(18,6))) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as so_net_value
                 , case when d.exchange_rate is null then 0.00 else CAST(REPLACE(c.cost            , ',', '') AS NUMERIC(18,6))  / CAST(d.exchange_rate AS NUMERIC(18,6)) end as cost
                 , CAST(REPLACE(c.margin_rate , ',', '') AS NUMERIC(18,6))                                                                                              as margin_rate
                 , c.so_curr
                 , c.so_create_on
                 , c.sales_org
                 , c.distr_channel
                 , c.plant
                 , c.stor_loc
                 , c.account_code
                 , c.account_name
                 , c.gc_id_gscm
                 , c.gc_name
                 , c.ap1_code
                 , c.ap1_name
                 , c.ap2_code
                 , c.ap2_name
                 , c.delivery
                 , abs(c.delivery_qty_base)                                      as delivery_qty_base
                 , c.billed_qty_base
                 , c.billing_date
                 , c.material_group
                 , c.so_local_create_on_d
                 , c.do_local_create_on_d
                 , c."1ST_GI_LOCAL_CREATE"
                 , c.billing_local_create
                 , c.final_sch_date
                 , CAST(c.last_modification_file AS TIMESTAMP)
                 , a.filterType
                 , case when c.delivery_qty_base < 0 then 'Returned' else a.po_status end as po_status
              from temp_ods_sales_control_tower_table_nerp_update_filter a
              join ow_md.dim_subsidiary                                         b on lower(b.country)    = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c on c.customer_po       = a.id
                                                                                 and c.material          = a.po_sku
                                                                                 and c.sales_org         = b.sales_org
         left join ow_lao.ft_ap2_exchange_rate                                  d on d.valid_from        = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE))
                                                                                 and d.to_currency       = a.currency
             where a.filterType in (1, 3)
               and not exists(
                        select 1
                          from ow_lao.temp_ods_sales_control_tower_table_nerp_update aa
                         where c.customer_po       = aa.id
                           and c.material          = aa.po_sku
                           and c.sales_org         = aa.sales_org
                           and a.filterType        = aa.filterType
                   );
                   
  -- Type 2       
      PERFORM INSERT INTO ow_lao.temp_ods_sales_control_tower_table_nerp_update            
            select a.id
                 , a.po_orderid
                 , a.po_sku
                 , c.sales_document
                 , c.sold_to_party
                 , c.name
                 , c.material
                 , c.item_descr
                 , c.item_division
                 , case when d.exchange_rate is null then 0.00 else CAST(REPLACE(e.so_net_price, ',', '') AS NUMERIC(18,6)) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as so_net_price   
                 , 0.00                                                              as so_net_value
                 , case when d.exchange_rate is null then 0.00 else  CAST(REPLACE(c.cost       , ',', '') AS NUMERIC(18,6)) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as cost
                 , CAST(REPLACE(c.margin_rate , ',', '') AS NUMERIC(18,6)) as margin_rate
                 , c.so_curr
                 , c.so_create_on
                 , c.sales_org
                 , c.distr_channel
                 , c.plant
                 , c.stor_loc
                 , c.account_code
                 , c.account_name
                 , c.gc_id_gscm
                 , c.gc_name
                 , c.ap1_code
                 , c.ap1_name
                 , c.ap2_code
                 , c.ap2_name
                 , c.delivery
                 , 0                                                                  as delivery_qty_base
                 , c.billed_qty_base
                 , c.billing_date
                 , c.material_group
                 , c.so_local_create_on_d
                 , c.do_local_create_on_d
                 , c."1ST_GI_LOCAL_CREATE"
                 , c.billing_local_create
                 , c.final_sch_date
                 , MAX(CAST(e.last_modification_file AS TIMESTAMP))                   as last_modification_file
                 , a.filterType
                 , 'Returned'                                                         as po_status
              from temp_ods_sales_control_tower_table_nerp_update_filter a
              join ow_md.dim_subsidiary                                         b on lower(b.country)    = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c on c.sales_document    = a.id
                                                                                 and c.material          = a.po_sku
                                                                                 and c.sales_org         = b.sales_org
                                                                                 and c.delivery_qty_base < 0  
         left join ow_lao.ft_ap2_exchange_rate                                  d on d.valid_from        = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE))
                                                                                 and d.to_currency       = a.currency
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e on e.sales_document    = a.id
                                                                                 and e.material          = a.po_sku
                                                                                 and e.sales_org         = b.sales_org
                                                                                 and e.delivery_qty_base >= 0
             where a.filterType in (2)
               and (c.delivery_qty_base + e.delivery_qty_base) <= 0
          group by a.id
                 , a.po_orderid
                 , a.po_sku
                 , c.sales_document
                 , c.sold_to_party
                 , c.name
                 , c.material
                 , c.item_descr
                 , c.item_division
                 , case when d.exchange_rate is null then 0.00 else CAST(REPLACE(e.so_net_price, ',', '') AS NUMERIC(18,6)) / CAST(d.exchange_rate AS NUMERIC(18,6)) end
                 , case when d.exchange_rate is null then 0.00 else  CAST(REPLACE(c.cost       , ',', '') AS NUMERIC(18,6)) / CAST(d.exchange_rate AS NUMERIC(18,6)) end
                 , CAST(REPLACE(c.margin_rate , ',', '') AS NUMERIC(18,6))
                 , c.so_curr
                 , c.so_create_on
                 , c.sales_org
                 , c.distr_channel
                 , c.plant
                 , c.stor_loc
                 , c.account_code
                 , c.account_name
                 , c.gc_id_gscm
                 , c.gc_name
                 , c.ap1_code
                 , c.ap1_name
                 , c.ap2_code
                 , c.ap2_name
                 , c.delivery
                 , c.billed_qty_base
                 , c.billing_date
                 , c.material_group
                 , c.so_local_create_on_d
                 , c.do_local_create_on_d
                 , c."1ST_GI_LOCAL_CREATE"
                 , c.billing_local_create
                 , c.final_sch_date
                 , a.filterType;       
               
                  
      PERFORM INSERT INTO ow_lao.temp_ods_sales_control_tower_table_nerp_update            
            select a.id
                 , a.po_orderid
                 , a.po_sku
                 , e.sales_document
                 , e.sold_to_party
                 , e.name
                 , e.material
                 , e.item_descr
                 , e.item_division
                 , case when d.exchange_rate is null then 0.00 else (CAST(REPLACE(e.so_net_price, ',', '') AS NUMERIC(18,6))                                                    ) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as so_net_price   
                 , case when d.exchange_rate is null then 0.00 else (CAST(REPLACE(c.so_net_value, ',', '') AS NUMERIC(18,6)) + CAST(REPLACE(e.so_net_value, ',', '') AS NUMERIC(18,6))) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as so_net_value
                 , case when d.exchange_rate is null then 0.00 else  CAST(REPLACE(c.cost        , ',', '') AS NUMERIC(18,6))                                                      / CAST(d.exchange_rate AS NUMERIC(18,6)) end as cost
                 , CAST(REPLACE(c.margin_rate , ',', '') AS NUMERIC(18,6)) as margin_rate
                 , e.so_curr
                 , e.so_create_on
                 , e.sales_org
                 , e.distr_channel
                 , e.plant
                 , e.stor_loc
                 , e.account_code
                 , e.account_name
                 , e.gc_id_gscm
                 , e.gc_name
                 , e.ap1_code
                 , e.ap1_name
                 , e.ap2_code
                 , e.ap2_name
                 , e.delivery
                 , c.delivery_qty_base + e.delivery_qty_base        as delivery_qty_base
                 , e.billed_qty_base
                 , e.billing_date
                 , e.material_group
                 , e.so_local_create_on_d
                 , e.do_local_create_on_d
                 , e."1ST_GI_LOCAL_CREATE"
                 , e.billing_local_create
                 , e.final_sch_date
                 , CAST(e.last_modification_file AS TIMESTAMP)
                 , a.filterType
                 , a.po_status
              from temp_ods_sales_control_tower_table_nerp_update_filter a
              join ow_md.dim_subsidiary                                         b on lower(b.country)    = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c on c.sales_document    = a.id
                                                                                 and c.material          = a.po_sku
                                                                                 and c.sales_org         = b.sales_org
                                                                                 and c.delivery_qty_base < 0  
         left join ow_lao.ft_ap2_exchange_rate                                  d on d.valid_from        = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE))
                                                                                 and d.to_currency       = a.currency
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e on e.sales_document    = a.id
                                                                                 and e.material          = a.po_sku
                                                                                 and e.sales_org         = b.sales_org
                                                                                 and e.delivery_qty_base >= 0
             where a.filterType in (2)
               and (c.delivery_qty_base + e.delivery_qty_base) > 0;
               
      PERFORM INSERT INTO ow_lao.temp_ods_sales_control_tower_table_nerp_update  
            select a.id
                 , a.po_orderid
                 , a.po_sku
                 , c.sales_document
                 , c.sold_to_party
                 , c.name
                 , c.material
                 , c.item_descr
                 , c.item_division
                 , case when d.exchange_rate is null then 0.00 else abs(CAST(REPLACE(c.so_net_price, ',', '') AS NUMERIC(18,6))) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as so_net_price
                 , case when d.exchange_rate is null then 0.00 else abs(CAST(REPLACE(c.so_net_value, ',', '') AS NUMERIC(18,6))) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as so_net_value
                 , case when d.exchange_rate is null then 0.00 else abs(CAST(REPLACE(c.cost        , ',', '') AS NUMERIC(18,6))) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as cost
                 , CAST(REPLACE(c.margin_rate , ',', '') AS NUMERIC(18,6))                                                                                              as margin_rate
                 , c.so_curr
                 , c.so_create_on
                 , c.sales_org
                 , c.distr_channel
                 , c.plant
                 , c.stor_loc
                 , c.account_code
                 , c.account_name
                 , c.gc_id_gscm
                 , c.gc_name
                 , c.ap1_code
                 , c.ap1_name
                 , c.ap2_code
                 , c.ap2_name
                 , c.delivery
                 , abs(c.delivery_qty_base)                                                as delivery_qty_base
                 , c.billed_qty_base
                 , c.billing_date
                 , c.material_group
                 , c.so_local_create_on_d
                 , c.do_local_create_on_d
                 , c."1ST_GI_LOCAL_CREATE"
                 , c.billing_local_create
                 , c.final_sch_date
                 , CAST(c.last_modification_file AS TIMESTAMP)
                 , a.filterType
                 , case when c.delivery_qty_base < 0 then 'Returned' else a.po_status end as po_status
              from temp_ods_sales_control_tower_table_nerp_update_filter a
              join ow_md.dim_subsidiary                                         b on lower(b.country)    = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c on c.sales_document    = a.id
                                                                                 and c.material          = a.po_sku
                                                                                 and c.sales_org         = b.sales_org
         left join ow_lao.ft_ap2_exchange_rate                                  d on d.valid_from        = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE))
                                                                                 and d.to_currency       = a.currency
             where a.filterType in (2)
               and not exists(
                        select 1
                          from ow_lao.temp_ods_sales_control_tower_table_nerp_update aa
                         where c.sales_document    = aa.id
                           and c.material          = aa.po_sku
                           and c.sales_org         = aa.sales_org
                           and a.filterType        = aa.filterType
                   );           
                   
      PERFORM UPDATE ow_lao.ods_sales_control_tower_table            a
           SET so_idcode             = c.sales_document
             , po_status             = c.po_status
             , soldto_party          = c.sold_to_party
             , soldto_name           = c.name
             , nerp_sku              = c.material
             , nerp_sku_description  = c.item_descr
             , nerp_sku_division     = c.item_division
             , nerp_netprice         = case when c.so_net_price < 0 then 0 else c.so_net_price end
             , nerp_netvalue         = case when c.so_net_value < 0 then 0 else c.so_net_value end
             , nerp_cost             = c.cost
             , nerp_marginrate       = c.margin_rate
             , nerp_currency         = c.so_curr
             , so_date_kst           = c.so_create_on
             , nerp_countrycode      = c.sales_org
             , nerp_distchannel      = c.distr_channel
             , nerp_plant            = c.plant
             , nerp_storagelocation  = c.stor_loc
             , nerp_accountcode      = c.account_code
             , nerp_accountname      = c.account_name
             , nerp_id_gscm          = c.gc_id_gscm
             , nerp_gc_name          = c.gc_name
             , nerp_ap1_code         = c.ap1_code
             , nerp_ap1_name         = c.ap1_name
             , nerp_ap2_code         = c.ap2_code
             , nerp_ap2_name         = c.ap2_name
             , nerp_deliverycode     = c.delivery
             , nerp_deliveruqty      = c.delivery_qty_base
             , nerp_billingqty       = c.billed_qty_base
             , nerp_billingdate      = c.billing_date
             , nerp_material_group   = c.material_group
             , so_date               = c.so_local_create_on_d
             , do_date               = c.do_local_create_on_d
             , "1GI_DATE"            = c."1ST_GI_LOCAL_CREATE"
             , billing_date_local    = c.billing_local_create
             , final_date            = c.final_sch_date
             , nerp_last_update_date = c.last_modification_file
             , updated_datetime      = current_timestamp
        FROM ow_md.dim_subsidiary                                  b 
        JOIN ow_lao.temp_ods_sales_control_tower_table_nerp_update c ON c.po_orderid     = a.po_orderid
                                                                      AND c.material       = a.po_sku
                                                                      AND c.sales_org      = b.sales_org
   LEFT JOIN ow_lao.ft_ap2_exchange_rate                           d ON d.valid_from     = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE))
                                                                      AND d.to_currency    = a.currency
       WHERE (a.nerp_last_update_date < CAST(c.last_modification_file AS TIMESTAMP) OR a.nerp_last_update_date IS NULL)
         AND lower(b.country) = lower(a.country);
         
END
$$;

-- CALL OW_LAO.proc_ods_sales_control_tower_table_nerp_update();
-- ERROR: Severity: ERROR, Message: Operator does not exist: varchar = timestamp, Sqlstate: 42883, Hint: No operator matches the given name and argument type(s). You may need to add explicit type casts, Where: PL/vSQL procedure proc_ods_sales_control_tower_table_nerp_update line 69 at static SQL, Routine: op_error, File: parse_oper.c, Line: 608, Error Code: 4286, 
-- CALL OW_LAO.proc_ods_sales_control_tower_table_nerp_update();
-- ERROR: Severity: ERROR, Message: Operator does not exist: varchar = timestamp, Sqlstate: 42883, Hint: No operator matches the given name and argument type(s). You may need to add explicit type casts, Where: PL/vSQL procedure proc_ods_sales_control_tower_table_nerp_update line 69 at static SQL, Routine: op_error, File: parse_oper.c, Line: 608, Error Code: 4286, 
CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_sales_control_tower_table_nerp_update()
 LANGUAGE PLvSQL AS $$
BEGIN
      
      PERFORM DROP TABLE IF EXISTS temp_ods_sales_control_tower_table_nerp_update_filter;
    
      PERFORM CREATE LOCAL TEMPORARY TABLE temp_ods_sales_control_tower_table_nerp_update_filter ON COMMIT PRESERVE ROWS
        AS ( 
            select distinct
                   a.po_sequence_orderid    as id
                 , a.po_sku
                 , b.sales_org
                 , a.currency
                 , a.country
                 , a.po_status
                 , a.po_orderid
                 , cast(a.po_date as date)  as po_date
                 , 1                        as filterType
              from ow_lao.ods_sales_control_tower_table            a
              join ow_md.dim_subsidiary                            b on lower(b.country) = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking c on c.customer_po    = a.po_sequence_orderid
                                                                    and c.material       = a.po_sku
                                                                    and c.sales_org      = b.sales_org
             where a.nerp_last_update_date < CAST(c.last_modification_file AS TIMESTAMP)
                or a.nerp_last_update_date is null 
             
             union all    
                     
            select distinct
                   a.po_ordersid            as id
                 , a.po_sku
                 , b.sales_org
                 , a.currency
                 , a.country
                 , a.po_status
                 , a.po_orderid
                 , cast(a.po_date as date)  as po_date
                 , 2                        as filterType
              from ow_lao.ods_sales_control_tower_table            a
              join ow_md.dim_subsidiary                            b on lower(b.country) = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking c on c.sales_document = a.po_ordersid
                                                                    and c.material       = a.po_sku
                                                                    and c.sales_org      = b.sales_org
             where a.nerp_last_update_date < CAST(c.last_modification_file AS TIMESTAMP)
                or a.nerp_last_update_date is null
             
             union all    
                     
            select distinct
                   a.po_orderid             as id
                 , a.po_sku
                 , b.sales_org
                 , a.currency
                 , a.country
                 , a.po_status
                 , a.po_orderid
                 , cast(a.po_date as date)  as po_date
                 , 3                        as filterType
              from ow_lao.ods_sales_control_tower_table            a
              join ow_md.dim_subsidiary                            b on lower(b.country) = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking c on c.customer_po    = a.po_orderid
                                                                    and c.material       = a.po_sku
                                                                    and c.sales_org      = b.sales_org
             where a.nerp_last_update_date < CAST(c.last_modification_file AS TIMESTAMP)
                or a.nerp_last_update_date is null   
        );
        
      PERFORM TRUNCATE TABLE ow_lao.temp_ods_sales_control_tower_table_nerp_update;
  -- Type 1 and 3      
      PERFORM INSERT INTO ow_lao.temp_ods_sales_control_tower_table_nerp_update            
            select a.id
                 , a.po_orderid
                 , a.po_sku
                 , c.sales_document
                 , c.sold_to_party
                 , c.name
                 , c.material
                 , c.item_descr
                 , c.item_division
                 , case when d.exchange_rate is null then 0.00 else CAST(REPLACE(e.so_net_price, ',', '') AS NUMERIC(18,6)) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as so_net_price   
                 , 0.00                                                                                                                                      as so_net_value
                 , case when d.exchange_rate is null then 0.00 else  CAST(REPLACE(c.cost       , ',', '') AS NUMERIC(18,6)) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as cost
                 , CAST(REPLACE(c.margin_rate , ',', '') AS NUMERIC(18,6)) as margin_rate
                 , c.so_curr
                 , c.so_create_on
                 , c.sales_org
                 , c.distr_channel
                 , c.plant
                 , c.stor_loc
                 , c.account_code
                 , c.account_name
                 , c.gc_id_gscm
                 , c.gc_name
                 , c.ap1_code
                 , c.ap1_name
                 , c.ap2_code
                 , c.ap2_name
                 , c.delivery
                 , 0                                                                  as delivery_qty_base
                 , c.billed_qty_base
                 , c.billing_date
                 , c.material_group
                 , c.so_local_create_on_d
                 , c.do_local_create_on_d
                 , c."1ST_GI_LOCAL_CREATE"
                 , c.billing_local_create
                 , c.final_sch_date
                 , MAX(CAST(e.last_modification_file AS TIMESTAMP))                   as last_modification_file
                 , a.filterType
                 , 'Returned'                                                         as po_status
              from temp_ods_sales_control_tower_table_nerp_update_filter a
              join ow_md.dim_subsidiary                                         b on lower(b.country)    = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c on c.customer_po       = a.id
                                                                                 and c.material          = a.po_sku
                                                                                 and c.sales_org         = b.sales_org
                                                                                 and c.delivery_qty_base < 0  
         left join ow_lao.ft_ap2_exchange_rate                                  d on CAST(d.valid_from AS DATE) = CAST(TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE)) AS DATE)
                                                                                 and d.to_currency       = a.currency
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e on e.customer_po       = a.id
                                                                                 and e.material          = a.po_sku
                                                                                 and e.sales_org         = b.sales_org
                                                                                 and e.delivery_qty_base >= 0
             where a.filterType in (1, 3)
               and (c.delivery_qty_base + e.delivery_qty_base) <= 0
          group by a.id
                 , a.po_orderid
                 , a.po_sku
                 , c.sales_document
                 , c.sold_to_party
                 , c.name
                 , c.material
                 , c.item_descr
                 , c.item_division
                 , case when d.exchange_rate is null then 0.00 else CAST(REPLACE(e.so_net_price, ',', '') AS NUMERIC(18,6)) / CAST(d.exchange_rate AS NUMERIC(18,6)) end
                 , case when d.exchange_rate is null then 0.00 else  CAST(REPLACE(c.cost       , ',', '') AS NUMERIC(18,6)) / CAST(d.exchange_rate AS NUMERIC(18,6)) end
                 , CAST(REPLACE(c.margin_rate , ',', '') AS NUMERIC(18,6))
                 , c.so_curr
                 , c.so_create_on
                 , c.sales_org
                 , c.distr_channel
                 , c.plant
                 , c.stor_loc
                 , c.account_code
                 , c.account_name
                 , c.gc_id_gscm
                 , c.gc_name
                 , c.ap1_code
                 , c.ap1_name
                 , c.ap2_code
                 , c.ap2_name
                 , c.delivery
                 , c.billed_qty_base
                 , c.billing_date
                 , c.material_group
                 , c.so_local_create_on_d
                 , c.do_local_create_on_d
                 , c."1ST_GI_LOCAL_CREATE"
                 , c.billing_local_create
                 , c.final_sch_date
                 , a.filterType;    
               
                  
      PERFORM INSERT INTO ow_lao.temp_ods_sales_control_tower_table_nerp_update            
            select a.id
                 , a.po_orderid
                 , a.po_sku
                 , e.sales_document
                 , e.sold_to_party
                 , e.name
                 , e.material
                 , e.item_descr
                 , e.item_division
                 , case when d.exchange_rate is null then 0.00 else (CAST(REPLACE(e.so_net_price, ',', '') AS NUMERIC(18,6))                                                    ) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as so_net_price   
                 , case when d.exchange_rate is null then 0.00 else (CAST(REPLACE(c.so_net_value, ',', '') AS NUMERIC(18,6)) + CAST(REPLACE(e.so_net_value, ',', '') AS NUMERIC(18,6))) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as so_net_value
                 , case when d.exchange_rate is null then 0.00 else  CAST(REPLACE(c.cost        , ',', '') AS NUMERIC(18,6))                                                      / CAST(d.exchange_rate AS NUMERIC(18,6)) end as cost
                 , CAST(REPLACE(c.margin_rate , ',', '') AS NUMERIC(18,6)) as margin_rate
                 , e.so_curr
                 , e.so_create_on
                 , e.sales_org
                 , e.distr_channel
                 , e.plant
                 , e.stor_loc
                 , e.account_code
                 , e.account_name
                 , e.gc_id_gscm
                 , e.gc_name
                 , e.ap1_code
                 , e.ap1_name
                 , e.ap2_code
                 , e.ap2_name
                 , e.delivery
                 , c.delivery_qty_base + e.delivery_qty_base        as delivery_qty_base
                 , e.billed_qty_base
                 , e.billing_date
                 , e.material_group
                 , e.so_local_create_on_d
                 , e.do_local_create_on_d
                 , e."1ST_GI_LOCAL_CREATE"
                 , e.billing_local_create
                 , e.final_sch_date
                 , CAST(e.last_modification_file AS TIMESTAMP)
                 , a.filterType
                 , a.po_status
              from temp_ods_sales_control_tower_table_nerp_update_filter a
              join ow_md.dim_subsidiary                                         b on lower(b.country)    = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c on c.customer_po       = a.id
                                                                                 and c.material          = a.po_sku
                                                                                 and c.sales_org         = b.sales_org
                                                                                 and c.delivery_qty_base < 0  
         left join ow_lao.ft_ap2_exchange_rate                                  d on CAST(d.valid_from AS DATE) = CAST(TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE)) AS DATE)
                                                                                 and d.to_currency       = a.currency
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e on e.customer_po       = a.id
                                                                                 and e.material          = a.po_sku
                                                                                 and e.sales_org         = b.sales_org
                                                                                 and e.delivery_qty_base >= 0
             where a.filterType in (1, 3)
               and (c.delivery_qty_base + e.delivery_qty_base) > 0;
               
      PERFORM INSERT INTO ow_lao.temp_ods_sales_control_tower_table_nerp_update  
            select a.id
                 , a.po_orderid
                 , a.po_sku
                 , c.sales_document
                 , c.sold_to_party
                 , c.name
                 , c.material
                 , c.item_descr
                 , c.item_division
                 , case when d.exchange_rate is null then 0.00 else abs(CAST(REPLACE(c.so_net_price, ',', '') AS NUMERIC(18,6))) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as so_net_price
                 , case when d.exchange_rate is null then 0.00 else abs(CAST(REPLACE(c.so_net_value, ',', '') AS NUMERIC(18,6))) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as so_net_value
                 , case when d.exchange_rate is null then 0.00 else CAST(REPLACE(c.cost            , ',', '') AS NUMERIC(18,6))  / CAST(d.exchange_rate AS NUMERIC(18,6)) end as cost
                 , CAST(REPLACE(c.margin_rate , ',', '') AS NUMERIC(18,6))                                                                                              as margin_rate
                 , c.so_curr
                 , c.so_create_on
                 , c.sales_org
                 , c.distr_channel
                 , c.plant
                 , c.stor_loc
                 , c.account_code
                 , c.account_name
                 , c.gc_id_gscm
                 , c.gc_name
                 , c.ap1_code
                 , c.ap1_name
                 , c.ap2_code
                 , c.ap2_name
                 , c.delivery
                 , abs(c.delivery_qty_base)                                      as delivery_qty_base
                 , c.billed_qty_base
                 , c.billing_date
                 , c.material_group
                 , c.so_local_create_on_d
                 , c.do_local_create_on_d
                 , c."1ST_GI_LOCAL_CREATE"
                 , c.billing_local_create
                 , c.final_sch_date
                 , CAST(c.last_modification_file AS TIMESTAMP)
                 , a.filterType
                 , case when c.delivery_qty_base < 0 then 'Returned' else a.po_status end as po_status
              from temp_ods_sales_control_tower_table_nerp_update_filter a
              join ow_md.dim_subsidiary                                         b on lower(b.country)    = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c on c.customer_po       = a.id
                                                                                 and c.material          = a.po_sku
                                                                                 and c.sales_org         = b.sales_org
         left join ow_lao.ft_ap2_exchange_rate                                  d on CAST(d.valid_from AS DATE) = CAST(TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE)) AS DATE)
                                                                                 and d.to_currency       = a.currency
             where a.filterType in (1, 3)
               and not exists(
                        select 1
                          from ow_lao.temp_ods_sales_control_tower_table_nerp_update aa
                         where c.customer_po       = aa.id
                           and c.material          = aa.po_sku
                           and c.sales_org         = aa.sales_org
                           and a.filterType        = aa.filterType
                   );
                   
  -- Type 2       
      PERFORM INSERT INTO ow_lao.temp_ods_sales_control_tower_table_nerp_update            
            select a.id
                 , a.po_orderid
                 , a.po_sku
                 , c.sales_document
                 , c.sold_to_party
                 , c.name
                 , c.material
                 , c.item_descr
                 , c.item_division
                 , case when d.exchange_rate is null then 0.00 else CAST(REPLACE(e.so_net_price, ',', '') AS NUMERIC(18,6)) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as so_net_price   
                 , 0.00                                                              as so_net_value
                 , case when d.exchange_rate is null then 0.00 else  CAST(REPLACE(c.cost       , ',', '') AS NUMERIC(18,6)) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as cost
                 , CAST(REPLACE(c.margin_rate , ',', '') AS NUMERIC(18,6)) as margin_rate
                 , c.so_curr
                 , c.so_create_on
                 , c.sales_org
                 , c.distr_channel
                 , c.plant
                 , c.stor_loc
                 , c.account_code
                 , c.account_name
                 , c.gc_id_gscm
                 , c.gc_name
                 , c.ap1_code
                 , c.ap1_name
                 , c.ap2_code
                 , c.ap2_name
                 , c.delivery
                 , 0                                                                  as delivery_qty_base
                 , c.billed_qty_base
                 , c.billing_date
                 , c.material_group
                 , c.so_local_create_on_d
                 , c.do_local_create_on_d
                 , c."1ST_GI_LOCAL_CREATE"
                 , c.billing_local_create
                 , c.final_sch_date
                 , MAX(CAST(e.last_modification_file AS TIMESTAMP))                   as last_modification_file
                 , a.filterType
                 , 'Returned'                                                         as po_status
              from temp_ods_sales_control_tower_table_nerp_update_filter a
              join ow_md.dim_subsidiary                                         b on lower(b.country)    = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c on c.sales_document    = a.id
                                                                                 and c.material          = a.po_sku
                                                                                 and c.sales_org         = b.sales_org
                                                                                 and c.delivery_qty_base < 0  
         left join ow_lao.ft_ap2_exchange_rate                                  d on CAST(d.valid_from AS DATE) = CAST(TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE)) AS DATE)
                                                                                 and d.to_currency       = a.currency
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e on e.sales_document    = a.id
                                                                                 and e.material          = a.po_sku
                                                                                 and e.sales_org         = b.sales_org
                                                                                 and e.delivery_qty_base >= 0
             where a.filterType in (2)
               and (c.delivery_qty_base + e.delivery_qty_base) <= 0
          group by a.id
                 , a.po_orderid
                 , a.po_sku
                 , c.sales_document
                 , c.sold_to_party
                 , c.name
                 , c.material
                 , c.item_descr
                 , c.item_division
                 , case when d.exchange_rate is null then 0.00 else CAST(REPLACE(e.so_net_price, ',', '') AS NUMERIC(18,6)) / CAST(d.exchange_rate AS NUMERIC(18,6)) end
                 , case when d.exchange_rate is null then 0.00 else  CAST(REPLACE(c.cost       , ',', '') AS NUMERIC(18,6)) / CAST(d.exchange_rate AS NUMERIC(18,6)) end
                 , CAST(REPLACE(c.margin_rate , ',', '') AS NUMERIC(18,6))
                 , c.so_curr
                 , c.so_create_on
                 , c.sales_org
                 , c.distr_channel
                 , c.plant
                 , c.stor_loc
                 , c.account_code
                 , c.account_name
                 , c.gc_id_gscm
                 , c.gc_name
                 , c.ap1_code
                 , c.ap1_name
                 , c.ap2_code
                 , c.ap2_name
                 , c.delivery
                 , c.billed_qty_base
                 , c.billing_date
                 , c.material_group
                 , c.so_local_create_on_d
                 , c.do_local_create_on_d
                 , c."1ST_GI_LOCAL_CREATE"
                 , c.billing_local_create
                 , c.final_sch_date
                 , a.filterType;       
               
                  
      PERFORM INSERT INTO ow_lao.temp_ods_sales_control_tower_table_nerp_update            
            select a.id
                 , a.po_orderid
                 , a.po_sku
                 , e.sales_document
                 , e.sold_to_party
                 , e.name
                 , e.material
                 , e.item_descr
                 , e.item_division
                 , case when d.exchange_rate is null then 0.00 else (CAST(REPLACE(e.so_net_price, ',', '') AS NUMERIC(18,6))                                                    ) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as so_net_price   
                 , case when d.exchange_rate is null then 0.00 else (CAST(REPLACE(c.so_net_value, ',', '') AS NUMERIC(18,6)) + CAST(REPLACE(e.so_net_value, ',', '') AS NUMERIC(18,6))) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as so_net_value
                 , case when d.exchange_rate is null then 0.00 else  CAST(REPLACE(c.cost        , ',', '') AS NUMERIC(18,6))                                                      / CAST(d.exchange_rate AS NUMERIC(18,6)) end as cost
                 , CAST(REPLACE(c.margin_rate , ',', '') AS NUMERIC(18,6)) as margin_rate
                 , e.so_curr
                 , e.so_create_on
                 , e.sales_org
                 , e.distr_channel
                 , e.plant
                 , e.stor_loc
                 , e.account_code
                 , e.account_name
                 , e.gc_id_gscm
                 , e.gc_name
                 , e.ap1_code
                 , e.ap1_name
                 , e.ap2_code
                 , e.ap2_name
                 , e.delivery
                 , c.delivery_qty_base + e.delivery_qty_base        as delivery_qty_base
                 , e.billed_qty_base
                 , e.billing_date
                 , e.material_group
                 , e.so_local_create_on_d
                 , e.do_local_create_on_d
                 , e."1ST_GI_LOCAL_CREATE"
                 , e.billing_local_create
                 , e.final_sch_date
                 , CAST(e.last_modification_file AS TIMESTAMP)
                 , a.filterType
                 , a.po_status
              from temp_ods_sales_control_tower_table_nerp_update_filter a
              join ow_md.dim_subsidiary                                         b on lower(b.country)    = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c on c.sales_document    = a.id
                                                                                 and c.material          = a.po_sku
                                                                                 and c.sales_org         = b.sales_org
                                                                                 and c.delivery_qty_base < 0  
         left join ow_lao.ft_ap2_exchange_rate                                  d on CAST(d.valid_from AS DATE) = CAST(TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE)) AS DATE)
                                                                                 and d.to_currency       = a.currency
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e on e.sales_document    = a.id
                                                                                 and e.material          = a.po_sku
                                                                                 and e.sales_org         = b.sales_org
                                                                                 and e.delivery_qty_base >= 0
             where a.filterType in (2)
               and (c.delivery_qty_base + e.delivery_qty_base) > 0;
               
      PERFORM INSERT INTO ow_lao.temp_ods_sales_control_tower_table_nerp_update  
            select a.id
                 , a.po_orderid
                 , a.po_sku
                 , c.sales_document
                 , c.sold_to_party
                 , c.name
                 , c.material
                 , c.item_descr
                 , c.item_division
                 , case when d.exchange_rate is null then 0.00 else abs(CAST(REPLACE(c.so_net_price, ',', '') AS NUMERIC(18,6))) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as so_net_price
                 , case when d.exchange_rate is null then 0.00 else abs(CAST(REPLACE(c.so_net_value, ',', '') AS NUMERIC(18,6))) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as so_net_value
                 , case when d.exchange_rate is null then 0.00 else abs(CAST(REPLACE(c.cost        , ',', '') AS NUMERIC(18,6))) / CAST(d.exchange_rate AS NUMERIC(18,6)) end as cost
                 , CAST(REPLACE(c.margin_rate , ',', '') AS NUMERIC(18,6))                                                                                              as margin_rate
                 , c.so_curr
                 , c.so_create_on
                 , c.sales_org
                 , c.distr_channel
                 , c.plant
                 , c.stor_loc
                 , c.account_code
                 , c.account_name
                 , c.gc_id_gscm
                 , c.gc_name
                 , c.ap1_code
                 , c.ap1_name
                 , c.ap2_code
                 , c.ap2_name
                 , c.delivery
                 , abs(c.delivery_qty_base)                                                as delivery_qty_base
                 , c.billed_qty_base
                 , c.billing_date
                 , c.material_group
                 , c.so_local_create_on_d
                 , c.do_local_create_on_d
                 , c."1ST_GI_LOCAL_CREATE"
                 , c.billing_local_create
                 , c.final_sch_date
                 , CAST(c.last_modification_file AS TIMESTAMP)
                 , a.filterType
                 , case when c.delivery_qty_base < 0 then 'Returned' else a.po_status end as po_status
              from temp_ods_sales_control_tower_table_nerp_update_filter a
              join ow_md.dim_subsidiary                                         b on lower(b.country)    = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c on c.sales_document    = a.id
                                                                                 and c.material          = a.po_sku
                                                                                 and c.sales_org         = b.sales_org
         left join ow_lao.ft_ap2_exchange_rate                                  d on CAST(d.valid_from AS DATE) = CAST(TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE)) AS DATE)
                                                                                 and d.to_currency       = a.currency
             where a.filterType in (2)
               and not exists(
                        select 1
                          from ow_lao.temp_ods_sales_control_tower_table_nerp_update aa
                         where c.sales_document    = aa.id
                           and c.material          = aa.po_sku
                           and c.sales_org         = aa.sales_org
                           and a.filterType        = aa.filterType
                   );           
                   
      PERFORM UPDATE ow_lao.ods_sales_control_tower_table            a
           SET so_idcode             = c.sales_document
             , po_status             = c.po_status
             , soldto_party          = c.sold_to_party
             , soldto_name           = c.name
             , nerp_sku              = c.material
             , nerp_sku_description  = c.item_descr
             , nerp_sku_division     = c.item_division
             , nerp_netprice         = case when c.so_net_price < 0 then 0 else c.so_net_price end
             , nerp_netvalue         = case when c.so_net_value < 0 then 0 else c.so_net_value end
             , nerp_cost             = c.cost
             , nerp_marginrate       = c.margin_rate
             , nerp_currency         = c.so_curr
             , so_date_kst           = c.so_create_on
             , nerp_countrycode      = c.sales_org
             , nerp_distchannel      = c.distr_channel
             , nerp_plant            = c.plant
             , nerp_storagelocation  = c.stor_loc
             , nerp_accountcode      = c.account_code
             , nerp_accountname      = c.account_name
             , nerp_id_gscm          = c.gc_id_gscm
             , nerp_gc_name          = c.gc_name
             , nerp_ap1_code         = c.ap1_code
             , nerp_ap1_name         = c.ap1_name
             , nerp_ap2_code         = c.ap2_code
             , nerp_ap2_name         = c.ap2_name
             , nerp_deliverycode     = c.delivery
             , nerp_deliveruqty      = c.delivery_qty_base
             , nerp_billingqty       = c.billed_qty_base
             , nerp_billingdate      = c.billing_date
             , nerp_material_group   = c.material_group
             , so_date               = c.so_local_create_on_d
             , do_date               = c.do_local_create_on_d
             , "1GI_DATE"            = c."1ST_GI_LOCAL_CREATE"
             , billing_date_local    = c.billing_local_create
             , final_date            = c.final_sch_date
             , nerp_last_update_date = c.last_modification_file
             , updated_datetime      = current_timestamp
        FROM ow_md.dim_subsidiary                                  b 
        JOIN ow_lao.temp_ods_sales_control_tower_table_nerp_update c ON c.po_orderid     = a.po_orderid
                                                                      AND c.material       = a.po_sku
                                                                      AND c.sales_org      = b.sales_org
   LEFT JOIN ow_lao.ft_ap2_exchange_rate                           d ON CAST(d.valid_from AS DATE) = CAST(TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE)) AS DATE)
                                                                      AND d.to_currency    = a.currency
       WHERE (a.nerp_last_update_date < CAST(c.last_modification_file AS TIMESTAMP) OR a.nerp_last_update_date IS NULL)
         AND lower(b.country) = lower(a.country);
         
END
$$;

-- CALL OW_LAO.proc_ods_sales_control_tower_table_nerp_update();
-- ERROR: Severity: ERROR, Message: Relation "a" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ods_sales_control_tower_table_nerp_update line 484 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4345, Error Code: 4566, 
-- CALL OW_LAO.proc_ods_sales_control_tower_table_nerp_update();
-- ERROR: Severity: ERROR, Message: Relation "a" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_ods_sales_control_tower_table_nerp_update line 484 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4345, Error Code: 4566, 
