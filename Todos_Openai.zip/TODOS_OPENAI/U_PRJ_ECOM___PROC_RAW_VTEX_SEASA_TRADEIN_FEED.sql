CREATE OR REPLACE PROCEDURE U_PRJ_ECOM.PROC_RAW_VTEX_SEASA_TRADEIN_FEED()
LANGUAGE PLvSQL AS $$
BEGIN
  
  -- Create temporary table to stage data
  PERFORM CREATE LOCAL TEMP TABLE TMP_VTEX_SEASA_TRADEIN_FEED ON COMMIT PRESERVE ROWS AS
  (
    SELECT 
       a.ORDER_ID,
       a.CREATION_DATE,
       a.HOSTNAME,
       a.UNIQUE_ID AS UNIQUEID,
       a.SKU_ID AS SKUID,
       a.PRODUCT_ID AS PRODUCTID,
       a.EAN,
       a.REF_ID AS REFID,
       a.DEVICE_BRAND AS BRAND_DEVICE,
       a.DEVICE_MODEL AS MODEL_DEVICE,
       a.DEVICE_VALUE/100 AS TRADE_IN_DISCOUNT_DEVICE ,
       CURRENT_TIMESTAMP AS INSERT_DATE, 
       CURRENT_TIMESTAMP AS LAST_UPDATE_DATE
    FROM (
      -- Device 1
      SELECT
          a.order_id,
          b.CREATION_TIMESTAMP AS CREATION_DATE,
          b.HOSTNAME,
          a.UNIQUE_ID,
          a.SKU_ID,
          a.REF_ID AS REF_ID,
          a.PRODUCT_ID,
          a.EAN,
          JSON_EXTRACT_STRING(
              REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}'),
              '$.content.TradeIn.bonoTotal'
          ) AS bonoTotal,
          JSON_EXTRACT_STRING(
              REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}'),
              '$.content.TradeIn.device1.type'
          ) AS device_type,
          JSON_EXTRACT_STRING(
              REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}'),
              '$.content.TradeIn.device1.brand'
          ) AS device_brand,
          JSON_EXTRACT_STRING(
              REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}'),
              '$.content.TradeIn.device1.value'
          ) AS device_value,
          JSON_EXTRACT_STRING(
              REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}'),
              '$.content.TradeIn.device1.model'
          ) AS device_model,
          CASE 
            WHEN COALESCE(
                 JSON_EXTRACT_STRING(
                   REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}'),
                   '$.content.TradeIn.device1'
                 ), 'false') = 'false' THEN 0
            ELSE 1
          END AS tradeIn
      FROM U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER_ITEM a
      LEFT JOIN U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER b ON a.ORDER_ID = b.ORDER_ID 
      WHERE a.attachments IS NOT NULL
      UNION ALL
      -- Device 2
      SELECT
          a.order_id,
          b.CREATION_TIMESTAMP AS CREATION_DATE,
          b.HOSTNAME,
          a.UNIQUE_ID,
          a.SKU_ID,
          a.REF_ID AS REF_ID,
          a.PRODUCT_ID,
          a.EAN,
          JSON_EXTRACT_STRING(
              REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}'),
              '$.content.TradeIn.bonoTotal'
          ) AS bonoTotal,
          JSON_EXTRACT_STRING(
              REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}'),
              '$.content.TradeIn.device2.type'
          ) AS device_type,
          JSON_EXTRACT_STRING(
              REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}'),
              '$.content.TradeIn.device2.brand'
          ) AS device_brand,
          JSON_EXTRACT_STRING(
              REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}'),
              '$.content.TradeIn.device2.value'
          ) AS device_value,
          JSON_EXTRACT_STRING(
              REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}'),
              '$.content.TradeIn.device2.model'
          ) AS device_model,
          CASE 
            WHEN COALESCE(
                 JSON_EXTRACT_STRING(
                   REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}'),
                   '$.content.TradeIn.device2'
                 ), 'false') = 'false' THEN 0
            ELSE 1
          END AS tradeIn
      FROM U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER_ITEM a
      LEFT JOIN U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER b ON a.ORDER_ID = b.ORDER_ID 
      WHERE a.attachments IS NOT NULL
    ) a
    WHERE a.TRADEIN = 1
      AND a.CREATION_DATE IS NOT NULL
      AND NOT EXISTS (
        SELECT 1
        FROM U_PRJ_ECOM.RAW_VTEX_SEASA_TRADEIN_FEED aa
        WHERE aa.ORDER_ID = a.ORDER_ID
          AND aa.REFID = a.REF_ID
      )
  );

  -- Insert into RAW table
  PERFORM INSERT INTO U_PRJ_ECOM.RAW_VTEX_SEASA_TRADEIN_FEED
  (
    SELECT DISTINCT 
      ORDER_ID,
      CREATION_DATE,
      HOSTNAME,
      UNIQUEID,
      SKUID,
      PRODUCTID,
      EAN,
      REFID,
      BRAND_DEVICE,
      MODEL_DEVICE,
      TRADE_IN_DISCOUNT_DEVICE,
      INSERT_DATE,
      LAST_UPDATE_DATE
    FROM TMP_VTEX_SEASA_TRADEIN_FEED tmp
    WHERE tmp.ORDER_ID IS NOT NULL
      AND NOT EXISTS (
        SELECT 1
        FROM U_PRJ_ECOM.RAW_VTEX_SEASA_TRADEIN_FEED aa
        WHERE aa.ORDER_ID = tmp.ORDER_ID
          AND aa.REFID = tmp.REFID
      )
  );

  -- Drop temporary table
  PERFORM DROP TABLE IF EXISTS TMP_VTEX_SEASA_TRADEIN_FEED;

END;
$$;

-- CALL U_PRJ_ECOM.PROC_RAW_VTEX_SEASA_TRADEIN_FEED();
-- ERROR: Severity: ERROR, Message: Function JSON_EXTRACT_STRING(varchar, unknown) does not exist, or permission is denied for JSON_EXTRACT_STRING(varchar, unknown), Sqlstate: 42883, Hint: No function matches the given name and argument types. You may need to add explicit type casts, Where: PL/vSQL procedure PROC_RAW_VTEX_SEASA_TRADEIN_FEED line 5 at static SQL, Routine: throwErrorFunctionDoesNotMatch, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/ParseFunc.cpp, Line: 4559, Error Code: 3457, 
-- CALL U_PRJ_ECOM.PROC_RAW_VTEX_SEASA_TRADEIN_FEED();
-- ERROR: Severity: ERROR, Message: Function JSON_EXTRACT_STRING(varchar, unknown) does not exist, or permission is denied for JSON_EXTRACT_STRING(varchar, unknown), Sqlstate: 42883, Hint: No function matches the given name and argument types. You may need to add explicit type casts, Where: PL/vSQL procedure PROC_RAW_VTEX_SEASA_TRADEIN_FEED line 5 at static SQL, Routine: throwErrorFunctionDoesNotMatch, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/ParseFunc.cpp, Line: 4559, Error Code: 3457, 
-- SELECT schema_name, function_name, argument_data_types FROM v_catalog.user_functions WHERE function_name ILIKE '%json%';
-- ERROR: Severity: ERROR, Message: Column "argument_data_types" does not exist, Sqlstate: 42703, Routine: transformSQLColumnRef, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Optimizer/OptUtil/ExprUtil.cpp, Line: 7401, Error Code: 2624, 
SELECT schema_name, function_name, procedure_type FROM v_catalog.user_functions WHERE function_name ILIKE '%json%';
-- schema_name | function_name | procedure_type
-- ------------+---------------+---------------
-- public | KafkaJsonParser | User Defined Parser
-- public | JsonExport | User Defined Transform
-- public | JsonExportMulti | User Defined Transform
-- public | ST_GeomFromGeoJSON | User Defined Function
-- public | ST_GeomFromGeoJSON | User Defined Function
-- public | STV_AsGeoJSON | User Defined Function
-- public | STV_AsGeoJSON | User Defined Function
-- public | STV_AsGeoJSON | User Defined Function
-- public | FJSONParser | User Defined Parser
-- public | MapJSONExtractor | User Defined Function

CREATE OR REPLACE PROCEDURE U_PRJ_ECOM.PROC_RAW_VTEX_SEASA_TRADEIN_FEED()
LANGUAGE PLvSQL AS $$
BEGIN
  
  -- Create temporary table to stage data
  PERFORM CREATE LOCAL TEMP TABLE TMP_VTEX_SEASA_TRADEIN_FEED ON COMMIT PRESERVE ROWS AS
  (
    SELECT 
       a.ORDER_ID,
       a.CREATION_DATE,
       a.HOSTNAME,
       a.UNIQUE_ID AS UNIQUEID,
       a.SKU_ID AS SKUID,
       a.PRODUCT_ID AS PRODUCTID,
       a.EAN,
       a.REF_ID AS REFID,
       a.DEVICE_BRAND AS BRAND_DEVICE,
       a.DEVICE_MODEL AS MODEL_DEVICE,
       a.DEVICE_VALUE/100.0 AS TRADE_IN_DISCOUNT_DEVICE ,
       CURRENT_TIMESTAMP AS INSERT_DATE, 
       CURRENT_TIMESTAMP AS LAST_UPDATE_DATE
    FROM (
      -- Device 1
      SELECT
          a.order_id,
          b.CREATION_TIMESTAMP AS CREATION_DATE,
          b.HOSTNAME,
          a.UNIQUE_ID,
          a.SKU_ID,
          a.REF_ID AS REF_ID,
          a.PRODUCT_ID,
          a.EAN,
          -- cleaned JSON text
          REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}') AS CLEAN_ATTACH,
          -- fields from device1
          REGEXP_SUBSTR(REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}'), '"bonoTotal"[[:space:]]*:[[:space:]]*"?([^",}]+)"?', 1, 1, '', 1) AS bonoTotal,
          REGEXP_SUBSTR(REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}'), '"device1"[^}]*"type"[[:space:]]*:[[:space:]]*"?([^",}]+)"?', 1, 1, '', 1) AS device_type,
          REGEXP_SUBSTR(REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}'), '"device1"[^}]*"brand"[[:space:]]*:[[:space:]]*"?([^",}]+)"?', 1, 1, '', 1) AS device_brand,
          REGEXP_SUBSTR(REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}'), '"device1"[^}]*"value"[[:space:]]*:[[:space:]]*"?([^",}]+)"?', 1, 1, '', 1) AS device_value,
          REGEXP_SUBSTR(REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}'), '"device1"[^}]*"model"[[:space:]]*:[[:space:]]*"?([^",}]+)"?', 1, 1, '', 1) AS device_model,
          CASE WHEN POSITION('"device1"' IN REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}')) > 0 THEN 1 ELSE 0 END AS tradeIn
      FROM U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER_ITEM a
      LEFT JOIN U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER b ON a.ORDER_ID = b.ORDER_ID 
      WHERE a.attachments IS NOT NULL
      UNION ALL
      -- Device 2
      SELECT
          a.order_id,
          b.CREATION_TIMESTAMP AS CREATION_DATE,
          b.HOSTNAME,
          a.UNIQUE_ID,
          a.SKU_ID,
          a.REF_ID AS REF_ID,
          a.PRODUCT_ID,
          a.EAN,
          REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}') AS CLEAN_ATTACH,
          REGEXP_SUBSTR(REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}'), '"bonoTotal"[[:space:]]*:[[:space:]]*"?([^",}]+)"?', 1, 1, '', 1) AS bonoTotal,
          REGEXP_SUBSTR(REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}'), '"device2"[^}]*"type"[[:space:]]*:[[:space:]]*"?([^",}]+)"?', 1, 1, '', 1) AS device_type,
          REGEXP_SUBSTR(REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}'), '"device2"[^}]*"brand"[[:space:]]*:[[:space:]]*"?([^",}]+)"?', 1, 1, '', 1) AS device_brand,
          REGEXP_SUBSTR(REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}'), '"device2"[^}]*"value"[[:space:]]*:[[:space:]]*"?([^",}]+)"?', 1, 1, '', 1) AS device_value,
          REGEXP_SUBSTR(REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}'), '"device2"[^}]*"model"[[:space:]]*:[[:space:]]*"?([^",}]+)"?', 1, 1, '', 1) AS device_model,
          CASE WHEN POSITION('"device2"' IN REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}')) > 0 THEN 1 ELSE 0 END AS tradeIn
      FROM U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER_ITEM a
      LEFT JOIN U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER b ON a.ORDER_ID = b.ORDER_ID 
      WHERE a.attachments IS NOT NULL
    ) a
    WHERE a.TRADEIN = 1
      AND a.CREATION_DATE IS NOT NULL
      AND NOT EXISTS (
        SELECT 1
        FROM U_PRJ_ECOM.RAW_VTEX_SEASA_TRADEIN_FEED aa
        WHERE aa.ORDER_ID = a.ORDER_ID
          AND aa.REFID = a.REF_ID
      )
  );

  -- Insert into RAW table
  PERFORM INSERT INTO U_PRJ_ECOM.RAW_VTEX_SEASA_TRADEIN_FEED
  (
    SELECT DISTINCT 
      ORDER_ID,
      CREATION_DATE,
      HOSTNAME,
      UNIQUEID,
      SKUID,
      PRODUCTID,
      EAN,
      REFID,
      BRAND_DEVICE,
      MODEL_DEVICE,
      -- cast value to numeric if text
      CASE WHEN REGEXP_LIKE(TRADE_IN_DISCOUNT_DEVICE::VARCHAR, '^[0-9]+(\.[0-9]+)?$') THEN TRADE_IN_DISCOUNT_DEVICE ELSE NULL END,
      INSERT_DATE,
      LAST_UPDATE_DATE
    FROM (
      SELECT 
        ORDER_ID,
        CREATION_DATE,
        HOSTNAME,
        UNIQUEID,
        SKUID,
        PRODUCTID,
        EAN,
        REFID,
        device_brand AS BRAND_DEVICE,
        device_model AS MODEL_DEVICE,
        CASE WHEN device_value ~ '^[0-9]+(\.[0-9]+)?$' THEN (device_value)::NUMERIC / 100.0 ELSE NULL END AS TRADE_IN_DISCOUNT_DEVICE,
        CURRENT_TIMESTAMP AS INSERT_DATE,
        CURRENT_TIMESTAMP AS LAST_UPDATE_DATE
      FROM TMP_VTEX_SEASA_TRADEIN_FEED
    ) tmp
    WHERE tmp.ORDER_ID IS NOT NULL
      AND NOT EXISTS (
        SELECT 1
        FROM U_PRJ_ECOM.RAW_VTEX_SEASA_TRADEIN_FEED aa
        WHERE aa.ORDER_ID = tmp.ORDER_ID
          AND aa.REFID = tmp.REFID
      )
  );

  -- Drop temporary table
  PERFORM DROP TABLE IF EXISTS TMP_VTEX_SEASA_TRADEIN_FEED;

END;
$$;

-- CALL U_PRJ_ECOM.PROC_RAW_VTEX_SEASA_TRADEIN_FEED();
-- ERROR: Severity: ERROR, Message: Column "device_brand" does not exist, Sqlstate: 42703, Where: PL/vSQL procedure PROC_RAW_VTEX_SEASA_TRADEIN_FEED line 77 at static SQL, Routine: transformSQLColumnRef, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Optimizer/OptUtil/ExprUtil.cpp, Line: 7401, Error Code: 2624, 
-- CALL U_PRJ_ECOM.PROC_RAW_VTEX_SEASA_TRADEIN_FEED();
-- ERROR: Severity: ERROR, Message: Column "device_brand" does not exist, Sqlstate: 42703, Where: PL/vSQL procedure PROC_RAW_VTEX_SEASA_TRADEIN_FEED line 77 at static SQL, Routine: transformSQLColumnRef, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Optimizer/OptUtil/ExprUtil.cpp, Line: 7401, Error Code: 2624, 
CREATE OR REPLACE PROCEDURE U_PRJ_ECOM.PROC_RAW_VTEX_SEASA_TRADEIN_FEED()
LANGUAGE PLvSQL AS $$
BEGIN
  
  -- Stage data in a local temp table
  PERFORM CREATE LOCAL TEMP TABLE TMP_VTEX_SEASA_TRADEIN_FEED ON COMMIT PRESERVE ROWS AS
  SELECT 
       a.ORDER_ID,
       a.CREATION_DATE,
       a.HOSTNAME,
       a.UNIQUE_ID AS UNIQUEID,
       a.SKU_ID AS SKUID,
       a.PRODUCT_ID AS PRODUCTID,
       a.EAN,
       a.REF_ID AS REFID,
       a.DEVICE_BRAND AS BRAND_DEVICE,
       a.DEVICE_MODEL AS MODEL_DEVICE,
       CASE WHEN REGEXP_LIKE(a.DEVICE_VALUE_STR, '^[0-9]+(\.[0-9]+)?$') THEN CAST(a.DEVICE_VALUE_STR AS NUMERIC)/100.0 ELSE NULL END AS TRADE_IN_DISCOUNT_DEVICE,
       CURRENT_TIMESTAMP AS INSERT_DATE, 
       CURRENT_TIMESTAMP AS LAST_UPDATE_DATE
  FROM (
      -- Device 1
      SELECT
          a.order_id,
          b.CREATION_TIMESTAMP AS CREATION_DATE,
          b.HOSTNAME,
          a.UNIQUE_ID,
          a.SKU_ID,
          a.REF_ID AS REF_ID,
          a.PRODUCT_ID,
          a.EAN,
          REGEXP_REPLACE(
            REGEXP_SUBSTR(REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}'),
                           '"device1"[^}]*"brand"\s*:\s*"[^",}]+' ),
            '^.*"brand"\s*:\s*"', ''
          ) AS DEVICE_BRAND,
          REGEXP_REPLACE(
            REGEXP_SUBSTR(REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}'),
                           '"device1"[^}]*"model"\s*:\s*"[^",}]+' ),
            '^.*"model"\s*:\s*"', ''
          ) AS DEVICE_MODEL,
          REGEXP_REPLACE(
            REGEXP_SUBSTR(REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}'),
                           '"device1"[^}]*"value"\s*:\s*"?[^",}]+' ),
            '^.*"value"\s*:\s*"?', ''
          ) AS DEVICE_VALUE_STR,
          CASE WHEN POSITION('"device1"' IN REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}')) > 0 THEN 1 ELSE 0 END AS tradeIn
      FROM U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER_ITEM a
      LEFT JOIN U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER b ON a.ORDER_ID = b.ORDER_ID 
      WHERE a.attachments IS NOT NULL
      UNION ALL
      -- Device 2
      SELECT
          a.order_id,
          b.CREATION_TIMESTAMP AS CREATION_DATE,
          b.HOSTNAME,
          a.UNIQUE_ID,
          a.SKU_ID,
          a.REF_ID AS REF_ID,
          a.PRODUCT_ID,
          a.EAN,
          REGEXP_REPLACE(
            REGEXP_SUBSTR(REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}'),
                           '"device2"[^}]*"brand"\s*:\s*"[^",}]+' ),
            '^.*"brand"\s*:\s*"', ''
          ) AS DEVICE_BRAND,
          REGEXP_REPLACE(
            REGEXP_SUBSTR(REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}'),
                           '"device2"[^}]*"model"\s*:\s*"[^",}]+' ),
            '^.*"model"\s*:\s*"', ''
          ) AS DEVICE_MODEL,
          REGEXP_REPLACE(
            REGEXP_SUBSTR(REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}'),
                           '"device2"[^}]*"value"\s*:\s*"?[^",}]+' ),
            '^.*"value"\s*:\s*"?', ''
          ) AS DEVICE_VALUE_STR,
          CASE WHEN POSITION('"device2"' IN REPLACE(REPLACE(REPLACE(a.attachments, CHR(92), ''), '"{', '{'), '}"', '}')) > 0 THEN 1 ELSE 0 END AS tradeIn
      FROM U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER_ITEM a
      LEFT JOIN U_PRJ_ECOM.RAW_VTEX_SSG_AR_SALES_ORDER b ON a.ORDER_ID = b.ORDER_ID 
      WHERE a.attachments IS NOT NULL
  ) a
  WHERE a.TRADEIN = 1
    AND a.CREATION_DATE IS NOT NULL 
    AND NOT EXISTS (
      SELECT 1
      FROM U_PRJ_ECOM.RAW_VTEX_SEASA_TRADEIN_FEED aa
      WHERE aa.ORDER_ID = a.ORDER_ID
        AND aa.REFID = a.REF_ID
    );
  
  -- Insert into RAW table (dedupe safeguard)
  PERFORM INSERT INTO U_PRJ_ECOM.RAW_VTEX_SEASA_TRADEIN_FEED
  SELECT DISTINCT 
    ORDER_ID,
    CREATION_DATE,
    HOSTNAME,
    UNIQUEID,
    SKUID,
    PRODUCTID,
    EAN,
    REFID,
    BRAND_DEVICE,
    MODEL_DEVICE,
    TRADE_IN_DISCOUNT_DEVICE,
    INSERT_DATE,
    LAST_UPDATE_DATE
  FROM TMP_VTEX_SEASA_TRADEIN_FEED tmp
  WHERE tmp.ORDER_ID IS NOT NULL
    AND NOT EXISTS (
      SELECT 1
      FROM U_PRJ_ECOM.RAW_VTEX_SEASA_TRADEIN_FEED aa
      WHERE aa.ORDER_ID = tmp.ORDER_ID
        AND aa.REFID = tmp.REFID
    );

  -- Drop temporary table
  PERFORM DROP TABLE IF EXISTS TMP_VTEX_SEASA_TRADEIN_FEED;

END;
$$;

CALL U_PRJ_ECOM.PROC_RAW_VTEX_SEASA_TRADEIN_FEED();
-- PROC_RAW_VTEX_SEASA_TRADEIN_FEED
-- --------------------------------
-- 0

