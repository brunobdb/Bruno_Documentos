CREATE OR REPLACE PROCEDURE OW_LAO.PROC_D2C_PAYMENT_ITAU(
    IN p_DATE_INI DATE,
    IN p_DATE_FIM DATE
)
LANGUAGE PLvSQL AS $$
BEGIN
    -- parameter temp table
    PERFORM DROP TABLE IF EXISTS TMP_PARAMETER_PAYMENT_ITAU;
    PERFORM CREATE LOCAL TEMP TABLE TMP_PARAMETER_PAYMENT_ITAU ON COMMIT PRESERVE ROWS AS
        SELECT (CURRENT_DATE - 7) AS DATE_INI,
               (CURRENT_DATE + 2) AS DATE_FIM;

    PERFORM UPDATE TMP_PARAMETER_PAYMENT_ITAU
       SET DATE_INI = COALESCE(p_DATE_INI, (CURRENT_DATE - 7)),
           DATE_FIM = COALESCE(p_DATE_FIM, (CURRENT_DATE + 2));

    -- adjusted temp table
    PERFORM DROP TABLE IF EXISTS TMP_PAYMENT_ITAU_AJUSTADO;
    PERFORM CREATE LOCAL TEMP TABLE TMP_PAYMENT_ITAU_AJUSTADO ON COMMIT PRESERVE ROWS AS
    WITH CTE_TMP_PARAMETER_PAYMENT_ITAU AS (
        SELECT DATE_INI, DATE_FIM FROM TMP_PARAMETER_PAYMENT_ITAU
    ),
    CTE_TMP_D2C_PAYMENT_ITAU AS (
        SELECT
            VT.ORDER_ID,
            VT.SEQUENCE,
            VT.STATUS_PO,
            VT.DATE_REF,
            VT.YYYYWW,
            VT.YYYYMM,
            VT.YYYYQQ,
            VT.PO_CREATION_DATE,
            VT.PO_WEEK_DAY_NUM,
            VT.PO_WEEK_DAY_NAME,
            VT.PO_HOUR,
            VT.SUBSIDIARY,
            VT.AFFILIATE_ID_ADJUSTED,
            VT.AFFILIATE_CHANNEL,
            VT.AFFILIATE_SUB_CHANNEL,
            VT.AFFILIATE_PARTNER_LEVEL,
            '{"ORDER_ID": "' || BSO.ORDER_ID || '", "SEQUENCE":"' || BSO.SEQUENCE || '", "JSON": ' ||
                COALESCE(
                    NULLIF(EPO_APP0_TRANSACTION, ''),
                    NULLIF(SSO_APP0_TRANSACTION, ''),
                    NULLIF(BSO_APP0_TRANSACTION, ''),
                    NULLIF(B2B_APP0_TRANSACTION, ''),
                    ''
                )
            || '}' AS JSON_CUSTOM_DATA
        FROM (
            SELECT 
                  ORDER_ID,
                  SEQUENCE,
                  STATUS_PO,
                  DATE_REF,
                  YYYYWW,
                  YYYYMM,
                  YYYYQQ,
                  PO_CREATION_DATE,
                  PO_WEEK_DAY_NUM,
                  PO_WEEK_DAY_NAME,
                  PO_HOUR,
                  SALES_CHANNEL,
                  SUBSIDIARY,
                  AFFILIATE_ID_ADJUSTED,
                  AFFILIATE_CHANNEL,
                  AFFILIATE_SUB_CHANNEL,
                  AFFILIATE_PARTNER_LEVEL
            FROM (
                SELECT DISTINCT S.*  
                FROM OW_LAO.TF_D2C_NERP_SALES AS S 
                INNER JOIN ( 
                              SELECT DISTINCT ORDER_ID
                              FROM OW_LAO.TF_D2C_PAYMENT_ITAU
                              WHERE VALUE IS NULL 
                           ) I
                   ON S.ORDER_ID = I.ORDER_ID
                WHERE S.SOURCE = 'PO'
                  AND S.SUBSIDIARY = 'SEDA'
                UNION 
                SELECT DISTINCT S.*  
                FROM OW_LAO.TF_D2C_NERP_SALES AS S 
                WHERE S.SOURCE = 'PO'
                  AND S.SUBSIDIARY = 'SEDA'
                  AND DATE_REF BETWEEN (SELECT DATE_INI FROM CTE_TMP_PARAMETER_PAYMENT_ITAU)
                                    AND (SELECT DATE_FIM FROM CTE_TMP_PARAMETER_PAYMENT_ITAU)
            ) T
            WHERE "SOURCE" = 'PO'
              AND SUBSIDIARY = 'SEDA'
            GROUP BY
                  ORDER_ID,
                  SEQUENCE,
                  STATUS_PO,
                  DATE_REF,
                  YYYYWW,
                  YYYYMM,
                  YYYYQQ,
                  PO_CREATION_DATE,
                  PO_WEEK_DAY_NUM,
                  PO_WEEK_DAY_NAME,
                  PO_HOUR,
                  SALES_CHANNEL,
                  SUBSIDIARY,
                  AFFILIATE_ID_ADJUSTED,
                  AFFILIATE_CHANNEL,
                  AFFILIATE_SUB_CHANNEL,
                  AFFILIATE_PARTNER_LEVEL
        ) VT
        INNER JOIN (
            SELECT 
                ORDER_ID,
                MARKETPLACE_ORDER_ID,
                SEQUENCE,
                CASE 
                    WHEN CUSTOM_DATA LIKE '%"transaction"%'
                    THEN REGEXP_SUBSTR(CUSTOM_DATA,
                        '"customApps"\s*:\s*\[\s*\{[\s\S]*?"id"\s*:\s*"([^"]*)"',
                        1, 1, 'c', 1)
                    ELSE ''
                END AS BSO_APP0_ID,
                CASE 
                    WHEN CUSTOM_DATA LIKE '%"transaction"%'
                    THEN REGEXP_SUBSTR(CUSTOM_DATA,
                        '"customApps"\s*:\s*\[\s*\{[\s\S]*?"fields"\s*:\s*\{[\s\S]*?"transaction"\s*:\s*"([^"]*)"',
                        1, 1, 'c', 1)
                    ELSE ''
                END AS BSO_APP0_TRANSACTION
            FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER
        ) BSO
            ON BSO.ORDER_ID = VT.ORDER_ID
        LEFT JOIN (
            SELECT DISTINCT  
                ORDER_ID,
                CASE 
                    WHEN CUSTOM_DATA LIKE '%"transaction"%'
                    THEN REGEXP_SUBSTR(CUSTOM_DATA,
                        '"customApps"\s*:\s*\[\s*\{[\s\S]*?"id"\s*:\s*"([^"]*)"',
                        1, 1, 'c', 1)
                    ELSE ''
                END AS SSO_APP0_ID,
                CASE 
                    WHEN CUSTOM_DATA LIKE '%"transaction"%'
                    THEN REGEXP_SUBSTR(CUSTOM_DATA,
                        '"customApps"\s*:\s*\[\s*\{[\s\S]*?"fields"\s*:\s*\{[\s\S]*?"transaction"\s*:\s*"([^"]*)"',
                        1, 1, 'c', 1)
                    ELSE ''
                END AS SSO_APP0_TRANSACTION
            FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SALES_ORDER 
            WHERE CUSTOM_DATA IS NOT NULL        
        ) SSO
            ON BSO.MARKETPLACE_ORDER_ID = SSO.ORDER_ID
        LEFT JOIN (
            SELECT 
                ORDER_ID,
                CASE 
                    WHEN CUSTOM_DATA LIKE '%"transaction"%'
                    THEN REGEXP_SUBSTR(CUSTOM_DATA,
                        '"customApps"\s*:\s*\[\s*\{[\s\S]*?"id"\s*:\s*"([^"]*)"',
                        1, 1, 'c', 1)
                    ELSE ''
                END AS EPO_APP0_ID,
                CASE 
                    WHEN CUSTOM_DATA LIKE '%"transaction"%'
                    THEN REGEXP_SUBSTR(CUSTOM_DATA,
                        '"customApps"\s*:\s*\[\s*\{[\s\S]*?"fields"\s*:\s*\{[\s\S]*?"transaction"\s*:\s*"([^"]*)"',
                        1, 1, 'c', 1)
                    ELSE ''
                END AS EPO_APP0_TRANSACTION
            FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_EPP2_SALES_ORDER 
            WHERE CUSTOM_DATA IS NOT NULL 
        ) EPO
            ON BSO.MARKETPLACE_ORDER_ID = EPO.ORDER_ID
        LEFT JOIN (
            SELECT 
                ORDER_ID,
                CASE 
                    WHEN CUSTOM_DATA LIKE '%"transaction"%'
                    THEN REGEXP_SUBSTR(CUSTOM_DATA,
                        '"customApps"\s*:\s*\[\s*\{[\s\S]*?"id"\s*:\s*"([^"]*)"',
                        1, 1, 'c', 1)
                    ELSE ''
                END AS B2B_APP0_ID,
                CASE 
                    WHEN CUSTOM_DATA LIKE '%"transaction"%'
                    THEN REGEXP_SUBSTR(CUSTOM_DATA,
                        '"customApps"\s*:\s*\[\s*\{[\s\S]*?"fields"\s*:\s*\{[\s\S]*?"transaction"\s*:\s*"([^"]*)"',
                        1, 1, 'c', 1)
                    ELSE ''
                END AS B2B_APP0_TRANSACTION
            FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_B2B_SALES_ORDER 
            WHERE CUSTOM_DATA IS NOT NULL 
        ) B2B
            ON BSO.MARKETPLACE_ORDER_ID = B2B.ORDER_ID
        WHERE 
            COALESCE(
                NULLIF(EPO_APP0_ID, ''),
                NULLIF(SSO_APP0_ID, ''),
                NULLIF(BSO_APP0_ID, ''),
                NULLIF(B2B_APP0_ID, ''),
                ''
            ) = 'itau-transaction'
    ),
    CTE_CURSOR_SELECT_JSON AS (
        SELECT JSON_CUSTOM_DATA FROM CTE_TMP_D2C_PAYMENT_ITAU
    ),
    CTE_TMP_JSON AS (
        SELECT 
            REGEXP_SUBSTR(JSON_CUSTOM_DATA, '"ORDER_ID"\s*:\s*"([^"]*)"', 1, 1, 'c', 1) AS ORDER_ID,
            REGEXP_SUBSTR(JSON_CUSTOM_DATA, '"SEQUENCE"\s*:\s*"([^"]*)"', 1, 1, 'c', 1) AS "SEQUENCE",
            REGEXP_SUBSTR(JSON_CUSTOM_DATA, '"payments"\s*:\s*\[[\s\S]*?\{[\s\S]*?"value"\s*:\s*"?([0-9\.]+)"?', 1, 1, 'c', 1) AS VALUE,
            REGEXP_SUBSTR(JSON_CUSTOM_DATA, '"payments"\s*:\s*\[[\s\S]*?\{[\s\S]*?"paymentSystemName"\s*:\s*"([^"]*)"', 1, 1, 'c', 1) AS PAYMENTSYSTEMNAME,
            REGEXP_SUBSTR(JSON_CUSTOM_DATA, '"payments"\s*:\s*\[[\s\S]*?\{[\s\S]*?"installments"\s*:\s*"?([0-9]+)"?', 1, 1, 'c', 1) AS INSTALLMENTS,
            REGEXP_SUBSTR(JSON_CUSTOM_DATA, '"connectorResponses"\s*:\s*\{[\s\S]*?"authId"\s*:\s*"([^"]*)"', 1, 1, 'c', 1) AS AUTHID,
            REGEXP_SUBSTR(JSON_CUSTOM_DATA, '"connectorResponses"\s*:\s*\{[\s\S]*?"Tid"\s*:\s*"([^"]*)"', 1, 1, 'c', 1) AS TID
        FROM CTE_CURSOR_SELECT_JSON
    ),
    CTE_TF_D2C_PAYMENT_ITAU AS (
        SELECT PM.ORDER_ID,
               PM.SEQUENCE,
               PM.STATUS_PO,
               PM.DATE_REF,
               PM.YYYYWW,
               PM.YYYYMM,
               PM.YYYYQQ,
               PM.PO_CREATION_DATE,
               PM.PO_WEEK_DAY_NUM,
               PM.PO_WEEK_DAY_NAME,
               PM.PO_HOUR,
               PM.SUBSIDIARY,
               PM.AFFILIATE_ID_ADJUSTED,
               PM.AFFILIATE_CHANNEL,
               PM.AFFILIATE_SUB_CHANNEL,
               PM.AFFILIATE_PARTNER_LEVEL,
               JD.VALUE,
               JD.PAYMENTSYSTEMNAME,
               JD.INSTALLMENTS,
               JD.AUTHID,
               JD.TID
        FROM      CTE_TMP_D2C_PAYMENT_ITAU AS PM
        LEFT JOIN CTE_TMP_JSON            AS JD
               ON PM.ORDER_ID = JD.ORDER_ID
              AND PM.SEQUENCE = JD."SEQUENCE"
    ),
    CTE_TF_D2C_PAYMENT_ITAU_FINAL AS (
        SELECT T.*,
               CASE WHEN P.ORDER_ID IS NULL THEN 'N' ELSE 'S' END AS IND_EXCLUI
        FROM      CTE_TF_D2C_PAYMENT_ITAU    AS T
        LEFT JOIN OW_LAO.TF_D2C_PAYMENT_ITAU AS P
               ON T.ORDER_ID = P.ORDER_ID
    )
    SELECT DISTINCT * FROM CTE_TF_D2C_PAYMENT_ITAU_FINAL;

    -- delete existing orders marked to exclude
    PERFORM DELETE FROM OW_LAO.TF_D2C_PAYMENT_ITAU
     WHERE ORDER_ID IN (
        SELECT DISTINCT ORDER_ID
          FROM TMP_PAYMENT_ITAU_AJUSTADO 
         WHERE IND_EXCLUI = 'S'
    );

    -- insert new/updated rows
    PERFORM INSERT INTO OW_LAO.TF_D2C_PAYMENT_ITAU (
          ORDER_ID,
          "SEQUENCE",
          STATUS_PO,
          DATE_REF,
          YYYYWW,
          YYYYMM,
          YYYYQQ,
          PO_CREATION_DATE,
          PO_WEEK_DAY_NUM,
          PO_WEEK_DAY_NAME,
          PO_HOUR,
          SUBSIDIARY,
          AFFILIATE_ID_ADJUSTED,
          AFFILIATE_CHANNEL,
          AFFILIATE_SUB_CHANNEL,
          AFFILIATE_PARTNER_LEVEL,
          VALUE,
          PAYMENTSYSTEMNAME,
          INSTALLMENTS,
          AUTHID,
          TID
    )
    SELECT 
          P.ORDER_ID,
          P.SEQUENCE,
          P.STATUS_PO,
          P.DATE_REF,
          P.YYYYWW,
          P.YYYYMM,
          P.YYYYQQ,
          P.PO_CREATION_DATE,
          P.PO_WEEK_DAY_NUM,
          P.PO_WEEK_DAY_NAME,
          P.PO_HOUR,
          P.SUBSIDIARY,
          P.AFFILIATE_ID_ADJUSTED,
          P.AFFILIATE_CHANNEL,
          P.AFFILIATE_SUB_CHANNEL,
          P.AFFILIATE_PARTNER_LEVEL,
          P.VALUE,
          P.PAYMENTSYSTEMNAME,
          P.INSTALLMENTS,
          P.AUTHID,
          P.TID
      FROM TMP_PAYMENT_ITAU_AJUSTADO AS P;

    -- drop temp table
    PERFORM DROP TABLE IF EXISTS TMP_PAYMENT_ITAU_AJUSTADO;
    PERFORM DROP TABLE IF EXISTS TMP_PARAMETER_PAYMENT_ITAU;
END
$$;

CALL OW_LAO.PROC_D2C_PAYMENT_ITAU(NULL, NULL);
-- PROC_D2C_PAYMENT_ITAU
-- ---------------------
-- 0

