-- CREATE OR REPLACE PROCEDURE OW_SEDA_S.PRC_CE_UPDATE_ESES_ON_PIVOT()
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--     -- Build staging temp table
--     PERFORM CREATE LOCAL TEMP TABLE TMP_ESES_PIVOT ON COMMIT PRESERVE ROWS AS
--     SELECT 
--         COALESCE(SITE_ID, 'C820_47960950094517_SP') AS SITE_ID,
--         ITEM,
--         WEEKNUM,
--         SUM(SELL_OUT) AS SELL_OUT,
--         SUM(COALESCE(INVENTORY, 0)) AS INVENTORY,
--         0 AS STOCK_OUT,
--         0 AS DEAD_INVENTORY,
--         0 AS DEAD_SKU,
--         0 AS CHANNEL_INV,
--         0 AS CUST_SALES,
--         0 AS BOOKING_CONFIRMED,
--         AVG(RRP) AS RRP,
--         NULL AS ESTIMATED_SALES_LOST,
--         0 AS INV_WO_DISPLAY
--     FROM OW_SEDA_S.FT_CE_DAILY_PIVOT fcdp 
--     WHERE 1=1
--         AND SUBSTR(CAST(WEEKNUM AS VARCHAR), 1, 4) = '2023'
--         AND ACCOUNT LIKE '%E-SES%'
--         AND WEEKNUM <= (SELECT MAX(WEEKNUM) FROM OW_SEDA_S.FT_CE_PIVOT WHERE INVENTORY > 0)
--     GROUP BY
--         COALESCE(SITE_ID, 'C820_47960950094517_SP'), 
--         ITEM, 
--         WEEKNUM;
-- 
--     -- Delete existing rows for the same weeks and E-STORE accounts
--     PERFORM DELETE FROM OW_SEDA_S.FT_CE_PIVOT fcp 
--     WHERE 1=1
--         AND EXISTS (
--             SELECT 1 
--             FROM OW_SEDA_S.MAP_CE_STORES mcs 
--             WHERE mcs.SITE_ID = fcp.SITE_ID 
--               AND mcs.ACCOUNT IN ('E-STORE')
--         )
--         AND EXISTS (
--             SELECT 1 FROM TMP_ESES_PIVOT t WHERE t.WEEKNUM = fcp.WEEKNUM
--         );
-- 
--     -- Insert new aggregated rows
--     PERFORM INSERT INTO OW_SEDA_S.FT_CE_PIVOT
--     SELECT * FROM TMP_ESES_PIVOT;
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: Syntax error at or near "fcp", Sqlstate: 42601, Position: 1107, Routine: base_yyerror, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/scan.l, Line: 1056, Error Code: 4856, 
CREATE OR REPLACE PROCEDURE OW_SEDA_S.PRC_CE_UPDATE_ESES_ON_PIVOT()
LANGUAGE PLvSQL AS $$
BEGIN
    -- Build staging temp table
    PERFORM CREATE LOCAL TEMP TABLE TMP_ESES_PIVOT ON COMMIT PRESERVE ROWS AS
    SELECT 
        COALESCE(SITE_ID, 'C820_47960950094517_SP') AS SITE_ID,
        ITEM,
        WEEKNUM,
        SUM(SELL_OUT) AS SELL_OUT,
        SUM(COALESCE(INVENTORY, 0)) AS INVENTORY,
        0 AS STOCK_OUT,
        0 AS DEAD_INVENTORY,
        0 AS DEAD_SKU,
        0 AS CHANNEL_INV,
        0 AS CUST_SALES,
        0 AS BOOKING_CONFIRMED,
        AVG(RRP) AS RRP,
        NULL AS ESTIMATED_SALES_LOST,
        0 AS INV_WO_DISPLAY
    FROM OW_SEDA_S.FT_CE_DAILY_PIVOT fcdp 
    WHERE 1=1
        AND SUBSTR(CAST(WEEKNUM AS VARCHAR), 1, 4) = '2023'
        AND ACCOUNT LIKE '%E-SES%'
        AND WEEKNUM <= (SELECT MAX(WEEKNUM) FROM OW_SEDA_S.FT_CE_PIVOT WHERE INVENTORY > 0)
    GROUP BY
        COALESCE(SITE_ID, 'C820_47960950094517_SP'), 
        ITEM, 
        WEEKNUM;

    -- Delete existing rows for the same weeks and E-STORE accounts
    PERFORM DELETE FROM OW_SEDA_S.FT_CE_PIVOT
    WHERE 1=1
        AND EXISTS (
            SELECT 1 
            FROM OW_SEDA_S.MAP_CE_STORES mcs 
            WHERE mcs.SITE_ID = SITE_ID
              AND mcs.ACCOUNT IN ('E-STORE')
        )
        AND EXISTS (
            SELECT 1 FROM TMP_ESES_PIVOT t WHERE t.WEEKNUM = WEEKNUM
        );

    -- Insert new aggregated rows
    PERFORM INSERT INTO OW_SEDA_S.FT_CE_PIVOT
    SELECT * FROM TMP_ESES_PIVOT;
END;
$$;

CALL OW_SEDA_S.PRC_CE_UPDATE_ESES_ON_PIVOT();
-- PRC_CE_UPDATE_ESES_ON_PIVOT
-- ---------------------------
-- 0

