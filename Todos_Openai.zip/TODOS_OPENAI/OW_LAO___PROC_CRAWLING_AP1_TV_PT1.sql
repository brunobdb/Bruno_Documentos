CREATE OR REPLACE PROCEDURE PROC_CRAWLING_AP1_TV_PT1()
LANGUAGE PLvSQL AS $$
BEGIN
  
  PERFORM TRUNCATE TABLE TF_CRAWLING_AP1_TV_1;
  PERFORM INSERT INTO TF_CRAWLING_AP1_TV_1
  SELECT DISTINCT
    TRIM(UPPER(SUBSTR(D."PROD_BRAND",1,99))) AS brand_nm,
    SUBSTR(D."MODEL",1,99) AS model_nm,
    SUBSTR(D."DESC",1,99) AS model_desc,
    SUBSTR(P."SUB",1,99) AS subsidiary,
    SUBSTR(D."COUNTRY",1,99) AS country,
    SUBSTR(D."COUNTRY",1,99) AS country_code,
    SUBSTR(D."COMPANY_NAME",1,99) AS site_company_name,
    SUBSTR(P."SITE",1,99) AS site_nm,
    SUBSTR(D."PROD_HREF",1,499) AS site_url,
    SUBSTR(P."PAGE_NUMBER",1,99) AS site_page,
    SUBSTR(P."POSITION",1,99) AS site_position,
    SUBSTR(D."CURRENCY",1,99) AS site_price_currency,
    SUBSTR(DT."RATING",1,99) AS site_rating,
    SUBSTR(DT."RATING_AMOUNT",1,99) AS site_rating_amount,
    SUBSTR(DT."RATING_SCALE",1,99) AS site_rating_scale,
    SUBSTR(P."TODAY_DATE_TIME",1,99) AS refer_date,
    SUBSTR(P."POR_VALUE",1,16) AS price_unit,
    SUBSTR(D."MODEL2",1,99) AS MODEL2,
    SUBSTR(D."REF",1,99) AS REF,
    SUBSTR(D."REF2",1,99) AS REF2,
    SUBSTR(P."DE_VALUE",1,16) AS retail_price_base,
    SUBSTR(P."POR_VALUE",1,16) AS retail_price_actual,
    SUBSTR(P."TODAY_DATE_TIME",1,99) AS crawling_date,
    SUBSTR(P.AVAILABLE,1,99) AS product_available,
    NULL AS process_status,
    NULL AS comment_status,
    SUBSTR(D.LAST_UPDATE,1,99) AS product_update_date,
    NOW() AS process_datetime
  FROM "ODS_CRAWLING_AP1_IM_PRODUCT_DAILY_PRICE" P
  INNER JOIN "ODS_CRAWLING_AP1_CE_PRODUCT_DETAIL" D
    ON P."KEY" = D."KEY"
  LEFT JOIN "ODS_CRAWLING_AP1_TV_PRODUCT_DETAIL_DAILY" DT
    ON P."KEY" = DT."KEY" AND to_char(P."TODAY_DATE_TIME", 'YYYY-MM-DD') = to_char(DT."LOAD_DATE", 'YYYY-MM-DD')
  WHERE P."TODAY_DATE_TIME" > TIMESTAMP '2020-06-27 00:00:00'
    AND to_char(P."TODAY_DATE_TIME", 'YYYY-MM-DD') < to_char(CURRENT_DATE, 'YYYY-MM-DD')
    AND UPPER(TRIM(PRODUCT_TYPE)) = 'CE';

  PERFORM UPDATE "OW_LAO"."TF_CRAWLING_AP1_TV_1" ORIG
  SET  ORIG."RETAIL_PRICE_ACTUAL" = DEST."NEW_LIVER_ACT",
       ORIG."PRICE_UNIT" = DEST."NEW_LIVER_UNIT"
  FROM (
    SELECT
      LIVER."LIVER_URL",
      LIVER."LIVER_RETAIL_PRICE_BASE",
      LIVER."LIVER_RETAIL_PRICE_ACTUAL",
      LIVER."LIVER_UNIT_LEGTH",
      LIVER."LIVER_ACT_LEGTH",
      LIVER."LIVER_PRICE_UNIT",
      CASE WHEN CAST(LIVER."LIVER_ACT_LEGTH" AS INTEGER) >= CAST(AVG(LENGTH(MX."RETAIL_PRICE_ACTUAL")) + 1 AS INTEGER) THEN LIVER."LIVER_RETAIL_PRICE_BASE" ELSE LIVER."LIVER_RETAIL_PRICE_ACTUAL" END AS "NEW_LIVER_ACT",
      CASE WHEN CAST(LIVER."LIVER_UNIT_LEGTH" AS INTEGER) >= CAST(AVG(LENGTH(MX."PRICE_UNIT")) + 1 AS INTEGER) THEN LIVER."LIVER_RETAIL_PRICE_BASE" ELSE LIVER."LIVER_PRICE_UNIT" END AS "NEW_LIVER_UNIT"
    FROM "OW_LAO"."TF_CRAWLING_AP1_TV_1" MX
    INNER JOIN (
      SELECT 
        "SITE_URL" AS "LIVER_URL",
        LENGTH("PRICE_UNIT") AS "LIVER_UNIT_LEGTH",
        "PRICE_UNIT" AS "LIVER_PRICE_UNIT",
        LENGTH("RETAIL_PRICE_BASE") AS "LIVER_BASE_LEGTH",
        "RETAIL_PRICE_BASE" AS "LIVER_RETAIL_PRICE_BASE",
        LENGTH("RETAIL_PRICE_ACTUAL") AS "LIVER_ACT_LEGTH",
        "RETAIL_PRICE_ACTUAL" AS "LIVER_RETAIL_PRICE_ACTUAL"
      FROM "OW_LAO"."TF_CRAWLING_AP1_TV_1"
      WHERE  "SITE_URL" LIKE '%liverpoo%.mx%'
        AND ( 
              "PRICE_UNIT" != '0.0'
          AND "PRICE_UNIT" != '0'
          AND TRIM("PRICE_UNIT") != '' 
          AND "RETAIL_PRICE_ACTUAL" != '0.0'
          AND "RETAIL_PRICE_ACTUAL" != '0'
          AND TRIM("RETAIL_PRICE_ACTUAL") != '' 
            )
      GROUP BY "SITE_URL" ,"PRICE_UNIT","RETAIL_PRICE_BASE" ,"RETAIL_PRICE_ACTUAL"
    ) LIVER 
      ON 1=1
    WHERE MX."COUNTRY"='MX'
      AND ( 
            MX."PRICE_UNIT" != '0.0'
        AND MX."PRICE_UNIT" != '0'
        AND TRIM(MX."PRICE_UNIT") != '' 
        AND MX."RETAIL_PRICE_ACTUAL" != '0.0'
        AND MX."RETAIL_PRICE_ACTUAL" != '0'
        AND TRIM(MX."RETAIL_PRICE_ACTUAL") != '' 
          )              
    GROUP BY   
     LIVER."LIVER_URL" ,LIVER."LIVER_RETAIL_PRICE_BASE",LIVER."LIVER_RETAIL_PRICE_ACTUAL",LIVER."LIVER_UNIT_LEGTH",LIVER."LIVER_ACT_LEGTH",LIVER."LIVER_PRICE_UNIT"
  ) DEST 
  WHERE DEST."LIVER_URL" = ORIG."SITE_URL";

  PERFORM UPDATE TF_CRAWLING_AP1_TV_1
  SET 
    model_nm = CASE WHEN TRIM(model_nm) = '' OR model_nm IS NULL 
                    THEN SUBSTR(REPLACE(TRIM(site_url), TRIM(site_nm), ''), 1, 99)
                    ELSE TRIM(model_nm) END;

  PERFORM UPDATE TF_CRAWLING_AP1_TV_1
  SET
    site_rating = COALESCE(site_rating, '') ,
    site_rating_amount = COALESCE(site_rating_amount, '') ,
    site_rating_scale = COALESCE(site_rating_scale, '');

  PERFORM UPDATE TF_CRAWLING_AP1_TV_1
  SET
    site_rating = REGEXP_SUBSTR(UPPER(TRIM(REPLACE(site_rating, ',', '.'))), '[0-9]+(\\.[0-9]{1,2})?', 1, 1),
    site_rating_amount = REGEXP_SUBSTR(UPPER(TRIM(site_rating_amount)), '[0-9]+(\\.[0-9]{1,2})?', 1, 1),
    site_rating_scale = REGEXP_SUBSTR(UPPER(TRIM(site_rating_scale)), '[0-9]+(\\.[0-9]{1,2})?', 1, 1),
    price_unit = REGEXP_SUBSTR(UPPER(TRIM(price_unit)), '[0-9]+(\\.[0-9]{1,2})?', 1, 1),
    retail_price_base = REGEXP_SUBSTR(UPPER(TRIM(retail_price_base)), '[0-9]+(\\.[0-9]{1,2})?', 1, 1),
    retail_price_actual = REGEXP_SUBSTR(UPPER(TRIM(retail_price_actual)), '[0-9]+(\\.[0-9]{1,2})?', 1, 1);

  PERFORM TRUNCATE TABLE TF_CRAWLING_AP1_TV_2;
  PERFORM INSERT INTO TF_CRAWLING_AP1_TV_2
  SELECT
    UPPER(TRIM(INITCAP(brand_nm))) AS brand_nm,
    ' ' AS mktcode,
    ' ' AS mktname,
    model_nm AS model_nm,
    subsidiary,
    country,
    country_code,
    UPPER(TRIM(site_company_name)) AS site_company_name,
    site_nm,
    site_url,
    site_page,
    site_position,
    site_price_currency,
    CASE WHEN TRIM(site_rating) = '' THEN NULL ELSE TO_DECIMAL(site_rating, 8, 1) END AS site_rating , 
    CASE WHEN TRIM(site_rating_amount) = '' THEN NULL ELSE TO_DECIMAL(site_rating_amount, 8, 0) END AS site_rating_amount , 
    CASE WHEN TRIM(site_rating_scale) = '' THEN NULL ELSE TO_DECIMAL(site_rating_scale, 8, 0) END AS site_rating_scale ,
    TO_TIMESTAMP(refer_date, 'YYYY-MM-DD HH24:MI') AS refer_date,
    ROUND(MAX(retail_price_actual)::NUMERIC, 2) AS price_unit,
    ROUND(MAX(retail_price_base)::NUMERIC, 2) AS price_local_base,
    ROUND(MAX(retail_price_actual)::NUMERIC, 2) AS price_local_act,
    'Y' AS update_flg,
    CURRENT_TIMESTAMP
  FROM TF_CRAWLING_AP1_TV_1
  WHERE process_status IS NULL
  GROUP BY 
    UPPER(TRIM(INITCAP(brand_nm))),
    model_nm,
    subsidiary,
    country,
    country_code,
    UPPER(TRIM(site_company_name)),
    site_nm,
    site_url,
    site_page,
    site_position,
    site_price_currency,
    CASE WHEN TRIM(site_rating) = '' THEN NULL ELSE TO_DECIMAL(site_rating, 8, 1) END, 
    CASE WHEN TRIM(site_rating_amount) = '' THEN NULL ELSE TO_DECIMAL(site_rating_amount, 8, 0) END, 
    CASE WHEN TRIM(site_rating_scale) = '' THEN NULL ELSE TO_DECIMAL(site_rating_scale, 8, 0) END,
    TO_TIMESTAMP(refer_date, 'YYYY-MM-DD HH24:MI');

  PERFORM CALL PROC_CRAWLING_AP1_TV_SITE_MAPPING_MERGE_AUTOMATIC();

  PERFORM TRUNCATE TABLE FT_CRAWLING_AP1_TV_DISPLAY_SHARE;
  
  PERFORM INSERT INTO FT_CRAWLING_AP1_TV_DISPLAY_SHARE
  SELECT * 
  FROM VW_CRAWLING_AP1_TV_DISPLAY_SHARE;
  
  PERFORM TRUNCATE TABLE FT_CRAWLING_AP1_TV_SEGMENT;
  
  PERFORM INSERT INTO FT_CRAWLING_AP1_TV_SEGMENT                            
  SELECT A.* 
       , NULL AS REFER_WEEK
       , NULL AS REFER_WEEK_T
       , NULL AS REFER_YEAR,
         CASE WHEN B.GFK_BRAND_TV IS NULL THEN 'NO' ELSE 'YES' END AS "GFK_BrandList"
  FROM "OW_LAO".VW_CRAWLING_AP1_TV_SEGMENT A
  LEFT JOIN "OW_LAO"."DIM_GFK_BRAND_TV" B ON (TRIM(A."UPPER(BRAND_NM)") = TRIM(B.GFK_BRAND_TV));
 
  PERFORM UPDATE OW_LAO.FT_CRAWLING_AP1_TV_SEGMENT F
  SET
    REFER_WEEK = (SELECT DISTINCT YYYYWW FROM OW_MD.DIM_CALENDAR D WHERE to_char(F.REFER_DATE,'YYYY-MM-DD') = to_char(D.YYYYMMDD,'YYYY-MM-DD')),
    REFER_WEEK_T = (SELECT DISTINCT 'W' || RIGHT(YYYYWW,2) FROM OW_MD.DIM_CALENDAR D WHERE to_char(F.REFER_DATE,'YYYY-MM-DD') = to_char(D.YYYYMMDD,'YYYY-MM-DD')),
    REFER_YEAR = (SELECT DISTINCT YYYY FROM OW_MD.DIM_CALENDAR D WHERE to_char(F.REFER_DATE,'YYYY-MM-DD') = to_char(D.YYYYMMDD,'YYYY-MM-DD'))
  WHERE REFER_WEEK IS NULL;

  PERFORM UPDATE "OW_LAO"."FT_CRAWLING_AP1_TV_SEGMENT"
  SET "SITE_RATING" = "SITE_RATING" / 1000000000000
  WHERE LENGTH(CAST("SITE_RATING" AS VARCHAR)) > 11;
END;
$$;

-- CALL PROC_CRAWLING_AP1_TV_PT1();
-- ERROR: Severity: ROLLBACK, Message: Table "TF_CRAWLING_AP1_TV_1" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_CRAWLING_AP1_TV_PT1 line 4 at static SQL, Routine: TruncateTable, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Commands/DDL.cpp, Line: 20681, Error Code: 4876, 
-- CALL PROC_CRAWLING_AP1_TV_PT1();
-- ERROR: Severity: ROLLBACK, Message: Table "TF_CRAWLING_AP1_TV_1" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure PROC_CRAWLING_AP1_TV_PT1 line 4 at static SQL, Routine: TruncateTable, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Commands/DDL.cpp, Line: 20681, Error Code: 4876, 
