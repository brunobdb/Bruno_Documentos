CREATE OR REPLACE PROCEDURE OW_LAO.proc_tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_homolog()
LANGUAGE PLvSQL AS $$
BEGIN

  -- Refresh filter table (prefer truncate over drop/create)
  PERFORM TRUNCATE TABLE ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter;

  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter
    (id, po_sku, sales_org, currency, country, po_status, po_orderid, po_date, filterType)
  SELECT DISTINCT
         a.po_sequence_orderid    AS id
       , a.po_sku
       , b.sales_org
       , a.currency
       , a.country
       , a.po_status
       , a.po_orderid
       , CAST(a.po_date AS DATE)  AS po_date
       , 1                        AS filterType
    FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown            a
    JOIN ow_md.dim_subsidiary                            b ON LOWER(b.country) = LOWER(a.country)
    JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking c ON c.customer_po    = a.po_sequence_orderid
                                                           AND c.material       = a.po_sku
                                                           AND c.sales_org      = b.sales_org
   WHERE nerp_last_update_date < c.last_modification_file
      OR nerp_last_update_date IS NULL

  UNION ALL    

  SELECT DISTINCT
         a.po_ordersid            AS id
       , a.po_sku
       , b.sales_org
       , a.currency
       , a.country
       , a.po_status
       , a.po_orderid
       , CAST(a.po_date AS DATE)  AS po_date
       , 2                        AS filterType
    FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown            a
    JOIN ow_md.dim_subsidiary                            b ON LOWER(b.country) = LOWER(a.country)
    JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking c ON c.sales_document = a.po_ordersid
                                                           AND c.material       = a.po_sku
                                                           AND c.sales_org      = b.sales_org
   WHERE nerp_last_update_date < c.last_modification_file
      OR nerp_last_update_date IS NULL

  UNION ALL    

  SELECT DISTINCT
         a.po_orderid             AS id
       , a.po_sku
       , b.sales_org
       , a.currency
       , a.country
       , a.po_status
       , a.po_orderid
       , CAST(a.po_date AS DATE)  AS po_date
       , 3                        AS filterType
    FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown            a
    JOIN ow_md.dim_subsidiary                            b ON LOWER(b.country) = LOWER(a.country)
    JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking c ON c.customer_po    = a.po_orderid
                                                           AND c.material       = a.po_sku
                                                           AND c.sales_org      = b.sales_org
   WHERE nerp_last_update_date < c.last_modification_file
      OR nerp_last_update_date IS NULL;

  PERFORM TRUNCATE TABLE ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update;

  -- Type 1 and 3
  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update            
    SELECT a.id
         , a.po_orderid
         , a.po_sku
         , c.sales_document
         , c.sold_to_party
         , c.name
         , c.material
         , c.item_descr
         , c.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE CAST(REPLACE(e.so_net_price, ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_price   
         , 0.00                                                                                                                                      AS so_net_value
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE  CAST(REPLACE(c.cost       , ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END AS cost
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL) AS margin_rate
         , c.so_curr
         , c.so_create_on
         , c.sales_org
         , c.distr_channel
         , c.plant
         , c.stor_loc
         , c.account_code
         , c.account_name
         , c.gc_id_gscm
         , c.gc_name
         , c.ap1_code
         , c.ap1_name
         , c.ap2_code
         , c.ap2_name
         , c.delivery
         , 0                                                                  AS delivery_qty_base
         , c.billed_qty_base
         , c.billing_date
         , c.material_group
         , c.so_local_create_on_d
         , c.do_local_create_on_d
         , c."1ST_GI_LOCAL_CREATE"
         , c.billing_local_create
         , c.final_sch_date
         , MAX(e.last_modification_file)                                      AS last_modification_file
         , a.filterType
         , 'Returned'                                                         AS po_status
      FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter a
      JOIN ow_md.dim_subsidiary                                         b ON LOWER(b.country)    = LOWER(a.country)
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c ON c.customer_po       = a.id
                                                                           AND c.material          = a.po_sku
                                                                           AND c.sales_org         = b.sales_org
                                                                           AND c.delivery_qty_base < 0  
 LEFT JOIN ow_lao.ft_ap2_exchange_rate                                  d ON d.valid_from        = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE))
                                                                           AND d.to_currency       = a.currency
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e ON e.customer_po       = a.id
                                                                           AND e.material          = a.po_sku
                                                                           AND e.sales_org         = b.sales_org
                                                                           AND e.delivery_qty_base >= 0
     WHERE a.filterType IN (1, 3)
       AND (c.delivery_qty_base + e.delivery_qty_base) <= 0
  GROUP BY a.id
         , a.po_orderid
         , a.po_sku
         , c.sales_document
         , c.sold_to_party
         , c.name
         , c.material
         , c.item_descr
         , c.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE CAST(REPLACE(e.so_net_price, ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE  CAST(REPLACE(c.cost       , ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL)
         , c.so_curr
         , c.so_create_on
         , c.sales_org
         , c.distr_channel
         , c.plant
         , c.stor_loc
         , c.account_code
         , c.account_name
         , c.gc_id_gscm
         , c.gc_name
         , c.ap1_code
         , c.ap1_name
         , c.ap2_code
         , c.ap2_name
         , c.delivery
         , c.billed_qty_base
         , c.billing_date
         , c.material_group
         , c.so_local_create_on_d
         , c.do_local_create_on_d
         , c."1ST_GI_LOCAL_CREATE"
         , c.billing_local_create
         , c.final_sch_date
         , a.filterType;    

  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update            
    SELECT a.id
         , a.po_orderid
         , a.po_sku
         , e.sales_document
         , e.sold_to_party
         , e.name
         , e.material
         , e.item_descr
         , e.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE (CAST(REPLACE(e.so_net_price, ',', '') AS DECIMAL)                                                    ) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_price   
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE (CAST(REPLACE(c.so_net_value, ',', '') AS DECIMAL) + CAST(REPLACE(e.so_net_value, ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_value
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE  CAST(REPLACE(c.cost        , ',', '') AS DECIMAL)                                                      / CAST(d.exchange_rate AS DECIMAL) END AS cost
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL) AS margin_rate
         , e.so_curr
         , e.so_create_on
         , e.sales_org
         , e.distr_channel
         , e.plant
         , e.stor_loc
         , e.account_code
         , e.account_name
         , e.gc_id_gscm
         , e.gc_name
         , e.ap1_code
         , e.ap1_name
         , e.ap2_code
         , e.ap2_name
         , e.delivery
         , c.delivery_qty_base + e.delivery_qty_base        AS delivery_qty_base
         , e.billed_qty_base
         , e.billing_date
         , e.material_group
         , e.so_local_create_on_d
         , e.do_local_create_on_d
         , e."1ST_GI_LOCAL_CREATE"
         , e.billing_local_create
         , e.final_sch_date
         , e.last_modification_file
         , a.filterType
         , a.po_status
      FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter a
      JOIN ow_md.dim_subsidiary                                         b ON LOWER(b.country)    = LOWER(a.country)
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c ON c.customer_po       = a.id
                                                                           AND c.material          = a.po_sku
                                                                           AND c.sales_org         = b.sales_org
                                                                           AND c.delivery_qty_base < 0  
 LEFT JOIN ow_lao.ft_ap2_exchange_rate                                  d ON d.valid_from        = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE))
                                                                           AND d.to_currency       = a.currency
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e ON e.customer_po       = a.id
                                                                           AND e.material          = a.po_sku
                                                                           AND e.sales_org         = b.sales_org
                                                                           AND e.delivery_qty_base >= 0
     WHERE a.filterType IN (1, 3)
       AND (c.delivery_qty_base + e.delivery_qty_base) > 0;

  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update  
    SELECT a.id
         , a.po_orderid
         , a.po_sku
         , c.sales_document
         , c.sold_to_party
         , c.name
         , c.material
         , c.item_descr
         , c.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE ABS(CAST(REPLACE(c.so_net_price, ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_price
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE ABS(CAST(REPLACE(c.so_net_value, ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_value
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE CAST(REPLACE(c.cost            , ',', '') AS DECIMAL)  / CAST(d.exchange_rate AS DECIMAL) END AS cost
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL)                                                                                              AS margin_rate
         , c.so_curr
         , c.so_create_on
         , c.sales_org
         , c.distr_channel
         , c.plant
         , c.stor_loc
         , c.account_code
         , c.account_name
         , c.gc_id_gscm
         , c.gc_name
         , c.ap1_code
         , c.ap1_name
         , c.ap2_code
         , c.ap2_name
         , c.delivery
         , ABS(c.delivery_qty_base)                                      AS delivery_qty_base
         , c.billed_qty_base
         , c.billing_date
         , c.material_group
         , c.so_local_create_on_d
         , c.do_local_create_on_d
         , c."1ST_GI_LOCAL_CREATE"
         , c.billing_local_create
         , c.final_sch_date
         , c.last_modification_file
         , a.filterType
         , CASE WHEN c.delivery_qty_base < 0 THEN 'Returned' ELSE a.po_status END AS po_status
      FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter a
      JOIN ow_md.dim_subsidiary                                         b ON LOWER(b.country)    = LOWER(a.country)
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c ON c.customer_po       = a.id
                                                                           AND c.material          = a.po_sku
                                                                           AND c.sales_org         = b.sales_org
 LEFT JOIN ow_lao.ft_ap2_exchange_rate                                  d ON d.valid_from        = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE))
                                                                           AND d.to_currency       = a.currency
     WHERE a.filterType IN (1, 3)
       AND NOT EXISTS(
                SELECT 1
                  FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update aa
                 WHERE c.customer_po       = aa.id
                   AND c.material          = aa.po_sku
                   AND c.sales_org         = aa.sales_org
                   AND a.filterType        = aa.filterType
           );

  -- Type 2
  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update            
    SELECT a.id
         , a.po_orderid
         , a.po_sku
         , c.sales_document
         , c.sold_to_party
         , c.name
         , c.material
         , c.item_descr
         , c.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE CAST(REPLACE(e.so_net_price, ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_price   
         , 0.00                                                              AS so_net_value
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE  CAST(REPLACE(c.cost       , ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END AS cost
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL) AS margin_rate
         , c.so_curr
         , c.so_create_on
         , c.sales_org
         , c.distr_channel
         , c.plant
         , c.stor_loc
         , c.account_code
         , c.account_name
         , c.gc_id_gscm
         , c.gc_name
         , c.ap1_code
         , c.ap1_name
         , c.ap2_code
         , c.ap2_name
         , c.delivery
         , 0                                                                  AS delivery_qty_base
         , c.billed_qty_base
         , c.billing_date
         , c.material_group
         , c.so_local_create_on_d
         , c.do_local_create_on_d
         , c."1ST_GI_LOCAL_CREATE"
         , c.billing_local_create
         , c.final_sch_date
         , MAX(e.last_modification_file)                                      AS last_modification_file
         , a.filterType
         , 'Returned'                                                         AS po_status
      FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter a
      JOIN ow_md.dim_subsidiary                                         b ON LOWER(b.country)    = LOWER(a.country)
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c ON c.sales_document    = a.id
                                                                           AND c.material          = a.po_sku
                                                                           AND c.sales_org         = b.sales_org
                                                                           AND c.delivery_qty_base < 0  
 LEFT JOIN ow_lao.ft_ap2_exchange_rate                                  d ON d.valid_from        = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE))
                                                                           AND d.to_currency       = a.currency
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e ON e.sales_document    = a.id
                                                                           AND e.material          = a.po_sku
                                                                           AND e.sales_org         = b.sales_org
                                                                           AND e.delivery_qty_base >= 0
     WHERE a.filterType IN (2)
       AND (c.delivery_qty_base + e.delivery_qty_base) <= 0
  GROUP BY a.id
         , a.po_orderid
         , a.po_sku
         , c.sales_document
         , c.sold_to_party
         , c.name
         , c.material
         , c.item_descr
         , c.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE CAST(REPLACE(e.so_net_price, ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE  CAST(REPLACE(c.cost       , ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL)
         , c.so_curr
         , c.so_create_on
         , c.sales_org
         , c.distr_channel
         , c.plant
         , c.stor_loc
         , c.account_code
         , c.account_name
         , c.gc_id_gscm
         , c.gc_name
         , c.ap1_code
         , c.ap1_name
         , c.ap2_code
         , c.ap2_name
         , c.delivery
         , c.billed_qty_base
         , c.billing_date
         , c.material_group
         , c.so_local_create_on_d
         , c.do_local_create_on_d
         , c."1ST_GI_LOCAL_CREATE"
         , c.billing_local_create
         , c.final_sch_date
         , a.filterType;       

  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update            
    SELECT a.id
         , a.po_orderid
         , a.po_sku
         , e.sales_document
         , e.sold_to_party
         , e.name
         , e.material
         , e.item_descr
         , e.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE (CAST(REPLACE(e.so_net_price, ',', '') AS DECIMAL)                                                    ) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_price   
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE (CAST(REPLACE(c.so_net_value, ',', '') AS DECIMAL) + CAST(REPLACE(e.so_net_value, ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_value
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE  CAST(REPLACE(c.cost        , ',', '') AS DECIMAL)                                                      / CAST(d.exchange_rate AS DECIMAL) END AS cost
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL) AS margin_rate
         , e.so_curr
         , e.so_create_on
         , e.sales_org
         , e.distr_channel
         , e.plant
         , e.stor_loc
         , e.account_code
         , e.account_name
         , e.gc_id_gscm
         , e.gc_name
         , e.ap1_code
         , e.ap1_name
         , e.ap2_code
         , e.ap2_name
         , e.delivery
         , c.delivery_qty_base + e.delivery_qty_base        AS delivery_qty_base
         , e.billed_qty_base
         , e.billing_date
         , e.material_group
         , e.so_local_create_on_d
         , e.do_local_create_on_d
         , e."1ST_GI_LOCAL_CREATE"
         , e.billing_local_create
         , e.final_sch_date
         , e.last_modification_file
         , a.filterType
         , a.po_status
      FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter a
      JOIN ow_md.dim_subsidiary                                         b ON LOWER(b.country)    = LOWER(a.country)
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c ON c.sales_document    = a.id
                                                                           AND c.material          = a.po_sku
                                                                           AND c.sales_org         = b.sales_org
                                                                           AND c.delivery_qty_base < 0  
 LEFT JOIN ow_lao.ft_ap2_exchange_rate                                  d ON d.valid_from        = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE))
                                                                           AND d.to_currency       = a.currency
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e ON e.sales_document    = a.id
                                                                           AND e.material          = a.po_sku
                                                                           AND e.sales_org         = b.sales_org
                                                                           AND e.delivery_qty_base >= 0
     WHERE a.filterType IN (2)
       AND (c.delivery_qty_base + e.delivery_qty_base) > 0;

  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update  
    SELECT a.id
         , a.po_orderid
         , a.po_sku
         , c.sales_document
         , c.sold_to_party
         , c.name
         , c.material
         , c.item_descr
         , c.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE ABS(CAST(REPLACE(c.so_net_price, ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_price
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE ABS(CAST(REPLACE(c.so_net_value, ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_value
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE ABS(CAST(REPLACE(c.cost        , ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS cost
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL)                                                                                              AS margin_rate
         , c.so_curr
         , c.so_create_on
         , c.sales_org
         , c.distr_channel
         , c.plant
         , c.stor_loc
         , c.account_code
         , c.account_name
         , c.gc_id_gscm
         , c.gc_name
         , c.ap1_code
         , c.ap1_name
         , c.ap2_code
         , c.ap2_name
         , c.delivery
         , ABS(c.delivery_qty_base)                                                AS delivery_qty_base
         , c.billed_qty_base
         , c.billing_date
         , c.material_group
         , c.so_local_create_on_d
         , c.do_local_create_on_d
         , c."1ST_GI_LOCAL_CREATE"
         , c.billing_local_create
         , c.final_sch_date
         , c.last_modification_file
         , a.filterType
         , CASE WHEN c.delivery_qty_base < 0 THEN 'Returned' ELSE a.po_status END AS po_status
      FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter a
      JOIN ow_md.dim_subsidiary                                         b ON LOWER(b.country)    = LOWER(a.country)
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c ON c.sales_document    = a.id
                                                                           AND c.material          = a.po_sku
                                                                           AND c.sales_org         = b.sales_org
 LEFT JOIN ow_lao.ft_ap2_exchange_rate                                  d ON d.valid_from        = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE))
                                                                           AND d.to_currency       = a.currency
     WHERE a.filterType IN (2)
       AND NOT EXISTS(
                SELECT 1
                  FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update aa
                 WHERE c.sales_document    = aa.id
                   AND c.material          = aa.po_sku
                   AND c.sales_org         = aa.sales_org
                   AND a.filterType        = aa.filterType
           );           

  -- Update base table with latest NERP snapshot
  PERFORM UPDATE ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown a
     SET so_idcode             = c.sales_document
       , po_status             = c.po_status
       , soldto_party          = c.sold_to_party
       , soldto_name           = c.name
       , nerp_sku              = c.material
       , nerp_sku_description  = c.item_descr
       , nerp_sku_division     = c.item_division
       , nerp_netprice         = CASE WHEN c.so_net_price < 0 THEN 0 ELSE c.so_net_price END
       , nerp_netvalue         = CASE WHEN c.so_net_value < 0 THEN 0 ELSE c.so_net_value END
       , nerp_cost             = c.cost
       , nerp_marginrate       = c.margin_rate
       , nerp_currency         = c.so_curr
       , so_date_kst           = c.so_create_on
       , nerp_countrycode      = c.sales_org
       , nerp_distchannel      = c.distr_channel
       , nerp_plant            = c.plant
       , nerp_storagelocation  = c.stor_loc
       , nerp_accountcode      = c.account_code
       , nerp_accountname      = c.account_name
       , nerp_id_gscm          = c.gc_id_gscm
       , nerp_gc_name          = c.gc_name
       , nerp_ap1_code         = c.ap1_code
       , nerp_ap1_name         = c.ap1_name
       , nerp_ap2_code         = c.ap2_code
       , nerp_ap2_name         = c.ap2_name
       , nerp_deliverycode     = c.delivery
       , nerp_deliveruqty      = c.delivery_qty_base
       , nerp_billingqty       = c.billed_qty_base
       , nerp_billingdate      = c.billing_date
       , nerp_material_group   = c.material_group
       , so_date               = c.so_local_create_on_d
       , do_date               = c.do_local_create_on_d
       , "1GI_DATE"           = c."1ST_GI_LOCAL_CREATE"
       , billing_date_local    = c.billing_local_create
       , final_date            = c.final_sch_date
       , nerp_last_update_date = c.last_modification_file
       , updated_datetime      = CURRENT_TIMESTAMP
    FROM ow_md.dim_subsidiary b
    JOIN ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update c 
      ON c.material       = a.po_sku
     AND c.po_orderid     = a.po_orderid
    LEFT JOIN ow_lao.ft_ap2_exchange_rate d 
      ON d.valid_from     = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE))
     AND d.to_currency    = a.currency
   WHERE LOWER(b.country) = LOWER(a.country)
     AND c.sales_org      = b.sales_org
     AND (a.nerp_last_update_date < c.last_modification_file OR a.nerp_last_update_date IS NULL);

END;
$$;

-- CALL OW_LAO.proc_tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_homolog();
-- ERROR: Severity: ERROR, Message: Operator does not exist: timestamp < varchar, Sqlstate: 42883, Hint: No operator matches the given name and argument type(s). You may need to add explicit type casts, Where: PL/vSQL procedure proc_tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_homolog line 7 at static SQL, Routine: op_error, File: parse_oper.c, Line: 608, Error Code: 4286, 
-- CALL OW_LAO.proc_tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_homolog();
-- ERROR: Severity: ERROR, Message: Operator does not exist: timestamp < varchar, Sqlstate: 42883, Hint: No operator matches the given name and argument type(s). You may need to add explicit type casts, Where: PL/vSQL procedure proc_tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_homolog line 7 at static SQL, Routine: op_error, File: parse_oper.c, Line: 608, Error Code: 4286, 
CREATE OR REPLACE PROCEDURE OW_LAO.proc_tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_homolog()
LANGUAGE PLvSQL AS $$
BEGIN

  -- Refresh filter table (prefer truncate over drop/create)
  PERFORM TRUNCATE TABLE ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter;

  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter
    (id, po_sku, sales_org, currency, country, po_status, po_orderid, po_date, filterType)
  SELECT DISTINCT
         a.po_sequence_orderid    AS id
       , a.po_sku
       , b.sales_org
       , a.currency
       , a.country
       , a.po_status
       , a.po_orderid
       , CAST(a.po_date AS DATE)  AS po_date
       , 1                        AS filterType
    FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown            a
    JOIN ow_md.dim_subsidiary                            b ON LOWER(b.country) = LOWER(a.country)
    JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking c ON c.customer_po    = a.po_sequence_orderid
                                                           AND c.material       = a.po_sku
                                                           AND c.sales_org      = b.sales_org
   WHERE a.nerp_last_update_date < CAST(c.last_modification_file AS TIMESTAMP)
      OR a.nerp_last_update_date IS NULL

  UNION ALL    

  SELECT DISTINCT
         a.po_ordersid            AS id
       , a.po_sku
       , b.sales_org
       , a.currency
       , a.country
       , a.po_status
       , a.po_orderid
       , CAST(a.po_date AS DATE)  AS po_date
       , 2                        AS filterType
    FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown            a
    JOIN ow_md.dim_subsidiary                            b ON LOWER(b.country) = LOWER(a.country)
    JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking c ON c.sales_document = a.po_ordersid
                                                           AND c.material       = a.po_sku
                                                           AND c.sales_org      = b.sales_org
   WHERE a.nerp_last_update_date < CAST(c.last_modification_file AS TIMESTAMP)
      OR a.nerp_last_update_date IS NULL

  UNION ALL    

  SELECT DISTINCT
         a.po_orderid             AS id
       , a.po_sku
       , b.sales_org
       , a.currency
       , a.country
       , a.po_status
       , a.po_orderid
       , CAST(a.po_date AS DATE)  AS po_date
       , 3                        AS filterType
    FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown            a
    JOIN ow_md.dim_subsidiary                            b ON LOWER(b.country) = LOWER(a.country)
    JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking c ON c.customer_po    = a.po_orderid
                                                           AND c.material       = a.po_sku
                                                           AND c.sales_org      = b.sales_org
   WHERE a.nerp_last_update_date < CAST(c.last_modification_file AS TIMESTAMP)
      OR a.nerp_last_update_date IS NULL;

  PERFORM TRUNCATE TABLE ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update;

  -- Type 1 and 3
  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update            
    SELECT a.id
         , a.po_orderid
         , a.po_sku
         , c.sales_document
         , c.sold_to_party
         , c.name
         , c.material
         , c.item_descr
         , c.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE CAST(REPLACE(e.so_net_price, ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_price   
         , 0.00                                                                                                                                      AS so_net_value
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE  CAST(REPLACE(c.cost       , ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END AS cost
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL) AS margin_rate
         , c.so_curr
         , c.so_create_on
         , c.sales_org
         , c.distr_channel
         , c.plant
         , c.stor_loc
         , c.account_code
         , c.account_name
         , c.gc_id_gscm
         , c.gc_name
         , c.ap1_code
         , c.ap1_name
         , c.ap2_code
         , c.ap2_name
         , c.delivery
         , 0                                                                  AS delivery_qty_base
         , c.billed_qty_base
         , c.billing_date
         , c.material_group
         , c.so_local_create_on_d
         , c.do_local_create_on_d
         , c."1ST_GI_LOCAL_CREATE"
         , c.billing_local_create
         , c.final_sch_date
         , MAX(e.last_modification_file)                                      AS last_modification_file
         , a.filterType
         , 'Returned'                                                         AS po_status
      FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter a
      JOIN ow_md.dim_subsidiary                                         b ON LOWER(b.country)    = LOWER(a.country)
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c ON c.customer_po       = a.id
                                                                           AND c.material          = a.po_sku
                                                                           AND c.sales_org         = b.sales_org
                                                                           AND c.delivery_qty_base < 0  
 LEFT JOIN ow_lao.ft_ap2_exchange_rate                                  d ON d.valid_from        = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE))
                                                                           AND d.to_currency       = a.currency
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e ON e.customer_po       = a.id
                                                                           AND e.material          = a.po_sku
                                                                           AND e.sales_org         = b.sales_org
                                                                           AND e.delivery_qty_base >= 0
     WHERE a.filterType IN (1, 3)
       AND (c.delivery_qty_base + e.delivery_qty_base) <= 0
  GROUP BY a.id
         , a.po_orderid
         , a.po_sku
         , c.sales_document
         , c.sold_to_party
         , c.name
         , c.material
         , c.item_descr
         , c.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE CAST(REPLACE(e.so_net_price, ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE  CAST(REPLACE(c.cost       , ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL)
         , c.so_curr
         , c.so_create_on
         , c.sales_org
         , c.distr_channel
         , c.plant
         , c.stor_loc
         , c.account_code
         , c.account_name
         , c.gc_id_gscm
         , c.gc_name
         , c.ap1_code
         , c.ap1_name
         , c.ap2_code
         , c.ap2_name
         , c.delivery
         , c.billed_qty_base
         , c.billing_date
         , c.material_group
         , c.so_local_create_on_d
         , c.do_local_create_on_d
         , c."1ST_GI_LOCAL_CREATE"
         , c.billing_local_create
         , c.final_sch_date
         , a.filterType;    

  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update            
    SELECT a.id
         , a.po_orderid
         , a.po_sku
         , e.sales_document
         , e.sold_to_party
         , e.name
         , e.material
         , e.item_descr
         , e.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE (CAST(REPLACE(e.so_net_price, ',', '') AS DECIMAL)                                                    ) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_price   
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE (CAST(REPLACE(c.so_net_value, ',', '') AS DECIMAL) + CAST(REPLACE(e.so_net_value, ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_value
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE  CAST(REPLACE(c.cost        , ',', '') AS DECIMAL)                                                      / CAST(d.exchange_rate AS DECIMAL) END AS cost
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL) AS margin_rate
         , e.so_curr
         , e.so_create_on
         , e.sales_org
         , e.distr_channel
         , e.plant
         , e.stor_loc
         , e.account_code
         , e.account_name
         , e.gc_id_gscm
         , e.gc_name
         , e.ap1_code
         , e.ap1_name
         , e.ap2_code
         , e.ap2_name
         , e.delivery
         , c.delivery_qty_base + e.delivery_qty_base        AS delivery_qty_base
         , e.billed_qty_base
         , e.billing_date
         , e.material_group
         , e.so_local_create_on_d
         , e.do_local_create_on_d
         , e."1ST_GI_LOCAL_CREATE"
         , e.billing_local_create
         , e.final_sch_date
         , e.last_modification_file
         , a.filterType
         , a.po_status
      FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter a
      JOIN ow_md.dim_subsidiary                                         b ON LOWER(b.country)    = LOWER(a.country)
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c ON c.customer_po       = a.id
                                                                           AND c.material          = a.po_sku
                                                                           AND c.sales_org         = b.sales_org
                                                                           AND c.delivery_qty_base < 0  
 LEFT JOIN ow_lao.ft_ap2_exchange_rate                                  d ON d.valid_from        = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE))
                                                                           AND d.to_currency       = a.currency
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e ON e.customer_po       = a.id
                                                                           AND e.material          = a.po_sku
                                                                           AND e.sales_org         = b.sales_org
                                                                           AND e.delivery_qty_base >= 0
     WHERE a.filterType IN (1, 3)
       AND (c.delivery_qty_base + e.delivery_qty_base) > 0;

  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update  
    SELECT a.id
         , a.po_orderid
         , a.po_sku
         , c.sales_document
         , c.sold_to_party
         , c.name
         , c.material
         , c.item_descr
         , c.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE ABS(CAST(REPLACE(c.so_net_price, ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_price
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE ABS(CAST(REPLACE(c.so_net_value, ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_value
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE CAST(REPLACE(c.cost            , ',', '') AS DECIMAL)  / CAST(d.exchange_rate AS DECIMAL) END AS cost
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL)                                                                                              AS margin_rate
         , c.so_curr
         , c.so_create_on
         , c.sales_org
         , c.distr_channel
         , c.plant
         , c.stor_loc
         , c.account_code
         , c.account_name
         , c.gc_id_gscm
         , c.gc_name
         , c.ap1_code
         , c.ap1_name
         , c.ap2_code
         , c.ap2_name
         , c.delivery
         , ABS(c.delivery_qty_base)                                      AS delivery_qty_base
         , c.billed_qty_base
         , c.billing_date
         , c.material_group
         , c.so_local_create_on_d
         , c.do_local_create_on_d
         , c."1ST_GI_LOCAL_CREATE"
         , c.billing_local_create
         , c.final_sch_date
         , c.last_modification_file
         , a.filterType
         , CASE WHEN c.delivery_qty_base < 0 THEN 'Returned' ELSE a.po_status END AS po_status
      FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter a
      JOIN ow_md.dim_subsidiary                                         b ON LOWER(b.country)    = LOWER(a.country)
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c ON c.customer_po       = a.id
                                                                           AND c.material          = a.po_sku
                                                                           AND c.sales_org         = b.sales_org
 LEFT JOIN ow_lao.ft_ap2_exchange_rate                                  d ON d.valid_from        = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE))
                                                                           AND d.to_currency       = a.currency
     WHERE a.filterType IN (1, 3)
       AND NOT EXISTS(
                SELECT 1
                  FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update aa
                 WHERE c.customer_po       = aa.id
                   AND c.material          = aa.po_sku
                   AND c.sales_org         = aa.sales_org
                   AND a.filterType        = aa.filterType
           );

  -- Type 2
  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update            
    SELECT a.id
         , a.po_orderid
         , a.po_sku
         , c.sales_document
         , c.sold_to_party
         , c.name
         , c.material
         , c.item_descr
         , c.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE CAST(REPLACE(e.so_net_price, ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_price   
         , 0.00                                                              AS so_net_value
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE  CAST(REPLACE(c.cost       , ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END AS cost
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL) AS margin_rate
         , c.so_curr
         , c.so_create_on
         , c.sales_org
         , c.distr_channel
         , c.plant
         , c.stor_loc
         , c.account_code
         , c.account_name
         , c.gc_id_gscm
         , c.gc_name
         , c.ap1_code
         , c.ap1_name
         , c.ap2_code
         , c.ap2_name
         , c.delivery
         , 0                                                                  AS delivery_qty_base
         , c.billed_qty_base
         , c.billing_date
         , c.material_group
         , c.so_local_create_on_d
         , c.do_local_create_on_d
         , c."1ST_GI_LOCAL_CREATE"
         , c.billing_local_create
         , c.final_sch_date
         , MAX(e.last_modification_file)                                      AS last_modification_file
         , a.filterType
         , 'Returned'                                                         AS po_status
      FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter a
      JOIN ow_md.dim_subsidiary                                         b ON LOWER(b.country)    = LOWER(a.country)
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c ON c.sales_document    = a.id
                                                                           AND c.material          = a.po_sku
                                                                           AND c.sales_org         = b.sales_org
                                                                           AND c.delivery_qty_base < 0  
 LEFT JOIN ow_lao.ft_ap2_exchange_rate                                  d ON d.valid_from        = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE))
                                                                           AND d.to_currency       = a.currency
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e ON e.sales_document    = a.id
                                                                           AND e.material          = a.po_sku
                                                                           AND e.sales_org         = b.sales_org
                                                                           AND e.delivery_qty_base >= 0
     WHERE a.filterType IN (2)
       AND (c.delivery_qty_base + e.delivery_qty_base) <= 0
  GROUP BY a.id
         , a.po_orderid
         , a.po_sku
         , c.sales_document
         , c.sold_to_party
         , c.name
         , c.material
         , c.item_descr
         , c.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE CAST(REPLACE(e.so_net_price, ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE  CAST(REPLACE(c.cost       , ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL)
         , c.so_curr
         , c.so_create_on
         , c.sales_org
         , c.distr_channel
         , c.plant
         , c.stor_loc
         , c.account_code
         , c.account_name
         , c.gc_id_gscm
         , c.gc_name
         , c.ap1_code
         , c.ap1_name
         , c.ap2_code
         , c.ap2_name
         , c.delivery
         , c.billed_qty_base
         , c.billing_date
         , c.material_group
         , c.so_local_create_on_d
         , c.do_local_create_on_d
         , c."1ST_GI_LOCAL_CREATE"
         , c.billing_local_create
         , c.final_sch_date
         , a.filterType;       

  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update            
    SELECT a.id
         , a.po_orderid
         , a.po_sku
         , e.sales_document
         , e.sold_to_party
         , e.name
         , e.material
         , e.item_descr
         , e.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE (CAST(REPLACE(e.so_net_price, ',', '') AS DECIMAL)                                                    ) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_price   
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE (CAST(REPLACE(c.so_net_value, ',', '') AS DECIMAL) + CAST(REPLACE(e.so_net_value, ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_value
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE  CAST(REPLACE(c.cost        , ',', '') AS DECIMAL)                                                      / CAST(d.exchange_rate AS DECIMAL) END AS cost
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL) AS margin_rate
         , e.so_curr
         , e.so_create_on
         , e.sales_org
         , e.distr_channel
         , e.plant
         , e.stor_loc
         , e.account_code
         , e.account_name
         , e.gc_id_gscm
         , e.gc_name
         , e.ap1_code
         , e.ap1_name
         , e.ap2_code
         , e.ap2_name
         , e.delivery
         , c.delivery_qty_base + e.delivery_qty_base        AS delivery_qty_base
         , e.billed_qty_base
         , e.billing_date
         , e.material_group
         , e.so_local_create_on_d
         , e.do_local_create_on_d
         , e."1ST_GI_LOCAL_CREATE"
         , e.billing_local_create
         , e.final_sch_date
         , e.last_modification_file
         , a.filterType
         , a.po_status
      FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter a
      JOIN ow_md.dim_subsidiary                                         b ON LOWER(b.country)    = LOWER(a.country)
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c ON c.sales_document    = a.id
                                                                           AND c.material          = a.po_sku
                                                                           AND c.sales_org         = b.sales_org
                                                                           AND c.delivery_qty_base < 0  
 LEFT JOIN ow_lao.ft_ap2_exchange_rate                                  d ON d.valid_from        = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE))
                                                                           AND d.to_currency       = a.currency
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e ON e.sales_document    = a.id
                                                                           AND e.material          = a.po_sku
                                                                           AND e.sales_org         = b.sales_org
                                                                           AND e.delivery_qty_base >= 0
     WHERE a.filterType IN (2)
       AND (c.delivery_qty_base + e.delivery_qty_base) > 0;

  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update  
    SELECT a.id
         , a.po_orderid
         , a.po_sku
         , c.sales_document
         , c.sold_to_party
         , c.name
         , c.material
         , c.item_descr
         , c.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE ABS(CAST(REPLACE(c.so_net_price, ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_price
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE ABS(CAST(REPLACE(c.so_net_value, ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_value
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE ABS(CAST(REPLACE(c.cost        , ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS cost
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL)                                                                                              AS margin_rate
         , c.so_curr
         , c.so_create_on
         , c.sales_org
         , c.distr_channel
         , c.plant
         , c.stor_loc
         , c.account_code
         , c.account_name
         , c.gc_id_gscm
         , c.gc_name
         , c.ap1_code
         , c.ap1_name
         , c.ap2_code
         , c.ap2_name
         , c.delivery
         , ABS(c.delivery_qty_base)                                                AS delivery_qty_base
         , c.billed_qty_base
         , c.billing_date
         , c.material_group
         , c.so_local_create_on_d
         , c.do_local_create_on_d
         , c."1ST_GI_LOCAL_CREATE"
         , c.billing_local_create
         , c.final_sch_date
         , c.last_modification_file
         , a.filterType
         , CASE WHEN c.delivery_qty_base < 0 THEN 'Returned' ELSE a.po_status END AS po_status
      FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter a
      JOIN ow_md.dim_subsidiary                                         b ON LOWER(b.country)    = LOWER(a.country)
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c ON c.sales_document    = a.id
                                                                           AND c.material          = a.po_sku
                                                                           AND c.sales_org         = b.sales_org
 LEFT JOIN ow_lao.ft_ap2_exchange_rate                                  d ON d.valid_from        = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE))
                                                                           AND d.to_currency       = a.currency
     WHERE a.filterType IN (2)
       AND NOT EXISTS(
                SELECT 1
                  FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update aa
                 WHERE c.sales_document    = aa.id
                   AND c.material          = aa.po_sku
                   AND c.sales_org         = aa.sales_org
                   AND a.filterType        = aa.filterType
           );           

  -- Update base table with latest NERP snapshot
  PERFORM UPDATE ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown a
     SET so_idcode             = c.sales_document
       , po_status             = c.po_status
       , soldto_party          = c.sold_to_party
       , soldto_name           = c.name
       , nerp_sku              = c.material
       , nerp_sku_description  = c.item_descr
       , nerp_sku_division     = c.item_division
       , nerp_netprice         = CASE WHEN c.so_net_price < 0 THEN 0 ELSE c.so_net_price END
       , nerp_netvalue         = CASE WHEN c.so_net_value < 0 THEN 0 ELSE c.so_net_value END
       , nerp_cost             = c.cost
       , nerp_marginrate       = c.margin_rate
       , nerp_currency         = c.so_curr
       , so_date_kst           = c.so_create_on
       , nerp_countrycode      = c.sales_org
       , nerp_distchannel      = c.distr_channel
       , nerp_plant            = c.plant
       , nerp_storagelocation  = c.stor_loc
       , nerp_accountcode      = c.account_code
       , nerp_accountname      = c.account_name
       , nerp_id_gscm          = c.gc_id_gscm
       , nerp_gc_name          = c.gc_name
       , nerp_ap1_code         = c.ap1_code
       , nerp_ap1_name         = c.ap1_name
       , nerp_ap2_code         = c.ap2_code
       , nerp_ap2_name         = c.ap2_name
       , nerp_deliverycode     = c.delivery
       , nerp_deliveruqty      = c.delivery_qty_base
       , nerp_billingqty       = c.billed_qty_base
       , nerp_billingdate      = c.billing_date
       , nerp_material_group   = c.material_group
       , so_date               = c.so_local_create_on_d
       , do_date               = c.do_local_create_on_d
       , "1GI_DATE"           = c."1ST_GI_LOCAL_CREATE"
       , billing_date_local    = c.billing_local_create
       , final_date            = c.final_sch_date
       , nerp_last_update_date = CAST(c.last_modification_file AS TIMESTAMP)
       , updated_datetime      = CURRENT_TIMESTAMP
    FROM ow_md.dim_subsidiary b
    JOIN ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update c 
      ON c.material       = a.po_sku
     AND c.po_orderid     = a.po_orderid
    LEFT JOIN ow_lao.ft_ap2_exchange_rate d 
      ON d.valid_from     = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE))
     AND d.to_currency    = a.currency
   WHERE LOWER(b.country) = LOWER(a.country)
     AND c.sales_org      = b.sales_org
     AND (a.nerp_last_update_date < CAST(c.last_modification_file AS TIMESTAMP) OR a.nerp_last_update_date IS NULL);

END;
$$;

-- CALL OW_LAO.proc_tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_homolog();
-- ERROR: Severity: ERROR, Message: Operator does not exist: varchar = timestamp, Sqlstate: 42883, Hint: No operator matches the given name and argument type(s). You may need to add explicit type casts, Where: PL/vSQL procedure proc_tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_homolog line 70 at static SQL, Routine: op_error, File: parse_oper.c, Line: 608, Error Code: 4286, 
-- CALL OW_LAO.proc_tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_homolog();
-- ERROR: Severity: ERROR, Message: Operator does not exist: varchar = timestamp, Sqlstate: 42883, Hint: No operator matches the given name and argument type(s). You may need to add explicit type casts, Where: PL/vSQL procedure proc_tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_homolog line 70 at static SQL, Routine: op_error, File: parse_oper.c, Line: 608, Error Code: 4286, 
CREATE OR REPLACE PROCEDURE OW_LAO.proc_tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_homolog()
LANGUAGE PLvSQL AS $$
BEGIN

  -- Refresh filter table (prefer truncate over drop/create)
  PERFORM TRUNCATE TABLE ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter;

  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter
    (id, po_sku, sales_org, currency, country, po_status, po_orderid, po_date, filterType)
  SELECT DISTINCT
         a.po_sequence_orderid    AS id
       , a.po_sku
       , b.sales_org
       , a.currency
       , a.country
       , a.po_status
       , a.po_orderid
       , CAST(a.po_date AS DATE)  AS po_date
       , 1                        AS filterType
    FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown            a
    JOIN ow_md.dim_subsidiary                            b ON LOWER(b.country) = LOWER(a.country)
    JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking c ON c.customer_po    = a.po_sequence_orderid
                                                           AND c.material       = a.po_sku
                                                           AND c.sales_org      = b.sales_org
   WHERE a.nerp_last_update_date < CAST(c.last_modification_file AS TIMESTAMP)
      OR a.nerp_last_update_date IS NULL

  UNION ALL    

  SELECT DISTINCT
         a.po_ordersid            AS id
       , a.po_sku
       , b.sales_org
       , a.currency
       , a.country
       , a.po_status
       , a.po_orderid
       , CAST(a.po_date AS DATE)  AS po_date
       , 2                        AS filterType
    FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown            a
    JOIN ow_md.dim_subsidiary                            b ON LOWER(b.country) = LOWER(a.country)
    JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking c ON c.sales_document = a.po_ordersid
                                                           AND c.material       = a.po_sku
                                                           AND c.sales_org      = b.sales_org
   WHERE a.nerp_last_update_date < CAST(c.last_modification_file AS TIMESTAMP)
      OR a.nerp_last_update_date IS NULL

  UNION ALL    

  SELECT DISTINCT
         a.po_orderid             AS id
       , a.po_sku
       , b.sales_org
       , a.currency
       , a.country
       , a.po_status
       , a.po_orderid
       , CAST(a.po_date AS DATE)  AS po_date
       , 3                        AS filterType
    FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown            a
    JOIN ow_md.dim_subsidiary                            b ON LOWER(b.country) = LOWER(a.country)
    JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking c ON c.customer_po    = a.po_orderid
                                                           AND c.material       = a.po_sku
                                                           AND c.sales_org      = b.sales_org
   WHERE a.nerp_last_update_date < CAST(c.last_modification_file AS TIMESTAMP)
      OR a.nerp_last_update_date IS NULL;

  PERFORM TRUNCATE TABLE ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update;

  -- Type 1 and 3
  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update            
    SELECT a.id
         , a.po_orderid
         , a.po_sku
         , c.sales_document
         , c.sold_to_party
         , c.name
         , c.material
         , c.item_descr
         , c.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE CAST(REPLACE(e.so_net_price, ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_price   
         , 0.00                                                                                                                                      AS so_net_value
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE  CAST(REPLACE(c.cost       , ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END AS cost
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL) AS margin_rate
         , c.so_curr
         , c.so_create_on
         , c.sales_org
         , c.distr_channel
         , c.plant
         , c.stor_loc
         , c.account_code
         , c.account_name
         , c.gc_id_gscm
         , c.gc_name
         , c.ap1_code
         , c.ap1_name
         , c.ap2_code
         , c.ap2_name
         , c.delivery
         , 0                                                                  AS delivery_qty_base
         , c.billed_qty_base
         , c.billing_date
         , c.material_group
         , c.so_local_create_on_d
         , c.do_local_create_on_d
         , c."1ST_GI_LOCAL_CREATE"
         , c.billing_local_create
         , c.final_sch_date
         , MAX(e.last_modification_file)                                      AS last_modification_file
         , a.filterType
         , 'Returned'                                                         AS po_status
      FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter a
      JOIN ow_md.dim_subsidiary                                         b ON LOWER(b.country)    = LOWER(a.country)
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c ON c.customer_po       = a.id
                                                                           AND c.material          = a.po_sku
                                                                           AND c.sales_org         = b.sales_org
                                                                           AND c.delivery_qty_base < 0  
 LEFT JOIN ow_lao.ft_ap2_exchange_rate                                  d ON CAST(d.valid_from AS TIMESTAMP) = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS TIMESTAMP))
                                                                           AND d.to_currency       = a.currency
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e ON e.customer_po       = a.id
                                                                           AND e.material          = a.po_sku
                                                                           AND e.sales_org         = b.sales_org
                                                                           AND e.delivery_qty_base >= 0
     WHERE a.filterType IN (1, 3)
       AND (c.delivery_qty_base + e.delivery_qty_base) <= 0
  GROUP BY a.id
         , a.po_orderid
         , a.po_sku
         , c.sales_document
         , c.sold_to_party
         , c.name
         , c.material
         , c.item_descr
         , c.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE CAST(REPLACE(e.so_net_price, ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE  CAST(REPLACE(c.cost       , ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL)
         , c.so_curr
         , c.so_create_on
         , c.sales_org
         , c.distr_channel
         , c.plant
         , c.stor_loc
         , c.account_code
         , c.account_name
         , c.gc_id_gscm
         , c.gc_name
         , c.ap1_code
         , c.ap1_name
         , c.ap2_code
         , c.ap2_name
         , c.delivery
         , c.billed_qty_base
         , c.billing_date
         , c.material_group
         , c.so_local_create_on_d
         , c.do_local_create_on_d
         , c."1ST_GI_LOCAL_CREATE"
         , c.billing_local_create
         , c.final_sch_date
         , a.filterType;    

  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update            
    SELECT a.id
         , a.po_orderid
         , a.po_sku
         , e.sales_document
         , e.sold_to_party
         , e.name
         , e.material
         , e.item_descr
         , e.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE (CAST(REPLACE(e.so_net_price, ',', '') AS DECIMAL)                                                    ) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_price   
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE (CAST(REPLACE(c.so_net_value, ',', '') AS DECIMAL) + CAST(REPLACE(e.so_net_value, ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_value
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE  CAST(REPLACE(c.cost        , ',', '') AS DECIMAL)                                                      / CAST(d.exchange_rate AS DECIMAL) END AS cost
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL) AS margin_rate
         , e.so_curr
         , e.so_create_on
         , e.sales_org
         , e.distr_channel
         , e.plant
         , e.stor_loc
         , e.account_code
         , e.account_name
         , e.gc_id_gscm
         , e.gc_name
         , e.ap1_code
         , e.ap1_name
         , e.ap2_code
         , e.ap2_name
         , e.delivery
         , c.delivery_qty_base + e.delivery_qty_base        AS delivery_qty_base
         , e.billed_qty_base
         , e.billing_date
         , e.material_group
         , e.so_local_create_on_d
         , e.do_local_create_on_d
         , e."1ST_GI_LOCAL_CREATE"
         , e.billing_local_create
         , e.final_sch_date
         , e.last_modification_file
         , a.filterType
         , a.po_status
      FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter a
      JOIN ow_md.dim_subsidiary                                         b ON LOWER(b.country)    = LOWER(a.country)
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c ON c.customer_po       = a.id
                                                                           AND c.material          = a.po_sku
                                                                           AND c.sales_org         = b.sales_org
                                                                           AND c.delivery_qty_base < 0  
 LEFT JOIN ow_lao.ft_ap2_exchange_rate                                  d ON CAST(d.valid_from AS TIMESTAMP) = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS TIMESTAMP))
                                                                           AND d.to_currency       = a.currency
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e ON e.customer_po       = a.id
                                                                           AND e.material          = a.po_sku
                                                                           AND e.sales_org         = b.sales_org
                                                                           AND e.delivery_qty_base >= 0
     WHERE a.filterType IN (1, 3)
       AND (c.delivery_qty_base + e.delivery_qty_base) > 0;

  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update  
    SELECT a.id
         , a.po_orderid
         , a.po_sku
         , c.sales_document
         , c.sold_to_party
         , c.name
         , c.material
         , c.item_descr
         , c.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE ABS(CAST(REPLACE(c.so_net_price, ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_price
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE ABS(CAST(REPLACE(c.so_net_value, ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_value
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE CAST(REPLACE(c.cost            , ',', '') AS DECIMAL)  / CAST(d.exchange_rate AS DECIMAL) END AS cost
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL)                                                                                              AS margin_rate
         , c.so_curr
         , c.so_create_on
         , c.sales_org
         , c.distr_channel
         , c.plant
         , c.stor_loc
         , c.account_code
         , c.account_name
         , c.gc_id_gscm
         , c.gc_name
         , c.ap1_code
         , c.ap1_name
         , c.ap2_code
         , c.ap2_name
         , c.delivery
         , ABS(c.delivery_qty_base)                                      AS delivery_qty_base
         , c.billed_qty_base
         , c.billing_date
         , c.material_group
         , c.so_local_create_on_d
         , c.do_local_create_on_d
         , c."1ST_GI_LOCAL_CREATE"
         , c.billing_local_create
         , c.final_sch_date
         , c.last_modification_file
         , a.filterType
         , CASE WHEN c.delivery_qty_base < 0 THEN 'Returned' ELSE a.po_status END AS po_status
      FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter a
      JOIN ow_md.dim_subsidiary                                         b ON LOWER(b.country)    = LOWER(a.country)
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c ON c.customer_po       = a.id
                                                                           AND c.material          = a.po_sku
                                                                           AND c.sales_org         = b.sales_org
 LEFT JOIN ow_lao.ft_ap2_exchange_rate                                  d ON CAST(d.valid_from AS TIMESTAMP) = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS TIMESTAMP))
                                                                           AND d.to_currency       = a.currency
     WHERE a.filterType IN (1, 3)
       AND NOT EXISTS(
                SELECT 1
                  FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update aa
                 WHERE c.customer_po       = aa.id
                   AND c.material          = aa.po_sku
                   AND c.sales_org         = aa.sales_org
                   AND a.filterType        = aa.filterType
           );

  -- Type 2
  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update            
    SELECT a.id
         , a.po_orderid
         , a.po_sku
         , c.sales_document
         , c.sold_to_party
         , c.name
         , c.material
         , c.item_descr
         , c.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE CAST(REPLACE(e.so_net_price, ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_price   
         , 0.00                                                              AS so_net_value
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE  CAST(REPLACE(c.cost       , ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END AS cost
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL) AS margin_rate
         , c.so_curr
         , c.so_create_on
         , c.sales_org
         , c.distr_channel
         , c.plant
         , c.stor_loc
         , c.account_code
         , c.account_name
         , c.gc_id_gscm
         , c.gc_name
         , c.ap1_code
         , c.ap1_name
         , c.ap2_code
         , c.ap2_name
         , c.delivery
         , 0                                                                  AS delivery_qty_base
         , c.billed_qty_base
         , c.billing_date
         , c.material_group
         , c.so_local_create_on_d
         , c.do_local_create_on_d
         , c."1ST_GI_LOCAL_CREATE"
         , c.billing_local_create
         , c.final_sch_date
         , MAX(e.last_modification_file)                                      AS last_modification_file
         , a.filterType
         , 'Returned'                                                         AS po_status
      FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter a
      JOIN ow_md.dim_subsidiary                                         b ON LOWER(b.country)    = LOWER(a.country)
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c ON c.sales_document    = a.id
                                                                           AND c.material          = a.po_sku
                                                                           AND c.sales_org         = b.sales_org
                                                                           AND c.delivery_qty_base < 0  
 LEFT JOIN ow_lao.ft_ap2_exchange_rate                                  d ON CAST(d.valid_from AS TIMESTAMP) = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS TIMESTAMP))
                                                                           AND d.to_currency       = a.currency
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e ON e.sales_document    = a.id
                                                                           AND e.material          = a.po_sku
                                                                           AND e.sales_org         = b.sales_org
                                                                           AND e.delivery_qty_base >= 0
     WHERE a.filterType IN (2)
       AND (c.delivery_qty_base + e.delivery_qty_base) <= 0
  GROUP BY a.id
         , a.po_orderid
         , a.po_sku
         , c.sales_document
         , c.sold_to_party
         , c.name
         , c.material
         , c.item_descr
         , c.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE CAST(REPLACE(e.so_net_price, ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE  CAST(REPLACE(c.cost       , ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL)
         , c.so_curr
         , c.so_create_on
         , c.sales_org
         , c.distr_channel
         , c.plant
         , c.stor_loc
         , c.account_code
         , c.account_name
         , c.gc_id_gscm
         , c.gc_name
         , c.ap1_code
         , c.ap1_name
         , c.ap2_code
         , c.ap2_name
         , c.delivery
         , c.billed_qty_base
         , c.billing_date
         , c.material_group
         , c.so_local_create_on_d
         , c.do_local_create_on_d
         , c."1ST_GI_LOCAL_CREATE"
         , c.billing_local_create
         , c.final_sch_date
         , a.filterType;       

  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update            
    SELECT a.id
         , a.po_orderid
         , a.po_sku
         , e.sales_document
         , e.sold_to_party
         , e.name
         , e.material
         , e.item_descr
         , e.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE (CAST(REPLACE(e.so_net_price, ',', '') AS DECIMAL)                                                    ) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_price   
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE (CAST(REPLACE(c.so_net_value, ',', '') AS DECIMAL) + CAST(REPLACE(e.so_net_value, ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_value
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE  CAST(REPLACE(c.cost        , ',', '') AS DECIMAL)                                                      / CAST(d.exchange_rate AS DECIMAL) END AS cost
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL) AS margin_rate
         , e.so_curr
         , e.so_create_on
         , e.sales_org
         , e.distr_channel
         , e.plant
         , e.stor_loc
         , e.account_code
         , e.account_name
         , e.gc_id_gscm
         , e.gc_name
         , e.ap1_code
         , e.ap1_name
         , e.ap2_code
         , e.ap2_name
         , e.delivery
         , c.delivery_qty_base + e.delivery_qty_base        AS delivery_qty_base
         , e.billed_qty_base
         , e.billing_date
         , e.material_group
         , e.so_local_create_on_d
         , e.do_local_create_on_d
         , e."1ST_GI_LOCAL_CREATE"
         , e.billing_local_create
         , e.final_sch_date
         , e.last_modification_file
         , a.filterType
         , a.po_status
      FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter a
      JOIN ow_md.dim_subsidiary                                         b ON LOWER(b.country)    = LOWER(a.country)
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c ON c.sales_document    = a.id
                                                                           AND c.material          = a.po_sku
                                                                           AND c.sales_org         = b.sales_org
                                                                           AND c.delivery_qty_base < 0  
 LEFT JOIN ow_lao.ft_ap2_exchange_rate                                  d ON CAST(d.valid_from AS TIMESTAMP) = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS TIMESTAMP))
                                                                           AND d.to_currency       = a.currency
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e ON e.sales_document    = a.id
                                                                           AND e.material          = a.po_sku
                                                                           AND e.sales_org         = b.sales_org
                                                                           AND e.delivery_qty_base >= 0
     WHERE a.filterType IN (2)
       AND (c.delivery_qty_base + e.delivery_qty_base) > 0;

  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update  
    SELECT a.id
         , a.po_orderid
         , a.po_sku
         , c.sales_document
         , c.sold_to_party
         , c.name
         , c.material
         , c.item_descr
         , c.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE ABS(CAST(REPLACE(c.so_net_price, ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_price
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE ABS(CAST(REPLACE(c.so_net_value, ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_value
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE ABS(CAST(REPLACE(c.cost        , ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS cost
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL)                                                                                              AS margin_rate
         , c.so_curr
         , c.so_create_on
         , c.sales_org
         , c.distr_channel
         , c.plant
         , c.stor_loc
         , c.account_code
         , c.account_name
         , c.gc_id_gscm
         , c.gc_name
         , c.ap1_code
         , c.ap1_name
         , c.ap2_code
         , c.ap2_name
         , c.delivery
         , ABS(c.delivery_qty_base)                                                AS delivery_qty_base
         , c.billed_qty_base
         , c.billing_date
         , c.material_group
         , c.so_local_create_on_d
         , c.do_local_create_on_d
         , c."1ST_GI_LOCAL_CREATE"
         , c.billing_local_create
         , c.final_sch_date
         , c.last_modification_file
         , a.filterType
         , CASE WHEN c.delivery_qty_base < 0 THEN 'Returned' ELSE a.po_status END AS po_status
      FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter a
      JOIN ow_md.dim_subsidiary                                         b ON LOWER(b.country)    = LOWER(a.country)
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c ON c.sales_document    = a.id
                                                                           AND c.material          = a.po_sku
                                                                           AND c.sales_org         = b.sales_org
 LEFT JOIN ow_lao.ft_ap2_exchange_rate                                  d ON CAST(d.valid_from AS TIMESTAMP) = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS TIMESTAMP))
                                                                           AND d.to_currency       = a.currency
     WHERE a.filterType IN (2)
       AND NOT EXISTS(
                SELECT 1
                  FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update aa
                 WHERE c.sales_document    = aa.id
                   AND c.material          = aa.po_sku
                   AND c.sales_org         = aa.sales_org
                   AND a.filterType        = aa.filterType
           );           

  -- Update base table with latest NERP snapshot
  PERFORM UPDATE ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown a
     SET so_idcode             = c.sales_document
       , po_status             = c.po_status
       , soldto_party          = c.sold_to_party
       , soldto_name           = c.name
       , nerp_sku              = c.material
       , nerp_sku_description  = c.item_descr
       , nerp_sku_division     = c.item_division
       , nerp_netprice         = CASE WHEN c.so_net_price < 0 THEN 0 ELSE c.so_net_price END
       , nerp_netvalue         = CASE WHEN c.so_net_value < 0 THEN 0 ELSE c.so_net_value END
       , nerp_cost             = c.cost
       , nerp_marginrate       = c.margin_rate
       , nerp_currency         = c.so_curr
       , so_date_kst           = c.so_create_on
       , nerp_countrycode      = c.sales_org
       , nerp_distchannel      = c.distr_channel
       , nerp_plant            = c.plant
       , nerp_storagelocation  = c.stor_loc
       , nerp_accountcode      = c.account_code
       , nerp_accountname      = c.account_name
       , nerp_id_gscm          = c.gc_id_gscm
       , nerp_gc_name          = c.gc_name
       , nerp_ap1_code         = c.ap1_code
       , nerp_ap1_name         = c.ap1_name
       , nerp_ap2_code         = c.ap2_code
       , nerp_ap2_name         = c.ap2_name
       , nerp_deliverycode     = c.delivery
       , nerp_deliveruqty      = c.delivery_qty_base
       , nerp_billingqty       = c.billed_qty_base
       , nerp_billingdate      = c.billing_date
       , nerp_material_group   = c.material_group
       , so_date               = c.so_local_create_on_d
       , do_date               = c.do_local_create_on_d
       , "1GI_DATE"           = c."1ST_GI_LOCAL_CREATE"
       , billing_date_local    = c.billing_local_create
       , final_date            = c.final_sch_date
       , nerp_last_update_date = CAST(c.last_modification_file AS TIMESTAMP)
       , updated_datetime      = CURRENT_TIMESTAMP
    FROM ow_md.dim_subsidiary b
    JOIN ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update c 
      ON c.material       = a.po_sku
     AND c.po_orderid     = a.po_orderid
    LEFT JOIN ow_lao.ft_ap2_exchange_rate d 
      ON CAST(d.valid_from AS TIMESTAMP) = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS TIMESTAMP))
     AND d.to_currency    = a.currency
   WHERE LOWER(b.country) = LOWER(a.country)
     AND c.sales_org      = b.sales_org
     AND (a.nerp_last_update_date < CAST(c.last_modification_file AS TIMESTAMP) OR a.nerp_last_update_date IS NULL);

END;
$$;

-- CALL OW_LAO.proc_tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_homolog();
-- ERROR: Severity: ERROR, Message: Relation "a" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_homolog line 484 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4345, Error Code: 4566, 
-- CALL OW_LAO.proc_tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_homolog();
-- ERROR: Severity: ERROR, Message: Relation "a" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_homolog line 484 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4345, Error Code: 4566, 
CREATE OR REPLACE PROCEDURE OW_LAO.proc_tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_homolog()
LANGUAGE PLvSQL AS $$
BEGIN

  -- Refresh filter table (prefer truncate over drop/create)
  PERFORM TRUNCATE TABLE ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter;

  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter
    (id, po_sku, sales_org, currency, country, po_status, po_orderid, po_date, filterType)
  SELECT DISTINCT
         a.po_sequence_orderid    AS id
       , a.po_sku
       , b.sales_org
       , a.currency
       , a.country
       , a.po_status
       , a.po_orderid
       , CAST(a.po_date AS DATE)  AS po_date
       , 1                        AS filterType
    FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown            a
    JOIN ow_md.dim_subsidiary                            b ON LOWER(b.country) = LOWER(a.country)
    JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking c ON c.customer_po    = a.po_sequence_orderid
                                                           AND c.material       = a.po_sku
                                                           AND c.sales_org      = b.sales_org
   WHERE a.nerp_last_update_date < CAST(c.last_modification_file AS TIMESTAMP)
      OR a.nerp_last_update_date IS NULL

  UNION ALL    

  SELECT DISTINCT
         a.po_ordersid            AS id
       , a.po_sku
       , b.sales_org
       , a.currency
       , a.country
       , a.po_status
       , a.po_orderid
       , CAST(a.po_date AS DATE)  AS po_date
       , 2                        AS filterType
    FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown            a
    JOIN ow_md.dim_subsidiary                            b ON LOWER(b.country) = LOWER(a.country)
    JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking c ON c.sales_document = a.po_ordersid
                                                           AND c.material       = a.po_sku
                                                           AND c.sales_org      = b.sales_org
   WHERE a.nerp_last_update_date < CAST(c.last_modification_file AS TIMESTAMP)
      OR a.nerp_last_update_date IS NULL

  UNION ALL    

  SELECT DISTINCT
         a.po_orderid             AS id
       , a.po_sku
       , b.sales_org
       , a.currency
       , a.country
       , a.po_status
       , a.po_orderid
       , CAST(a.po_date AS DATE)  AS po_date
       , 3                        AS filterType
    FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown            a
    JOIN ow_md.dim_subsidiary                            b ON LOWER(b.country) = LOWER(a.country)
    JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking c ON c.customer_po    = a.po_orderid
                                                           AND c.material       = a.po_sku
                                                           AND c.sales_org      = b.sales_org
   WHERE a.nerp_last_update_date < CAST(c.last_modification_file AS TIMESTAMP)
      OR a.nerp_last_update_date IS NULL;

  PERFORM TRUNCATE TABLE ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update;

  -- Type 1 and 3
  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update            
    SELECT a.id
         , a.po_orderid
         , a.po_sku
         , c.sales_document
         , c.sold_to_party
         , c.name
         , c.material
         , c.item_descr
         , c.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE CAST(REPLACE(e.so_net_price, ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_price   
         , 0.00                                                                                                                                      AS so_net_value
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE  CAST(REPLACE(c.cost       , ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END AS cost
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL) AS margin_rate
         , c.so_curr
         , c.so_create_on
         , c.sales_org
         , c.distr_channel
         , c.plant
         , c.stor_loc
         , c.account_code
         , c.account_name
         , c.gc_id_gscm
         , c.gc_name
         , c.ap1_code
         , c.ap1_name
         , c.ap2_code
         , c.ap2_name
         , c.delivery
         , 0                                                                  AS delivery_qty_base
         , c.billed_qty_base
         , c.billing_date
         , c.material_group
         , c.so_local_create_on_d
         , c.do_local_create_on_d
         , c."1ST_GI_LOCAL_CREATE"
         , c.billing_local_create
         , c.final_sch_date
         , MAX(e.last_modification_file)                                      AS last_modification_file
         , a.filterType
         , 'Returned'                                                         AS po_status
      FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter a
      JOIN ow_md.dim_subsidiary                                         b ON LOWER(b.country)    = LOWER(a.country)
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c ON c.customer_po       = a.id
                                                                           AND c.material          = a.po_sku
                                                                           AND c.sales_org         = b.sales_org
                                                                           AND c.delivery_qty_base < 0  
 LEFT JOIN ow_lao.ft_ap2_exchange_rate                                  d ON CAST(d.valid_from AS TIMESTAMP) = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS TIMESTAMP))
                                                                           AND d.to_currency       = a.currency
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e ON e.customer_po       = a.id
                                                                           AND e.material          = a.po_sku
                                                                           AND e.sales_org         = b.sales_org
                                                                           AND e.delivery_qty_base >= 0
     WHERE a.filterType IN (1, 3)
       AND (c.delivery_qty_base + e.delivery_qty_base) <= 0
  GROUP BY a.id
         , a.po_orderid
         , a.po_sku
         , c.sales_document
         , c.sold_to_party
         , c.name
         , c.material
         , c.item_descr
         , c.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE CAST(REPLACE(e.so_net_price, ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE  CAST(REPLACE(c.cost       , ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL)
         , c.so_curr
         , c.so_create_on
         , c.sales_org
         , c.distr_channel
         , c.plant
         , c.stor_loc
         , c.account_code
         , c.account_name
         , c.gc_id_gscm
         , c.gc_name
         , c.ap1_code
         , c.ap1_name
         , c.ap2_code
         , c.ap2_name
         , c.delivery
         , c.billed_qty_base
         , c.billing_date
         , c.material_group
         , c.so_local_create_on_d
         , c.do_local_create_on_d
         , c."1ST_GI_LOCAL_CREATE"
         , c.billing_local_create
         , c.final_sch_date
         , a.filterType;    

  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update            
    SELECT a.id
         , a.po_orderid
         , a.po_sku
         , e.sales_document
         , e.sold_to_party
         , e.name
         , e.material
         , e.item_descr
         , e.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE (CAST(REPLACE(e.so_net_price, ',', '') AS DECIMAL)                                                    ) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_price   
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE (CAST(REPLACE(c.so_net_value, ',', '') AS DECIMAL) + CAST(REPLACE(e.so_net_value, ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_value
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE  CAST(REPLACE(c.cost        , ',', '') AS DECIMAL)                                                      / CAST(d.exchange_rate AS DECIMAL) END AS cost
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL) AS margin_rate
         , e.so_curr
         , e.so_create_on
         , e.sales_org
         , e.distr_channel
         , e.plant
         , e.stor_loc
         , e.account_code
         , e.account_name
         , e.gc_id_gscm
         , e.gc_name
         , e.ap1_code
         , e.ap1_name
         , e.ap2_code
         , e.ap2_name
         , e.delivery
         , c.delivery_qty_base + e.delivery_qty_base        AS delivery_qty_base
         , e.billed_qty_base
         , e.billing_date
         , e.material_group
         , e.so_local_create_on_d
         , e.do_local_create_on_d
         , e."1ST_GI_LOCAL_CREATE"
         , e.billing_local_create
         , e.final_sch_date
         , e.last_modification_file
         , a.filterType
         , a.po_status
      FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter a
      JOIN ow_md.dim_subsidiary                                         b ON LOWER(b.country)    = LOWER(a.country)
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c ON c.customer_po       = a.id
                                                                           AND c.material          = a.po_sku
                                                                           AND c.sales_org         = b.sales_org
                                                                           AND c.delivery_qty_base < 0  
 LEFT JOIN ow_lao.ft_ap2_exchange_rate                                  d ON CAST(d.valid_from AS TIMESTAMP) = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS TIMESTAMP))
                                                                           AND d.to_currency       = a.currency
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e ON e.customer_po       = a.id
                                                                           AND e.material          = a.po_sku
                                                                           AND e.sales_org         = b.sales_org
                                                                           AND e.delivery_qty_base >= 0
     WHERE a.filterType IN (1, 3)
       AND (c.delivery_qty_base + e.delivery_qty_base) > 0;

  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update  
    SELECT a.id
         , a.po_orderid
         , a.po_sku
         , c.sales_document
         , c.sold_to_party
         , c.name
         , c.material
         , c.item_descr
         , c.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE ABS(CAST(REPLACE(c.so_net_price, ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_price
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE ABS(CAST(REPLACE(c.so_net_value, ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_value
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE CAST(REPLACE(c.cost            , ',', '') AS DECIMAL)  / CAST(d.exchange_rate AS DECIMAL) END AS cost
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL)                                                                                              AS margin_rate
         , c.so_curr
         , c.so_create_on
         , c.sales_org
         , c.distr_channel
         , c.plant
         , c.stor_loc
         , c.account_code
         , c.account_name
         , c.gc_id_gscm
         , c.gc_name
         , c.ap1_code
         , c.ap1_name
         , c.ap2_code
         , c.ap2_name
         , c.delivery
         , ABS(c.delivery_qty_base)                                      AS delivery_qty_base
         , c.billed_qty_base
         , c.billing_date
         , c.material_group
         , c.so_local_create_on_d
         , c.do_local_create_on_d
         , c."1ST_GI_LOCAL_CREATE"
         , c.billing_local_create
         , c.final_sch_date
         , c.last_modification_file
         , a.filterType
         , CASE WHEN c.delivery_qty_base < 0 THEN 'Returned' ELSE a.po_status END AS po_status
      FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter a
      JOIN ow_md.dim_subsidiary                                         b ON LOWER(b.country)    = LOWER(a.country)
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c ON c.customer_po       = a.id
                                                                           AND c.material          = a.po_sku
                                                                           AND c.sales_org         = b.sales_org
 LEFT JOIN ow_lao.ft_ap2_exchange_rate                                  d ON CAST(d.valid_from AS TIMESTAMP) = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS TIMESTAMP))
                                                                           AND d.to_currency       = a.currency
     WHERE a.filterType IN (1, 3)
       AND NOT EXISTS(
                SELECT 1
                  FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update aa
                 WHERE c.customer_po       = aa.id
                   AND c.material          = aa.po_sku
                   AND c.sales_org         = aa.sales_org
                   AND a.filterType        = aa.filterType
           );

  -- Type 2
  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update            
    SELECT a.id
         , a.po_orderid
         , a.po_sku
         , c.sales_document
         , c.sold_to_party
         , c.name
         , c.material
         , c.item_descr
         , c.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE CAST(REPLACE(e.so_net_price, ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_price   
         , 0.00                                                              AS so_net_value
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE  CAST(REPLACE(c.cost       , ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END AS cost
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL) AS margin_rate
         , c.so_curr
         , c.so_create_on
         , c.sales_org
         , c.distr_channel
         , c.plant
         , c.stor_loc
         , c.account_code
         , c.account_name
         , c.gc_id_gscm
         , c.gc_name
         , c.ap1_code
         , c.ap1_name
         , c.ap2_code
         , c.ap2_name
         , c.delivery
         , 0                                                                  AS delivery_qty_base
         , c.billed_qty_base
         , c.billing_date
         , c.material_group
         , c.so_local_create_on_d
         , c.do_local_create_on_d
         , c."1ST_GI_LOCAL_CREATE"
         , c.billing_local_create
         , c.final_sch_date
         , MAX(e.last_modification_file)                                      AS last_modification_file
         , a.filterType
         , 'Returned'                                                         AS po_status
      FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter a
      JOIN ow_md.dim_subsidiary                                         b ON LOWER(b.country)    = LOWER(a.country)
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c ON c.sales_document    = a.id
                                                                           AND c.material          = a.po_sku
                                                                           AND c.sales_org         = b.sales_org
                                                                           AND c.delivery_qty_base < 0  
 LEFT JOIN ow_lao.ft_ap2_exchange_rate                                  d ON CAST(d.valid_from AS TIMESTAMP) = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS TIMESTAMP))
                                                                           AND d.to_currency       = a.currency
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e ON e.sales_document    = a.id
                                                                           AND e.material          = a.po_sku
                                                                           AND e.sales_org         = b.sales_org
                                                                           AND e.delivery_qty_base >= 0
     WHERE a.filterType IN (2)
       AND (c.delivery_qty_base + e.delivery_qty_base) <= 0
  GROUP BY a.id
         , a.po_orderid
         , a.po_sku
         , c.sales_document
         , c.sold_to_party
         , c.name
         , c.material
         , c.item_descr
         , c.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE CAST(REPLACE(e.so_net_price, ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE  CAST(REPLACE(c.cost       , ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL)
         , c.so_curr
         , c.so_create_on
         , c.sales_org
         , c.distr_channel
         , c.plant
         , c.stor_loc
         , c.account_code
         , c.account_name
         , c.gc_id_gscm
         , c.gc_name
         , c.ap1_code
         , c.ap1_name
         , c.ap2_code
         , c.ap2_name
         , c.delivery
         , c.billed_qty_base
         , c.billing_date
         , c.material_group
         , c.so_local_create_on_d
         , c.do_local_create_on_d
         , c."1ST_GI_LOCAL_CREATE"
         , c.billing_local_create
         , c.final_sch_date
         , a.filterType;       

  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update            
    SELECT a.id
         , a.po_orderid
         , a.po_sku
         , e.sales_document
         , e.sold_to_party
         , e.name
         , e.material
         , e.item_descr
         , e.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE (CAST(REPLACE(e.so_net_price, ',', '') AS DECIMAL)                                                    ) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_price   
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE (CAST(REPLACE(c.so_net_value, ',', '') AS DECIMAL) + CAST(REPLACE(e.so_net_value, ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_value
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE  CAST(REPLACE(c.cost        , ',', '') AS DECIMAL)                                                      / CAST(d.exchange_rate AS DECIMAL) END AS cost
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL) AS margin_rate
         , e.so_curr
         , e.so_create_on
         , e.sales_org
         , e.distr_channel
         , e.plant
         , e.stor_loc
         , e.account_code
         , e.account_name
         , e.gc_id_gscm
         , e.gc_name
         , e.ap1_code
         , e.ap1_name
         , e.ap2_code
         , e.ap2_name
         , e.delivery
         , c.delivery_qty_base + e.delivery_qty_base        AS delivery_qty_base
         , e.billed_qty_base
         , e.billing_date
         , e.material_group
         , e.so_local_create_on_d
         , e.do_local_create_on_d
         , e."1ST_GI_LOCAL_CREATE"
         , e.billing_local_create
         , e.final_sch_date
         , e.last_modification_file
         , a.filterType
         , a.po_status
      FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter a
      JOIN ow_md.dim_subsidiary                                         b ON LOWER(b.country)    = LOWER(a.country)
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c ON c.sales_document    = a.id
                                                                           AND c.material          = a.po_sku
                                                                           AND c.sales_org         = b.sales_org
                                                                           AND c.delivery_qty_base < 0  
 LEFT JOIN ow_lao.ft_ap2_exchange_rate                                  d ON CAST(d.valid_from AS TIMESTAMP) = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS TIMESTAMP))
                                                                           AND d.to_currency       = a.currency
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e ON e.sales_document    = a.id
                                                                           AND e.material          = a.po_sku
                                                                           AND e.sales_org         = b.sales_org
                                                                           AND e.delivery_qty_base >= 0
     WHERE a.filterType IN (2)
       AND (c.delivery_qty_base + e.delivery_qty_base) > 0;

  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update  
    SELECT a.id
         , a.po_orderid
         , a.po_sku
         , c.sales_document
         , c.sold_to_party
         , c.name
         , c.material
         , c.item_descr
         , c.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE ABS(CAST(REPLACE(c.so_net_price, ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_price
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE ABS(CAST(REPLACE(c.so_net_value, ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_value
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE ABS(CAST(REPLACE(c.cost        , ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS cost
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL)                                                                                              AS margin_rate
         , c.so_curr
         , c.so_create_on
         , c.sales_org
         , c.distr_channel
         , c.plant
         , c.stor_loc
         , c.account_code
         , c.account_name
         , c.gc_id_gscm
         , c.gc_name
         , c.ap1_code
         , c.ap1_name
         , c.ap2_code
         , c.ap2_name
         , c.delivery
         , ABS(c.delivery_qty_base)                                                AS delivery_qty_base
         , c.billed_qty_base
         , c.billing_date
         , c.material_group
         , c.so_local_create_on_d
         , c.do_local_create_on_d
         , c."1ST_GI_LOCAL_CREATE"
         , c.billing_local_create
         , c.final_sch_date
         , c.last_modification_file
         , a.filterType
         , CASE WHEN c.delivery_qty_base < 0 THEN 'Returned' ELSE a.po_status END AS po_status
      FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter a
      JOIN ow_md.dim_subsidiary                                         b ON LOWER(b.country)    = LOWER(a.country)
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c ON c.sales_document    = a.id
                                                                           AND c.material          = a.po_sku
                                                                           AND c.sales_org         = b.sales_org
 LEFT JOIN ow_lao.ft_ap2_exchange_rate                                  d ON CAST(d.valid_from AS TIMESTAMP) = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS TIMESTAMP))
                                                                           AND d.to_currency       = a.currency
     WHERE a.filterType IN (2)
       AND NOT EXISTS(
                SELECT 1
                  FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update aa
                 WHERE c.sales_document    = aa.id
                   AND c.material          = aa.po_sku
                   AND c.sales_org         = aa.sales_org
                   AND a.filterType        = aa.filterType
           );           

  -- Update base table with latest NERP snapshot
  PERFORM UPDATE ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown
     SET so_idcode             = c.sales_document
       , po_status             = c.po_status
       , soldto_party          = c.sold_to_party
       , soldto_name           = c.name
       , nerp_sku              = c.material
       , nerp_sku_description  = c.item_descr
       , nerp_sku_division     = c.item_division
       , nerp_netprice         = CASE WHEN c.so_net_price < 0 THEN 0 ELSE c.so_net_price END
       , nerp_netvalue         = CASE WHEN c.so_net_value < 0 THEN 0 ELSE c.so_net_value END
       , nerp_cost             = c.cost
       , nerp_marginrate       = c.margin_rate
       , nerp_currency         = c.so_curr
       , so_date_kst           = c.so_create_on
       , nerp_countrycode      = c.sales_org
       , nerp_distchannel      = c.distr_channel
       , nerp_plant            = c.plant
       , nerp_storagelocation  = c.stor_loc
       , nerp_accountcode      = c.account_code
       , nerp_accountname      = c.account_name
       , nerp_id_gscm          = c.gc_id_gscm
       , nerp_gc_name          = c.gc_name
       , nerp_ap1_code         = c.ap1_code
       , nerp_ap1_name         = c.ap1_name
       , nerp_ap2_code         = c.ap2_code
       , nerp_ap2_name         = c.ap2_name
       , nerp_deliverycode     = c.delivery
       , nerp_deliveruqty      = c.delivery_qty_base
       , nerp_billingqty       = c.billed_qty_base
       , nerp_billingdate      = c.billing_date
       , nerp_material_group   = c.material_group
       , so_date               = c.so_local_create_on_d
       , do_date               = c.do_local_create_on_d
       , "1GI_DATE"           = c."1ST_GI_LOCAL_CREATE"
       , billing_date_local    = c.billing_local_create
       , final_date            = c.final_sch_date
       , nerp_last_update_date = CAST(c.last_modification_file AS TIMESTAMP)
       , updated_datetime      = CURRENT_TIMESTAMP
    FROM ow_md.dim_subsidiary b
    JOIN ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update c 
      ON c.material       = ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown.po_sku
     AND c.po_orderid     = ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown.po_orderid
    LEFT JOIN ow_lao.ft_ap2_exchange_rate d 
      ON CAST(d.valid_from AS TIMESTAMP) = TIMESTAMPADD(DAY, -1, CAST(ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown.po_date AS TIMESTAMP))
     AND d.to_currency    = ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown.currency
   WHERE LOWER(b.country) = LOWER(ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown.country)
     AND c.sales_org      = b.sales_org
     AND (ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown.nerp_last_update_date < CAST(c.last_modification_file AS TIMESTAMP) OR ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown.nerp_last_update_date IS NULL);

END;
$$;

-- CALL OW_LAO.proc_tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_homolog();
-- ERROR: Severity: ERROR, Message: Missing FROM-clause entry for table "tmp_ecommerce_sales_control_tower_table_bundles_breakdown", Sqlstate: 42V01, Where: PL/vSQL procedure proc_tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_homolog line 484 at static SQL, Routine: warnAutoRange, File: parse_relation.c, Line: 2927, Error Code: 3953, 
-- CALL OW_LAO.proc_tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_homolog();
-- ERROR: Severity: ERROR, Message: Missing FROM-clause entry for table "tmp_ecommerce_sales_control_tower_table_bundles_breakdown", Sqlstate: 42V01, Where: PL/vSQL procedure proc_tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_homolog line 484 at static SQL, Routine: warnAutoRange, File: parse_relation.c, Line: 2927, Error Code: 3953, 
CREATE OR REPLACE PROCEDURE OW_LAO.proc_tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_homolog()
LANGUAGE PLvSQL AS $$
BEGIN

  PERFORM TRUNCATE TABLE ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter;

  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter
    (id, po_sku, sales_org, currency, country, po_status, po_orderid, po_date, filterType)
  SELECT DISTINCT
         a.po_sequence_orderid    AS id
       , a.po_sku
       , b.sales_org
       , a.currency
       , a.country
       , a.po_status
       , a.po_orderid
       , CAST(a.po_date AS DATE)  AS po_date
       , 1                        AS filterType
    FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown            a
    JOIN ow_md.dim_subsidiary                            b ON LOWER(b.country) = LOWER(a.country)
    JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking c ON c.customer_po    = a.po_sequence_orderid
                                                           AND c.material       = a.po_sku
                                                           AND c.sales_org      = b.sales_org
   WHERE a.nerp_last_update_date < CAST(c.last_modification_file AS TIMESTAMP)
      OR a.nerp_last_update_date IS NULL

  UNION ALL    

  SELECT DISTINCT
         a.po_ordersid            AS id
       , a.po_sku
       , b.sales_org
       , a.currency
       , a.country
       , a.po_status
       , a.po_orderid
       , CAST(a.po_date AS DATE)  AS po_date
       , 2                        AS filterType
    FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown            a
    JOIN ow_md.dim_subsidiary                            b ON LOWER(b.country) = LOWER(a.country)
    JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking c ON c.sales_document = a.po_ordersid
                                                           AND c.material       = a.po_sku
                                                           AND c.sales_org      = b.sales_org
   WHERE a.nerp_last_update_date < CAST(c.last_modification_file AS TIMESTAMP)
      OR a.nerp_last_update_date IS NULL

  UNION ALL    

  SELECT DISTINCT
         a.po_orderid             AS id
       , a.po_sku
       , b.sales_org
       , a.currency
       , a.country
       , a.po_status
       , a.po_orderid
       , CAST(a.po_date AS DATE)  AS po_date
       , 3                        AS filterType
    FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown            a
    JOIN ow_md.dim_subsidiary                            b ON LOWER(b.country) = LOWER(a.country)
    JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking c ON c.customer_po    = a.po_orderid
                                                           AND c.material       = a.po_sku
                                                           AND c.sales_org      = b.sales_org
   WHERE a.nerp_last_update_date < CAST(c.last_modification_file AS TIMESTAMP)
      OR a.nerp_last_update_date IS NULL;

  PERFORM TRUNCATE TABLE ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update;

  -- Type 1 and 3
  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update            
    SELECT a.id
         , a.po_orderid
         , a.po_sku
         , c.sales_document
         , c.sold_to_party
         , c.name
         , c.material
         , c.item_descr
         , c.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE CAST(REPLACE(e.so_net_price, ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_price   
         , 0.00                                                                                                                                      AS so_net_value
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE  CAST(REPLACE(c.cost       , ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END AS cost
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL) AS margin_rate
         , c.so_curr
         , c.so_create_on
         , c.sales_org
         , c.distr_channel
         , c.plant
         , c.stor_loc
         , c.account_code
         , c.account_name
         , c.gc_id_gscm
         , c.gc_name
         , c.ap1_code
         , c.ap1_name
         , c.ap2_code
         , c.ap2_name
         , c.delivery
         , 0                                                                  AS delivery_qty_base
         , c.billed_qty_base
         , c.billing_date
         , c.material_group
         , c.so_local_create_on_d
         , c.do_local_create_on_d
         , c."1ST_GI_LOCAL_CREATE"
         , c.billing_local_create
         , c.final_sch_date
         , MAX(e.last_modification_file)                                      AS last_modification_file
         , a.filterType
         , 'Returned'                                                         AS po_status
      FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter a
      JOIN ow_md.dim_subsidiary                                         b ON LOWER(b.country)    = LOWER(a.country)
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c ON c.customer_po       = a.id
                                                                           AND c.material          = a.po_sku
                                                                           AND c.sales_org         = b.sales_org
                                                                           AND c.delivery_qty_base < 0  
 LEFT JOIN ow_lao.ft_ap2_exchange_rate                                  d ON CAST(d.valid_from AS TIMESTAMP) = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS TIMESTAMP))
                                                                           AND d.to_currency       = a.currency
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e ON e.customer_po       = a.id
                                                                           AND e.material          = a.po_sku
                                                                           AND e.sales_org         = b.sales_org
                                                                           AND e.delivery_qty_base >= 0
     WHERE a.filterType IN (1, 3)
       AND (c.delivery_qty_base + e.delivery_qty_base) <= 0
  GROUP BY a.id
         , a.po_orderid
         , a.po_sku
         , c.sales_document
         , c.sold_to_party
         , c.name
         , c.material
         , c.item_descr
         , c.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE CAST(REPLACE(e.so_net_price, ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE  CAST(REPLACE(c.cost       , ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL)
         , c.so_curr
         , c.so_create_on
         , c.sales_org
         , c.distr_channel
         , c.plant
         , c.stor_loc
         , c.account_code
         , c.account_name
         , c.gc_id_gscm
         , c.gc_name
         , c.ap1_code
         , c.ap1_name
         , c.ap2_code
         , c.ap2_name
         , c.delivery
         , c.billed_qty_base
         , c.billing_date
         , c.material_group
         , c.so_local_create_on_d
         , c.do_local_create_on_d
         , c."1ST_GI_LOCAL_CREATE"
         , c.billing_local_create
         , c.final_sch_date
         , a.filterType;    

  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update            
    SELECT a.id
         , a.po_orderid
         , a.po_sku
         , e.sales_document
         , e.sold_to_party
         , e.name
         , e.material
         , e.item_descr
         , e.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE (CAST(REPLACE(e.so_net_price, ',', '') AS DECIMAL)                                                    ) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_price   
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE (CAST(REPLACE(c.so_net_value, ',', '') AS DECIMAL) + CAST(REPLACE(e.so_net_value, ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_value
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE  CAST(REPLACE(c.cost        , ',', '') AS DECIMAL)                                                      / CAST(d.exchange_rate AS DECIMAL) END AS cost
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL) AS margin_rate
         , e.so_curr
         , e.so_create_on
         , e.sales_org
         , e.distr_channel
         , e.plant
         , e.stor_loc
         , e.account_code
         , e.account_name
         , e.gc_id_gscm
         , e.gc_name
         , e.ap1_code
         , e.ap1_name
         , e.ap2_code
         , e.ap2_name
         , e.delivery
         , c.delivery_qty_base + e.delivery_qty_base        AS delivery_qty_base
         , e.billed_qty_base
         , e.billing_date
         , e.material_group
         , e.so_local_create_on_d
         , e.do_local_create_on_d
         , e."1ST_GI_LOCAL_CREATE"
         , e.billing_local_create
         , e.final_sch_date
         , e.last_modification_file
         , a.filterType
         , a.po_status
      FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter a
      JOIN ow_md.dim_subsidiary                                         b ON LOWER(b.country)    = LOWER(a.country)
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c ON c.customer_po       = a.id
                                                                           AND c.material          = a.po_sku
                                                                           AND c.sales_org         = b.sales_org
                                                                           AND c.delivery_qty_base < 0  
 LEFT JOIN ow_lao.ft_ap2_exchange_rate                                  d ON CAST(d.valid_from AS TIMESTAMP) = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS TIMESTAMP))
                                                                           AND d.to_currency       = a.currency
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e ON e.customer_po       = a.id
                                                                           AND e.material          = a.po_sku
                                                                           AND e.sales_org         = b.sales_org
                                                                           AND e.delivery_qty_base >= 0
     WHERE a.filterType IN (1, 3)
       AND (c.delivery_qty_base + e.delivery_qty_base) > 0;

  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update  
    SELECT a.id
         , a.po_orderid
         , a.po_sku
         , c.sales_document
         , c.sold_to_party
         , c.name
         , c.material
         , c.item_descr
         , c.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE ABS(CAST(REPLACE(c.so_net_price, ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_price
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE ABS(CAST(REPLACE(c.so_net_value, ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_value
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE CAST(REPLACE(c.cost            , ',', '') AS DECIMAL)  / CAST(d.exchange_rate AS DECIMAL) END AS cost
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL)                                                                                              AS margin_rate
         , c.so_curr
         , c.so_create_on
         , c.sales_org
         , c.distr_channel
         , c.plant
         , c.stor_loc
         , c.account_code
         , c.account_name
         , c.gc_id_gscm
         , c.gc_name
         , c.ap1_code
         , c.ap1_name
         , c.ap2_code
         , c.ap2_name
         , c.delivery
         , ABS(c.delivery_qty_base)                                      AS delivery_qty_base
         , c.billed_qty_base
         , c.billing_date
         , c.material_group
         , c.so_local_create_on_d
         , c.do_local_create_on_d
         , c."1ST_GI_LOCAL_CREATE"
         , c.billing_local_create
         , c.final_sch_date
         , c.last_modification_file
         , a.filterType
         , CASE WHEN c.delivery_qty_base < 0 THEN 'Returned' ELSE a.po_status END AS po_status
      FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter a
      JOIN ow_md.dim_subsidiary                                         b ON LOWER(b.country)    = LOWER(a.country)
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c ON c.customer_po       = a.id
                                                                           AND c.material          = a.po_sku
                                                                           AND c.sales_org         = b.sales_org
 LEFT JOIN ow_lao.ft_ap2_exchange_rate                                  d ON CAST(d.valid_from AS TIMESTAMP) = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS TIMESTAMP))
                                                                           AND d.to_currency       = a.currency
     WHERE a.filterType IN (1, 3)
       AND NOT EXISTS(
                SELECT 1
                  FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update aa
                 WHERE c.customer_po       = aa.id
                   AND c.material          = aa.po_sku
                   AND c.sales_org         = aa.sales_org
                   AND a.filterType        = aa.filterType
           );

  -- Type 2
  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update            
    SELECT a.id
         , a.po_orderid
         , a.po_sku
         , c.sales_document
         , c.sold_to_party
         , c.name
         , c.material
         , c.item_descr
         , c.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE CAST(REPLACE(e.so_net_price, ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_price   
         , 0.00                                                              AS so_net_value
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE  CAST(REPLACE(c.cost       , ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END AS cost
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL) AS margin_rate
         , c.so_curr
         , c.so_create_on
         , c.sales_org
         , c.distr_channel
         , c.plant
         , c.stor_loc
         , c.account_code
         , c.account_name
         , c.gc_id_gscm
         , c.gc_name
         , c.ap1_code
         , c.ap1_name
         , c.ap2_code
         , c.ap2_name
         , c.delivery
         , 0                                                                  AS delivery_qty_base
         , c.billed_qty_base
         , c.billing_date
         , c.material_group
         , c.so_local_create_on_d
         , c.do_local_create_on_d
         , c."1ST_GI_LOCAL_CREATE"
         , c.billing_local_create
         , c.final_sch_date
         , MAX(e.last_modification_file)                                      AS last_modification_file
         , a.filterType
         , 'Returned'                                                         AS po_status
      FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter a
      JOIN ow_md.dim_subsidiary                                         b ON LOWER(b.country)    = LOWER(a.country)
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c ON c.sales_document    = a.id
                                                                           AND c.material          = a.po_sku
                                                                           AND c.sales_org         = b.sales_org
                                                                           AND c.delivery_qty_base < 0  
 LEFT JOIN ow_lao.ft_ap2_exchange_rate                                  d ON CAST(d.valid_from AS TIMESTAMP) = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS TIMESTAMP))
                                                                           AND d.to_currency       = a.currency
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e ON e.sales_document    = a.id
                                                                           AND e.material          = a.po_sku
                                                                           AND e.sales_org         = b.sales_org
                                                                           AND e.delivery_qty_base >= 0
     WHERE a.filterType IN (2)
       AND (c.delivery_qty_base + e.delivery_qty_base) <= 0
  GROUP BY a.id
         , a.po_orderid
         , a.po_sku
         , c.sales_document
         , c.sold_to_party
         , c.name
         , c.material
         , c.item_descr
         , c.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE CAST(REPLACE(e.so_net_price, ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE  CAST(REPLACE(c.cost       , ',', '') AS DECIMAL) / CAST(d.exchange_rate AS DECIMAL) END
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL)
         , c.so_curr
         , c.so_create_on
         , c.sales_org
         , c.distr_channel
         , c.plant
         , c.stor_loc
         , c.account_code
         , c.account_name
         , c.gc_id_gscm
         , c.gc_name
         , c.ap1_code
         , c.ap1_name
         , c.ap2_code
         , c.ap2_name
         , c.delivery
         , c.billed_qty_base
         , c.billing_date
         , c.material_group
         , c.so_local_create_on_d
         , c.do_local_create_on_d
         , c."1ST_GI_LOCAL_CREATE"
         , c.billing_local_create
         , c.final_sch_date
         , a.filterType;       

  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update            
    SELECT a.id
         , a.po_orderid
         , a.po_sku
         , e.sales_document
         , e.sold_to_party
         , e.name
         , e.material
         , e.item_descr
         , e.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE (CAST(REPLACE(e.so_net_price, ',', '') AS DECIMAL)                                                    ) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_price   
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE (CAST(REPLACE(c.so_net_value, ',', '') AS DECIMAL) + CAST(REPLACE(e.so_net_value, ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_value
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE  CAST(REPLACE(c.cost        , ',', '') AS DECIMAL)                                                      / CAST(d.exchange_rate AS DECIMAL) END AS cost
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL) AS margin_rate
         , e.so_curr
         , e.so_create_on
         , e.sales_org
         , e.distr_channel
         , e.plant
         , e.stor_loc
         , e.account_code
         , e.account_name
         , e.gc_id_gscm
         , e.gc_name
         , e.ap1_code
         , e.ap1_name
         , e.ap2_code
         , e.ap2_name
         , e.delivery
         , c.delivery_qty_base + e.delivery_qty_base        AS delivery_qty_base
         , e.billed_qty_base
         , e.billing_date
         , e.material_group
         , e.so_local_create_on_d
         , e.do_local_create_on_d
         , e."1ST_GI_LOCAL_CREATE"
         , e.billing_local_create
         , e.final_sch_date
         , e.last_modification_file
         , a.filterType
         , a.po_status
      FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter a
      JOIN ow_md.dim_subsidiary                                         b ON LOWER(b.country)    = LOWER(a.country)
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c ON c.sales_document    = a.id
                                                                           AND c.material          = a.po_sku
                                                                           AND c.sales_org         = b.sales_org
                                                                           AND c.delivery_qty_base < 0  
 LEFT JOIN ow_lao.ft_ap2_exchange_rate                                  d ON CAST(d.valid_from AS TIMESTAMP) = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS TIMESTAMP))
                                                                           AND d.to_currency       = a.currency
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e ON e.sales_document    = a.id
                                                                           AND e.material          = a.po_sku
                                                                           AND e.sales_org         = b.sales_org
                                                                           AND e.delivery_qty_base >= 0
     WHERE a.filterType IN (2)
       AND (c.delivery_qty_base + e.delivery_qty_base) > 0;

  PERFORM INSERT INTO ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update  
    SELECT a.id
         , a.po_orderid
         , a.po_sku
         , c.sales_document
         , c.sold_to_party
         , c.name
         , c.material
         , c.item_descr
         , c.item_division
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE ABS(CAST(REPLACE(c.so_net_price, ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_price
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE ABS(CAST(REPLACE(c.so_net_value, ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS so_net_value
         , CASE WHEN d.exchange_rate IS NULL THEN 0.00 ELSE ABS(CAST(REPLACE(c.cost        , ',', '') AS DECIMAL)) / CAST(d.exchange_rate AS DECIMAL) END AS cost
         , CAST(REPLACE(c.margin_rate , ',', '') AS DECIMAL)                                                                                              AS margin_rate
         , c.so_curr
         , c.so_create_on
         , c.sales_org
         , c.distr_channel
         , c.plant
         , c.stor_loc
         , c.account_code
         , c.account_name
         , c.gc_id_gscm
         , c.gc_name
         , c.ap1_code
         , c.ap1_name
         , c.ap2_code
         , c.ap2_name
         , c.delivery
         , ABS(c.delivery_qty_base)                                                AS delivery_qty_base
         , c.billed_qty_base
         , c.billing_date
         , c.material_group
         , c.so_local_create_on_d
         , c.do_local_create_on_d
         , c."1ST_GI_LOCAL_CREATE"
         , c.billing_local_create
         , c.final_sch_date
         , c.last_modification_file
         , a.filterType
         , CASE WHEN c.delivery_qty_base < 0 THEN 'Returned' ELSE a.po_status END AS po_status
      FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_filter a
      JOIN ow_md.dim_subsidiary                                         b ON LOWER(b.country)    = LOWER(a.country)
      JOIN ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c ON c.sales_document    = a.id
                                                                           AND c.material          = a.po_sku
                                                                           AND c.sales_org         = b.sales_org
 LEFT JOIN ow_lao.ft_ap2_exchange_rate                                  d ON CAST(d.valid_from AS TIMESTAMP) = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS TIMESTAMP))
                                                                           AND d.to_currency       = a.currency
     WHERE a.filterType IN (2)
       AND NOT EXISTS(
                SELECT 1
                  FROM ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update aa
                 WHERE c.sales_document    = aa.id
                   AND c.material          = aa.po_sku
                   AND c.sales_org         = aa.sales_org
                   AND a.filterType        = aa.filterType
           );           

  -- Update base table with latest NERP snapshot
  PERFORM UPDATE ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown AS a
     SET so_idcode             = c.sales_document
       , po_status             = c.po_status
       , soldto_party          = c.sold_to_party
       , soldto_name           = c.name
       , nerp_sku              = c.material
       , nerp_sku_description  = c.item_descr
       , nerp_sku_division     = c.item_division
       , nerp_netprice         = CASE WHEN c.so_net_price < 0 THEN 0 ELSE c.so_net_price END
       , nerp_netvalue         = CASE WHEN c.so_net_value < 0 THEN 0 ELSE c.so_net_value END
       , nerp_cost             = c.cost
       , nerp_marginrate       = c.margin_rate
       , nerp_currency         = c.so_curr
       , so_date_kst           = c.so_create_on
       , nerp_countrycode      = c.sales_org
       , nerp_distchannel      = c.distr_channel
       , nerp_plant            = c.plant
       , nerp_storagelocation  = c.stor_loc
       , nerp_accountcode      = c.account_code
       , nerp_accountname      = c.account_name
       , nerp_id_gscm          = c.gc_id_gscm
       , nerp_gc_name          = c.gc_name
       , nerp_ap1_code         = c.ap1_code
       , nerp_ap1_name         = c.ap1_name
       , nerp_ap2_code         = c.ap2_code
       , nerp_ap2_name         = c.ap2_name
       , nerp_deliverycode     = c.delivery
       , nerp_deliveruqty      = c.delivery_qty_base
       , nerp_billingqty       = c.billed_qty_base
       , nerp_billingdate      = c.billing_date
       , nerp_material_group   = c.material_group
       , so_date               = c.so_local_create_on_d
       , do_date               = c.do_local_create_on_d
       , "1GI_DATE"           = c."1ST_GI_LOCAL_CREATE"
       , billing_date_local    = c.billing_local_create
       , final_date            = c.final_sch_date
       , nerp_last_update_date = CAST(c.last_modification_file AS TIMESTAMP)
       , updated_datetime      = CURRENT_TIMESTAMP
    FROM ow_md.dim_subsidiary b
    JOIN ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update c 
      ON c.material   = a.po_sku
     AND c.po_orderid = a.po_orderid
    LEFT JOIN ow_lao.ft_ap2_exchange_rate d 
      ON CAST(d.valid_from AS TIMESTAMP) = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS TIMESTAMP))
     AND d.to_currency = a.currency
   WHERE LOWER(b.country) = LOWER(a.country)
     AND c.sales_org      = b.sales_org
     AND (a.nerp_last_update_date < CAST(c.last_modification_file AS TIMESTAMP) OR a.nerp_last_update_date IS NULL);

END;
$$;

-- CALL OW_LAO.proc_tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_homolog();
-- ERROR: Severity: ERROR, Message: Relation "a" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_homolog line 483 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4345, Error Code: 4566, 
-- CALL OW_LAO.proc_tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_homolog();
-- ERROR: Severity: ERROR, Message: Relation "a" does not exist, Sqlstate: 42V01, Where: PL/vSQL procedure proc_tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_update_homolog line 483 at static SQL, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Catalog/CatalogLookup.cpp, Line: 4345, Error Code: 4566, 
