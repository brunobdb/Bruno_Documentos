-- CREATE OR REPLACE PROCEDURE u_prj_ecom.proc_ods_diggit_ecom_orders()
-- LANGUAGE PLvSQL AS $$
-- BEGIN
--  
--   SELECT MIN(order_creation_date) AS order_creation_min,
--          MAX(order_creation_date) AS order_creation_max
--   FROM u_prj_ecom.stg_diggit_ecom_orders;
-- 
--   PERFORM CREATE LOCAL TEMP TABLE tmp_stg_diggit_ecom_orders_aggregation ON COMMIT PRESERVE ROWS AS
--   SELECT order_code,
--          order_creation_date,
--          order_creation_hour,
--          country,
--          sku,
--          order_status,
--          channel,
--          store_name,
--          currency,
--          qty,
--          product_price,
--          revenue
--   FROM (
--     SELECT a.order_code,
--            a.order_creation_date,
--            a.order_creation_hour,
--            a.country,
--            a.sku,
--            a.order_status,
--            a.channel,
--            a.store_name,
--            a.currency,
--            SUM(CAST(a.qty AS INT)) AS qty,
--            a.product_price,
--            SUM(CAST(a.revenue AS DECIMAL(18,2))) AS revenue,
--            ROW_NUMBER() OVER (PARTITION BY order_code ORDER BY order_creation_date DESC, order_creation_hour DESC) AS rn
--     FROM u_prj_ecom.stg_diggit_ecom_orders a
--     GROUP BY a.order_code,
--              a.country,
--              a.sku,
--              a.order_status,
--              a.channel,
--              a.store_name,
--              a.currency,
--              a.product_price,
--              a.order_creation_date,
--              a.order_creation_hour
--   ) s
--   WHERE rn = 1;
-- 
--   SELECT CAST(MIN(order_creation_date) AS DATE) AS order_creation_min,
--          CAST(MAX(order_creation_date) AS DATE) AS order_creation_max
--   FROM tmp_stg_diggit_ecom_orders_aggregation;
-- 
--   PERFORM CREATE LOCAL TEMP TABLE orders_codes_cancelleds ON COMMIT PRESERVE ROWS AS
--   SELECT DISTINCT
--          a.order_code,
--          a.sku
--   FROM u_prj_ecom.ods_diggit_ecom_orders a
--   WHERE a.order_creation_date BETWEEN
--         (SELECT MIN(order_creation_date) FROM u_prj_ecom.stg_diggit_ecom_orders) AND
--         (SELECT MAX(order_creation_date) FROM u_prj_ecom.stg_diggit_ecom_orders)
--     AND NOT EXISTS (
--       SELECT 1
--       FROM u_prj_ecom.stg_diggit_ecom_orders aa
--       WHERE aa.order_code = a.order_code
--         AND aa.sku        = a.sku
--         AND aa.store_name = a.store_name
--     );
-- 
--   PERFORM UPDATE u_prj_ecom.ods_diggit_ecom_orders a
--     SET order_status = 'Cancelled',
--         updated_timestamp = CURRENT_TIMESTAMP
--   FROM orders_codes_cancelleds b
--   WHERE b.order_code = a.order_code
--     AND b.sku = a.sku
--     AND a.order_status <> 'Cancelled';
-- 
--   PERFORM MERGE INTO u_prj_ecom.ods_diggit_ecom_orders a
--   USING tmp_stg_diggit_ecom_orders_aggregation b
--   ON b.order_code = a.order_code
--      AND b.sku = a.sku
--   WHEN MATCHED THEN UPDATE
--     SET channel = b.channel,
--         store_name = b.store_name,
--         currency = b.currency,
--         qty = b.qty,
--         product_price = b.product_price,
--         revenue = b.revenue,
--         order_status = b.order_status,
--         order_creation_date = b.order_creation_date,
--         order_creation_hour = b.order_creation_hour,
--         updated_timestamp = CURRENT_TIMESTAMP
--   WHEN NOT MATCHED THEN INSERT (
--         order_code,
--         order_creation_date,
--         order_creation_hour,
--         country,
--         sku,
--         order_status,
--         channel,
--         store_name,
--         currency,
--         qty,
--         product_price,
--         revenue
--     )
--     VALUES (
--         b.order_code,
--         b.order_creation_date,
--         b.order_creation_hour,
--         b.country,
--         b.sku,
--         b.order_status,
--         b.channel,
--         b.store_name,
--         b.currency,
--         b.qty,
--         b.product_price,
--         b.revenue
--     );
-- 
-- END;
-- $$;
-- ERROR: Severity: ROLLBACK, Message: PL/vSQL parser failed at 6.41 of source string: syntax error, unexpected ;, expecting INTO, Sqlstate: 42601, Position: 253, Routine: error, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Proc/PLvSQL/Parser.cpp, Line: 177, Error Code: 10448, 
CREATE OR REPLACE PROCEDURE u_prj_ecom.proc_ods_diggit_ecom_orders()
LANGUAGE PLvSQL AS $$
BEGIN
  PERFORM CREATE LOCAL TEMP TABLE tmp_stg_diggit_ecom_orders_aggregation ON COMMIT PRESERVE ROWS AS
  SELECT order_code,
         order_creation_date,
         order_creation_hour,
         country,
         sku,
         order_status,
         channel,
         store_name,
         currency,
         qty,
         product_price,
         revenue
  FROM (
    SELECT a.order_code,
           a.order_creation_date,
           a.order_creation_hour,
           a.country,
           a.sku,
           a.order_status,
           a.channel,
           a.store_name,
           a.currency,
           SUM(CAST(a.qty AS INT)) AS qty,
           a.product_price,
           SUM(CAST(a.revenue AS DECIMAL(18,2))) AS revenue,
           ROW_NUMBER() OVER (PARTITION BY a.order_code ORDER BY a.order_creation_date DESC, a.order_creation_hour DESC) AS rn
    FROM u_prj_ecom.stg_diggit_ecom_orders a
    GROUP BY a.order_code,
             a.country,
             a.sku,
             a.order_status,
             a.channel,
             a.store_name,
             a.currency,
             a.product_price,
             a.order_creation_date,
             a.order_creation_hour
  ) s
  WHERE rn = 1;

  PERFORM CREATE LOCAL TEMP TABLE orders_codes_cancelleds ON COMMIT PRESERVE ROWS AS
  SELECT DISTINCT a.order_code, a.sku
  FROM u_prj_ecom.ods_diggit_ecom_orders a
  WHERE a.order_creation_date BETWEEN
        (SELECT MIN(order_creation_date) FROM u_prj_ecom.stg_diggit_ecom_orders)
        AND
        (SELECT MAX(order_creation_date) FROM u_prj_ecom.stg_diggit_ecom_orders)
    AND NOT EXISTS (
      SELECT 1
      FROM u_prj_ecom.stg_diggit_ecom_orders aa
      WHERE aa.order_code = a.order_code
        AND aa.sku = a.sku
        AND aa.store_name = a.store_name
  );

  PERFORM UPDATE u_prj_ecom.ods_diggit_ecom_orders a
  SET order_status = 'Cancelled',
      updated_timestamp = CURRENT_TIMESTAMP
  FROM orders_codes_cancelleds b
  WHERE b.order_code = a.order_code
    AND b.sku = a.sku
    AND a.order_status <> 'Cancelled';

  PERFORM MERGE INTO u_prj_ecom.ods_diggit_ecom_orders a
  USING tmp_stg_diggit_ecom_orders_aggregation b
  ON b.order_code = a.order_code AND b.sku = a.sku
  WHEN MATCHED THEN UPDATE SET
      channel = b.channel,
      store_name = b.store_name,
      currency = b.currency,
      qty = b.qty,
      product_price = b.product_price,
      revenue = b.revenue,
      order_status = b.order_status,
      order_creation_date = b.order_creation_date,
      order_creation_hour = b.order_creation_hour,
      updated_timestamp = CURRENT_TIMESTAMP
  WHEN NOT MATCHED THEN INSERT
      (order_code, order_creation_date, order_creation_hour, country, sku, order_status, channel, store_name, currency, qty, product_price, revenue)
      VALUES (b.order_code, b.order_creation_date, b.order_creation_hour, b.country, b.sku, b.order_status, b.channel, b.store_name, b.currency, b.qty, b.product_price, b.revenue);

END;
$$;

CALL u_prj_ecom.proc_ods_diggit_ecom_orders();
-- proc_ods_diggit_ecom_orders
-- ---------------------------
-- 0

