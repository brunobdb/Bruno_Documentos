CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_sales_control_tower_table_diggit()
LANGUAGE PLvSQL AS $$
BEGIN

  PERFORM CREATE LOCAL TEMPORARY TABLE vt_ods_diggit_ecom_orders_prepare ON COMMIT PRESERVE ROWS AS (
    SELECT
        CAST((a.order_creation_date || ' ' || a.order_creation_hour) AS TIMESTAMP) AS po_date,
        EXTRACT(MONTH FROM a.order_creation_date) AS po_month,
        EXTRACT(YEAR  FROM a.order_creation_date) AS po_year,
        b.country AS country,
        b.subsidiary AS subsidiary,
        b.currency AS currency,
        COALESCE(a.updated_timestamp, a.inserted_timestamp) AS po_lastupdate_date_hour,
        COALESCE(a.updated_timestamp, a.inserted_timestamp) AS po_source_last_update_date,
        a.order_code AS po_orderid,
        'diggit' AS po_seller_name,
        a.sku AS po_prodname,
        CAST(NULL AS VARCHAR(255)) AS po_storename,
        a.store_name AS po_store_name,
        CAST(NULL AS VARCHAR(255)) AS channel,
        CAST(NULL AS VARCHAR(255)) AS biz_type,
        CAST(NULL AS VARCHAR(255)) AS audience_type,
        c.status AS po_status,
        a.order_status AS po_internal_status,
        a.sku AS po_sku,
        SUM(ABS(a.qty)) AS po_qty,
        0 AS po_orderqty,
        CAST(0.00 AS DECIMAL(18,2)) AS po_itemdiscount_localcurr,
        CAST(0.00 AS DECIMAL(18,2)) AS po_itemdiscount_usd,
        SUM(CAST(a.product_price AS DECIMAL(18,2))) AS po_price_localcurr,
        CAST(0.00 AS DECIMAL(18,2)) AS po_price_usd,
        'u_prj_ecom.ods_diggit_ecom_orders' AS po_plataform_datasource,
        a.inserted_timestamp AS po_source_insert_date,
        CAST(0.00 AS DECIMAL(18,2)) AS po_totalprice_usd,
        CAST(0.00 AS DECIMAL(18,2)) AS po_totalprice_local,
        MAX(a.id) AS po_plataform_datasource_order_id,
        CAST(NULL AS VARCHAR(255)) AS po_devicetype,
        '' AS po_sku_kit,
        '' AS po_prodname_kit,
        CAST(0.00 AS DECIMAL(18,2)) AS po_price_localcurr_kit,
        CAST(0.00 AS DECIMAL(18,2)) AS po_itemdiscount_localcurr_kit,
        FALSE AS is_kit,
        'ARG' AS country_cd,
        CAST(NULL AS VARCHAR(3)) AS biz_type_ebi_hq,
        CAST(NULL AS VARCHAR(3)) AS global_channel_ebi_hq,
        1 AS installment,
        MAX(b.id) AS client_subsidiary_id,
        'diggit' AS po_sitecode,
        CAST(a.order_creation_hour AS TIME) AS po_hour,
        CAST(NULL AS VARCHAR(255)) AS customer_type,
        CAST(NULL AS VARCHAR(255)) AS po_mobile_os
    FROM u_prj_ecom.ods_diggit_ecom_orders a
    JOIN u_prj_ecom.dim_subsidiary b ON b.id = 1
    LEFT JOIN ow_lao.dim_ods_sales_control_tower_table_status_mapping c ON c.status_origin = COALESCE(a.order_status, 'incomplete')
    WHERE a.qty > 0
      AND NOT EXISTS (
        SELECT 1
        FROM ow_lao.ods_sales_control_tower_table aa
        WHERE aa.po_orderid = a.order_code
          AND aa.po_sku = a.sku
          AND aa.client_subsidiary_id = 1
          AND aa.po_sitecode = 'diggit'
          AND aa.po_internal_status = a.order_status
      )
      AND a.store_name NOT IN (
        '7960 - DIGGIT MENDOZA',
        '7B10 - DIGGIT LA RIOJA',
        '7B90 - DIGGIT-CBA-PDV-NUEVOCENTRO',
        '7C10 - DIGGIT ABASTO',
        '7950 - DIGGIT QUILMES',
        '7A10 - DIGGIT BAHIA BLANCA',
        '7A70 - DIGGIT SALTA',
        '7B80 - DIGGIT - MZ - PDV - PALMARES',
        '7970 - DIGGIT LOMAS',
        '7A80 - DIGGIT ALTO ROSARIO',
        '7B00 - DIGGIT PLAZA OESTE',
        '7990 - DIGGIT SAN MIGUEL',
        '7980 - DIGGIT PERU',
        '7A00 - DIGGIT TUCUMAN',
        '7A20 - DIGGIT SANTA FE',
        '7A40 - DIGGIT MERLO',
        '7C70 - DIGGIT RIO GRANDE',
        '7940 - DIGGIT USHUAIA'
      )
    GROUP BY
        CAST((a.order_creation_date || ' ' || a.order_creation_hour) AS TIMESTAMP),
        EXTRACT(MONTH FROM a.order_creation_date),
        EXTRACT(YEAR  FROM a.order_creation_date),
        b.country,
        b.subsidiary,
        b.currency,
        a.inserted_timestamp,
        a.updated_timestamp,
        a.order_code,
        c.status,
        a.order_status,
        a.sku,
        a.store_name,
        CAST(a.order_creation_hour AS TIME)
  );

  PERFORM CREATE LOCAL TEMPORARY TABLE vt_ods_diggit_ecom_orders_prepare_agg ON COMMIT PRESERVE ROWS AS (
    SELECT
      country,
      po_orderid,
      SUM(po_qty) AS po_orderqty,
      SUM(po_price_localcurr) AS po_totalprice_local
    FROM vt_ods_diggit_ecom_orders_prepare
    GROUP BY country, po_orderid
  );

  PERFORM CREATE LOCAL TEMPORARY TABLE vt_ods_diggit_ecom_orders_prepare_sku_agg ON COMMIT PRESERVE ROWS AS (
    SELECT
      country,
      po_orderid,
      po_sku,
      SUM(po_qty) AS po_orderqty,
      SUM(po_price_localcurr) AS po_totalprice_local,
      SUM(po_itemdiscount_localcurr) AS po_itemdiscount_localcurr
    FROM vt_ods_diggit_ecom_orders_prepare
    GROUP BY country, po_orderid, po_sku
  );

  PERFORM UPDATE vt_ods_diggit_ecom_orders_prepare a
    SET po_orderqty = b.po_orderqty,
        po_totalprice_local = (c.po_totalprice_local * c.po_orderqty) - c.po_itemdiscount_localcurr
  FROM vt_ods_diggit_ecom_orders_prepare_agg b
  JOIN vt_ods_diggit_ecom_orders_prepare_sku_agg c
    ON c.country = b.country AND c.po_orderid = b.po_orderid
  WHERE b.country = a.country
    AND b.po_orderid = a.po_orderid
    AND c.country = a.country
    AND c.po_orderid = a.po_orderid
    AND c.po_sku = a.po_sku;

  PERFORM UPDATE vt_ods_diggit_ecom_orders_prepare a
    SET po_itemdiscount_usd = a.po_itemdiscount_localcurr / CAST(b.exchange_rate AS DECIMAL(18,6)),
        po_price_usd        = a.po_price_localcurr        / CAST(b.exchange_rate AS DECIMAL(18,6)),
        po_totalprice_usd   = a.po_totalprice_local       / CAST(b.exchange_rate AS DECIMAL(18,6))
  FROM ow_lao.ft_ap2_exchange_rate b
  WHERE b.valid_from  = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE))
    AND b.to_currency = a.currency;

  PERFORM UPDATE vt_ods_diggit_ecom_orders_prepare a
    SET channel               = b.global_channel,
        biz_type              = b.biz_type,
        audience_type         = b.audience_type,
        biz_type_ebi_hq       = b.biz_type_ebi,
        global_channel_ebi_hq = b.global_channel_ebi,
        po_storename          = b.partner_level,
        customer_type         = b.customer_type,
        po_mobile_os          = b.po_mobile_os
  FROM ow_md.sales_channel b
  WHERE LOWER(b.country) = LOWER(a.country)
    AND LOWER(b.identifier) = LOWER(a.po_store_name)
    AND a.client_subsidiary_id = 1
    AND LOWER(b.plataform_type) = 'diggit';

  PERFORM UPDATE vt_ods_diggit_ecom_orders_prepare
    SET po_devicetype = 'MOBILEAPP'
  WHERE po_sitecode = 'samsungarapp'
    AND client_subsidiary_id = 1;

  PERFORM UPDATE vt_ods_diggit_ecom_orders_prepare
    SET po_devicetype = 'Web'
  WHERE po_devicetype IS NULL;

  PERFORM UPDATE vt_ods_diggit_ecom_orders_prepare
    SET global_channel_ebi_hq = '3PD',
        biz_type_ebi_hq = 'B2C'
  WHERE global_channel_ebi_hq IS NULL;

  PERFORM UPDATE vt_ods_diggit_ecom_orders_prepare
    SET channel = 'eStore',
        biz_type = '3PD',
        audience_type = '3PD'
  WHERE channel IS NULL;

  PERFORM MERGE INTO ow_lao.ods_sales_control_tower_table a
  USING vt_ods_diggit_ecom_orders_prepare b
     ON b.po_orderid  = a.po_orderid
    AND b.po_sku      = a.po_sku
    AND b.country     = a.country
    AND b.po_sku_kit  = a.po_sku_kit
    AND b.po_sitecode = a.po_sitecode
  WHEN MATCHED THEN UPDATE SET
       po_date                         = b.po_date,
       podate_month                    = b.po_month,
       podate_year                     = b.po_year,
       country                         = b.country,
       subsidiary                      = b.subsidiary,
       currency                        = b.currency,
       po_lastupdate_date_hour         = b.po_lastupdate_date_hour,
       po_source_last_update_date      = b.po_source_last_update_date,
       po_orderid                      = b.po_orderid,
       po_seller_name                  = b.po_seller_name,
       po_prodname                     = b.po_prodname,
       po_storename                    = b.po_storename,
       po_store_name                   = b.po_store_name,
       channel                         = b.channel,
       biz_type                        = b.biz_type,
       audience_type                   = b.audience_type,
       po_status                       = b.po_status,
       po_internal_status              = b.po_internal_status,
       po_sku                          = b.po_sku,
       po_qty                          = b.po_qty,
       po_orderqty                     = b.po_orderqty,
       po_itemdiscount_localcurr       = b.po_itemdiscount_localcurr,
       po_itemdiscount_usd             = b.po_itemdiscount_usd,
       po_price_localcurr              = b.po_price_localcurr,
       po_price_usd                    = b.po_price_usd,
       po_plataform_datasource         = b.po_plataform_datasource,
       po_source_insert_date           = b.po_source_insert_date,
       po_totalprice_usd               = b.po_totalprice_usd,
       po_totalprice_local             = b.po_totalprice_local,
       po_devicetype                   = b.po_devicetype,
       po_sku_kit                      = b.po_sku_kit,
       po_prodname_kit                 = b.po_prodname_kit,
       is_kit                          = b.is_kit,
       country_cd                      = b.country_cd,
       biz_type_ebi_hq                 = b.biz_type_ebi_hq,
       global_channel_ebi_hq           = b.global_channel_ebi_hq,
       installment                     = b.installment,
       customer_type                   = b.customer_type,
       po_mobile_os                    = b.po_mobile_os,
       updated_datetime                = CURRENT_TIMESTAMP
  WHEN NOT MATCHED THEN INSERT (
       po_date,
       podate_month,
       podate_year,
       country,
       subsidiary,
       currency,
       po_lastupdate_date_hour,
       po_source_last_update_date,
       po_orderid,
       po_seller_name,
       po_prodname,
       po_storename,
       po_store_name,
       channel,
       biz_type,
       audience_type,
       po_status,
       po_internal_status,
       po_sku,
       po_qty,
       po_orderqty,
       po_itemdiscount_localcurr,
       po_itemdiscount_usd,
       po_price_localcurr,
       po_price_usd,
       po_plataform_datasource,
       po_source_insert_date,
       po_totalprice_usd,
       po_totalprice_local,
       po_devicetype,
       po_sku_kit,
       po_prodname_kit,
       is_kit,
       country_cd,
       biz_type_ebi_hq,
       global_channel_ebi_hq,
       installment,
       samsung_care_order,
       samsung_care_eligibility,
       trade_in_eligibility,
       client_subsidiary_id,
       po_sitecode,
       customer_type,
       po_mobile_os
  ) VALUES (
       b.po_date,
       b.po_month,
       b.po_year,
       b.country,
       b.subsidiary,
       b.currency,
       b.po_lastupdate_date_hour,
       b.po_source_last_update_date,
       b.po_orderid,
       b.po_seller_name,
       b.po_prodname,
       b.po_storename,
       b.po_store_name,
       b.channel,
       b.biz_type,
       b.audience_type,
       b.po_status,
       b.po_internal_status,
       b.po_sku,
       b.po_qty,
       b.po_orderqty,
       b.po_itemdiscount_localcurr,
       b.po_itemdiscount_usd,
       b.po_price_localcurr,
       b.po_price_usd,
       b.po_plataform_datasource,
       b.po_source_insert_date,
       b.po_totalprice_usd,
       b.po_totalprice_local,
       b.po_devicetype,
       b.po_sku_kit,
       b.po_prodname_kit,
       b.is_kit,
       b.country_cd,
       b.biz_type_ebi_hq,
       b.global_channel_ebi_hq,
       b.installment,
       0,
       0,
       0,
       b.client_subsidiary_id,
       b.po_sitecode,
       b.customer_type,
       b.po_mobile_os
  );

END;
$$;

-- CALL OW_LAO.proc_ods_sales_control_tower_table_diggit();
-- ERROR: Severity: ERROR, Message: Function catalog.date_part(unknown, varchar) does not exist, or permission is denied for catalog.date_part(unknown, varchar), Sqlstate: 42883, Hint: No function matches the given name and argument types. Candidates are: catalog.date_part(field::varchar, date::timetz) catalog.date_part(field::varchar, date::time) catalog.date_part(field::varchar, date::interval(in months)) catalog.date_part(field::varchar, date::interval(in seconds)) catalog.date_part(field::varchar, date::timestamp), Where: PL/vSQL procedure proc_ods_sales_control_tower_table_diggit line 4 at static SQL, Routine: throwErrorFunctionDoesNotMatchCandidates, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/ParseFunc.cpp, Line: 4569, Error Code: 3457, 
-- CALL OW_LAO.proc_ods_sales_control_tower_table_diggit();
-- ERROR: Severity: ERROR, Message: Function catalog.date_part(unknown, varchar) does not exist, or permission is denied for catalog.date_part(unknown, varchar), Sqlstate: 42883, Hint: No function matches the given name and argument types. Candidates are: catalog.date_part(field::varchar, date::timetz) catalog.date_part(field::varchar, date::time) catalog.date_part(field::varchar, date::interval(in months)) catalog.date_part(field::varchar, date::interval(in seconds)) catalog.date_part(field::varchar, date::timestamp), Where: PL/vSQL procedure proc_ods_sales_control_tower_table_diggit line 4 at static SQL, Routine: throwErrorFunctionDoesNotMatchCandidates, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/ParseFunc.cpp, Line: 4569, Error Code: 3457, 
CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_sales_control_tower_table_diggit()
LANGUAGE PLvSQL AS $$
BEGIN

  PERFORM CREATE LOCAL TEMPORARY TABLE vt_ods_diggit_ecom_orders_prepare ON COMMIT PRESERVE ROWS AS (
    SELECT
        CAST((a.order_creation_date || ' ' || a.order_creation_hour) AS TIMESTAMP) AS po_date,
        EXTRACT(MONTH FROM CAST(a.order_creation_date AS DATE)) AS po_month,
        EXTRACT(YEAR  FROM CAST(a.order_creation_date AS DATE)) AS po_year,
        b.country AS country,
        b.subsidiary AS subsidiary,
        b.currency AS currency,
        COALESCE(a.updated_timestamp, a.inserted_timestamp) AS po_lastupdate_date_hour,
        COALESCE(a.updated_timestamp, a.inserted_timestamp) AS po_source_last_update_date,
        a.order_code AS po_orderid,
        'diggit' AS po_seller_name,
        a.sku AS po_prodname,
        CAST(NULL AS VARCHAR(255)) AS po_storename,
        a.store_name AS po_store_name,
        CAST(NULL AS VARCHAR(255)) AS channel,
        CAST(NULL AS VARCHAR(255)) AS biz_type,
        CAST(NULL AS VARCHAR(255)) AS audience_type,
        c.status AS po_status,
        a.order_status AS po_internal_status,
        a.sku AS po_sku,
        SUM(ABS(a.qty)) AS po_qty,
        0 AS po_orderqty,
        CAST(0.00 AS DECIMAL(18,2)) AS po_itemdiscount_localcurr,
        CAST(0.00 AS DECIMAL(18,2)) AS po_itemdiscount_usd,
        SUM(CAST(a.product_price AS DECIMAL(18,2))) AS po_price_localcurr,
        CAST(0.00 AS DECIMAL(18,2)) AS po_price_usd,
        'u_prj_ecom.ods_diggit_ecom_orders' AS po_plataform_datasource,
        a.inserted_timestamp AS po_source_insert_date,
        CAST(0.00 AS DECIMAL(18,2)) AS po_totalprice_usd,
        CAST(0.00 AS DECIMAL(18,2)) AS po_totalprice_local,
        MAX(a.id) AS po_plataform_datasource_order_id,
        CAST(NULL AS VARCHAR(255)) AS po_devicetype,
        '' AS po_sku_kit,
        '' AS po_prodname_kit,
        CAST(0.00 AS DECIMAL(18,2)) AS po_price_localcurr_kit,
        CAST(0.00 AS DECIMAL(18,2)) AS po_itemdiscount_localcurr_kit,
        FALSE AS is_kit,
        'ARG' AS country_cd,
        CAST(NULL AS VARCHAR(3)) AS biz_type_ebi_hq,
        CAST(NULL AS VARCHAR(3)) AS global_channel_ebi_hq,
        1 AS installment,
        MAX(b.id) AS client_subsidiary_id,
        'diggit' AS po_sitecode,
        CAST(a.order_creation_hour AS TIME) AS po_hour,
        CAST(NULL AS VARCHAR(255)) AS customer_type,
        CAST(NULL AS VARCHAR(255)) AS po_mobile_os
    FROM u_prj_ecom.ods_diggit_ecom_orders a
    JOIN u_prj_ecom.dim_subsidiary b ON b.id = 1
    LEFT JOIN ow_lao.dim_ods_sales_control_tower_table_status_mapping c ON c.status_origin = COALESCE(a.order_status, 'incomplete')
    WHERE a.qty > 0
      AND NOT EXISTS (
        SELECT 1
        FROM ow_lao.ods_sales_control_tower_table aa
        WHERE aa.po_orderid = a.order_code
          AND aa.po_sku = a.sku
          AND aa.client_subsidiary_id = 1
          AND aa.po_sitecode = 'diggit'
          AND aa.po_internal_status = a.order_status
      )
      AND a.store_name NOT IN (
        '7960 - DIGGIT MENDOZA',
        '7B10 - DIGGIT LA RIOJA',
        '7B90 - DIGGIT-CBA-PDV-NUEVOCENTRO',
        '7C10 - DIGGIT ABASTO',
        '7950 - DIGGIT QUILMES',
        '7A10 - DIGGIT BAHIA BLANCA',
        '7A70 - DIGGIT SALTA',
        '7B80 - DIGGIT - MZ - PDV - PALMARES',
        '7970 - DIGGIT LOMAS',
        '7A80 - DIGGIT ALTO ROSARIO',
        '7B00 - DIGGIT PLAZA OESTE',
        '7990 - DIGGIT SAN MIGUEL',
        '7980 - DIGGIT PERU',
        '7A00 - DIGGIT TUCUMAN',
        '7A20 - DIGGIT SANTA FE',
        '7A40 - DIGGIT MERLO',
        '7C70 - DIGGIT RIO GRANDE',
        '7940 - DIGGIT USHUAIA'
      )
    GROUP BY
        CAST((a.order_creation_date || ' ' || a.order_creation_hour) AS TIMESTAMP),
        EXTRACT(MONTH FROM CAST(a.order_creation_date AS DATE)),
        EXTRACT(YEAR  FROM CAST(a.order_creation_date AS DATE)),
        b.country,
        b.subsidiary,
        b.currency,
        a.inserted_timestamp,
        a.updated_timestamp,
        a.order_code,
        c.status,
        a.order_status,
        a.sku,
        a.store_name,
        CAST(a.order_creation_hour AS TIME)
  );

  PERFORM CREATE LOCAL TEMPORARY TABLE vt_ods_diggit_ecom_orders_prepare_agg ON COMMIT PRESERVE ROWS AS (
    SELECT
      country,
      po_orderid,
      SUM(po_qty) AS po_orderqty,
      SUM(po_price_localcurr) AS po_totalprice_local
    FROM vt_ods_diggit_ecom_orders_prepare
    GROUP BY country, po_orderid
  );

  PERFORM CREATE LOCAL TEMPORARY TABLE vt_ods_diggit_ecom_orders_prepare_sku_agg ON COMMIT PRESERVE ROWS AS (
    SELECT
      country,
      po_orderid,
      po_sku,
      SUM(po_qty) AS po_orderqty,
      SUM(po_price_localcurr) AS po_totalprice_local,
      SUM(po_itemdiscount_localcurr) AS po_itemdiscount_localcurr
    FROM vt_ods_diggit_ecom_orders_prepare
    GROUP BY country, po_orderid, po_sku
  );

  PERFORM UPDATE vt_ods_diggit_ecom_orders_prepare a
    SET po_orderqty = b.po_orderqty,
        po_totalprice_local = (c.po_totalprice_local * c.po_orderqty) - c.po_itemdiscount_localcurr
  FROM vt_ods_diggit_ecom_orders_prepare_agg b
  JOIN vt_ods_diggit_ecom_orders_prepare_sku_agg c
    ON c.country = b.country AND c.po_orderid = b.po_orderid
  WHERE b.country = a.country
    AND b.po_orderid = a.po_orderid
    AND c.country = a.country
    AND c.po_orderid = a.po_orderid
    AND c.po_sku = a.po_sku;

  PERFORM UPDATE vt_ods_diggit_ecom_orders_prepare a
    SET po_itemdiscount_usd = a.po_itemdiscount_localcurr / CAST(b.exchange_rate AS DECIMAL(18,6)),
        po_price_usd        = a.po_price_localcurr        / CAST(b.exchange_rate AS DECIMAL(18,6)),
        po_totalprice_usd   = a.po_totalprice_local       / CAST(b.exchange_rate AS DECIMAL(18,6))
  FROM ow_lao.ft_ap2_exchange_rate b
  WHERE b.valid_from  = TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE))
    AND b.to_currency = a.currency;

  PERFORM UPDATE vt_ods_diggit_ecom_orders_prepare a
    SET channel               = b.global_channel,
        biz_type              = b.biz_type,
        audience_type         = b.audience_type,
        biz_type_ebi_hq       = b.biz_type_ebi,
        global_channel_ebi_hq = b.global_channel_ebi,
        po_storename          = b.partner_level,
        customer_type         = b.customer_type,
        po_mobile_os          = b.po_mobile_os
  FROM ow_md.sales_channel b
  WHERE LOWER(b.country) = LOWER(a.country)
    AND LOWER(b.identifier) = LOWER(a.po_store_name)
    AND a.client_subsidiary_id = 1
    AND LOWER(b.plataform_type) = 'diggit';

  PERFORM UPDATE vt_ods_diggit_ecom_orders_prepare
    SET po_devicetype = 'MOBILEAPP'
  WHERE po_sitecode = 'samsungarapp'
    AND client_subsidiary_id = 1;

  PERFORM UPDATE vt_ods_diggit_ecom_orders_prepare
    SET po_devicetype = 'Web'
  WHERE po_devicetype IS NULL;

  PERFORM UPDATE vt_ods_diggit_ecom_orders_prepare
    SET global_channel_ebi_hq = '3PD',
        biz_type_ebi_hq = 'B2C'
  WHERE global_channel_ebi_hq IS NULL;

  PERFORM UPDATE vt_ods_diggit_ecom_orders_prepare
    SET channel = 'eStore',
        biz_type = '3PD',
        audience_type = '3PD'
  WHERE channel IS NULL;

  PERFORM MERGE INTO ow_lao.ods_sales_control_tower_table a
  USING vt_ods_diggit_ecom_orders_prepare b
     ON b.po_orderid  = a.po_orderid
    AND b.po_sku      = a.po_sku
    AND b.country     = a.country
    AND b.po_sku_kit  = a.po_sku_kit
    AND b.po_sitecode = a.po_sitecode
  WHEN MATCHED THEN UPDATE SET
       po_date                         = b.po_date,
       podate_month                    = b.po_month,
       podate_year                     = b.po_year,
       country                         = b.country,
       subsidiary                      = b.subsidiary,
       currency                        = b.currency,
       po_lastupdate_date_hour         = b.po_lastupdate_date_hour,
       po_source_last_update_date      = b.po_source_last_update_date,
       po_orderid                      = b.po_orderid,
       po_seller_name                  = b.po_seller_name,
       po_prodname                     = b.po_prodname,
       po_storename                    = b.po_storename,
       po_store_name                   = b.po_store_name,
       channel                         = b.channel,
       biz_type                        = b.biz_type,
       audience_type                   = b.audience_type,
       po_status                       = b.po_status,
       po_internal_status              = b.po_internal_status,
       po_sku                          = b.po_sku,
       po_qty                          = b.po_qty,
       po_orderqty                     = b.po_orderqty,
       po_itemdiscount_localcurr       = b.po_itemdiscount_localcurr,
       po_itemdiscount_usd             = b.po_itemdiscount_usd,
       po_price_localcurr              = b.po_price_localcurr,
       po_price_usd                    = b.po_price_usd,
       po_plataform_datasource         = b.po_plataform_datasource,
       po_source_insert_date           = b.po_source_insert_date,
       po_totalprice_usd               = b.po_totalprice_usd,
       po_totalprice_local             = b.po_totalprice_local,
       po_devicetype                   = b.po_devicetype,
       po_sku_kit                      = b.po_sku_kit,
       po_prodname_kit                 = b.po_prodname_kit,
       is_kit                          = b.is_kit,
       country_cd                      = b.country_cd,
       biz_type_ebi_hq                 = b.biz_type_ebi_hq,
       global_channel_ebi_hq           = b.global_channel_ebi_hq,
       installment                     = b.installment,
       customer_type                   = b.customer_type,
       po_mobile_os                    = b.po_mobile_os,
       updated_datetime                = CURRENT_TIMESTAMP
  WHEN NOT MATCHED THEN INSERT (
       po_date,
       podate_month,
       podate_year,
       country,
       subsidiary,
       currency,
       po_lastupdate_date_hour,
       po_source_last_update_date,
       po_orderid,
       po_seller_name,
       po_prodname,
       po_storename,
       po_store_name,
       channel,
       biz_type,
       audience_type,
       po_status,
       po_internal_status,
       po_sku,
       po_qty,
       po_orderqty,
       po_itemdiscount_localcurr,
       po_itemdiscount_usd,
       po_price_localcurr,
       po_price_usd,
       po_plataform_datasource,
       po_source_insert_date,
       po_totalprice_usd,
       po_totalprice_local,
       po_devicetype,
       po_sku_kit,
       po_prodname_kit,
       is_kit,
       country_cd,
       biz_type_ebi_hq,
       global_channel_ebi_hq,
       installment,
       samsung_care_order,
       samsung_care_eligibility,
       trade_in_eligibility,
       client_subsidiary_id,
       po_sitecode,
       customer_type,
       po_mobile_os
  ) VALUES (
       b.po_date,
       b.po_month,
       b.po_year,
       b.country,
       b.subsidiary,
       b.currency,
       b.po_lastupdate_date_hour,
       b.po_source_last_update_date,
       b.po_orderid,
       b.po_seller_name,
       b.po_prodname,
       b.po_storename,
       b.po_store_name,
       b.channel,
       b.biz_type,
       b.audience_type,
       b.po_status,
       b.po_internal_status,
       b.po_sku,
       b.po_qty,
       b.po_orderqty,
       b.po_itemdiscount_localcurr,
       b.po_itemdiscount_usd,
       b.po_price_localcurr,
       b.po_price_usd,
       b.po_plataform_datasource,
       b.po_source_insert_date,
       b.po_totalprice_usd,
       b.po_totalprice_local,
       b.po_devicetype,
       b.po_sku_kit,
       b.po_prodname_kit,
       b.is_kit,
       b.country_cd,
       b.biz_type_ebi_hq,
       b.global_channel_ebi_hq,
       b.installment,
       0,
       0,
       0,
       b.client_subsidiary_id,
       b.po_sitecode,
       b.customer_type,
       b.po_mobile_os
  );

END;
$$;

-- CALL OW_LAO.proc_ods_sales_control_tower_table_diggit();
-- ERROR: Severity: ERROR, Message: Operator does not exist: varchar = timestamp, Sqlstate: 42883, Hint: No operator matches the given name and argument type(s). You may need to add explicit type casts, Where: PL/vSQL procedure proc_ods_sales_control_tower_table_diggit line 135 at static SQL, Routine: op_error, File: parse_oper.c, Line: 608, Error Code: 4286, 
-- CALL OW_LAO.proc_ods_sales_control_tower_table_diggit();
-- ERROR: Severity: ERROR, Message: Operator does not exist: varchar = timestamp, Sqlstate: 42883, Hint: No operator matches the given name and argument type(s). You may need to add explicit type casts, Where: PL/vSQL procedure proc_ods_sales_control_tower_table_diggit line 135 at static SQL, Routine: op_error, File: parse_oper.c, Line: 608, Error Code: 4286, 
CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_sales_control_tower_table_diggit()
LANGUAGE PLvSQL AS $$
BEGIN

  PERFORM CREATE LOCAL TEMPORARY TABLE vt_ods_diggit_ecom_orders_prepare ON COMMIT PRESERVE ROWS AS (
    SELECT
        CAST((a.order_creation_date || ' ' || a.order_creation_hour) AS TIMESTAMP) AS po_date,
        EXTRACT(MONTH FROM CAST(a.order_creation_date AS DATE)) AS po_month,
        EXTRACT(YEAR  FROM CAST(a.order_creation_date AS DATE)) AS po_year,
        b.country AS country,
        b.subsidiary AS subsidiary,
        b.currency AS currency,
        COALESCE(a.updated_timestamp, a.inserted_timestamp) AS po_lastupdate_date_hour,
        COALESCE(a.updated_timestamp, a.inserted_timestamp) AS po_source_last_update_date,
        a.order_code AS po_orderid,
        'diggit' AS po_seller_name,
        a.sku AS po_prodname,
        CAST(NULL AS VARCHAR(255)) AS po_storename,
        a.store_name AS po_store_name,
        CAST(NULL AS VARCHAR(255)) AS channel,
        CAST(NULL AS VARCHAR(255)) AS biz_type,
        CAST(NULL AS VARCHAR(255)) AS audience_type,
        c.status AS po_status,
        a.order_status AS po_internal_status,
        a.sku AS po_sku,
        SUM(ABS(a.qty)) AS po_qty,
        0 AS po_orderqty,
        CAST(0.00 AS DECIMAL(18,2)) AS po_itemdiscount_localcurr,
        CAST(0.00 AS DECIMAL(18,2)) AS po_itemdiscount_usd,
        SUM(CAST(a.product_price AS DECIMAL(18,2))) AS po_price_localcurr,
        CAST(0.00 AS DECIMAL(18,2)) AS po_price_usd,
        'u_prj_ecom.ods_diggit_ecom_orders' AS po_plataform_datasource,
        a.inserted_timestamp AS po_source_insert_date,
        CAST(0.00 AS DECIMAL(18,2)) AS po_totalprice_usd,
        CAST(0.00 AS DECIMAL(18,2)) AS po_totalprice_local,
        MAX(a.id) AS po_plataform_datasource_order_id,
        CAST(NULL AS VARCHAR(255)) AS po_devicetype,
        '' AS po_sku_kit,
        '' AS po_prodname_kit,
        CAST(0.00 AS DECIMAL(18,2)) AS po_price_localcurr_kit,
        CAST(0.00 AS DECIMAL(18,2)) AS po_itemdiscount_localcurr_kit,
        FALSE AS is_kit,
        'ARG' AS country_cd,
        CAST(NULL AS VARCHAR(3)) AS biz_type_ebi_hq,
        CAST(NULL AS VARCHAR(3)) AS global_channel_ebi_hq,
        1 AS installment,
        MAX(b.id) AS client_subsidiary_id,
        'diggit' AS po_sitecode,
        CAST(a.order_creation_hour AS TIME) AS po_hour,
        CAST(NULL AS VARCHAR(255)) AS customer_type,
        CAST(NULL AS VARCHAR(255)) AS po_mobile_os
    FROM u_prj_ecom.ods_diggit_ecom_orders a
    JOIN u_prj_ecom.dim_subsidiary b ON b.id = 1
    LEFT JOIN ow_lao.dim_ods_sales_control_tower_table_status_mapping c ON c.status_origin = COALESCE(a.order_status, 'incomplete')
    WHERE a.qty > 0
      AND NOT EXISTS (
        SELECT 1
        FROM ow_lao.ods_sales_control_tower_table aa
        WHERE aa.po_orderid = a.order_code
          AND aa.po_sku = a.sku
          AND aa.client_subsidiary_id = 1
          AND aa.po_sitecode = 'diggit'
          AND aa.po_internal_status = a.order_status
      )
      AND a.store_name NOT IN (
        '7960 - DIGGIT MENDOZA',
        '7B10 - DIGGIT LA RIOJA',
        '7B90 - DIGGIT-CBA-PDV-NUEVOCENTRO',
        '7C10 - DIGGIT ABASTO',
        '7950 - DIGGIT QUILMES',
        '7A10 - DIGGIT BAHIA BLANCA',
        '7A70 - DIGGIT SALTA',
        '7B80 - DIGGIT - MZ - PDV - PALMARES',
        '7970 - DIGGIT LOMAS',
        '7A80 - DIGGIT ALTO ROSARIO',
        '7B00 - DIGGIT PLAZA OESTE',
        '7990 - DIGGIT SAN MIGUEL',
        '7980 - DIGGIT PERU',
        '7A00 - DIGGIT TUCUMAN',
        '7A20 - DIGGIT SANTA FE',
        '7A40 - DIGGIT MERLO',
        '7C70 - DIGGIT RIO GRANDE',
        '7940 - DIGGIT USHUAIA'
      )
    GROUP BY
        CAST((a.order_creation_date || ' ' || a.order_creation_hour) AS TIMESTAMP),
        EXTRACT(MONTH FROM CAST(a.order_creation_date AS DATE)),
        EXTRACT(YEAR  FROM CAST(a.order_creation_date AS DATE)),
        b.country,
        b.subsidiary,
        b.currency,
        a.inserted_timestamp,
        a.updated_timestamp,
        a.order_code,
        c.status,
        a.order_status,
        a.sku,
        a.store_name,
        CAST(a.order_creation_hour AS TIME)
  );

  PERFORM CREATE LOCAL TEMPORARY TABLE vt_ods_diggit_ecom_orders_prepare_agg ON COMMIT PRESERVE ROWS AS (
    SELECT
      country,
      po_orderid,
      SUM(po_qty) AS po_orderqty,
      SUM(po_price_localcurr) AS po_totalprice_local
    FROM vt_ods_diggit_ecom_orders_prepare
    GROUP BY country, po_orderid
  );

  PERFORM CREATE LOCAL TEMPORARY TABLE vt_ods_diggit_ecom_orders_prepare_sku_agg ON COMMIT PRESERVE ROWS AS (
    SELECT
      country,
      po_orderid,
      po_sku,
      SUM(po_qty) AS po_orderqty,
      SUM(po_price_localcurr) AS po_totalprice_local,
      SUM(po_itemdiscount_localcurr) AS po_itemdiscount_localcurr
    FROM vt_ods_diggit_ecom_orders_prepare
    GROUP BY country, po_orderid, po_sku
  );

  PERFORM UPDATE vt_ods_diggit_ecom_orders_prepare a
    SET po_orderqty = b.po_orderqty,
        po_totalprice_local = (c.po_totalprice_local * c.po_orderqty) - c.po_itemdiscount_localcurr
  FROM vt_ods_diggit_ecom_orders_prepare_agg b
  JOIN vt_ods_diggit_ecom_orders_prepare_sku_agg c
    ON c.country = b.country AND c.po_orderid = b.po_orderid
  WHERE b.country = a.country
    AND b.po_orderid = a.po_orderid
    AND c.country = a.country
    AND c.po_orderid = a.po_orderid
    AND c.po_sku = a.po_sku;

  PERFORM UPDATE vt_ods_diggit_ecom_orders_prepare a
    SET po_itemdiscount_usd = a.po_itemdiscount_localcurr / CAST(b.exchange_rate AS DECIMAL(18,6)),
        po_price_usd        = a.po_price_localcurr        / CAST(b.exchange_rate AS DECIMAL(18,6)),
        po_totalprice_usd   = a.po_totalprice_local       / CAST(b.exchange_rate AS DECIMAL(18,6))
  FROM ow_lao.ft_ap2_exchange_rate b
  WHERE CAST(b.valid_from AS DATE) = CAST(TIMESTAMPADD(DAY, -1, CAST(a.po_date AS DATE)) AS DATE)
    AND b.to_currency = a.currency;

  PERFORM UPDATE vt_ods_diggit_ecom_orders_prepare a
    SET channel               = b.global_channel,
        biz_type              = b.biz_type,
        audience_type         = b.audience_type,
        biz_type_ebi_hq       = b.biz_type_ebi,
        global_channel_ebi_hq = b.global_channel_ebi,
        po_storename          = b.partner_level,
        customer_type         = b.customer_type,
        po_mobile_os          = b.po_mobile_os
  FROM ow_md.sales_channel b
  WHERE LOWER(b.country) = LOWER(a.country)
    AND LOWER(b.identifier) = LOWER(a.po_store_name)
    AND a.client_subsidiary_id = 1
    AND LOWER(b.plataform_type) = 'diggit';

  PERFORM UPDATE vt_ods_diggit_ecom_orders_prepare
    SET po_devicetype = 'MOBILEAPP'
  WHERE po_sitecode = 'samsungarapp'
    AND client_subsidiary_id = 1;

  PERFORM UPDATE vt_ods_diggit_ecom_orders_prepare
    SET po_devicetype = 'Web'
  WHERE po_devicetype IS NULL;

  PERFORM UPDATE vt_ods_diggit_ecom_orders_prepare
    SET global_channel_ebi_hq = '3PD',
        biz_type_ebi_hq = 'B2C'
  WHERE global_channel_ebi_hq IS NULL;

  PERFORM UPDATE vt_ods_diggit_ecom_orders_prepare
    SET channel = 'eStore',
        biz_type = '3PD',
        audience_type = '3PD'
  WHERE channel IS NULL;

  PERFORM MERGE INTO ow_lao.ods_sales_control_tower_table a
  USING vt_ods_diggit_ecom_orders_prepare b
     ON b.po_orderid  = a.po_orderid
    AND b.po_sku      = a.po_sku
    AND b.country     = a.country
    AND b.po_sku_kit  = a.po_sku_kit
    AND b.po_sitecode = a.po_sitecode
  WHEN MATCHED THEN UPDATE SET
       po_date                         = b.po_date,
       podate_month                    = b.po_month,
       podate_year                     = b.po_year,
       country                         = b.country,
       subsidiary                      = b.subsidiary,
       currency                        = b.currency,
       po_lastupdate_date_hour         = b.po_lastupdate_date_hour,
       po_source_last_update_date      = b.po_source_last_update_date,
       po_orderid                      = b.po_orderid,
       po_seller_name                  = b.po_seller_name,
       po_prodname                     = b.po_prodname,
       po_storename                    = b.po_storename,
       po_store_name                   = b.po_store_name,
       channel                         = b.channel,
       biz_type                        = b.biz_type,
       audience_type                   = b.audience_type,
       po_status                       = b.po_status,
       po_internal_status              = b.po_internal_status,
       po_sku                          = b.po_sku,
       po_qty                          = b.po_qty,
       po_orderqty                     = b.po_orderqty,
       po_itemdiscount_localcurr       = b.po_itemdiscount_localcurr,
       po_itemdiscount_usd             = b.po_itemdiscount_usd,
       po_price_localcurr              = b.po_price_localcurr,
       po_price_usd                    = b.po_price_usd,
       po_plataform_datasource         = b.po_plataform_datasource,
       po_source_insert_date           = b.po_source_insert_date,
       po_totalprice_usd               = b.po_totalprice_usd,
       po_totalprice_local             = b.po_totalprice_local,
       po_devicetype                   = b.po_devicetype,
       po_sku_kit                      = b.po_sku_kit,
       po_prodname_kit                 = b.po_prodname_kit,
       is_kit                          = b.is_kit,
       country_cd                      = b.country_cd,
       biz_type_ebi_hq                 = b.biz_type_ebi_hq,
       global_channel_ebi_hq           = b.global_channel_ebi_hq,
       installment                     = b.installment,
       customer_type                   = b.customer_type,
       po_mobile_os                    = b.po_mobile_os,
       updated_datetime                = CURRENT_TIMESTAMP
  WHEN NOT MATCHED THEN INSERT (
       po_date,
       podate_month,
       podate_year,
       country,
       subsidiary,
       currency,
       po_lastupdate_date_hour,
       po_source_last_update_date,
       po_orderid,
       po_seller_name,
       po_prodname,
       po_storename,
       po_store_name,
       channel,
       biz_type,
       audience_type,
       po_status,
       po_internal_status,
       po_sku,
       po_qty,
       po_orderqty,
       po_itemdiscount_localcurr,
       po_itemdiscount_usd,
       po_price_localcurr,
       po_price_usd,
       po_plataform_datasource,
       po_source_insert_date,
       po_totalprice_usd,
       po_totalprice_local,
       po_devicetype,
       po_sku_kit,
       po_prodname_kit,
       is_kit,
       country_cd,
       biz_type_ebi_hq,
       global_channel_ebi_hq,
       installment,
       samsung_care_order,
       samsung_care_eligibility,
       trade_in_eligibility,
       client_subsidiary_id,
       po_sitecode,
       customer_type,
       po_mobile_os
  ) VALUES (
       b.po_date,
       b.po_month,
       b.po_year,
       b.country,
       b.subsidiary,
       b.currency,
       b.po_lastupdate_date_hour,
       b.po_source_last_update_date,
       b.po_orderid,
       b.po_seller_name,
       b.po_prodname,
       b.po_storename,
       b.po_store_name,
       b.channel,
       b.biz_type,
       b.audience_type,
       b.po_status,
       b.po_internal_status,
       b.po_sku,
       b.po_qty,
       b.po_orderqty,
       b.po_itemdiscount_localcurr,
       b.po_itemdiscount_usd,
       b.po_price_localcurr,
       b.po_price_usd,
       b.po_plataform_datasource,
       b.po_source_insert_date,
       b.po_totalprice_usd,
       b.po_totalprice_local,
       b.po_devicetype,
       b.po_sku_kit,
       b.po_prodname_kit,
       b.is_kit,
       b.country_cd,
       b.biz_type_ebi_hq,
       b.global_channel_ebi_hq,
       b.installment,
       0,
       0,
       0,
       b.client_subsidiary_id,
       b.po_sitecode,
       b.customer_type,
       b.po_mobile_os
  );

END;
$$;

-- CALL OW_LAO.proc_ods_sales_control_tower_table_diggit();
-- ERROR: Severity: ERROR, Message: Cannot set a NOT NULL column (ID) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure proc_ods_sales_control_tower_table_diggit line 178 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3216, Error Code: 2502, 
-- CALL OW_LAO.proc_ods_sales_control_tower_table_diggit();
-- ERROR: Severity: ERROR, Message: Cannot set a NOT NULL column (ID) to a NULL value in INSERT/UPDATE statement, Sqlstate: 22004, Where: PL/vSQL procedure proc_ods_sales_control_tower_table_diggit line 178 at static SQL, Routine: errorIfSettingNonNullColumnToNULL, File: vertica.c, Line: 3216, Error Code: 2502, 
SELECT column_name, data_type, is_nullable, column_default FROM v_catalog.columns WHERE table_schema = 'ow_lao' AND table_name = 'ods_sales_control_tower_table' ORDER BY ordinal_position;
-- column_name | data_type | is_nullable | column_default
-- ------------+-----------+-------------+---------------

SELECT * FROM ow_lao.ods_sales_control_tower_table LIMIT 0;
-- PO_DATE | PODATE_YEAR | PODATE_MONTH | COUNTRY | SAMSUNG_CARE_ORDER | SAMSUNG_CARE | SAMSUNG_CARE_ELIGIBILITY | TRADE_IN | TRADE_IN_ELIGIBILITY | COSTUMER_CODE_ID_NAME | PO_ORDERID | SELLER_PO_ORDERID | PAYMENT_CARD_BRAND | PAYMENT_TYPE | INSTALLMENT | INSTALLMENT_ELIGIBILITY | PO_CANCELATION_REASON | PO_PRODUCTGROUP | PO_CODE_SALES_CHANNEL | PO_COSTUMER_ID | PO_SITECODE | PO_INTERNAL_STATUS | PO_INVOICENUMBER | PO_CAMPAIN_TAGS | PO_CAMPAIN | PO_COUPON | PO_MEDIUM | PO_SRC | PO_UTMI_CAMPAING | PO_SEQUENCE_ORDERID | PO_PRODNAME | PO_SKU | PO_SELLER_ID | PO_SELLER_NAME | PO_STATUS | CLIENT_SUBSIDIARY_ID | SUBSIDIARY | CURRENCY | PO_TRADEPOLICY | PO_VENDORTYPE | CHANNEL | BIZ_TYPE | AUDIENCE_TYPE | PO_STORENAME | CLIENT_ACQUIRER_MESSAGE | PO_LASTUPDATE_DATE_HOUR | PO_ORDERQTY | PO_QTY | PO_ITEMDISCOUNT_LOCALCURR | PO_ITEMDISCOUNT_USD | PO_PRICE_LOCALCURR | PO_PRICE_USD | PO_PLATAFORM_DATASOURCE | PO_SOURCE_INSERT_DATE | PO_SOURCE_LAST_UPDATE_DATE | PO_INSERT_DATE | PO_LAST_UPDATE_DATE | SO_IDCODE | SOLDTO_PARTY | SOLDTO_NAME | NERP_SKU | NERP_SKU_DESCRIPTION | NERP_SKU_DIVISION | NERP_NETPRICE | NERP_NETVALUE | NERP_COST | NERP_MARGINRATE | NERP_CURRENCY | SO_DATE_KST | NERP_COUNTRYCODE | NERP_DISTCHANNEL | NERP_PLANT | NERP_STORAGELOCATION | NERP_ACCOUNTCODE | NERP_ACCOUNTNAME | NERP_ID_GSCM | NERP_GC_NAME | NERP_AP1_CODE | NERP_AP1_NAME | NERP_AP2_CODE | NERP_AP2_NAME | NERP_DELIVERYCODE | NERP_DELIVERUQTY | NERP_BILLINGQTY | NERP_BILLINGDATE | NERP_MATERIAL_GROUP | SO_DATE | DO_DATE | 1GI_DATE | BILLING_DATE_LOCAL | FINAL_DATE | EBI_ORDERID | CLIENT_DEVICETYPE | WEEK | EBI_PO_DATE | EBI_PRODUCT_CATEGORY | EBI_PRODUCT_SUBCATEGORY | EBI_PRODUCT_FAMILY | EBI_PRODUCT_SERIES | EBI_PRODUCT_NAME | EBI_STATUS | EBI_PAYMENT_METHOD | EBI_PAYMENT_PROVIDER | EBI_TRADE_IN_ELIGIBLE | EBI_TRADE_IN_ORDER | EBI_EIP_ELIGIBLE | EBI_EIP_ORDER | EBI_EUP_ELIGIBLE | EBI_EUP_ORDER | EBI_SCPLUS_ELIGIBLE | EBI_SCPLUS_ORDER | EBI_TARIFF_ELIGIBLE | EBI_TARIFF_ORDER | EBI_GROSSREVENUE | EBI_NETREVENUE | EBI_GROSSORDER | EBI_NETORDER | EBI_NETQTY | EBI_GROSSQTY | EBI_CANCELAMT | EBI_CANCELQTY | EBI_RETURNEDAMT | EBI_RETURNED_QTY | DELIVERY_NO | CITY | REGION | DISTRICT | DATE_TORETRIVE | DATE_RETRIVED | VOLUME | WEIGHT | SHIPPING_TYPE | DATE_DELIVERED | STORAGE_LOCATION | FINAL_ETA_DATE | DELIVEY_DATE | SERIAL_NUMBER_CODE | DELIVERY_EXTIMETED_DATE | DELIVERY_CARRIER | POSTAL | INSETED_DATETIME | UPDATED_DATETIME | NERP_LAST_UPDATE_DATE | PO_PAYMENT_REMARK | NERP_OUTBOUND_LAST_UPDATE_DATE | EBI_LAST_UPDATE_DATE | PO_HOUR | PO_TOTALPRICE_LOCAL | PO_TOTALPRICE_USD | PO_TOTALPRICE | PO_TOTALTAX | COSTUMERTYPE | PO_ORDERSID | PO_PAYMENTPROVIDER | PO_PAYMENTDATE | PO_STORE_ID | PO_STORE_NAME | CLIENT_TRADE_IN_EXCHANGE_BRAND | TRADE_IN_DISCOUNT | CLIENT_TRADE_IN_EXCHANGE_MODEL | PO_DEVICETYPE | PO_ADDED_SERVICES | PO_EXTERNAL_SERVICE_TYPE | TRADE_IN_DISCOUNT_DETAILS | EBI_SKU | EBI_CHANNEL | EBI_BIZ_TYPE | PRODUCT | PRODUCT_FAMILY | PRODUCT_GROUP | DIVISION | NET_REVENUE | NET_REVENUE_LOCAL | ACCESS_CODE | PO_SOURCE_PAYMENT_LAST_UPDATE_DATE | PO_PAYMENT_GATEWAY | PARTNER_LEVEL | PO_SKU_KIT | PO_PRODNAME_KIT | IS_KIT | WARRANTY | WARRANTY_ELIGIBILITY | COUNTRY_CD | PRODUCT_CATEGORY | BIZ_TYPE_EBI_HQ | GLOBAL_CHANNEL_EBI_HQ | ITEM_EXCLUSIVE | PREMIUMPRODUCT | PARTNER_LEVEL_CODE | UNIQUE_ID | ID | CRP | SHIPPING_METHOD | PO_TIMESTAMP | SPI | DELIVERY_MODE | PO_MOBILE_OS | CUSTOMER_TYPE | INSTALLMENT_AMOUNT | EPROMOTER
-- --------+-------------+--------------+---------+--------------------+--------------+--------------------------+----------+----------------------+-----------------------+------------+-------------------+--------------------+--------------+-------------+-------------------------+-----------------------+-----------------+-----------------------+----------------+-------------+--------------------+------------------+-----------------+------------+-----------+-----------+--------+------------------+---------------------+-------------+--------+--------------+----------------+-----------+----------------------+------------+----------+----------------+---------------+---------+----------+---------------+--------------+-------------------------+-------------------------+-------------+--------+---------------------------+---------------------+--------------------+--------------+-------------------------+-----------------------+----------------------------+----------------+---------------------+-----------+--------------+-------------+----------+----------------------+-------------------+---------------+---------------+-----------+-----------------+---------------+-------------+------------------+------------------+------------+----------------------+------------------+------------------+--------------+--------------+---------------+---------------+---------------+---------------+-------------------+------------------+-----------------+------------------+---------------------+---------+---------+----------+--------------------+------------+-------------+-------------------+------+-------------+----------------------+-------------------------+--------------------+--------------------+------------------+------------+--------------------+----------------------+-----------------------+--------------------+------------------+---------------+------------------+---------------+---------------------+------------------+---------------------+------------------+------------------+----------------+----------------+--------------+------------+--------------+---------------+---------------+-----------------+------------------+-------------+------+--------+----------+----------------+---------------+--------+--------+---------------+----------------+------------------+----------------+--------------+--------------------+-------------------------+------------------+--------+------------------+------------------+-----------------------+-------------------+--------------------------------+----------------------+---------+---------------------+-------------------+---------------+-------------+--------------+-------------+--------------------+----------------+-------------+---------------+--------------------------------+-------------------+--------------------------------+---------------+-------------------+--------------------------+---------------------------+---------+-------------+--------------+---------+----------------+---------------+----------+-------------+-------------------+-------------+------------------------------------+--------------------+---------------+------------+-----------------+--------+----------+----------------------+------------+------------------+-----------------+-----------------------+----------------+----------------+--------------------+-----------+----+-----+-----------------+--------------+-----+---------------+--------------+---------------+--------------------+----------

-- SELECT HASH('test') AS h1, FNV_HASH('test') AS h2, FARM_FINGERPRINT('test') AS h3;
-- ERROR: Severity: ERROR, Message: Function FNV_HASH(unknown) does not exist, or permission is denied for FNV_HASH(unknown), Sqlstate: 42883, Hint: No function matches the given name and argument types. You may need to add explicit type casts, Routine: throwErrorFunctionDoesNotMatch, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Nibbler/server/vertica/Parser/ParseFunc.cpp, Line: 4559, Error Code: 3457, 
SELECT column_name, data_type, is_nullable, column_default FROM v_catalog.columns WHERE table_schema ILIKE 'ow_lao' AND table_name ILIKE 'ods_sales_control_tower_table' ORDER BY ordinal_position;
-- column_name | data_type | is_nullable | column_default
-- ------------+-----------+-------------+---------------
-- PO_DATE | date | False | 
-- PODATE_YEAR | int | True | 
-- PODATE_MONTH | int | True | 
-- COUNTRY | varchar(30) | False | 
-- SAMSUNG_CARE_ORDER | int | False | 
-- SAMSUNG_CARE | int | True | 
-- SAMSUNG_CARE_ELIGIBILITY | int | False | 
-- TRADE_IN | int | True | 
-- TRADE_IN_ELIGIBILITY | int | False | 
-- COSTUMER_CODE_ID_NAME | varchar(100) | True | 
-- PO_ORDERID | varchar(50) | False | 
-- SELLER_PO_ORDERID | varchar(100) | True | 
-- PAYMENT_CARD_BRAND | varchar(1000) | True | 
-- PAYMENT_TYPE | varchar(1000) | True | 
-- INSTALLMENT | int | True | 
-- INSTALLMENT_ELIGIBILITY | varchar(1) | True | 
-- PO_CANCELATION_REASON | varchar(3000) | True | 
-- PO_PRODUCTGROUP | varchar(255) | True | 
-- PO_CODE_SALES_CHANNEL | varchar(50) | True | 
-- PO_COSTUMER_ID | varchar(1000) | True | 
-- PO_SITECODE | varchar(100) | True | 
-- PO_INTERNAL_STATUS | varchar(255) | True | 
-- PO_INVOICENUMBER | varchar(1000) | True | 
-- PO_CAMPAIN_TAGS | varchar(4000) | True | 
-- PO_CAMPAIN | varchar(5000) | True | 
-- PO_COUPON | varchar(2000) | True | 
-- PO_MEDIUM | varchar(400) | True | 
-- PO_SRC | varchar(400) | True | 
-- PO_UTMI_CAMPAING | varchar(400) | True | 
-- PO_SEQUENCE_ORDERID | varchar(100) | True | 
-- PO_PRODNAME | varchar(3000) | True | 
-- PO_SKU | varchar(3000) | True | 
-- PO_SELLER_ID | varchar(100) | True | 
-- PO_SELLER_NAME | varchar(100) | True | 
-- PO_STATUS | varchar(1000) | True | 
-- CLIENT_SUBSIDIARY_ID | int | False | 
-- SUBSIDIARY | varchar(10) | False | 
-- CURRENCY | varchar(3) | False | 
-- PO_TRADEPOLICY | varchar(100) | True | 
-- PO_VENDORTYPE | varchar(20) | True | 
-- CHANNEL | varchar(255) | True | 
-- BIZ_TYPE | varchar(255) | True | 
-- AUDIENCE_TYPE | varchar(255) | True | 
-- PO_STORENAME | varchar(255) | True | 
-- CLIENT_ACQUIRER_MESSAGE | varchar(1000) | True | 
-- PO_LASTUPDATE_DATE_HOUR | timestamp | True | 
-- PO_ORDERQTY | int | False | 
-- PO_QTY | int | False | 
-- PO_ITEMDISCOUNT_LOCALCURR | numeric(20,2) | True | 
-- PO_ITEMDISCOUNT_USD | numeric(34,0) | False | 
-- PO_PRICE_LOCALCURR | numeric(20,2) | True | 
-- PO_PRICE_USD | numeric(34,0) | False | 
-- PO_PLATAFORM_DATASOURCE | varchar(50) | False | 
-- PO_SOURCE_INSERT_DATE | timestamp | False | 
-- PO_SOURCE_LAST_UPDATE_DATE | timestamp | True | 
-- PO_INSERT_DATE | timestamp | True | 
-- PO_LAST_UPDATE_DATE | varchar(1) | True | 
-- SO_IDCODE | varchar(255) | True | 
-- SOLDTO_PARTY | varchar(255) | True | 
-- SOLDTO_NAME | varchar(255) | True | 
-- NERP_SKU | varchar(255) | True | 
-- NERP_SKU_DESCRIPTION | varchar(255) | True | 
-- NERP_SKU_DIVISION | varchar(255) | True | 
-- NERP_NETPRICE | numeric(34,0) | True | 
-- NERP_NETVALUE | numeric(34,0) | True | 
-- NERP_COST | numeric(34,0) | True | 
-- NERP_MARGINRATE | numeric(34,0) | True | 
-- NERP_CURRENCY | varchar(255) | True | 
-- SO_DATE_KST | date | True | 
-- NERP_COUNTRYCODE | varchar(255) | True | 
-- NERP_DISTCHANNEL | varchar(255) | True | 
-- NERP_PLANT | varchar(255) | True | 
-- NERP_STORAGELOCATION | varchar(255) | True | 
-- NERP_ACCOUNTCODE | varchar(255) | True | 
-- NERP_ACCOUNTNAME | varchar(255) | True | 
-- NERP_ID_GSCM | varchar(255) | True | 
-- NERP_GC_NAME | varchar(255) | True | 
-- NERP_AP1_CODE | varchar(255) | True | 
-- NERP_AP1_NAME | varchar(255) | True | 
-- NERP_AP2_CODE | varchar(255) | True | 
-- NERP_AP2_NAME | varchar(255) | True | 
-- NERP_DELIVERYCODE | varchar(255) | True | 
-- NERP_DELIVERUQTY | int | True | 
-- NERP_BILLINGQTY | int | True | 
-- NERP_BILLINGDATE | date | True | 
-- NERP_MATERIAL_GROUP | varchar(255) | True | 
-- SO_DATE | date | True | 
-- DO_DATE | date | True | 
-- 1GI_DATE | date | True | 
-- BILLING_DATE_LOCAL | date | True | 
-- FINAL_DATE | date | True | 
-- EBI_ORDERID | varchar(255) | True | 
-- CLIENT_DEVICETYPE | varchar(255) | True | 
-- WEEK | varchar(255) | True | 
-- EBI_PO_DATE | date | True | 
-- EBI_PRODUCT_CATEGORY | varchar(255) | True | 
-- EBI_PRODUCT_SUBCATEGORY | varchar(255) | True | 
-- EBI_PRODUCT_FAMILY | varchar(255) | True | 
-- EBI_PRODUCT_SERIES | varchar(255) | True | 
-- EBI_PRODUCT_NAME | varchar(255) | True | 
-- EBI_STATUS | varchar(255) | True | 
-- EBI_PAYMENT_METHOD | varchar(255) | True | 
-- EBI_PAYMENT_PROVIDER | varchar(255) | True | 
-- EBI_TRADE_IN_ELIGIBLE | int | True | 
-- EBI_TRADE_IN_ORDER | int | True | 
-- EBI_EIP_ELIGIBLE | int | True | 
-- EBI_EIP_ORDER | int | True | 
-- EBI_EUP_ELIGIBLE | int | True | 
-- EBI_EUP_ORDER | int | True | 
-- EBI_SCPLUS_ELIGIBLE | int | True | 
-- EBI_SCPLUS_ORDER | int | True | 
-- EBI_TARIFF_ELIGIBLE | int | True | 
-- EBI_TARIFF_ORDER | int | True | 
-- EBI_GROSSREVENUE | numeric(34,0) | True | 
-- EBI_NETREVENUE | numeric(34,0) | True | 
-- EBI_GROSSORDER | numeric(34,0) | True | 
-- EBI_NETORDER | numeric(34,0) | True | 
-- EBI_NETQTY | int | True | 
-- EBI_GROSSQTY | int | True | 
-- EBI_CANCELAMT | numeric(34,0) | True | 
-- EBI_CANCELQTY | int | True | 
-- EBI_RETURNEDAMT | numeric(34,0) | True | 
-- EBI_RETURNED_QTY | int | True | 
-- DELIVERY_NO | varchar(255) | True | 
-- CITY | varchar(255) | True | 
-- REGION | varchar(255) | True | 
-- DISTRICT | varchar(255) | True | 
-- DATE_TORETRIVE | date | True | 
-- DATE_RETRIVED | date | True | 
-- VOLUME | numeric(34,0) | True | 
-- WEIGHT | numeric(34,0) | True | 
-- SHIPPING_TYPE | varchar(255) | True | 
-- DATE_DELIVERED | date | True | 
-- STORAGE_LOCATION | varchar(255) | True | 
-- FINAL_ETA_DATE | date | True | 
-- DELIVEY_DATE | date | True | 
-- SERIAL_NUMBER_CODE | varchar(255) | True | 
-- DELIVERY_EXTIMETED_DATE | date | True | 
-- DELIVERY_CARRIER | varchar(255) | True | 
-- POSTAL | varchar(255) | True | 
-- INSETED_DATETIME | timestamp | True | 
-- UPDATED_DATETIME | timestamp | True | 
-- NERP_LAST_UPDATE_DATE | timestamp | True | 
-- PO_PAYMENT_REMARK | varchar(2000) | True | 
-- NERP_OUTBOUND_LAST_UPDATE_DATE | timestamp | True | 
-- EBI_LAST_UPDATE_DATE | timestamp | True | 
-- PO_HOUR | time | True | 
-- PO_TOTALPRICE_LOCAL | numeric(34,0) | True | 
-- PO_TOTALPRICE_USD | numeric(34,0) | True | 
-- PO_TOTALPRICE | numeric(34,0) | True | 
-- PO_TOTALTAX | numeric(34,0) | True | 
-- COSTUMERTYPE | varchar(255) | True | 
-- PO_ORDERSID | varchar(255) | True | 
-- PO_PAYMENTPROVIDER | varchar(255) | True | 
-- PO_PAYMENTDATE | timestamp | True | 
-- PO_STORE_ID | varchar(255) | True | 
-- PO_STORE_NAME | varchar(255) | True | 
-- CLIENT_TRADE_IN_EXCHANGE_BRAND | varchar(255) | True | 
-- TRADE_IN_DISCOUNT | numeric(34,0) | True | 
-- CLIENT_TRADE_IN_EXCHANGE_MODEL | varchar(1000) | True | 
-- PO_DEVICETYPE | varchar(255) | True | 
-- PO_ADDED_SERVICES | varchar(3000) | True | 
-- PO_EXTERNAL_SERVICE_TYPE | varchar(255) | True | 
-- TRADE_IN_DISCOUNT_DETAILS | varchar(3000) | True | 
-- EBI_SKU | varchar(255) | True | 
-- EBI_CHANNEL | varchar(255) | True | 
-- EBI_BIZ_TYPE | varchar(255) | True | 
-- PRODUCT | varchar(255) | True | 
-- PRODUCT_FAMILY | varchar(255) | True | 
-- PRODUCT_GROUP | varchar(255) | True | 
-- DIVISION | varchar(255) | True | 
-- NET_REVENUE | numeric(34,0) | True | 
-- NET_REVENUE_LOCAL | numeric(34,0) | True | 
-- ACCESS_CODE | varchar(2000) | True | 
-- PO_SOURCE_PAYMENT_LAST_UPDATE_DATE | timestamp | True | 
-- PO_PAYMENT_GATEWAY | varchar(1000) | True | 
-- PARTNER_LEVEL | varchar(255) | True | 
-- PO_SKU_KIT | varchar(1000) | True | 
-- PO_PRODNAME_KIT | varchar(1000) | True | 
-- IS_KIT | boolean | True | 
-- WARRANTY | int | True | 
-- WARRANTY_ELIGIBILITY | int | True | 
-- COUNTRY_CD | varchar(10) | True | 
-- PRODUCT_CATEGORY | varchar(100) | True | 
-- BIZ_TYPE_EBI_HQ | varchar(50) | True | 
-- GLOBAL_CHANNEL_EBI_HQ | varchar(50) | True | 
-- ITEM_EXCLUSIVE | int | True | 
-- PREMIUMPRODUCT | int | True | 
-- PARTNER_LEVEL_CODE | varchar(250) | True | 
-- UNIQUE_ID | int | True | 
-- ID | int | False | 
-- CRP | int | True | 
-- SHIPPING_METHOD | varchar(200) | True | 
-- PO_TIMESTAMP | timestamp | True | 
-- SPI | varchar(20) | True | 
-- DELIVERY_MODE | varchar(200) | True | 
-- PO_MOBILE_OS | varchar(225) | True | 
-- CUSTOMER_TYPE | varchar(225) | True | 
-- INSTALLMENT_AMOUNT | numeric(34,0) | True | 
-- EPROMOTER | numeric(34,0) | True | 

