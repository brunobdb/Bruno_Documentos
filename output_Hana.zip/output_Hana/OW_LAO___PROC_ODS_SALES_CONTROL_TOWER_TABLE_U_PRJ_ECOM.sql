CREATE PROCEDURE OW_LAO.proc_ods_sales_control_tower_table_u_prj_ecom
 LANGUAGE SQLSCRIPT AS
 BEGIN
  -- Sales nao BRSHOP       
          truncate table ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom;
    
            insert into ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom
    
            select cast(a.creation_date as date)        as po_date
                 , year(a.creation_date)                as podate_year
                 , month(a.creation_date)               as podate_month
                 , e.country                            as country
                 , coalesce(b.is_samsung_care, 0)       as samsung_care_order
                 , coalesce(b.is_samsung_care, 0)       as samsung_care
                 , coalesce(b.is_samsung_care, 0)       as samsung_care_eligibility
                 , 0                                    as trade_in
                 , 0                                    as trade_in_eligibility
                 , 0                                    as trade_up
                 , 0                                    as trade_up_eligibility
                 , a.affiliate_id                       as costumer_code_id_name
                 , a.external_order_id                  as po_orderid
                 , a.seller_order_id                    as seller_po_orderid
                 , cast(null as varchar(3000))          as payment_card_brand
                 , cast(null as varchar(3000))          as payment_type
                 , 0                                    as installment
                 , null                                 as installment_eligibility
                 , a.cancellation_reason                as po_cancelation_reason
                 , f.product_group_1                    as po_productgroup
                 , a.cod_sales_channel                  as po_code_sales_channel
                 , a.customer_id                        as po_costumer_id
                 , a.hostname                           as po_sitecode
                 , a.status                             as po_internal_status
                 , a.invoice_number                     as po_invoicenumber
                 , a.mkt_campaign_tags                  as po_campain_tags
                 , a.mkt_utm_campaign                   as po_campain
                 , a.mkt_utm_coupon                     as po_coupon
                 , a.mkt_utm_medium                     as po_medium
                 , a.mkt_utm_src                        as po_src
                 , a.mkt_utmi_campaign                  as po_utmi_campaing
                 , a.order_sequence                     as po_sequence_orderid
                 , string_agg(b.product_name, '|')      as po_prodname
                 , coalesce(
                        b.reference_code
                      , string_agg(b.product_name, '|')
                   )                                    as po_sku
                 , a.seller_id                          as po_seller_id
                 , a.seller_name                        as po_seller_name
                 , g.status                             as po_status
                 , a.subsidiary_id                      as client_subsidiary_id
                 , e.subsidiary                         as subsidiary
                 , e.currency                           as currency
                 , a.trade_policy                       as po_tradepolicy
                 , a.vendor                             as po_vendortype       
                 , null                                 as channel
                 , null                                 as biz_type
                 , null                                 as audience_type
                 , null                                 as po_storename
                 , a.acquirer_message                   as client_acquirer_message
                 , a.last_update_date                   as po_lastupdate_date_hour
                 , 0                                    as po_orderqty
                 , sum(b.quantity)                      as po_qty
                 , sum(b.discount)                      as po_itemdiscount_localcurr
                 , 0                                    as po_itemdiscount_usd
                 , sum(b.price)                         as po_price_localcurr
                 , 0                                    as po_price_usd
                 , 'u_prj_ecom.ft_ecom_order'           as po_plataform_datasource   
                 , a.insert_date                        as po_source_insert_date
                 , a.last_update_date                   as po_source_last_update_date
                 , current_timestamp                    as po_insert_date
                 , null                                 as po_last_update_date
                 , cast(null as varchar(3000))          as po_payment_remark
                 , cast(a.creation_date as time)        as po_hour 
                 , 0                                    as po_totalprice_usd
                 , 0                                    as po_totalprice_local
                 , 1                                    as po_plataform_datasource_type_id
                 , a.id                                 as po_plataform_datasource_order_id
                 , null                                 as po_devicetype
                 , ''                                   as po_sku_kit
                 , ''                                   as po_prodname_kit
                 , 0.00                                 as po_price_localcurr_kit
                 , 0.00                                 as po_itemdiscount_localcurr_kit
                 , false                                as is_kit
                 ,case when a.subsidiary_id = 7 
                 and  a.country is null then 'PAN' 
                       when a.subsidiary_id = 17 then 'FLA' 
                       when a.subsidiary_id = 16 THEN 'CAR' 
                 else a.country end                     as country_cd
                 , null                                 as biz_type_ebi_hq
                 , null                                 as global_channel_ebi_hq
                 , cast(null as varchar(255))           as customer_type
                 , cast(null as varchar(255))           as po_mobile_os
                 , 0                                    as crp
                 , current_timestamp                    as load_date 
                 , cast(null as date)                   as nerp_billingdate
                 , cast(null as date)                   as so_date
                 , cast(null as date)                   as do_date
                 , cast(null as date)                   as billing_date_local
                 , cast(null as varchar(255))           as shipping_method
                 , cast(null as varchar(255))           as delivery_mode
              from u_prj_ecom.ft_ecom_order                                a
              join u_prj_ecom.ft_ecom_order_item                           b on b.order_id      = a.id
         left join u_prj_ecom.dim_customer                                 d on d.id            = a.customer_id
              join u_prj_ecom.dim_subsidiary                               e on e.id            = a.subsidiary_id
         left join ow_md.dim_product                                       f on f.sku           = b.reference_code
         left join ow_lao.dim_ods_sales_control_tower_table_status_mapping g on g.status_origin = a.status
             where 1 = 1
               and a.creation_date >= add_days(current_date, -180)
               --and a.external_order_id in ('1359283008239-01')
               and a.subsidiary_id not in (1, 6, 9)
               and not exists(                        
                        select 1
                          from ow_lao.ods_sales_control_tower_table aa
                         where aa.po_orderid                  = a.external_order_id
                           and aa.po_sku                      = b.reference_code
                           and aa.country                     = e.country
                           and aa.po_internal_status          = a.status
                           and aa.po_source_last_update_date >= a.last_update_date
                   )
          group by a.creation_date
                 , e.country                            
                 , coalesce(b.is_samsung_care, 0)
                 , coalesce(a.is_trade_in, 0)
                 , a.affiliate_id                       
                 , a.external_order_id                  
                 , a.seller_order_id                    
                 , a.cancellation_reason                
                 , f.product_group_1                    
                 , a.cod_sales_channel                  
                 , a.customer_id                                              
                 , a.hostname                           
                 , a.status                  
                 , a.invoice_number                     
                 , a.mkt_campaign_tags                  
                 , a.mkt_utm_campaign                   
                 , a.mkt_utm_coupon                     
                 , a.mkt_utm_medium                     
                 , a.mkt_utm_src                        
                 , a.mkt_utmi_campaign                  
                 , a.order_sequence                     
                 , b.reference_code                     
                 , a.seller_id                          
                 , a.seller_name                        
                 , g.status                             
                 , a.subsidiary_id                      
                 , e.subsidiary                         
                 , e.currency                           
                 , a.trade_policy                       
                 , a.vendor                             
                 , a.acquirer_message                   
                 , a.last_update_date                   
                 , a.insert_date                        
                 , a.last_update_date                                                
                 , a.id 
                 ,case when a.subsidiary_id = 7 
                 and  a.country is null then 'PAN' 
                       when a.subsidiary_id = 17 then 'FLA' 
                       when a.subsidiary_id = 16 THEN 'CAR' 
                 else a.country end  
                 ,null
                 ,null
          order by cast(a.creation_date as date) desc
                 , a.external_order_id;
                 
              
  -- Blundes Discount
                         
             drop table ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_discount;
    create column table ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_discount
                    as ( 
                            select a.po_orderid
                                 , a.po_sku
                                 , a.country
                                 , a.po_sku_kit
                                 , case 
                                        when abs(a.po_itemdiscount_localcurr_kit) > 0.00 
                                             and abs(a.po_itemdiscount_localcurr) > 0.00
                                        then round(a.po_itemdiscount_localcurr_kit 
                                                * round(abs(a.po_itemdiscount_localcurr) 
                                                    / (sum(abs(a.po_itemdiscount_localcurr))
                                                        over(partition by a.po_orderid
                                                                        , a.po_sku_kit
                                                         ) 
                                                       )
                                                   ,2)
                                               ,2)
                                        when abs(a.po_itemdiscount_localcurr_kit) > 0.00 
                                             and abs(a.po_itemdiscount_localcurr) = 0.00
                                        then round(a.po_itemdiscount_localcurr_kit 
                                                * round(abs(a.po_price_localcurr) 
                                                    / (sum(abs(a.po_price_localcurr))
                                                        over(partition by a.po_orderid
                                                                        , a.po_sku_kit
                                                         ) 
                                                       )
                                                   ,2)
                                               ,2)
                                        when abs(a.po_itemdiscount_localcurr_kit) = 0.00
                                        then abs(a.po_itemdiscount_localcurr)
                                        else 0.00
                                    end                                    as po_itemdiscount_localcurr
                              from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom a
                             where is_kit = true
                          group by a.po_orderid
                                 , a.po_sku
                                 , a.country
                                 , a.po_sku_kit
                                 , a.po_itemdiscount_localcurr_kit
                                 , abs(a.po_itemdiscount_localcurr)
                                 , a.po_price_localcurr
                    );
                    
                    
        update ow_lao.tmp_ods_sales_control_tower_table_bundle                    a
           set po_itemdiscount_localcurr = b.po_itemdiscount_localcurr
          from ow_lao.tmp_ods_sales_control_tower_table_bundle                    a
          join ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_discount b on b.country    = a.country
                                                                                   and b.po_orderid = a.po_orderid
                                                                                   and b.po_sku     = a.po_sku
                                                                                   and b.po_sku_kit = a.po_sku_kit
         where a.is_kit = true;  
        
 -- Bundles -- ADICIONADO LUCAS.GIL
    
        update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom         
           set po_sku_kit = po_sku
             , is_kit     = true
         where po_sku like '%+%'
           and client_subsidiary_id in (7,8,9,10,11,12,13,14,15,16,17,18,19)
           and PO_SKU NOT LIKE '%+'
           and po_sku_kit is null;
    
         
-- Payments                        
                 
             drop table ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_payments;
    create column table ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_payments
        as (
                 
              select a.po_plataform_datasource_order_id
                   , a.po_plataform_datasource_type_id
                   , max(installment)                   as installment
                   , string_agg(a.brand       , '|')    as payment_card_brand
                   , string_agg(a.payment_type, '|')    as payment_type
                   , string_agg(
                        a.payment_type || ':' || 
                        a.brand        || ':' || 
                        a.value        || ':' || 
                        a.installment
                        , '|' 
                   )                                    as po_payment_remark
                from (   
                            select distinct
                                   a.po_plataform_datasource_order_id
                                 , a.po_plataform_datasource_type_id
                                 , coalesce(b.brand       , '')   as brand
                                 , coalesce(b.payment_type, '')   as payment_type
                                 , b.value
                                 , b.installment
                              from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom a  
                              join u_prj_ecom_synapcom.ft_ecom_order_payment                 b on b.order_id = a.po_plataform_datasource_order_id
                             where a.po_plataform_datasource_type_id = 2   
                             
                             union all
                             
                            select distinct
                                   a.po_plataform_datasource_order_id
                                 , a.po_plataform_datasource_type_id
                                 , coalesce(b.brand       , '')   as brand
                                 , coalesce(b.payment_type, '')   as payment_type
                                 , b.value
                                 , b.installment
                              from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom a  
                              join u_prj_ecom.ft_ecom_order_payment                          b on b.order_id = a.po_plataform_datasource_order_id
                             where a.po_plataform_datasource_type_id = 1
                 ) a
            group by a.po_plataform_datasource_order_id
                   , a.po_plataform_datasource_type_id
        );                 
        
        update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom          a
           set installment        = b.installment
             , payment_card_brand = b.payment_card_brand
             , payment_type       = b.payment_type
             , po_payment_remark  = b.po_payment_remark
          from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom          a
          join ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_payments b on b.po_plataform_datasource_order_id = a.po_plataform_datasource_order_id
                                                                                   and b.po_plataform_datasource_type_id  = b.po_plataform_datasource_type_id;        
 
              drop table ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_agg;
     create column table ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_agg
         as (               
                select country
                     , po_orderid
                     , sum(po_qty)             as po_orderqty
                     , sum(po_price_localcurr) as po_totalprice_local
                  from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom   
              group by country
                     , po_orderid           
         );
         
              drop table ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_sku_agg;
     create column table ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_sku_agg
         as (               
                select country
                     , po_orderid
                     , po_sku
                     , sum(po_qty)                    as po_orderqty
                     , sum(po_price_localcurr)        as po_totalprice_local
                     , sum(po_itemdiscount_localcurr) as po_itemdiscount_localcurr
                  from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom   
              group by country
                     , po_orderid   
                     , po_sku        
         );         
   
        update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom         a
           set a.po_orderqty         = b.po_orderqty
             , a.po_totalprice_local = (c.po_totalprice_local * c.po_orderqty) - c.po_itemdiscount_localcurr
             , a.po_price_localcurr  = (c.po_totalprice_local * c.po_orderqty) - c.po_itemdiscount_localcurr
          from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom         a
          join ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_agg     b on b.country    = a.country
                                                                                  and b.po_orderid = a.po_orderid
          join ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_sku_agg c on c.country    = a.country
                                                                                  and c.po_orderid = a.po_orderid
                                                                                  and c.po_sku     = a.po_sku;  
             
       /* update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom a
           set trade_in_eligibility     = case b.is_tradein_eligible       when true then 1 else 0 end
             , samsung_care_eligibility = case b.is_samsung_care_eligible  when true then 1 else 0 end
          from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom a
          join u_prj_ecom.ods_ecom_sku_enables                           b on b.subsidiary_id  = a.client_subsidiary_id
                                                                          and b.account        = a.po_sitecode
                                                                          and b.reference_code = a.po_sku;*/
                                                                          
        update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom a
           set po_itemdiscount_usd = COALESCE (a.po_itemdiscount_localcurr / cast(b.exchange_rate as decimal),0)
             , po_price_usd        = COALESCE (a.po_price_localcurr        / cast(b.exchange_rate as decimal),0)
             , po_totalprice_usd   = COALESCE (a.po_totalprice_local       / cast(b.exchange_rate as decimal),0)
          from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom a
          join ow_lao.ft_ap2_exchange_rate                               b on b.valid_from  = add_days(a.po_date, -1)
                                                                          and b.to_currency = a.currency;   
                                                                          
-- Sales custom ---alterado pelo lucas.gil
-- Adicionado atualização po_hour  - p.anaalinne
        update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom a
           set nerp_billingdate   = b.delivered_date
             , so_date            = b.invoice_date
             , do_date            = b.delivered_date
             , billing_date_local = b.delivered_date
             , po_coupon          = b.coupon_code
             , shipping_method	  = b.shipping_and_handling
             , po_hour            = cast(b.creation_date as time)
          from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom a
          join ow_lao.ods_sela_custom_orders_items                        b on b.order_id      = a.po_orderid
                                                                           and b.code          = a.po_sku
                                                                           and b.subsidiary_id = a.client_subsidiary_id
                                                                           and b.account       = a.po_sitecode
         where a.client_subsidiary_id in (7, 8, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19);    
        
                
-- Sales channel
           
        update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom a
           set a.channel               = b.global_channel
             , a.biz_type              = b.biz_type
             , a.audience_type         = b.audience_type
             , a.po_storename          = b.partner_level
             , a.biz_type_ebi_hq       = b.biz_type_ebi
             ,a.global_channel_ebi_hq  = b.global_channel_ebi
             , a.customer_type         = b.customer_type
             , a.po_mobile_os          = b.po_mobile_os
          from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom a
          join ow_md.sales_channel                                       b on lower(b.country)          = lower(a.country)
                                                                          and b.sales_channel           = a.po_code_sales_channel
                                                                          and coalesce(b.identifier,'') = a.costumer_code_id_name
                                                                          and b.plataform_account       = a.po_sitecode
         where client_subsidiary_id in (1)
           and lower(b.plataform_type)     = 'vtex'
           and coalesce(has_store_id, 'N') = 'N'
           and coalesce(b.identifier,'')  != '';                    
           
        update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom a
           set a.channel               = b.global_channel
             , a.biz_type              = b.biz_type
             , a.audience_type         = b.audience_type
             , a.po_storename          = b.partner_level
             , a.biz_type_ebi_hq       = b.biz_type_ebi
             ,a.global_channel_ebi_hq  = b.global_channel_ebi
             , a.customer_type         = b.customer_type
             , a.po_mobile_os          = b.po_mobile_os
          from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom a
          join ow_md.sales_channel                                       b on lower(b.country)     = lower(a.country)
                                                                          and b.sales_channel      = a.po_code_sales_channel
                                                                          and b.plataform_account  = a.po_sitecode
         where client_subsidiary_id in (1, 8, 9)
           and lower(b.plataform_type)     = 'vtex'
           and coalesce(has_store_id, 'N') = 'N'
           and coalesce(b.identifier,'')   = '';       
           
        update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom a
           set a.channel                = b.global_channel
             , a.biz_type               = b.biz_type
             , a.audience_type          = b.audience_type
             , a.po_storename           = b.partner_level
             , a.biz_type_ebi_hq        = b.biz_type_ebi
             , a.global_channel_ebi_hq  = b.global_channel_ebi
             , a.customer_type         = b.customer_type
             , a.po_mobile_os          = b.po_mobile_os
          from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom a
          join ow_md.sales_channel                                       b on lower(b.country)    = lower(a.country)
                                                                          and lower(b.identifier) = lower(a.po_sitecode)
                                                                          
         where client_subsidiary_id in (7, 8, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19)
           and lower(b.plataform_type)     = 'magento'
           and coalesce(b.sku_mapping, '') = '';  
          
        update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom a
           set a.channel                = b.global_channel
             , a.biz_type               = b.biz_type
             , a.audience_type          = b.audience_type
             , a.po_storename           = (b.partner_level ||'-'|| b.biz_type)
             , a.biz_type_ebi_hq        = b.biz_type_ebi
             , a.global_channel_ebi_hq  = b.global_channel_ebi
             , a.customer_type         = b.customer_type
             , a.po_mobile_os          = b.po_mobile_os
          from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom a
          join ow_md.sales_channel                                       b on lower(b.country)    = lower(a.country)
                                                                          and lower(b.identifier) = lower(a.po_sitecode)
                                                                          and b.sku_mapping       = substring(
                                                                                                          a.po_sku
                                                                                                        , locate(a.po_sku, '-', -1)
                                                                                                        , length(a.po_sku)
                                                                                                     ) --ADICIONADO POR LUCAS.GIL
         where client_subsidiary_id in (7, 8, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19)
           and lower(b.plataform_type)      = 'magento'
           and coalesce(b.sku_mapping, '') != '';    
                            
           
        update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom a
           set a.channel                = b.channel
             , a.biz_type               = b.byz_type
             , a.audience_type          = b.audience_type
             , a.po_storename           = b.storename
             , a.biz_type_ebi_hq        = b.biz_type_ebi_hq
             , a.global_channel_ebi_hq  = b.global_channel_ebi_hq
          from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom a
          join ow_lao.temp_dim_ecom_store_seasa_mkm                      b on b.id = left(a.po_orderid, 6)
         where client_subsidiary_id    = 1
           and a.costumer_code_id_name = 'MKM';   
           
        update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom a
           set a.channel                = 'eStore'
             , a.biz_type               = '3PD'
             , a.audience_type          = '3PD'
             , a.po_storename           = 'Mercado Libre'
             , a.biz_type_ebi_hq        = 'B2C'
             , a.global_channel_ebi_hq  = '3PD'
          from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom a
         where a.po_plataform_datasource in ('u_prj_ecom_synapcom.ft_ecom_order', 'u_prj_ecom.ft_ecom_order')
           and client_subsidiary_id    = 1
           and a.costumer_code_id_name = 'MKM'
           and a.channel               is null
           and not exists(
                    select 1
                      from ow_lao.temp_dim_ecom_store_seasa_mkm aa 
                     where aa.id = left(a.po_orderid, 6)
               );
        
--mkb seasa inserido dia 04/07/2024
        update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom a
           set a.channel                = b.global_channel
             , a.biz_type               = b.biz_type
             , a.audience_type          = b.audience_type
             , a.po_storename           = b.partner_level
             , a.biz_type_ebi_hq        = b.biz_type_ebi
             , a.global_channel_ebi_hq  = b.global_channel_ebi
          from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom a
          join ow_md.sales_channel                                       b on lower(b.country)          = lower(a.country)
                                                                          and coalesce(b.identifier,'') = a.costumer_code_id_name
                                                                          and b.plataform_account       = a.po_sitecode
         where client_subsidiary_id in (1)
           and lower(b.plataform_type)     = 'vtex'
           and coalesce(has_store_id, 'N') = 'N'
           and coalesce(b.identifier,'')  != ''
           and left(a.po_orderid, 3) = 'MKB';
          
          
-- app samsung
             
          update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom
             set po_devicetype = 'MOBILEAPP'
           where po_sitecode  in ('samsungarapp', 'samsungarappios')
             and client_subsidiary_id = 1; 
 
-- default po_device_type   
        --  update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom
         --    set po_devicetype = 'Web'
          -- where po_storename not in   ('App Samsung','App IOS','App Android')
          --   and po_devicetype is not null
          --   and client_subsidiary_id in (6,1);  
   
-- 24092024 - Rodrigo - duplicidade de codigo linha: 934         
             
             
-- O2O ENDLESS AISLE lucas.gil 15/07/2024 - S2SDSLA-383
        update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom a
           set a.channel                = 'eStore'
             , a.biz_type               = 'EPP' 
             , a.audience_type          = 'Endless Aisle'
             , a.po_storename           = 'Endless Aisle'
             , a.biz_type_ebi_hq        = 'EPP' 
             , a.global_channel_ebi_hq  = 'eStore'
          from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom a
          join U_PRJ_ECOM.FT_ECOM_ORDER                                  b on b.EXTERNAL_ORDER_ID = a.po_orderid
         where a.client_subsidiary_id = 1
           and b.ADDRESS_TYPE         = 'pickup' ;   
           
-- Fuso        
          update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom a  
             set a.po_date     = cast(
                                    add_seconds(
                                        to_timestamp(c.creation_date)
                                        , (b.timezone * 60) * 60
                                    )
                                  as date) 
               , a.po_hour     = cast(
                                    add_seconds(
                                        to_timestamp(c.creation_date)
                                        , (b.timezone * 60) * 60
                                    )
                                  as time)  
               , a.podate_year = year(cast(
                                        add_seconds(
                                            to_timestamp(c.creation_date)
                                            , (b.timezone * 60) * 60
                                        )
                                      as date))   
               , a.podate_month = month(cast(
                                        add_seconds(
                                            to_timestamp(c.creation_date)
                                            , (b.timezone * 60) * 60
                                        )
                                      as date)) 
            from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom a
            join u_prj_ecom.dim_subsidiary                                 b on b.country           = a.country
            join u_prj_ecom.ft_ecom_order                                  c on c.external_order_id = a.po_orderid
           where b.order_apply_timezone = 1;
--- Atualização po_internal status Sela - 05/07/2024 
          
           drop table  ow_lao.tmp_ecommerce_sales_control_tower_table_sela_status;
  create column table  ow_lao.tmp_ecommerce_sales_control_tower_table_sela_status AS (
select distinct
                  a.po_orderid                           
                 ,b.internal_status                     as po_internal_status
                 ,COALESCE ( c.status,NULL)             as po_status
                ,b.subsidiary_id                        as client_subsidiary_id
    
                  from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom      a
                  join u_prj_ecom.ft_ecom_order b          on b.external_order_id = a.po_orderid
                                                          and b.subsidiary_id     = a.client_subsidiary_id
             left join ow_lao.dim_ods_sales_control_tower_table_status_mapping c on c.status_origin = b.internal_status 
  where a.client_subsidiary_id in (7, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19))
  
 
 ;
 
update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom   a
   set a.po_internal_status       = b.po_internal_status  
     , a.po_status                = b.po_status
          
 
from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom   a
join ow_lao.tmp_ecommerce_sales_control_tower_table_sela_status  b on b.po_orderid            = a.po_orderid
                                                                  and b.client_subsidiary_id  = a.client_subsidiary_id
                                                                  
 ;
-- CRP(COUPON/STORENAME) - ADICIONADO LUCAS.GIL
  
       update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom     a
          set CRP = 1
         from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom     a
         join u_prj_ecom.dim_subsidiary                                     b ON lower(b.COUNTRY_CODE) =  lower(a.COUNTRY)
         join OW_LAO.DIM_LAO_CRP_CS_STORENAME                               c ON lower(c.SKU_MAPPING) LIKE '%'|| substring(PO_SKU,locate(PO_SKU, '-', -1),length(PO_SKU)) || '%' --ADICIONADO POR LUCAS.GIL
                                                                             AND c.SUBSIDIARY = b.SUBSIDIARY
        where a.CRP is null
          and a.client_subsidiary_id in (7,8,9,10,11,12,13,14,15,16,17,18,19)
          and 1 = 0; -- Rodrigo Benincasa desativado porque as colunas c.SKU_MAPPING, a.crp nao existiam nas tabelas
        
        update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom     a
           set a.CRP = 0
         where a.crp is null
           and a.client_subsidiary_id in (7,8,9,10,11,12,13,14,15,16,17,18,19);
-- TRADE_IN - ADICIONADO LUCAS.GIL
        update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom     a
           set 	 TRADE_IN   = 1
               , TRADE_IN_ELIGIBILITY  = 1
         where a.TRADE_IN = 0
           and a.po_sku like '%-ECO'
           and a.client_subsidiary_id in (7,8,9,10,11,12,13,14,15,16,17,18,19);   
-- default po_device_type   
          update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom
             set po_devicetype = 'Web'
           where po_devicetype is null;    
          
          
--DELIVERY_MODE MAPPING
		update 
            ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom      a
        set   
            a.delivery_mode         = b.delivery_mode
        from 
            ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom          a
        join   
            ow_lao.dim_lao_delivery_mode_mapping_control_tower          b on b.subsidiary       = a.subsidiary 
                                                                        and  b.shipping_method  = a.shipping_method 
        where  
            b.active = true
            and a.delivery_mode is null;          
           
-- Control Tower                        
                 
     merge into ow_lao.ods_sales_control_tower_table                      a
          using ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom b on b.po_orderid = a.po_orderid
                                                                           and b.po_sku     = a.po_sku
                                                                           and b.country    = a.country
                                                                           and b.po_sku_kit = a.po_sku_kit
           when    matched then update  
                                   set a.po_date                    = b.po_date
                                     , a.po_hour                    = b.po_hour
                                     , a.podate_year                = b.podate_year
                                     , a.podate_month               = b.podate_month
                                     , a.samsung_care_order         = b.samsung_care_order
                                     , a.samsung_care               = b.samsung_care
                                     , a.samsung_care_eligibility   = b.samsung_care_eligibility
                                     , a.trade_in                   = b.trade_in
                                     , a.trade_in_eligibility       = b.trade_in_eligibility
                                     , a.costumer_code_id_name      = b.costumer_code_id_name
                                     , a.seller_po_orderid          = b.seller_po_orderid
                                     , a.payment_card_brand         = b.payment_card_brand
                                     , a.payment_type               = b.payment_type
                                     , a.installment                = b.installment
                                     , a.installment_eligibility    = b.installment_eligibility
                                     , a.po_cancelation_reason      = b.po_cancelation_reason
                                     , a.po_productgroup            = b.po_productgroup
                                     , a.po_code_sales_channel      = b.po_code_sales_channel
                                     , a.po_costumer_id             = b.po_costumer_id
                                     , a.po_sitecode                = b.po_sitecode
                                     , a.po_internal_status         = b.po_internal_status
                                     , a.po_invoicenumber           = b.po_invoicenumber
                                     , a.po_campain_tags            = b.po_campain_tags
                                     , a.po_campain                 = b.po_campain
                                     , a.po_coupon                  = b.po_coupon
                                     , a.po_medium                  = b.po_medium
                                     , a.po_src                     = b.po_src
                                     , a.po_utmi_campaing           = b.po_utmi_campaing
                                     , a.po_prodname                = b.po_prodname
                                     , a.po_seller_id               = b.po_seller_id
                                     , a.po_seller_name             = b.po_seller_name
                                     , a.po_status                  = b.po_status
                                     , a.client_subsidiary_id       = b.client_subsidiary_id
                                     , a.subsidiary                 = b.subsidiary
                                     , a.currency                   = b.currency
                                     , a.po_tradepolicy             = b.po_tradepolicy
                                     , a.po_vendortype              = b.po_vendortype
                                     , a.channel                    = b.channel
                                     , a.biz_type                   = b.biz_type
                                     , a.audience_type              = b.audience_type
                                     , a.po_storename               = b.po_storename
                                     , a.client_acquirer_message    = b.client_acquirer_message
                                     , a.po_lastupdate_date_hour    = b.po_lastupdate_date_hour
                                     , a.po_orderqty                = b.po_orderqty
                                     , a.po_qty                     = b.po_qty
                                     , a.po_itemdiscount_localcurr  = b.po_itemdiscount_localcurr
                                     , a.po_itemdiscount_usd        = b.po_itemdiscount_usd
                                     , a.po_price_localcurr         = b.po_price_localcurr
                                     , a.po_price_usd               = b.po_price_usd
                                     , a.po_plataform_datasource    = b.po_plataform_datasource
                                     , a.po_source_insert_date      = b.po_source_insert_date
                                     , a.po_source_last_update_date = b.po_source_last_update_date
                                     , a.po_insert_date             = b.po_insert_date
                                     , a.po_last_update_date        = b.po_last_update_date
                                     , a.po_payment_remark          = b.po_payment_remark
                                     , a.po_totalprice_usd          = b.po_totalprice_usd
                                     , a.po_totalprice_local        = b.po_totalprice_local
                                     , a.po_devicetype              = b.po_devicetype
                                     , a.updated_datetime           = current_timestamp
                                     , a.po_sku_kit                 = b.po_sku_kit  
                                     , a.po_prodname_kit            = b.po_prodname_kit           
                                     , a.is_kit                     = b.is_kit
                                     , a.country_cd                 = b.country_cd  
                                     , a.biz_type_ebi_hq            = b.biz_type_ebi_hq 
                                     , a.global_channel_ebi_hq      = b.global_channel_ebi_hq
                                     , a.customer_type              = b.customer_type
                                     , a.po_mobile_os               = b.po_mobile_os
                                     , a.nerp_billingdate           = b.nerp_billingdate
                                     , a.so_date                    = b.so_date
                                     , a.do_date                    = b.do_date
                                     , a.billing_date_local         = b.billing_date_local
                                     , a.shipping_method            = b.shipping_method
                                     , a.delivery_mode              = b.delivery_mode
           when not matched then insert(
                                           po_date
                                         , po_hour
                                         , podate_year
                                         , podate_month
                                         , country
                                         , samsung_care_order
                                         , samsung_care
                                         , samsung_care_eligibility
                                         , trade_in
                                         , trade_in_eligibility
                                         , costumer_code_id_name
                                         , po_orderid
                                         , seller_po_orderid
                                         , payment_card_brand
                                         , payment_type
                                         , installment
                                         , installment_eligibility
                                         , po_cancelation_reason
                                         , po_productgroup
                                         , po_code_sales_channel
                                         , po_costumer_id
                                         , po_sitecode
                                         , po_internal_status
                                         , po_invoicenumber
                                         , po_campain_tags
                                         , po_campain
                                         , po_coupon
                                         , po_medium
                                         , po_src
                                         , po_utmi_campaing
                                         , po_sequence_orderid
                                         , po_prodname
                                         , po_sku
                                         , po_seller_id
                                         , po_seller_name
                                         , po_status
                                         , client_subsidiary_id
                                         , subsidiary
                                         , currency
                                         , po_tradepolicy
                                         , po_vendortype
                                         , channel
                                         , biz_type
                                         , audience_type
                                         , po_storename
                                         , client_acquirer_message
                                         , po_lastupdate_date_hour
                                         , po_orderqty
                                         , po_qty
                                         , po_itemdiscount_localcurr
                                         , po_itemdiscount_usd
                                         , po_price_localcurr
                                         , po_price_usd
                                         , po_plataform_datasource
                                         , po_source_insert_date
                                         , po_source_last_update_date
                                         , po_insert_date
                                         , po_last_update_date
                                         , po_payment_remark   
                                         , po_totalprice_usd
                                         , po_totalprice_local    
                                         , po_devicetype    
                                         , po_sku_kit                   
                                         , po_prodname_kit              
                                         , is_kit    
                                         , country_cd
                                         , biz_type_ebi_hq              
                                         , global_channel_ebi_hq  
                                         , customer_type
                                         , po_mobile_os
                                         , nerp_billingdate
                                         , so_date
                                         , do_date
                                         , billing_date_local
                                         , shipping_method
                                         , delivery_mode
                                 )
                                 values(
                                           b.po_date
                                         , b.po_hour
                                         , b.podate_year
                                         , b.podate_month
                                         , b.country
                                         , b.samsung_care_order
                                         , b.samsung_care
                                         , b.samsung_care_eligibility
                                         , b.trade_in
                                         , b.trade_in_eligibility
                                         , b.costumer_code_id_name
                                         , b.po_orderid
                                         , b.seller_po_orderid
                                         , b.payment_card_brand
                                         , b.payment_type
                                         , b.installment
                                         , b.installment_eligibility
                                         , b.po_cancelation_reason
                                         , b.po_productgroup
                                         , b.po_code_sales_channel
                                         , b.po_costumer_id
                                         , b.po_sitecode
                                         , b.po_internal_status
                                         , b.po_invoicenumber
                                         , b.po_campain_tags
                                         , b.po_campain
                                         , b.po_coupon
                                         , b.po_medium
                                         , b.po_src
                                         , b.po_utmi_campaing
                                         , b.po_sequence_orderid
                                         , b.po_prodname
                                         , b.po_sku
                                         , b.po_seller_id
                                         , b.po_seller_name
                                         , b.po_status
                                         , b.client_subsidiary_id
                                         , b.subsidiary
                                         , b.currency
                                         , b.po_tradepolicy
                                         , b.po_vendortype
                                         , b.channel
                                         , b.biz_type
                                         , b.audience_type
                                         , b.po_storename
                                         , b.client_acquirer_message
                                         , b.po_lastupdate_date_hour
                                         , b.po_orderqty
                                         , b.po_qty
                                         , b.po_itemdiscount_localcurr
                                         , b.po_itemdiscount_usd
                                         , b.po_price_localcurr
                                         , b.po_price_usd
                                         , b.po_plataform_datasource
                                         , b.po_source_insert_date
                                         , b.po_source_last_update_date
                                         , b.po_insert_date
                                         , b.po_last_update_date
                                         , b.po_payment_remark   
                                         , b.po_totalprice_usd
                                         , b.po_totalprice_local                              
                                         , b.po_devicetype
                                         , b.po_sku_kit                   
                                         , b.po_prodname_kit              
                                         , b.is_kit 
                                         , b.country_cd 
                                         , b.biz_type_ebi_hq                 
                                         , b.global_channel_ebi_hq  
                                         , b.customer_type
                                         , b.po_mobile_os
                                         , b.nerp_billingdate
                                         , b.so_date
                                         , b.do_date
                                         , b.billing_date_local
                                         , b.shipping_method
                                         , b.delivery_mode
                                 );
         
end