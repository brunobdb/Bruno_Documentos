CREATE PROCEDURE OW_LAO.proc_stg_table_ods_premium_items
(IN input_text NVARCHAR(250))
LANGUAGE SQLSCRIPT AS
BEGIN
	
truncate table OW_LAO.STG_LAO_PRODUCT_PREMIUM_ITEMS;
     insert into OW_LAO.STG_LAO_PRODUCT_PREMIUM_ITEMS
     SELECT DISTINCT *              
		     FROM OW_LAO.RAW_LAO_PRODUCT_PREMIUM_ITEMS m
		    WHERE m.FILE_NAME = input_text;
		   
		MERGE INTO OW_LAO.ODS_LAO_PRODUCT_PREMIUM_ITEMS O
         USING OW_LAO.STG_LAO_PRODUCT_PREMIUM_ITEMS M ON O.ITEM = M.ITEM_PREMIUM
                                                        AND O.AP2      = M.SUBSIDIARY
														AND O.PLAN    >= M.PLAN
          WHEN NOT MATCHED THEN INSERT (
                                       	 AP2
                                       , PRODUCT_GRP
                                       , PRODUCT
                                       , ITEM
                                       , PLAN
									   , MONTH
									   , VALUE
									   , FILE_NAME
									   , INSERTED_TIMESTAMP
									   ,FILE_ROW_NUMBER
                                 )
                                VALUES (
                                         M.SUBSIDIARY
                                       , '-'
                                       , '-'
                                       , M.ITEM_PREMIUM
                                       , M.PLAN
									   , M.MONTH
									   , M.VALUE
									   , M.FILE_NAME
									   , M.INSERTED_TIMESTAMP
									   , '1'
									   );       
   
END