CREATE PROCEDURE ow_lao.proc_ods_sales_control_tower_table_raw_vtex_ssg_ar_sales_order
 LANGUAGE SQLSCRIPT AS
 BEGIN
 
      truncate table ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order;
 
 -- Vtex Argentina Talend   
       insert into ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order
   
            select cast(
                         add_seconds(
                           to_timestamp(a.creation_date)
                          , (-3 * 60) * 60
                         )
                    as date)                            as po_date
                 , year(cast(
                           add_seconds(
                             to_timestamp(a.creation_date)
                            , (-3 * 60) * 60
                           )
                   as date))                            as podate_year
                 ,  month(cast(
                             add_seconds(
                                to_timestamp(a.creation_date)
                               , (-3 * 60) * 60
                           )
                    as date))                           as podate_month
                 , 'Argentina'                          as country
                 , 0                                    as samsung_care_order
                 , 0                                    as samsung_care
                 , 0                                    as samsung_care_eligibility
                 , 0                                    as trade_in
                 , 0                                    as trade_in_eligibility
                 , 0                                    as trade_up
                 , 0                                    as trade_up_eligibility
                 , a.affiliate_id                       as costumer_code_id_name
                 , a.order_id                           as po_orderid
                 , a.seller_order_id                    as seller_po_orderid
                 , cast(null as varchar(3000))          as payment_card_brand
                 , cast(null as varchar(3000))          as payment_type
                 , 0                                    as installment
                 , null                                 as installment_eligibility
                 , a.cancellation_reason                as po_cancelation_reason
                 , c.product_group_1                    as po_productgroup
                 , a.sales_channel                      as po_code_sales_channel
                 , null                                 as po_costumer_id
                 , a.hostname                           as po_sitecode
                 , a.status                             as po_internal_status
                 , null                                 as po_invoicenumber
                 , a.marketing_tags                     as po_campain_tags
                 , a.utm_campaign                       as po_campain
                 , a.coupon                             as po_coupon
                 , a.utm_medium                         as po_medium
                 , a.utm_source                         as po_src
                 , a.utmi_campaign                      as po_utmi_campaing
                 , a.sequence                           as po_sequence_orderid
                 , b.name                               as po_prodname
                 , coalesce(
                        b.ref_id
                      , b.name
                   )                                    as po_sku
                 , replace(replace(a.seller_id 
                             , '["', ''), '"]', '')     as po_seller_id
                 , replace(replace(a.seller_name 
                             , '["', ''), '"]', '')     as po_seller_name
                 , d.status                             as po_status
                 , 1                                    as client_subsidiary_id
                 , 'SEASA'                              as subsidiary
                 , 'ARS'                                as currency
                 , null                                 as po_tradepolicy
                 , a.origin                             as po_vendortype       
                 , cast(null as varchar(255))           as channel
                 , cast(null as varchar(255))           as biz_type
                 , cast(null as varchar(255))           as audience_type
                 , cast(null as varchar(255))           as po_storename
                 , cast(null as varchar(255))           as client_acquirer_message
                 , a.creation_timestamp                 as po_lastupdate_date_hour
                 , 0                                    as po_orderqty
                 , sum(b.quantity)                      as po_qty
                 , sum(b.price - b.selling_price) 
                       / 100.00                         as po_itemdiscount_localcurr
                 , 0                                    as po_itemdiscount_usd
                 , sum(b.price / 100.00)                as po_price_localcurr
                 , 0                                    as po_price_usd
                 , 'u_prj_ecom.raw_vtex_ssg_ar_sales_order'  
                                                        as po_plataform_datasource   
                 , a.created_at                         as po_source_insert_date
                 , a.creation_timestamp                 as po_source_last_update_date
                 , current_timestamp                    as po_insert_date
                 , null                                 as po_last_update_date
                 , cast(null as varchar(3000))          as po_payment_remark
                 , cast(
                        add_seconds(
                            to_timestamp(a.creation_date)
                          , (-3 * 60) * 60
                        )
                   as time)                             as po_hour 
                 , 0                                    as po_totalprice_usd
                 , 0                                    as po_totalprice_local
                 , cast(null as varchar(255))           as po_devicetype
                 , cast('' as varchar(255))             as po_sku_kit
                 , cast('' as varchar(255))             as po_prodname_kit
                 , cast(0.00 as decimal)                as po_price_localcurr_kit
                 , cast(0.00 as decimal)                as po_itemdiscount_localcurr_kit
                 , false                                as is_kit 
                 , 'ARG'                                as country_cd
                 , cast(null as varchar(255))           as biz_type_ebi_hq
                 , cast(null as varchar(255))           as global_channel_ebi_hq
                 , b.attachments                        as po_sku_attachments
                 , e.selected_sla 						as shipping_method
				 , cast(null as varchar(255))           as customer_type
				 , cast(null as varchar(255))           as po_mobile_os
				 ,CAST (0 AS int )                      AS crp
				 ,cast(null as varchar(255))            AS delivery_mode
                 
              from u_prj_ecom.raw_vtex_ssg_ar_sales_order                  a
              join u_prj_ecom.raw_vtex_ssg_ar_sales_order_item             b on b.order_id      = a.order_id
         left join ow_md.dim_product                                       c on c.sku           = b.ref_id
         left join ow_lao.dim_ods_sales_control_tower_table_status_mapping d on d.status_origin = coalesce(a.status, 'incomplete')
         left join u_prj_ecom.raw_vtex_ssg_ar_sales_order_shipping         e on e.order_id      = a.order_id 
                                                                             and e.item_index   = b.item_index
             where 1 = 1 
               -- and e.order_id = '1475093605703-01'
               and a.creation_timestamp >= add_days(current_date, -3)
               and not exists(                        
                        select 1
                          from ow_lao.ods_sales_control_tower_table aa
                         where aa.po_orderid                  = a.order_id
                           and aa.po_sku                      = b.ref_id
                           and aa.country                     = 'Argentina'
                           and aa.po_internal_status          = coalesce(a.status, 'incomplete')
                           and aa.po_source_last_update_date >= cast(a.creation_timestamp as seconddate)
                   )
          group by a.creation_date
                 , a.affiliate_id                       
                 , a.order_id                  
                 , a.seller_order_id                    
                 , a.cancellation_reason                
                 , c.product_group_1                    
                 , a.sales_channel                  
                 , a.hostname                           
                 , a.status                             
                 , a.marketing_tags                  
                 , a.utm_campaign                   
                 , a.coupon                     
                 , a.utm_medium                     
                 , a.utm_source
                 , a.utmi_campaign                  
                 , a.sequence                     
                 , b.name                       
                 , b.ref_id
                 , a.seller_id                          
                 , a.seller_name                        
                 , d.status                             
                 , a.created_at                   
                 , a.creation_timestamp      
                 , a.origin
                 , b.attachments
                 , e.selected_sla
                ; 
                 
 -- Samsung Care
    update ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order
       set samsung_care = 1
     where upper(po_prodname) like upper('%samsung care%');
                 
 -- Payments                        
                 
             drop table ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_payments;
    create column table ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_payments
        as (
                 
              select a.po_orderid
                   , max(a.installments)                as installment
                   , string_agg(a.brand, '|')           as payment_card_brand
                   , string_agg(a.payment_type, '|')    as payment_type
                   , string_agg(
                        a.payment_type     || ':' || 
                        a.brand            || ':' || 
                        a.value / 100.00   || ':' || 
                        a.installments
                        , '|' 
                   )                                    as po_payment_remark
                from (   
                            select distinct
                                   a.po_orderid
                                 , case coalesce(b.payment_group, '')
                                        when ''
                                        then ''
                                        else coalesce(b.payment_system_name, '')
                                   end                                   as brand
                                 , coalesce(b.payment_group      , '')   as payment_type
                                 , b.value
                                 , case when b.installments is  null then 1 else b.installments end as installments
                              from ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order a  
                              join u_prj_ecom.raw_vtex_ssg_ar_sales_order_payment                       b on b.order_id = a.po_orderid
                 ) a
            group by a.po_orderid
        );                 
        
        update ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order          a
           set installment        = b.installment
             , payment_card_brand = b.payment_card_brand
             , payment_type       = b.payment_type
             , po_payment_remark  = b.po_payment_remark
          from ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order    a
          join ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_payments b on b.po_orderid = a.po_orderid;        
 
              drop table ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order_agg;
     create column table ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order_agg
         as (               
                select country
                     , po_orderid
                     , sum(po_qty)             as po_orderqty
                     , sum(po_price_localcurr) as po_totalprice_local
                  from ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order   
              group by country
                     , po_orderid           
         );
         
              drop table ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order_sku_agg;
     create column table ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order_sku_agg
         as (               
                select country
                     , po_orderid
                     , po_sku
                     , sum(po_qty)                    as po_orderqty
                     , sum(po_price_localcurr)        as po_totalprice_local
                     , sum(po_itemdiscount_localcurr) as po_itemdiscount_localcurr
                  from ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order   
              group by country
                     , po_orderid   
                     , po_sku        
         );        
           
        update ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order         a
           set a.po_orderqty         = b.po_orderqty
             , a.po_totalprice_local = (c.po_totalprice_local * c.po_orderqty) - c.po_itemdiscount_localcurr
             , a.po_price_localcurr  = (c.po_totalprice_local * c.po_orderqty) - c.po_itemdiscount_localcurr
          from ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order         a
          join ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order_agg     b on b.country    = a.country
                                                                                             and b.po_orderid = a.po_orderid
          join ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order_sku_agg c on c.country    = a.country
                                                                                             and c.po_orderid = a.po_orderid
                                                                                             and c.po_sku     = a.po_sku;
  
  -- Conversao para dolar
        update ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order a
           set po_itemdiscount_usd = COALESCE (a.po_itemdiscount_localcurr / cast(b.exchange_rate as decimal),0)
             , po_price_usd        = COALESCE (a.po_price_localcurr        / cast(b.exchange_rate as decimal),0)
             , po_totalprice_usd   = COALESCE (a.po_totalprice_local       / cast(b.exchange_rate as decimal),0)
          from ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order a
          join ow_lao.ft_ap2_exchange_rate                                          b on b.valid_from  = add_days(a.po_date, -1)
                                                                                     and b.to_currency = a.currency;   
  
  -- Sales channel                                                                            
         update ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order a
           set a.channel               = b.global_channel
             , a.biz_type              = b.biz_type
             , a.audience_type         = b.audience_type
             , a.po_storename          = b.partner_level
             , a.biz_type_ebi_hq       = b.biz_type_ebi
             ,a.global_channel_ebi_hq  = b.global_channel_ebi
             , a.customer_type		   = b.customer_type
             , a.po_mobile_os		   = b.po_mobile_os
          from ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order a
          join ow_md.sales_channel                                                  b on lower(b.country)          = lower(a.country)
                                                                                     and b.sales_channel           = a.po_code_sales_channel
                                                                                     and coalesce(b.identifier,'') = a.costumer_code_id_name
                                                                                     and b.plataform_account       = a.po_sitecode
         where client_subsidiary_id in (1)
           and lower(b.plataform_type)     = 'vtex'
           and coalesce(has_store_id, 'N') = 'N'
           and coalesce(b.identifier,'')  != '';   
           
        update ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order a
           set a.channel               = b.global_channel
             , a.biz_type              = b.biz_type
             , a.audience_type         = b.audience_type
             , a.po_storename          = b.partner_level
             , a.biz_type_ebi_hq       = b.biz_type_ebi
             ,a.global_channel_ebi_hq  = b.global_channel_ebi
             , a.customer_type		   = b.customer_type
             , a.po_mobile_os		   = b.po_mobile_os
          from ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order a
          join ow_md.sales_channel                                                  b on lower(b.country)     = lower(a.country)
                                                                                     and b.sales_channel      = a.po_code_sales_channel
                                                                                     and b.plataform_account  = a.po_sitecode
         where client_subsidiary_id in (1)
           and lower(b.plataform_type)     = 'vtex'
           and coalesce(has_store_id, 'N') = 'N'
           and coalesce(b.identifier,'')   = '';  
           
        update ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order a
           set a.channel                = b.channel
             , a.biz_type               = b.byz_type
             , a.audience_type          = b.audience_type
             , a.po_storename           = b.storename
             , a.biz_type_ebi_hq        = b.biz_type_ebi_hq
             , a.global_channel_ebi_hq  = b.global_channel_ebi_hq
             
          from ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order a
          join ow_lao.temp_dim_ecom_store_seasa_mkm                                 b on b.id = left(a.po_orderid, 6)
         where client_subsidiary_id    = 1
           and a.costumer_code_id_name = 'MKM';   
           
        update ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order a
           set a.channel                = 'eStore'
             , a.biz_type               = '3PD'
             , a.audience_type          = '3PD'
             , a.po_storename           = 'Mercado Libre'
             , a.biz_type_ebi_hq        = 'B2C'
             , a.global_channel_ebi_hq  = '3PD'
          from ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order a
         where client_subsidiary_id    = 1
           and a.costumer_code_id_name = 'MKM'
           and a.channel               is null
           and not exists(
                    select 1
                      from ow_lao.temp_dim_ecom_store_seasa_mkm aa 
                     where aa.id = left(a.po_orderid, 6)
               );
               
--mkb seasa inserido dia 04/07/2024
        update ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order a
           set a.channel                = b.global_channel
             , a.biz_type               = b.biz_type
             , a.audience_type          = b.audience_type
             , a.po_storename           = b.partner_level
             , a.biz_type_ebi_hq        = b.biz_type_ebi
             , a.global_channel_ebi_hq  = b.global_channel_ebi
          from ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order a
          join ow_md.sales_channel                                                  b on lower(b.country)          = lower(a.country)
                                                                                     and coalesce(b.identifier,'') = a.costumer_code_id_name
                                                                                     and b.plataform_account       = a.po_sitecode
         where client_subsidiary_id in (1)
           and lower(b.plataform_type)     = 'vtex'
           and coalesce(has_store_id, 'N') = 'N'
           and coalesce(b.identifier,'')  != ''
           and left(a.po_orderid, 3) = 'MKB';                                    
           
-- app samsung
          update ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order
             set po_devicetype = 'MOBILEAPP'
           where po_sitecode  in ('samsungarapp', 'samsungarappios')
             and client_subsidiary_id = 1; 
             
-- O2O ENDLESS AISLE p.anaalinne 10/09/2025 - S2SDSLA-11264
        update ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order a
           set a.channel                = 'eStore'
             , a.biz_type               = 'B2C' 
             , a.audience_type          = 'Endless Aisle'
             , a.po_storename           = 'Endless Aisle'
             , a.biz_type_ebi_hq        = 'B2C' 
             , a.global_channel_ebi_hq  = 'eStore'
          from ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order a
          join u_prj_ecom.raw_vtex_ssg_ar_sales_order_shipping                      b on b.order_id = a.po_orderid
         where a.client_subsidiary_id    = 1
           and b.delivery_company = 'Retiro en Tienda'
           and a.biz_type != 'EPP' ;      
       
-- Trade in and Trade up Flag
         --drop table #sales_control_tower_raw_vtex_ssg_ar_sales_order_tradein_tradeup;
        create local temporary table #sales_control_tower_raw_vtex_ssg_ar_sales_order_tradein_tradeup
            as (
                    select po_orderid
                         , case 
                               when json_value(
                                        replace(
                                           replace(
                                                replace(
                                                    po_sku_attachments
                                                , '\','')
                                           , '"{', '{')
                                       , '}"', '}')
                                   , '$.content.TradeIn' DEFAULT 'false' ON EMPTY)  = false 
                                then 0
                                else 1
                            end                                                         as tradeIn
                         , case 
                               when json_value(
                                        replace(
                                           replace(
                                                replace(
                                                    po_sku_attachments
                                                , '\','')
                                           , '"{', '{')
                                       , '}"', '}')
                                   , '$.content.TradeIn.device1.ecoTradein' DEFAULT 'false' ON EMPTY)  = false 
                                then 0
                                else 1
                            end                                                         as tradeUP
                      from ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order   
                     where po_sku_attachments is not null
            );
            
        
          --drop table #sales_control_tower_raw_vtex_ssg_ar_sales_order_tradein_tradeup_agg;
        create local temporary table #sales_control_tower_raw_vtex_ssg_ar_sales_order_tradein_tradeup_agg
            as (
                    select po_orderid
                         , sum(tradeIn)    tradeIn
                         , sum(tradeUP)    tradeUP
                      from #sales_control_tower_raw_vtex_ssg_ar_sales_order_tradein_tradeup
                  group by po_orderid
            );
           
           
        update OW_LAO.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order a
           set TRADE_IN = b.tradeIn
             , trade_up = b.tradeUP
          from OW_LAO.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order a
          join #sales_control_tower_raw_vtex_ssg_ar_sales_order_tradein_tradeup_agg b on b.po_orderid = a.po_orderid
         where a.client_subsidiary_id    = 1;     
             
-- default po_device_type   
          update ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order
             set po_devicetype = 'Web'
           where po_devicetype is null
             and client_subsidiary_id = 1;  
            
 --CRP mapping Storename/Voucher_coupon --lucas.gil -03/09/2025
		update
		    ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order     a
		set
		    a.crp = 1  
		from
		     ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order     a
		join ow_lao.dim_lao_crp_cs_storename b on
		     lower(b.storename_crp) = lower (a.po_storename)
		    and a.subsidiary = b.subsidiary
		    where a.crp = 0;
   
  ----Mapping ALL coupon(GREATER THAN 3 digits)--lucas.gil -03/09/2025
		update
			 ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order a
		set
			a.crp = 2
		from
			 ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order a
		join ow_lao.dim_lao_crp_cs_voucher_coupon b on
			 lower(b.voucher_coupon) = lower (a.po_coupon) 
				and b.subsidiary = a.subsidiary
			where a.crp = 0
				and length(b.voucher_coupon) > 3;
	
--------Partial COUPON mapping with "-" before/after coupon --lucas.gil -03/09/2025
		update
			 ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order a
		set
			a.crp = 2	
		from
			 ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order a
		join ow_lao.dim_lao_crp_cs_voucher_coupon b on
			        	 locate (a.po_coupon, '-' || b.voucher_coupon || '-') > 0
			        	 and b.subsidiary = a.subsidiary
			        	where a.crp = 0
			        and length(b.voucher_coupon) = 3;
		
		update
			 ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order a
		set
			a.crp = 2	
		from
			 ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order a
		join ow_lao.dim_lao_crp_cs_voucher_coupon b on
							  	locate(a.po_coupon, b.voucher_coupon || '-') = 1
			        	 and a.subsidiary = b.subsidiary
			        	where a.crp = 0
			        and length(b.voucher_coupon) = 3;
			       
--DELIVERY_MODE MAPPING
		update 
            ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order      a
        set   
            a.delivery_mode         = b.delivery_mode
        from 
            ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order          a
        join   
            ow_lao.dim_lao_delivery_mode_mapping_control_tower          b on b.subsidiary       = a.subsidiary 
                                                                        and  b.shipping_method  = a.shipping_method 
        where  
            b.active = true
            and a.delivery_mode is null;
	       
            
-- Control tower
     merge into ow_lao.ods_sales_control_tower_table                                 a
          using ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_ar_sales_order b on b.po_orderid = a.po_orderid
                                                                                      and b.po_sku     = a.po_sku
                                                                                      and b.country    = a.country
                                                                                      and b.po_sku_kit = a.po_sku_kit
           when    matched then update  
                                   set a.po_date                    = b.po_date
                                     , a.po_hour                    = b.po_hour
                                     , a.podate_year                = b.podate_year
                                     , a.podate_month               = b.podate_month
                                     , a.samsung_care_order         = b.samsung_care_order
                                     , a.samsung_care               = b.samsung_care
                                     , a.samsung_care_eligibility   = b.samsung_care_eligibility
                                     , a.trade_in                   = b.trade_in
                                     , a.trade_in_eligibility       = b.trade_in_eligibility
                                     , a.costumer_code_id_name      = b.costumer_code_id_name
                                     , a.seller_po_orderid          = b.seller_po_orderid
                                     , a.payment_card_brand         = b.payment_card_brand
                                     , a.payment_type               = b.payment_type
                                     , a.installment                = b.installment
                                     , a.installment_eligibility    = b.installment_eligibility
                                     , a.po_cancelation_reason      = b.po_cancelation_reason
                                     , a.po_productgroup            = b.po_productgroup
                                     , a.po_code_sales_channel      = b.po_code_sales_channel
                                     , a.po_costumer_id             = b.po_costumer_id
                                     , a.po_sitecode                = b.po_sitecode
                                     , a.po_internal_status         = b.po_internal_status
                                     , a.po_invoicenumber           = b.po_invoicenumber
                                     , a.po_campain_tags            = b.po_campain_tags
                                     , a.po_campain                 = b.po_campain
                                     , a.po_coupon                  = b.po_coupon
                                     , a.po_medium                  = b.po_medium
                                     , a.po_src                     = b.po_src
                                     , a.po_utmi_campaing           = b.po_utmi_campaing
                                     , a.po_prodname                = b.po_prodname
                                     , a.po_seller_id               = b.po_seller_id
                                     , a.po_seller_name             = b.po_seller_name
                                     , a.po_status                  = b.po_status
                                     , a.client_subsidiary_id       = b.client_subsidiary_id
                                     , a.subsidiary                 = b.subsidiary
                                     , a.currency                   = b.currency
                                     , a.po_tradepolicy             = b.po_tradepolicy
                                     , a.po_vendortype              = b.po_vendortype
                                     , a.channel                    = b.channel
                                     , a.biz_type                   = b.biz_type
                                     , a.audience_type              = b.audience_type
                                     , a.po_storename               = b.po_storename
                                     , a.client_acquirer_message    = b.client_acquirer_message
                                     , a.po_lastupdate_date_hour    = b.po_lastupdate_date_hour
                                     , a.po_orderqty                = b.po_orderqty
                                     , a.po_qty                     = b.po_qty
                                     , a.po_itemdiscount_localcurr  = b.po_itemdiscount_localcurr
                                     , a.po_itemdiscount_usd        = b.po_itemdiscount_usd
                                     , a.po_price_localcurr         = b.po_price_localcurr
                                     , a.po_price_usd               = b.po_price_usd
                                     , a.po_plataform_datasource    = b.po_plataform_datasource
                                     , a.po_source_insert_date      = b.po_source_insert_date
                                     , a.po_source_last_update_date = b.po_source_last_update_date
                                     , a.po_insert_date             = b.po_insert_date
                                     , a.po_last_update_date        = b.po_last_update_date
                                     , a.po_payment_remark          = b.po_payment_remark
                                     , a.po_totalprice_usd          = b.po_totalprice_usd
                                     , a.po_totalprice_local        = b.po_totalprice_local
                                     , a.po_devicetype              = b.po_devicetype
                                     , a.updated_datetime           = current_timestamp
                                     , a.po_sku_kit                 = b.po_sku_kit  
                                     , a.po_prodname_kit            = b.po_prodname_kit           
                                     , a.is_kit                     = b.is_kit
                                     , a.country_cd                 = b.country_cd  
                                     , a.biz_type_ebi_hq            = b.biz_type_ebi_hq 
                                     , a.global_channel_ebi_hq      = b.global_channel_ebi_hq
                                     , a.shipping_method			= b.shipping_method
                                     , a.customer_type				= b.customer_type
                                     , a.po_mobile_os				= b.po_mobile_os
                                     , a.crp 						= b.crp
                                     , a.delivery_mode   			= b.delivery_mode
           when not matched then insert(
                                           po_date
                                         , po_hour
                                         , podate_year
                                         , podate_month
                                         , country
                                         , samsung_care_order
                                         , samsung_care
                                         , samsung_care_eligibility
                                         , trade_in
                                         , trade_in_eligibility
                                         , costumer_code_id_name
                                         , po_orderid
                                         , seller_po_orderid
                                         , payment_card_brand
                                         , payment_type
                                         , installment
                                         , installment_eligibility
                                         , po_cancelation_reason
                                         , po_productgroup
                                         , po_code_sales_channel
                                         , po_costumer_id
                                         , po_sitecode
                                         , po_internal_status
                                         , po_invoicenumber
                                         , po_campain_tags
                                         , po_campain
                                         , po_coupon
                                         , po_medium
                                         , po_src
                                         , po_utmi_campaing
                                         , po_sequence_orderid
                                         , po_prodname
                                         , po_sku
                                         , po_seller_id
                                         , po_seller_name
                                         , po_status
                                         , client_subsidiary_id
                                         , subsidiary
                                         , currency
                                         , po_tradepolicy
                                         , po_vendortype
                                         , channel
                                         , biz_type
                                         , audience_type
                                         , po_storename
                                         , client_acquirer_message
                                         , po_lastupdate_date_hour
                                         , po_orderqty
                                         , po_qty
                                         , po_itemdiscount_localcurr
                                         , po_itemdiscount_usd
                                         , po_price_localcurr
                                         , po_price_usd
                                         , po_plataform_datasource
                                         , po_source_insert_date
                                         , po_source_last_update_date
                                         , po_insert_date
                                         , po_last_update_date
                                         , po_payment_remark   
                                         , po_totalprice_usd
                                         , po_totalprice_local    
                                         , po_devicetype    
                                         , po_sku_kit                   
                                         , po_prodname_kit              
                                         , is_kit    
                                         , country_cd
                                         , biz_type_ebi_hq              
                                         , global_channel_ebi_hq  
                                         , shipping_method
                                         , customer_type
                                         , po_mobile_os
                                         , crp
                                         , delivery_mode
                                 )
                                 values(
                                           b.po_date
                                         , b.po_hour
                                         , b.podate_year
                                         , b.podate_month
                                         , b.country
                                         , b.samsung_care_order
                                         , b.samsung_care
                                         , b.samsung_care_eligibility
                                         , b.trade_in
                                         , b.trade_in_eligibility
                                         , b.costumer_code_id_name
                                         , b.po_orderid
                                         , b.seller_po_orderid
                                         , b.payment_card_brand
                                         , b.payment_type
                                         , b.installment
                                         , b.installment_eligibility
                                         , b.po_cancelation_reason
                                         , b.po_productgroup
                                         , b.po_code_sales_channel
                                         , b.po_costumer_id
                                         , b.po_sitecode
                                         , b.po_internal_status
                                         , b.po_invoicenumber
                                         , b.po_campain_tags
                                         , b.po_campain
                                         , b.po_coupon
                                         , b.po_medium
                                         , b.po_src
                                         , b.po_utmi_campaing
                                         , b.po_sequence_orderid
                                         , b.po_prodname
                                         , b.po_sku
                                         , b.po_seller_id
                                         , b.po_seller_name
                                         , b.po_status
                                         , b.client_subsidiary_id
                                         , b.subsidiary
                                         , b.currency
                                         , b.po_tradepolicy
                                         , b.po_vendortype
                                         , b.channel
                                         , b.biz_type
                                         , b.audience_type
                                         , b.po_storename
                                         , b.client_acquirer_message
                                         , b.po_lastupdate_date_hour
                                         , b.po_orderqty
                                         , b.po_qty
                                         , b.po_itemdiscount_localcurr
                                         , b.po_itemdiscount_usd
                                         , b.po_price_localcurr
                                         , b.po_price_usd
                                         , b.po_plataform_datasource
                                         , b.po_source_insert_date
                                         , b.po_source_last_update_date
                                         , b.po_insert_date
                                         , b.po_last_update_date
                                         , b.po_payment_remark   
                                         , b.po_totalprice_usd
                                         , b.po_totalprice_local                              
                                         , b.po_devicetype
                                         , b.po_sku_kit                   
                                         , b.po_prodname_kit              
                                         , b.is_kit 
                                         , b.country_cd 
                                         , b.biz_type_ebi_hq                 
                                         , b.global_channel_ebi_hq  
                                         , b.shipping_method
                                         , b.customer_type
                                         , b.po_mobile_os
                                         , b.crp
                                         , b.delivery_mode
                                 );    
  end