CREATE PROCEDURE OW_LAO.proc_ods_sales_control_tower_table_diggit
 LANGUAGE SQLSCRIPT AS
     begin
          --drop table #ods_diggit_ecom_orders_prepare;
          --drop table #ods_diggit_ecom_orders_prepare_agg;
          --drop table #ods_diggit_ecom_orders_prepare_sku_agg;          
        create local temporary table #ods_diggit_ecom_orders_prepare 
            as (
                    select cast(
                                   concat(
                                       concat(a.order_creation_date, ' ')
                                     , a.order_creation_hour)
                                as timestamp)                                as po_date
                         , month(a.order_creation_date)                      as po_month
                         , year(a.order_creation_date)                       as po_year
                         , b.country                                         as country
                         , b.subsidiary                                      as subsidiary
                         , b.currency                                        as currency
                         , coalesce(  a.updated_timestamp
                                    , a.inserted_timestamp
                           )                                                 as po_lastupdate_date_hour
                         , coalesce(  a.updated_timestamp
                                    , a.inserted_timestamp
                           )                                                 as po_source_last_update_date
                         , a.order_code                                      as po_orderid
                         , 'diggit'                                          as po_seller_name
                         , a.sku                                             as po_prodname
                         , cast(null as varchar(255))                        as po_storename                            
                         , a.store_name                                      as po_store_name       
                         , cast(null as varchar(255))                        as channel
                         , cast(null as varchar(255))                        as biz_type
                         , cast(null as varchar(255))                        as audience_type
                         , c.status                                          as po_status
                         , a.order_status                                    as po_internal_status
                         , a.sku                                             as po_sku
                         , sum(abs(a.qty))                                   as po_qty
                         , 0                                                 as po_orderqty
                         , cast(0.00 as decimal)                             as po_itemdiscount_localcurr
                         , cast(0.00 as decimal)                             as po_itemdiscount_usd
                         , sum(cast(a.product_price as decimal))             as po_price_localcurr
                         , cast(0.00 as decimal)                             as po_price_usd
                         , 'u_prj_ecom.ods_diggit_ecom_orders'               as po_plataform_datasource   
                         , a.inserted_timestamp                              as po_source_insert_date
                         , cast(0.00 as decimal)                             as po_totalprice_usd
                         , cast(0.00 as decimal)                             as po_totalprice_local
                         , max(a.id)                                         as po_plataform_datasource_order_id
                         , cast(null as varchar(255))                        as po_devicetype
                         , ''                                                as po_sku_kit
                         , ''                                                as po_prodname_kit
                         , cast(0.00 as decimal)                             as po_price_localcurr_kit
                         , cast(0.00 as decimal)                             as po_itemdiscount_localcurr_kit
                         , false                                             as is_kit 
                         , 'ARG'                                             as country_cd
                         , cast(null as varchar(3))                          as biz_type_ebi_hq
                         , cast(null as varchar(3))                          as global_channel_ebi_hq
                         , 1                                                 as installment
                         , max(b.id)                                         as client_subsidiary_id
                         , 'diggit'                                          as po_sitecode
                         , cast(a.order_creation_hour as time)               as po_hour
                         , cast(null as varchar(255))						 AS customer_type
                         , cast(null as varchar(255))						 AS po_mobile_os
                      from u_prj_ecom.ods_diggit_ecom_orders                       a
                      join u_prj_ecom.dim_subsidiary                               b on b.id            = 1
                 left join ow_lao.dim_ods_sales_control_tower_table_status_mapping c on c.status_origin = coalesce(a.order_status, 'incomplete')
                     where a.qty > 0
                       and not exists(
		                                select 1
		                                  from ow_lao.ods_sales_control_tower_table aa
		                                  where aa.po_orderid           = a.order_code
                                            and aa.po_sku               = a.sku
                                            and aa.client_subsidiary_id = 1
                                            and aa.po_sitecode          = 'diggit'
                                            and aa.po_internal_status   = a.order_status
                           )
                       and  a.store_name  NOT IN (
                        		  '7960 - DIGGIT MENDOZA' 
								, '7B10 - DIGGIT LA RIOJA'
								, '7B90 - DIGGIT-CBA-PDV-NUEVOCENTRO'
								, '7C10 - DIGGIT ABASTO'
								, '7950 - DIGGIT QUILMES'
								, '7A10 - DIGGIT BAHIA BLANCA'
								, '7A70 - DIGGIT SALTA'
								, '7B80 - DIGGIT - MZ - PDV - PALMARES'
								, '7970 - DIGGIT LOMAS'
								, '7A80 - DIGGIT ALTO ROSARIO'
								, '7B00 - DIGGIT PLAZA OESTE'
								, '7990 - DIGGIT SAN MIGUEL'
								, '7980 - DIGGIT PERU'
								, '7A00 - DIGGIT TUCUMAN'
								, '7A20 - DIGGIT SANTA FE'
								, '7A40 - DIGGIT MERLO'
								, '7C70 - DIGGIT RIO GRANDE'
								, '7940 - DIGGIT USHUAIA'
								)--S2SDSLA-8613
                  group by cast(
                                   concat(
                                       concat(a.order_creation_date, ' ')
                                     , a.order_creation_hour)
                                as timestamp)
                         , month(a.order_creation_date)
                         , year(a.order_creation_date)
                         , b.country
                         , b.subsidiary
                         , b.currency
                         , a.inserted_timestamp
                         , a.updated_timestamp
                         , a.order_code
                         , c.status
                         , a.order_status
                         , a.sku
                         , a.store_name
                         , cast(a.order_creation_hour as time)
           );
           
     create local temporary table  #ods_diggit_ecom_orders_prepare_agg
         as (               
                select country
                     , po_orderid
                     , sum(po_qty)             as po_orderqty
                     , sum(po_price_localcurr) as po_totalprice_local
                  from #ods_diggit_ecom_orders_prepare 
              group by country
                     , po_orderid           
         );
        
     create local temporary table  #ods_diggit_ecom_orders_prepare_sku_agg
         as (               
                select country
                     , po_orderid
                     , po_sku
                     , sum(po_qty)                    as po_orderqty
                     , sum(po_price_localcurr)        as po_totalprice_local
                     , sum(po_itemdiscount_localcurr) as po_itemdiscount_localcurr
                  from #ods_diggit_ecom_orders_prepare  
              group by country
                     , po_orderid   
                     , po_sku        
         );         
   
        update #ods_diggit_ecom_orders_prepare         a
           set a.po_orderqty         = b.po_orderqty
             , a.po_totalprice_local = (c.po_totalprice_local * c.po_orderqty) - c.po_itemdiscount_localcurr
            -- , a.po_price_localcurr  = (c.po_totalprice_local * c.po_orderqty) - c.po_itemdiscount_localcurr
          from #ods_diggit_ecom_orders_prepare         a
          join #ods_diggit_ecom_orders_prepare_agg     b on b.country    = a.country
                                                        and b.po_orderid = a.po_orderid
          join #ods_diggit_ecom_orders_prepare_sku_agg c on c.country    = a.country
                                                        and c.po_orderid = a.po_orderid
                                                        and c.po_sku     = a.po_sku;
                                                                          
        update #ods_diggit_ecom_orders_prepare a
           set po_itemdiscount_usd = a.po_itemdiscount_localcurr / cast(b.exchange_rate as decimal)
             , po_price_usd        = a.po_price_localcurr        / cast(b.exchange_rate as decimal)
             , po_totalprice_usd   = a.po_totalprice_local       / cast(b.exchange_rate as decimal)
          from #ods_diggit_ecom_orders_prepare  a
          join ow_lao.ft_ap2_exchange_rate      b on b.valid_from  = add_days(cast(a.po_date as date), -1)
                                                 and b.to_currency = a.currency; 
                                            
-- Sales Channel                                            
        update #ods_diggit_ecom_orders_prepare a
           set a.channel                = b.global_channel
             , a.biz_type               = b.biz_type
             , a.audience_type          = b.audience_type
             , a.biz_type_ebi_hq        = b.biz_type_ebi
             , a.global_channel_ebi_hq  = b.global_channel_ebi
             , a.po_storename			= b.partner_level 
             , a.customer_type			= b.customer_type
             , a.po_mobile_os			= b.po_mobile_os
          from #ods_diggit_ecom_orders_prepare a
          join ow_md.sales_channel             b on lower(b.country)    = lower(a.country)
                                                and lower(b.identifier) = lower(a.po_store_name)
         where client_subsidiary_id    = 1
           and lower(b.plataform_type) = 'diggit';                                                       
        
-- app samsung             
          update #ods_diggit_ecom_orders_prepare
             set po_devicetype = 'MOBILEAPP'
           where po_sitecode   = 'samsungarapp'
             and client_subsidiary_id = 1;    
         
-- default po_device_type   
          update #ods_diggit_ecom_orders_prepare
             set po_devicetype = 'Web'
           where po_devicetype is null;  
           
-- default for global bi feed
    update #ods_diggit_ecom_orders_prepare
       set global_channel_ebi_hq = '3PD'   
         , biz_type_ebi_hq       = 'B2C'
     where global_channel_ebi_hq is null;     
     
-- default for sales channel
    update #ods_diggit_ecom_orders_prepare
       set channel       = 'eStore'   
         , biz_type      = '3PD'
         , audience_type = '3PD'   
     where channel is null;              
        
     merge into ow_lao.ods_sales_control_tower_table a
          using #ods_diggit_ecom_orders_prepare      b on b.po_orderid  = a.po_orderid
                                                      and b.po_sku      = a.po_sku
                                                      and b.country     = a.country
                                                      and b.po_sku_kit  = a.po_sku_kit
                                                      and b.po_sitecode = a.po_sitecode
           when    matched then update  
                                   set a.po_date                          = b.po_date
                                     , a.podate_month                     = b.po_month
                                     , a.podate_year                      = b.po_year
                                     , a.country                          = b.country
                                     , a.subsidiary                       = b.subsidiary
                                     , a.currency                         = b.currency
                                     , a.po_lastupdate_date_hour          = b.po_lastupdate_date_hour
                                     , a.po_source_last_update_date       = b.po_source_last_update_date
                                     , a.po_orderid                       = b.po_orderid
                                     , a.po_seller_name                   = b.po_seller_name
                                     , a.po_prodname                      = b.po_prodname
                                     , a.po_storename                     = b.po_storename                                      
                                     , a.po_store_name                    = b.po_store_name       
                                     , a.channel                          = b.channel
                                     , a.biz_type                         = b.biz_type
                                     , a.audience_type                    = b.audience_type
                                     , a.po_status                        = b.po_status
                                     , a.po_internal_status               = b.po_internal_status
                                     , a.po_sku                           = b.po_sku
                                     , a.po_qty                           = b.po_qty
                                     , a.po_orderqty                      = b.po_orderqty
                                     , a.po_itemdiscount_localcurr        = b.po_itemdiscount_localcurr
                                     , a.po_itemdiscount_usd              = b.po_itemdiscount_usd
                                     , a.po_price_localcurr               = b.po_price_localcurr
                                     , a.po_price_usd                     = b.po_price_usd
                                     , a.po_plataform_datasource          = b.po_plataform_datasource   
                                     , a.po_source_insert_date            = b.po_source_insert_date
                                     , a.po_totalprice_usd                = b.po_totalprice_usd
                                     , a.po_totalprice_local              = b.po_totalprice_local
                                     , a.po_devicetype                    = b.po_devicetype
                                     , a.po_sku_kit                       = b.po_sku_kit
                                     , a.po_prodname_kit                  = b.po_prodname_kit
                                     , a.is_kit                           = b.is_kit 
                                     , a.country_cd                       = b.country_cd
                                     , a.biz_type_ebi_hq                  = b.biz_type_ebi_hq
                                     , a.global_channel_ebi_hq            = b.global_channel_ebi_hq
                                     , a.installment                      = b.installment
                                     , a.customer_type					  = b.customer_type
                                     , a.po_mobile_os					  = b.po_mobile_os
                                     , a.updated_datetime                 = current_timestamp
           when not matched then insert(
                                           po_date
                                         , podate_month
                                         , podate_year
                                         , country
                                         , subsidiary
                                         , currency
                                         , po_lastupdate_date_hour
                                         , po_source_last_update_date
                                         , po_orderid
                                         , po_seller_name
                                         , po_prodname   
                                         , po_storename                                         
                                         , po_store_name
                                         , channel
                                         , biz_type
                                         , audience_type
                                         , po_status
                                         , po_internal_status
                                         , po_sku
                                         , po_qty
                                         , po_orderqty
                                         , po_itemdiscount_localcurr
                                         , po_itemdiscount_usd
                                         , po_price_localcurr
                                         , po_price_usd
                                         , po_plataform_datasource
                                         , po_source_insert_date
                                         , po_totalprice_usd
                                         , po_totalprice_local
                                         , po_devicetype
                                         , po_sku_kit
                                         , po_prodname_kit
                                         , is_kit
                                         , country_cd
                                         , biz_type_ebi_hq
                                         , global_channel_ebi_hq
                                         , installment
                                         , samsung_care_order
                                         , samsung_care_eligibility
                                         , trade_in_eligibility
                                         , client_subsidiary_id
                                         , po_sitecode
                                         , customer_type
                                         , po_mobile_os
                                 )
                                 values(
                                           b.po_date
                                         , b.po_month
                                         , b.po_year
                                         , b.country
                                         , b.subsidiary
                                         , b.currency
                                         , b.po_lastupdate_date_hour
                                         , b.po_source_last_update_date
                                         , b.po_orderid
                                         , b.po_seller_name
                                         , b.po_prodname  
                                         , b.po_storename                                         
                                         , b.po_store_name
                                         , b.channel
                                         , b.biz_type
                                         , b.audience_type
                                         , b.po_status
                                         , b.po_internal_status
                                         , b.po_sku
                                         , b.po_qty
                                         , b.po_orderqty
                                         , b.po_itemdiscount_localcurr
                                         , b.po_itemdiscount_usd
                                         , b.po_price_localcurr
                                         , b.po_price_usd
                                         , b.po_plataform_datasource
                                         , b.po_source_insert_date
                                         , b.po_totalprice_usd
                                         , b.po_totalprice_local
                                         , b.po_devicetype
                                         , b.po_sku_kit
                                         , b.po_prodname_kit
                                         , b.is_kit
                                         , b.country_cd
                                         , b.biz_type_ebi_hq
                                         , b.global_channel_ebi_hq
                                         , b.installment 
                                         , 0
                                         , 0
                                         , 0
                                         , b.client_subsidiary_id
                                         , b.po_sitecode
                                         , b.customer_type
                                         , b.po_mobile_os
                                 );
    end