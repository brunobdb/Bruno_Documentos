CREATE PROCEDURE OW_LAO.proc_tmp_ecommerce_sales_control_tower_table_bundles_breakdown_globalbi_update_homolog
 LANGUAGE SQLSCRIPT AS
 BEGIN
       update ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown a
          set a.ebi_orderid             = b.po_id
            , a.client_devicetype       = b.device_type
            , a.week                    = b.week
            , a.ebi_po_date             = b.order_date
            , a.ebi_product_category    = b.product_category
            , a.ebi_product_subcategory = b.product_sub_category
            , a.ebi_product_family      = b.product_family
            , a.ebi_product_series      = b.product_series
            , a.ebi_product_name        = b.product_name
            , a.ebi_status              = b.line_item_status
            , a.ebi_payment_method      = b.payment_method_name
            , a.ebi_payment_provider    = b.payment_provider
            , a.ebi_trade_in_eligible   = case lower(b.trade_in_eligible) when lower('true') then 1 else 0 end
            , a.ebi_trade_in_order      = case lower(b.trade_in_order   ) when lower('true') then 1 else 0 end
            , a.ebi_eip_eligible        = case lower(b.eip_eligible     ) when lower('true') then 1 else 0 end
            , a.ebi_eip_order           = case lower(b.eip_order        ) when lower('true') then 1 else 0 end
            , a.ebi_eup_eligible        = case lower(b.eup_eligible     ) when lower('true') then 1 else 0 end
            , a.ebi_eup_order           = case lower(b.eup_order        ) when lower('true') then 1 else 0 end
            , a.ebi_scplus_eligible     = case lower(b.scplus__eligible ) when lower('true') then 1 else 0 end
            , a.ebi_scplus_order        = case lower(b.scplus_order     ) when lower('true') then 1 else 0 end
            , a.ebi_tariff_eligible     = case lower(b.tariff_eligible  ) when lower('true') then 1 else 0 end
            , a.ebi_tariff_order        = case lower(b.tariff_order     ) when lower('true') then 1 else 0 end
            , a.ebi_grossrevenue        = b.transaction_gross_revenue
            , a.ebi_netrevenue          = b.transaction_net_revenue
            , a.ebi_grossorder          = b.gross_orders
            , a.ebi_netorder            = b.net_orders
            , a.ebi_netqty              = b.net_quantity
            , a.ebi_grossqty            = b.gross_quantity
            , a.ebi_cancelamt           = b.cancelled_amount
            , a.ebi_cancelqty           = b.cancelled_quantity
            , a.ebi_returnedamt         = b.returned_amount
            , a.ebi_returned_qty        = b.returned_quantity
            , a.ebi_sku                 = b.sku
            , a.ebi_channel             = b.channel
            , a.ebi_biz_type            = b.biz_type
            , a.ebi_last_update_date    = b.load_date
            , a.updated_datetime        = current_timestamp
         from ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown a
         join ow_lao.ods_global_bi_sales                                       b on b.po_id   = a.po_orderid
							                                                    and b.sku     = a.po_sku
							                                                    and b.country = a.country
        where a.ebi_last_update_date < b.load_date
           or a.ebi_last_update_date is null;
           
    end