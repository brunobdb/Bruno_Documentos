CREATE PROCEDURE ow_lao.proc_ods_sales_control_tower_table_taxes_update
 LANGUAGE SQLSCRIPT AS
 BEGIN
        update ow_lao.ods_sales_control_tower_table       a
           set net_revenue        = a.po_totalprice_usd   - (a.po_totalprice_usd   * b.tax_value)
             , net_revenue_local  = a.po_totalprice_local - (a.po_totalprice_local * b.tax_value)  
          from ow_lao.ods_sales_control_tower_table       a
          join ow_lao.aux_sales_control_tower_table_taxes b on b.subsidiary_id                     = a.client_subsidiary_id
                                                           and b.sku_division                      = a.division
                                                           and b.sku_product_group                 = a.product_group 
                                                           and b.sku_minimun_value_local_currency <= a.po_totalprice_local
                                                           and b.sku_divisions_all                 = false
                                                           and b.sku_product_group_all             = false   
         where  (a.net_revenue_local IS NULL OR a.net_revenue = 0)
           and po_plataform_datasource != 'ow_lao.ods_global_bi_sales';
        update ow_lao.ods_sales_control_tower_table       a
           set net_revenue        = a.po_totalprice_usd   - (a.po_totalprice_usd   * b.tax_value)
             , net_revenue_local  = a.po_totalprice_local - (a.po_totalprice_local * b.tax_value)  
          from ow_lao.ods_sales_control_tower_table       a
          join ow_lao.aux_sales_control_tower_table_taxes b on b.subsidiary_id                     = a.client_subsidiary_id
                                                           and b.sku_division                      = a.division
                                                           and b.sku_product_group                 = a.product_group 
                                                           and b.sku_minimun_value_local_currency <= a.po_totalprice_local
                                                           and b.sku_divisions_all                 = false
                                                           and b.sku_product_group_all             = true  
         where  (a.net_revenue_local IS NULL OR a.net_revenue = 0)
           and po_plataform_datasource != 'ow_lao.ods_global_bi_sales';
         
        update ow_lao.ods_sales_control_tower_table       a
           set net_revenue        = a.po_totalprice_usd   - (a.po_totalprice_usd   * b.tax_value)
             , net_revenue_local  = a.po_totalprice_local - (a.po_totalprice_local * b.tax_value)  
          from ow_lao.ods_sales_control_tower_table       a
          join ow_lao.aux_sales_control_tower_table_taxes b on b.subsidiary_id                     = a.client_subsidiary_id
                                                           and b.sku_division                      = 'Unmaped'
                                                           and b.sku_minimun_value_local_currency <= a.po_totalprice_local
                                                           and b.sku_divisions_all                 = false
         where a.division          is null
           and  (a.net_revenue_local IS NULL OR a.net_revenue = 0)
           and po_plataform_datasource != 'ow_lao.ods_global_bi_sales';
        update ow_lao.ods_sales_control_tower_table       a
           set net_revenue        = a.po_totalprice_usd   - (a.po_totalprice_usd   * b.tax_value)
             , net_revenue_local  = a.po_totalprice_local - (a.po_totalprice_local * b.tax_value)           
          from ow_lao.ods_sales_control_tower_table       a
          join ow_lao.aux_sales_control_tower_table_taxes b on b.subsidiary_id                     = a.client_subsidiary_id
                                                           and b.sku_minimun_value_local_currency <= a.po_totalprice_local
                                                           and b.sku_divisions_all                 = true
         where  (a.net_revenue_local IS NULL OR a.net_revenue = 0)
           and po_plataform_datasource != 'ow_lao.ods_global_bi_sales';
         
         
        update ow_lao.ods_sales_control_tower_table       a
           set net_revenue        = a.po_totalprice_usd
             , net_revenue_local  = a.po_totalprice_local
         where  (a.net_revenue_local IS NULL OR a.net_revenue = 0)
           and po_plataform_datasource != 'ow_lao.ods_global_bi_sales';
     
  end