CREATE PROCEDURE OW_LAO.proc_ods_sales_control_tower_table_dim_product_mapping_lao_update
 LANGUAGE SQLSCRIPT AS
 BEGIN
   
      update ow_lao.ods_sales_control_tower_table a
       set a.product          = c.product
         , a.product_family   = c.product_family
         , a.product_group    = c.product_group
         , a.division         = c.division
         , a.product_category = c.product_category
                                    
                                    
      from ow_lao.ods_sales_control_tower_table a
      join "OW_LAO"."DIM_PRODUCT_MAPPING_LAO"     c on lower(c.item) = lower(a.po_sku)
     where a.division =  'Unmapped';
    
    
          update ow_lao.ods_sales_control_tower_table a
       set 
           a.product          = null
         , a.product_family   = null
         , a.product_group    = null
         , a.division         =  'Unmapped'
         , a.product_category = null
     
     from ow_lao.ods_sales_control_tower_table a
    where a.division is null;
    
    
  END