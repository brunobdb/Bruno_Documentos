CREATE PROCEDURE OW_LAO.PROC_ODS_SALES_CONTROL_TOWER_TABLE_OW_LAO_ODS_HYBRIS_SALES
 --call   OW_LAO.PROC_ODS_SALES_CONTROL_TOWER_TABLE_OW_LAO_ODS_HYBRIS_SALES
LANGUAGE SQLSCRIPT AS 
BEGIN
    
    DROP TABLE ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales;
CREATE COLUMN TABLE ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales
AS (
    SELECT  
    b.country                                                   AS country
    ,a.site                                                     AS po_storename
    ,a.order_code                                               AS po_orderid
    ,d.status                                                   AS po_status
    ,a.order_status                                             AS po_internal_status
    ,CAST (a.order_creation_date AS datetime)                   AS po_date
    ,CAST (a.order_creation_date AS  time)                      AS po_hour
    ,YEAR (a.order_creation_date)                               AS podate_year
    ,MONTH (a.order_creation_date)                              AS podate_month
    , CASE WHEN a.external_service_type = 'INSURANCE' 
      THEN 1
      ELSE 0 
      END                                                       AS samsung_care_order
    , CASE WHEN a.external_service_type = 'INSURANCE' 
      THEN 1
      ELSE 0 
      END                                                       AS samsung_care_eligibility
    , 0                                                         AS trade_up
    , 0                                                         AS trade_up_eligibility
    , CASE WHEN a.external_service_type = 'TRADE_IN'
      THEN 1
      WHEN a.exchange_model  = 'T-TRADEUP_VARIANT'
      THEN 1
      WHEN a.exchange_brand  = 'T-TRADEUP'
      THEN 1
      ELSE 0 
      END                                                       AS trade_in 
    ,a.order_entry_total_price                                  AS po_totalprice
    ,0                                                          AS po_totalprice_usd
    ,a.order_entry_total_tax                                    AS po_totaltax
    ,a.order_currency                                           AS currency
    ,a.product_code                                             AS po_sku
    ,a.product_name                                             AS po_prodname
    ,a.order_entry_total_price                                  AS po_totalprice_local
    ,a.order_entry_unit_price                                   AS po_price_localcurr
    , CAST (
    replace  (a.order_entry_quantity, '.00', '')
    AS int 
    )                                                           AS po_qty
    ,a.voucer_code                                              AS po_coupon
    ,a.payment_mode                                             AS payment_type
    ,a.customer_type                                            AS costumertype
    ,a.sales_order                                              AS po_ordersid
    ,CASE WHEN a.external_service_type = 'INSURANCE' 
      THEN 1
      ELSE 0 
      END                                                       AS samsung_care
    ,a.added_services                                           AS po_added_services
    , CASE WHEN a.external_service_type = 'TRADE_IN'
      THEN 1
      WHEN a.exchange_model  = 'T-TRADEUP_VARIANT'
      THEN 1
      WHEN a.exchange_brand  = 'T-TRADEUP'
      THEN 1
      ELSE 0 
      END                                                       AS trade_in_eligibility 
    ,a.payment_provider                                         AS po_paymentprovider
    ,a.payment_mode_creditcardtype                              AS payment_card_brand
    ,a.payment_date                                             AS po_paymentdate
    ,b.id                                                       AS client_subsidiary_id
    ,b.subsidiary                                               AS subsidiary
    ,a.store_id                                                 AS po_store_id
    ,a.store_name                                               AS po_store_name
    ,a.exchange_brand                                           AS client_trade_in_exchange_brand
    ,0.00                                                       AS trade_in_discount
    ,a.trade_in_discount                                        AS trade_in_discount_details
    ,a.exchange_model                                           AS client_trade_in_exchange_model
    ,a.guid                                                     AS po_costumer_id
    ,a.external_service_type                                    AS po_external_service_type
    ,a.sales_application                                        AS po_devicetype
    ,'ow_lao.ods_hybris_sales'                                  AS po_plataform_datasource
    ,a.inserted_date                                            AS po_source_insert_date
    ,a.updated_datetime                                         AS po_source_last_update_date
    ,current_timestamp                                          AS po_insert_date
    ,CAST (0 AS decimal )                                       AS po_itemdiscount_usd
    ,CAST (0 AS decimal )                                       AS po_price_usd
    ,CAST (NULL AS varchar(255))                                AS channel
    ,CAST (NULL AS varchar(255))                                AS biz_type
    ,CAST (NULL AS varchar(255))                                AS audience_type
    ,0                                                          AS po_orderqty
    ,SUBSTR(Access_Code, INSTR(Access_Code, ',', -1) + 1)       AS access_code
    ,(a.order_entry_unit_price * order_entry_quantity) 
      - a.order_entry_total_price                               as po_itemdiscount_localcurr
    ,CASE WHEN a.external_service_type = 'WARRANTY'            
      THEN 1
      ELSE 0 
      END                                                      as warranty
    ,CASE WHEN a.external_service_type = 'WARRANTY'            
      THEN 1
      ELSE 0 
      END                                                      as warranty_eligibility
    ,a.crp                                                     AS crp
    ,a.SHIPPING_METHOD                                         AS shipping_method
    ,CAST (NULL AS varchar(255))                               AS delivery_mode
    ,CAST (NULL AS varchar(255))                               AS customer_type
    ,CAST (NULL AS varchar(255))                               AS po_mobile_os
    ,CAST (0 AS decimal )                                      AS installment_amount
    ,CAST (0 AS int )                                          AS installment
    , cast(0 as int)                                           as select_ai
    , cast(0 as int)                                           as select_ai_eligibility
    , cast(0 as int)                                           as subscription
    FROM ow_lao.ods_hybris_sales                                      a
    LEFT JOIN u_prj_ecom.dim_subsidiary                               b ON lower(b.country_code) =  lower(a.country_cd)
    LEFT JOIN ow_md.dim_product                                       c ON c.sku                 = a.PRODUCT_CODE 
    LEFT JOIN ow_lao.dim_ods_sales_control_tower_table_status_mapping d ON d.status_origin       = a.order_status
    WHERE 1 = 1
    AND a.order_creation_date >= add_days (current_date,-180)
    AND NOT EXISTS (
    SELECT 1
    FROM ow_lao.ods_sales_control_tower_table aa
    WHERE aa.po_orderid             = a.order_code
    AND   aa.po_sku                 = a.product_code
    AND   aa.country                = b.country
    AND   aa.po_source_last_update_date >= CAST (a.updated_datetime AS seconddate)
    )
    AND NOT EXISTS (
    SELECT 1
    FROM ow_lao.ods_sales_control_tower_table aa
    WHERE aa.po_orderid                  = a.order_code
    AND aa.po_sku                      = a.product_code
    AND aa.country                     = b.country
    AND CAST(a.updated_datetime AS seconddate) is null
    )
    ORDER BY a.order_creation_date DESC 
            ,a.order_code
            
    );
-- timezone adjustment
      UPDATE ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales a
   SET po_date  = add_seconds(
                      to_timestamp(a.po_date)
                     ,(COALESCE(e.timezone,b.timezone,0) * 60) * 60
                     )
    ,po_hour    = cast(
                  ADD_SECONDS(
                  To_timestamp (a.po_date)
                  ,(COALESCE(e.timezone,b.timezone,0) * 60) * 60
                  )
                     AS time
    )
    ,podate_year = year(
                      CAST (
                      add_seconds(
                          to_timestamp (a.po_date)
                         ,(COALESCE(e.timezone,b.timezone,0) * 60) * 60
                        ) AS date
                      )
                     )
    ,podate_month = month(
                    CAST (
                      add_seconds(
                          to_timestamp (a.po_date)
                         ,(COALESCE(e.timezone,b.timezone,0) * 60) * 60
                        ) AS date
                      )
                     )
     FROM  ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales a
     JOIN  u_prj_ecom.dim_subsidiary                                              b ON lower(b.country) = lower (a.country)
LEFT JOIN ow_lao.ods_dim_subsidiary_timezone_exceptions                           e ON e.subsidiary_id =  b.id
AND a.po_date    BETWEEN e.timezone_from AND e.timezone_until
 WHERE b.ORDER_APPLY_TIMEZONE  = 1;
 
DROP TABLE ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales_agg;
 
CREATE COLUMN TABLE ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales_agg
AS (
SELECT country
,po_orderid
,sum(cast(po_qty AS decimal))  AS po_orderqty
FROM ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales
GROUP BY country
,po_orderid
);
-- web device type adjustment
UPDATE ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales      a
SET  a.PO_DEVICETYPE  = 'Web'
WHERE a.PO_DEVICETYPE  NOT IN ('MOBILEAPP', 'WebMobile');
-- orders aggregations
UPDATE ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales      a
 SET a.PO_ORDERQTY  =  b.po_orderqty
 FROM ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales       a
 JOIN ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales_agg   b  ON b.country = a.country
                                                                                      AND b.PO_ORDERID = a.PO_ORDERID ;
--currecncy conversions
 UPDATE ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales    a
SET po_price_usd        =   COALESCE ( a.po_price_localcurr / CAST (b.exchange_rate AS decimal),0)
,   po_totalprice_usd   =   COALESCE ( a.po_totalprice      / CAST (b.exchange_rate AS decimal),0)
,   po_itemdiscount_usd =   COALESCE ( a.po_itemdiscount_localcurr      / CAST (b.exchange_rate AS decimal),0)
FROM    ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales    a
JOIN ow_lao.FT_AP2_EXCHANGE_RATE                                                  b ON b.VALID_FROM  = add_days(CAST (a.po_date AS date), -1)
                                                                                    AND b.TO_CURRENCY = a.CURRENCY ; 
                                                                          
                                                          
--sales channel identification
UPDATE ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales     a 
SET channel    = b.global_channel
,biz_type      = b.biz_type
,audience_type = b.audience_type
  FROM ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales     a
  JOIN ow_lao.dim_affiliate_channel                                               b ON lower(b.SUBSIDIARY) = lower (a.SUBSIDIARY)
                                                                                    AND b.AFFILIATE_ID     = a.PO_STORENAME 
                                                                                    
   WHERE 1 = 0;
  
 UPDATE ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales     a
 SET channel       = b.global_channel
 ,   biz_type      = b.biz_type
 ,   audience_type = b.audience_type
 ,   customer_type = b.customer_type
 ,   po_mobile_os  = b.po_mobile_os
 FROM   ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales      a
 JOIN ow_md.sales_channel                                                           b ON lower(b.COUNTRY)    = lower (a.COUNTRY)
                                                                                       AND lower(b.IDENTIFIER) =  lower (a.PO_STORENAME) 
;
--CRP mapping Storename
UPDATE
    ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales     a
SET
    CRP = 1
FROM
    ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales     a
JOIN u_prj_ecom.dim_subsidiary      b ON lower(b.COUNTRY_CODE) =  lower(a.COUNTRY)
JOIN OW_LAO.DIM_LAO_CRP_CS_STORENAME c ON
     lower(c.STORENAME_CRP) = lower (a.PO_STORE_NAME)
    AND c.SUBSIDIARY = b.SUBSIDIARY
    WHERE a.CRP IS NULL
    ;
    
    UPDATE
    ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales     a
SET
    a.CRP = 0
    WHERE a.crp IS NULL
    
    ;
   
---------DELIVERY_MODE MAPPING --lucas.gil 02/06
   UPDATE 
            ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales      a
        SET   
            a.delivery_mode         = b.delivery_mode
        FROM   
            ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales          a
        JOIN   
            ow_lao.dim_lao_delivery_mode_mapping_control_tower          b ON b.subsidiary       = a.subsidiary 
                                                                        AND  b.shipping_method  = a.shipping_method 
        WHERE  
            b.active = TRUE
            AND a.delivery_mode IS NULL;
---------INSTALLMENT --lucas.gil 14/08
   UPDATE 
    ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales      a
SET   
     a.installment_amount   = CAST (b.installment_amount AS decimal)
    ,a.installment          = CAST (b.installments AS int)
FROM   
    ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales          a
JOIN   
    ow_lao.raw_lao_orders_installment_report_hybris_control_tower b     on    b.order_code    = a.po_orderid
                                                                        and   b.order_status  = a.po_internal_status
                                                                        and   b.site          = a.po_storename  
WHERE  a.installment IS NULL
   and coalesce(b.installments, '') != '';
        
-------------------------------------------------------------------------------------
UPDATE ow_lao.ods_sales_control_tower_table  a
SET 
    a.po_sku_kit = b.reference_code,
    a.is_kit     = true
FROM ow_lao.ods_sales_control_tower_table    a
 JOIN ow_lao.ods_hybris_combo                                               b ON LEFT (a.po_orderid,17) = LEFT (b.order_code,17)
                                                                             AND a.po_sku               = b.product_code
                                                                             AND a.subsidiary           = b.subsidiary
                                                                             
 WHERE po_plataform_datasource  = 'ow_lao.ods_hybris_sales'
 AND CAST (PO_DATE AS DATE) >= '2025-01-01'
;                                                    
--CRP mapping Offers p.anaalinne 25/08 ------------------------------------------
update  ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales  a
set    a.crp = 3
from  ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales        a
join   ow_lao.ods_lao_offers_promotion             b on  left (b.order_code,17) = left (a.po_orderid,17) 
                                                     and  b.product_code        = a.po_sku  
                                                     and  b.subsidiary          = a.subsidiary
where b.campaing_in_hybris_code like 'CRP%'
and   a.crp = 0
;
------------------------------------------------------------------------------------
--Select AI-------------------------------------------------------------------------
 -- Mark Select AI Sales Flag
       
    -- without combo   
    update ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales a
       set select_ai             = 1
         , select_ai_eligibility = 1
      from ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales a
      join ow_lao.manual_mapping_selectai_hybris_sales                            b on b.sku1     = a.po_sku
                                                                                   and b.sub      = a.subsidiary
                                                                                   and b.bizType  = a.biz_type
     where 1 = 1
       and b.is_combo is null
       and a.po_date >= cast(b.ActivationDate as date)
       and b.division in ('MX', 'DA', 'VD');
    -- with combo
       -- Sku 1
    update ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales a
       set select_ai             = 1
         , select_ai_eligibility = 1
      from ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales a
      join ow_lao.manual_mapping_selectai_hybris_sales                            b on b.sku1       = a.po_sku
                                                                                   and b.sub        = a.subsidiary
                                                                                   and b.bizType    = a.biz_type
      join ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales c on c.po_orderid = a.po_orderid 
                                                                                   and c.po_sku     = b.sku2 
                                                                                   and c.subsidiary = b.sub
                                                                                   and c.biz_type   = b.bizType                                                                
     where 1 = 1
       and b.is_combo is not null
       and a.po_date >= cast(b.ActivationDate as date)
       and b.division in ('VD', 'DA'); 
       -- Sku 2       
    update ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales a
       set select_ai             = 1
         , select_ai_eligibility = 1
      from ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales a
      join ow_lao.manual_mapping_selectai_hybris_sales                            b on b.sku2       = a.po_sku
                                                                                   and b.sub        = a.subsidiary
                                                                                   and b.bizType    = a.biz_type
      join ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales c on c.po_orderid = a.po_orderid 
                                                                                   and c.po_sku     = b.sku1
                                                                                   and c.subsidiary = b.sub
                                                                                   and c.biz_type   = b.bizType                                                                
     where 1 = 1
       and b.is_combo is not null
       and a.po_date >= cast(b.ActivationDate as date)
       and b.division in ('VD', 'DA');      
  -- Mark Select AI Elegibility Flag
       
    -- without combo   
    update ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales a
       set select_ai_eligibility = 1
      from ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales a
      join ow_lao.manual_mapping_selectai_hybris_elegibility                      b on b.sku1     = a.po_sku
                                                                                   and b.sub      = a.subsidiary
                                                                                   and b.bizType  = a.biz_type
     where 1 = 1
       and b.is_combo is null
       and a.po_date >= cast(b.ActivationDate as date)
       and b.division in ('MX', 'DA', 'VD');
    -- with combo
       -- Sku 1
    update ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales a
       set select_ai_eligibility = 1
      from ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales a
      join ow_lao.manual_mapping_selectai_hybris_elegibility                      b on b.sku1       = a.po_sku
                                                                                   and b.sub        = a.subsidiary
                                                                                   and b.bizType    = a.biz_type
      join ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales c on c.po_orderid = a.po_orderid 
                                                                                   and c.po_sku     = b.sku2 
                                                                                   and c.subsidiary = b.sub
                                                                                   and c.biz_type   = b.bizType                                                                
     where 1 = 1
       and b.is_combo is not null
       and a.po_date >= cast(b.ActivationDate as date)
       and b.division in ('VD', 'DA');
       -- Sku 2       
    update ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales a
       set select_ai_eligibility = 1
      from ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales a
      join ow_lao.manual_mapping_selectai_hybris_elegibility                      b on b.sku2       = a.po_sku
                                                                                   and b.sub        = a.subsidiary
                                                                                   and b.bizType    = a.biz_type
      join ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales c on c.po_orderid = a.po_orderid 
                                                                                   and c.po_sku     = b.sku1
                                                                                   and c.subsidiary = b.sub
                                                                                   and c.biz_type   = b.bizType                                                                
     where 1 = 1
       and b.is_combo is not null
       and a.po_date >= cast(b.ActivationDate as date)
       and b.division in ('VD', 'DA');
       
  -- Mark Select AI Subscription Flagging
       
    -- without combo   
    update ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales a
       set select_ai_eligibility = 1
         , select_ai             = 1
         , subscription          = 1
      from ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales a
      join ow_lao.manual_mapping_selectai_hybris_subscription                     b on b.sku1     = a.po_sku
                                                                                   and b.sub      = a.subsidiary
                                                                                   and b.bizType  = a.biz_type
     where 1 = 1
       and b.is_combo is null
       and a.po_date >= cast(b.ActivationDate as date)
       and b.division in ('MX', 'DA', 'VD')
       and a.po_plataform_datasource = 'ow_lao.ods_hybris_sales';  
    -- with combo
       -- Sku 1
    update ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales a
       set select_ai_eligibility = 1
         , select_ai             = 1
         , subscription          = 1
      from ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales a
      join ow_lao.manual_mapping_selectai_hybris_subscription                     b on b.sku1       = a.po_sku
                                                                                   and b.sub        = a.subsidiary
                                                                                   and b.bizType    = a.biz_type
      join ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales c on c.po_orderid = a.po_orderid 
                                                                                   and c.po_sku     = b.sku2 
                                                                                   and c.subsidiary = b.sub
                                                                                   and c.biz_type   = b.bizType                                                                
     where 1 = 1
       and b.is_combo is not null
       and a.po_date >= cast(b.ActivationDate as date)
       and b.division in ('VD', 'DA')
       and a.po_plataform_datasource = 'ow_lao.ods_hybris_sales'; 
       -- Sku 2       
    update ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales a
       set select_ai_eligibility = 1
         , select_ai             = 1
         , subscription          = 1
      from ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales a
      join ow_lao.manual_mapping_selectai_hybris_subscription                     b on b.sku2       = a.po_sku
                                                                                   and b.sub        = a.subsidiary
                                                                                   and b.bizType    = a.biz_type
      join ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales c on c.po_orderid = a.po_orderid 
                                                                                   and c.po_sku     = b.sku1
                                                                                   and c.subsidiary = b.sub
                                                                                   and c.biz_type   = b.bizType                                                                
     where 1 = 1
       and b.is_combo is not null
       and a.po_date >= cast(b.ActivationDate as date)
       and b.division in ('VD', 'DA')
       and a.po_plataform_datasource = 'ow_lao.ods_hybris_sales';       
--Select AI end----------------------------------------------------------------------
                                                    
MERGE INTO ow_lao.ods_sales_control_tower_table                               a
 USING     ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_sales  b ON b.po_orderid = a.PO_ORDERID 
                                                                                     AND b.po_sku    = a.PO_SKU 
                                                                                     AND b.country   = a.COUNTRY
 
WHEN   MATCHED THEN UPDATE
                   SET   a.po_date                         = b.po_date
                        ,a.po_hour                         = b.po_hour
                        ,a.podate_year                     = b.podate_year
                        ,a.podate_month                    = b.podate_month
                        ,a.po_storename                    = b.po_storename
                        ,a.po_status                       = b.po_status
                        ,a.po_internal_status              = b.po_internal_status
                        ,a.po_totalprice                   = b.po_totalprice
                        ,a.po_totalprice_usd               = b.po_totalprice_usd
                        ,a.po_totaltax                     = b.po_totaltax
                        ,a.currency                        = b.currency
                        ,a.po_prodname                     = b.po_prodname                 
                        ,a.po_totalprice_local             = b.po_totalprice_local
                        ,a.po_price_localcurr              = b.po_price_localcurr
                        ,a.po_qty                          = b.po_qty
                        ,a.po_coupon                       = b.po_coupon
                        ,a.payment_type                    = b.payment_type
                        ,a.costumertype                    = b.costumertype
                        ,a.po_ordersid                     = b.po_ordersid
                        ,a.samsung_care                    = b.samsung_care
                        ,a.trade_in_eligibility            = b.trade_in_eligibility
                        ,a.po_paymentprovider              = b.po_paymentprovider
                        ,a.payment_card_brand              = b.payment_card_brand 
                        ,a.po_paymentdate                  = b.po_paymentdate
                        ,a.client_subsidiary_id            = b.client_subsidiary_id
                        ,a.subsidiary                      = b.subsidiary
                        ,a.po_store_id                     = b.po_store_id
                        ,a.po_store_name                   = b.po_store_name
                        ,a.client_trade_in_exchange_brand  = b.client_trade_in_exchange_brand
                        ,a.trade_in_discount               = b.trade_in_discount
                        ,a.client_trade_in_exchange_model  = b.client_trade_in_exchange_model
                        ,a.po_costumer_id                  = b.po_costumer_id
                        ,a.trade_in                        = b.trade_in
                        ,a.po_devicetype                   = b.po_devicetype
                        ,a.po_plataform_datasource         = b.po_plataform_datasource
                        ,a.po_source_insert_date           = b.po_source_insert_date
                        ,a.po_source_last_update_date      = b.po_source_last_update_date
                        ,a.po_insert_date                  = b.po_insert_date 
                        ,a.po_itemdiscount_usd             = b.po_itemdiscount_usd
                        ,a.po_price_usd                    = b.po_price_usd
                        ,a.channel                         = b.channel
                        ,a.biz_type                        = b.biz_type
                        ,a.audience_type                   = b.audience_type  
                        ,a.samsung_care_order              = b.samsung_care_order
                        ,a.samsung_care_eligibility        = b.samsung_care_eligibility
                        ,a.po_orderqty                     = b.po_orderqty 
                        ,a.po_added_services               = b.po_added_services
                        ,a.po_external_service_type        = b.po_external_service_type
                        ,a.trade_in_discount_details       = b.trade_in_discount_details
                        ,a.access_code                     = b.access_code
                        ,a.updated_datetime                = current_timestamp
                        ,a.warranty                        = b.warranty
                        ,a.warranty_eligibility            = b.warranty_eligibility
                        ,a.crp                             = b.crp
                        ,a.shipping_method                 = b.shipping_method
                        ,a.delivery_mode                   = b.delivery_mode
                        ,a.customer_type                   = b.customer_type
                        ,a.po_mobile_os                    = b.po_mobile_os
                        ,a.installment_amount              = b.installment_amount
                        ,a.installment                     = b.installment
                        ,a.select_ai                       = b.select_ai
                        ,a.select_ai_eligibility           = b.select_ai_eligibility
                        ,a.subscription                    = b.subscription
                        
    WHEN NOT MATCHED THEN INSERT (
                                 country
                                ,po_storename
                                ,po_orderid
                                ,po_status
                                ,po_internal_status
                                ,po_date
                                ,po_hour
                                ,po_totalprice
                                ,po_totalprice_usd
                                ,po_totaltax
                                ,currency
                                ,po_sku
                                ,po_prodname
                                ,po_totalprice_local
                                ,po_price_localcurr
                                ,po_qty
                                ,po_coupon
                                ,payment_type
                                ,costumertype
                                ,po_ordersid
                                ,samsung_care
                                ,trade_in_eligibility
                                ,po_paymentprovider
                                ,payment_card_brand
                                ,po_paymentdate
                                ,client_subsidiary_id
                                ,subsidiary
                                ,po_store_id
                                ,po_store_name
                                ,client_trade_in_exchange_brand
                                ,trade_in_discount
                                ,client_trade_in_exchange_model
                                ,po_costumer_id
                                ,trade_in
                                ,po_devicetype
                                ,po_plataform_datasource
                                ,po_source_insert_date
                                ,po_source_last_update_date
                                ,po_insert_date
                                ,po_itemdiscount_usd              
                                ,po_price_usd                    
                                ,channel                         
                                ,biz_type                        
                                ,audience_type                    
                                ,samsung_care_order               
                                ,samsung_care_eligibility        
                                ,po_orderqty                      
                                ,po_added_services            
                                ,po_external_service_type       
                                ,trade_in_discount_details        
                                ,podate_year
                                ,podate_month
                                ,access_code 
                                ,po_itemdiscount_localcurr
                                ,warranty 
                                ,warranty_eligibility
                                ,crp
                                ,shipping_method
                                ,delivery_mode
                                ,customer_type
                                ,po_mobile_os
                                ,installment_amount
                                ,installment
                                ,select_ai
                                ,select_ai_eligibility
                                ,subscription
                                )
VALUES (
                                 b.country
                                ,b.po_storename
                                ,b.po_orderid
                                ,b.po_status
                                ,b.po_internal_status
                                ,b.po_date
                                ,b.po_hour
                                ,b.po_totalprice
                                ,b.po_totalprice_usd
                                ,b.po_totaltax
                                ,b.currency
                                ,b.po_sku
                                ,b.po_prodname
                                ,b.po_totalprice_local
                                ,b.po_price_localcurr
                                ,b.po_qty
                                ,b.po_coupon
                                ,b.payment_type
                                ,b.costumertype
                                ,b.po_ordersid
                                ,b.samsung_care
                                ,b.trade_in_eligibility
                                ,b.po_paymentprovider
                                ,b.payment_card_brand
                                ,b.po_paymentdate
                                ,b.client_subsidiary_id
                                ,b.subsidiary
                                ,b.po_store_id
                                ,b.po_store_name
                                ,b.client_trade_in_exchange_brand
                                ,b.trade_in_discount
                                ,b.client_trade_in_exchange_model
                                ,b.po_costumer_id
                                ,b.trade_in
                                ,b.po_devicetype
                                ,b.po_plataform_datasource
                                ,b.po_source_insert_date
                                ,b.po_source_last_update_date
                                ,b.po_insert_date
                                ,b.po_itemdiscount_usd              
                                ,b.po_price_usd                    
                                ,b.channel                         
                                ,b.biz_type                        
                                ,b.audience_type                    
                                ,b.samsung_care_order               
                                ,b.samsung_care_eligibility        
                                ,b.po_orderqty                      
                                ,b.po_added_services            
                                ,b.po_external_service_type       
                                ,b.trade_in_discount_details        
                                ,b.podate_year
                                ,b.podate_month
                                ,b.access_code 
                                ,b.po_itemdiscount_localcurr
                                ,b.warranty 
                                ,b.warranty_eligibility
                                ,b.crp
                                ,b.shipping_method
                                ,b.delivery_mode
                                ,b.customer_type
                                ,b.po_mobile_os
                                ,b.installment_amount
                                ,b.installment
                                ,b.select_ai
                                ,b.select_ai_eligibility
                                ,b.subscription
                                );
                               
                               END