CREATE PROCEDURE OW_LAO.PROC_PAYMENT_FUNNEL_GATEWAY_STATUS_MAP() 
LANGUAGE SQLSCRIPT AS
BEGIN
	/*-------------------------------------------------------------------------------------------------*/
	--		
	MERGE INTO 
	 	OW_LAO.DIM_PAYMENT_PAY_GATEWAY_MAPPING		AS A
	USING 
		OW_LAO.TMP_PAYMENT_PAY_GATEWAY 	AS B 
	ON 
		A.PAY_GATEWAY			= B.PAY_GATEWAY
		AND A.DATA_SOURCE		= B.DATA_SOURCE
	WHEN MATCHED AND A.GATEWAY <> B.GATEWAY OR (A.ACTIVE = FALSE OR A.ACTIVE IS NULL) THEN UPDATE SET 
		A.GATEWAY				= B.GATEWAY,
		A.UPDATED_TIMESTAMP		= CURRENT_TIMESTAMP,
		A.ACTIVE 				= TRUE,
		A.REPROCESSING			= TRUE
	WHEN NOT MATCHED THEN INSERT(
		DATA_SOURCE,
		PAY_GATEWAY,
	 	GATEWAY,
	 	ACTIVE,
	 	REPROCESSING
	 )
	 VALUES (
	 	B.DATA_SOURCE,
	 	B.PAY_GATEWAY,
	 	B.GATEWAY,
	 	TRUE,
	 	TRUE
	);
	/*-------------------------------------------------------------------------------------------------*/
	--Realiza update para desativar os mapeamentos excluídos
	UPDATE
		OW_LAO.DIM_PAYMENT_PAY_GATEWAY_MAPPING A	
	SET
		ACTIVE 				= FALSE,
		REPROCESSING 		= TRUE,
		UPDATED_TIMESTAMP 	= CURRENT_TIMESTAMP
	FROM
		OW_LAO.DIM_PAYMENT_PAY_GATEWAY_MAPPING A
	WHERE
		NOT EXISTS(
			SELECT 
				1
			FROM
				OW_LAO.TMP_PAYMENT_PAY_GATEWAY B
			WHERE 
				A.DATA_SOURCE			= B.DATA_SOURCE
				AND A.PAY_GATEWAY 		= B.PAY_GATEWAY
				AND A.GATEWAY			= B.GATEWAY
		)
	AND ACTIVE = TRUE;
	/*-------------------------------------------------------------------------------------------------*/
--	Atualização do mapeamento para null na tabela ODS, onde o mapeamento foi excluído 
	UPDATE   
		OW_LAO.ODS_PAYMENT_FUNNEL 				A
	SET   
		 A.PAY_GATEWAY_STATUS 	= NULL,
		 A.UPDATED_TIMESTAMP 	= CURRENT_TIMESTAMP 
	FROM   
		OW_LAO.ODS_PAYMENT_FUNNEL 				A
	JOIN   
		OW_LAO.DIM_PAYMENT_PAY_GATEWAY_MAPPING      	B 
	ON 
		B.DATA_SOURCE 		= A.PO_PLATAFORM_DATASOURCE 
		AND B.PAY_GATEWAY 	= A.PAY_GATEWAY
	WHERE  
		ACTIVE = FALSE
		AND REPROCESSING = TRUE; 	
	/*-------------------------------------------------------------------------------------------------*/	
	--Atualização na tabela ods, somente onde ocorreu modificações das chaves do mapeamento
	UPDATE   
		OW_LAO.ODS_PAYMENT_FUNNEL 						A
	SET   
		A.PAY_GATEWAY_STATUS 	= B.GATEWAY,
		A.UPDATED_TIMESTAMP 	= CURRENT_TIMESTAMP 
	FROM   
		OW_LAO.ODS_PAYMENT_FUNNEL						A
	JOIN   
		OW_LAO.DIM_PAYMENT_PAY_GATEWAY_MAPPING      	B 
		ON B.DATA_SOURCE = A.PO_PLATAFORM_DATASOURCE AND B.PAY_GATEWAY = A.PAY_GATEWAY
	WHERE  
		ACTIVE = TRUE
		AND REPROCESSING = TRUE; 	
	/*-------------------------------------------------------------------------------------------------*/			
	--Marca status de reprocessamento para FALSE depois de realizar as atualizações
	UPDATE   
		OW_LAO.DIM_PAYMENT_PAY_GATEWAY_MAPPING     
	SET 
		REPROCESSING = FALSE
	WHERE 
		REPROCESSING = TRUE;
END;