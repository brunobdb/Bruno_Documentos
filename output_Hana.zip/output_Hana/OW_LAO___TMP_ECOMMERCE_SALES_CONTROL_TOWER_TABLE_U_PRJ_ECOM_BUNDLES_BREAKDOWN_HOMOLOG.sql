CREATE PROCEDURE OW_LAO.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown_homolog
 LANGUAGE SQLSCRIPT AS
 BEGIN
-- Prepare      
      drop table ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_delete_bundles;
              
          truncate table ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown;      
          truncate table ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown;
            
            insert into ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown
                
                    select *
                         , cast(null as varchar(1000))  as po_sku_kit
                         , cast(null as varchar(1000))  as po_prodname_kit
                         , cast(null as decimal)        as po_price_localcurr_kit
                         , cast(null as decimal)        as po_itemdiscount_localcurr_kit
                         , false                        as is_kit
                      from ow_lao.ods_sales_control_tower_table a
                     where 1 = 1
                       and a.po_plataform_datasource = 'u_prj_ecom_synapcom.ft_ecom_order'
                       and ( --po_date >= '2024-04-04' and po_hour >= '10:00'
                               -- or 
                                a.po_orderid in ('1418473273251-01', 'MZN-702-3443108-5201832', 'SSG-1278971039783-01')
                       );
            
            create column table ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_delete_bundles
                as (    
                    select a.id 
                      from ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown a
                      join u_prj_ecom.dim_subsidiary                                        b on b.country           = a.country
                      join u_prj_ecom_synapcom.ft_ecom_order                                c on c.external_order_id = a.po_orderid
                                                                                             and c.subsidiary_id     = b.id
                      join u_prj_ecom_synapcom.ft_ecom_order_item                           d on d.order_id          = c.id
                                                                                             and d.reference_code    = a.po_sku
                     where 1 = 1
                       and a.po_plataform_datasource = 'u_prj_ecom_synapcom.ft_ecom_order'
                       and a.client_subsidiary_id    = 6
                       and exists(
                                select 1
                                  from u_prj_ecom_synapcom.ft_ecom_order_kit_component aa
                                 where aa.item_id = d.id
                           )
               );   
               
               
            delete
              from ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown a
             where id in (select id from ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_delete_bundles);
        
        
-- Ecommerce Sales
        
               insert into ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown       
        
                    select cast(a.creation_date as date)        as po_date
                         , year(a.creation_date)                as podate_year
                         , month(a.creation_date)               as podate_month
                         , e.country                            as country
                         , 0                                    as samsung_care_order
                         , coalesce(b.is_samsung_care, 0)       as samsung_care
                         , 0                                    as samsung_care_eligibility
                         , coalesce(a.is_trade_in, 0)           as trade_in
                         , 0                                    as trade_in_eligibility
                         , 0                                    as trade_up
                         , 0                                    as trade_up_eligibility
                         , a.affiliate_id                       as costumer_code_id_name
                         , a.external_order_id                  as po_orderid
                         , a.seller_order_id                    as seller_po_orderid
                         , cast(null as varchar(3000))          as payment_card_brand
                         , cast(null as varchar(3000))          as payment_type
                         , 0                                    as installment
                         , null                                 as installment_eligibility
                         , a.cancellation_reason                as po_cancelation_reason
                         , f.product_group_1                    as po_productgroup
                         , a.cod_sales_channel                  as po_code_sales_channel
                         , a.customer_id                        as po_costumer_id
                         , f.division                           as po_division
                         , a.hostname                           as po_sitecode
                         , a.status                             as po_internal_status
                         , a.invoice_number                     as po_invoicenumber
                         , a.mkt_campaign_tags                  as po_campain_tags
                         , a.mkt_utm_campaign                   as po_campain
                         , a.mkt_utm_coupon                     as po_coupon
                         , a.mkt_utm_medium                     as po_medium
                         , a.mkt_utm_src                        as po_src
                         , a.mkt_utmi_campaign                  as po_utmi_campaing
                         , a.order_sequence                     as po_sequence_orderid
                         , c.product_name                       as po_prodname
                         , coalesce(
                                c.reference_code
                              , c.product_name
                           )                                    as po_sku
                         , a.seller_id                          as po_seller_id
                         , a.seller_name                        as po_seller_name
                         , g.status                             as po_status
                         , a.subsidiary_id                      as client_subsidiary_id
                         , e.subsidiary                         as subsidiary
                         , e.currency                           as currency
                         , a.trade_policy                       as po_tradepolicy
                         , a.vendor                             as po_vendortype       
                         , null                                 as channel
                         , null                                 as biz_type
                         , null                                 as audience_type
                         , null                                 as po_storename
                         , a.acquirer_message                   as client_acquirer_message
                         , a.last_update_date                   as po_lastupdate_date_hour
                         , 0                                    as po_orderqty
                         , sum(c.quantity)                      as po_qty
                         , round(b.discount 
                            * round(abs(c.discount) 
                                / (sum(abs(c.discount))
                                    over(partition by a.external_order_id
                                                    , b.reference_code
                                     ) 
                                   )
                               ,2)
                           ,2)                                  as po_itemdiscount_localcurr
                         , 0                                    as po_itemdiscount_usd
                         , c.price                              as po_price_localcurr
                         , 0                                    as po_price_usd
                         , 'u_prj_ecom_synapcom.ft_ecom_order'  as po_plataform_datasource   
                         , a.insert_date                        as po_source_insert_date
                         , a.last_update_date                   as po_source_last_update_date
                         , current_timestamp                    as po_insert_date
                         , null                                 as po_last_update_date
                         , f.product                            as product_group_gscm
                         , f.scm_type                           as product_scmtype
                         , f.product_1                          as product_gscm
                         , f.attb01                             as product_att1_gscm
                         , cast(null as varchar(3000))          as po_payment_remark
                         , cast(a.creation_date as time)        as po_hour 
                         , 0                                    as po_totalprice_usd
                         , 0                                    as po_totalprice_local
                         , 2                                    as po_plataform_datasource_type_id
                         , a.id                                 as po_plataform_datasource_order_id
                         , null                                 as po_devicetype
                         , coalesce(
                                b.reference_code
                              , b.product_name
                           )                                    as po_sku_kit
                         , b.product_name                       as po_prodname_kit
                         , b.price                              as po_price_localcurr_kit
                         , b.discount                           as po_itemdiscount_localcurr_kit
                         , true                                 as is_kit
                      from u_prj_ecom_synapcom.ft_ecom_order                       a
                      join u_prj_ecom_synapcom.ft_ecom_order_item                  b on b.order_id      = a.id
                      join u_prj_ecom_synapcom.ft_ecom_order_kit_component         c on c.item_id       = b.id
                 left join u_prj_ecom_synapcom.dim_customer                        d on d.id            = a.customer_id
                      join u_prj_ecom.dim_subsidiary                               e on e.id            = a.subsidiary_id
                 left join ow_md.dim_product                                       f on f.sku           = b.reference_code
                 left join ow_lao.dim_ods_sales_control_tower_table_status_mapping g on g.status_origin = a.status
                     where 1 = 1
                       and a.external_order_id in ('1418473273251-01', 'MZN-702-3443108-5201832', 'SSG-1278971039783-01')
                       and abs(b.discount) > 0.00
                       and abs(c.discount) > 0.00
                       /*and not exists(
                        select 1
                          from ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown aa
                         where aa.po_orderid = a.external_order_id
                           and aa.po_sku     = c.reference_code
                   )*/
                  group by a.creation_date
                         , e.country                            
                         , coalesce(b.is_samsung_care, 0)
                         , coalesce(a.is_trade_in, 0)
                         , a.affiliate_id                       
                         , a.external_order_id                  
                         , a.seller_order_id                    
                         , a.cancellation_reason                
                         , f.product_group_1                    
                         , a.cod_sales_channel                  
                         , a.customer_id                        
                         , f.division                           
                         , a.hostname                           
                         , a.status                    
                         , a.invoice_number                     
                         , a.mkt_campaign_tags                  
                         , a.mkt_utm_campaign                   
                         , a.mkt_utm_coupon                     
                         , a.mkt_utm_medium                     
                         , a.mkt_utm_src                        
                         , a.mkt_utmi_campaign                  
                         , a.order_sequence                     
                         , c.product_name                      
                         , b.product_name   
                         , b.discount                   
                         , c.reference_code                        
                         , b.reference_code                    
                         , a.seller_id                          
                         , a.seller_name                        
                         , g.status                             
                         , a.subsidiary_id                      
                         , e.subsidiary                         
                         , e.currency                           
                         , a.trade_policy                       
                         , a.vendor                             
                         , a.acquirer_message                   
                         , a.last_update_date                   
                         , a.insert_date                        
                         , a.last_update_date                   
                         , f.product                            
                         , f.scm_type                           
                         , f.product_1                          
                         , f.attb01                             
                         , a.id      
                         , c.discount
                         , c.price    
                         , b.discount
                         , b.price         
                     
                     union all            
                     
                    select cast(a.creation_date as date)        as po_date
                         , year(a.creation_date)                as podate_year
                         , month(a.creation_date)               as podate_month
                         , e.country                            as country
                         , 0                                    as samsung_care_order
                         , coalesce(b.is_samsung_care, 0)       as samsung_care
                         , 0                                    as samsung_care_eligibility
                         , coalesce(a.is_trade_in, 0)           as trade_in
                         , 0                                    as trade_in_eligibility
                         , 0                                    as trade_up
                         , 0                                    as trade_up_eligibility
                         , a.affiliate_id                       as costumer_code_id_name
                         , a.external_order_id                  as po_orderid
                         , a.seller_order_id                    as seller_po_orderid
                         , cast(null as varchar(3000))          as payment_card_brand
                         , cast(null as varchar(3000))          as payment_type
                         , 0                                    as installment
                         , null                                 as installment_eligibility
                         , a.cancellation_reason                as po_cancelation_reason
                         , f.product_group_1                    as po_productgroup
                         , a.cod_sales_channel                  as po_code_sales_channel
                         , a.customer_id                        as po_costumer_id
                         , f.division                           as po_division
                         , a.hostname                           as po_sitecode
                         , a.status                             as po_internal_status
                         , a.invoice_number                     as po_invoicenumber
                         , a.mkt_campaign_tags                  as po_campain_tags
                         , a.mkt_utm_campaign                   as po_campain
                         , a.mkt_utm_coupon                     as po_coupon
                         , a.mkt_utm_medium                     as po_medium
                         , a.mkt_utm_src                        as po_src
                         , a.mkt_utmi_campaign                  as po_utmi_campaing
                         , a.order_sequence                     as po_sequence_orderid
                         , c.product_name                       as po_prodname
                         , coalesce(
                                c.reference_code
                              , c.product_name
                           )                                    as po_sku
                         , a.seller_id                          as po_seller_id
                         , a.seller_name                        as po_seller_name
                         , g.status                             as po_status
                         , a.subsidiary_id                      as client_subsidiary_id
                         , e.subsidiary                         as subsidiary
                         , e.currency                           as currency
                         , a.trade_policy                       as po_tradepolicy
                         , a.vendor                             as po_vendortype       
                         , null                                 as channel
                         , null                                 as biz_type
                         , null                                 as audience_type
                         , null                                 as po_storename
                         , a.acquirer_message                   as client_acquirer_message
                         , a.last_update_date                   as po_lastupdate_date_hour
                         , 0                                    as po_orderqty
                         , sum(c.quantity)                      as po_qty
                         , round(b.discount 
                            / count(1)
                                over(partition by a.external_order_id
                                                , b.reference_code
                                ) 
                           ,2)                                  as po_itemdiscount_localcurr
                         , 0                                    as po_itemdiscount_usd
                         , c.price                              as po_price_localcurr
                         , 0                                    as po_price_usd
                         , 'u_prj_ecom_synapcom.ft_ecom_order'  as po_plataform_datasource   
                         , a.insert_date                        as po_source_insert_date
                         , a.last_update_date                   as po_source_last_update_date
                         , current_timestamp                    as po_insert_date
                         , null                                 as po_last_update_date
                         , f.product                            as product_group_gscm
                         , f.scm_type                           as product_scmtype
                         , f.product_1                          as product_gscm
                         , f.attb01                             as product_att1_gscm
                         , cast(null as varchar(3000))          as po_payment_remark
                         , cast(a.creation_date as time)        as po_hour 
                         , 0                                    as po_totalprice_usd
                         , 0                                    as po_totalprice_local
                         , 2                                    as po_plataform_datasource_type_id
                         , a.id                                 as po_plataform_datasource_order_id
                         , null                                 as po_devicetype
                         , coalesce(
                                b.reference_code
                              , b.product_name
                           )                                    as po_sku_kit
                         , b.product_name                       as po_prodname_kit
                         , b.price                              as po_price_localcurr_kit
                         , b.discount                           as po_itemdiscount_localcurr_kit
                         , true                                 as is_kit
                      from u_prj_ecom_synapcom.ft_ecom_order                       a
                      join u_prj_ecom_synapcom.ft_ecom_order_item                  b on b.order_id      = a.id
                      join u_prj_ecom_synapcom.ft_ecom_order_kit_component         c on c.item_id       = b.id
                 left join u_prj_ecom_synapcom.dim_customer                        d on d.id            = a.customer_id
                      join u_prj_ecom.dim_subsidiary                               e on e.id            = a.subsidiary_id
                 left join ow_md.dim_product                                       f on f.sku           = b.reference_code
                 left join ow_lao.dim_ods_sales_control_tower_table_status_mapping g on g.status_origin = a.status
                     where 1 = 1
                       and a.external_order_id in ('1418473273251-01', 'MZN-702-3443108-5201832', 'SSG-1278971039783-01')
                       and abs(b.discount) > 0.00
                       and abs(c.discount) = 0.00
                       /*and not exists(
                        select 1
                          from ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown aa
                         where aa.po_orderid = a.external_order_id
                           and aa.po_sku     = c.reference_code
                   )*/
                  group by a.creation_date
                         , e.country                            
                         , coalesce(b.is_samsung_care, 0)
                         , coalesce(a.is_trade_in, 0)
                         , a.affiliate_id                       
                         , a.external_order_id                  
                         , a.seller_order_id                    
                         , a.cancellation_reason                
                         , f.product_group_1                    
                         , a.cod_sales_channel                  
                         , a.customer_id                        
                         , f.division                           
                         , a.hostname                           
                         , a.status                    
                         , a.invoice_number                     
                         , a.mkt_campaign_tags                  
                         , a.mkt_utm_campaign                   
                         , a.mkt_utm_coupon                     
                         , a.mkt_utm_medium                     
                         , a.mkt_utm_src                        
                         , a.mkt_utmi_campaign                  
                         , a.order_sequence                     
                         , c.product_name                      
                         , b.product_name   
                         , b.discount                   
                         , c.reference_code                        
                         , b.reference_code                    
                         , a.seller_id                          
                         , a.seller_name                        
                         , g.status                             
                         , a.subsidiary_id                      
                         , e.subsidiary                         
                         , e.currency                           
                         , a.trade_policy                       
                         , a.vendor                             
                         , a.acquirer_message                   
                         , a.last_update_date                   
                         , a.insert_date                        
                         , a.last_update_date                   
                         , f.product                            
                         , f.scm_type                           
                         , f.product_1                          
                         , f.attb01                             
                         , a.id      
                         , c.discount 
                         , c.price
                         , b.discount
                         , b.price            
                     
                     union all       
               
                    select cast(a.creation_date as date)        as po_date
                         , year(a.creation_date)                as podate_year
                         , month(a.creation_date)               as podate_month
                         , e.country                            as country
                         , 0                                    as samsung_care_order
                         , coalesce(b.is_samsung_care, 0)       as samsung_care
                         , 0                                    as samsung_care_eligibility
                         , coalesce(a.is_trade_in, 0)           as trade_in
                         , 0                                    as trade_in_eligibility
                         , 0                                    as trade_up
                         , 0                                    as trade_up_eligibility
                         , a.affiliate_id                       as costumer_code_id_name
                         , a.external_order_id                  as po_orderid
                         , a.seller_order_id                    as seller_po_orderid
                         , cast(null as varchar(3000))          as payment_card_brand
                         , cast(null as varchar(3000))          as payment_type
                         , 0                                    as installment
                         , null                                 as installment_eligibility
                         , a.cancellation_reason                as po_cancelation_reason
                         , f.product_group_1                    as po_productgroup
                         , a.cod_sales_channel                  as po_code_sales_channel
                         , a.customer_id                        as po_costumer_id
                         , f.division                           as po_division
                         , a.hostname                           as po_sitecode
                         , a.status                             as po_internal_status
                         , a.invoice_number                     as po_invoicenumber
                         , a.mkt_campaign_tags                  as po_campain_tags
                         , a.mkt_utm_campaign                   as po_campain
                         , a.mkt_utm_coupon                     as po_coupon
                         , a.mkt_utm_medium                     as po_medium
                         , a.mkt_utm_src                        as po_src
                         , a.mkt_utmi_campaign                  as po_utmi_campaing
                         , a.order_sequence                     as po_sequence_orderid
                         , c.product_name                       as po_prodname
                         , coalesce(
                                c.reference_code
                              , c.product_name
                           )                                    as po_sku
                         , a.seller_id                          as po_seller_id
                         , a.seller_name                        as po_seller_name
                         , g.status                             as po_status
                         , a.subsidiary_id                      as client_subsidiary_id
                         , e.subsidiary                         as subsidiary
                         , e.currency                           as currency
                         , a.trade_policy                       as po_tradepolicy
                         , a.vendor                             as po_vendortype       
                         , null                                 as channel
                         , null                                 as biz_type
                         , null                                 as audience_type
                         , null                                 as po_storename
                         , a.acquirer_message                   as client_acquirer_message
                         , a.last_update_date                   as po_lastupdate_date_hour
                         , 0                                    as po_orderqty
                         , sum(c.quantity)                      as po_qty
                         , c.discount                           as po_itemdiscount_localcurr
                         , 0                                    as po_itemdiscount_usd
                         , c.price                              as po_price_localcurr
                         , 0                                    as po_price_usd
                         , 'u_prj_ecom_synapcom.ft_ecom_order'  as po_plataform_datasource   
                         , a.insert_date                        as po_source_insert_date
                         , a.last_update_date                   as po_source_last_update_date
                         , current_timestamp                    as po_insert_date
                         , null                                 as po_last_update_date
                         , f.product                            as product_group_gscm
                         , f.scm_type                           as product_scmtype
                         , f.product_1                          as product_gscm
                         , f.attb01                             as product_att1_gscm
                         , cast(null as varchar(3000))          as po_payment_remark
                         , cast(a.creation_date as time)        as po_hour 
                         , 0                                    as po_totalprice_usd
                         , 0                                    as po_totalprice_local
                         , 2                                    as po_plataform_datasource_type_id
                         , a.id                                 as po_plataform_datasource_order_id
                         , null                                 as po_devicetype
                         , coalesce(
                                b.reference_code
                              , b.product_name
                           )                                    as po_sku_kit
                         , b.product_name                       as po_prodname_kit
                         , b.price                              as po_price_localcurr_kit
                         , b.discount                           as po_itemdiscount_localcurr_kit
                         , true                                 as is_kit
                      from u_prj_ecom_synapcom.ft_ecom_order                       a
                      join u_prj_ecom_synapcom.ft_ecom_order_item                  b on b.order_id      = a.id
                      join u_prj_ecom_synapcom.ft_ecom_order_kit_component         c on c.item_id       = b.id
                 left join u_prj_ecom_synapcom.dim_customer                        d on d.id            = a.customer_id
                      join u_prj_ecom.dim_subsidiary                               e on e.id            = a.subsidiary_id
                 left join ow_md.dim_product                                       f on f.sku           = b.reference_code
                 left join ow_lao.dim_ods_sales_control_tower_table_status_mapping g on g.status_origin = a.status
                     where 1 = 1
                       and a.external_order_id in ('1418473273251-01', 'MZN-702-3443108-5201832', 'SSG-1278971039783-01')
                       and abs(b.discount) = 0.00
                       and not exists(
                                select 1
                                  from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown aa
                                 where aa.po_orderid = a.external_order_id
                                   and aa.po_sku     = c.reference_code
                           )
                  group by a.creation_date
                         , e.country                            
                         , coalesce(b.is_samsung_care, 0)
                         , coalesce(a.is_trade_in, 0)
                         , a.affiliate_id                       
                         , a.external_order_id                  
                         , a.seller_order_id                    
                         , a.cancellation_reason                
                         , f.product_group_1                    
                         , a.cod_sales_channel                  
                         , a.customer_id                        
                         , f.division                           
                         , a.hostname                           
                         , a.status                    
                         , a.invoice_number                     
                         , a.mkt_campaign_tags                  
                         , a.mkt_utm_campaign                   
                         , a.mkt_utm_coupon                     
                         , a.mkt_utm_medium                     
                         , a.mkt_utm_src                        
                         , a.mkt_utmi_campaign                  
                         , a.order_sequence                     
                         , c.product_name                      
                         , b.product_name   
                         , b.discount                   
                         , c.reference_code                        
                         , b.reference_code                    
                         , a.seller_id                          
                         , a.seller_name                        
                         , g.status                             
                         , a.subsidiary_id                      
                         , e.subsidiary                         
                         , e.currency                           
                         , a.trade_policy                       
                         , a.vendor                             
                         , a.acquirer_message                   
                         , a.last_update_date                   
                         , a.insert_date                        
                         , a.last_update_date                   
                         , f.product                            
                         , f.scm_type                           
                         , f.product_1                          
                         , f.attb01                             
                         , a.id      
                         , c.discount
                         , b.discount
                         , b.price
                         , c.price;
               
         
         -- Payments
               
                     drop table ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown_payments;
            create column table ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown_payments
                as (
                         
                      select a.po_plataform_datasource_order_id
                           , a.po_plataform_datasource_type_id
                           , max(installment)                   as installment
                           , string_agg(a.brand       , '|')    as payment_card_brand
                           , string_agg(a.payment_type, '|')    as payment_type
                           , string_agg(
                                a.payment_type || ':' || 
                                a.brand        || ':' || 
                                a.value        || ':' || 
                                a.installment
                                , '|' 
                           )                                    as po_payment_remark
                        from (   
                                    select distinct
                                           a.po_plataform_datasource_order_id
                                         , a.po_plataform_datasource_type_id
                                         , coalesce(b.brand       , '')   as brand
                                         , coalesce(b.payment_type, '')   as payment_type
                                         , b.value
                                         , b.installment
                                      from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown a  
                                      join u_prj_ecom_synapcom.ft_ecom_order_payment                                   b on b.order_id = a.po_plataform_datasource_order_id
                                     where a.po_plataform_datasource_type_id = 2   
                                     
                                     union all
                                     
                                    select distinct
                                           a.po_plataform_datasource_order_id
                                         , a.po_plataform_datasource_type_id
                                         , coalesce(b.brand       , '')   as brand
                                         , coalesce(b.payment_type, '')   as payment_type
                                         , b.value
                                         , b.installment
                                      from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown a  
                                      join u_prj_ecom.ft_ecom_order_payment                                            b on b.order_id = a.po_plataform_datasource_order_id
                                     where a.po_plataform_datasource_type_id = 1
                         ) a
                    group by a.po_plataform_datasource_order_id
                           , a.po_plataform_datasource_type_id
                );                 
                
                update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown          a
                   set installment        = b.installment
                     , payment_card_brand = b.payment_card_brand
                     , payment_type       = b.payment_type
                     , po_payment_remark  = b.po_payment_remark
                  from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown          a
                  join ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown_payments b on b.po_plataform_datasource_order_id = a.po_plataform_datasource_order_id
                                                                                                             and b.po_plataform_datasource_type_id  = b.po_plataform_datasource_type_id;       
                                                                                                             
-- Pricing
        
                      drop table ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown_agg;
             create column table ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown_agg
                 as (               
                        select country
                             , po_orderid
                             , sum(po_qty)             as po_orderqty
                             , sum(po_price_localcurr) as po_totalprice_local
                          from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown   
                      group by country
                             , po_orderid           
                 );
                 
                      drop table ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown_sku_agg;
             create column table ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown_sku_agg
                 as (               
                        select country
                             , po_orderid
                             , po_sku
                             , sum(po_qty)                    as po_orderqty
                             , sum(po_price_localcurr)        as po_totalprice_local
                             , sum(po_itemdiscount_localcurr) as po_itemdiscount_localcurr
                          from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown   
                      group by country
                             , po_orderid   
                             , po_sku        
                 );         
           
                update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown         a
                   set a.po_orderqty         = b.po_orderqty
                     , a.po_totalprice_local = (c.po_totalprice_local * c.po_orderqty) - c.po_itemdiscount_localcurr
                     , a.po_price_localcurr  = (c.po_totalprice_local * c.po_orderqty) - c.po_itemdiscount_localcurr
                  from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown         a
                  join ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown_agg     b on b.country    = a.country
                                                                                                            and b.po_orderid = a.po_orderid
                  join ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown_sku_agg c on c.country    = a.country
                                                                                                            and c.po_orderid = a.po_orderid
                                                                                                            and c.po_sku     = a.po_sku;                                                                                                      
                                                                                                                              
-- Enables (SC+|TradeIn|TradeUp)
        
                update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown a
                   set trade_in_eligibility     = case b.is_tradein_eligible       when true then 1 else 0 end
                     , samsung_care_eligibility = case b.is_samsung_care_eligible  when true then 1 else 0 end
                  from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown a
                  join u_prj_ecom.ods_ecom_sku_enables                                             b on b.subsidiary_id  = a.client_subsidiary_id
                                                                                                    and b.account        = a.po_sitecode
                                                                                                    and b.reference_code = a.po_sku
                 where a.is_kit = false;
        
                update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown a
                   set trade_in_eligibility     = case b.is_tradein_eligible       when true then 1 else 0 end
                     , samsung_care_eligibility = case b.is_samsung_care_eligible  when true then 1 else 0 end
                  from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown a
                  join u_prj_ecom.ods_ecom_sku_enables                                             b on b.subsidiary_id  = a.client_subsidiary_id
                                                                                                    and b.account        = a.po_sitecode
                                                                                                    and b.reference_code = a.po_sku_kit
                 where a.is_kit = true;
                 
-- Exchange dolar
        
                update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown a
                   set po_itemdiscount_usd = a.po_itemdiscount_localcurr / cast(b.exchange_rate as decimal)
                     , po_price_usd        = a.po_price_localcurr        / cast(b.exchange_rate as decimal)
                     , po_totalprice_usd   = a.po_totalprice_local       / cast(b.exchange_rate as decimal)
                  from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown a
                  join ow_lao.ft_ap2_exchange_rate                                                 b on b.valid_from  = add_days(a.po_date, -1)
                                                                                                    and b.to_currency = a.currency;
                                                                                  
-- Sales channels
        
                update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown a
                   set a.channel       = b.global_channel
                     , a.biz_type      = b.biz_type
                     , a.audience_type = b.audience_type
                     , a.po_storename  = b.partner_level
                  from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown a
                  join ow_md.sales_channel                                                         b on lower(b.country)            = lower(a.country)
                                                                                                    and b.sales_channel             = a.po_code_sales_channel
                                                                                                    and coalesce(b.affiliate_id,'') = a.costumer_code_id_name
                 where client_subsidiary_id in (6)
                   and lower(b.plataform_type) = 'vtex'
                   and coalesce(has_store_id, 'N') = 'N';   
                   
                update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown a
                   set a.channel       = b.global_channel
                     , a.biz_type      = b.biz_type
                     , a.audience_type = b.audience_type
                     , a.po_storename  = b.partner_level
                  from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown a
                  join ow_md.sales_channel                                                         b on lower(b.country)            = lower(a.country)
                                                                                                    and b.sales_channel             = a.po_code_sales_channel
                 where client_subsidiary_id in (6)
                   and lower(b.plataform_type)     = 'vtex'
                   and a.costumer_code_id_name     = 'SAMSUNG'
                   and coalesce(b.affiliate_id,'') = ''
                   and coalesce(has_store_id, 'N') = 'N';             
                   
                update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown a
                   set a.channel       = 'eStore'
                     , a.biz_type      = 'B2C' 
                     , a.audience_type = 'Store+' 
                     , a.po_storename  = 'Store+' 
                  from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown a
                  join "U_PRJ_ECOM"."VIEW_ECOM_ENDLESS_AISLE_REPORT"                               b on b."order_id"    = a.po_orderid
                                                                                                    and b."environment" = a.po_sitecode
                 where client_subsidiary_id in (6);   
                   
                update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown a
                   set a.channel       = b.global_channel
                     , a.biz_type      = b.biz_type
                     , a.audience_type = b.audience_type
                     , a.po_storename  = b.partner_level
                  from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown a
                  join ow_md.sales_channel                                                         b on lower(b.country)          = lower(a.country)
                                                                                                    and b.sales_channel           = a.po_code_sales_channel
                                                                                                    and coalesce(b.identifier,'') = a.costumer_code_id_name
                                                                                                    and b.plataform_account       = a.po_sitecode
                 where client_subsidiary_id in (1)
                   and lower(b.plataform_type)     = 'vtex'
                   and coalesce(has_store_id, 'N') = 'N'
                   and coalesce(b.identifier,'')  != '';                    
                   
                update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown a
                   set a.channel       = b.global_channel
                     , a.biz_type      = b.biz_type
                     , a.audience_type = b.audience_type
                     , a.po_storename  = b.partner_level
                  from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown a
                  join ow_md.sales_channel                                                         b on lower(b.country)     = lower(a.country)
                                                                                                    and b.sales_channel      = a.po_code_sales_channel
                                                                                                    and b.plataform_account  = a.po_sitecode
                 where client_subsidiary_id in (1, 8, 9)
                   and lower(b.plataform_type)     = 'vtex'
                   and coalesce(has_store_id, 'N') = 'N'
                   and coalesce(b.identifier,'')   = '';       
                   
                update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown a
                   set a.channel       = b.global_channel
                     , a.biz_type      = b.biz_type
                     , a.audience_type = b.audience_type
                     , a.po_storename  = b.partner_level
                  from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown a
                  join ow_md.sales_channel                                                         b on lower(b.country)    = lower(a.country)
                                                                                                    and lower(b.identifier) = lower(a.po_sitecode)
                 where client_subsidiary_id in (7, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19)
                   and lower(b.plataform_type) = 'magento';                   
                   
                update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown a
                   set a.channel       = b.channel
                     , a.biz_type      = b.byz_type
                     , a.audience_type = b.audience_type
                     , a.po_storename  = b.storename
                  from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown a
                  join ow_lao.temp_dim_ecom_store_seasa_mkm                                        b on b.id = left(a.po_orderid, 6)
                 where client_subsidiary_id    = 1
                   and a.costumer_code_id_name = 'MKM';   
                   
                update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown a
                   set a.channel       = 'eStore'
                     , a.biz_type      = '3PD'
                     , a.audience_type = '3PD'
                     , a.po_storename  = 'Mercado Libre'
                  from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown a
                 where a.po_plataform_datasource in ('u_prj_ecom_synapcom.ft_ecom_order', 'u_prj_ecom.ft_ecom_order')
                   and client_subsidiary_id    = 1
                   and a.costumer_code_id_name = 'MKM'
                   and a.channel               is null
                   and not exists(
                            select 1
                              from ow_lao.temp_dim_ecom_store_seasa_mkm aa 
                             where aa.id = left(a.po_orderid, 6)
                       );                                                                                   
                       
-- app samsung
        
                  update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown
                     set po_devicetype = 'MOBILEAPP'
                   where po_storename = 'App Mobile Samsung'
                     and client_subsidiary_id = 6;
                     
                  update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown
                     set po_devicetype = 'MOBILEAPP'
                   where po_sitecode = 'samsungarapp'
                     and client_subsidiary_id = 1;                 
                     
-- Timezone
                       
                  update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown a  
                     set a.po_date     = cast(
                                            add_seconds(
                                                to_timestamp(c.creation_date)
                                                , (b.timezone * 60) * 60
                                            )
                                          as date) 
                       , a.po_hour     = cast(
                                            add_seconds(
                                                to_timestamp(c.creation_date)
                                                , (b.timezone * 60) * 60
                                            )
                                          as time)  
                       , a.podate_year = year(cast(
                                                add_seconds(
                                                    to_timestamp(c.creation_date)
                                                    , (b.timezone * 60) * 60
                                                )
                                              as date))   
                       , a.podate_month = month(cast(
                                                add_seconds(
                                                    to_timestamp(c.creation_date)
                                                    , (b.timezone * 60) * 60
                                                )
                                              as date)) 
                    from ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown a
                    join u_prj_ecom.dim_subsidiary                                                   b on b.country           = a.country
                    join u_prj_ecom.ft_ecom_order                                                    c on c.external_order_id = a.po_orderid
                   where b.order_apply_timezone = 1;             
                   
-- default po_device_type   
        
                  update ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown
                     set po_devicetype = 'Web'
                   where po_devicetype is null;   
                   
                   
-- Control tower
                         
             merge into ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown            a
                  using ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown b on b.po_orderid = a.po_orderid
                                                                                                     and b.po_sku     = a.po_sku
                                                                                                     and b.country    = a.country
                                                                                                     and b.po_sku_kit is null
                                                                                                        
                  when    matched then update  
                                           set a.po_date                    = b.po_date
                                             , a.po_hour                    = b.po_hour
                                             , a.podate_year                = b.podate_year
                                             , a.podate_month               = b.podate_month
                                             , a.samsung_care_order         = b.samsung_care_order
                                             , a.samsung_care               = b.samsung_care
                                             , a.samsung_care_eligibility   = b.samsung_care_eligibility
                                             , a.trade_in                   = b.trade_in
                                             , a.trade_in_eligibility       = b.trade_in_eligibility
                                             , a.costumer_code_id_name      = b.costumer_code_id_name
                                             , a.seller_po_orderid          = b.seller_po_orderid
                                             , a.payment_card_brand         = b.payment_card_brand
                                             , a.payment_type               = b.payment_type
                                             , a.installment                = b.installment
                                             , a.installment_eligibility    = b.installment_eligibility
                                             , a.po_cancelation_reason      = b.po_cancelation_reason
                                             , a.po_productgroup            = b.po_productgroup
                                             , a.po_code_sales_channel      = b.po_code_sales_channel
                                             , a.po_costumer_id             = b.po_costumer_id
                                             , a.po_division                = b.po_division
                                             , a.po_sitecode                = b.po_sitecode
                                             , a.po_internal_status         = b.po_internal_status
                                             , a.po_invoicenumber           = b.po_invoicenumber
                                             , a.po_campain_tags            = b.po_campain_tags
                                             , a.po_campain                 = b.po_campain
                                             , a.po_coupon                  = b.po_coupon
                                             , a.po_medium                  = b.po_medium
                                             , a.po_src                     = b.po_src
                                             , a.po_utmi_campaing           = b.po_utmi_campaing
                                             , a.po_prodname                = b.po_prodname
                                             , a.po_seller_id               = b.po_seller_id
                                             , a.po_seller_name             = b.po_seller_name
                                             , a.po_status                  = b.po_status
                                             , a.client_subsidiary_id       = b.client_subsidiary_id
                                             , a.subsidiary                 = b.subsidiary
                                             , a.currency                   = b.currency
                                             , a.po_tradepolicy             = b.po_tradepolicy
                                             , a.po_vendortype              = b.po_vendortype
                                             , a.channel                    = b.channel
                                             , a.biz_type                   = b.biz_type
                                             , a.audience_type              = b.audience_type
                                             , a.po_storename               = b.po_storename
                                             , a.client_acquirer_message    = b.client_acquirer_message
                                             , a.po_lastupdate_date_hour    = b.po_lastupdate_date_hour
                                             , a.po_orderqty                = b.po_orderqty
                                             , a.po_qty                     = b.po_qty
                                             , a.po_itemdiscount_localcurr  = b.po_itemdiscount_localcurr
                                             , a.po_itemdiscount_usd        = b.po_itemdiscount_usd
                                             , a.po_price_localcurr         = b.po_price_localcurr
                                             , a.po_price_usd               = b.po_price_usd
                                             , a.po_plataform_datasource    = b.po_plataform_datasource
                                             , a.po_source_insert_date      = b.po_source_insert_date
                                             , a.po_source_last_update_date = b.po_source_last_update_date
                                             , a.po_insert_date             = b.po_insert_date
                                             , a.po_last_update_date        = b.po_last_update_date
                                             , a.product_group_gscm         = b.product_group_gscm
                                             , a.product_scmtype            = b.product_scmtype
                                             , a.product_gscm               = b.product_gscm
                                             , a.product_att1_gscm          = b.product_att1_gscm
                                             , a.po_payment_remark          = b.po_payment_remark
                                             , a.po_totalprice_usd          = b.po_totalprice_usd
                                             , a.po_totalprice_local        = b.po_totalprice_local
                                             , a.po_devicetype              = b.po_devicetype
                                             , a.updated_datetime           = current_timestamp
                                             , a.po_sku_kit                 = b.po_sku_kit  
                                             , a.po_prodname_kit            = b.po_prodname_kit           
                                             , a.po_price_localcurr_kit     = b.po_price_localcurr_kit  
                                             , a.po_itemdiscount_localcurr_kit = b.po_itemdiscount_localcurr_kit
                                             , a.is_kit                     = b.is_kit
                   when not matched then insert(
                                                   po_date
                                                 , po_hour
                                                 , podate_year
                                                 , podate_month
                                                 , country
                                                 , samsung_care_order
                                                 , samsung_care
                                                 , samsung_care_eligibility
                                                 , trade_in
                                                 , trade_in_eligibility
                                                 , costumer_code_id_name
                                                 , po_orderid
                                                 , seller_po_orderid
                                                 , payment_card_brand
                                                 , payment_type
                                                 , installment
                                                 , installment_eligibility
                                                 , po_cancelation_reason
                                                 , po_productgroup
                                                 , po_code_sales_channel
                                                 , po_costumer_id
                                                 , po_division
                                                 , po_sitecode
                                                 , po_internal_status
                                                 , po_invoicenumber
                                                 , po_campain_tags
                                                 , po_campain
                                                 , po_coupon
                                                 , po_medium
                                                 , po_src
                                                 , po_utmi_campaing
                                                 , po_sequence_orderid
                                                 , po_prodname
                                                 , po_sku
                                                 , po_seller_id
                                                 , po_seller_name
                                                 , po_status
                                                 , client_subsidiary_id
                                                 , subsidiary
                                                 , currency
                                                 , po_tradepolicy
                                                 , po_vendortype
                                                 , channel
                                                 , biz_type
                                                 , audience_type
                                                 , po_storename
                                                 , client_acquirer_message
                                                 , po_lastupdate_date_hour
                                                 , po_orderqty
                                                 , po_qty
                                                 , po_itemdiscount_localcurr
                                                 , po_itemdiscount_usd
                                                 , po_price_localcurr
                                                 , po_price_usd
                                                 , po_plataform_datasource
                                                 , po_source_insert_date
                                                 , po_source_last_update_date
                                                 , po_insert_date
                                                 , po_last_update_date
                                                 , product_group_gscm
                                                 , product_scmtype
                                                 , product_gscm
                                                 , product_att1_gscm   
                                                 , po_payment_remark   
                                                 , po_totalprice_usd
                                                 , po_totalprice_local    
                                                 , po_devicetype
                                                 , po_sku_kit                   
                                                 , po_prodname_kit              
                                                 , po_price_localcurr_kit       
                                                 , po_itemdiscount_localcurr_kit
                                                 , is_kit                            
                                         )
                                         values(
                                                   b.po_date
                                                 , b.po_hour
                                                 , b.podate_year
                                                 , b.podate_month
                                                 , b.country
                                                 , b.samsung_care_order
                                                 , b.samsung_care
                                                 , b.samsung_care_eligibility
                                                 , b.trade_in
                                                 , b.trade_in_eligibility
                                                 , b.costumer_code_id_name
                                                 , b.po_orderid
                                                 , b.seller_po_orderid
                                                 , b.payment_card_brand
                                                 , b.payment_type
                                                 , b.installment
                                                 , b.installment_eligibility
                                                 , b.po_cancelation_reason
                                                 , b.po_productgroup
                                                 , b.po_code_sales_channel
                                                 , b.po_costumer_id
                                                 , b.po_division
                                                 , b.po_sitecode
                                                 , b.po_internal_status
                                                 , b.po_invoicenumber
                                                 , b.po_campain_tags
                                                 , b.po_campain
                                                 , b.po_coupon
                                                 , b.po_medium
                                                 , b.po_src
                                                 , b.po_utmi_campaing
                                                 , b.po_sequence_orderid
                                                 , b.po_prodname
                                                 , b.po_sku
                                                 , b.po_seller_id
                                                 , b.po_seller_name
                                                 , b.po_status
                                                 , b.client_subsidiary_id
                                                 , b.subsidiary
                                                 , b.currency
                                                 , b.po_tradepolicy
                                                 , b.po_vendortype
                                                 , b.channel
                                                 , b.biz_type
                                                 , b.audience_type
                                                 , b.po_storename
                                                 , b.client_acquirer_message
                                                 , b.po_lastupdate_date_hour
                                                 , b.po_orderqty
                                                 , b.po_qty
                                                 , b.po_itemdiscount_localcurr
                                                 , b.po_itemdiscount_usd
                                                 , b.po_price_localcurr
                                                 , b.po_price_usd
                                                 , b.po_plataform_datasource
                                                 , b.po_source_insert_date
                                                 , b.po_source_last_update_date
                                                 , b.po_insert_date
                                                 , b.po_last_update_date
                                                 , b.product_group_gscm
                                                 , b.product_scmtype
                                                 , b.product_gscm
                                                 , b.product_att1_gscm 
                                                 , b.po_payment_remark   
                                                 , b.po_totalprice_usd
                                                 , b.po_totalprice_local                              
                                                 , b.po_devicetype
                                                 , b.po_sku_kit                   
                                                 , b.po_prodname_kit              
                                                 , b.po_price_localcurr_kit       
                                                 , b.po_itemdiscount_localcurr_kit
                                                 , b.is_kit  
                                         );
                                                                                                             
-- Control tower kit                      
                         
             merge into ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown            a
                  using ow_lao.tmp_ecommerce_sales_control_tower_table_u_prj_ecom_bundles_breakdown b on b.po_orderid = a.po_orderid
                                                                                                     and b.po_sku     = a.po_sku
                                                                                                     and b.country    = a.country
                                                                                                     and b.po_sku_kit = a.po_sku_kit
                                                                                                        
                  when    matched then update  
                                           set a.po_date                    = b.po_date
                                             , a.po_hour                    = b.po_hour
                                             , a.podate_year                = b.podate_year
                                             , a.podate_month               = b.podate_month
                                             , a.samsung_care_order         = b.samsung_care_order
                                             , a.samsung_care               = b.samsung_care
                                             , a.samsung_care_eligibility   = b.samsung_care_eligibility
                                             , a.trade_in                   = b.trade_in
                                             , a.trade_in_eligibility       = b.trade_in_eligibility
                                             , a.costumer_code_id_name      = b.costumer_code_id_name
                                             , a.seller_po_orderid          = b.seller_po_orderid
                                             , a.payment_card_brand         = b.payment_card_brand
                                             , a.payment_type               = b.payment_type
                                             , a.installment                = b.installment
                                             , a.installment_eligibility    = b.installment_eligibility
                                             , a.po_cancelation_reason      = b.po_cancelation_reason
                                             , a.po_productgroup            = b.po_productgroup
                                             , a.po_code_sales_channel      = b.po_code_sales_channel
                                             , a.po_costumer_id             = b.po_costumer_id
                                             , a.po_division                = b.po_division
                                             , a.po_sitecode                = b.po_sitecode
                                             , a.po_internal_status         = b.po_internal_status
                                             , a.po_invoicenumber           = b.po_invoicenumber
                                             , a.po_campain_tags            = b.po_campain_tags
                                             , a.po_campain                 = b.po_campain
                                             , a.po_coupon                  = b.po_coupon
                                             , a.po_medium                  = b.po_medium
                                             , a.po_src                     = b.po_src
                                             , a.po_utmi_campaing           = b.po_utmi_campaing
                                             , a.po_prodname                = b.po_prodname
                                             , a.po_seller_id               = b.po_seller_id
                                             , a.po_seller_name             = b.po_seller_name
                                             , a.po_status                  = b.po_status
                                             , a.client_subsidiary_id       = b.client_subsidiary_id
                                             , a.subsidiary                 = b.subsidiary
                                             , a.currency                   = b.currency
                                             , a.po_tradepolicy             = b.po_tradepolicy
                                             , a.po_vendortype              = b.po_vendortype
                                             , a.channel                    = b.channel
                                             , a.biz_type                   = b.biz_type
                                             , a.audience_type              = b.audience_type
                                             , a.po_storename               = b.po_storename
                                             , a.client_acquirer_message    = b.client_acquirer_message
                                             , a.po_lastupdate_date_hour    = b.po_lastupdate_date_hour
                                             , a.po_orderqty                = b.po_orderqty
                                             , a.po_qty                     = b.po_qty
                                             , a.po_itemdiscount_localcurr  = b.po_itemdiscount_localcurr
                                             , a.po_itemdiscount_usd        = b.po_itemdiscount_usd
                                             , a.po_price_localcurr         = b.po_price_localcurr
                                             , a.po_price_usd               = b.po_price_usd
                                             , a.po_plataform_datasource    = b.po_plataform_datasource
                                             , a.po_source_insert_date      = b.po_source_insert_date
                                             , a.po_source_last_update_date = b.po_source_last_update_date
                                             , a.po_insert_date             = b.po_insert_date
                                             , a.po_last_update_date        = b.po_last_update_date
                                             , a.product_group_gscm         = b.product_group_gscm
                                             , a.product_scmtype            = b.product_scmtype
                                             , a.product_gscm               = b.product_gscm
                                             , a.product_att1_gscm          = b.product_att1_gscm
                                             , a.po_payment_remark          = b.po_payment_remark
                                             , a.po_totalprice_usd          = b.po_totalprice_usd
                                             , a.po_totalprice_local        = b.po_totalprice_local
                                             , a.po_devicetype              = b.po_devicetype
                                             , a.updated_datetime           = current_timestamp
                                             , a.po_sku_kit                 = b.po_sku_kit  
                                             , a.po_prodname_kit            = b.po_prodname_kit           
                                             , a.po_price_localcurr_kit     = b.po_price_localcurr_kit  
                                             , a.po_itemdiscount_localcurr_kit = b.po_itemdiscount_localcurr_kit
                                             , a.is_kit                     = b.is_kit
                   when not matched then insert(
                                                   po_date
                                                 , po_hour
                                                 , podate_year
                                                 , podate_month
                                                 , country
                                                 , samsung_care_order
                                                 , samsung_care
                                                 , samsung_care_eligibility
                                                 , trade_in
                                                 , trade_in_eligibility
                                                 , costumer_code_id_name
                                                 , po_orderid
                                                 , seller_po_orderid
                                                 , payment_card_brand
                                                 , payment_type
                                                 , installment
                                                 , installment_eligibility
                                                 , po_cancelation_reason
                                                 , po_productgroup
                                                 , po_code_sales_channel
                                                 , po_costumer_id
                                                 , po_division
                                                 , po_sitecode
                                                 , po_internal_status
                                                 , po_invoicenumber
                                                 , po_campain_tags
                                                 , po_campain
                                                 , po_coupon
                                                 , po_medium
                                                 , po_src
                                                 , po_utmi_campaing
                                                 , po_sequence_orderid
                                                 , po_prodname
                                                 , po_sku
                                                 , po_seller_id
                                                 , po_seller_name
                                                 , po_status
                                                 , client_subsidiary_id
                                                 , subsidiary
                                                 , currency
                                                 , po_tradepolicy
                                                 , po_vendortype
                                                 , channel
                                                 , biz_type
                                                 , audience_type
                                                 , po_storename
                                                 , client_acquirer_message
                                                 , po_lastupdate_date_hour
                                                 , po_orderqty
                                                 , po_qty
                                                 , po_itemdiscount_localcurr
                                                 , po_itemdiscount_usd
                                                 , po_price_localcurr
                                                 , po_price_usd
                                                 , po_plataform_datasource
                                                 , po_source_insert_date
                                                 , po_source_last_update_date
                                                 , po_insert_date
                                                 , po_last_update_date
                                                 , product_group_gscm
                                                 , product_scmtype
                                                 , product_gscm
                                                 , product_att1_gscm   
                                                 , po_payment_remark   
                                                 , po_totalprice_usd
                                                 , po_totalprice_local    
                                                 , po_devicetype     
                                                 , po_sku_kit                   
                                                 , po_prodname_kit              
                                                 , po_price_localcurr_kit       
                                                 , po_itemdiscount_localcurr_kit
                                                 , is_kit  
                                         )
                                         values(
                                                   b.po_date
                                                 , b.po_hour
                                                 , b.podate_year
                                                 , b.podate_month
                                                 , b.country
                                                 , b.samsung_care_order
                                                 , b.samsung_care
                                                 , b.samsung_care_eligibility
                                                 , b.trade_in
                                                 , b.trade_in_eligibility
                                                 , b.costumer_code_id_name
                                                 , b.po_orderid
                                                 , b.seller_po_orderid
                                                 , b.payment_card_brand
                                                 , b.payment_type
                                                 , b.installment
                                                 , b.installment_eligibility
                                                 , b.po_cancelation_reason
                                                 , b.po_productgroup
                                                 , b.po_code_sales_channel
                                                 , b.po_costumer_id
                                                 , b.po_division
                                                 , b.po_sitecode
                                                 , b.po_internal_status
                                                 , b.po_invoicenumber
                                                 , b.po_campain_tags
                                                 , b.po_campain
                                                 , b.po_coupon
                                                 , b.po_medium
                                                 , b.po_src
                                                 , b.po_utmi_campaing
                                                 , b.po_sequence_orderid
                                                 , b.po_prodname
                                                 , b.po_sku
                                                 , b.po_seller_id
                                                 , b.po_seller_name
                                                 , b.po_status
                                                 , b.client_subsidiary_id
                                                 , b.subsidiary
                                                 , b.currency
                                                 , b.po_tradepolicy
                                                 , b.po_vendortype
                                                 , b.channel
                                                 , b.biz_type
                                                 , b.audience_type
                                                 , b.po_storename
                                                 , b.client_acquirer_message
                                                 , b.po_lastupdate_date_hour
                                                 , b.po_orderqty
                                                 , b.po_qty
                                                 , b.po_itemdiscount_localcurr
                                                 , b.po_itemdiscount_usd
                                                 , b.po_price_localcurr
                                                 , b.po_price_usd
                                                 , b.po_plataform_datasource
                                                 , b.po_source_insert_date
                                                 , b.po_source_last_update_date
                                                 , b.po_insert_date
                                                 , b.po_last_update_date
                                                 , b.product_group_gscm
                                                 , b.product_scmtype
                                                 , b.product_gscm
                                                 , b.product_att1_gscm 
                                                 , b.po_payment_remark   
                                                 , b.po_totalprice_usd
                                                 , b.po_totalprice_local                              
                                                 , b.po_devicetype
                                                 , b.po_sku_kit                   
                                                 , b.po_prodname_kit              
                                                 , b.po_price_localcurr_kit       
                                                 , b.po_itemdiscount_localcurr_kit
                                                 , b.is_kit  
                                         );
                                                                                                                                                                                                                  
-- Reprocessing order totals                                                                                                                                                                                                          
                                                                                                                                                                                                                  
                      drop table ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_agg;
             create column table ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_agg
                 as (               
                        select country
                             , po_orderid
                             , sum(po_qty)             as po_orderqty
                             , sum(po_price_localcurr) as po_totalprice_local
                          from ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown   
                      group by country
                             , po_orderid           
                 );
                 
                update ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown         a
                   set a.po_orderqty         = b.po_orderqty
                  from ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown         a
                  join ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_agg     b on b.country    = a.country
                                                                                                 and b.po_orderid = a.po_orderid;
                                                                                                            
    
         
end