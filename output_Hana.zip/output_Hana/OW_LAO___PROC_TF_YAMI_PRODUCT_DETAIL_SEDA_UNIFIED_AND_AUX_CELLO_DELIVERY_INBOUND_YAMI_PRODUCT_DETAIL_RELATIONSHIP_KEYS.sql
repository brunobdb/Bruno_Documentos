CREATE PROCEDURE OW_LAO.PROC_TF_YAMI_PRODUCT_DETAIL_SEDA_UNIFIED_AND_AUX_CELLO_DELIVERY_INBOUND_YAMI_PRODUCT_DETAIL_RELATIONSHIP_KEYS
 LANGUAGE SQLSCRIPT AS
 BEGIN  
	truncate table "OW_LAO"."AUX_CELLO_DELIVERY_INBOUND_YAMI_PRODUCT_DETAIL_RELATIONSHIP_KEYS";
	
	    insert into "OW_LAO"."AUX_CELLO_DELIVERY_INBOUND_YAMI_PRODUCT_DETAIL_RELATIONSHIP_KEYS" 
	  
	    select po_number
	         , length(po_number)                    po_number_lenght
	         , case 
	                when length(po_number) = 6
	                --then concat('0', po_number)
	                then po_number
	                when length(po_number) = 20
	                then right(po_number, 16)
	                else po_number
	            end                                 po_number_fix
	         , case length(po_number)
	                when 15
	                then 'order_id'
	                when 20
	                then 'order_id'
	                else 'sequence'
	            end                                 po_number_fix_key
	      from "OW_SEDA_S".CELLO_DELIVERY_INBOUND                 a
	      join "OW_LAO".AUX_CELLO_DELIVERY_INBOUND_ORDER_TYPE d on d.order_type     = a.order_type  
	     where 1 = 1
	       and a.ship_type_cd in ('P3', 'P4')
	       and a.po_number is not null;
	
	truncate table "OW_LAO"."TF_YAMI_PRODUCT_DETAIL_SEDA_UNIFIED";
	
	
	    insert into "OW_LAO"."TF_YAMI_PRODUCT_DETAIL_SEDA_UNIFIED"(
	           "ACCOUNT"
	         , "MKT_ACCOUNT"
	         , "CUSTOMER_ID"
	         , "PROTOCOL_VALUE"
	         , "ORDER_ID"
	         , "ORDER_SEQUENCE"
	         , "MKT_PLACE_ORDER_ID"
	         , "STATUS"
	         , "TYPE"
	         , "NAME"
	         , "PROCESSED_TIME"
	         , "ORDER_INVOICE_NUMBER"
	         , "ORDER_ORIGIN_DATE"
	         , "ORDER_GIFT_CARD"
	         , "ORDER_TRACK_NUMBER"
	         , "ORDER_SELLER"
	         , "ORDER_TRANSACTION_ID"
	         , "CREATED_DATE"
	         , "PAYMENT_METHOD"
	         , "ID"
	         , "ITEM_CODE"
	         , "ITEM_MOTIVE"
	         , "ITEM_NAME"
	         , "ITEM_QUANTITY_IN_ORDER"
	         , "ITEM_QUANTITY_IN_REQUEST"
	         , "ITEM_VALUE"
	         , "ITEM_VALUE_PAID"
	         , "ITEM_REF_CODE"
	         , "ITEM_FREIGHT"
	         , "PRODUCT_ID"
	         , "LOAD_DATE")
	    select "ACCOUNT"
	         , "MKT_ACCOUNT"
	         , "CUSTOMER_ID"
	         , "PROTOCOL_VALUE"
	         , "ORDER_ID"
	         , "ORDER_SEQUENCE"
	         , "MKT_PLACE_ORDER_ID"
	         , "STATUS"
	         , "TYPE"
	         , "NAME"
	         , "PROCESSED_TIME"
	         , "ORDER_INVOICE_NUMBER"
	         , "ORDER_ORIGIN_DATE"
	         , "ORDER_GIFT_CARD"
	         , "ORDER_TRACK_NUMBER"
	         , "ORDER_SELLER"
	         , "ORDER_TRANSACTION_ID"
	         , "CREATED_DATE"
	         , "PAYMENT_METHOD"
	         , "ID"
	         , "ITEM_CODE"
	         , "ITEM_MOTIVE"
	         , "ITEM_NAME"
	         , "ITEM_QUANTITY_IN_ORDER"
	         , "ITEM_QUANTITY_IN_REQUEST"
	         , "ITEM_VALUE"
	         , "ITEM_VALUE_PAID"
	         , "ITEM_REF_CODE"
	         , "ITEM_FREIGHT"
	         , "PRODUCT_ID"
	         , "LOAD_DATE"
	      from (
	         select row_number() 
	                    over(partition by account
	                                    , mkt_account
	                                    , order_id
	                                    , item_ref_code
	                             order by b.order_flow
	                    )                                        as dedup
	              , a.*
	           from "OW_SEDA_S".ODS_YAMI_PRODUCT_DETAIL_SAMSUNGBR a
	           join "OW_LAO".AUX_YAMI_PRODUCT_DETAIL_STATUS   b on b.status_name = a.status
	          where b."IMPORT" = true
	      ) a
	     where dedup = 1;
	     
	    insert into "OW_LAO"."TF_YAMI_PRODUCT_DETAIL_SEDA_UNIFIED"(
	           "ACCOUNT"
	         , "MKT_ACCOUNT"
	         , "CUSTOMER_ID"
	         , "PROTOCOL_VALUE"
	         , "ORDER_ID"
	         , "ORDER_SEQUENCE"
	         , "MKT_PLACE_ORDER_ID"
	         , "STATUS"
	         , "TYPE"
	         , "NAME"
	         , "PROCESSED_TIME"
	         , "ORDER_INVOICE_NUMBER"
	         , "ORDER_ORIGIN_DATE"
	         , "ORDER_GIFT_CARD"
	         , "ORDER_TRACK_NUMBER"
	         , "ORDER_SELLER"
	         , "ORDER_TRANSACTION_ID"
	         , "CREATED_DATE"
	         , "PAYMENT_METHOD"
	         , "ID"
	         , "ITEM_CODE"
	         , "ITEM_MOTIVE"
	         , "ITEM_NAME"
	         , "ITEM_QUANTITY_IN_ORDER"
	         , "ITEM_QUANTITY_IN_REQUEST"
	         , "ITEM_VALUE"
	         , "ITEM_VALUE_PAID"
	         , "ITEM_REF_CODE"
	         , "ITEM_FREIGHT"
	         , "PRODUCT_ID"
	         , "LOAD_DATE")
	    select "ACCOUNT"
	         , "MKT_ACCOUNT"
	         , "CUSTOMER_ID"
	         , "PROTOCOL_VALUE"
	         , "ORDER_ID"
	         , "ORDER_SEQUENCE"
	         , "MKT_PLACE_ORDER_ID"
	         , "STATUS"
	         , "TYPE"
	         , "NAME"
	         , "PROCESSED_TIME"
	         , "ORDER_INVOICE_NUMBER"
	         , "ORDER_ORIGIN_DATE"
	         , "ORDER_GIFT_CARD"
	         , "ORDER_TRACK_NUMBER"
	         , "ORDER_SELLER"
	         , "ORDER_TRANSACTION_ID"
	         , "CREATED_DATE"
	         , "PAYMENT_METHOD"
	         , "ID"
	         , "ITEM_CODE"
	         , "ITEM_MOTIVE"
	         , "ITEM_NAME"
	         , "ITEM_QUANTITY_IN_ORDER"
	         , "ITEM_QUANTITY_IN_REQUEST"
	         , "ITEM_VALUE"
	         , "ITEM_VALUE_PAID"
	         , "ITEM_REF_CODE"
	         , "ITEM_FREIGHT"
	         , "PRODUCT_ID"
	         , "LOAD_DATE"
	      from (
	         select row_number() 
	                    over(partition by account
	                                    , mkt_account
	                                    , order_id
	                                    , item_ref_code 
	                             order by b.order_flow
	                    )                                        as dedup
	              , a.*
	           from "OW_SEDA_S".ODS_YAMI_PRODUCT_DETAIL_SAMSUNGBRB2B a
	           join "OW_LAO".AUX_YAMI_PRODUCT_DETAIL_STATUS   b on b.status_name = a.status
	          where b."IMPORT" = true
	      ) a
	     where dedup = 1;
	     
	    insert into "OW_LAO"."TF_YAMI_PRODUCT_DETAIL_SEDA_UNIFIED"(
	           "ACCOUNT"
	         , "MKT_ACCOUNT"
	         , "CUSTOMER_ID"
	         , "PROTOCOL_VALUE"
	         , "ORDER_ID"
	         , "ORDER_SEQUENCE"
	         , "MKT_PLACE_ORDER_ID"
	         , "STATUS"
	         , "TYPE"
	         , "NAME"
	         , "PROCESSED_TIME"
	         , "ORDER_INVOICE_NUMBER"
	         , "ORDER_ORIGIN_DATE"
	         , "ORDER_GIFT_CARD"
	         , "ORDER_TRACK_NUMBER"
	         , "ORDER_SELLER"
	         , "ORDER_TRANSACTION_ID"
	         , "CREATED_DATE"
	         , "PAYMENT_METHOD"
	         , "ID"
	         , "ITEM_CODE"
	         , "ITEM_MOTIVE"
	         , "ITEM_NAME"
	         , "ITEM_QUANTITY_IN_ORDER"
	         , "ITEM_QUANTITY_IN_REQUEST"
	         , "ITEM_VALUE"
	         , "ITEM_VALUE_PAID"
	         , "ITEM_REF_CODE"
	         , "ITEM_FREIGHT"
	         , "PRODUCT_ID"
	         , "LOAD_DATE")
	    select "ACCOUNT"
	         , "MKT_ACCOUNT"
	         , "CUSTOMER_ID"
	         , "PROTOCOL_VALUE"
	         , "ORDER_ID"
	         , "ORDER_SEQUENCE"
	         , "MKT_PLACE_ORDER_ID"
	         , "STATUS"
	         , "TYPE"
	         , "NAME"
	         , "PROCESSED_TIME"
	         , "ORDER_INVOICE_NUMBER"
	         , "ORDER_ORIGIN_DATE"
	         , "ORDER_GIFT_CARD"
	         , "ORDER_TRACK_NUMBER"
	         , "ORDER_SELLER"
	         , "ORDER_TRANSACTION_ID"
	         , "CREATED_DATE"
	         , "PAYMENT_METHOD"
	         , "ID"
	         , "ITEM_CODE"
	         , "ITEM_MOTIVE"
	         , "ITEM_NAME"
	         , "ITEM_QUANTITY_IN_ORDER"
	         , "ITEM_QUANTITY_IN_REQUEST"
	         , "ITEM_VALUE"
	         , "ITEM_VALUE_PAID"
	         , "ITEM_REF_CODE"
	         , "ITEM_FREIGHT"
	         , "PRODUCT_ID"
	         , "LOAD_DATE"
	      from (
	         select row_number() 
	                    over(partition by account
	                                    , mkt_account
	                                    , order_id
	                                    , item_ref_code 
	                             order by b.order_flow
	                    )                                        as dedup
	              , a.*
	           from "OW_SEDA_S".ODS_YAMI_PRODUCT_DETAIL_SAMSUNGBREPP2 a
	           join "OW_LAO".AUX_YAMI_PRODUCT_DETAIL_STATUS   b on b.status_name = a.status
	          where b."IMPORT" = true
	      ) a
	     where dedup = 1;     
	     
END