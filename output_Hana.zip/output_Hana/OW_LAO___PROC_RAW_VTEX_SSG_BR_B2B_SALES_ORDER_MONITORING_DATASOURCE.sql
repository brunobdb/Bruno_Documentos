CREATE procedure ow_lao.proc_RAW_VTEX_SSG_BR_B2B_SALES_ORDER_monitoring_datasource
language sqlscript as
begin
    select case 
                when max(creation_timestamp) <= add_seconds(current_timestamp, -10800)
                then 3
                else 2
           end                                                                                       as monitoring_execution_result_status
         , concat('Last order imported was on : ', left(to_varchar(max(creation_timestamp)), 19))    as value
      from U_PRJ_ECOM.RAW_VTEX_SSG_BR_B2B_SALES_ORDER;
      
      
 end