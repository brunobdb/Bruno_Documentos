CREATE PROCEDURE OW_LAO.proc_ods_sela_custom_orders_history_comments
 LANGUAGE SQLSCRIPT AS
 BEGIN
 
 
    create local temporary table #ods_sela_custom_orders_history_comments
        as (
        
                select *
                     , hash_sha256(
			                to_varbinary(IFNULL(subsidiary_id,'0'))
			              , to_varbinary(IFNULL(account      ,'0'))
			              , to_varbinary(IFNULL(order_id     ,'0'))
			              , to_varbinary(IFNULL(date         ,'0'))
			           )                                             as guid
                  from ow_lao.stg_sela_custom_orders_history_comments
        
        );
        
     delete
       from ow_lao.ods_sela_custom_orders_history_comments
      where guid in (select distinct guid from ow_lao.stg_sela_custom_orders_history_comments);
     merge into ow_lao.ods_sela_custom_orders_history_comments a
          using #ods_sela_custom_orders_history_comments       b on b.guid = a.guid
          
           when    matched then update  
                                   set a.updated_timestamp  = current_timestamp   
                                     , a.comment            = b.comment
           when not matched then insert(           
                                           updated_timestamp    
                                         , comment
                                         , subsidiary_id
                                         , account
                                         , order_id
                                         , date
                                         , guid
                                  )
                                 values(
                                           current_timestamp 
                                         , b.comment
                                         , b.subsidiary_id
                                         , b.account
                                         , b.order_id
                                         , b.date
                                         , b.guid
                                 );
    end