CREATE PROCEDURE OW_LAO.proc_ods_sela_sales_coupons_items
 LANGUAGE SQLSCRIPT AS
 BEGIN
     merge into ow_lao.ods_sela_sales_coupons_items a
          using ow_lao.stg_sela_sales_coupons_items b on b.subsidiary_id = a.subsidiary_id
                                                     and b.account       = a.account
                                                     and b.entity_id     = a.entity_id
                                                     and b.item_id       = a.item_id
           when    matched then update  
                                   set a.updated_timestamp                            = current_timestamp      
                                     , a.parent_applied_rule_ids = b.parent_applied_rule_ids
                                     , a.amount_refunded = b.amount_refunded
                                     , a.applied_rule_ids = b.applied_rule_ids
                                     , a.base_amount_refunded = b.base_amount_refunded
                                     , a.base_discount_amount = b.base_discount_amount
                                     , a.base_discount_invoiced = b.base_discount_invoiced
                                     , a.base_discount_refunded = b.base_discount_refunded
                                     , a.base_discount_tax_compensation_amount = b.base_discount_tax_compensation_amount
                                     , a.base_discount_tax_compensation_invoiced = b.base_discount_tax_compensation_invoiced
                                     , a.base_discount_tax_compensation_refunded = b.base_discount_tax_compensation_refunded
                                     , a.base_original_price = b.base_original_price
                                     , a.base_price = b.base_price
                                     , a.base_price_incl_tax = b.base_price_incl_tax
                                     , a.base_row_invoiced = b.base_row_invoiced
                                     , a.base_row_total = b.base_row_total
                                     , a.base_row_total_incl_tax = b.base_row_total_incl_tax
                                     , a.base_tax_amount = b.base_tax_amount
                                     , a.base_tax_invoiced = b.base_tax_invoiced
                                     , a.base_tax_refunded = b.base_tax_refunded
                                     , a.created_at = b.created_at
                                     , a.discount_amount = b.discount_amount
                                     , a.discount_invoiced = b.discount_invoiced
                                     , a.discount_percent = b.discount_percent
                                     , a.discount_refunded = b.discount_refunded
                                     , a.free_shipping = b.free_shipping
                                     , a.discount_tax_compensation_amount = b.discount_tax_compensation_amount
                                     , a.discount_tax_compensation_invoiced = b.discount_tax_compensation_invoiced
                                     , a.discount_tax_compensation_refunded = b.discount_tax_compensation_refunded
                                     , a.is_qty_decimal = b.is_qty_decimal
                                     , a.is_virtual = b.is_virtual
                                     , a.name = b.name
                                     , a.no_discount = b.no_discount
                                     , a.order_id = b.order_id
                                     , a.original_price = b.original_price
                                     , a.price = b.price
                                     , a.price_incl_tax = b.price_incl_tax
                                     , a.product_id = b.product_id
                                     , a.product_type = b.product_type
                                     , a.qty_canceled = b.qty_canceled
                                     , a.qty_invoiced = b.qty_invoiced
                                     , a.qty_ordered = b.qty_ordered
                                     , a.qty_refunded = b.qty_refunded
                                     , a.qty_shipped = b.qty_shipped
                                     , a.quote_item_id = b.quote_item_id
                                     , a.row_invoiced = b.row_invoiced
                                     , a.row_total = b.row_total
                                     , a.row_total_incl_tax = b.row_total_incl_tax
                                     , a.row_weight = b.row_weight
                                     , a.sku = b.sku
                                     , a.items_store_id = b.items_store_id
                                     , a.tax_amount = b.tax_amount
                                     , a.tax_invoiced = b.tax_invoiced
                                     , a.tax_percent = b.tax_percent
                                     , a.tax_refunded = b.tax_refunded
                                     , a.updated_at = b.updated_at
                                     , a.weee_tax_applied = b.weee_tax_applied
                                     , a.weight = b.weight
                                     , a.product_option_extension_attributes_config  = b.product_option_extension_attributes_config                                                                                         
           when not matched then insert(           
                                           updated_timestamp   
                                         , entity_id
                                         , subsidiary_id
                                         , account
                                         , parent_applied_rule_ids
                                         , amount_refunded
                                         , applied_rule_ids
                                         , base_amount_refunded
                                         , base_discount_amount
                                         , base_discount_invoiced
                                         , base_discount_refunded
                                         , base_discount_tax_compensation_amount
                                         , base_discount_tax_compensation_invoiced
                                         , base_discount_tax_compensation_refunded
                                         , base_original_price
                                         , base_price
                                         , base_price_incl_tax
                                         , base_row_invoiced
                                         , base_row_total
                                         , base_row_total_incl_tax
                                         , base_tax_amount
                                         , base_tax_invoiced
                                         , base_tax_refunded
                                         , created_at
                                         , discount_amount
                                         , discount_invoiced
                                         , discount_percent
                                         , discount_refunded
                                         , free_shipping
                                         , discount_tax_compensation_amount
                                         , discount_tax_compensation_invoiced
                                         , discount_tax_compensation_refunded
                                         , is_qty_decimal
                                         , is_virtual
                                         , item_id
                                         , name
                                         , no_discount
                                         , order_id
                                         , original_price
                                         , price
                                         , price_incl_tax
                                         , product_id
                                         , product_type
                                         , qty_canceled
                                         , qty_invoiced
                                         , qty_ordered
                                         , qty_refunded
                                         , qty_shipped
                                         , quote_item_id
                                         , row_invoiced
                                         , row_total
                                         , row_total_incl_tax
                                         , row_weight
                                         , sku
                                         , items_store_id
                                         , tax_amount
                                         , tax_invoiced
                                         , tax_percent
                                         , tax_refunded
                                         , updated_at
                                         , weee_tax_applied
                                         , weight
                                         , product_option_extension_attributes_config         
                                 )      
                                 values(
                                           current_timestamp
                                         , b.entity_id
                                         , b.subsidiary_id
                                         , b.account
                                         , b.parent_applied_rule_ids
                                         , b.amount_refunded
                                         , b.applied_rule_ids
                                         , b.base_amount_refunded
                                         , b.base_discount_amount
                                         , b.base_discount_invoiced
                                         , b.base_discount_refunded
                                         , b.base_discount_tax_compensation_amount
                                         , b.base_discount_tax_compensation_invoiced
                                         , b.base_discount_tax_compensation_refunded
                                         , b.base_original_price
                                         , b.base_price
                                         , b.base_price_incl_tax
                                         , b.base_row_invoiced
                                         , b.base_row_total
                                         , b.base_row_total_incl_tax
                                         , b.base_tax_amount
                                         , b.base_tax_invoiced
                                         , b.base_tax_refunded
                                         , b.created_at
                                         , b.discount_amount
                                         , b.discount_invoiced
                                         , b.discount_percent
                                         , b.discount_refunded
                                         , b.free_shipping
                                         , b.discount_tax_compensation_amount
                                         , b.discount_tax_compensation_invoiced
                                         , b.discount_tax_compensation_refunded
                                         , b.is_qty_decimal
                                         , b.is_virtual
                                         , b.item_id
                                         , b.name
                                         , b.no_discount
                                         , b.order_id
                                         , b.original_price
                                         , b.price
                                         , b.price_incl_tax
                                         , b.product_id
                                         , b.product_type
                                         , b.qty_canceled
                                         , b.qty_invoiced
                                         , b.qty_ordered
                                         , b.qty_refunded
                                         , b.qty_shipped
                                         , b.quote_item_id
                                         , b.row_invoiced
                                         , b.row_total
                                         , b.row_total_incl_tax
                                         , b.row_weight
                                         , b.sku
                                         , b.items_store_id
                                         , b.tax_amount
                                         , b.tax_invoiced
                                         , b.tax_percent
                                         , b.tax_refunded
                                         , b.updated_at
                                         , b.weee_tax_applied
                                         , b.weight
                                         , b.product_option_extension_attributes_config                                            
                                 );
    end