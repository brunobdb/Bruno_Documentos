CREATE PROCEDURE OW_LAO.proc_ods_sales_control_tower_table_stienda
 LANGUAGE SQLSCRIPT AS
     begin
     
         --drop table #stg_sales_orders_stienda_uruguay_prepare ;
         --drop table #stg_sales_orders_stienda_uruguay_prepare_agg;
         --drop table #stg_sales_orders_stienda_uruguay_prepare_sku_agg;  
        create local temporary table #stg_sales_orders_stienda_uruguay_prepare 
            as (            
                select cast( 
                            replace(
                                left(fechainicio, 16)
                            , 'T', ' ')       as date)      as po_date
                     , year(
                        cast( 
                            replace(
                                left(fechainicio, 16)
                            , 'T', ' ')  
                            as date)
                       )                                    as po_year
                     , month(
                        cast( 
                            replace(
                                left(fechainicio, 16)
                            , 'T', ' ') 
                        as date)
                       )                                    as po_month
                     , 'Uruguay'                            as country
                     , 0                                    as samsung_care_order
                     , 0                                    as samsung_care
                     , 0                                    as samsung_care_eligibility
                     , 0                                    as trade_in
                     , 0                                    as trade_in_eligibility
                     , 0                                    as trade_up
                     , 0                                    as trade_up_eligibility
                     , ''                                   as costumer_code_id_name
                     , cast(a.idorden as varchar(3000))     as po_orderid
                     , 0                                    as seller_po_orderid
                     , cast(null as varchar(3000))          as payment_card_brand
                     , cast(null as varchar(3000))          as payment_type
                     , 0                                    as installment
                     , null                                 as installment_eligibility
                     , ''                                   as po_cancelation_reason
                     , d.product_group_1                    as po_productgroup
                     , ''                                   as po_code_sales_channel
                     , null                                 as po_costumer_id
                     , 'stienda_uy'                         as po_sitecode
                     , a.estado                             as po_internal_status
                     , null                                 as po_invoicenumber
                     , b.nombre                             as po_prodname
                     , coalesce(
                            b.sku
                          , b.nombre
                       )                                    as po_sku
                     , e.status                             as po_status
                     , 9                                    as client_subsidiary_id
                     , 'SELA'                               as subsidiary
                     , a.moneda                             as currency
                     , null                                 as po_tradepolicy      
                     , cast(null as varchar(255))           as channel
                     , cast(null as varchar(255))           as biz_type
                     , cast(null as varchar(255))           as audience_type
                     , cast(null as varchar(255))           as po_storename
                     , cast(null as varchar(255))           as client_acquirer_message
                     , cast(null as varchar(255))           as customer_type
                     , cast(null as varchar(255))           as po_seller_name
                     , 'stienda_uy'                         as po_store_name
                     , cast(null as varchar(255))           as po_mobile_os
                     , current_timestamp                    as po_source_insert_date
                     , null                                 as po_lastupdate_date_hour
                     , 0                                    as po_orderqty
                     , sum(b.cantidad)                      as po_qty
                     , sum(c.monto)                         as po_itemdiscount_localcurr
                     , 0                                    as po_itemdiscount_usd
                     , sum(b.precio) - sum(c.monto)         as po_price_localcurr
                     , 0                                    as po_price_usd
                     , 'ow_lao.stg_sales_orders_stienda_uruguay'  
                                                            as po_plataform_datasource  
                     , current_timestamp                    as po_source_last_update_date
                     , current_timestamp                    as po_insert_date
                     , null                                 as po_last_update_date
                     , cast(null as varchar(3000))          as po_payment_remark
                     , cast(
                            replace(
                                left(fechainicio, 16)
                            , 'T', ' ') 
                       as time)                             as po_hour 
                     , 0                                    as po_totalprice_usd
                     , 0                                    as po_totalprice_local
                     , cast('' as varchar(255))             as po_sku_kit
                     , cast('' as varchar(255))             as po_prodname_kit
                     , cast(0.00 as decimal)                as po_price_localcurr_kit
                     , cast(0.00 as decimal)                as po_itemdiscount_localcurr_kit
                     , false                                as is_kit 
                     , 'URY'                                as country_cd
                     , cast(null as varchar(255))           as biz_type_ebi_hq
                     , cast(null as varchar(255))           as global_channel_ebi_hq
                     , a.origen                             as po_devicetype                 
                  from ow_lao.stg_sales_orders_stienda_uruguay                 a
                  join ow_lao.stg_sales_orders_itens_stienda_uruguay           b on b.idorden       = a.idorden
                  join ow_lao.stg_sales_orders_itens_discounts_stienda_uruguay c on c.idorden       = b.idorden 
                                                                                and c.sku           = b.sku
             left join ow_md.dim_product                                       d on d.sku           = b.sku
             left join ow_lao.dim_ods_sales_control_tower_table_status_mapping e on e.status_origin = coalesce(a.estado, 'incomplete')
                 where 1 = 1 
                   --and a.idorden = 161145
                   and not exists(                        
                            select 1
                              from ow_lao.ods_sales_control_tower_table aa
                             where aa.po_orderid                  = cast(a.idorden as varchar(255))
                               and aa.po_sku                      = b.sku
                               and aa.country                     = 'Uruguay'
                               and aa.po_internal_status          = coalesce(a.estado, 'incomplete')
                               and aa.po_sitecode                 = 'stienda_uy'
                       )
              group by a.fechainicio
                     , a.idorden
                     , d.product_group_1
                     , a.estado
                     , e.status
                     , b.sku
                     , b.nombre
                     , a.moneda
                     , a.origen                 
        );  
        
     create local temporary table  #stg_sales_orders_stienda_uruguay_prepare_agg
         as (               
                select country
                     , po_orderid
                     , sum(po_qty)             as po_orderqty
                     , sum(po_price_localcurr) as po_totalprice_local
                  from #stg_sales_orders_stienda_uruguay_prepare 
              group by country
                     , po_orderid           
         );
        
     create local temporary table  #stg_sales_orders_stienda_uruguay_prepare_sku_agg
         as (               
                select country
                     , po_orderid
                     , po_sku
                     , sum(po_qty)                    as po_orderqty
                     , sum(po_price_localcurr)        as po_totalprice_local
                     , sum(po_itemdiscount_localcurr) as po_itemdiscount_localcurr
                  from #stg_sales_orders_stienda_uruguay_prepare  
              group by country
                     , po_orderid   
                     , po_sku        
         );  
         
        update #stg_sales_orders_stienda_uruguay_prepare         a
           set a.po_orderqty         = b.po_orderqty
             , a.po_totalprice_local = (c.po_totalprice_local * c.po_orderqty) - c.po_itemdiscount_localcurr
          from #stg_sales_orders_stienda_uruguay_prepare         a
          join #stg_sales_orders_stienda_uruguay_prepare_agg     b on b.country    = a.country
                                                                  and b.po_orderid = a.po_orderid
          join #stg_sales_orders_stienda_uruguay_prepare_sku_agg c on c.country    = a.country
                                                                  and c.po_orderid = a.po_orderid
                                                                  and c.po_sku     = a.po_sku;
                                                                          
        update #stg_sales_orders_stienda_uruguay_prepare a
           set po_itemdiscount_usd = a.po_itemdiscount_localcurr / cast(b.exchange_rate as decimal)
             , po_price_usd        = a.po_price_localcurr        / cast(b.exchange_rate as decimal)
             , po_totalprice_usd   = a.po_totalprice_local       / cast(b.exchange_rate as decimal)
          from #stg_sales_orders_stienda_uruguay_prepare  a
          join ow_lao.ft_ap2_exchange_rate                b on b.valid_from  = add_days(a.po_date, -1)
                                                           and b.to_currency = a.currency;  
                                            
-- Sales Channel                                            
        update #stg_sales_orders_stienda_uruguay_prepare a
           set a.channel                = b.global_channel
             , a.biz_type               = b.biz_type
             , a.audience_type          = b.audience_type
             , a.biz_type_ebi_hq        = b.biz_type_ebi
             , a.global_channel_ebi_hq  = b.global_channel_ebi
             , a.po_storename           = b.partner_level
             , a.customer_type          = b.customer_type
             , a.po_mobile_os           = b.po_mobile_os
          from #stg_sales_orders_stienda_uruguay_prepare a
          join ow_md.sales_channel                       b on lower(b.country)    = lower(a.country)
                                                          and lower(b.identifier) = lower(a.po_sitecode)
         where client_subsidiary_id    = 9
           and lower(b.plataform_type) = 'stienda';         
           
-- default po_device_type   
          update #stg_sales_orders_stienda_uruguay_prepare
             set po_devicetype = 'Web'
           where po_devicetype is null;     
           
-- default for global bi feed
    update #stg_sales_orders_stienda_uruguay_prepare
       set global_channel_ebi_hq = '3PD'   
         , biz_type_ebi_hq       = 'B2C'
     where global_channel_ebi_hq is null;     
     
-- default for sales channel
    update #stg_sales_orders_stienda_uruguay_prepare
       set channel       = 'eStore'   
         , biz_type      = '3PD'
         , audience_type = '3PD'   
     where channel is null;                       
     
     merge into ow_lao.ods_sales_control_tower_table                 a
          using #stg_sales_orders_stienda_uruguay_prepare            b on b.po_orderid  = a.po_orderid
                                                                      and b.po_sku      = a.po_sku
                                                                      and b.country     = a.country
                                                                      and b.po_sku_kit  = a.po_sku_kit
                                                                      and b.po_sitecode = a.po_sitecode
           when    matched then update  
                                   set a.po_date                          = b.po_date
                                     , a.podate_month                     = b.po_month
                                     , a.podate_year                      = b.po_year
                                     , a.country                          = b.country
                                     , a.subsidiary                       = b.subsidiary
                                     , a.currency                         = b.currency
                                     , a.po_lastupdate_date_hour          = b.po_lastupdate_date_hour
                                     , a.po_source_last_update_date       = b.po_source_last_update_date
                                     , a.po_orderid                       = b.po_orderid
                                     , a.po_seller_name                   = b.po_seller_name
                                     , a.po_prodname                      = b.po_prodname
                                     , a.po_store_name                    = b.po_store_name
                                     , a.po_storename                     = b.po_storename
                                     , a.channel                          = b.channel
                                     , a.biz_type                         = b.biz_type
                                     , a.audience_type                    = b.audience_type
                                     , a.po_status                        = b.po_status
                                     , a.po_internal_status               = b.po_internal_status
                                     , a.po_sku                           = b.po_sku
                                     , a.po_qty                           = b.po_qty
                                     , a.po_orderqty                      = b.po_orderqty
                                     , a.po_itemdiscount_localcurr        = b.po_itemdiscount_localcurr
                                     , a.po_itemdiscount_usd              = b.po_itemdiscount_usd
                                     , a.po_price_localcurr               = b.po_price_localcurr
                                     , a.po_price_usd                     = b.po_price_usd
                                     , a.po_plataform_datasource          = b.po_plataform_datasource   
                                     , a.po_source_insert_date            = b.po_source_insert_date
                                     , a.po_totalprice_usd                = b.po_totalprice_usd
                                     , a.po_totalprice_local              = b.po_totalprice_local
                                     , a.po_devicetype                    = b.po_devicetype
                                     , a.po_sku_kit                       = b.po_sku_kit
                                     , a.po_prodname_kit                  = b.po_prodname_kit
                                     , a.is_kit                           = b.is_kit 
                                     , a.country_cd                       = b.country_cd
                                     , a.biz_type_ebi_hq                  = b.biz_type_ebi_hq
                                     , a.global_channel_ebi_hq            = b.global_channel_ebi_hq
                                     , a.customer_type                    = b.customer_type
                                     , a.po_mobile_os                     = b.po_mobile_os
                                     , a.installment                      = b.installment
                                     , a.updated_datetime                 = current_timestamp
           when not matched then insert(
                                           po_date
                                         , podate_month
                                         , podate_year
                                         , country
                                         , subsidiary
                                         , currency
                                         , po_lastupdate_date_hour
                                         , po_source_last_update_date
                                         , po_orderid
                                         , po_seller_name
                                         , po_prodname                     
                                         , po_store_name
                                         , po_storename
                                         , channel
                                         , biz_type
                                         , audience_type
                                         , po_status
                                         , po_internal_status
                                         , po_sku
                                         , po_qty
                                         , po_orderqty
                                         , po_itemdiscount_localcurr
                                         , po_itemdiscount_usd
                                         , po_price_localcurr
                                         , po_price_usd
                                         , po_plataform_datasource
                                         , po_source_insert_date
                                         , po_totalprice_usd
                                         , po_totalprice_local
                                         , po_devicetype
                                         , po_sku_kit
                                         , po_prodname_kit
                                         , is_kit
                                         , country_cd
                                         , biz_type_ebi_hq
                                         , global_channel_ebi_hq
                                         , installment
                                         , samsung_care_order
                                         , samsung_care_eligibility
                                         , trade_in_eligibility
                                         , client_subsidiary_id
                                         , po_sitecode
                                         , customer_type
                                         , po_mobile_os
                                 )
                                 values(
                                           b.po_date
                                         , b.po_month
                                         , b.po_year
                                         , b.country
                                         , b.subsidiary
                                         , b.currency
                                         , b.po_lastupdate_date_hour
                                         , b.po_source_last_update_date
                                         , b.po_orderid
                                         , b.po_seller_name
                                         , b.po_prodname                     
                                         , b.po_store_name
                                         , b.po_storename
                                         , b.channel
                                         , b.biz_type
                                         , b.audience_type
                                         , b.po_status
                                         , b.po_internal_status
                                         , b.po_sku
                                         , b.po_qty
                                         , b.po_orderqty
                                         , b.po_itemdiscount_localcurr
                                         , b.po_itemdiscount_usd
                                         , b.po_price_localcurr
                                         , b.po_price_usd
                                         , b.po_plataform_datasource
                                         , b.po_source_insert_date
                                         , b.po_totalprice_usd
                                         , b.po_totalprice_local
                                         , b.po_devicetype
                                         , b.po_sku_kit
                                         , b.po_prodname_kit
                                         , b.is_kit
                                         , b.country_cd
                                         , b.biz_type_ebi_hq
                                         , b.global_channel_ebi_hq
                                         , b.installment 
                                         , 0
                                         , 0
                                         , 0
                                         , b.client_subsidiary_id
                                         , b.po_sitecode
                                         , b.customer_type
                                         , b.po_mobile_os
                                 ); 
                                 
    end