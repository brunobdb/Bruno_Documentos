
CREATE PROCEDURE OW_LAO.PROC_SALES_DEDUCTION_MONITORING_STATUS
LANGUAGE SQLSCRIPT
AS
BEGIN
    DECLARE DAY_OF_WEEK VARCHAR(20); 
    DECLARE LOAD_DATE_CHECK DATE;
    DECLARE V_COUNT_040 INT;
    DECLARE VALIDATION_DATE DATE;
    SELECT DAYNAME(CURRENT_DATE) INTO DAY_OF_WEEK FROM DUMMY;
    SELECT CURRENT_DATE INTO LOAD_DATE_CHECK FROM DUMMY;
    IF DAY_OF_WEEK = 'TUESDAY' THEN
        
      /*  -- VALIDATION IF RPA WORKS TODAY. 
        
        DECLARE V_COUNT_SALES_ORG INT;
        SELECT COUNT(DISTINCT SALES_ORG) INTO V_COUNT_SALES_ORG
        FROM OW_LAO.ODS_NERP_ZLMKC00040_CONDITION_PROGRESS_REPORT
        WHERE TO_DATE(LOAD_DATE) = CURRENT_DATE;
        UPDATE OW_LAO.FT_LAO_SALES_DEDUCTION_WEEKLY_MONITORING 
        SET MON = CASE 
                    WHEN V_COUNT_SALES_ORG > 0 THEN 'OK'
                    ELSE 'NOK'
                  END
        WHERE PROCESS = 'RPA Validation' 
          AND SUB_PROCESS = 'ZLMKC00040';
          
          
          
          
             -- VALIDATION IF RPA WORKS TODAY. 
        SELECT DISTINCT SALES_ORG
        FROM OW_LAO.ODS_NERP_ZLMKC00040_CONDITION_PROGRESS_REPORT
        WHERE TO_DATE(LOAD_DATE) = CURRENT_DATE;
        UPDATE OW_LAO.FT_LAO_SALES_DEDUCTION_WEEKLY_MONITORING 
        SET MON = CASE 
                    WHEN TO_DATE(LOAD_DATE) = CURRENT_DATE THEN 'OK'
                    ELSE 'NOK'
                  END
        WHERE PROCESS = 'Condition DB Extraction' 
        AND SUB_PROCESS = 'RPA ZLMKC00040 (Condition Progress Report)';
          
          
*/
    
    -- VALIDATION 040 IF RPA WORKS TODAY. 
    
    
        SELECT DISTINCT SALES_ORG
        FROM OW_LAO.ODS_NERP_ZLMKC00040_CONDITION_PROGRESS_REPORT
        WHERE TO_DATE(LOAD_DATE) = CURRENT_DATE;
        UPDATE OW_LAO.FT_LAO_SALES_DEDUCTION_WEEKLY_MONITORING 
        SET MON = CASE 
                    WHEN TO_DATE(LOAD_DATE) = CURRENT_DATE THEN 'OK'
                    ELSE 'NOK'
                  END, 
                  "390A" = 'OK',
                  "810A" = 'OK',
                  "810C" = 'OK',
                  "810D" = 'OK',
                  "810F" = 'OK',
                  "810J" = 'OK',
                  "810M" = 'OK',
                  "850A" = 'OK',
                  "813A" = 'OK',
                  "860A" = 'OK',
                  	UPDATE_DATE_390A= now(),
					UPDATE_DATE_810A= now(),	
					UPDATE_DATE_810C= now(),	
					UPDATE_DATE_810D= now(),	
					UPDATE_DATE_810F= now(),	
					UPDATE_DATE_810J= now(),	
					UPDATE_DATE_810M= now(),	
					UPDATE_DATE_850A= now(),	
					UPDATE_DATE_813A= now(),	
					UPDATE_DATE_860A= now()
        WHERE PROCESS = 'Condition DB Extraction' 
        AND SUB_PROCESS = 'RPA ZLMKC00040 (Condition Progress Report)';
    
       
      -- VALIDATION 040 BI TEAM.
        SELECT COUNT(*) INTO V_COUNT_040
        FROM (
            SELECT DISTINCT 
                T2.COMPANY_CODE,
                T2.BUSINESS_AREA,
                TO_DATE(T1.LOAD_DATE)
            FROM OW_LAO.ODS_NERP_ZLMKC00040_CONDITION_PROGRESS_REPORT T1
            INNER JOIN OW_LAO.INPUT_MAPPING_BIZ_AREA_SALES_DEDUCTION T2
                ON SUBSTRING(T1.SALES_ORG, 1, 2) = SUBSTRING(T2.BUSINESS_AREA, 1, 2)
            WHERE TO_DATE(T1.LOAD_DATE) = CURRENT_DATE
            	  AND T2.BUSINESS_AREA != '850C'
        ) AS VALIDATION_040;
        UPDATE OW_LAO.FT_LAO_SALES_DEDUCTION_WEEKLY_MONITORING 
        SET MON = CASE 
                    WHEN V_COUNT_040 = 10 THEN 'OK'
                    ELSE 'NOK'
                  END, 
                  "390A" = 'OK',
                  "810A" = 'OK',
                  "810C" = 'OK',
                  "810D" = 'OK',
                  "810F" = 'OK',
                  "810J" = 'OK',
                  "810M" = 'OK',
                  "850A" = 'OK',
                  "813A" = 'OK',
                  "860A" = 'OK',
                  	UPDATE_DATE_390A= now(),
					UPDATE_DATE_810A= now(),	
					UPDATE_DATE_810C= now(),	
					UPDATE_DATE_810D= now(),	
					UPDATE_DATE_810F= now(),	
					UPDATE_DATE_810J= now(),	
					UPDATE_DATE_810M= now(),	
					UPDATE_DATE_850A= now(),	
					UPDATE_DATE_813A= now(),	
					UPDATE_DATE_860A= now()
        WHERE PROCESS = 'Condition DB Extraction' 
        AND SUB_PROCESS = 'Data ingestion to SAP Hana - ZLMKC00040';
    END IF;
END;
