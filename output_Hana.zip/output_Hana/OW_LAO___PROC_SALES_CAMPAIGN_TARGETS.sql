CREATE PROCEDURE OW_LAO.PROC_SALES_CAMPAIGN_TARGETS(
	IN CONSULTA NVARCHAR(40),
	IN ID INTEGER
) LANGUAGE SQLSCRIPT AS
BEGIN
	/*-------------------------------------------------------------------------------------------------*/	
	-- Delete realizado no Job Talend para apagar os dados de arquivos que foram descartados ou atualizados
	IF :CONSULTA = 'EXEC_DELETE' THEN	
	BEGIN
		DELETE FROM OW_LAO.TMP_TARGETS_CAMPAIGN WHERE  ID = :ID;
		DELETE FROM OW_LAO.ODS_TARGETS_CAMPAIGN WHERE  ID = :ID;	
		DELETE FROM OW_LAO.DIM_EXCEL_TARGETS_CAMPAIGN WHERE ID = :ID;
	END;
	/*-------------------------------------------------------------------------------------------------*/	
	-- Update realizado no Job Talend para atualizar/apagar o satus do arquivo informando o erro na importação.
	ELSEIF :CONSULTA = 'EXEC_DELETE_2' THEN	
	BEGIN	
		UPDATE
			OW_LAO.DIM_EXCEL_TARGETS_CAMPAIGN
		SET
			STATUS 	= 'ERROR',
			DETAILS = 'ERROR'
		WHERE 
			ID =  :ID;
		
		DELETE FROM 
			OW_LAO.TMP_TARGETS_CAMPAIGN
		WHERE 
			ID =  :ID;	
	END;
	
	/*-------------------------------------------------------------------------------------------------*/	
	-- Delete realizado no Job Talend para reprocessar os dados do arquivo.
	ELSEIF :CONSULTA = 'EXEC_DELETE_3' THEN	
	BEGIN	
		DELETE FROM OW_LAO.TMP_TARGETS_CAMPAIGN WHERE ID = :ID;
		DELETE FROM OW_LAO.ODS_TARGETS_CAMPAIGN WHERE ID = :ID;	
	END;
	/*-------------------------------------------------------------------------------------------------*/	
	-- Execute do primeiro cursor de três. 
	--Cursor usado para realizar pivot na tabela OW_LAO.TMP_TARGETS_CAMPAIGN para OW_LAO.ODS_TARGETS_CAMPAIGN usando a visão de negocio Division
	ELSEIF :CONSULTA = 'EXEC_CURSOR_1' THEN		
	BEGIN
		--Declaração do cursor
	  	DECLARE CURSOR VISAO_FLOW FOR 
	  	SELECT * FROM OW_LAO.DIM_TARGETS_MAP_VISAO WHERE VISAO = 'Division'; 
	  	DECLARE V_NIVEL_1 	VARCHAR(255);
	  	DECLARE V_NIVEL_2 	VARCHAR(255);
	  	DECLARE V_ROW_CURRENT VARCHAR(255);
		-- limpa dados do target sobre o id
	  	DELETE FROM OW_LAO.ODS_TARGETS_CAMPAIGN WHERE ID = :ID;
		-- Percorendo tabela
	  	FOR ROW_VISAOFLOW AS VISAO_FLOW
	  	DO
			-- Atribuição de valor da linha para as variáveis   		
	  		V_NIVEL_1 		:= ROW_VISAOFLOW.NIVEL_1;
		  	V_NIVEL_2 		:= ROW_VISAOFLOW.NIVEL_2;
		  	V_ROW_CURRENT	:= ROW_VISAOFLOW.ROW_CURRENT;
		  
			-- Execução do SQL Dinamico	  	
			EXEC '
				INSERT INTO OW_LAO.ODS_TARGETS_CAMPAIGN (ID,CAMPAIGN_NAME,SUB,WEEK,"DAY",DIVISION,PRODUCT_GROUP,VALUE)
				SELECT 
					ID,CAMPAIGN_NAME,SUB,WEEK,"DAY",
					''' || :V_NIVEL_1 || '''		AS "DIVISION",
					''' || :V_NIVEL_2 || '''		AS "PRODUCT_GROUP", 
					'|| :V_ROW_CURRENT ||'			AS "VALUE"
				FROM 
					OW_LAO.TMP_TARGETS_CAMPAIGN
				WHERE 
					ID = '|| :ID ||';
			';
		END FOR;
		CLOSE VISAO_FLOW;
	END;
	/*-------------------------------------------------------------------------------------------------*/	
	-- Execute do segundo, cursor pivot na tabela OW_LAO.TMP_TARGETS_CAMPAIGN para OW_LAO.ODS_TARGETS_CAMPAIGN usando a visão de negocio Channels
	ELSEIF :CONSULTA = 'EXEC_CURSOR_2' THEN				
	BEGIN		
		--Declaração do cursor
	  	DECLARE CURSOR VISAO_FLOW FOR 
	  	SELECT * FROM OW_LAO.DIM_TARGETS_MAP_VISAO WHERE VISAO = 'Channels';
		--Declaração das variáveis
	  	DECLARE V_NIVEL_1 	VARCHAR(255);
	  	DECLARE V_NIVEL_2 	VARCHAR(255);
	    DECLARE V_NIVEL_3 	VARCHAR(255);
	  	DECLARE V_ROW_CURRENT VARCHAR(255);
		-- Percorendo tabela
	  	FOR ROW_VISAOFLOW AS VISAO_FLOW
	  	DO
			-- Atribuição de valor da linha para as variáveis   		
	  		V_NIVEL_1 		:= ROW_VISAOFLOW.NIVEL_1;
		  	V_NIVEL_2 		:= ROW_VISAOFLOW.NIVEL_2;
		  	V_NIVEL_3 		:= ROW_VISAOFLOW.NIVEL_3;
		  	V_ROW_CURRENT	:= ROW_VISAOFLOW.ROW_CURRENT;
		  
			-- Execução do SQL Dinamico	  	
			EXEC '
				INSERT INTO OW_LAO.ODS_TARGETS_CAMPAIGN (ID,CAMPAIGN_NAME,SUB,WEEK,DAY,BIZ_TYPE,AUDIENCE_TYPE,DEVICE_TYPE,VALUE)
				SELECT 
					ID,CAMPAIGN_NAME,SUB,WEEK,"DAY",
					''' || :V_NIVEL_1 || '''		AS "BIZ_TYPE",
					''' || :V_NIVEL_2 || '''		AS "AUDIENCE_TYPE", 
					''' || :V_NIVEL_3 || '''		AS "DEVICE_TYPE",
					'|| :V_ROW_CURRENT ||'			AS "VALUE"
				FROM 
					OW_LAO.TMP_TARGETS_CAMPAIGN
				WHERE 
					ID = '|| :ID ||';
			';
		END FOR; 
		CLOSE VISAO_FLOW;
	END;		
	
	/*-------------------------------------------------------------------------------------------------*/	
	-- Execute do terceiro cursor, pivot na tabela OW_LAO.TMP_TARGETS_CAMPAIGN para OW_LAO.ODS_TARGETS_CAMPAIGN usando a visão de negocio CEJ_KPIs
	ELSEIF :CONSULTA = 'EXEC_CURSOR_3' THEN	
	BEGIN
		--Declaração do cursor
	  	DECLARE CURSOR VISAO_FLOW FOR 
	  	SELECT * FROM OW_LAO.DIM_TARGETS_MAP_VISAO WHERE VISAO = 'CEJ_KPIs';
		--Declaração das variáveis
	  	DECLARE V_NIVEL_1 	VARCHAR(255);
	  	DECLARE V_NIVEL_2 	VARCHAR(255);
	    DECLARE V_NIVEL_3 	VARCHAR(255);
	  	DECLARE V_ROW_CURRENT VARCHAR(255);
		-- Percorendo tabela
	  	FOR ROW_VISAOFLOW AS VISAO_FLOW
	  	DO
			-- Atribuição de valor da linha para as variáveis   		
	  		V_NIVEL_1 		:= ROW_VISAOFLOW.NIVEL_1;
		  	V_NIVEL_2 		:= ROW_VISAOFLOW.NIVEL_2;
		  	V_NIVEL_3 		:= ROW_VISAOFLOW.NIVEL_3;
		  	V_ROW_CURRENT	:= ROW_VISAOFLOW.ROW_CURRENT;
		  
			-- Execução do SQL Dinamico	  	
			EXEC '
				INSERT INTO OW_LAO.ODS_TARGETS_CAMPAIGN (ID,CAMPAIGN_NAME,SUB,WEEK,DAY,CEJ_KPIS,VALUE)
				SELECT 
					ID,CAMPAIGN_NAME,SUB,WEEK,"DAY",
					''' || :V_NIVEL_1 || '''		AS "CEJ_KPIs",
					'|| :V_ROW_CURRENT ||'			AS "VALUE"
				FROM 
					OW_LAO.TMP_TARGETS_CAMPAIGN
				WHERE 
					ID = '|| :ID ||';
			';
		END FOR; 
		CLOSE VISAO_FLOW;
	END;
	/*-------------------------------------------------------------------------------------------------*/	
	-- Execute de update para tratar o TEXTO null para o TYPE null do sql, processo será revisto para que esse procedimento não seja necessário
	ELSEIF :CONSULTA = 'Adjust_table' THEN	
	BEGIN
		--Update que precisa ser elaborado na raiz
		UPDATE 
			OW_LAO.ODS_TARGETS_CAMPAIGN 
		SET	
			PRODUCT_GROUP = NULL
		FROM 
			OW_LAO.ODS_TARGETS_CAMPAIGN 
		WHERE
			PRODUCT_GROUP = 'NULL';
		
		--Realiza ajuste manual
		UPDATE 
			OW_LAO.ODS_TARGETS_CAMPAIGN 
		SET 
			AUDIENCE_TYPE = NULL
		--SELECT 
		--	*
		FROM 
			OW_LAO.ODS_TARGETS_CAMPAIGN 
		WHERE 
			AUDIENCE_TYPE = 'NULL';
			
		UPDATE 
			OW_LAO.ODS_TARGETS_CAMPAIGN 
		SET 
			DEVICE_TYPE = NULL	
		--SELECT
		--	*
		FROM 
			OW_LAO.ODS_TARGETS_CAMPAIGN 
		WHERE 
			DEVICE_TYPE = 'NULL';	
	END;
	/*-------------------------------------------------------------------------------------------------*/	
	--Esta procedure consulta a tabela ODS das campanhas e recolhe as informaçãos das vendas da visão Division do período da campanha e do período anterior(-1 ano)
	ELSEIF :CONSULTA = 'TARGET_PRODUCTS' THEN			
	BEGIN
		-- Criação da tabela temporaria recolhendo os dados das vendas do período corrente 		
		TRUNCATE TABLE	OW_LAO.TMP_TARGET_PRODUCTS_CURRENT_YEAR;
		INSERT INTO OW_LAO.TMP_TARGET_PRODUCTS_CURRENT_YEAR		
		SELECT
			A.ID_CAMPAIGN,
			A.CAMPAIGN_TAG,
			A.SUBSIDIARY,
			CAST(RIGHT(ISOWEEK(A.PO_DATE),2) AS integer) 							AS  "WEEK",
			TO_NVARCHAR(A.PO_DATE,'YYYY-MM-DD')  		AS  "DATE",
			A.CAMPAIGN_DAY ,
			A.PO_STATUS,
			CASE 
				WHEN A.DIVISION NOT IN ('MX','DA','VD') THEN 'OTHERS'
				WHEN A.DIVISION IS NULL 	 			THEN 'OTHERS'
				ELSE A.DIVISION
			END AS DIVISION,
			CASE 
				WHEN A.DIVISION = 'VD' AND (A.PRODUCT_GROUP =  'TV' OR A.PRODUCT_GROUP =  'AV') THEN 'TV/AV'
				WHEN A.DIVISION = 'VD' AND (A.PRODUCT_GROUP <> 'TV' OR A.PRODUCT_GROUP <> 'AV') THEN 'EB'  
				ELSE NULL
			END 										AS "PRODUCT_GROUP",
			SUM(A.EBI_NETREVENUE)						AS "EBI_NETREVENUE",
			SUM(A.PO_TOTALPRICE_USD) 					AS "PO_TOTALPRICE_USD",
			SUM(A.NET_REVENUE)							AS "NET_REVENUE",
			SUM(A.PO_QTY)								AS "PO_QTY"
		FROM 
			OW_LAO.ODS_SALES_CAMPAIGN A
		WHERE 
			A.PREVIOUS_YEAR =  FALSE 
--			AND A.PO_STATUS = 'Approved'
			AND (A.PO_STATUS = 'Approved' OR (SUBSIDIARY = 'SELA' AND A.PO_STATUS IN ('Approved','Pending')))			
--			AND A.DIVISION IN ('MX','DA','VD')
			AND A.BIZ_TYPE IN ('B2C','EPP','SMB','3PD','APP')
		GROUP BY 
			A.ID_CAMPAIGN,
			A.SUBSIDIARY,
			A.CAMPAIGN_DAY,
			CAST(RIGHT(ISOWEEK(A.PO_DATE),2) AS integer),
			TO_NVARCHAR(A.PO_DATE,'YYYY-MM-DD'),
			A.PO_STATUS,
			A.CAMPAIGN_TAG,
			CASE 
				WHEN A.DIVISION NOT IN ('MX','DA','VD') THEN 'OTHERS'
				WHEN A.DIVISION IS NULL 	 			THEN 'OTHERS'
				ELSE A.DIVISION
			END, 
			CASE 
				WHEN A.DIVISION = 'VD' AND (A.PRODUCT_GROUP =  'TV' OR A.PRODUCT_GROUP =  'AV') THEN 'TV/AV'
				WHEN A.DIVISION = 'VD' AND (A.PRODUCT_GROUP <> 'TV' OR A.PRODUCT_GROUP <> 'AV') THEN 'EB'  
				ELSE NULL
			END 
--		ORDER BY
--			A.CAMPAIGN_TAG,
--			A.SUBSIDIARY,
--			TO_NVARCHAR(A.PO_DATE,'YYYY-MM-DD'),
--			A.CAMPAIGN_DAY,
--			A.DIVISION
		;
	
		/*-------------------------------------------------------------------------------------------------*/	
		-- Criação da tabela temporaria recolhendo os dados das vendas do período anterior
		TRUNCATE TABLE	OW_LAO.TMP_TARGET_PRODUCTS_PREVIOUS_YEAR;
		INSERT INTO OW_LAO.TMP_TARGET_PRODUCTS_PREVIOUS_YEAR		
		SELECT
			A.ID_CAMPAIGN,
			A.CAMPAIGN_TAG,
			A.SUBSIDIARY,
			CAST(RIGHT(ISOWEEK(A.PO_DATE),2) AS integer) 						AS  "WEEK",
			TO_NVARCHAR(A.PO_DATE,'YYYY-MM-DD')  	AS  "DATE",
			A.CAMPAIGN_DAY,
			A.PO_STATUS,
			CASE 
				WHEN A.DIVISION NOT IN ('MX','DA','VD') THEN 'OTHERS'
				WHEN A.DIVISION IS NULL 	 			THEN 'OTHERS'
				ELSE A.DIVISION
			END AS DIVISION,
			CASE 
				WHEN A.DIVISION = 'VD' AND (A.PRODUCT_GROUP =  'TV' OR A.PRODUCT_GROUP =  'AV') THEN 'TV/AV'
				WHEN A.DIVISION = 'VD' AND (A.PRODUCT_GROUP <> 'TV' OR A.PRODUCT_GROUP <> 'AV') THEN 'EB'  
				ELSE NULL
			END 						AS "PRODUCT_GROUP",
			SUM(A.EBI_NETREVENUE)		AS "EBI_NETREVENUE_PREVIOUS_YEAR",
			SUM(A.PO_TOTALPRICE_USD) 	AS "PO_TOTALPRICE_USD_PREVIOUS_YEAR",
			SUM(A.NET_REVENUE)			AS "NET_REVENUE_PREVIOUS_YEAR",
			SUM(A.PO_QTY)				AS "PO_QTY_PREVIOUS_YEAR"
		FROM 
			OW_LAO.ODS_SALES_CAMPAIGN A
		WHERE 
			A.PREVIOUS_YEAR = TRUE 
--			AND A.PO_STATUS = 'Approved'
			AND (A.PO_STATUS = 'Approved' OR (SUBSIDIARY = 'SELA' AND A.PO_STATUS IN ('Approved','Pending')))			
--			AND A.DIVISION IN ('MX','DA','VD')
			AND A.BIZ_TYPE IN ('B2C','EPP','SMB','3PD','APP')
		--	AND CAMPAIGN_TAG =  'Youmake'
		--	AND SUBSIDIARY = 'SEDA'
		--	AND A.CAMPAIGN_DAY = 1
		GROUP BY 
			A.ID_CAMPAIGN,
			A.SUBSIDIARY,
			A.CAMPAIGN_DAY ,
			CAST(RIGHT(ISOWEEK(A.PO_DATE),2) AS integer),
			TO_NVARCHAR(A.PO_DATE,'YYYY-MM-DD'),
			A.PO_STATUS,
			A.CAMPAIGN_TAG,
			CASE 
				WHEN A.DIVISION NOT IN ('MX','DA','VD') THEN 'OTHERS'
				WHEN A.DIVISION IS NULL 	 			THEN 'OTHERS'
				ELSE A.DIVISION
			END, 			
			CASE 
				WHEN A.DIVISION = 'VD' AND (A.PRODUCT_GROUP =  'TV' OR A.PRODUCT_GROUP =  'AV') THEN 'TV/AV'
				WHEN A.DIVISION = 'VD' AND (A.PRODUCT_GROUP <> 'TV' OR A.PRODUCT_GROUP <> 'AV') THEN 'EB'  
				ELSE NULL
			END 
--		ORDER BY
--			A.CAMPAIGN_TAG,
--			A.SUBSIDIARY,
--			TO_NVARCHAR(A.PO_DATE,'YYYY-MM-DD'),
--			A.CAMPAIGN_DAY,
--			A.DIVISION 
		;
	
		/*-------------------------------------------------------------------------------------------------*/	
		-- Criação da tabela final de divison(PRODUCTS) relacionado com os targets, dados do período atual da campanha e dados de venda do período anterior  
		TRUNCATE TABLE	OW_LAO.ODS_CAMPAIGN_TARGET_PRODUCTS;
		INSERT INTO OW_LAO.ODS_CAMPAIGN_TARGET_PRODUCTS		
		SELECT
			B.CAMPAIGN_NAME,
			B.SUB,
			B.WEEK,
			A.CAMPAIGN_DAY,
			TO_NVARCHAR(B.DAY,'YYYY/MM/DD') AS "DATE",
			TO_NVARCHAR(A.DATE_PREVIOUS_YEAR,'YYYY/MM/DD') AS "DATE_PREVIOUS_YEAR",
			PO_STATUS,
			--
			B.DIVISION,
			B.PRODUCT_GROUP,
			--
			B.VALUE AS "TARGET",
			PO_QTY,
			A.PO_QTY_PREVIOUS_YEAR,
			EBI_NETREVENUE,
			A.EBI_NETREVENUE_PREVIOUS_YEAR,
			PO_TOTALPRICE_USD,
			A.PO_TOTALPRICE_USD_PREVIOUS_YEAR,
			NET_REVENUE,
			A.NET_REVENUE_PREVIOUS_YEAR
		FROM(
			SELECT 
				CAMPAIGN_TAG, SUBSIDIARY, WEEK, DATE, DATE_PREVIOUS_YEAR, CAMPAIGN_DAY, PO_STATUS, DIVISION, PRODUCT_GROUP,
				SUM(D.EBI_NETREVENUE)								AS EBI_NETREVENUE,
				SUM(D.PO_TOTALPRICE_USD) 							AS PO_TOTALPRICE_USD,
				SUM(D.NET_REVENUE) 									AS NET_REVENUE,
				SUM(D.PO_QTY)										AS PO_QTY,
				IFNULL(SUM(D.EBI_NETREVENUE_PREVIOUS_YEAR),0) 		AS EBI_NETREVENUE_PREVIOUS_YEAR,
				IFNULL(SUM(D.PO_TOTALPRICE_USD_PREVIOUS_YEAR),0)	AS PO_TOTALPRICE_USD_PREVIOUS_YEAR,
				IFNULL(SUM(D.NET_REVENUE_PREVIOUS_YEAR)	,0)			AS NET_REVENUE_PREVIOUS_YEAR,
				IFNULL(SUM(D.PO_QTY_PREVIOUS_YEAR)	,0)				AS PO_QTY_PREVIOUS_YEAR
			FROM(
				SELECT 
					A.CAMPAIGN_TAG,
					A.SUBSIDIARY,
					A.WEEK,
					A.DATE,
					ADD_DAYS(TO_DATE(C.INITIAL_DATE_LY),A.CAMPAIGN_DAY-1) 		AS DATE_PREVIOUS_YEAR,
					A.CAMPAIGN_DAY,
					A.PO_STATUS,
					A.DIVISION,
					A.PRODUCT_GROUP,
					SUM(A.EBI_NETREVENUE)										AS EBI_NETREVENUE,
					SUM(A.PO_TOTALPRICE_USD) 									AS PO_TOTALPRICE_USD,
					SUM(A.NET_REVENUE) 											AS NET_REVENUE,
					SUM(A.PO_QTY)												AS PO_QTY,
					IFNULL(SUM(B.EBI_NETREVENUE_PREVIOUS_YEAR),0) 				AS EBI_NETREVENUE_PREVIOUS_YEAR,
					IFNULL(SUM(B.PO_TOTALPRICE_USD_PREVIOUS_YEAR),0)			AS PO_TOTALPRICE_USD_PREVIOUS_YEAR,
					IFNULL(SUM(B.NET_REVENUE_PREVIOUS_YEAR)	,0)					AS NET_REVENUE_PREVIOUS_YEAR,
					IFNULL(SUM(B.PO_QTY_PREVIOUS_YEAR)	,0)						AS PO_QTY_PREVIOUS_YEAR
				FROM 
					 OW_LAO.TMP_TARGET_PRODUCTS_CURRENT_YEAR	 	A
				LEFT JOIN
					 OW_LAO.TMP_TARGET_PRODUCTS_PREVIOUS_YEAR		B	
				ON
					A.SUBSIDIARY 					= B.SUBSIDIARY
					AND A.CAMPAIGN_DAY 				= B.CAMPAIGN_DAY 
					AND A.PO_STATUS 				= B.PO_STATUS
					AND A.ID_CAMPAIGN				= B.ID_CAMPAIGN
					AND A.DIVISION 					= B.DIVISION
					AND IFNULL(A.PRODUCT_GROUP,'') 	= IFNULL(B.PRODUCT_GROUP,'')
				JOIN 
					OW_LAO.DIM_CAMPAIGN_NAME C
				ON
					A.ID_CAMPAIGN = C.ID_CAMPAIGN 				
				GROUP BY 
					A.CAMPAIGN_TAG,
					A.SUBSIDIARY,
					A.WEEK,
					A.DATE,
					B.DATE,
					A.CAMPAIGN_DAY,
					C.INITIAL_DATE_LY,
					A.PO_STATUS,
					A.DIVISION,
					A.PRODUCT_GROUP	
			) AS D
			GROUP BY 
				CAMPAIGN_TAG, SUBSIDIARY, WEEK, DATE, DATE_PREVIOUS_YEAR, CAMPAIGN_DAY, PO_STATUS, DIVISION, PRODUCT_GROUP
		) AS A
		RIGHT JOIN
			OW_LAO.ODS_TARGETS_CAMPAIGN B
		ON
			A.SUBSIDIARY					= B.SUB
			AND A.CAMPAIGN_TAG				= B.CAMPAIGN_NAME
			AND A.WEEK						= B.WEEK
			AND A.DATE						= TO_NVARCHAR(B.DAY,'YYYY-MM-DD')
			AND A.DIVISION					= B.DIVISION
			AND IFNULL(A.PRODUCT_GROUP,'')  = IFNULL(B.PRODUCT_GROUP,'') 
		WHERE
			B.DIVISION IS NOT NULL;	
--			AND B.DIVISION IN ('MX','DA','VD');
		--	AND A.CAMPAIGN_TAG = 'Father''s'
		--	AND A.SUBSIDIARY = 'SEM'
		--	AND A."Week" = 24
--			ORDER BY 
--				B.CAMPAIGN_NAME,
--				A.SUBSIDIARY,
--				DATE,
--				A.DIVISION;	
	-- Criação da tabela para ajuste do target do grupo de DIVISION que não teve o target definido para Approved/Pending. O calculado de distribuição do target é definido de acordo com o percentual do que foi realizado: NET_REVENUE / TARGET. 	
		--
		--Identifica onde é necessário realizar o update		
		CREATE LOCAL TEMPORARY TABLE #STG_PRODUCTS_PO_STATUS_FILTER_ADJUST_1 AS (	
			SELECT
				CAMPAIGN_NAME,
				DATE,
				DIVISION,
				COUNT(*)
			FROM 
				OW_LAO.ODS_CAMPAIGN_TARGET_PRODUCTS B
			WHERE 
				SUB = 'SELA'
				AND PO_STATUS IS NOT NULL
				AND PRODUCT_GROUP IS NULL
			GROUP BY	
				CAMPAIGN_NAME,
				DATE,
				DIVISION
			HAVING
				COUNT(*) = 2 	
		);	
		/*-------------------------------------------------------------------------------------------------*/	
		-- 
		CREATE LOCAL TEMPORARY TABLE #STG_PRODUCTS_PO_STATUS_ADJUST_APPROVED_1 AS (			
			SELECT
				CAMPAIGN_NAME,SUB,"DATE",PO_STATUS,DIVISION,TARGET,NET_REVENUE
			FROM 
				OW_LAO.ODS_CAMPAIGN_TARGET_PRODUCTS A
			WHERE 
				SUB = 'SELA'
				AND PRODUCT_GROUP IS NULL
				AND PO_STATUS = 'Approved'
				AND TARGET <> 0
				AND EXISTS (
					--
					SELECT 
						*
					FROM 
						#STG_PRODUCTS_PO_STATUS_FILTER_ADJUST_1 B
					WHERE
						--JOIN ON
						A.CAMPAIGN_NAME 	= B.CAMPAIGN_NAME
						AND A.DATE			= B.DATE			
						AND A.DIVISION		= B.DIVISION 
				)
		);	
		/*-------------------------------------------------------------------------------------------------*/	
		-- 
		CREATE LOCAL TEMPORARY TABLE #STG_PRODUCTS_PO_STATUS_ADJUST_PENDING_1 AS (	
			SELECT
				CAMPAIGN_NAME,SUB,"DATE",PO_STATUS,DIVISION,TARGET,NET_REVENUE
			FROM 
				OW_LAO.ODS_CAMPAIGN_TARGET_PRODUCTS A
			WHERE 
				SUB = 'SELA'
				AND PRODUCT_GROUP IS NULL
				AND PO_STATUS = 'Pending'
				AND TARGET <> 0
				AND EXISTS (
					--
					SELECT 
						*
					FROM 
						#STG_PRODUCTS_PO_STATUS_FILTER_ADJUST_1 B
					WHERE
						--JOIN ON
						A.CAMPAIGN_NAME 	= B.CAMPAIGN_NAME
						AND A.DATE			= B.DATE			
						AND A.DIVISION		= B.DIVISION 
				)	
		);
		/*-------------------------------------------------------------------------------------------------*/	
		-- 
		CREATE LOCAL TEMPORARY TABLE #STG_PRODUCTS_PO_STATUS_ADJUSTED_1 AS (	
			SELECT 
				A.CAMPAIGN_NAME,
				A.SUB,
				A.DATE,
				A.DIVISION, 		
				A.PO_STATUS AS PO_STATUS_APPROVED,
				B.PO_STATUS AS PO_STATUS_PENDING,
		--		A.TARGET,
		--		B.TARGET,
		--		A.NET_REVENUE,
		--		B.NET_REVENUE,
				CASE 
					WHEN IFNULL(A.NET_REVENUE,0) = 0 AND  IFNULL(B.NET_REVENUE,0) = 0 										THEN A.TARGET / 2 											-- Caso não tenha sido realizada nenhuma venda, o target é dividido entre app web
					WHEN IFNULL(A.NET_REVENUE,0) = 0 																		THEN 0														-- Não houve vendas em app, target é zero
					WHEN IFNULL(B.NET_REVENUE,0) = 0 																		THEN A.TARGET												-- Não houve vendas em web, 100% do target é alocado em app	 											
					WHEN IFNULL(A.NET_REVENUE,0) / A.TARGET >= 0.5 AND IFNULL(B.NET_REVENUE,0) / A.TARGET >= 0.5  			THEN A.TARGET / 2  											-- Se as vendas de App e Web juntas foram maior ou igual a 50% o target é dividido 
					WHEN IFNULL(A.NET_REVENUE,0) < IFNULL(B.NET_REVENUE,0)  												THEN     (IFNULL(A.NET_REVENUE,0) / A.TARGET)  * A.TARGET	-- As vendas de APP foram menor que web, então é calculado o percentual de net revenue APP sobre o target
					WHEN IFNULL(A.NET_REVENUE,0) > IFNULL(B.NET_REVENUE,0) 													THEN (1 -(IFNULL(B.NET_REVENUE,0) / A.TARGET)) * A.TARGET 	-- AS vendas de APP foram maior que web e o net_revenue pode ter passado o total do target, então é calculado: (percentual de Web - 100%). O resultado é o percentual de app 
				END AS "TARGET_APPROVED",
				CASE 
					WHEN IFNULL(A.NET_REVENUE,0) = 0 AND  IFNULL(B.NET_REVENUE,0) = 0 										THEN A.TARGET / 2											-- Caso não tenha sido realizada nenhuma venda, o target é dividido entre app web
					WHEN IFNULL(B.NET_REVENUE,0) = 0 																		THEN 0														-- Não houve vendas em web, target é zero
					WHEN IFNULL(A.NET_REVENUE,0) = 0 																		THEN A.TARGET												-- Não houve vendas em app, 100% do target é alocado em web	
					WHEN IFNULL(A.NET_REVENUE,0) / A.TARGET >= 0.5 AND IFNULL(B.NET_REVENUE,0) / A.TARGET >= 0.5 			THEN A.TARGET / 2 											-- Se as vendas de App e Web juntas foram maior ou igual a 50% o target é dividido
					WHEN IFNULL(B.NET_REVENUE,0) < IFNULL(A.NET_REVENUE,0)  												THEN      (IFNULL(B.NET_REVENUE,0) / A.TARGET)  * A.TARGET	-- As vendas de web foram menor que app, então é calculado o percentual de net revenue web sobre o target
					WHEN IFNULL(B.NET_REVENUE,0) > IFNULL(A.NET_REVENUE,0) 													THEN (1 - (IFNULL(A.NET_REVENUE,0) / A.TARGET)) * A.TARGET	-- AS vendas de web foram maior que app e o net_revenue pode ter passado o total do target, então é calculado: (percentual de app - 100%). O resultado é o percentual de web 
				END AS "TARGET_PENDING"		
			FROM 
				#STG_PRODUCTS_PO_STATUS_ADJUST_APPROVED_1 A
			JOIN
				#STG_PRODUCTS_PO_STATUS_ADJUST_PENDING_1 	B
			ON
				A.CAMPAIGN_NAME 		= B.CAMPAIGN_NAME
				AND A.SUB				= B.SUB
				AND A.DATE 				= B.DATE
				AND A.DIVISION			= B.DIVISION 
			--	AND A.PO_STATUS 		= B.PO_STATUS
		);
		/*-------------------------------------------------------------------------------------------------*/	
		-- 
		UPDATE
			OW_LAO.ODS_CAMPAIGN_TARGET_PRODUCTS A
		SET
			A.TARGET = B.TARGET
		FROM 
			OW_LAO.ODS_CAMPAIGN_TARGET_PRODUCTS A
		JOIN(
			SELECT 
				CAMPAIGN_NAME, SUB, DATE, DIVISION , PO_STATUS_APPROVED AS PO_STATUS , TARGET_APPROVED AS TARGET
			FROM 
				#STG_PRODUCTS_PO_STATUS_ADJUSTED_1 		
		UNION ALL
			SELECT 
				CAMPAIGN_NAME, SUB, DATE, DIVISION , PO_STATUS_PENDING AS PO_STATUS , TARGET_PENDING AS TARGET
			FROM 
				#STG_PRODUCTS_PO_STATUS_ADJUSTED_1
		) AS B ON 
			A.CAMPAIGN_NAME 		= B.CAMPAIGN_NAME
			AND A.SUB				= B.SUB
			AND A.DATE 				= B.DATE
			AND A.DIVISION			= B.DIVISION 
			AND A.PO_STATUS 		= B.PO_STATUS;	
		-- Criação da tabela para ajuste do target do grupo de DIVISION/PRODUCT_GROUP que não teve o target definido para Approved/Pending. O calculado de distribuição do target é definido de acordo com o percentual do que foi realizado: NET_REVENUE / TARGET. 	
		--
		--Identifica onde é necessário realizar o update		
		CREATE LOCAL TEMPORARY TABLE #STG_PRODUCTS_PO_STATUS_FILTER_ADJUST_2 AS (	
			SELECT
				CAMPAIGN_NAME,
				DATE,
				DIVISION,
				PRODUCT_GROUP,
				COUNT(*)
			FROM 
				OW_LAO.ODS_CAMPAIGN_TARGET_PRODUCTS B
			WHERE 
				SUB = 'SELA'
				AND PO_STATUS IS NOT NULL
				AND PRODUCT_GROUP IS NOT NULL
			GROUP BY	
				CAMPAIGN_NAME,
				DATE,
				DIVISION,
				PRODUCT_GROUP
			HAVING
				COUNT(*) = 2 	
		);	
		/*-------------------------------------------------------------------------------------------------*/	
		-- 
		CREATE LOCAL TEMPORARY TABLE #STG_PRODUCTS_PO_STATUS_ADJUST_APPROVED_2 AS (			
			SELECT
				CAMPAIGN_NAME,SUB,"DATE",PO_STATUS,DIVISION,PRODUCT_GROUP,TARGET,NET_REVENUE
			FROM 
				OW_LAO.ODS_CAMPAIGN_TARGET_PRODUCTS A
			WHERE 
				SUB = 'SELA'
				AND PRODUCT_GROUP IS NOT NULL
				AND PO_STATUS = 'Approved'
				AND TARGET <> 0
				AND EXISTS (
					--
					SELECT 
						*
					FROM 
						#STG_PRODUCTS_PO_STATUS_FILTER_ADJUST_2 B
					WHERE
						--JOIN ON
						A.CAMPAIGN_NAME 		= B.CAMPAIGN_NAME
						AND A.DATE				= B.DATE			
						AND A.DIVISION			= B.DIVISION 
						AND A.PRODUCT_GROUP		= B.PRODUCT_GROUP 
				)	
		);	
		/*-------------------------------------------------------------------------------------------------*/	
		-- 
		CREATE LOCAL TEMPORARY TABLE #STG_PRODUCTS_PO_STATUS_ADJUST_PENDING_2 AS (	
			SELECT
				CAMPAIGN_NAME,SUB,"DATE",PO_STATUS,DIVISION,PRODUCT_GROUP,TARGET,NET_REVENUE
			FROM 
				OW_LAO.ODS_CAMPAIGN_TARGET_PRODUCTS A
			WHERE 
				SUB = 'SELA'
				AND PRODUCT_GROUP IS NOT NULL
				AND PO_STATUS = 'Pending'
				AND TARGET <> 0
				AND EXISTS (
					--
					SELECT 
						*
					FROM 
						#STG_PRODUCTS_PO_STATUS_FILTER_ADJUST_2 B
					WHERE
						--JOIN ON
						A.CAMPAIGN_NAME 	= B.CAMPAIGN_NAME
						AND A.DATE			= B.DATE			
						AND A.DIVISION		= B.DIVISION 
						AND A.PRODUCT_GROUP		= B.PRODUCT_GROUP 
				)	
		);
		/*-------------------------------------------------------------------------------------------------*/	
		-- 
		CREATE LOCAL TEMPORARY TABLE #STG_PRODUCTS_PO_STATUS_ADJUSTED_2 AS (	
			SELECT 
				A.CAMPAIGN_NAME,
				A.SUB,
				A.DATE,
				A.DIVISION, 
				A.PRODUCT_GROUP,
				A.PO_STATUS AS PO_STATUS_APPROVED,
				B.PO_STATUS AS PO_STATUS_PENDING,
		--		A.TARGET,
		--		B.TARGET,
		--		A.NET_REVENUE,
		--		B.NET_REVENUE,
				CASE 
					WHEN IFNULL(A.NET_REVENUE,0) = 0 AND  IFNULL(B.NET_REVENUE,0) = 0 										THEN A.TARGET / 2 											-- Caso não tenha sido realizada nenhuma venda, o target é dividido entre app web
					WHEN IFNULL(A.NET_REVENUE,0) = 0 																		THEN 0														-- Não houve vendas em app, target é zero
					WHEN IFNULL(B.NET_REVENUE,0) = 0 																		THEN A.TARGET												-- Não houve vendas em web, 100% do target é alocado em app	 											
					WHEN IFNULL(A.NET_REVENUE,0) / A.TARGET >= 0.5 AND IFNULL(B.NET_REVENUE,0) / A.TARGET >= 0.5  			THEN A.TARGET / 2  											-- Se as vendas de App e Web juntas foram maior ou igual a 50% o target é dividido 
					WHEN IFNULL(A.NET_REVENUE,0) < IFNULL(B.NET_REVENUE,0)  												THEN     (IFNULL(A.NET_REVENUE,0) / A.TARGET)  * A.TARGET	-- As vendas de APP foram menor que web, então é calculado o percentual de net revenue APP sobre o target
					WHEN IFNULL(A.NET_REVENUE,0) > IFNULL(B.NET_REVENUE,0) 													THEN (1 -(IFNULL(B.NET_REVENUE,0) / A.TARGET)) * A.TARGET 	-- AS vendas de APP foram maior que web e o net_revenue pode ter passado o total do target, então é calculado: (percentual de Web - 100%). O resultado é o percentual de app 
				END AS "TARGET_APPROVED",
				CASE 
					WHEN IFNULL(A.NET_REVENUE,0) = 0 AND  IFNULL(B.NET_REVENUE,0) = 0 										THEN A.TARGET / 2											-- Caso não tenha sido realizada nenhuma venda, o target é dividido entre app web
					WHEN IFNULL(B.NET_REVENUE,0) = 0 																		THEN 0														-- Não houve vendas em web, target é zero
					WHEN IFNULL(A.NET_REVENUE,0) = 0 																		THEN A.TARGET												-- Não houve vendas em app, 100% do target é alocado em web	
					WHEN IFNULL(A.NET_REVENUE,0) / A.TARGET >= 0.5 AND IFNULL(B.NET_REVENUE,0) / A.TARGET >= 0.5 			THEN A.TARGET / 2 											-- Se as vendas de App e Web juntas foram maior ou igual a 50% o target é dividido
					WHEN IFNULL(B.NET_REVENUE,0) < IFNULL(A.NET_REVENUE,0)  												THEN      (IFNULL(B.NET_REVENUE,0) / A.TARGET)  * A.TARGET	-- As vendas de web foram menor que app, então é calculado o percentual de net revenue web sobre o target
					WHEN IFNULL(B.NET_REVENUE,0) > IFNULL(A.NET_REVENUE,0) 													THEN (1 - (IFNULL(A.NET_REVENUE,0) / A.TARGET)) * A.TARGET	-- AS vendas de web foram maior que app e o net_revenue pode ter passado o total do target, então é calculado: (percentual de app - 100%). O resultado é o percentual de web 
				END AS "TARGET_PENDING"		
			FROM 
				#STG_PRODUCTS_PO_STATUS_ADJUST_APPROVED_2 A
			JOIN
				#STG_PRODUCTS_PO_STATUS_ADJUST_PENDING_2 	B
			ON
				A.CAMPAIGN_NAME 		= B.CAMPAIGN_NAME
				AND A.SUB				= B.SUB
				AND A.DATE 				= B.DATE
				AND A.DIVISION			= B.DIVISION 
				AND A.PRODUCT_GROUP		= B.PRODUCT_GROUP 			
			--	AND A.PO_STATUS 		= B.PO_STATUS
		);
		/*-------------------------------------------------------------------------------------------------*/	
		-- 	
		UPDATE
			OW_LAO.ODS_CAMPAIGN_TARGET_PRODUCTS A
		SET
			A.TARGET = B.TARGET
		FROM 
			OW_LAO.ODS_CAMPAIGN_TARGET_PRODUCTS A
		JOIN(
			SELECT 
				CAMPAIGN_NAME, SUB, DATE, DIVISION, PRODUCT_GROUP, PO_STATUS_APPROVED AS PO_STATUS , TARGET_APPROVED AS TARGET
			FROM 
				#STG_PRODUCTS_PO_STATUS_ADJUSTED_2 		
		UNION ALL
			SELECT 
				CAMPAIGN_NAME, SUB, DATE, DIVISION, PRODUCT_GROUP, PO_STATUS_PENDING AS PO_STATUS , TARGET_PENDING AS TARGET
			FROM 
				#STG_PRODUCTS_PO_STATUS_ADJUSTED_2
		) AS B ON 
			A.CAMPAIGN_NAME 		= B.CAMPAIGN_NAME
			AND A.SUB				= B.SUB
			AND A.DATE 				= B.DATE
			AND A.DIVISION			= B.DIVISION 
			AND A.PRODUCT_GROUP		= B.PRODUCT_GROUP 	
			AND A.PO_STATUS 		= B.PO_STATUS;
	END;
	/*-------------------------------------------------------------------------------------------------*/	
	--Esta procedure consulta a tabela ODS das campanhas e recolhe as informaçãos das vendas da visão CHANNELS do período da campanha e do período anterior(-1 ano)
	ELSEIF :CONSULTA = 'TARGET_CHANNELS' THEN			
	BEGIN
		-- Criação da tabela temporaria recolhendo os dados das vendas do período corrente 
		TRUNCATE TABLE	OW_LAO.TMP_CAMPAIGN_TARGET_CHANNELS_CURRENT_YEAR;
		INSERT INTO OW_LAO.TMP_CAMPAIGN_TARGET_CHANNELS_CURRENT_YEAR
		SELECT 
			A.ID_CAMPAIGN,
			A.CAMPAIGN_TAG,
			A.SUBSIDIARY,
			CAST(RIGHT(ISOWEEK(A.PO_DATE),2) AS integer) 										AS  "WEEK",
			TO_NVARCHAR(A.PO_DATE,'YYYY-MM-DD')  					AS  "DATE",
			A.CAMPAIGN_DAY,
			A.PO_STATUS,
			A.BIZ_TYPE,
			B.MAP_AUDIENCE_TYPE	 									AS "AUDIENCE_TYPE", 	
			CASE 
				WHEN UPPER(A.PO_DEVICETYPE) IN ('WEB','WEBMOBILE') 	THEN 'Web'
				WHEN UPPER(A.PO_DEVICETYPE) IN ('MOBILEAPP') 		THEN 'App'
				ELSE NULL
			END 													AS "PO_DEVICETYPE",
			SUM(A.PO_QTY) 											AS "PO_QTY",
			SUM(A.EBI_NETREVENUE) 									AS "EBI_NETREVENUE",
			SUM(A.PO_TOTALPRICE_USD) 								AS "PO_TOTALPRICE_USD",
			SUM(A.NET_REVENUE) 										AS "NET_REVENUE"
		FROM 
			OW_LAO.ODS_SALES_CAMPAIGN 				A
		LEFT JOIN
			OW_LAO.DIM_TARGETS_MAP_VISAO_CHANNELS 	B 			
		ON 	
			UPPER(A.BIZ_TYPE) 			= UPPER(B.BIZ_TYPE) 
			AND UPPER(A.AUDIENCE_TYPE) 	= UPPER(B.AUDIENCE_TYPE) 
			AND CASE WHEN UPPER(A.PO_DEVICETYPE) IN ('WEB','WEBMOBILE') THEN 'WEB' WHEN UPPER(A.PO_DEVICETYPE) IN ('MOBILEAPP') THEN 'APP' ELSE NULL END = UPPER(B.PO_DEVICETYPE)				
		WHERE 
			A.PREVIOUS_YEAR = FALSE 
			AND (A.PO_STATUS = 'Approved' OR (SUBSIDIARY = 'SELA' AND A.PO_STATUS IN ('Approved','Pending')))			
			AND A.BIZ_TYPE IN ('B2C','EPP','SMB','3PD','APP')
		GROUP BY
			ID_CAMPAIGN,
			A.CAMPAIGN_TAG,
			A.SUBSIDIARY,
			CAST(RIGHT(ISOWEEK(A.PO_DATE),2) AS integer),
			TO_NVARCHAR(A.PO_DATE,'YYYY-MM-DD'),
			A.CAMPAIGN_DAY,
			A.PO_STATUS,
			A.BIZ_TYPE,
			B.MAP_AUDIENCE_TYPE	,
			CASE 
				WHEN UPPER(A.PO_DEVICETYPE) IN ('WEB','WEBMOBILE') 	THEN 'Web'
				WHEN UPPER(A.PO_DEVICETYPE) IN ('MOBILEAPP') 		THEN 'App'
				ELSE NULL
			END;
		/*-------------------------------------------------------------------------------------------------*/	
		-- Criação da tabela temporaria recolhendo os dados das vendas do período anterior
		TRUNCATE TABLE	OW_LAO.TMP_CAMPAIGN_TARGET_CHANNELS_PREVIOUS_YEAR;
		INSERT INTO OW_LAO.TMP_CAMPAIGN_TARGET_CHANNELS_PREVIOUS_YEAR	
		SELECT 
			A.ID_CAMPAIGN,
			A.CAMPAIGN_TAG,
			A.SUBSIDIARY,
			CAST(RIGHT(ISOWEEK(A.PO_DATE),2) AS integer) 										AS  "WEEK",
			TO_NVARCHAR(A.PO_DATE,'YYYY-MM-DD')  					AS  "DATE",
			A.CAMPAIGN_DAY,
			A.PO_STATUS,
			A.BIZ_TYPE,
			B.MAP_AUDIENCE_TYPE	 									AS "AUDIENCE_TYPE", 	
			CASE 
				WHEN UPPER(A.PO_DEVICETYPE) IN ('WEB','WEBMOBILE') 	THEN 'Web'
				WHEN UPPER(A.PO_DEVICETYPE) IN ('MOBILEAPP') 		THEN 'App'
				ELSE NULL
			END 													AS "PO_DEVICETYPE",
			SUM(A.PO_QTY) 											AS "PO_QTY",
			SUM(A.EBI_NETREVENUE) 									AS "EBI_NETREVENUE",
			SUM(A.PO_TOTALPRICE_USD) 								AS "PO_TOTALPRICE_USD",
			SUM(A.NET_REVENUE) 										AS "NET_REVENUE"
		FROM 
			OW_LAO.ODS_SALES_CAMPAIGN 				A
		LEFT JOIN
			OW_LAO.DIM_TARGETS_MAP_VISAO_CHANNELS 	B 			
		ON 	
			UPPER(A.BIZ_TYPE) 			= UPPER(B.BIZ_TYPE) 
			AND UPPER(A.AUDIENCE_TYPE) 	= UPPER(B.AUDIENCE_TYPE) 
			AND CASE WHEN UPPER(A.PO_DEVICETYPE) IN ('WEB','WEBMOBILE') THEN 'WEB' WHEN UPPER(A.PO_DEVICETYPE) IN ('MOBILEAPP') THEN 'APP' ELSE NULL END = UPPER(B.PO_DEVICETYPE)				
		WHERE 
			A.PREVIOUS_YEAR = TRUE 
			AND (A.PO_STATUS = 'Approved' OR (SUBSIDIARY = 'SELA' AND A.PO_STATUS IN ('Approved','Pending')))			
			AND A.BIZ_TYPE IN ('B2C','EPP','SMB','3PD','APP')
		GROUP BY
			A.ID_CAMPAIGN,
			A.CAMPAIGN_TAG,
			A.SUBSIDIARY,
			CAST(RIGHT(ISOWEEK(A.PO_DATE),2) AS integer),
			TO_NVARCHAR(A.PO_DATE,'YYYY-MM-DD'),
			A.CAMPAIGN_DAY,
			A.PO_STATUS,
			A.BIZ_TYPE,
			B.MAP_AUDIENCE_TYPE	,
			CASE 
				WHEN UPPER(A.PO_DEVICETYPE) IN ('WEB','WEBMOBILE') 	THEN 'Web'
				WHEN UPPER(A.PO_DEVICETYPE) IN ('MOBILEAPP') 		THEN 'App'
				ELSE NULL
			END;
		/*-------------------------------------------------------------------------------------------------*/	
		-- Criação da tabela final de CHANNELS relacionado com os targets, dados do período atual da campanha e dados de venda do período anterior  
		TRUNCATE TABLE	OW_LAO.ODS_CAMPAIGN_TARGET_CHANNELS;
		INSERT INTO OW_LAO.ODS_CAMPAIGN_TARGET_CHANNELS	
		SELECT 
			B.CAMPAIGN_NAME,
			B.SUB,
			B.WEEK,
			A.CAMPAIGN_DAY,
			TO_NVARCHAR(B.DAY,'YYYY/MM/DD') AS "DATE",
			TO_NVARCHAR(A.DATE_PREVIOUS_YEAR ,'YYYY/MM/DD') AS "DATE_PREVIOUS_YEAR",
			PO_STATUS,
			--
			B.BIZ_TYPE AS "BIZ_TYPE",
			B.AUDIENCE_TYPE AS "AUDIENCE_TYPE",
			B.DEVICE_TYPE AS "DEVICE_TYPE",
			--	
			B.VALUE AS "TARGET",
			PO_QTY,
			A.PO_QTY_PREVIOUS_YEAR,
			EBI_NETREVENUE,
			A.EBI_NETREVENUE_PREVIOUS_YEAR,
			PO_TOTALPRICE_USD,
			A.PO_TOTALPRICE_USD_PREVIOUS_YEAR,
			NET_REVENUE,
			A.NET_REVENUE_PREVIOUS_YEAR
		FROM(
			SELECT
				CAMPAIGN_TAG, SUBSIDIARY, WEEK, CAMPAIGN_DAY, DATE, DATE_PREVIOUS_YEAR, PO_STATUS, BIZ_TYPE, AUDIENCE_TYPE, PO_DEVICETYPE,
				SUM(D.EBI_NETREVENUE)								AS EBI_NETREVENUE,
				SUM(D.PO_TOTALPRICE_USD) 							AS PO_TOTALPRICE_USD,
				SUM(D.NET_REVENUE) 									AS NET_REVENUE,
				SUM(D.PO_QTY)										AS PO_QTY,
				IFNULL(SUM(D.EBI_NETREVENUE_PREVIOUS_YEAR),0) 		AS EBI_NETREVENUE_PREVIOUS_YEAR,
				IFNULL(SUM(D.PO_TOTALPRICE_USD_PREVIOUS_YEAR),0)	AS PO_TOTALPRICE_USD_PREVIOUS_YEAR,
				IFNULL(SUM(D.NET_REVENUE_PREVIOUS_YEAR)	,0)			AS NET_REVENUE_PREVIOUS_YEAR,
				IFNULL(SUM(D.PO_QTY_PREVIOUS_YEAR)	,0)				AS PO_QTY_PREVIOUS_YEAR				
			FROM(
				SELECT 
					A.CAMPAIGN_TAG,
					A.SUBSIDIARY,
					A.WEEK,
					A.CAMPAIGN_DAY,
					A.DATE,
					ADD_DAYS(TO_DATE(C.INITIAL_DATE_LY),A.CAMPAIGN_DAY-1) 		AS DATE_PREVIOUS_YEAR,
					A.PO_STATUS,
					A.BIZ_TYPE,
					A.AUDIENCE_TYPE,
					A.PO_DEVICETYPE,
					SUM(A.EBI_NETREVENUE)										AS EBI_NETREVENUE,
					SUM(A.PO_TOTALPRICE_USD) 									AS PO_TOTALPRICE_USD,
					SUM(A.NET_REVENUE) 											AS NET_REVENUE,
					SUM(A.PO_QTY)												AS PO_QTY,
					IFNULL(SUM(B.EBI_NETREVENUE_PREVIOUS_YEAR),0) 				AS EBI_NETREVENUE_PREVIOUS_YEAR,
					IFNULL(SUM(B.PO_TOTALPRICE_USD_PREVIOUS_YEAR),0)			AS PO_TOTALPRICE_USD_PREVIOUS_YEAR,
					IFNULL(SUM(B.NET_REVENUE_PREVIOUS_YEAR)	,0)					AS NET_REVENUE_PREVIOUS_YEAR,
					IFNULL(SUM(B.PO_QTY_PREVIOUS_YEAR)	,0)						AS PO_QTY_PREVIOUS_YEAR
				FROM 
					OW_LAO.TMP_CAMPAIGN_TARGET_CHANNELS_CURRENT_YEAR	A
				LEFT JOIN
					OW_LAO.TMP_CAMPAIGN_TARGET_CHANNELS_PREVIOUS_YEAR	B
				ON
					A.SUBSIDIARY 					= B.SUBSIDIARY
					AND A.CAMPAIGN_DAY 				= B.CAMPAIGN_DAY 
					AND A.PO_STATUS 				= B.PO_STATUS
					AND A.ID_CAMPAIGN 				= B.ID_CAMPAIGN
					AND IFNULL(A.BIZ_TYPE,'') 		= IFNULL(B.BIZ_TYPE,'')
					AND IFNULL(A.AUDIENCE_TYPE,'') 	= IFNULL(B.AUDIENCE_TYPE,'')
					AND IFNULL(A.PO_DEVICETYPE,'') 	= IFNULL(B.PO_DEVICETYPE,'')		
				JOIN 
					OW_LAO.DIM_CAMPAIGN_NAME C
				ON
					A.ID_CAMPAIGN = C.ID_CAMPAIGN 
				GROUP BY 
					A.CAMPAIGN_TAG,
					A.SUBSIDIARY,
					A.WEEK,
					A.CAMPAIGN_DAY,
					A.DATE,
					ADD_DAYS(TO_DATE(C.INITIAL_DATE_LY),A.CAMPAIGN_DAY-1),
					A.PO_STATUS,
					A.BIZ_TYPE,
					A.AUDIENCE_TYPE,
					A.PO_DEVICETYPE		
			) AS D
			GROUP BY 
				CAMPAIGN_TAG, SUBSIDIARY, WEEK, CAMPAIGN_DAY, DATE, DATE_PREVIOUS_YEAR, PO_STATUS, BIZ_TYPE, AUDIENCE_TYPE, PO_DEVICETYPE
		) AS "A"
		RIGHT JOIN
			OW_LAO.ODS_TARGETS_CAMPAIGN B
		ON
			A.CAMPAIGN_TAG 			= B.CAMPAIGN_NAME
			AND A.SUBSIDIARY 		= B.SUB 
			AND A."WEEK" 			= B.WEEK 
			AND A."DATE" 			= B.DAY
			AND IFNULL(UPPER(A.BIZ_TYPE),'') 			= IFNULL(UPPER(B.BIZ_TYPE),'')
			AND IFNULL(UPPER(A.PO_DEVICETYPE),'') 		= IFNULL(UPPER(B.DEVICE_TYPE),'') 
			AND IFNULL(UPPER(A.AUDIENCE_TYPE),'')  		= IFNULL(UPPER(B.AUDIENCE_TYPE),'')
		WHERE 							
			B.BIZ_TYPE IN ('B2C','EPP','SMB','3PD','APP');									
		/*-------------------------------------------------------------------------------------------------*/	
		-- Criação da tabela para ajuste do target do grupo de EPP que não teve o target definido para app/web. O calculado de distribuição do target é definido de acordo com o percentual do que foi realizado: NET_REVENUE / TARGET. 
		TRUNCATE TABLE OW_LAO.TMP_CAMPAIGN_TARGET_CHANNELS_ADJUSTS;
		INSERT INTO OW_LAO.TMP_CAMPAIGN_TARGET_CHANNELS_ADJUSTS
		SELECT
			A.CAMPAIGN_NAME, 						
			A.SUB, 								 
			A."DATE", 							
			A.BIZ_TYPE, 	
			A.AUDIENCE_TYPE,
			A.DEVICE_TYPE AS DEVICE_TYPE_APP,
			B.DEVICE_TYPE AS DEVICE_TYPE_WEB,
--			A.NET_REVENUE AS "NET_REVENUE_APP",
--			B.NET_REVENUE AS "NET_REVENUE_WEB",
--			-A.TARGET,
			CASE 
				WHEN IFNULL(A.NET_REVENUE,0) = 0 AND  IFNULL(B.NET_REVENUE,0) = 0 										THEN A.TARGET / 2 											-- Caso não tenha sido realizada nenhuma venda, o target é dividido entre app web
				WHEN IFNULL(A.NET_REVENUE,0) = 0 																		THEN 0														-- Não houve vendas em app, target é zero
				WHEN IFNULL(B.NET_REVENUE,0) = 0 																		THEN A.TARGET												-- Não houve vendas em web, 100% do target é alocado em app	 											
				WHEN IFNULL(A.NET_REVENUE,0) / A.TARGET >= 0.5 AND IFNULL(B.NET_REVENUE,0) / A.TARGET >= 0.5  			THEN A.TARGET / 2  											-- Se as vendas de App e Web juntas foram maior ou igual a 50% o target é dividido 
				WHEN IFNULL(A.NET_REVENUE,0) < IFNULL(B.NET_REVENUE,0)  												THEN     (IFNULL(A.NET_REVENUE,0) / A.TARGET)  * A.TARGET	-- As vendas de APP foram menor que web, então é calculado o percentual de net revenue APP sobre o target
				WHEN IFNULL(A.NET_REVENUE,0) > IFNULL(B.NET_REVENUE,0) 													THEN (1 -(IFNULL(B.NET_REVENUE,0) / A.TARGET)) * A.TARGET 	-- AS vendas de APP foram maior que web e o net_revenue pode ter passado o total do target, então é calculado: (percentual de Web - 100%). O resultado é o percentual de app 
			END AS "TARGET_APP",
			CASE 
				WHEN IFNULL(A.NET_REVENUE,0) = 0 AND  IFNULL(B.NET_REVENUE,0) = 0 										THEN A.TARGET / 2											-- Caso não tenha sido realizada nenhuma venda, o target é dividido entre app web
				WHEN IFNULL(B.NET_REVENUE,0) = 0 																		THEN 0														-- Não houve vendas em web, target é zero
				WHEN IFNULL(A.NET_REVENUE,0) = 0 																		THEN A.TARGET												-- Não houve vendas em app, 100% do target é alocado em web	
				WHEN IFNULL(A.NET_REVENUE,0) / A.TARGET >= 0.5 AND IFNULL(B.NET_REVENUE,0) / A.TARGET >= 0.5 			THEN A.TARGET / 2 											-- Se as vendas de App e Web juntas foram maior ou igual a 50% o target é dividido
				WHEN IFNULL(B.NET_REVENUE,0) < IFNULL(A.NET_REVENUE,0)  												THEN      (IFNULL(B.NET_REVENUE,0) / A.TARGET)  * A.TARGET	-- As vendas de web foram menor que app, então é calculado o percentual de net revenue web sobre o target
				WHEN IFNULL(B.NET_REVENUE,0) > IFNULL(A.NET_REVENUE,0) 													THEN (1 - (IFNULL(A.NET_REVENUE,0) / A.TARGET)) * A.TARGET	-- AS vendas de web foram maior que app e o net_revenue pode ter passado o total do target, então é calculado: (percentual de app - 100%). O resultado é o percentual de web 
			END AS "TARGET_WEB"	
		FROM 
			OW_LAO.ODS_CAMPAIGN_TARGET_CHANNELS A
		JOIN 
			OW_LAO.ODS_CAMPAIGN_TARGET_CHANNELS B
		ON
			A.CAMPAIGN_NAME 						= B.CAMPAIGN_NAME
			AND A.SUB 								= B.SUB 
			AND A."DATE" 							= B."DATE"
--			AND IFNULL(UPPER(A.BIZ_TYPE),'') 		= IFNULL(UPPER(B.BIZ_TYPE),'')
			AND IFNULL(UPPER(A.AUDIENCE_TYPE),'')  	= IFNULL(UPPER(B.AUDIENCE_TYPE),'')
		WHERE 	
			A.BIZ_TYPE  IN ('EPP','APP')
			AND A.AUDIENCE_TYPE <> 'Students'
			AND A.DEVICE_TYPE = 'App'
			AND B.DEVICE_TYPE = 'Web'
			AND A.TARGET >0;
		--	AND (IFNULL(A.NET_REVENUE,0) >0 OR IFNULL(B.NET_REVENUE,0)> 0)
		--	AND A.CAMPAIGN_NAME = 'Father''s'	
		--	AND A.SUB = 'SEASA'
		--	AND A."DATE" = '2024/06/05'		
		--	AND A.NET_REVENUE >0 
		--ORDER BY 
		--		CAMPAIGN_NAME,
		--		SUB,
		--		"DATE",
		--		BIZ_TYPE,AUDIENCE_TYPE,A.DEVICE_TYPE
			/*-------------------------------------------------------------------------------------------------*/	
		-- Apos criação da tabela com ajuste do valor de target, os dados são atualizados na tabela final  		
		UPDATE
			OW_LAO.ODS_CAMPAIGN_TARGET_CHANNELS A
		SET
			A.TARGET = C.TARGET
		FROM
			OW_LAO.ODS_CAMPAIGN_TARGET_CHANNELS A
		JOIN(
			-- Target de APP			
			SELECT 
				CAMPAIGN_NAME,SUB,"DATE",BIZ_TYPE,AUDIENCE_TYPE,
				DEVICE_TYPE_APP AS "DEVICE_TYPE",
				TARGET_APP		AS "TARGET"
			FROM 
				OW_LAO.TMP_CAMPAIGN_TARGET_CHANNELS_ADJUSTS			
			UNION ALL
			-- Target de WEB	
			SELECT 
				CAMPAIGN_NAME,SUB,"DATE",BIZ_TYPE,AUDIENCE_TYPE,
				DEVICE_TYPE_WEB AS "DEVICE_TYPE",
				TARGET_WEB		AS "TARGET"
			FROM 
				OW_LAO.TMP_CAMPAIGN_TARGET_CHANNELS_ADJUSTS
		) C	ON
			A.CAMPAIGN_NAME 						= C.CAMPAIGN_NAME
			AND A.SUB 								= C.SUB 
			AND A."DATE" 							= C."DATE"
--			AND IFNULL(UPPER(A.BIZ_TYPE),'') 		= IFNULL(UPPER(C.BIZ_TYPE),'')
			AND IFNULL(UPPER(A.DEVICE_TYPE),'') 	= IFNULL(UPPER(C.DEVICE_TYPE),'')
			AND IFNULL(UPPER(A.AUDIENCE_TYPE),'')  	= IFNULL(UPPER(C.AUDIENCE_TYPE),'');	
		/*-------------------------------------------------------------------------------------------------*/	
		-- Criação da tabela para ajuste do target do grupo de BIZ_TYPE/AUDIENCE_TYPE/DEVICE_TYPE que não teve o target definido para Approved/Pending. O calculado de distribuição do target é definido de acordo com o percentual do que foi realizado: NET_REVENUE / TARGET. 	
		--
		--Identifica onde é necessário realizar o update		
		CREATE LOCAL TEMPORARY TABLE #STG_CHANNELS_PO_STATUS_FILTER_ADJUST_1 AS (	
			SELECT
				CAMPAIGN_NAME,
				DATE,
				BIZ_TYPE,
				AUDIENCE_TYPE, 
				DEVICE_TYPE,
				COUNT(*)
			FROM 
				OW_LAO.ODS_CAMPAIGN_TARGET_CHANNELS B
			WHERE 
				SUB = 'SELA'
				AND PO_STATUS IS NOT NULL
				AND BIZ_TYPE IN ('EPP','B2C')
			GROUP BY	
				CAMPAIGN_NAME,
				DATE,
				BIZ_TYPE,
				AUDIENCE_TYPE, 
				DEVICE_TYPE
			HAVING
				COUNT(*) = 2 
		);		
		/*-------------------------------------------------------------------------------------------------*/	
		--		
		CREATE LOCAL TEMPORARY TABLE #STG_CHANNELS_PO_STATUS_ADJUST_APPROVED AS (		
			SELECT
				CAMPAIGN_NAME,SUB,"DATE",PO_STATUS,BIZ_TYPE,AUDIENCE_TYPE,DEVICE_TYPE,TARGET,NET_REVENUE
			FROM 
				OW_LAO.ODS_CAMPAIGN_TARGET_CHANNELS A
			WHERE 
				SUB = 'SELA'
				AND BIZ_TYPE IN ('EPP','B2C')
				AND PO_STATUS = 'Approved'
				AND TARGET <> 0
				AND EXISTS (
					--
					SELECT
						*
					FROM 
						#STG_CHANNELS_PO_STATUS_FILTER_ADJUST_1 B
					WHERE
						--JOIN ON
						A.CAMPAIGN_NAME 	= B.CAMPAIGN_NAME
						AND A.DATE			= B.DATE			
						AND A.BIZ_TYPE		= B.BIZ_TYPE	
						AND A.AUDIENCE_TYPE	= B.AUDIENCE_TYPE	
						AND A.DEVICE_TYPE 	= B.DEVICE_TYPE 	
				)
		);	
		/*-------------------------------------------------------------------------------------------------*/	
		-- 
		CREATE LOCAL TEMPORARY TABLE #STG_CHANNELS_PO_STATUS_ADJUST_PENDING AS (		
			SELECT
				CAMPAIGN_NAME,SUB,"DATE",PO_STATUS,BIZ_TYPE,AUDIENCE_TYPE,DEVICE_TYPE,TARGET,NET_REVENUE
			FROM 
				OW_LAO.ODS_CAMPAIGN_TARGET_CHANNELS A
			WHERE 
				SUB = 'SELA'
				AND BIZ_TYPE IN ('EPP','B2C')
				AND PO_STATUS IS NOT NULL
				AND PO_STATUS = 'Pending'
				AND TARGET <> 0
				AND EXISTS (
					--
					SELECT
						1
					FROM 
						#STG_CHANNELS_PO_STATUS_FILTER_ADJUST_1 B
					WHERE
						--JOIN ON
						A.CAMPAIGN_NAME 	= B.CAMPAIGN_NAME
						AND A.DATE			= B.DATE			
						AND A.BIZ_TYPE		= B.BIZ_TYPE	
						AND A.AUDIENCE_TYPE	= B.AUDIENCE_TYPE	
						AND A.DEVICE_TYPE 	= B.DEVICE_TYPE 	
				)
		);	
		/*-------------------------------------------------------------------------------------------------*/	
		-- 
		CREATE LOCAL TEMPORARY TABLE #STG_CHANNELS_PO_STATUS_ADJUSTED AS (	
			SELECT 
				A.CAMPAIGN_NAME,
				A.SUB,
				A.DATE,
				A.BIZ_TYPE,
				A.AUDIENCE_TYPE,
				A.DEVICE_TYPE,
				A.PO_STATUS AS PO_STATUS_APPROVED,
				B.PO_STATUS AS PO_STATUS_PENDING,
			--	A.TARGET,
			--	B.TARGET,
			--	A.NET_REVENUE,
			--	B.NET_REVENUE,
				CASE 
					WHEN IFNULL(A.NET_REVENUE,0) = 0 AND  IFNULL(B.NET_REVENUE,0) = 0 										THEN A.TARGET / 2 											-- Caso não tenha sido realizada nenhuma venda, o target é dividido entre app web
					WHEN IFNULL(A.NET_REVENUE,0) = 0 																		THEN 0														-- Não houve vendas em app, target é zero
					WHEN IFNULL(B.NET_REVENUE,0) = 0 																		THEN A.TARGET												-- Não houve vendas em web, 100% do target é alocado em app	 											
					WHEN IFNULL(A.NET_REVENUE,0) / A.TARGET >= 0.5 AND IFNULL(B.NET_REVENUE,0) / A.TARGET >= 0.5  			THEN A.TARGET / 2  											-- Se as vendas de App e Web juntas foram maior ou igual a 50% o target é dividido 
					WHEN IFNULL(A.NET_REVENUE,0) < IFNULL(B.NET_REVENUE,0)  												THEN     (IFNULL(A.NET_REVENUE,0) / A.TARGET)  * A.TARGET	-- As vendas de APP foram menor que web, então é calculado o percentual de net revenue APP sobre o target
					WHEN IFNULL(A.NET_REVENUE,0) > IFNULL(B.NET_REVENUE,0) 													THEN (1 -(IFNULL(B.NET_REVENUE,0) / A.TARGET)) * A.TARGET 	-- AS vendas de APP foram maior que web e o net_revenue pode ter passado o total do target, então é calculado: (percentual de Web - 100%). O resultado é o percentual de app 
				END AS "TARGET_APPROVED",
				CASE 
					WHEN IFNULL(A.NET_REVENUE,0) = 0 AND  IFNULL(B.NET_REVENUE,0) = 0 										THEN A.TARGET / 2											-- Caso não tenha sido realizada nenhuma venda, o target é dividido entre app web
					WHEN IFNULL(B.NET_REVENUE,0) = 0 																		THEN 0														-- Não houve vendas em web, target é zero
					WHEN IFNULL(A.NET_REVENUE,0) = 0 																		THEN A.TARGET												-- Não houve vendas em app, 100% do target é alocado em web	
					WHEN IFNULL(A.NET_REVENUE,0) / A.TARGET >= 0.5 AND IFNULL(B.NET_REVENUE,0) / A.TARGET >= 0.5 			THEN A.TARGET / 2 											-- Se as vendas de App e Web juntas foram maior ou igual a 50% o target é dividido
					WHEN IFNULL(B.NET_REVENUE,0) < IFNULL(A.NET_REVENUE,0)  												THEN      (IFNULL(B.NET_REVENUE,0) / A.TARGET)  * A.TARGET	-- As vendas de web foram menor que app, então é calculado o percentual de net revenue web sobre o target
					WHEN IFNULL(B.NET_REVENUE,0) > IFNULL(A.NET_REVENUE,0) 													THEN (1 - (IFNULL(A.NET_REVENUE,0) / A.TARGET)) * A.TARGET	-- AS vendas de web foram maior que app e o net_revenue pode ter passado o total do target, então é calculado: (percentual de app - 100%). O resultado é o percentual de web 
				END AS "TARGET_PENDING"		
			FROM 
				#STG_CHANNELS_PO_STATUS_ADJUST_APPROVED A
			JOIN
				#STG_CHANNELS_PO_STATUS_ADJUST_PENDING 	B
			ON
				A.CAMPAIGN_NAME 		= B.CAMPAIGN_NAME
				AND A.SUB				= B.SUB
				AND A.DATE 				= B.DATE
			--	AND A.PO_STATUS 		= B.PO_STATUS
				AND A.BIZ_TYPE			= B.BIZ_TYPE
				AND A.AUDIENCE_TYPE 	= B.AUDIENCE_TYPE
				AND A.DEVICE_TYPE 		= B.DEVICE_TYPE
		);
		/*-------------------------------------------------------------------------------------------------*/	
		-- 
		UPDATE
			OW_LAO.ODS_CAMPAIGN_TARGET_CHANNELS A
		SET
			A.TARGET = B.TARGET
		FROM 
			OW_LAO.ODS_CAMPAIGN_TARGET_CHANNELS A
		JOIN(
			SELECT 
				CAMPAIGN_NAME, SUB, DATE, BIZ_TYPE, AUDIENCE_TYPE, DEVICE_TYPE, PO_STATUS_APPROVED AS PO_STATUS , TARGET_APPROVED AS TARGET
			FROM 
				#STG_CHANNELS_PO_STATUS_ADJUSTED 		
		UNION ALL
			SELECT 
				CAMPAIGN_NAME, SUB, DATE, BIZ_TYPE, AUDIENCE_TYPE, DEVICE_TYPE, PO_STATUS_PENDING AS PO_STATUS , TARGET_PENDING AS TARGET
			FROM 
				#STG_CHANNELS_PO_STATUS_ADJUSTED 
		) AS B ON
			A.CAMPAIGN_NAME 		= B.CAMPAIGN_NAME
			AND A.SUB				= B.SUB
			AND A.DATE 				= B.DATE
			AND A.PO_STATUS 		= B.PO_STATUS
			AND A.BIZ_TYPE			= B.BIZ_TYPE
			AND A.AUDIENCE_TYPE 	= B.AUDIENCE_TYPE
			AND A.DEVICE_TYPE 		= B.DEVICE_TYPE;	
		
		DROP TABLE #STG_CHANNELS_PO_STATUS_FILTER_ADJUST_1;
		DROP TABLE #STG_CHANNELS_PO_STATUS_ADJUST_PENDING;
		DROP TABLE #STG_CHANNELS_PO_STATUS_ADJUST_APPROVED;
		DROP TABLE #STG_CHANNELS_PO_STATUS_ADJUSTED;
	END;	
	/*-------------------------------------------------------------------------------------------------*/	
	ELSEIF :CONSULTA = 'CHECK_DATA_SOURCE' THEN			
	BEGIN
		--Totais tabela de campanha	
		CREATE LOCAL TEMPORARY TABLE  #ODS_SALES_CAMPAIGN_TEMP AS (	
			SELECT
				A.CAMPAIGN_TAG AS CAMPAIGN_NAME,
				A.SUBSIDIARY AS SUB,
				TO_NVARCHAR(A.PO_DATE,'YYYY/MM/DD')  		AS  "DATE",
				IFNULL(-SUM(A.NET_REVENUE),0)				AS "NET_REVENUE",
				'ODS_SALES_CAMPAIGN'	AS "TYPE"			
			FROM 
				OW_LAO.ODS_SALES_CAMPAIGN A
			WHERE 
				A.PREVIOUS_YEAR =  FALSE 
				AND (A.PO_STATUS = 'Approved' OR (SUBSIDIARY = 'SELA' AND A.PO_STATUS IN ('Approved','Pending')))
				AND A.BIZ_TYPE IN ('B2C','EPP','SMB','3PD','APP')
			GROUP BY 
				A.CAMPAIGN_TAG,
				A.SUBSIDIARY,
				TO_NVARCHAR(A.PO_DATE,'YYYY/MM/DD')  
		);	
		--Totais tabela de TARGET RAW
		CREATE LOCAL TEMPORARY TABLE  #TARGET_CHECK AS (	
			SELECT
				CAMPAIGN_NAME,
				SUB,
				TO_NVARCHAR("DAY",'YYYY/MM/DD') 								AS DATE, 
				SUM(MX + VD + DA + OTHERS) 										AS TARGET_PRODUCTS,
				SUM(B2C + EPP + SMB + _PD) 										AS TARGET_CHANNELS,	
				(SUM(MX + VD + DA + OTHERS) + SUM(B2C + EPP + SMB + _PD) ) /2	AS TARGET,
				SUM(MX + VD + DA + OTHERS)  - SUM(B2C + EPP + SMB + _PD) 		AS TARGET_CHECK,
				'TMP_TARGET' AS TYPE 
			FROM 
				OW_LAO.TMP_TARGETS_CAMPAIGN
			GROUP BY 
				CAMPAIGN_NAME,
				SUB,
				"DAY"
		);	
		--Totais tabela de Produtos	
		CREATE LOCAL TEMPORARY TABLE  #TARGET_PRODUCTS_TEMP AS (
			SELECT 
			CAMPAIGN_NAME,SUB,"DATE", 
			IFNULL(SUM(TARGET),0) AS TARGET,
			IFNULL(SUM(NET_REVENUE),0) AS NET_REVENUE,
			'PRODUCTS'	AS "TYPE"
			FROM 
				OW_LAO.ODS_CAMPAIGN_TARGET_PRODUCTS 
			GROUP BY
			CAMPAIGN_NAME,SUB,"DATE"
		);
		--Totais tabela de Canais
		CREATE LOCAL TEMPORARY TABLE  #TARGET_CHANNELS_TEMP AS (
			SELECT 
				CAMPAIGN_NAME,SUB,"DATE",
				IFNULL(-SUM(TARGET),0) AS TARGET,
				IFNULL(-SUM(NET_REVENUE),0) AS NET_REVENUE,
				'CHANNELS'AS "TYPE"
			FROM 
				OW_LAO.ODS_CAMPAIGN_TARGET_CHANNELS
			GROUP BY
				CAMPAIGN_NAME,SUB,"DATE"
			ORDER BY 
				CAMPAIGN_NAME,SUB,"DATE","TYPE"
		);
	--Analise Analítica	
	SELECT 
		A.CAMPAIGN_NAME,A.SUB,A."DATE",
		((IFNULL(ABS(C.NET_REVENUE),0) 	+ IFNULL(ABS(A.NET_REVENUE),0) + IFNULL(ABS(B.NET_REVENUE),0)) / 3) + IFNULL(C.NET_REVENUE,0) 	AS CHECK_NET_REVENUE,
		((IFNULL(ABS(D.TARGET),0) 		+ IFNULL(ABS(A.TARGET),0) 	   + IFNULL(ABS(B.TARGET),0)) / 3) 		- IFNULL(B.TARGET,0) 		AS CHECK_TARGET,	
		C.NET_REVENUE 	AS NET_REVENUE_ODS_SALES_CAMPAIGN,	
		A.NET_REVENUE 	AS NET_REVENUE_PRODUCTS,	
		B.NET_REVENUE 	AS NET_REVENUE_CHANNELS,
		D.TARGET 		AS TARGETS_CAMPAIGN,	
		A.TARGET		AS TARGET_PRODUCTS,
		B.TARGET		AS TARGET_CHANNELS
	FROM 
		#TARGET_PRODUCTS_TEMP 		A
	LEFT JOIN
		#TARGET_CHANNELS_TEMP 		B ON A.CAMPAIGN_NAME = B.CAMPAIGN_NAME AND A.SUB = B.SUB  AND A.DATE = B.DATE
	LEFT JOIN 
		#ODS_SALES_CAMPAIGN_TEMP 	C ON A.CAMPAIGN_NAME = C.CAMPAIGN_NAME AND A.SUB = C.SUB  AND A.DATE = C.DATE	
	LEFT JOIN 
		#TARGET_CHECK				D ON A.CAMPAIGN_NAME = D.CAMPAIGN_NAME AND A.SUB = D.SUB  AND A.DATE = D.DATE	
	WHERE 
		(ROUND(((IFNULL(ABS(C.NET_REVENUE),0) + IFNULL(ABS(A.NET_REVENUE),0) + IFNULL(ABS(B.NET_REVENUE),0)) / 3) + IFNULL(C.NET_REVENUE,0),2) <> 0
		OR ROUND(A.TARGET + B.TARGET,2) <> 0)
	--	AND A.CAMPAIGN_NAME = 'Father''s'	
	--	A.CAMPAIGN_NAME = 'Olympics'
	ORDER BY 
		A.CAMPAIGN_NAME DESC,	
		A.SUB,
		A.DATE;
	END;
	DROP TABLE #TARGET_PRODUCTS_TEMP;
	DROP TABLE #TARGET_CHANNELS_TEMP;
	DROP TABLE #ODS_SALES_CAMPAIGN_TEMP;
	DROP TABLE #TARGET_CHECK;
	/*-------------------------------------------------------------------------------------------------*/	
	ELSE
		SELECT 'Procedimento não declaro' AS CONSULTA FROM DUMMY;		
	END IF;
END;