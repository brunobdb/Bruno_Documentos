CREATE PROCEDURE OW_LAO.proc_ods_sales_control_tower_table_nerp_update
 LANGUAGE SQLSCRIPT AS
 BEGIN
      
      drop table ow_lao.temp_ods_sales_control_tower_table_nerp_update_filter;
    
    create column table ow_lao.temp_ods_sales_control_tower_table_nerp_update_filter
        as ( 
        
            select distinct
                   a.po_sequence_orderid    as id
                 , a.po_sku
                 , b.sales_org
                 , a.currency
                 , a.country
                 , a.po_status
                 , a.po_orderid
                 , cast(a.po_date as date)  as po_date
                 , 1                        as filterType
              from ow_lao.ods_sales_control_tower_table            a
              join ow_md.dim_subsidiary                            b on lower(b.country) = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking c on c.customer_po    = a.po_sequence_orderid
                                                                    and c.material       = a.po_sku
                                                                    and c.sales_org      = b.sales_org
             where nerp_last_update_date < c.last_modification_file
                or nerp_last_update_date is null 
             
             union all    
                     
            select distinct
                   a.po_ordersid            as id
                 , a.po_sku
                 , b.sales_org
                 , a.currency
                 , a.country
                 , a.po_status
                 , a.po_orderid
                 , cast(a.po_date as date)  as po_date
                 , 2                        as filterType
              from ow_lao.ods_sales_control_tower_table            a
              join ow_md.dim_subsidiary                            b on lower(b.country) = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking c on c.sales_document = a.po_ordersid
                                                                    and c.material       = a.po_sku
                                                                    and c.sales_org      = b.sales_org
             where nerp_last_update_date < c.last_modification_file
                or nerp_last_update_date is null
             
             union all    
                     
            select distinct
                   a.po_orderid             as id
                 , a.po_sku
                 , b.sales_org
                 , a.currency
                 , a.country
                 , a.po_status
                 , a.po_orderid
                 , cast(a.po_date as date)  as po_date
                 , 3                        as filterType
              from ow_lao.ods_sales_control_tower_table            a
              join ow_md.dim_subsidiary                            b on lower(b.country) = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking c on c.customer_po    = a.po_orderid
                                                                    and c.material       = a.po_sku
                                                                    and c.sales_org      = b.sales_org
             where nerp_last_update_date < c.last_modification_file
                or nerp_last_update_date is null   
        );
        
          truncate table ow_lao.temp_ods_sales_control_tower_table_nerp_update;
  -- Type 1 and 3      
       insert into ow_lao.temp_ods_sales_control_tower_table_nerp_update            
            select a.id
                 , a.po_orderid
                 , a.po_sku
                 , c.sales_document
                 , c.sold_to_party
                 , c.name
                 , c.material
                 , c.item_descr
                 , c.item_division
                 , case when d.exchange_rate is null then 0.00 else cast(replace(e.so_net_price, ',', '') as decimal) / cast(d.exchange_rate as decimal) end as so_net_price   
                 , 0.00                                                                                                                                      as so_net_value
                 , case when d.exchange_rate is null then 0.00 else  cast(replace(c.cost       , ',', '') as decimal) / cast(d.exchange_rate as decimal) end as cost
                 , cast(replace(c.margin_rate , ',', '') as decimal) as margin_rate
                 , c.so_curr
                 , c.so_create_on
                 , c.sales_org
                 , c.distr_channel
                 , c.plant
                 , c.stor_loc
                 , c.account_code
                 , c.account_name
                 , c.gc_id_gscm
                 , c.gc_name
                 , c.ap1_code
                 , c.ap1_name
                 , c.ap2_code
                 , c.ap2_name
                 , c.delivery
                 , 0                                                                  as delivery_qty_base
                 , c.billed_qty_base
                 , c.billing_date
                 , c.material_group
                 , c.so_local_create_on_d
                 , c.do_local_create_on_d
                 , c."1ST_GI_LOCAL_CREATE"
                 , c.billing_local_create
                 , c.final_sch_date
                 , max(e.last_modification_file)                                      as last_modification_file
                 , a.filterType
                 , 'Returned'                                                         as po_status
              from ow_lao.temp_ods_sales_control_tower_table_nerp_update_filter a
              join ow_md.dim_subsidiary                                         b on lower(b.country)    = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c on c.customer_po       = a.id
                                                                                 and c.material          = a.po_sku
                                                                                 and c.sales_org         = b.sales_org
                                                                                 and c.delivery_qty_base < 0  
         left join ow_lao.ft_ap2_exchange_rate                                  d on d.valid_from        = add_days(cast(a.po_date as date), -1)
                                                                                 and d.to_currency       = a.currency
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e on e.customer_po       = a.id
                                                                                 and e.material          = a.po_sku
                                                                                 and e.sales_org         = b.sales_org
                                                                                 and e.delivery_qty_base >= 0
             where a.filterType in (1, 3)
               and (c.delivery_qty_base + e.delivery_qty_base) <= 0
          group by a.id
                 , a.po_orderid
                 , a.po_sku
                 , c.sales_document
                 , c.sold_to_party
                 , c.name
                 , c.material
                 , c.item_descr
                 , c.item_division
                 , case when d.exchange_rate is null then 0.00 else cast(replace(e.so_net_price, ',', '') as decimal) / cast(d.exchange_rate as decimal) end
                 , case when d.exchange_rate is null then 0.00 else  cast(replace(c.cost       , ',', '') as decimal) / cast(d.exchange_rate as decimal) end
                 , cast(replace(c.margin_rate , ',', '') as decimal)
                 , c.so_curr
                 , c.so_create_on
                 , c.sales_org
                 , c.distr_channel
                 , c.plant
                 , c.stor_loc
                 , c.account_code
                 , c.account_name
                 , c.gc_id_gscm
                 , c.gc_name
                 , c.ap1_code
                 , c.ap1_name
                 , c.ap2_code
                 , c.ap2_name
                 , c.delivery
                 , c.billed_qty_base
                 , c.billing_date
                 , c.material_group
                 , c.so_local_create_on_d
                 , c.do_local_create_on_d
                 , c."1ST_GI_LOCAL_CREATE"
                 , c.billing_local_create
                 , c.final_sch_date
                 , a.filterType;    
               
                  
       insert into ow_lao.temp_ods_sales_control_tower_table_nerp_update            
            select a.id
                 , a.po_orderid
                 , a.po_sku
                 , e.sales_document
                 , e.sold_to_party
                 , e.name
                 , e.material
                 , e.item_descr
                 , e.item_division
                 , case when d.exchange_rate is null then 0.00 else (cast(replace(e.so_net_price, ',', '') as decimal)                                                    ) / cast(d.exchange_rate as decimal) end as so_net_price   
                 , case when d.exchange_rate is null then 0.00 else (cast(replace(c.so_net_value, ',', '') as decimal) + cast(replace(e.so_net_value, ',', '') as decimal)) / cast(d.exchange_rate as decimal) end as so_net_value
                 , case when d.exchange_rate is null then 0.00 else  cast(replace(c.cost        , ',', '') as decimal)                                                      / cast(d.exchange_rate as decimal) end as cost
                 , cast(replace(c.margin_rate , ',', '') as decimal) as margin_rate
                 , e.so_curr
                 , e.so_create_on
                 , e.sales_org
                 , e.distr_channel
                 , e.plant
                 , e.stor_loc
                 , e.account_code
                 , e.account_name
                 , e.gc_id_gscm
                 , e.gc_name
                 , e.ap1_code
                 , e.ap1_name
                 , e.ap2_code
                 , e.ap2_name
                 , e.delivery
                 , c.delivery_qty_base + e.delivery_qty_base        as delivery_qty_base
                 , e.billed_qty_base
                 , e.billing_date
                 , e.material_group
                 , e.so_local_create_on_d
                 , e.do_local_create_on_d
                 , e."1ST_GI_LOCAL_CREATE"
                 , e.billing_local_create
                 , e.final_sch_date
                 , e.last_modification_file
                 , a.filterType
                 , a.po_status
              from ow_lao.temp_ods_sales_control_tower_table_nerp_update_filter a
              join ow_md.dim_subsidiary                                         b on lower(b.country)    = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c on c.customer_po       = a.id
                                                                                 and c.material          = a.po_sku
                                                                                 and c.sales_org         = b.sales_org
                                                                                 and c.delivery_qty_base < 0  
         left join ow_lao.ft_ap2_exchange_rate                                  d on d.valid_from        = add_days(cast(a.po_date as date), -1)
                                                                                 and d.to_currency       = a.currency
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e on e.customer_po       = a.id
                                                                                 and e.material          = a.po_sku
                                                                                 and e.sales_org         = b.sales_org
                                                                                 and e.delivery_qty_base >= 0
             where a.filterType in (1, 3)
               and (c.delivery_qty_base + e.delivery_qty_base) > 0;
               
       insert into ow_lao.temp_ods_sales_control_tower_table_nerp_update  
            select a.id
                 , a.po_orderid
                 , a.po_sku
                 , c.sales_document
                 , c.sold_to_party
                 , c.name
                 , c.material
                 , c.item_descr
                 , c.item_division
                 , case when d.exchange_rate is null then 0.00 else abs(cast(replace(c.so_net_price, ',', '') as decimal)) / cast(d.exchange_rate as decimal) end as so_net_price
                 , case when d.exchange_rate is null then 0.00 else abs(cast(replace(c.so_net_value, ',', '') as decimal)) / cast(d.exchange_rate as decimal) end as so_net_value
                 , case when d.exchange_rate is null then 0.00 else cast(replace(c.cost            , ',', '') as decimal)  / cast(d.exchange_rate as decimal) end as cost
                 , cast(replace(c.margin_rate , ',', '') as decimal)                                                                                              as margin_rate
                 , c.so_curr
                 , c.so_create_on
                 , c.sales_org
                 , c.distr_channel
                 , c.plant
                 , c.stor_loc
                 , c.account_code
                 , c.account_name
                 , c.gc_id_gscm
                 , c.gc_name
                 , c.ap1_code
                 , c.ap1_name
                 , c.ap2_code
                 , c.ap2_name
                 , c.delivery
                 , abs(c.delivery_qty_base)                                      as delivery_qty_base
                 , c.billed_qty_base
                 , c.billing_date
                 , c.material_group
                 , c.so_local_create_on_d
                 , c.do_local_create_on_d
                 , c."1ST_GI_LOCAL_CREATE"
                 , c.billing_local_create
                 , c.final_sch_date
                 , c.last_modification_file
                 , a.filterType
                 , case when c.delivery_qty_base < 0 then 'Returned' else a.po_status end as po_status
              from ow_lao.temp_ods_sales_control_tower_table_nerp_update_filter a
              join ow_md.dim_subsidiary                                         b on lower(b.country)    = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c on c.customer_po       = a.id
                                                                                 and c.material          = a.po_sku
                                                                                 and c.sales_org         = b.sales_org
         left join ow_lao.ft_ap2_exchange_rate                                  d on d.valid_from        = add_days(cast(a.po_date as date), -1)
                                                                                 and d.to_currency       = a.currency
             where a.filterType in (1, 3)
               and not exists(
                        select 1
                          from ow_lao.temp_ods_sales_control_tower_table_nerp_update aa
                         where c.customer_po       = aa.id
                           and c.material          = aa.po_sku
                           and c.sales_org         = aa.sales_org
                           and a.filterType        = aa.filterType
                   );
                   
  -- Type 2       
       insert into ow_lao.temp_ods_sales_control_tower_table_nerp_update            
            select a.id
                 , a.po_orderid
                 , a.po_sku
                 , c.sales_document
                 , c.sold_to_party
                 , c.name
                 , c.material
                 , c.item_descr
                 , c.item_division
                 , case when d.exchange_rate is null then 0.00 else cast(replace(e.so_net_price, ',', '') as decimal) / cast(d.exchange_rate as decimal) end as so_net_price   
                 , 0.00                                                              as so_net_value
                 , case when d.exchange_rate is null then 0.00 else  cast(replace(c.cost       , ',', '') as decimal) / cast(d.exchange_rate as decimal) end as cost
                 , cast(replace(c.margin_rate , ',', '') as decimal) as margin_rate
                 , c.so_curr
                 , c.so_create_on
                 , c.sales_org
                 , c.distr_channel
                 , c.plant
                 , c.stor_loc
                 , c.account_code
                 , c.account_name
                 , c.gc_id_gscm
                 , c.gc_name
                 , c.ap1_code
                 , c.ap1_name
                 , c.ap2_code
                 , c.ap2_name
                 , c.delivery
                 , 0                                                                  as delivery_qty_base
                 , c.billed_qty_base
                 , c.billing_date
                 , c.material_group
                 , c.so_local_create_on_d
                 , c.do_local_create_on_d
                 , c."1ST_GI_LOCAL_CREATE"
                 , c.billing_local_create
                 , c.final_sch_date
                 , max(e.last_modification_file)                                      as last_modification_file
                 , a.filterType
                 , 'Returned'                                                         as po_status
              from ow_lao.temp_ods_sales_control_tower_table_nerp_update_filter a
              join ow_md.dim_subsidiary                                         b on lower(b.country)    = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c on c.sales_document    = a.id
                                                                                 and c.material          = a.po_sku
                                                                                 and c.sales_org         = b.sales_org
                                                                                 and c.delivery_qty_base < 0  
         left join ow_lao.ft_ap2_exchange_rate                                  d on d.valid_from        = add_days(cast(a.po_date as date), -1)
                                                                                 and d.to_currency       = a.currency
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e on e.sales_document    = a.id
                                                                                 and e.material          = a.po_sku
                                                                                 and e.sales_org         = b.sales_org
                                                                                 and e.delivery_qty_base >= 0
             where a.filterType in (2)
               and (c.delivery_qty_base + e.delivery_qty_base) <= 0
          group by a.id
                 , a.po_orderid
                 , a.po_sku
                 , c.sales_document
                 , c.sold_to_party
                 , c.name
                 , c.material
                 , c.item_descr
                 , c.item_division
                 , case when d.exchange_rate is null then 0.00 else cast(replace(e.so_net_price, ',', '') as decimal) / cast(d.exchange_rate as decimal) end
                 , case when d.exchange_rate is null then 0.00 else  cast(replace(c.cost       , ',', '') as decimal) / cast(d.exchange_rate as decimal) end
                 , cast(replace(c.margin_rate , ',', '') as decimal)
                 , c.so_curr
                 , c.so_create_on
                 , c.sales_org
                 , c.distr_channel
                 , c.plant
                 , c.stor_loc
                 , c.account_code
                 , c.account_name
                 , c.gc_id_gscm
                 , c.gc_name
                 , c.ap1_code
                 , c.ap1_name
                 , c.ap2_code
                 , c.ap2_name
                 , c.delivery
                 , c.billed_qty_base
                 , c.billing_date
                 , c.material_group
                 , c.so_local_create_on_d
                 , c.do_local_create_on_d
                 , c."1ST_GI_LOCAL_CREATE"
                 , c.billing_local_create
                 , c.final_sch_date
                 , a.filterType;       
               
                  
       insert into ow_lao.temp_ods_sales_control_tower_table_nerp_update            
            select a.id
                 , a.po_orderid
                 , a.po_sku
                 , e.sales_document
                 , e.sold_to_party
                 , e.name
                 , e.material
                 , e.item_descr
                 , e.item_division
                 , case when d.exchange_rate is null then 0.00 else (cast(replace(e.so_net_price, ',', '') as decimal)                                                    ) / cast(d.exchange_rate as decimal) end as so_net_price   
                 , case when d.exchange_rate is null then 0.00 else (cast(replace(c.so_net_value, ',', '') as decimal) + cast(replace(e.so_net_value, ',', '') as decimal)) / cast(d.exchange_rate as decimal) end as so_net_value
                 , case when d.exchange_rate is null then 0.00 else  cast(replace(c.cost        , ',', '') as decimal)                                                      / cast(d.exchange_rate as decimal) end as cost
                 , cast(replace(c.margin_rate , ',', '') as decimal) as margin_rate
                 , e.so_curr
                 , e.so_create_on
                 , e.sales_org
                 , e.distr_channel
                 , e.plant
                 , e.stor_loc
                 , e.account_code
                 , e.account_name
                 , e.gc_id_gscm
                 , e.gc_name
                 , e.ap1_code
                 , e.ap1_name
                 , e.ap2_code
                 , e.ap2_name
                 , e.delivery
                 , c.delivery_qty_base + e.delivery_qty_base        as delivery_qty_base
                 , e.billed_qty_base
                 , e.billing_date
                 , e.material_group
                 , e.so_local_create_on_d
                 , e.do_local_create_on_d
                 , e."1ST_GI_LOCAL_CREATE"
                 , e.billing_local_create
                 , e.final_sch_date
                 , e.last_modification_file
                 , a.filterType
                 , a.po_status
              from ow_lao.temp_ods_sales_control_tower_table_nerp_update_filter a
              join ow_md.dim_subsidiary                                         b on lower(b.country)    = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c on c.sales_document    = a.id
                                                                                 and c.material          = a.po_sku
                                                                                 and c.sales_org         = b.sales_org
                                                                                 and c.delivery_qty_base < 0  
         left join ow_lao.ft_ap2_exchange_rate                                  d on d.valid_from        = add_days(cast(a.po_date as date), -1)
                                                                                 and d.to_currency       = a.currency
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              e on e.sales_document    = a.id
                                                                                 and e.material          = a.po_sku
                                                                                 and e.sales_org         = b.sales_org
                                                                                 and e.delivery_qty_base >= 0
             where a.filterType in (2)
               and (c.delivery_qty_base + e.delivery_qty_base) > 0;
               
       insert into ow_lao.temp_ods_sales_control_tower_table_nerp_update  
            select a.id
                 , a.po_orderid
                 , a.po_sku
                 , c.sales_document
                 , c.sold_to_party
                 , c.name
                 , c.material
                 , c.item_descr
                 , c.item_division
                 , case when d.exchange_rate is null then 0.00 else abs(cast(replace(c.so_net_price, ',', '') as decimal)) / cast(d.exchange_rate as decimal) end as so_net_price
                 , case when d.exchange_rate is null then 0.00 else abs(cast(replace(c.so_net_value, ',', '') as decimal)) / cast(d.exchange_rate as decimal) end as so_net_value
                 , case when d.exchange_rate is null then 0.00 else abs(cast(replace(c.cost        , ',', '') as decimal)) / cast(d.exchange_rate as decimal) end as cost
                 , cast(replace(c.margin_rate , ',', '') as decimal)                                                                                              as margin_rate
                 , c.so_curr
                 , c.so_create_on
                 , c.sales_org
                 , c.distr_channel
                 , c.plant
                 , c.stor_loc
                 , c.account_code
                 , c.account_name
                 , c.gc_id_gscm
                 , c.gc_name
                 , c.ap1_code
                 , c.ap1_name
                 , c.ap2_code
                 , c.ap2_name
                 , c.delivery
                 , abs(c.delivery_qty_base)                                                as delivery_qty_base
                 , c.billed_qty_base
                 , c.billing_date
                 , c.material_group
                 , c.so_local_create_on_d
                 , c.do_local_create_on_d
                 , c."1ST_GI_LOCAL_CREATE"
                 , c.billing_local_create
                 , c.final_sch_date
                 , c.last_modification_file
                 , a.filterType
                 , case when c.delivery_qty_base < 0 then 'Returned' else a.po_status end as po_status
              from ow_lao.temp_ods_sales_control_tower_table_nerp_update_filter a
              join ow_md.dim_subsidiary                                         b on lower(b.country)    = lower(a.country)
              join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking              c on c.sales_document    = a.id
                                                                                 and c.material          = a.po_sku
                                                                                 and c.sales_org         = b.sales_org
         left join ow_lao.ft_ap2_exchange_rate                                  d on d.valid_from        = add_days(cast(a.po_date as date), -1)
                                                                                 and d.to_currency       = a.currency
             where a.filterType in (2)
               and not exists(
                        select 1
                          from ow_lao.temp_ods_sales_control_tower_table_nerp_update aa
                         where c.sales_document    = aa.id
                           and c.material          = aa.po_sku
                           and c.sales_org         = aa.sales_org
                           and a.filterType        = aa.filterType
                   );           
                   
       update ow_lao.ods_sales_control_tower_table            a
           set a.so_idcode             = c.sales_document
             , a.po_status             = c.po_status
             , a.soldto_party          = c.sold_to_party
             , a.soldto_name           = c.name
             , a.nerp_sku              = c.material
             , a.nerp_sku_description  = c.item_descr
             , a.nerp_sku_division     = c.item_division
             , a.nerp_netprice         = case when c.so_net_price < 0 then 0 else c.so_net_price end
             , a.nerp_netvalue         = case when c.so_net_value < 0 then 0 else c.so_net_value end
             , a.nerp_cost             = c.cost
             , a.nerp_marginrate       = c.margin_rate
             , a.nerp_currency         = c.so_curr
             , a.so_date_kst           = c.so_create_on
             , a.nerp_countrycode      = c.sales_org
             , a.nerp_distchannel      = c.distr_channel
             , a.nerp_plant            = c.plant
             , a.nerp_storagelocation  = c.stor_loc
             , a.nerp_accountcode      = c.account_code
             , a.nerp_accountname      = c.account_name
             , a.nerp_id_gscm          = c.gc_id_gscm
             , a.nerp_gc_name          = c.gc_name
             , a.nerp_ap1_code         = c.ap1_code
             , a.nerp_ap1_name         = c.ap1_name
             , a.nerp_ap2_code         = c.ap2_code
             , a.nerp_ap2_name         = c.ap2_name
             , a.nerp_deliverycode     = c.delivery
             , a.nerp_deliveruqty      = c.delivery_qty_base
             , a.nerp_billingqty       = c.billed_qty_base
             , a.nerp_billingdate      = c.billing_date
             , a.nerp_material_group   = c.material_group
             , a.so_date               = c.so_local_create_on_d
             , a.do_date               = c.do_local_create_on_d
             , a."1GI_DATE"            = c."1ST_GI_LOCAL_CREATE"
             , a.billing_date_local    = c.billing_local_create
             , a.final_date            = c.final_sch_date
             , a.nerp_last_update_date = c.last_modification_file
             , a.updated_datetime      = current_timestamp
          from ow_lao.ods_sales_control_tower_table                  a
          join ow_md.dim_subsidiary                                  b on lower(b.country) = lower(a.country)
          join ow_lao.temp_ods_sales_control_tower_table_nerp_update c on c.po_orderid     = a.po_orderid
                                                                      and c.material       = a.po_sku
                                                                      and c.sales_org      = b.sales_org
     left join ow_lao.ft_ap2_exchange_rate                           d on d.valid_from     = add_days(cast(a.po_date as date), -1)
                                                                      and d.to_currency    = a.currency
         where nerp_last_update_date < c.last_modification_file
            or nerp_last_update_date is null;
         
    end