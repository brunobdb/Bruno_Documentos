CREATE procedure ow_lao.proc_TF_NERP_GROSS_MARGIN_monitoring_datasource
as
begin
     
    select 2                                                    as monitoring_execution_result_status
         , string_agg(
                   'Billing date: ' || CHAR(10) || billing_date || CHAR(10)
                || 'Amount ZKE: '   || CHAR(10) || amount_zke 
                , CHAR(10) || CHAR(10)
           )                                                    as value
      from (
	         select billing_date    as billing_date
	              , sum(amount_zke) as amount_zke 
	           from OW_LAO.TF_NERP_GROSS_MARGIN 
	          where billing_date = add_days(current_date, -1)
	       group by billing_date
       ) a     ;
     
    
end