CREATE procedure ow_lao.proc_ods_sela_orders_coupons_status_history
 language sqlscript as
 begin
     merge into ow_lao.ods_sela_orders_coupons_status_history a
          using ow_lao.stg_sela_orders_coupons_status_history b on b.store_id      = a.store_id
		                                                       and b.subsidiary_id = a.subsidiary_id
		                                                       and b.account       = a.account
		                                                       and b.entity_id     = a.entity_id
		                                                       and b.parent_id     = a.parent_id
           when    matched then update  
                                   set a.updated_timestamp                            = current_timestamp     
                                     , a.comment  = b.comment 
                                     , a.created_at  = b.created_at 
                                     , a.entity_name  = b.entity_name 
                                     , a.is_customer_notified  = b.is_customer_notified 
                                     , a.is_visible_on_front  = b.is_visible_on_front 
                                     , a.status  = b.status 
                                     , a.coupons_entity_id  = b.coupons_entity_id                                                                                        
           when not matched then insert(           
                                           updated_timestamp 
                                         , comment 
                                         , created_at 
                                         , entity_id 
                                         , entity_name 
                                         , is_customer_notified 
                                         , is_visible_on_front 
                                         , parent_id 
                                         , status 
                                         , coupons_entity_id 
                                         , store_id 
                                         , subsidiary_id
                                         , account         
                                 )      
                                 values(
                                           current_timestamp
                                         , b.comment 
                                         , b.created_at 
                                         , b.entity_id 
                                         , b.entity_name 
                                         , b.is_customer_notified 
                                         , b.is_visible_on_front 
                                         , b.parent_id 
                                         , b.status 
                                         , b.coupons_entity_id 
                                         , b.store_id 
                                         , b.subsidiary_id
                                         , b.account                                            
                                 );
    end