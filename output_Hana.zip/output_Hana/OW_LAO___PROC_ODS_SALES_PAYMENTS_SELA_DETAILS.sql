CREATE procedure ow_lao.proc_ods_sales_payments_sela_details as
begin
	     --drop table #sela_subsidiaries_region_mapping;
	   create local temporary table #sela_subsidiaries_region_mapping
	       as (
                    select  8 as subsidiary_id, 'Paraguay' as api_account, '45' as store_id, 'Regional' as api_group from dummy union all
                    select 17                 , 'Miami-USA'              ,  '8', 'Regional'             as api_group from dummy union all
                    select  7                 , 'MyEmployees'            ,  '9', 'Regional'             as api_group from dummy union all
                    select  7                 , 'Panama'                 , '44', 'Regional'             as api_group from dummy union all
                    select 13                 , 'Nicaragua'              , '13', 'Regional'             as api_group from dummy union all
                    select  7                 , 'CRBN'                   , '15', 'Regional'             as api_group from dummy union all
                    select  7                 , 'Offers'                 , '16', 'Regional'             as api_group from dummy union all
                    select 18                 , 'Puerto Rico'            , '17', 'Regional'             as api_group from dummy union all
                    select  7                 , 'Mybenefits PA'          , '22', 'Regional'             as api_group from dummy union all
                    select  7                 , 'Alianzas'               , '34', 'Regional'             as api_group from dummy union all
                    select 12                 , 'Dominican Republic'     , '35', 'Regional'             as api_group from dummy union all
                    select 12                 , 'Mybenefits DR'          , '42', 'Regional'             as api_group from dummy union all
                    select 10                 , 'Guatemala'              ,  '6', 'NCA'                  as api_group from dummy union all
                    select 15                 , 'El Salvador'            , '20', 'NCA'                  as api_group from dummy union all
                    select 14                 , 'Honduras'               , '21', 'NCA'                  as api_group from dummy union all
                    select 10                 , 'EPP Guatemala'          , '26', 'NCA'                  as api_group from dummy union all
                    select 10                 , 'Employees NCA'          , '27', 'NCA'                  as api_group from dummy union all
                    select 15                 , 'EPP El Salvador'        , '29', 'NCA'                  as api_group from dummy union all
                    select 14                 , 'EPP Honduras'           , '41', 'NCA'                  as api_group from dummy union all
                    select 19                 , 'Costa Rica'             , '43', 'NCA'                  as api_group from dummy union all  
                    select 11                 , 'Employees ECU'          , '45', 'NCA'                  as api_group from dummy union all
                    select 11                 , 'Ecuador'                , '43', 'ECU'                  as api_group from dummy union all 
                    select 11                 , 'Ecuador Benefits'       , '44', 'ECU'                  as api_group from dummy           
	       );
	
         --drop table #sales_payments_sela_prepare;	
	   create local temporary table #sales_payments_sela_prepare
	       as (
	       
		        select a.created_at                         as insert_timestamp                                              
		             , c.po_date                            as po_date 
		             , c.podate_month                       as po_month 
		             , c.podate_year                        as po_year 
		             , hour(c.po_date)                      as po_hour                     
		             , c.country                            as pay_subsidiary 
		             , a.response_code                      as pay_code 
		             , cast(null as varchar(255))           as pay_id                                                 
		             , cast(a.reponse_timestamp as date)    as pay_date 
		             , month(cast(a.reponse_timestamp as date)) as pay_month 
		             ,  year(cast(a.reponse_timestamp as date)) as pay_year 
		             ,  hour(cast(a.reponse_timestamp as date)) as pay_hour                      
		             , coalesce(a.reponse_status, '')           as pay_status 
		             , a.response_message                   as pay_detail 
		             , cast(null as varchar(255))           as pay_gateway_code 
		             , cast(null as varchar(255))           as payment_type 
		             , a.payment_method                     as pay_gateway 
		             , c.po_price_localcurr                  as revenue_local 
		             , c.po_orderid                         as pay_orderid 
		             , c.po_sitecode                        as pay_storename 
		             , cast(null as varchar(255))           as postoretype 
		             , c.po_devicetype                      as po_devicetype 
		             , coalesce(c.po_status, '')            as po_status 
		             , cast(null as varchar(255))           as order_status_type 
		             , c.currency                           as currency                                                                              
		             , cast(null as timestamp)              as po_order_lastmodifydate              
		             , c.po_storename                       as postorename 
		             , c.channel                            as channel 
		             , c.biz_type                           as biz_type 
		             , c.audience_type                      as audience_type 
		             , c.subsidiary                         as subsidiary 
		             , a.reponse_amount                     as pe_amount
		             , po_price_usd                         as revenu_usd
		             , c.po_orderid                         as po_orderid 
		             , cast(  '' as varchar(255))           as pay_action 
		             , cast(  '' as varchar(255))           as pay_result 
		             , cast(  '' as varchar(1000))          as pay_description 
		             , a.response_message                   as pay_message
		             , c.po_status                          as po_status_ct
		             , cast(null as varchar(255))           as funnel_status
		             , c.po_orderid                         as orderid_log
		             , c.po_internal_status                 as po_internal_status
		             , cast(  '' as varchar(255))           as po_payment_type
		             , c.po_paymentprovider
		             , c.payment_card_brand
		             , coalesce(a.reponse_timestamp, a.created_at)                         as datasource_origin_timestamp
		             , 'ow_lao.raw_sela_sales_orders_cancelations_reason'                  as PO_PLATAFORM_DATASOURCE
		             , cast(null as varchar(255))                                          as PAY_GATEWAY_STATUS
		             , cast(null as varchar(255))                                          as PO_PAYMENT_TYPE_STATUS 
                     , row_number()
                        over(partition by c.country
                                        , c.po_sitecode
                                        , c.po_orderid
                                order by coalesce(a.reponse_timestamp, a.created_at) desc) as dedup
                  from ow_lao.raw_sela_sales_orders_cancelations_reason a
                  join #sela_subsidiaries_region_mapping                b on b.api_group            = a.api_group
                                                                         and b.store_id             = a.store_id
                  join ow_lao.ods_sales_control_tower_table             c on c.po_orderid           = a.order_id
                                                                         and c.client_subsidiary_id = b.subsidiary_id
                 where 1 = 1
                   --and a.order_id = '44000010837'	       
	      );
	      
	      delete 
	        from #sales_payments_sela_prepare
	       where dedup != 1;	
	       
	      update #sales_payments_sela_prepare             a
	         set funnel_status = b.status
	        from #sales_payments_sela_prepare             a
	        join ow_lao.DIM_PAYMENT_FUNNEL_STATUS_MAPPING b on b.pay_status                = a.pay_status
	                                                       and b.po_status                 = a.po_status
	                                                       and b.pay_description           = a.pay_description
	                                                       and b.data_source               = a.po_plataform_datasource 
	       where b.active = true;	
	       
	      update #sales_payments_sela_prepare           a
	         set a.pay_gateway_status = b.gateway
	        from #sales_payments_sela_prepare           a
	        join ow_lao.dim_payment_pay_gateway_mapping b on b.data_source = a.po_plataform_datasource 
	                                                     and b.pay_gateway = a.pay_gateway
	       where active = true;       
	     
	    update #sales_payments_sela_prepare    a
	       set a.po_payment_type_status = b.payment_mode
	      from #sales_payments_sela_prepare    a
	      join ow_lao.dim_payment_type_mapping b on b.data_source  = a.po_plataform_datasource 
	                                            and b.payment_type = a.payment_type
	     where active = true; 
	     
	      
     merge into ow_lao.ods_payment_funnel_sela_homolog    a
          using #sales_payments_sela_prepare              b on b.pay_orderid    = a.pay_orderid
                                                           and b.pay_subsidiary = a.pay_subsidiary
           when    matched then update  
                                   set a.po_date = b.po_date 
                                     , a.po_month = b.po_month 
                                     , a.po_year = b.po_year 
                                     , a.po_hour = b.po_hour 
                                     , a.pay_subsidiary = b.pay_subsidiary 
                                     , a.pay_code = b.pay_code 
                                     , a.pay_id = b.pay_id 
                                     , a.pay_date = b.pay_date 
                                     , a.pay_month = b.pay_month 
                                     , a.pay_year = b.pay_year 
                                     , a.pay_hour = b.pay_hour 
                                     , a.pay_status = b.pay_status 
                                     , a.pay_detail = b.pay_detail 
                                     , a.pay_gateway_code = b.pay_gateway_code 
                                     , a.payment_type = b.payment_type 
                                     , a.pay_gateway = b.pay_gateway 
                                     , a.revenue_local = b.revenue_local 
                                     , a.pay_orderid = b.pay_orderid 
                                     , a.pay_storename = b.pay_storename 
                                     , a.postoretype = b.postoretype 
                                     , a.po_devicetype = b.po_devicetype 
                                     , a.po_status = b.po_status 
                                     , a.order_status_type = b.order_status_type 
                                     , a.currency = b.currency 
                                     , a.po_order_lastmodifydate = b.po_order_lastmodifydate 
                                     , a.postorename = b.postorename 
                                     , a.channel = b.channel 
                                     , a.biz_type = b.biz_type 
                                     , a.audience_type = b.audience_type 
                                     , a.subsidiary = b.subsidiary 
                                     , a.pe_amount= b.pe_amount
                                     , a.revenu_usd= b.revenu_usd
                                     , a.po_orderid = b.po_orderid 
                                     , a.pay_action = b.pay_action 
                                     , a.pay_result = b.pay_result 
                                     , a.pay_description = b.pay_description 
                                     , a.pay_message = b.pay_message 
                                     , a.po_internal_status= b.po_internal_status
                                     , a.po_payment_type= b.po_payment_type
                                     , a.po_paymentprovider= b.po_paymentprovider
                                     , a.payment_card_brand= b.payment_card_brand
                                     , a.po_status_ct = b.po_status_ct 
                                     , a.funnel_status = b.funnel_status
                                     , a.updated_timestamp = current_timestamp
                                     , a.PAY_GATEWAY_STATUS = b.PAY_GATEWAY_STATUS
                                     , a.PO_PAYMENT_TYPE_STATUS = b.PO_PAYMENT_TYPE_STATUS
                                     , a.PO_PLATAFORM_DATASOURCE =   b.PO_PLATAFORM_DATASOURCE
                                     , a.datasource_origin_timestamp = b.datasource_origin_timestamp
           when not matched then insert(
                                           po_date 
                                         , po_month 
                                         , po_year 
                                         , po_hour 
                                         , pay_subsidiary 
                                         , pay_code 
                                         , pay_id 
                                         , pay_date 
                                         , pay_month 
                                         , pay_year 
                                         , pay_hour 
                                         , pay_status 
                                         , pay_detail 
                                         , pay_gateway_code 
                                         , payment_type 
                                         , pay_gateway 
                                         , revenue_local 
                                         , pay_orderid 
                                         , pay_storename 
                                         , postoretype 
                                         , po_devicetype 
                                         , po_status 
                                         , order_status_type 
                                         , currency 
                                         , po_order_lastmodifydate 
                                         , postorename 
                                         , channel 
                                         , biz_type 
                                         , audience_type 
                                         , subsidiary 
                                         , pe_amount
                                         , revenu_usd
                                         , po_orderid 
                                         , pay_action 
                                         , pay_result 
                                         , pay_description 
                                         , pay_message 
                                         , po_internal_status
                                         , po_payment_type
                                         , po_paymentprovider
                                         , payment_card_brand
                                         , po_status_ct   
                                         , funnel_status 
                                         , PAY_GATEWAY_STATUS
                                         , PO_PAYMENT_TYPE_STATUS
                                         , PO_PLATAFORM_DATASOURCE
                                         , datasource_origin_timestamp
                                 )
                                 values(
                                           b.po_date 
                                         , b.po_month 
                                         , b.po_year 
                                         , b.po_hour 
                                         , b.pay_subsidiary 
                                         , b.pay_code 
                                         , b.pay_id 
                                         , b.pay_date 
                                         , b.pay_month 
                                         , b.pay_year 
                                         , b.pay_hour 
                                         , b.pay_status 
                                         , b.pay_detail 
                                         , b.pay_gateway_code 
                                         , b.payment_type 
                                         , b.pay_gateway 
                                         , b.revenue_local 
                                         , b.pay_orderid 
                                         , b.pay_storename 
                                         , b.postoretype 
                                         , b.po_devicetype 
                                         , b.po_status 
                                         , b.order_status_type 
                                         , b.currency 
                                         , b.po_order_lastmodifydate 
                                         , b.postorename 
                                         , b.channel 
                                         , b.biz_type 
                                         , b.audience_type 
                                         , b.subsidiary 
                                         , b.pe_amount
                                         , b.revenu_usd
                                         , b.po_orderid 
                                         , b.pay_action 
                                         , b.pay_result 
                                         , b.pay_description 
                                         , b.pay_message 
                                         , b.po_internal_status
                                         , b.po_payment_type
                                         , b.po_paymentprovider
                                         , b.payment_card_brand
                                         , b.po_status_ct     
                                         , b.funnel_status
                                         , b.PAY_GATEWAY_STATUS
                                         , b.PO_PAYMENT_TYPE_STATUS
                                         , b.PO_PLATAFORM_DATASOURCE
                                         , b.datasource_origin_timestamp                            
                                 );        
end