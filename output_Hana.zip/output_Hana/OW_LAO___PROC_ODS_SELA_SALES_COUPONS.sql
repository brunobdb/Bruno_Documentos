CREATE procedure ow_lao.proc_ods_sela_sales_coupons
 language sqlscript as
 begin
     merge into ow_lao.ods_sela_sales_coupons a
          using ow_lao.stg_sela_sales_coupons b on b.subsidiary_id                  = b.subsidiary_id
                                               and b.account                        = b.account
                                               and coalesce(b.applied_rule_ids, '') = coalesce(a.applied_rule_ids, '')
                                               and b.entity_id                      = b.entity_id
             when    matched then update  
                                   set a.updated_timestamp                            = current_timestamp 
                                     , a.base_currency_code  = b.base_currency_code 
                                     , a.base_discount_amount  = b.base_discount_amount 
                                     , a.base_discount_invoiced  = b.base_discount_invoiced 
                                     , a.base_grand_total  = b.base_grand_total 
                                     , a.base_discount_tax_compensation_amount  = b.base_discount_tax_compensation_amount 
                                     , a.base_discount_tax_compensation_invoiced  = b.base_discount_tax_compensation_invoiced 
                                     , a.base_shipping_amount  = b.base_shipping_amount 
                                     , a.base_shipping_discount_amount  = b.base_shipping_discount_amount 
                                     , a.base_shipping_discount_tax_compensation_amnt  = b.base_shipping_discount_tax_compensation_amnt 
                                     , a.base_shipping_incl_tax  = b.base_shipping_incl_tax 
                                     , a.base_shipping_invoiced  = b.base_shipping_invoiced 
                                     , a.base_shipping_tax_amount  = b.base_shipping_tax_amount 
                                     , a.base_subtotal  = b.base_subtotal 
                                     , a.base_subtotal_incl_tax  = b.base_subtotal_incl_tax 
                                     , a.base_subtotal_invoiced  = b.base_subtotal_invoiced 
                                     , a.base_tax_amount  = b.base_tax_amount 
                                     , a.base_tax_invoiced  = b.base_tax_invoiced 
                                     , a.base_total_due  = b.base_total_due 
                                     , a.base_total_invoiced  = b.base_total_invoiced 
                                     , a.base_total_invoiced_cost  = b.base_total_invoiced_cost 
                                     , a.base_total_paid  = b.base_total_paid 
                                     , a.base_to_global_rate  = b.base_to_global_rate 
                                     , a.base_to_order_rate  = b.base_to_order_rate 
                                     , a.billing_address_id  = b.billing_address_id 
                                     , a.created_at  = b.created_at 
                                     , a.customer_email  = b.customer_email 
                                     , a.customer_firstname  = b.customer_firstname 
                                     , a.customer_group_id  = b.customer_group_id 
                                     , a.customer_is_guest  = b.customer_is_guest 
                                     , a.customer_lastname  = b.customer_lastname 
                                     , a.customer_note  = b.customer_note 
                                     , a.customer_note_notify  = b.customer_note_notify 
                                     , a.discount_amount  = b.discount_amount 
                                     , a.discount_invoiced  = b.discount_invoiced 
                                     , a.email_sent  = b.email_sent 
                                     , a.global_currency_code  = b.global_currency_code 
                                     , a.grand_total  = b.grand_total 
                                     , a.discount_tax_compensation_amount  = b.discount_tax_compensation_amount 
                                     , a.discount_tax_compensation_invoiced  = b.discount_tax_compensation_invoiced 
                                     , a.increment_id  = b.increment_id 
                                     , a.is_virtual  = b.is_virtual 
                                     , a.order_currency_code  = b.order_currency_code 
                                     , a.protect_code  = b.protect_code 
                                     , a.quote_id  = b.quote_id 
                                     , a.remote_ip  = b.remote_ip 
                                     , a.shipping_amount  = b.shipping_amount 
                                     , a.shipping_description  = b.shipping_description 
                                     , a.shipping_discount_amount  = b.shipping_discount_amount 
                                     , a.shipping_discount_tax_compensation_amount  = b.shipping_discount_tax_compensation_amount 
                                     , a.shipping_incl_tax  = b.shipping_incl_tax 
                                     , a.shipping_invoiced  = b.shipping_invoiced 
                                     , a.shipping_tax_amount  = b.shipping_tax_amount 
                                     , a.state  = b.state 
                                     , a.status  = b.status 
                                     , a.store_currency_code  = b.store_currency_code 
                                     , a.store_id  = b.store_id 
                                     , a.store_name  = b.store_name 
                                     , a.store_to_base_rate  = b.store_to_base_rate 
                                     , a.store_to_order_rate  = b.store_to_order_rate 
                                     , a.subtotal  = b.subtotal 
                                     , a.subtotal_incl_tax  = b.subtotal_incl_tax 
                                     , a.subtotal_invoiced  = b.subtotal_invoiced 
                                     , a.tax_amount  = b.tax_amount 
                                     , a.tax_invoiced  = b.tax_invoiced 
                                     , a.total_due  = b.total_due 
                                     , a.total_invoiced  = b.total_invoiced 
                                     , a.total_item_count  = b.total_item_count 
                                     , a.total_paid  = b.total_paid 
                                     , a.total_qty_ordered  = b.total_qty_ordered 
                                     , a.updated_at  = b.updated_at 
                                     , a.weight  = b.weight 
                                     , a.billing_address_address_type  = b.billing_address_address_type 
                                     , a.billing_address_city  = b.billing_address_city 
                                     , a.billing_address_country_id  = b.billing_address_country_id 
                                     , a.billing_address_email  = b.billing_address_email 
                                     , a.billing_address_entity_id  = b.billing_address_entity_id 
                                     , a.billing_address_firstname  = b.billing_address_firstname 
                                     , a.billing_address_lastname  = b.billing_address_lastname 
                                     , a.billing_address_parent_id  = b.billing_address_parent_id 
                                     , a.billing_address_postcode  = b.billing_address_postcode 
                                     , a.billing_address_region  = b.billing_address_region 
                                     , a.billing_address_region_code  = b.billing_address_region_code 
                                     , a.billing_address_region_id  = b.billing_address_region_id 
                                     , a.billing_address_street  = b.billing_address_street 
                                     , a.billing_address_telephone  = b.billing_address_telephone 
                                     , a.billing_address_vat_id  = b.billing_address_vat_id 
                                     , a.payment_account_status  = b.payment_account_status 
                                     , a.payment_additional_information  = b.payment_additional_information 
                                     , a.payment_amount_ordered  = b.payment_amount_ordered 
                                     , a.payment_base_amount_ordered  = b.payment_base_amount_ordered 
                                     , a.payment_base_shipping_amount  = b.payment_base_shipping_amount 
                                     , a.payment_cc_exp_month  = b.payment_cc_exp_month 
                                     , a.payment_cc_exp_year  = b.payment_cc_exp_year 
                                     , a.payment_cc_last4  = b.payment_cc_last4 
                                     , a.payment_cc_type  = b.payment_cc_type 
                                     , a.payment_entity_id  = b.payment_entity_id 
                                     , a.payment_method  = b.payment_method 
                                     , a.payment_parent_id  = b.payment_parent_id 
                                     , a.payment_shipping_amount  = b.payment_shipping_amount 
                                     , a.payment_amount_paid  = b.payment_amount_paid 
                                     , a.payment_base_amount_paid  = b.payment_base_amount_paid 
                                     , a.payment_base_shipping_captured  = b.payment_base_shipping_captured 
                                     , a.payment_last_trans_id  = b.payment_last_trans_id 
                                     , a.payment_shipping_captured  = b.payment_shipping_captured 
                                     , a.base_discount_canceled  = b.base_discount_canceled 
                                     , a.base_shipping_canceled  = b.base_shipping_canceled 
                                     , a.base_subtotal_canceled  = b.base_subtotal_canceled 
                                     , a.base_tax_canceled  = b.base_tax_canceled 
                                     , a.base_total_canceled  = b.base_total_canceled 
                                     , a.discount_canceled  = b.discount_canceled 
                                     , a.shipping_canceled  = b.shipping_canceled 
                                     , a.subtotal_canceled  = b.subtotal_canceled 
                                     , a.tax_canceled  = b.tax_canceled 
                                     , a.total_canceled  = b.total_canceled 
                                     , a.extension_attributes_pickup_location_code  = b.extension_attributes_pickup_location_code 
                                     , a.extension_attributes_applied_taxes  = b.extension_attributes_applied_taxes 
                                     , a.extension_attributes_item_applied_taxes  = b.extension_attributes_item_applied_taxes 
                                     , a.extension_attributes_billing_customer_identification  = b.extension_attributes_billing_customer_identification                                      
           when not matched then insert(           
                                               applied_rule_ids 
                                             , base_currency_code 
                                             , base_discount_amount 
                                             , base_discount_invoiced 
                                             , base_grand_total 
                                             , base_discount_tax_compensation_amount 
                                             , base_discount_tax_compensation_invoiced 
                                             , base_shipping_amount 
                                             , base_shipping_discount_amount 
                                             , base_shipping_discount_tax_compensation_amnt 
                                             , base_shipping_incl_tax 
                                             , base_shipping_invoiced 
                                             , base_shipping_tax_amount 
                                             , base_subtotal 
                                             , base_subtotal_incl_tax 
                                             , base_subtotal_invoiced 
                                             , base_tax_amount 
                                             , base_tax_invoiced 
                                             , base_total_due 
                                             , base_total_invoiced 
                                             , base_total_invoiced_cost 
                                             , base_total_paid 
                                             , base_to_global_rate 
                                             , base_to_order_rate 
                                             , billing_address_id 
                                             , created_at 
                                             , customer_email 
                                             , customer_firstname 
                                             , customer_group_id 
                                             , customer_is_guest 
                                             , customer_lastname 
                                             , customer_note 
                                             , customer_note_notify 
                                             , discount_amount 
                                             , discount_invoiced 
                                             , email_sent 
                                             , entity_id 
                                             , global_currency_code 
                                             , grand_total 
                                             , discount_tax_compensation_amount 
                                             , discount_tax_compensation_invoiced 
                                             , increment_id 
                                             , is_virtual 
                                             , order_currency_code 
                                             , protect_code 
                                             , quote_id 
                                             , remote_ip 
                                             , shipping_amount 
                                             , shipping_description 
                                             , shipping_discount_amount 
                                             , shipping_discount_tax_compensation_amount 
                                             , shipping_incl_tax 
                                             , shipping_invoiced 
                                             , shipping_tax_amount 
                                             , state 
                                             , status 
                                             , store_currency_code 
                                             , store_id 
                                             , store_name 
                                             , store_to_base_rate 
                                             , store_to_order_rate 
                                             , subtotal 
                                             , subtotal_incl_tax 
                                             , subtotal_invoiced 
                                             , tax_amount 
                                             , tax_invoiced 
                                             , total_due 
                                             , total_invoiced 
                                             , total_item_count 
                                             , total_paid 
                                             , total_qty_ordered 
                                             , updated_at 
                                             , weight 
                                             , billing_address_address_type 
                                             , billing_address_city 
                                             , billing_address_country_id 
                                             , billing_address_email 
                                             , billing_address_entity_id 
                                             , billing_address_firstname 
                                             , billing_address_lastname 
                                             , billing_address_parent_id 
                                             , billing_address_postcode 
                                             , billing_address_region 
                                             , billing_address_region_code 
                                             , billing_address_region_id 
                                             , billing_address_street 
                                             , billing_address_telephone 
                                             , billing_address_vat_id 
                                             , payment_account_status 
                                             , payment_additional_information 
                                             , payment_amount_ordered 
                                             , payment_base_amount_ordered 
                                             , payment_base_shipping_amount 
                                             , payment_cc_exp_month 
                                             , payment_cc_exp_year 
                                             , payment_cc_last4 
                                             , payment_cc_type 
                                             , payment_entity_id 
                                             , payment_method 
                                             , payment_parent_id 
                                             , payment_shipping_amount 
                                             , payment_amount_paid 
                                             , payment_base_amount_paid 
                                             , payment_base_shipping_captured 
                                             , payment_last_trans_id 
                                             , payment_shipping_captured 
                                             , base_discount_canceled 
                                             , base_shipping_canceled 
                                             , base_subtotal_canceled 
                                             , base_tax_canceled 
                                             , base_total_canceled 
                                             , discount_canceled 
                                             , shipping_canceled 
                                             , subtotal_canceled 
                                             , tax_canceled 
                                             , total_canceled 
                                             , extension_attributes_pickup_location_code 
                                             , extension_attributes_applied_taxes 
                                             , extension_attributes_item_applied_taxes 
                                             , extension_attributes_billing_customer_identification 
                                             , subsidiary_id
                                             , account  
                                             , updated_timestamp          
                                 )                              
                                 values(
                                               coalesce(b.applied_rule_ids, '')
                                             , b.base_currency_code 
                                             , b.base_discount_amount 
                                             , b.base_discount_invoiced 
                                             , b.base_grand_total 
                                             , b.base_discount_tax_compensation_amount 
                                             , b.base_discount_tax_compensation_invoiced 
                                             , b.base_shipping_amount 
                                             , b.base_shipping_discount_amount 
                                             , b.base_shipping_discount_tax_compensation_amnt 
                                             , b.base_shipping_incl_tax 
                                             , b.base_shipping_invoiced 
                                             , b.base_shipping_tax_amount 
                                             , b.base_subtotal 
                                             , b.base_subtotal_incl_tax 
                                             , b.base_subtotal_invoiced 
                                             , b.base_tax_amount 
                                             , b.base_tax_invoiced 
                                             , b.base_total_due 
                                             , b.base_total_invoiced 
                                             , b.base_total_invoiced_cost 
                                             , b.base_total_paid 
                                             , b.base_to_global_rate 
                                             , b.base_to_order_rate 
                                             , b.billing_address_id 
                                             , b.created_at 
                                             , b.customer_email 
                                             , b.customer_firstname 
                                             , b.customer_group_id 
                                             , b.customer_is_guest 
                                             , b.customer_lastname 
                                             , b.customer_note 
                                             , b.customer_note_notify 
                                             , b.discount_amount 
                                             , b.discount_invoiced 
                                             , b.email_sent 
                                             , b.entity_id 
                                             , b.global_currency_code 
                                             , b.grand_total 
                                             , b.discount_tax_compensation_amount 
                                             , b.discount_tax_compensation_invoiced 
                                             , b.increment_id 
                                             , b.is_virtual 
                                             , b.order_currency_code 
                                             , b.protect_code 
                                             , b.quote_id 
                                             , b.remote_ip 
                                             , b.shipping_amount 
                                             , b.shipping_description 
                                             , b.shipping_discount_amount 
                                             , b.shipping_discount_tax_compensation_amount 
                                             , b.shipping_incl_tax 
                                             , b.shipping_invoiced 
                                             , b.shipping_tax_amount 
                                             , b.state 
                                             , b.status 
                                             , b.store_currency_code 
                                             , b.store_id 
                                             , b.store_name 
                                             , b.store_to_base_rate 
                                             , b.store_to_order_rate 
                                             , b.subtotal 
                                             , b.subtotal_incl_tax 
                                             , b.subtotal_invoiced 
                                             , b.tax_amount 
                                             , b.tax_invoiced 
                                             , b.total_due 
                                             , b.total_invoiced 
                                             , b.total_item_count 
                                             , b.total_paid 
                                             , b.total_qty_ordered 
                                             , b.updated_at 
                                             , b.weight 
                                             , b.billing_address_address_type 
                                             , b.billing_address_city 
                                             , b.billing_address_country_id 
                                             , b.billing_address_email 
                                             , b.billing_address_entity_id 
                                             , b.billing_address_firstname 
                                             , b.billing_address_lastname 
                                             , b.billing_address_parent_id 
                                             , b.billing_address_postcode 
                                             , b.billing_address_region 
                                             , b.billing_address_region_code 
                                             , b.billing_address_region_id 
                                             , b.billing_address_street 
                                             , b.billing_address_telephone 
                                             , b.billing_address_vat_id 
                                             , b.payment_account_status 
                                             , b.payment_additional_information 
                                             , b.payment_amount_ordered 
                                             , b.payment_base_amount_ordered 
                                             , b.payment_base_shipping_amount 
                                             , b.payment_cc_exp_month 
                                             , b.payment_cc_exp_year 
                                             , b.payment_cc_last4 
                                             , b.payment_cc_type 
                                             , b.payment_entity_id 
                                             , b.payment_method 
                                             , b.payment_parent_id 
                                             , b.payment_shipping_amount 
                                             , b.payment_amount_paid 
                                             , b.payment_base_amount_paid 
                                             , b.payment_base_shipping_captured 
                                             , b.payment_last_trans_id 
                                             , b.payment_shipping_captured 
                                             , b.base_discount_canceled 
                                             , b.base_shipping_canceled 
                                             , b.base_subtotal_canceled 
                                             , b.base_tax_canceled 
                                             , b.base_total_canceled 
                                             , b.discount_canceled 
                                             , b.shipping_canceled 
                                             , b.subtotal_canceled 
                                             , b.tax_canceled 
                                             , b.total_canceled 
                                             , b.extension_attributes_pickup_location_code 
                                             , b.extension_attributes_applied_taxes 
                                             , b.extension_attributes_item_applied_taxes 
                                             , b.extension_attributes_billing_customer_identification 
                                             , b.subsidiary_id
                                             , b.account                
                                             , current_timestamp                  
                                 );
    end