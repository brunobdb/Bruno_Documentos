CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_sales_control_tower_table_premium_models_update()
LANGUAGE PLvSQL AS $$
BEGIN
    
    PERFORM UPDATE ow_lao.ods_sales_control_tower_table a
           SET premiumproduct = 1
    FROM ow_lao.ods_sales_control_tower_table a
    JOIN OW_MD.DIM_CALENDAR b ON b.YYYYMMDD = CAST(a.PO_DATE AS DATE)
    JOIN OW_LAO.ODS_LAO_PRODUCT_PREMIUM_ITEMS c ON c.PLAN = b.YYYYWW_NORMAL_CALENDAR
    WHERE 
        c.ITEM = a.PO_SKU 
        AND a.SUBSIDIARY = c.AP2
        AND a.premiumproduct IS NULL
        AND CAST(a.PO_DATE AS DATE) >= DATE '2023-06-12';
                
    PERFORM UPDATE ow_lao.ods_sales_control_tower_table a
           SET premiumproduct = 1
    FROM ow_lao.ods_sales_control_tower_table a
    JOIN OW_MD.DIM_CALENDAR b ON b.YYYYMMDD = CAST(a.PO_DATE AS DATE)
    JOIN OW_LAO.ODS_LAO_PRODUCT_PREMIUM_ITEMS c ON c.PLAN = b.YYYYWW_NORMAL_CALENDAR
    WHERE 
        c.ITEM = a.PO_SKU 
        AND c.AP2 IN ('SELA-M','SELA-P')
        AND a.premiumproduct IS NULL
        AND a.client_subsidiary_id IN (7, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19)
        AND CAST(a.PO_DATE AS DATE) >= DATE '2023-06-12';

    PERFORM UPDATE ow_lao.ods_sales_control_tower_table a
    SET premiumproduct = 0
    WHERE premiumproduct IS NULL
      AND CAST(a.PO_DATE AS DATE) >= DATE '2023-06-12';

END
$$;