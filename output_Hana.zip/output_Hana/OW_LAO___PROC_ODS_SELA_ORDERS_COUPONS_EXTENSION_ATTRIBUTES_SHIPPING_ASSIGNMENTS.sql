create procedure ow_lao.proc_ods_sela_orders_coupons_extension_attributes_shipping_assignments
 language sqlscript as
 begin
     merge into ow_lao.ods_sela_orders_coupons_extension_attributes_shipping_assignments a
          using ow_lao.stg_sela_orders_coupons_extension_attributes_shipping_assignments b on b.store_id      = a.store_id
                                                                                          and b.subsidiary_id = a.subsidiary_id
                                                                                          and b.account       = a.account
                                                                                          and b.entity_id     = a.entity_id
           when    matched then update  
                                   set a.updated_timestamp = current_timestamp     
                                     , a.shipping_address_type = b.shipping_address_type
                                     , a.shipping_city = b.shipping_city
                                     , a.shipping_country_id = b.shipping_country_id
                                     , a.shipping_email = b.shipping_email
                                     , a.shipping_entity_id = b.shipping_entity_id
                                     , a.shipping_irstname = b.shipping_irstname
                                     , a.shipping_lastname = b.shipping_lastname
                                     , a.shipping_parent_id = b.shipping_parent_id
                                     , a.shipping_postcode = b.shipping_postcode
                                     , a.shipping_region = b.shipping_region
                                     , a.shipping_region_code = b.shipping_region_code
                                     , a.shipping_region_id = b.shipping_region_id
                                     , a.shipping_street = b.shipping_street
                                     , a.shipping_telephone = b.shipping_telephone
                                     , a.shipping_method = b.shipping_method                                                                                     
           when not matched then insert(           
                                           updated_timestamp 
                                         , shipping_address_type
                                         , shipping_city
                                         , shipping_country_id
                                         , shipping_email
                                         , shipping_entity_id
                                         , shipping_irstname
                                         , shipping_lastname
                                         , shipping_parent_id
                                         , shipping_postcode
                                         , shipping_region
                                         , shipping_region_code
                                         , shipping_region_id
                                         , shipping_street
                                         , shipping_telephone
                                         , shipping_method
                                         , store_id
                                         , entity_id
                                         , subsidiary_id
                                         , account      
                                 )      
                                 values(
                                           current_timestamp
                                         , b.shipping_address_type
                                         , b.shipping_city
                                         , b.shipping_country_id
                                         , b.shipping_email
                                         , b.shipping_entity_id
                                         , b.shipping_irstname
                                         , b.shipping_lastname
                                         , b.shipping_parent_id
                                         , b.shipping_postcode
                                         , b.shipping_region
                                         , b.shipping_region_code
                                         , b.shipping_region_id
                                         , b.shipping_street
                                         , b.shipping_telephone
                                         , b.shipping_method
                                         , b.store_id
                                         , b.entity_id
                                         , b.subsidiary_id
                                         , b.account                                           
                                 );
    end