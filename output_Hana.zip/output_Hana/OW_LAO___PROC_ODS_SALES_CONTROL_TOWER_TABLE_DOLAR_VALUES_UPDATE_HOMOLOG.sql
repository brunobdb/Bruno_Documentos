CREATE PROCEDURE OW_LAO.proc_ods_sales_control_tower_table_dolar_values_update_homolog
 LANGUAGE SQLSCRIPT AS
 BEGIN
        update ow_lao.ods_sales_control_tower_table a
           set po_itemdiscount_usd = COALESCE (a.po_itemdiscount_localcurr / cast(b.exchange_rate as decimal),0)
             , po_price_usd        = COALESCE (a.po_price_localcurr        / cast(b.exchange_rate as decimal),0)
             , po_totalprice_usd   = COALESCE (a.po_totalprice_local       / cast(b.exchange_rate as decimal),0)
          from ow_lao.ods_sales_control_tower_table a
          join ow_lao.ft_ap2_exchange_rate          b on b.valid_from  = cast(a.po_date as date)
                                                     and b.to_currency = a.currency
         where coalesce(a.po_totalprice_usd , 0)  = 0
           and coalesce(a.po_price_localcurr, 0) != 0
           and po_plataform_datasource in ('u_prj_ecom_synapcom.ft_ecom_order', 'u_prj_ecom.ft_ecom_order', 'u_prj_ecom.raw_vtex_ssg_br_shop_sales_order', 'ow_lao.ods_orders_visuar');
           
        update ow_lao.ods_sales_control_tower_table a
           set po_price_usd        = COALESCE (a.po_price_localcurr        / cast(b.exchange_rate as decimal),0)
             , po_totalprice_usd   = COALESCE (a.po_totalprice             / cast(b.exchange_rate as decimal),0)
             , po_itemdiscount_usd = COALESCE (a.po_itemdiscount_localcurr / cast(b.exchange_rate as decimal),0)
          from ow_lao.ods_sales_control_tower_table a
          join ow_lao.ft_ap2_exchange_rate          b on b.valid_from  = cast(a.po_date as date)
                                                     and b.to_currency = a.currency
         where coalesce(a.po_totalprice_usd , 0) = 0
           and coalesce(a.po_price_localcurr, 0) != 0
           and po_plataform_datasource in ('ow_lao.ods_hybris_sales');
 
           
        update ow_lao.ods_sales_control_tower_table            a
           set a.nerp_netprice         = COALESCE (cast(replace(c.so_net_price, ',', '') as decimal) / cast(d.exchange_rate as decimal),0)
             , a.nerp_netvalue         = COALESCE (cast(replace(c.so_net_value, ',', '') as decimal) / cast(d.exchange_rate as decimal),0)
             , a.nerp_cost             = COALESCE (cast(replace(c.cost        , ',', '') as decimal) / cast(d.exchange_rate as decimal),0)
          from ow_lao.ods_sales_control_tower_table            a
          join ow_md.dim_subsidiary                            b on lower(b.country) = lower(a.country)
          join ow_lao.ods_nerp_zrsdd6a120_sales_order_tracking c on c.customer_po    = a.po_sequence_orderid
                                                                and c.material       = a.po_sku
                                                                and c.sales_org      = b.sales_org
          join ow_lao.ft_ap2_exchange_rate                     d on d.valid_from     = cast(a.po_date as date)
                                                                and d.to_currency    = a.currency
         where coalesce(a.nerp_netprice, 0) = 0;     
         
                 update ow_lao.ods_sales_control_tower_table a
           set po_itemdiscount_usd = COALESCE (a.po_itemdiscount_localcurr / cast(b.exchange_rate as decimal),0)
             , po_price_usd        = COALESCE (a.po_price_localcurr        / cast(b.exchange_rate as decimal),0)
             , po_totalprice_usd   = COALESCE (a.po_totalprice_local       / cast(b.exchange_rate as decimal),0)
          from ow_lao.ods_sales_control_tower_table a
          join ow_lao.ft_ap2_exchange_rate          b on b.valid_from  = cast(a.po_date as date)
                                                     and b.to_currency = 'USD'
                                                     and a.currency    = 'PAB'
         where coalesce(a.po_totalprice_usd , 0)  = 0
           and coalesce(a.po_price_localcurr, 0) != 0
           and a.po_plataform_datasource in ('u_prj_ecom.ft_ecom_order')
           and a.currency = 'PAB' ;         
           
end