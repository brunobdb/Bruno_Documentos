CREATE PROCEDURE OW_LAO.proc_stg_table_ods_exclusives_items
(IN input_text NVARCHAR(250))
LANGUAGE SQLSCRIPT AS
BEGIN
	
truncate table OW_LAO.STG_LAO_PRODUCT_EXCLUSIVES_ITEMS;
      insert into OW_LAO.STG_LAO_PRODUCT_EXCLUSIVES_ITEMS
		   SELECT m.ITEM_EXCLUSIVES
		        , m.SUBSIDIARY
		        , m.DATE_START
		        , m.DATE_END
                , m.FILE_NAME
		     FROM OW_LAO.RAW_LAO_PRODUCT_EXCLUSIVES_ITEMS m
		    WHERE m.FILE_NAME = input_text
		    AND m.DATE_START IS NOT NULL 
		    AND m.DATE_END IS NOT null
		 GROUP BY m.ITEM_EXCLUSIVES
		        , m.SUBSIDIARY
		        , m.DATE_START
		        , m.DATE_END
		        , m.FILE_NAME;
		        
    MERGE INTO OW_LAO.ODS_LAO_PRODUCT_EXCLUSIVES_ITEMS O
         USING OW_LAO.STG_LAO_PRODUCT_EXCLUSIVES_ITEMS M ON O.ITEM_EXCLUSIVES = M.ITEM_EXCLUSIVES
		                                                        AND O.SUBSIDIARY      = M.SUBSIDIARY
		                                                        AND O.DATE_START      = M.DATE_START
																AND O.DATE_END 		  = M.DATE_END
          WHEN MATCHED 
          THEN UPDATE SET
						O.UPDATED_TIMESTAMP		= CURRENT_TIMESTAMP,
						O.ACTIVE 				= TRUE
          WHEN NOT MATCHED THEN INSERT (
                                     ITEM_EXCLUSIVES
                                   , DATE_START
                                   , DATE_END
                                   , FILE_NAME
                                   , SUBSIDIARY
                                   , ACTIVE
                                 )
                                VALUES (
                                         M.ITEM_EXCLUSIVES
                                       , M.DATE_START
                                       , M.DATE_END
                                       , M.FILE_NAME
                                       , M.SUBSIDIARY
                                       , TRUE
                                ); 
	
	UPDATE
			OW_LAO.ODS_LAO_PRODUCT_EXCLUSIVES_ITEMS A	
		SET
			A.ACTIVE 				= FALSE,
			A.UPDATED_TIMESTAMP 	= CURRENT_TIMESTAMP
		FROM
			OW_LAO.ODS_LAO_PRODUCT_EXCLUSIVES_ITEMS A
		WHERE
			NOT EXISTS(
				SELECT 
					1
				FROM
					OW_LAO.STG_LAO_PRODUCT_EXCLUSIVES_ITEMS B
				WHERE 
					A.ITEM_EXCLUSIVES = B.ITEM_EXCLUSIVES
		             AND A.SUBSIDIARY      = B.SUBSIDIARY
		             AND A.DATE_START      = B.DATE_START
					 AND A.DATE_END 	   = B.DATE_END
			)
		AND A.ACTIVE = TRUE;
	
       END