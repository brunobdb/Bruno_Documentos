CREATE PROCEDURE ow_lao.proc_ods_sales_control_tower_table_raw_vtex_ssg_br_shop
 
 LANGUAGE SQLSCRIPT AS
 BEGIN
	 
      truncate table ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop;
      truncate table ow_lao.tmp_ecommerce_sales_control_tower_vtex_ssg_br_shop_grouped;
                  
 -- Br Shop Orders   
       insert into  ow_lao.tmp_ecommerce_sales_control_tower_vtex_ssg_br_shop_grouped
select  
cast(a.creation_timestamp as date)   as po_date,
year(a.creation_timestamp)           as podate_year,
 month(a.creation_timestamp)         as podate_month,
 'Brazil'                            as country,
0                                    as samsung_care_order,
0                                    as samsung_care,
0                                    as samsung_care_eligibility,
0                                    as trade_in,
0                                    as trade_in_eligibility,
0                                    as trade_up,
0                                    as trade_up_eligibility ,
a.affiliate_id                       as costumer_code_id_name,
a.order_id                           as po_orderid,
a.seller_order_id                    as seller_po_orderid,
cast(null as varchar(3000))          as payment_card_brand,
cast(null as varchar(3000))          as payment_type,
 0                                   as installment,
null                                 as installment_eligibility,
a.cancellation_reason                as po_cancelation_reason,
e.product_group_1                    as po_productgroup,
a.sales_channel                      as po_code_sales_channel,
 null                                as po_costumer_id,
a.hostname                           as po_sitecode,
a.status                             as po_internal_status,
null                                 as po_invoicenumber,
 a.marketing_tags                    as po_campain_tags,
a.utm_campaign                       as po_campain,
a.coupon                             as po_coupon,
a.utm_medium                         as po_medium,
a.utm_source                         as po_src,
a.utmi_campaign                      as po_utmi_campaing,
a.sequence                           as po_sequence_orderid,
b.name                               as po_prodname,
COALESCE (C.REF_ID_KIT, b.REF_ID)    as po_sku ,
a.seller_id                          as po_seller_id,
a.seller_name                        as po_seller_name,
f.status                             as po_status,
6                                    as client_subsidiary_id,
'SEDA'                               as subsidiary,
'BRL'                                as currency,
null                                 as po_tradepolicy,
a.origin                             as po_vendortype  ,     
cast(null as varchar(255))           as channel,
cast(null as varchar(255))           as biz_type,
cast(null as varchar(255))           as audience_type,
cast(null as varchar(255))           as po_storename,
cast(null as varchar(255))           as client_acquirer_message,
a.updated_at                         as po_lastupdate_date_hour,
coalesce (c.quantity_kit, b.quantity)
                                     as po_orderqty,
coalesce (c.quantity_kit, b.quantity)         
                                     as po_qty,
d.price_shipping/ d.num_rows  
                                     as po_price_shipping,  
coalesce (c.discount_kit, b.discount)         
                                     as po_itemdiscount_localcurr,
0                                    as po_itemdiscount_usd,
coalesce (c.price_kit, b.price)      as po_price_localcurr ,
0                                    as po_price_usd,
'u_prj_ecom.raw_vtex_ssg_br_shop_sales_order'  
                                     as po_plataform_datasource,
a.created_at                         as po_source_insert_date,
a.updated_at                         as po_source_last_update_date,
current_timestamp                    as po_insert_date,
null                                 as po_last_update_date,
cast(null as varchar(3000))          as po_payment_remark,
cast(a.creation_timestamp as time)   as po_hour ,
0                                    as po_totalprice_usd,
0                                    as po_totalprice_local,
cast(null as varchar(255))           as po_devicetype,
c.ref_id                             as po_sku_kit,
c.name                               as po_prodname_kit,
cast(0.00 as decimal)                as po_price_localcurr_kit,
cast(0.00 as decimal)                as po_itemdiscount_localcurr_kit,
case 
when c.is_kit is null 
then false  
else c.is_kit 
end                                  as is_kit ,
'BRA'                                as country_cd,
cast(null as varchar(255))           as biz_type_ebi_hq,
cast(null as varchar(255))           as global_channel_ebi_hq,
D.selected_sla                       as shipping_method,
cast(null as varchar(255))           AS customer_type,
cast(null as varchar(255))           AS po_mobile_os,
cast(null as varchar(255))           AS delivery_mode
,CAST (0 AS int )                    AS crp
               
from u_prj_ecom.raw_vtex_ssg_br_shop_sales_order   a 
--item
join 
(select 
order_id,
item_index ,
unique_id,
name , 
sku_id,
ref_id, 
price/100 as price, 
quantity,
(price - selling_price)/100 * quantity as discount
from 
u_prj_ecom.raw_vtex_ssg_br_shop_sales_order_item
) b on b.order_id = a.order_id 
-- componente
left join 
(
select
a.order_id,
a.unique_id,
a.sku_id,
b.ref_id, 
a.ref_id as ref_id_kit, 
a.name,
a.price/100 as price_kit, 
b.quantity* a.quantity as quantity_kit,
true                   as is_kit, 
(a.price - a.selling_price)/100 * (b.quantity* a.quantity) as discount_kit
from 
 u_prj_ecom.raw_vtex_ssg_br_shop_sales_order_item_components a
 join u_prj_ecom.raw_vtex_ssg_br_shop_sales_order_item b       on  b.order_id  = a.order_id 
                                                              and  b.unique_id = a.unique_id   
                                                              and  b.sku_id    = a.sku_id
 ) c 
 on c.order_id =  a.order_id 
and c.unique_id = b.unique_id   
and c.sku_id    = b.sku_id
                                                                
                                                                
--- shipping
left join 
(  select 
    a.order_id,
    b.item_index,
    d.price/100 as price_shipping,
    c.unique_id, 
    c.sku_id, 
    d.selected_sla ,
    count(*) as num_rows
  from u_prj_ecom.raw_vtex_ssg_br_shop_sales_order a
  join u_prj_ecom.raw_vtex_ssg_br_shop_sales_order_item b 
    on b.order_id = a.order_id
   left join u_prj_ecom.raw_vtex_ssg_br_shop_sales_order_item_components c 
    on  c.order_id  = a.order_id 
    and c.unique_id = b.unique_id 
    and c.sku_id    = b.sku_id
  left join 
   u_prj_ecom.raw_vtex_ssg_br_shop_sales_order_shipping d
   on d.order_id   = a.order_id
  and d.item_index = b.item_index   
    
    group by 
    a.order_id,
    b.item_index,
    d.price,
    c.unique_id, 
    c.sku_id,
    d.selected_sla ) d on d.order_id   = a.order_id
                      and d.item_index = b.item_index 
                                                                                 
left join ow_md.dim_product     e                         on e.sku           = coalesce (c.ref_id_kit, b.ref_id)
left join ow_lao.dim_ods_sales_control_tower_table_status_mapping f
                                                          on f.status_origin = coalesce(a.status, 'incomplete')
    where 1 = 1 
             --  and cast(a.creation_timestamp as date) >= '2025-01-01'  
               and b.quantity is not null 
               and a.updated_at >= add_days(current_date, -5)
               and not exists(                        
                        select 1
                          from ow_lao.ods_sales_control_tower_table aa
                         where aa.po_orderid                  = a.order_id
                           and aa.po_sku                      = b.ref_id
                           and aa.country                     = 'Brazil'
                           and aa.po_internal_status          = coalesce(a.status, 'incomplete')
                           and aa.po_source_last_update_date >= cast(a.updated_at as seconddate)
                   )
;
delete  from ow_lao.tmp_ecommerce_sales_control_tower_vtex_ssg_br_shop_grouped 
where  po_sku like 'F%'
;
-- po_totalprice_local 
        update ow_lao.tmp_ecommerce_sales_control_tower_vtex_ssg_br_shop_grouped         a
           set a.po_totalprice_local =
            round(
        coalesce(po_price_localcurr, 0) * coalesce(po_qty, 0) 
        - coalesce(po_itemdiscount_localcurr, 0) 
        + coalesce(po_price_shipping, 0),
        5)
        
          from ow_lao.tmp_ecommerce_sales_control_tower_vtex_ssg_br_shop_grouped     a
 ;
         
           -- Conversao para dolar
        update ow_lao.tmp_ecommerce_sales_control_tower_vtex_ssg_br_shop_grouped   a
           set po_itemdiscount_usd = round(coalesce (a.po_itemdiscount_localcurr / cast(b.exchange_rate as decimal),0),2)
             , po_price_usd        = round(coalesce (a.po_price_localcurr        / cast(b.exchange_rate as decimal),0),2)
             , po_totalprice_usd   = round(coalesce (a.po_totalprice_local       / cast(b.exchange_rate as decimal),0),2)
          from ow_lao.tmp_ecommerce_sales_control_tower_vtex_ssg_br_shop_grouped   a
          join ow_lao.ft_ap2_exchange_rate                                   b on b.valid_from  = add_days(a.po_date, -1)
                                                                              and b.to_currency = a.currency; 
 
insert into ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop
select 
po_date,
podate_year,
podate_month,
country,
samsung_care_order,
samsung_care,
samsung_care_eligibility,
trade_in,
trade_in_eligibility,
trade_up,
trade_up_eligibility,
costumer_code_id_name,
po_orderid,
seller_po_orderid,
payment_card_brand,
payment_type,
installment,
installment_eligibility,
po_cancelation_reason,
po_productgroup,
po_code_sales_channel,
po_costumer_id,
po_sitecode,
po_internal_status,
po_invoicenumber,
po_campain_tags,
po_campain,
po_coupon,
po_medium,
po_src,
po_utmi_campaing,
po_sequence_orderid,
po_prodname,
po_sku,
po_seller_id,
po_seller_name,
po_status,
client_subsidiary_id,
subsidiary,
currency,
po_tradepolicy,
po_vendortype,
channel,
biz_type,
audience_type,
po_storename,
client_acquirer_message,
po_lastupdate_date_hour,
sum(po_orderqty) as po_orderqty,
sum (po_qty) as po_qty,
sum(po_itemdiscount_localcurr) as po_itemdiscount_localcurr,
sum(po_itemdiscount_usd) as po_itemdiscount_usd,
sum(po_price_localcurr) as po_price_localcurr,
sum(po_price_usd) as po_price_usd,
po_plataform_datasource,
po_source_insert_date,
po_source_last_update_date,
po_insert_date,
po_last_update_date,
po_payment_remark,
po_hour,
sum(po_totalprice_usd) as po_totalprice_usd,
sum (po_totalprice_local) as po_totalprice_local,
po_devicetype,
coalesce(po_sku_kit, '') as po_sku_kit,
coalesce(po_prodname_kit, false) as po_prodname_kit,
sum(po_price_localcurr_kit) as po_price_localcurr_kit,
sum (po_itemdiscount_localcurr_kit) as po_itemdiscount_localcurr_kit,
is_kit,
country_cd,
biz_type_ebi_hq,
global_channel_ebi_hq,
shipping_method,
customer_type,
po_mobile_os,
delivery_mode,
crp
from ow_lao.tmp_ecommerce_sales_control_tower_vtex_ssg_br_shop_grouped
group by 
    po_date,
    podate_year,
    podate_month,
    country,
    samsung_care_order,
    samsung_care,
    samsung_care_eligibility,
    trade_in,
    trade_in_eligibility,
    trade_up,
    trade_up_eligibility,
    costumer_code_id_name,
    po_orderid,
    seller_po_orderid,
    payment_card_brand,
    payment_type,
    installment,
    installment_eligibility,
    po_cancelation_reason,
    po_productgroup,
    po_code_sales_channel,
    po_costumer_id,
    po_sitecode,
    po_internal_status,
    po_invoicenumber,
    po_campain_tags,
    po_campain,
    po_coupon,
    po_medium,
    po_src,
    po_utmi_campaing,
    po_sequence_orderid,
    po_prodname,
    po_sku,
    po_seller_id,
    po_seller_name,
    po_status,
    client_subsidiary_id,
    subsidiary,
    currency,
    po_tradepolicy,
    po_vendortype,
    channel,
    biz_type,
    audience_type,
    po_storename,
    client_acquirer_message,
    po_lastupdate_date_hour,
    po_plataform_datasource,
    po_source_insert_date,
    po_source_last_update_date,
    po_insert_date,
    po_last_update_date,
    po_payment_remark,
    po_hour,
    po_devicetype,
    po_sku_kit,
    po_prodname_kit,
    is_kit,
    country_cd,
    biz_type_ebi_hq,
    global_channel_ebi_hq,
    shipping_method,
    customer_type,
    po_mobile_os,
    delivery_mode,
    crp
   
    ;
 -- Samsung Care
    update ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop
       set samsung_care = 1
     where upper(po_prodname) like upper('%samsung care%');
     
    
     -- Payments                        
                 
             drop table ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop_payments;
    create column table ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop_payments
        as (
                 
              select a.po_orderid
                   , max(a.installments)                as installment
                   , string_agg(a.brand, '|')           as payment_card_brand
                   , string_agg(a.payment_type, '|')    as payment_type
                   , string_agg(
                        a.payment_type     || ':' || 
                        a.brand            || ':' || 
                        a.value / 100.00   || ':' || 
                        a.installments
                        , '|' 
                   )                                    as po_payment_remark
                from (   
                            select distinct
                                   a.po_orderid
                                 , case coalesce(b.payment_group, '')
                                        when ''
                                        then ''
                                        else coalesce(b.payment_system_name, '')
                                   end                                   as brand
                                 , coalesce(b.payment_group      , '')   as payment_type
                                 , b.value
                                 , case when b.installments is  null then 1 else b.installments end as installments
                              from ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop_homolog_2 a  
                              join u_prj_ecom.raw_vtex_ssg_br_shop_sales_order_payment           b on b.order_id = a.po_orderid
                 ) a
            group by a.po_orderid
        );   
        
         update ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop     a
           set installment        = b.installment
             , payment_card_brand = b.payment_card_brand
             , payment_type       = b.payment_type
             , po_payment_remark  = b.po_payment_remark
          from ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop       a
          join ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop_payments b on b.po_orderid = a.po_orderid;        
                                                                                
                                                                                
  
  -- Sales channel                                                                            
        update ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop a
           set a.channel               = b.global_channel
             , a.biz_type              = b.biz_type
             , a.audience_type         = b.audience_type
             , a.po_storename          = b.partner_level
             , a.biz_type_ebi_hq       = b.biz_type_ebi
             ,a.global_channel_ebi_hq  = b.global_channel_ebi
             , a.customer_type         = b.customer_type
             , a.po_mobile_os          = b.po_mobile_os
          from  ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop  a
          join ow_md.sales_channel                                           b on lower(b.country)            = lower(a.country)
                                                                              and b.sales_channel             = a.po_code_sales_channel
                                                                              and coalesce(b.affiliate_id,'') = coalesce(a.costumer_code_id_name,'')
         where client_subsidiary_id in (6)
           and lower(b.plataform_type)      = 'vtex'
           and coalesce(has_store_id, 'N')  = 'N'
           and coalesce(b.sku_mapping, '')  = '';
          
        update ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop a
           set a.channel               = b.global_channel
             , a.biz_type              = b.biz_type
             , a.audience_type         = b.audience_type
             , a.po_storename          = b.partner_level
             , a.biz_type_ebi_hq       = b.biz_type_ebi
             , a.global_channel_ebi_hq = b.global_channel_ebi
             , a.customer_type         = b.customer_type
             , a.po_mobile_os          = b.po_mobile_os
          from  ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop  a
          join ow_md.sales_channel                                       b on lower(b.country)            = lower(a.country)
                                                                          and b.sales_channel             = a.po_code_sales_channel
         where client_subsidiary_id    in (6)
           and a.po_code_sales_channel in ('62','65','22')
           and coalesce(b.sku_mapping, '') = '';
           
           
        -- Sales channel by SKU sufix   
        update ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop a
           set a.channel               = b.global_channel
             , a.biz_type              = b.biz_type
             , a.audience_type         = b.audience_type
             , a.po_storename          = b.partner_level
             , a.biz_type_ebi_hq       = b.biz_type_ebi
             , a.global_channel_ebi_hq = b.global_channel_ebi
             , a.customer_type         = b.customer_type
             , a.po_mobile_os          = b.po_mobile_os
          from ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop  a
          join ow_md.sales_channel                                            b on lower(b.country)            = lower(a.country)
                                                                               and b.sales_channel             = a.po_code_sales_channel
                                                                               and coalesce(b.affiliate_id,'') = coalesce(a.costumer_code_id_name,'')
                                                                               and b.sku_mapping               = substring(
                                                                                                                       a.po_sku
                                                                                                                     , locate(a.po_sku, '_', -1)
                                                                                                                     , length(a.po_sku)
                                                                                                                 )
         where client_subsidiary_id         in (6)
           and lower(b.plataform_type)       = 'vtex'
           and coalesce(has_store_id, 'N')   = 'N'
           and coalesce(b.sku_mapping, '')  != '';             
          
------------------------------------------------------------------------------------------
      -- Sales channel    -MIGRAÇÃO Colaboradores | Outlet] GO-LIVE                                                                        
        update ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop  a
           set a.channel               = b.global_channel
             , a.biz_type              = b.biz_type
             , a.audience_type         = b.audience_type
             , a.po_storename          = b.partner_level
             , a.biz_type_ebi_hq       = b.biz_type_ebi
             ,a.global_channel_ebi_hq  = b.global_channel_ebi
             , a.customer_type         = b.customer_type
             , a.po_mobile_os          = b.po_mobile_os
          from ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop a
          join ow_md.sales_channel                                           b on lower(b.country)            = lower(a.country)
                                                                              and b.sales_channel             = a.po_code_sales_channel
                                                                              and coalesce(b.affiliate_id,'') = coalesce(a.costumer_code_id_name,'')
         where client_subsidiary_id        in (6)
           and lower(b.plataform_type)     = 'vtex'
           and coalesce(has_store_id, 'N') = 'N'
           and a.po_code_sales_channel     in ('3','48','50')
           and cast (a.po_date as date)    >= '2025-05-27'
           and coalesce(b.sku_mapping, '')  = '';
           
                                                                            
        update ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop  a
           set a.channel               = 'eStore' 
             , a.biz_type              = 'B2C'
             , a.audience_type         = 'Shop'
             , a.po_storename          = 'Shop'
             , a.biz_type_ebi_hq       = 'B2C'
             ,a.global_channel_ebi_hq  = 'eStore'
          from ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop  a
         WHERE a.po_code_sales_channel in ('3','48','50')
           and a.costumer_code_id_name is null 
           and cast (a.po_date as date) <= '2025-05-26';
------------------------------------------------------------------------------------------
          
        update  ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop a
           set a.channel               = 'eStore'
             , a.biz_type              = 'B2C' 
             , a.audience_type         = 'Store+' 
             , a.po_storename          = 'Store+' 
             , a.biz_type_ebi_hq       = 'B2C'
             ,a.global_channel_ebi_hq  = 'eStore'
          from  ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop a
          join "U_PRJ_ECOM"."VIEW_ECOM_ENDLESS_AISLE_REPORT"                 b on b."order_id"    = a.po_orderid
                                                                           
         where client_subsidiary_id in (6);
           
-- app samsung
          update ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop
             set po_devicetype = 'MOBILEAPP'
           where po_storename in ('App Samsung','App IOS','App Android')
             and client_subsidiary_id = 6;            
             
-- default po_device_type   
          update  ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop
             set po_devicetype = 'Web'
           where po_devicetype is null
             and client_subsidiary_id = 6; 
            
--DELIVERY_MODE MAPPING
   		update 
            ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop       a
        set   
            a.delivery_mode         = b.delivery_mode
        from 
            ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop           a
        join   
            ow_lao.dim_lao_delivery_mode_mapping_control_tower          b on b.subsidiary       = a.subsidiary 
                                                                        and  b.shipping_method  = a.shipping_method 
        where  
            b.active = true
            and a.delivery_mode is null;
           
 -- PO_COUPON VTEX CONTROL TOWER - TF_D2C_NERP_SALES
	update ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop a
	       set po_coupon = b.coupon
	      from ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop a
	      join ow_lao.TF_D2C_NERP_SALES             b on b.order_id   = a.po_orderid
	                                                 and b.sku        = a.po_sku
	                                                 and b.subsidiary = a.subsidiary
	     where 1 = 1 
	       and b.source                    = 'PO'
	       and b.subsidiary              = 'SEDA'
	       and coalesce(b.coupon   , '') != ''
	       and coalesce(a.po_coupon, '') = '';
 
           
 --CRP mapping Storename/Voucher_coupon --lucas.gil -03/09/2025
		update
		    ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop     a
		set
		    a.crp = 1  
		from
		     ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop     a
		join ow_lao.dim_lao_crp_cs_storename b on
		     lower(b.storename_crp) = lower (a.po_storename)
		    and a.subsidiary = b.subsidiary
		    where a.crp = 0;
   
  ----Mapping ALL coupon(GREATER THAN 3 digits)--lucas.gil -03/09/2025
		update
			 ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop a
		set
			a.crp = 2  
		from
			 ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop a
		join ow_lao.dim_lao_crp_cs_voucher_coupon b on
			 lower(b.voucher_coupon) = lower (a.po_coupon) 
				and b.subsidiary = a.subsidiary
			where a.crp = 0
				and length(b.voucher_coupon) > 3;
	
--------Partial COUPON mapping with "-" before/after coupon --lucas.gil -03/09/2025
	update
		 ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop a
	set
		a.crp = 2
	from
		 ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop a
	join ow_lao.dim_lao_crp_cs_voucher_coupon b on
		        	 locate (a.po_coupon, '-' || b.voucher_coupon || '-') > 0
		        	 and b.subsidiary = a.subsidiary
		        	where a.crp = 0
		        and length(b.voucher_coupon) = 3;
	       
	update
		 ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop a
	set
		a.crp = 2	
	from
		 ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop a
	join ow_lao.dim_lao_crp_cs_voucher_coupon b on
						  	locate(a.po_coupon, b.voucher_coupon || '-') = 1
		        	 and a.subsidiary = b.subsidiary
		        	where a.crp = 0
		        and length(b.voucher_coupon) = 3;
	       
       
-- Control tower
     merge into ow_lao.ods_sales_control_tower_table                           a
          using  ow_lao.tmp_ecommerce_sales_control_tower_raw_vtex_ssg_br_shop b on b.po_orderid = a.po_orderid
                                                                                          and b.po_sku     = a.po_sku
                                                                                          and b.country    = a.country
                                                                                          and b.po_sku_kit = a.po_sku_kit
           when    matched then update  
                                   set a.po_date                    = b.po_date
                                     , a.po_hour                    = b.po_hour
                                     , a.podate_year                = b.podate_year
                                     , a.podate_month               = b.podate_month
                                     , a.samsung_care_order         = b.samsung_care_order
                                     , a.samsung_care               = b.samsung_care
                                     , a.samsung_care_eligibility   = b.samsung_care_eligibility
                                     , a.trade_in                   = b.trade_in
                                     , a.trade_in_eligibility       = b.trade_in_eligibility
                                     , a.costumer_code_id_name      = b.costumer_code_id_name
                                     , a.seller_po_orderid          = b.seller_po_orderid
                                     , a.payment_card_brand         = b.payment_card_brand
                                     , a.payment_type               = b.payment_type
                                     , a.installment                = b.installment
                                     , a.installment_eligibility    = b.installment_eligibility
                                     , a.po_cancelation_reason      = b.po_cancelation_reason
                                     , a.po_productgroup            = b.po_productgroup
                                     , a.po_code_sales_channel      = b.po_code_sales_channel
                                     , a.po_costumer_id             = b.po_costumer_id
                                     , a.po_sitecode                = b.po_sitecode
                                     , a.po_internal_status         = b.po_internal_status
                                     , a.po_invoicenumber           = b.po_invoicenumber
                                     , a.po_campain_tags            = b.po_campain_tags
                                     , a.po_campain                 = b.po_campain
                                     , a.po_coupon                  = b.po_coupon
                                     , a.po_medium                  = b.po_medium
                                     , a.po_src                     = b.po_src
                                     , a.po_utmi_campaing           = b.po_utmi_campaing
                                     , a.po_prodname                = b.po_prodname
                                     , a.po_seller_id               = b.po_seller_id
                                     , a.po_seller_name             = b.po_seller_name
                                     , a.po_status                  = b.po_status
                                     , a.client_subsidiary_id       = b.client_subsidiary_id
                                     , a.subsidiary                 = b.subsidiary
                                     , a.currency                   = b.currency
                                     , a.po_tradepolicy             = b.po_tradepolicy
                                     , a.po_vendortype              = b.po_vendortype
                                     , a.channel                    = b.channel
                                     , a.biz_type                   = b.biz_type
                                     , a.audience_type              = b.audience_type
                                     , a.po_storename               = b.po_storename
                                     , a.client_acquirer_message    = b.client_acquirer_message
                                     , a.po_lastupdate_date_hour    = b.po_lastupdate_date_hour
                                     , a.po_orderqty                = b.po_orderqty
                                     , a.po_qty                     = b.po_qty
                                     , a.po_itemdiscount_localcurr  = b.po_itemdiscount_localcurr
                                     , a.po_itemdiscount_usd        = b.po_itemdiscount_usd
                                     , a.po_price_localcurr         = b.po_price_localcurr
                                     , a.po_price_usd               = b.po_price_usd
                                     , a.po_plataform_datasource    = b.po_plataform_datasource
                                     , a.po_source_insert_date      = b.po_source_insert_date
                                     , a.po_source_last_update_date = b.po_source_last_update_date
                                     , a.po_insert_date             = b.po_insert_date
                                     , a.po_last_update_date        = b.po_last_update_date
                                     , a.po_payment_remark          = b.po_payment_remark
                                     , a.po_totalprice_usd          = b.po_totalprice_usd
                                     , a.po_totalprice_local        = b.po_totalprice_local
                                     , a.po_devicetype              = b.po_devicetype
                                     , a.updated_datetime           = current_timestamp
                                     , a.po_sku_kit                 = b.po_sku_kit  
                                     , a.po_prodname_kit            = b.po_prodname_kit           
                                     , a.is_kit                     = b.is_kit
                                     , a.country_cd                 = b.country_cd  
                                     , a.biz_type_ebi_hq            = b.biz_type_ebi_hq 
                                     , a.global_channel_ebi_hq      = b.global_channel_ebi_hq
                                     , a.shipping_method            = b.shipping_method
                                     , a.customer_type              = b.customer_type
                                     , a.po_mobile_os               = b.po_mobile_os
                                     , a.delivery_mode              = b.delivery_mode
                                     , a.crp 						= b.crp
           when not matched then insert(
                                           po_date
                                         , po_hour
                                         , podate_year
                                         , podate_month
                                         , country
                                         , samsung_care_order
                                         , samsung_care
                                         , samsung_care_eligibility
                                         , trade_in
                                         , trade_in_eligibility
                                         , costumer_code_id_name
                                         , po_orderid
                                         , seller_po_orderid
                                         , payment_card_brand
                                         , payment_type
                                         , installment
                                         , installment_eligibility
                                         , po_cancelation_reason
                                         , po_productgroup
                                         , po_code_sales_channel
                                         , po_costumer_id
                                         , po_sitecode
                                         , po_internal_status
                                         , po_invoicenumber
                                         , po_campain_tags
                                         , po_campain
                                         , po_coupon
                                         , po_medium
                                         , po_src
                                         , po_utmi_campaing
                                         , po_sequence_orderid
                                         , po_prodname
                                         , po_sku
                                         , po_seller_id
                                         , po_seller_name
                                         , po_status
                                         , client_subsidiary_id
                                         , subsidiary
                                         , currency
                                         , po_tradepolicy
                                         , po_vendortype
                                         , channel
                                         , biz_type
                                         , audience_type
                                         , po_storename
                                         , client_acquirer_message
                                         , po_lastupdate_date_hour
                                         , po_orderqty
                                         , po_qty
                                         , po_itemdiscount_localcurr
                                         , po_itemdiscount_usd
                                         , po_price_localcurr
                                         , po_price_usd
                                         , po_plataform_datasource
                                         , po_source_insert_date
                                         , po_source_last_update_date
                                         , po_insert_date
                                         , po_last_update_date
                                         , po_payment_remark   
                                         , po_totalprice_usd
                                         , po_totalprice_local    
                                         , po_devicetype    
                                         , po_sku_kit                   
                                         , po_prodname_kit              
                                         , is_kit    
                                         , country_cd
                                         , biz_type_ebi_hq              
                                         , global_channel_ebi_hq  
                                         , shipping_method
                                         , customer_type
                                         , po_mobile_os
                                         , delivery_mode
                                         , crp
                                 )
                                 values(
                                           b.po_date
                                         , b.po_hour
                                         , b.podate_year
                                         , b.podate_month
                                         , b.country
                                         , b.samsung_care_order
                                         , b.samsung_care
                                         , b.samsung_care_eligibility
                                         , b.trade_in
                                         , b.trade_in_eligibility
                                         , b.costumer_code_id_name
                                         , b.po_orderid
                                         , b.seller_po_orderid
                                         , b.payment_card_brand
                                         , b.payment_type
                                         , b.installment
                                         , b.installment_eligibility
                                         , b.po_cancelation_reason
                                         , b.po_productgroup
                                         , b.po_code_sales_channel
                                         , b.po_costumer_id
                                         , b.po_sitecode
                                         , b.po_internal_status
                                         , b.po_invoicenumber
                                         , b.po_campain_tags
                                         , b.po_campain
                                         , b.po_coupon
                                         , b.po_medium
                                         , b.po_src
                                         , b.po_utmi_campaing
                                         , b.po_sequence_orderid
                                         , b.po_prodname
                                         , b.po_sku
                                         , b.po_seller_id
                                         , b.po_seller_name
                                         , b.po_status
                                         , b.client_subsidiary_id
                                         , b.subsidiary
                                         , b.currency
                                         , b.po_tradepolicy
                                         , b.po_vendortype
                                         , b.channel
                                         , b.biz_type
                                         , b.audience_type
                                         , b.po_storename
                                         , b.client_acquirer_message
                                         , b.po_lastupdate_date_hour
                                         , b.po_orderqty
                                         , b.po_qty
                                         , b.po_itemdiscount_localcurr
                                         , b.po_itemdiscount_usd
                                         , b.po_price_localcurr
                                         , b.po_price_usd
                                         , b.po_plataform_datasource
                                         , b.po_source_insert_date
                                         , b.po_source_last_update_date
                                         , b.po_insert_date
                                         , b.po_last_update_date
                                         , b.po_payment_remark   
                                         , b.po_totalprice_usd
                                         , b.po_totalprice_local                              
                                         , b.po_devicetype
                                         , b.po_sku_kit                   
                                         , b.po_prodname_kit              
                                         , b.is_kit 
                                         , b.country_cd 
                                         , b.biz_type_ebi_hq                 
                                         , b.global_channel_ebi_hq  
                                         , b.shipping_method
                                         , b.customer_type
                                         , b.po_mobile_os
                                         , b.delivery_mode
                                         , b.crp
                                 );    
  end