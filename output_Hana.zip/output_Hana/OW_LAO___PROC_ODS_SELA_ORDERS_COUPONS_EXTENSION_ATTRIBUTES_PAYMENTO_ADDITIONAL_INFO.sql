create procedure ow_lao.proc_ods_sela_orders_coupons_extension_attributes_paymento_additional_info
 language sqlscript as
 begin
     merge into ow_lao.ods_sela_orders_coupons_extension_attributes_paymento_additional_info a
          using ow_lao.stg_sela_orders_coupons_extension_attributes_paymento_additional_info b on b.store_id      = a.store_id
                                                                                              and b.subsidiary_id = a.subsidiary_id
                                                                                              and b.account       = a.account
                                                                                              and b.entity_id     = a.entity_id
                                                                                              and hash_sha256(
                                                                                                        to_varbinary(ifnull(b.key  ,'0'))
                                                                                                      , to_varbinary(ifnull(b.value,'0'))
                                                                                                   )             = a.guid
           when    matched then update  
                                   set a.updated_timestamp = current_timestamp     
                                     , a.key  = b.key 
                                     , a.value  = b.value                                                                                   
           when not matched then insert(           
                                           updated_timestamp 
                                         , key 
                                         , value 
                                         , store_id 
                                         , entity_id 
                                         , subsidiary_id
                                         , account
                                         , guid      
                                 )      
                                 values(
                                           current_timestamp
                                         , b.key 
                                         , b.value 
                                         , b.store_id 
                                         , b.entity_id 
                                         , b.subsidiary_id
                                         , b.account
                                         , hash_sha256(
                                                to_varbinary(ifnull(b.key  ,'0'))
                                               , to_varbinary(ifnull(b.value,'0'))
                                           )                                        
                                 );
    end