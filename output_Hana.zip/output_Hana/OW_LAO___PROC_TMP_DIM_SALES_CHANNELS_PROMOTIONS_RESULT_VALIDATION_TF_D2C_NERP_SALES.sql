CREATE PROCEDURE OW_LAO.proc_tmp_dim_sales_channels_promotions_result_validation_tf_d2c_nerp_sales
 LANGUAGE SQLSCRIPT AS
 BEGIN
             drop table ow_lao.tmp_ft_d2c_vtex_promotion_prom_name_reference;
    create column table ow_lao.tmp_ft_d2c_vtex_promotion_prom_name_reference
        as (   
                select a.environment
                     , a.sales_channel
                     , a.order_id
                     , a.marketplace_order_id
                     , a.reference_code
                     , a.item_name
                     , a.prom_name
                     , substring(a.prom_name
                          , (locate(a.prom_name, '[')) + 1
                          , (locate(a.prom_name, ']')
                             - locate(a.prom_name, '[')) - 1
                       )                                as prom_name_reference
                  from ow_lao.ft_d2c_vtex_promotion a
                 where a.po_creation_date between '2024-05-01' and '2024-05-31'
              order by a.po_creation_date
        );
        
             drop table ow_lao.tmp_ft_d2c_vtex_promotion_prom_name_reference_fix_null;
    create column table ow_lao.tmp_ft_d2c_vtex_promotion_prom_name_reference_fix_null
        as (   
                select distinct
                       a.environment
                     , a.sales_channel
                     , a.order_id
                     , a.marketplace_order_id
                     , a.reference_code
                     , a.item_name
                     , a.prom_name
                     , coalesce(a.prom_name_reference, '')  as prom_name_reference
                  from ow_lao.tmp_ft_d2c_vtex_promotion_prom_name_reference a
        );         
        
             drop table ow_lao.tmp_dim_sales_channels_promotions_result_ordering;
    create column table ow_lao.tmp_dim_sales_channels_promotions_result_ordering
        as (          
            select a.environment
                 , a.order_id
                 , a.marketplace_order_id
                 , a.reference_code
                 , coalesce(b.campaign_name_type, c.Tipo_Promo) as campaign_name_type
              from ow_lao.tmp_ft_d2c_vtex_promotion_prom_name_reference_fix_null a
         left join ow_md.dim_sales_channels_promotions                           b on coalesce(b.campaign_reference, '') = a.prom_name_reference
         left join ow_md.input_sales_channels_promotions_statics                 c on lower(c.prom_name)                 = lower(a.prom_name)
          group by a.environment
                 , a.order_id
                 , a.marketplace_order_id
                 , a.reference_code
                 , coalesce(b.campaign_name_type, c.Tipo_Promo)
          order by coalesce(b.campaign_name_type, c.Tipo_Promo)
         );      
        
             drop table ow_lao.tmp_dim_sales_channels_promotions_result_validation;
    create column table ow_lao.tmp_dim_sales_channels_promotions_result_validation
        as (          
            select a.environment
                 , a.order_id
                 , a.marketplace_order_id
                 , a.reference_code
                 , string_agg(a.campaign_name_type, ' + ')    as campaign_name_type
              from ow_lao.tmp_dim_sales_channels_promotions_result_ordering a
          group by a.environment
                 , a.order_id
                 , a.marketplace_order_id
                 , a.reference_code
         );     
      
      
             drop table ow_lao.tmp_dim_sales_channels_promotions_result_validation_tf_d2c_nerp_sales;
    create column table ow_lao.tmp_dim_sales_channels_promotions_result_validation_tf_d2c_nerp_sales
        as (  
                select a.*
                     , b.environment              promo_environment
                     , b.order_id                 promo_order_id
                     , b.marketplace_order_id     promo_marketplace_order_id
                     , b.reference_code           promo_reference_code
                     , b.campaign_name_type       promo_campaign_name_type
                  from OW_LAO.TF_D2C_NERP_SALES                                   a
                  join ow_lao.tmp_dim_sales_channels_promotions_result_validation b on b.order_id       = a.order_id
                                                                                   and b.reference_code = a.sku
                 where lower(a.status_po) not like '%cancel%'                                                                            
              order by a.po_creation_date desc
         );
         
    end