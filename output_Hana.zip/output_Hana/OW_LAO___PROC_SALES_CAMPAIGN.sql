CREATE PROCEDURE OW_LAO.PROC_SALES_CAMPAIGN(
	IN CONSULTA NVARCHAR(40),
	IN CAMPAIGN_TAG NVARCHAR(400)
) LANGUAGE SQLSCRIPT AS
BEGIN	
	/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
	IF :CONSULTA = 'EXEC_TMP_SALES_CAMPAIGN' THEN
	BEGIN
		/*-------------------------------------------------------------------------------------------------*/	
		-- Apaga da tabela de campanhas dados que não existem mais na control tower 		
		DELETE FROM 
			OW_LAO.TMP_SALES_CAMPAIGN 	A
		WHERE
			CAMPAIGN_TAG = :CAMPAIGN_TAG
			AND NOT EXISTS (
				SELECT 
					1
				FROM 
					OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE B
				WHERE 
					A.ID = B.ID
			);		
		
		/*-------------------------------------------------------------------------------------------------*/	
		-- Processo abaixo realiza a inserção dos dados do período atual e anterior da campanha sinalizado o campo PREVIOUS_YEAR = TRUE	no caso de ser o período anterior	
		-- Modificação da tabela dimensão aplicando a regra de retroagir -364 para anos bissexto e 365 para os outros anos	
		DELETE FROM OW_LAO.TMP_CAMPAIGN_NAME_PREVIOUS_YEAR;
		INSERT INTO OW_LAO.TMP_CAMPAIGN_NAME_PREVIOUS_YEAR (CAMPAIGN_TAG, SUBSIDIARY, DIVISION, BIZ_TYPE, PO_DEVICETYPE, INITIAL_DATE, FINAL_DATE, PRODUCT, PRODUCT_GROUP, PRODUCT_FAMILY, PO_SKU, ID_CAMPAIGN, AUDIENCE_TYPE, CAMPAIGN_DAY, PREVIOUS_YEAR)
		SELECT 
			*
		FROM(
			SELECT 
				CAMPAIGN_TAG, SUBSIDIARY, DIVISION, BIZ_TYPE, PO_DEVICETYPE, 
				INITIAL_DATE_LY AS INITIAL_DATE , 
				ADD_DAYS(INITIAL_DATE_LY,DAYS_BETWEEN (INITIAL_DATE, CASE WHEN CURRENT_DATE >= FINAL_DATE THEN FINAL_DATE ELSE CURRENT_DATE END)) AS FINAL_DATE,
				PRODUCT, PRODUCT_GROUP,PRODUCT_FAMILY, PO_SKU, ID_CAMPAIGN, AUDIENCE_TYPE, 
				DAYS_BETWEEN (INITIAL_DATE, CASE WHEN CURRENT_DATE >= FINAL_DATE THEN FINAL_DATE ELSE CURRENT_DATE END) +1 AS CAMPAIGN_DAY,
				TRUE AS "PREVIOUS_YEAR"	
			FROM 
				OW_LAO.DIM_CAMPAIGN_NAME 
			UNION ALL
			SELECT 
				CAMPAIGN_TAG, SUBSIDIARY, DIVISION, BIZ_TYPE, PO_DEVICETYPE, INITIAL_DATE, FINAL_DATE, PRODUCT, PRODUCT_GROUP,PRODUCT_FAMILY, PO_SKU, ID_CAMPAIGN, AUDIENCE_TYPE, 
				DAYS_BETWEEN (INITIAL_DATE, FINAL_DATE) + 1 AS CAMPAIGN_DAY,
				FALSE AS "PREVIOUS_YEAR"
			FROM 
				OW_LAO.DIM_CAMPAIGN_NAME 
		) AS A
		WHERE
			CAMPAIGN_TAG = :CAMPAIGN_TAG;
		/*-------------------------------------------------------------------------------------------------*/	
		--Realiza a busca das vendas de acordo com as regras das campanhas retornando apenas novas vendas ou atualizações 			
		CREATE LOCAL TEMPORARY TABLE #TMP_SALES_CAMPAIGN_UPDATE AS (
			SELECT DISTINCT 
				A.ID,
				CASE WHEN  A.SUBSIDIARY LIKE 'SELA%' THEN 'SELA' ELSE A.SUBSIDIARY END  AS SUBSIDIARY,
				A.PO_DATE, 
				A.PODATE_MONTH, 
				A.PODATE_YEAR, 
				A.PO_ORDERID, 
				A.PO_DEVICETYPE, 
				A.PO_SKU, 
				A.DIVISION,
				A.PRODUCT,
				A.PRODUCT_GROUP, 
				A.PRODUCT_FAMILY, 
				A.PO_STORENAME, 
				A.BIZ_TYPE, 
				A.AUDIENCE_TYPE, 
				A.EBI_NETREVENUE, 
				A.PO_TOTALPRICE_USD, 
				A.NET_REVENUE, 
				A.PO_QTY,
				DAYS_BETWEEN (B.INITIAL_DATE, A.PO_DATE) + 1 AS CAMPAIGN_DAY,
				B.CAMPAIGN_TAG,
				GREATEST(
					IFNULL(A.UPDATED_DATETIME,						INSETED_DATETIME),									
					IFNULL(A.PO_LASTUPDATE_DATE_HOUR,				INSETED_DATETIME),				
					IFNULL(A.PO_SOURCE_LAST_UPDATE_DATE,			INSETED_DATETIME)
				) AS DT_UPDATE,			
				B.ID_CAMPAIGN,
				A.PO_STATUS,
				A.PRODUCT_CATEGORY,
				B.PREVIOUS_YEAR,
             	ROW_NUMBER() OVER(
             		PARTITION BY 
						ID,
						CAMPAIGN_TAG
                   	ORDER BY 
                   		ID 
                ) AS DEDUP				
			FROM 
				OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE 		A
			JOIN 
				OW_LAO.TMP_CAMPAIGN_NAME_PREVIOUS_YEAR 		B
			ON 
				TO_NVARCHAR(A.PO_DATE,'YYYY-MM-DD') BETWEEN TO_NVARCHAR(B.INITIAL_DATE,'YYYY-MM-DD') AND TO_NVARCHAR(B.FINAL_DATE,'YYYY-MM-DD') 
				AND (B.SUBSIDIARY 		IS NULL OR CASE WHEN  A.SUBSIDIARY LIKE 'SELA%' THEN 'SELA' ELSE A.SUBSIDIARY END 	= B.SUBSIDIARY)
				AND (B.DIVISION 		IS NULL OR A.DIVISION  		= B.DIVISION)
				AND (B.BIZ_TYPE 		IS NULL OR A.BIZ_TYPE 		= B.BIZ_TYPE)
				AND (B.PO_DEVICETYPE 	IS NULL OR A.PO_DEVICETYPE 	= B.PO_DEVICETYPE)
				AND (B.PRODUCT 			IS NULL OR A.PRODUCT 		= B.PRODUCT)
				AND (B.PRODUCT_GROUP 	IS NULL OR A.PRODUCT_GROUP 	= B.PRODUCT_GROUP)
				AND (B.PRODUCT_FAMILY 	IS NULL OR A.PRODUCT_FAMILY = B.PRODUCT_FAMILY)				
				AND (B.PO_SKU 			IS NULL OR A.PO_SKU 		= B.PO_SKU)	
				AND (B.AUDIENCE_TYPE 	IS NULL OR A.AUDIENCE_TYPE 	= B.AUDIENCE_TYPE)	
			WHERE
				B.CAMPAIGN_DAY >= 1
				AND NOT EXISTS(
					SELECT 
						1
					FROM
						OW_LAO.TMP_SALES_CAMPAIGN C
					WHERE 
						(A.ID = C.ID AND B.ID_CAMPAIGN = C.ID_CAMPAIGN) 
						AND GREATEST(
								IFNULL(A.UPDATED_DATETIME,						INSETED_DATETIME),									
								IFNULL(A.PO_LASTUPDATE_DATE_HOUR,				INSETED_DATETIME),				
								IFNULL(A.PO_SOURCE_LAST_UPDATE_DATE,			INSETED_DATETIME)
							)  = C.DT_UPDATE
				) 				
		);
		
		/*-------------------------------------------------------------------------------------------------*/	
		--Deleta os PO_SKU que não estão cadastrados na DIM_CAMPAIGN_NAME_PO_SKU_REGISTRATION  		
		DELETE FROM 
			#TMP_SALES_CAMPAIGN_UPDATE 								A
		WHERE
			A.CAMPAIGN_TAG = :CAMPAIGN_TAG
			AND EXISTS (
			    SELECT 
			    	1
			    FROM 
			    	OW_LAO.DIM_CAMPAIGN_NAME_PO_SKU_REGISTRATION 	B1
			    WHERE 
			    	A.ID_CAMPAIGN = B1.ID_CAMPAIGN
			)
			AND NOT EXISTS (
			    SELECT 
			    	1
			    FROM 
			    	OW_LAO.DIM_CAMPAIGN_NAME_PO_SKU_REGISTRATION 	B2
			    WHERE 
			    	A.ID_CAMPAIGN 	= B2.ID_CAMPAIGN
			      	AND A.PO_SKU 	= B2.PO_SKU
			);				
		
		/*-------------------------------------------------------------------------------------------------*/	
		--Realiza o insert das novas vendas ou atualizações de status para a tabela TMP 			
		MERGE INTO 
			OW_LAO.TMP_SALES_CAMPAIGN 			A
		USING
			#TMP_SALES_CAMPAIGN_UPDATE			B 
		ON 
			A.ID = B.ID AND A.ID_CAMPAIGN = B.ID_CAMPAIGN  
		WHEN MATCHED THEN UPDATE SET 
			A.ID 					= B.ID,
			A.SUBSIDIARY 			= B.SUBSIDIARY,
			A.PO_DATE 				= B.PO_DATE,
			A.PODATE_MONTH 			= B.PODATE_MONTH,
			A.PODATE_YEAR 			= B.PODATE_YEAR,
			A.PO_ORDERID 			= B.PO_ORDERID,
			A.PO_DEVICETYPE 		= B.PO_DEVICETYPE,
			A.PO_SKU 				= B.PO_SKU,
			A.DIVISION 				= B.DIVISION,
			A.PRODUCT 				= B.PRODUCT,
			A.PRODUCT_GROUP 		= B.PRODUCT_GROUP,
			A.PRODUCT_FAMILY 		= B.PRODUCT_FAMILY,
			A.PO_STORENAME 			= B.PO_STORENAME,
			A.BIZ_TYPE 				= B.BIZ_TYPE,
			A.AUDIENCE_TYPE 		= B.AUDIENCE_TYPE,
			A.EBI_NETREVENUE 		= B.EBI_NETREVENUE,
			A.PO_TOTALPRICE_USD 	= B.PO_TOTALPRICE_USD,
			A.NET_REVENUE 			= B.NET_REVENUE,
			A.PO_QTY 				= B.PO_QTY,
			A.CAMPAIGN_DAY			= B.CAMPAIGN_DAY,
			A.CAMPAIGN_TAG 			= B.CAMPAIGN_TAG,
			A.DT_UPDATE 			= B.DT_UPDATE,
			A.ID_CAMPAIGN 			= B.ID_CAMPAIGN,
			A.PO_STATUS 			= B.PO_STATUS,
			A.PRODUCT_CATEGORY 		= B.PRODUCT_CATEGORY,
			A.PREVIOUS_YEAR 		= B.PREVIOUS_YEAR,
			A.DEDUP 				= B.DEDUP
		WHEN NOT MATCHED THEN INSERT(
			ID,
			SUBSIDIARY,
			PO_DATE,
			PODATE_MONTH,
			PODATE_YEAR,
			PO_ORDERID,
			PO_DEVICETYPE,
			PO_SKU,
			DIVISION,
			PRODUCT,
			PRODUCT_GROUP,
			PRODUCT_FAMILY,
			PO_STORENAME,
			BIZ_TYPE,
			AUDIENCE_TYPE,
			EBI_NETREVENUE,
			PO_TOTALPRICE_USD,
			NET_REVENUE,
			PO_QTY,
			CAMPAIGN_DAY,
			CAMPAIGN_TAG,
			DT_UPDATE,
			ID_CAMPAIGN,
			PO_STATUS,
			PRODUCT_CATEGORY,
			PREVIOUS_YEAR,
			DEDUP
		)
		VALUES(
			B.ID,
			B.SUBSIDIARY,
			B.PO_DATE,
			B.PODATE_MONTH,
			B.PODATE_YEAR,
			B.PO_ORDERID,
			B.PO_DEVICETYPE,
			B.PO_SKU,
			B.DIVISION,
			B.PRODUCT,
			B.PRODUCT_GROUP,
			B.PRODUCT_FAMILY,
			B.PO_STORENAME,
			B.BIZ_TYPE,
			B.AUDIENCE_TYPE,
			B.EBI_NETREVENUE,
			B.PO_TOTALPRICE_USD,
			B.NET_REVENUE,
			B.PO_QTY,
			B.CAMPAIGN_DAY,
			B.CAMPAIGN_TAG,
			B.DT_UPDATE,
			B.ID_CAMPAIGN,
			B.PO_STATUS,
			B.PRODUCT_CATEGORY,
			B.PREVIOUS_YEAR,
			B.DEDUP
		);		
	
		/*-------------------------------------------------------------------------------------------------*/	
		--Drop tabela temporaria   		
		DROP TABLE #TMP_SALES_CAMPAIGN_UPDATE;		
		
	END;
	/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/	
	ELSEIF :CONSULTA = 'EXEC_ODS_SALES_CAMPAIGN' THEN
	BEGIN
		/*-------------------------------------------------------------------------------------------------*/	
		--Deleta dados de campanhas alteradas ou apagadas 			
		DELETE FROM 
			OW_LAO.ODS_SALES_CAMPAIGN 			A
		WHERE 
			NOT EXISTS (
				SELECT 
					1
				FROM 
					OW_LAO.TMP_SALES_CAMPAIGN 	B
				WHERE 
					A.ID 				= B.ID
					AND A.ID_CAMPAIGN 	= B.ID_CAMPAIGN
					AND A.DT_UPDATE 	= B.DT_UPDATE
			);		
		/*-------------------------------------------------------------------------------------------------*/	
		--Retorna apenas as atualizações que foram inseridas na tabela temporaria 			
		CREATE LOCAL TEMPORARY TABLE #ODS_SALES_CAMPAIGN_UPDATE AS (	
			SELECT DISTINCT 
				A.ID,
				A.SUBSIDIARY,
				A.PO_DATE,
				A.PODATE_MONTH,
				A.PODATE_YEAR,
				A.PO_ORDERID,
				A.PO_DEVICETYPE,
				A.PO_SKU,
				A.DIVISION,
				A.PRODUCT,
				A.PRODUCT_GROUP,
				A.PRODUCT_FAMILY,
				A.PO_STORENAME,
				CASE 
					WHEN A.PO_DEVICETYPE = 'MOBILEAPP' THEN 'APP' 
					ELSE A.BIZ_TYPE 
				END AS BIZ_TYPE,
				A.AUDIENCE_TYPE,
				A.EBI_NETREVENUE,
				A.PO_TOTALPRICE_USD,
				A.NET_REVENUE,
				A.PO_QTY,
				A.CAMPAIGN_DAY,
				A.CAMPAIGN_TAG,
				A.DT_UPDATE,
				A.PO_STATUS,
				A.PRODUCT_CATEGORY,
				A.PREVIOUS_YEAR,
				A.ID_CAMPAIGN 
			FROM 
				OW_LAO.TMP_SALES_CAMPAIGN 			A
			WHERE 
				DEDUP = 1  
				AND NOT EXISTS (
					SELECT 
						1
					FROM 
						OW_LAO.ODS_SALES_CAMPAIGN 	B
					WHERE 
						A.ID 				= B.ID
						AND A.ID_CAMPAIGN 	= B.ID_CAMPAIGN
						AND A.DT_UPDATE 	= B.DT_UPDATE
				)
		);
	
		/*-------------------------------------------------------------------------------------------------*/	
		--Realiza o merge para a tabela final 		
		MERGE INTO 
			OW_LAO.ODS_SALES_CAMPAIGN 	A
		USING
			#ODS_SALES_CAMPAIGN_UPDATE			B 
		ON 
			A.ID = B.ID AND A.ID_CAMPAIGN = B.ID_CAMPAIGN  
		WHEN MATCHED THEN UPDATE SET 
			A.ID 					= B.ID,
			A.SUBSIDIARY 			= B.SUBSIDIARY,
			A.PO_DATE 				= B.PO_DATE,
			A.PODATE_MONTH 			= B.PODATE_MONTH,
			A.PODATE_YEAR 			= B.PODATE_YEAR,
			A.PO_ORDERID 			= B.PO_ORDERID,
			A.PO_DEVICETYPE 		= B.PO_DEVICETYPE,
			A.PO_SKU 				= B.PO_SKU,
			A.DIVISION 				= B.DIVISION,
			A.PRODUCT 				= B.PRODUCT,
			A.PRODUCT_GROUP 		= B.PRODUCT_GROUP,
			A.PRODUCT_FAMILY 		= B.PRODUCT_FAMILY,
			A.PO_STORENAME 			= B.PO_STORENAME,
			A.BIZ_TYPE 				= B.BIZ_TYPE,
			A.AUDIENCE_TYPE 		= B.AUDIENCE_TYPE,
			A.EBI_NETREVENUE 		= B.EBI_NETREVENUE,
			A.PO_TOTALPRICE_USD 	= B.PO_TOTALPRICE_USD,
			A.NET_REVENUE 			= B.NET_REVENUE,
			A.PO_QTY 				= B.PO_QTY,
			A.CAMPAIGN_DAY			= B.CAMPAIGN_DAY,
			A.CAMPAIGN_TAG 			= B.CAMPAIGN_TAG,
			A.DT_UPDATE 			= B.DT_UPDATE,
			A.PO_STATUS 			= B.PO_STATUS,
			A.PRODUCT_CATEGORY 		= B.PRODUCT_CATEGORY,
			A.PREVIOUS_YEAR 		= B.PREVIOUS_YEAR,
			A.ID_CAMPAIGN 			= B.ID_CAMPAIGN 
		WHEN NOT MATCHED THEN INSERT(
			ID,
			SUBSIDIARY,
			PO_DATE,
			PODATE_MONTH,
			PODATE_YEAR,
			PO_ORDERID,
			PO_DEVICETYPE,
			PO_SKU,
			DIVISION,
			PRODUCT,
			PRODUCT_GROUP,
			PRODUCT_FAMILY,
			PO_STORENAME,
			BIZ_TYPE,
			AUDIENCE_TYPE,
			EBI_NETREVENUE,
			PO_TOTALPRICE_USD,
			NET_REVENUE,
			PO_QTY,
			CAMPAIGN_DAY,
			CAMPAIGN_TAG,
			DT_UPDATE,
			PO_STATUS,
			PRODUCT_CATEGORY,
			PREVIOUS_YEAR,
			ID_CAMPAIGN 
		)
		VALUES(
			B.ID,
			B.SUBSIDIARY,
			B.PO_DATE,
			B.PODATE_MONTH,
			B.PODATE_YEAR,
			B.PO_ORDERID,
			B.PO_DEVICETYPE,
			B.PO_SKU,
			B.DIVISION,
			B.PRODUCT,
			B.PRODUCT_GROUP,
			B.PRODUCT_FAMILY,
			B.PO_STORENAME,
			B.BIZ_TYPE,
			B.AUDIENCE_TYPE,
			B.EBI_NETREVENUE,
			B.PO_TOTALPRICE_USD,
			B.NET_REVENUE,
			B.PO_QTY,
			B.CAMPAIGN_DAY,
			B.CAMPAIGN_TAG,
			B.DT_UPDATE,
			B.PO_STATUS,
			B.PRODUCT_CATEGORY,
			B.PREVIOUS_YEAR,
			B.ID_CAMPAIGN 
		);		
		
		DROP TABLE #ODS_SALES_CAMPAIGN_UPDATE;
		/*-------------------------------------------------------------------------------------------------*/				
		--Pedido da Sthe 18/06		
		DELETE 
		FROM
			OW_LAO.ODS_SALES_CAMPAIGN
		WHERE 
			CAMPAIGN_TAG 		= 'Success Sprint'
			AND SUBSIDIARY 		= 'SAMCOL'
			AND PODATE_YEAR  	= '2024';
	END;
	/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
	ELSE
	BEGIN
		SELECT 'Procedimento não declaro' AS CONSULTA FROM DUMMY;
	END;
	END IF;
END;