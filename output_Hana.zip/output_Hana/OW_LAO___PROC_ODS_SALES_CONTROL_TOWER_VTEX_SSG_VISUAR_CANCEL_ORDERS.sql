create procedure ow_lao.proc_ods_sales_control_tower_vtex_ssg_visuar_cancel_orders
    as
     begin  
  
         drop table #stg_vtex_order_seasa_visuar_cancel_filter;
       create local temporary table #stg_vtex_order_seasa_visuar_cancel_filter
          as (
      
                   select a.id
                        , a.po_orderid
                        , a.po_sku
                        , a.po_status
				     from ow_lao.ods_sales_control_tower_table          a
				     join u_prj_ecom.stg_vtex_order_seasa_visuar_cancel b on b.order_id = a.seller_po_orderid
				                                                         and b.sku      = a.po_sku
                    where a.po_status != 'Cancelled'
                      and lower(a.po_seller_id) like '%visuar%'
                      and a.client_subsidiary_id    = 1
                      and a.po_plataform_datasource in ('u_prj_ecom.raw_vtex_ssg_ar_sales_order', 'u_prj_ecom.ft_ecom_order')
		  );
		  
		  
     
            insert into #stg_vtex_order_seasa_visuar_cancel_filter
            select distinct
                   a.id
                 , a.po_orderid
                 , a.po_sku
                 , a.po_status
              from ow_lao.ods_sales_control_tower_table          a
              join u_prj_ecom.stg_vtex_order_seasa_visuar_cancel b on b.order_id = a.seller_po_orderid
             where a.po_status               != 'Cancelled'
               and lower(a.po_seller_id)     like '%visuar%'
               and a.client_subsidiary_id    = 1
               and a.po_plataform_datasource in ('u_prj_ecom.raw_vtex_ssg_ar_sales_order', 'u_prj_ecom.ft_ecom_order')
               and not exists(
                        select 1
                          from #stg_vtex_order_seasa_visuar_cancel_filter aa
                         where aa.po_orderid = a.po_orderid
                   )
               and exists (
              
                        select po_orderid
                          from ow_lao.ods_sales_control_tower_table bb
                         where bb.po_orderid = a.po_orderid
                      group by po_orderid
                        having count(1) = 1
                          
                   );     
                   
                   
            update ow_lao.ods_sales_control_tower_table       a
               set po_status        = 'Cancelled'
                 , updated_datetime = current_timestamp
              from ow_lao.ods_sales_control_tower_table       a
              join #stg_vtex_order_seasa_visuar_cancel_filter b on b.id = a.id;
               
        end