CREATE PROCEDURE OW_LAO.PROC_ODS_SALES_CONTROL_TOWER_TABLE_PARTNER_LEVEL
 LANGUAGE SQLSCRIPT AS
 BEGIN
    DROP TABLE OW_LAO.TMP_ACCESS_CODE_PARTNER_LEVEL_VTEX ;  
    DROP TABLE OW_LAO.TMP_ACCESS_CODE_PARTNER_LEVEL_VTEX_SELA ; 
    DROP TABLE OW_LAO.TMP_ACCESS_CODE_PARTNER_LEVEL_HYBRIS ; 
    DROP TABLE OW_LAO.TMP_ACCESS_CODE_PARTNER_LEVEL_HYBRIS_NUMBER ;  
    DROP TABLE OW_LAO.TMP_PARTNER_LEVEL_SMB_SEASA;  
    DROP TABLE OW_LAO.TMP_ACCESS_CODE_PARTNER_LEVEL_SMB;  
    DROP TABLE OW_LAO.TMP_ACCESS_CODE_PARTNER_LEVEL_SMB_TEL;  
    DROP TABLE OW_LAO.TMP_DIM_ECOM_PARTNER_LEVEL_INSERT;  
    DROP TABLE OW_LAO.TMP_DIM_ECOM_PARTNER_LEVEL;
    
 create column table OW_LAO.TMP_ACCESS_CODE_PARTNER_LEVEL_VTEX
        as (         
        
            SELECT  DISTINCT 
            
           BIZ_TYPE,
           PO_STORENAME,
           PO_STORENAME AS PARTNER_LEVEL,
           SUBSIDIARY
           FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE
           WHERE 
           BIZ_TYPE = 'EPP'
           AND SUBSIDIARY IN   ('SEDA','SEASA','SEASA-PY')
           AND  CAST (po_date AS DATE ) between cast(add_days(now(), -180) as date) 
                                   and cast(add_days(now(),  -0) as date)
        );                                       
                                                 
 
    
    update OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A
       set A.PARTNER_LEVEL        = B.PARTNER_LEVEL
          
      from OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE   A
      join OW_LAO.TMP_ACCESS_CODE_PARTNER_LEVEL_VTEX  B
      on  B.BIZ_TYPE      = A.BIZ_TYPE
      AND B.PO_STORENAME  = A.PO_STORENAME
      AND B.SUBSIDIARY    = A.SUBSIDIARY 
      
      ;
     
     
     
 create column table OW_LAO.TMP_ACCESS_CODE_PARTNER_LEVEL_VTEX_SELA
        as (         
        
            SELECT  DISTINCT 
            
           BIZ_TYPE,
           PO_STORENAME,
           PO_STORENAME AS PARTNER_LEVEL,
           SUBSIDIARY
           FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE
           WHERE 
           BIZ_TYPE = 'EPP'
           AND SUBSIDIARY  LIKE  'SELA%'
           AND CAST (po_date AS DATE ) between cast(add_days(now(), -180) as date) 
                                     and cast(add_days(now(),  -0) as date)
        );                                       
                   
    update OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A
       set A.PARTNER_LEVEL        = B.PARTNER_LEVEL
          
      from OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE   A
      join OW_LAO.TMP_ACCESS_CODE_PARTNER_LEVEL_VTEX_SELA  B
      on  B.BIZ_TYPE      = A.BIZ_TYPE
      AND B.PO_STORENAME  = A.PO_STORENAME
      AND B.SUBSIDIARY    = A.SUBSIDIARY 
      
      ;
      
         create column table OW_LAO.TMP_ACCESS_CODE_PARTNER_LEVEL_HYBRIS
        as (         
        
         SELECT DISTINCT 
 A.PO_ORDERID,
 A.SUBSIDIARY,
 A.ACCESS_CODE, 
 A.PO_PLATAFORM_DATASOURCE,
-- B.COMPANY_NAME,
 CASE 
     WHEN B.COMPANY_NAME IS NULL THEN  A.ACCESS_CODE 
     ELSE B.COMPANY_NAME 
     END AS PARTNER_LEVEL
  
FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A 
LEFT JOIN  "OW_LAO"."DIM_ACCESS_CODE"  B ON A.SUBSIDIARY = B.SUB AND A.ACCESS_CODE = B.ACCESS_CODE
WHERE A.ACCESS_CODE IS NOT NULL 
AND A.SUBSIDIARY IN ('SAMCOL','SECH','SEM','SEPR')
AND BIZ_TYPE = 'EPP'
AND CAST (a.po_date AS DATE ) between cast(add_days(now(), -180) as date) 
                                    and cast(add_days(now(),  -0) as date)
 
        );    
       
       update OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A
       set A.PARTNER_LEVEL      = B.PARTNER_LEVEL
          
      from OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE   A
      join OW_LAO.TMP_ACCESS_CODE_PARTNER_LEVEL_HYBRIS  B
      on  B.PO_ORDERID      = A.PO_ORDERID 
      AND B.SUBSIDIARY      = A.SUBSIDIARY
       
      ;
       
 
       create column table OW_LAO.TMP_ACCESS_CODE_PARTNER_LEVEL_HYBRIS_NUMBER
        as (         
        
         SELECT DISTINCT 
 PO_ORDERID,
ACCESS_CODE,  
SUBSIDIARY,
LEFT (ACCESS_CODE, 1), 
'' AS "ACCESS_CODE_AT"
 
FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE
WHERE ACCESS_CODE IS NOT NULL 
AND LEFT (ACCESS_CODE, 1) IN ('0','1','2','3','4','5','6','7','8','9')
AND BIZ_TYPE = 'EPP'
AND CAST (po_date AS DATE ) between cast(add_days(now(), -180) as date) 
                                   and cast(add_days(now(),  -0) as date)
        );    
       
                      
    update OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A
       set A.PARTNER_LEVEL        = B.ACCESS_CODE_AT
          
      from OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE   A
      join OW_LAO.TMP_ACCESS_CODE_PARTNER_LEVEL_HYBRIS_NUMBER B
      on   B.PO_ORDERID      = A.PO_ORDERID
      AND  B.SUBSIDIARY      = A.SUBSIDIARY
       
      ;
     
         
           CREATE COLUMN TABLE OW_LAO.TMP_PARTNER_LEVEL_SMB_SEASA  AS (
    
     SELECT DISTINCT 
    A.PO_ORDERID ,
    A.SUBSIDIARY ,
    A.BIZ_TYPE ,
    C.CODIGOPARCERIA  AS PARTNER_LEVEL,
    A.PO_PLATAFORM_DATASOURCE ,
    A.PO_SITECODE ,
    A.CLIENT_SUBSIDIARY_ID ,
    C.USERID,
    A.PO_COSTUMER_ID 
    
    FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A
    JOIN "U_PRJ_ECOM"."RAW_VTEX_SEASA_MASTER_DATA_CL"  B  ON B.ORDER_ID       = A.PO_ORDERID
    JOIN "U_PRJ_ECOM"."ODS_VTEX_MASTER_DATA_CL" C         ON C.USERID         = B.USERID
                                                         AND C.SUBSIDIARY_ID  = A.CLIENT_SUBSIDIARY_ID  
                                                         AND C.HOSTNAME       = A.PO_SITECODE 
                                                         AND C.CODIGOPARCERIA IS NOT NULL
 
                                                                                                                 
    WHERE  A.BIZ_TYPE = 'SMB'
    AND   A.CLIENT_SUBSIDIARY_ID  = 1
    AND   A.PARTNER_LEVEL IS NULL 
                                     );
    
    update OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A
       set A.PARTNER_LEVEL        = B.PARTNER_LEVEL 
          
      from OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE   A
      join OW_LAO.TMP_PARTNER_LEVEL_SMB_SEASA B
      on   B.PO_ORDERID                = A.PO_ORDERID
      AND  B.PO_PLATAFORM_DATASOURCE   = A.PO_PLATAFORM_DATASOURCE
      AND  B.BIZ_TYPE                  = A.BIZ_TYPE
      AND  B.CLIENT_SUBSIDIARY_ID      = A.CLIENT_SUBSIDIARY_ID
      AND  B.PO_SITECODE               = A.PO_SITECODE 
      
      WHERE A.PARTNER_LEVEL IS NULL 
      ;
      
       ---**PROCESSO DE INSERÇÃO DIM PARTNER LEVEL TABELA OW_LAO.ODS_NERP_ZLLEJ50090_OUTBOUND_TRACKING **
 --Coleta os casos de partner level não localizados porém possui o mesmo tel 
 CREATE COLUMN TABLE OW_LAO.TMP_DIM_ECOM_PARTNER_LEVEL_INSERT AS (
   SELECT * FROM (
    SELECT DISTINCT 
    a.SUBSIDIARY ,
    a.BIZ_TYPE ,
    b.SHIPTO_TEL ,
    b.BILLTO_NAME   ,
    c.BILLTO_NAME AS dim   ,
    c.PARTNER_LEVEL,
    LEFT (c.SHIPTO_TEL,11),
    ROW_NUMBER() OVER (PARTITION BY RIGHT  (b.SHIPTO_TEL, 11) ORDER BY UPPER (LEFT  (b.BILLTO_NAME,6)) DESC) AS NL
    FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE a
    
    JOIN OW_LAO.ODS_NERP_ZLLEJ50090_OUTBOUND_TRACKING  b ON  b.delivery_no             = a.nerp_deliverycode
    LEFT  JOIN OW_LAO.DIM_ECOM_PARTNER_LEVEL           c ON  RIGHT  (b.SHIPTO_TEL,11)  = RIGHT  (c.SHIPTO_TEL,11)
                                                        AND  a.SUBSIDIARY              = c.SUBSIDIARY 
                                                        AND  a.BIZ_TYPE                = c.BIZ_TYPE 
                                                                                                                 
    WHERE a.CLIENT_SUBSIDIARY_ID IN ('1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19')
    AND   a.BIZ_TYPE = 'SMB'   
    AND   c.BILLTO_NAME IS NOT NULL 
    AND   b.BILLTO_NAME   IS NOT    NULL
    AND   not exists(
                select 1
                  from OW_LAO.DIM_ECOM_PARTNER_LEVEL   bb
                 WHERE REPLACE(upper( bb.BILLTO_NAME),'.','')  = REPLACE (upper(b.BILLTO_NAME),'.','') 
                   AND bb.SUBSIDIARY                           = a.SUBSIDIARY 
                   AND bb.BIZ_TYPE                             = a.BIZ_TYPE 
           )
           ) WHERE NL = 1
           )
           ;
 
          
 --Insere os casos de partner level não localizados porém possui o mesmo tel na dim  
          
          INSERT INTO  OW_LAO.DIM_ECOM_PARTNER_LEVEL  (
          SELECT DISTINCT
          A.SUBSIDIARY,
          A. BIZ_TYPE,
          A.SHIPTO_TEL,
          A.BILLTO_NAME,
          A.PARTNER_LEVEL
        FROM OW_LAO.TMP_DIM_ECOM_PARTNER_LEVEL_INSERT A
        WHERE  not exists(
                select 1
                  from OW_LAO.DIM_ECOM_PARTNER_LEVEL   bb
                 WHERE REPLACE(upper( bb.BILLTO_NAME),'.','')  = REPLACE (upper(A.BILLTO_NAME),'.','') 
                   AND bb.SUBSIDIARY                           = A.SUBSIDIARY 
                   AND bb.BIZ_TYPE                             = A.BIZ_TYPE 
           )
           )
           ;
          
 --Coleta os casos de partner level não localizados 
       
CREATE COLUMN TABLE OW_LAO.TMP_DIM_ECOM_PARTNER_LEVEL AS (
 
     SELECT DISTINCT 
    a.SUBSIDIARY ,
    a.BIZ_TYPE ,
    b.SHIPTO_TEL ,
    b.BILLTO_NAME   ,
    c.PARTNER_LEVEL,
    LEFT (c.SHIPTO_TEL,11)
    FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE a
    
    JOIN OW_LAO.ODS_NERP_ZLLEJ50090_OUTBOUND_TRACKING  b ON  b.delivery_no = a.nerp_deliverycode
 LEFT   JOIN OW_LAO.DIM_ECOM_PARTNER_LEVEL             c ON  REPLACE (upper (b.BILLTO_NAME),'.','')  = REPLACE( upper (c.BILLTO_NAME),'.','') 
                                                        AND  a.SUBSIDIARY                            = c.SUBSIDIARY 
                                                        AND  a.BIZ_TYPE                              = c.BIZ_TYPE 
                                                                                                                 
    WHERE a.CLIENT_SUBSIDIARY_ID IN ('1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19')
    AND a.BIZ_TYPE = 'SMB'
    AND c.PARTNER_LEVEL IS NULL 
    AND b.BILLTO_NAME   IS NOT  NULL 
              
       and not exists(
                select 1
                  from OW_LAO.DIM_ECOM_PARTNER_LEVEL   aa
                 where RIGHT  (aa.SHIPTO_TEL,11)  = RIGHT  (c.SHIPTO_TEL,11)
                   AND aa.SUBSIDIARY              = c.SUBSIDIARY 
                   AND aa.BIZ_TYPE                = c.BIZ_TYPE 
           )
           
           
            and not exists(
                select 1
                  from OW_LAO.DIM_ECOM_PARTNER_LEVEL   bb
                 WHERE REPLACE (upper( bb.BILLTO_NAME),'.','')  = REPLACE (upper(c.BILLTO_NAME),'.','') 
                   AND bb.SUBSIDIARY                            = c.SUBSIDIARY 
                   AND bb.BIZ_TYPE                              = c.BIZ_TYPE 
           )
           )
           
           ;
 
 --Insere os casos de partner level não localizados   
     
            INSERT INTO  OW_LAO.DIM_ECOM_PARTNER_LEVEL  (
          SELECT DISTINCT
          A.SUBSIDIARY,
          A. BIZ_TYPE,
          A.SHIPTO_TEL,
          A.BILLTO_NAME,
          UPPER  (A.BILLTO_NAME)  AS PARTNER_LEVEL
        FROM OW_LAO.TMP_DIM_ECOM_PARTNER_LEVEL A
        WHERE    not exists(
                select 1
                  from OW_LAO.DIM_ECOM_PARTNER_LEVEL   aa
                 where RIGHT  (aa.SHIPTO_TEL,11)  = RIGHT  (A.SHIPTO_TEL,11)
                   AND aa.SUBSIDIARY              = A.SUBSIDIARY 
                   AND aa.BIZ_TYPE                = A.BIZ_TYPE 
           )
           
           
            and not exists(
                select 1
                  from OW_LAO.DIM_ECOM_PARTNER_LEVEL   bb
                 WHERE REPLACE (upper( bb.BILLTO_NAME),'.','')  = REPLACE (upper(A.BILLTO_NAME),'.','') 
                   AND bb.SUBSIDIARY                            = A.SUBSIDIARY 
                   AND bb.BIZ_TYPE                              = A.BIZ_TYPE 
           )
           )
           ;
          
  ---**PROCESSO DE INSERÇÃO DIM PARTNER LEVEL TABELA OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE **
             CREATE COLUMN TABLE OW_LAO.TMP_ACCESS_CODE_PARTNER_LEVEL_SMB_TEL  AS (
     SELECT DISTINCT 
    a.PO_ORDERID ,
    a.nerp_deliverycode,
    b.delivery_no ,
    a.SUBSIDIARY ,
    a.BIZ_TYPE ,
    b.BILLTO_NAME  ,
    c.PARTNER_LEVEL,
    a.PO_PLATAFORM_DATASOURCE ,
    b.SHIPTO_TEL AS PARTNER_LEVEL_CODE
    
    FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE a
    
    JOIN OW_LAO.ODS_NERP_ZLLEJ50090_OUTBOUND_TRACKING  b ON  b.delivery_no            = a.nerp_deliverycode
    JOIN OW_LAO.DIM_ECOM_PARTNER_LEVEL                 c ON  RIGHT (b.SHIPTO_TEL,11 ) = RIGHT (C.SHIPTO_TEL,11 )
                                                        AND  a.SUBSIDIARY             = c.SUBSIDIARY 
                                                        AND  a.BIZ_TYPE               = c.BIZ_TYPE 
                                                                                                                 
    WHERE a.CLIENT_SUBSIDIARY_ID IN ('1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19')
    AND a.BIZ_TYPE = 'SMB'
    AND CAST (a.po_date AS DATE ) between cast(add_days(now(), -180) as date) 
                                      and cast(add_days(now(),  -0) as date)
                                      
    );
                                      
                                      
   
      update OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A
       set A.PARTNER_LEVEL        = B.PARTNER_LEVEL
          ,A.PARTNER_LEVEL_CODE   = B.PARTNER_LEVEL_CODE
          
      from OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE   A
      join OW_LAO.TMP_ACCESS_CODE_PARTNER_LEVEL_SMB_TEL B
      on   B.PO_ORDERID                = A.PO_ORDERID
      AND  B.PO_PLATAFORM_DATASOURCE   = A.PO_PLATAFORM_DATASOURCE
      AND  B.BIZ_TYPE                  = A.BIZ_TYPE
      ;
      
        CREATE COLUMN TABLE OW_LAO.TMP_ACCESS_CODE_PARTNER_LEVEL_SMB  AS (
     SELECT DISTINCT 
    a.PO_ORDERID ,
    a.nerp_deliverycode,
    b.delivery_no ,
    a.SUBSIDIARY ,
    a.BIZ_TYPE ,
    b.BILLTO_NAME  ,
    c.PARTNER_LEVEL,
    a.PO_PLATAFORM_DATASOURCE ,
    b.SHIPTO_TEL AS PARTNER_LEVEL_CODE
    
    FROM OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE a
    
    JOIN OW_LAO.ODS_NERP_ZLLEJ50090_OUTBOUND_TRACKING  b ON  b.delivery_no                          = a.nerp_deliverycode
    JOIN OW_LAO.DIM_ECOM_PARTNER_LEVEL                 c ON  REPLACE(upper( b.BILLTO_NAME),'.','')  = REPLACE(upper( C.BILLTO_NAME),'.','') 
                                                        AND  a.SUBSIDIARY                           = c.SUBSIDIARY 
                                                        AND  a.BIZ_TYPE                             = c.BIZ_TYPE 
                                                                                                                 
    WHERE a.CLIENT_SUBSIDIARY_ID IN ('1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19')
    AND a.BIZ_TYPE = 'SMB'
    AND CAST (a.po_date AS DATE ) between cast(add_days(now(), -180) as date) 
                                      and cast(add_days(now(),  -0) as date)
                                      
    );
                                      
                                      
   
      update OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE A
       set A.PARTNER_LEVEL        = B.PARTNER_LEVEL
          ,A.PARTNER_LEVEL_CODE   = B.PARTNER_LEVEL_CODE
          
      from OW_LAO.ODS_SALES_CONTROL_TOWER_TABLE   A
      join OW_LAO.TMP_ACCESS_CODE_PARTNER_LEVEL_SMB B
      on   B.PO_ORDERID                = A.PO_ORDERID
      AND  B.PO_PLATAFORM_DATASOURCE   = A.PO_PLATAFORM_DATASOURCE
      AND  B.BIZ_TYPE                  = A.BIZ_TYPE
      ;
                
     
     END