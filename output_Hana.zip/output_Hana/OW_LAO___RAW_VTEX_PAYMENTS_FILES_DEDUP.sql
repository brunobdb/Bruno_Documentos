create procedure "OW_LAO"."RAW_VTEX_PAYMENTS_FILES_DEDUP"
 as 
    begin
                --drop table #vtx_payments_files_dedup;
                
                create local temporary table #vtx_payments_files_dedup
                    as (
                            select id
                                 , file_path
                                 , file_name
                                 , row_number()
                                        over(partition by file_path 
                                                 order by id desc
                                        )                               as dedup
                              from "OW_LAO"."RAW_VTEX_PAYMENTS_FILES"
                             where processed = false
                          group by id
                                 , file_path
                                 , file_name
                    );
                    
                    
                  update "OW_LAO"."RAW_VTEX_PAYMENTS_FILES" a
                     set processed = true
                    from "OW_LAO"."RAW_VTEX_PAYMENTS_FILES" a
                    join  #vtx_payments_files_dedup         b on b.id = a.id
                   where b.dedup  != 1
                     and processed = false;
                     
    end