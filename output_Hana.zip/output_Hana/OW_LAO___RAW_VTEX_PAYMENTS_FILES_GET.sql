create procedure OW_LAO.RAW_VTEX_PAYMENTS_FILES_GET
 as 
    begin
            
             select id
		          , FILE_PATH
		          , FILE_NAME
		       from OW_LAO.RAW_VTEX_PAYMENTS_FILES
		      where processed = false      
		        and file_path  like '\\105.202.32.19\SHARED\LAO\LAO\VTEX_PAYMENTS\year=2025\month=01\day=31\hour=14\%';
                     
    end