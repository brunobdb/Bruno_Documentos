CREATE procedure ow_lao.raw_vtex_payments_generate
  as
    begin
        insert into "OW_LAO"."RAW_VTEX_PAYMENTS" (
               "KEY_ID",
               "KEY_TRANSACTION_ID",
               "PAYMENT_ID",
               "SOURCE",
               "STATUS",
               "DATE",
               "MESSAGE",
               "TICKS",
               "BATCH_ID",
               "ACCOUNT",
               "FILE_NAME"
        ) 
             
             
        select distinct
               "KEY_ID",
               "KEY_TRANSACTION_ID",
               "PAYMENT_ID",
               "SOURCE",
               "STATUS",
               "DATE",
               "MESSAGE",
               "TICKS",
               "BATCH_ID",
               "ACCOUNT",
               "FILE_NAME"    
          from ow_lao.STG_VTEX_PAYMENTS a
         where not exists (
                     select 1
                       from "OW_LAO"."RAW_VTEX_PAYMENTS" aa
                      where 1 = 1
                        and aa.key_id = a.key_id
                        --and aa.batch_id  = a.batch_id
                        --and aa.file_name = a.file_name
               )
      order by batch_id
             , file_name ;    
                                 
    end