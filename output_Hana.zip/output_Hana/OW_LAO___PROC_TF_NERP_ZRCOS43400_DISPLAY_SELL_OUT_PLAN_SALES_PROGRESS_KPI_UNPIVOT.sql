CREATE PROCEDURE OW_LAO.PROC_TF_NERP_ZRCOS43400_DISPLAY_SELL_OUT_PLAN_SALES_PROGRESS_KPI_UNPIVOT
 LANGUAGE SQLSCRIPT AS
 BEGIN
	  drop table OW_LAO.TMP_NERP_ZRCOS43400_DISPLAY_SELL_OUT_PLAN_SALES_PROGRESS_KPI;
	  drop table OW_LAO.TF_NERP_ZRCOS43400_DISPLAY_SELL_OUT_PLAN_SALES_PROGRESS_KPI_DEDUP;
	  drop table OW_LAO.TF_NERP_ZRCOS43400_DISPLAY_SELL_OUT_PLAN_SALES_PROGRESS_KPI_FINAL;
	  drop table OW_LAO.TF_NERP_ZRCOS43400_DISPLAY_SELL_OUT_PLAN_SALES_PROGRESS_KPI_UNPIVOT;
	  drop table OW_LAO.TF_NERP_ZRCOS43400_DISPLAY_SELL_OUT_PLAN_SALES_PROGRESS_KPI_UNPIVOT_AGG_DIVISION_GROUP;
	  
	create column table OW_LAO.TMP_NERP_ZRCOS43400_DISPLAY_SELL_OUT_PLAN_SALES_PROGRESS_KPI as
	(
	    select row_number()
	                over(partition by company_code
	                                , material
	                                , TO_VARCHAR(
	                                    TO_DATE(replace(replace(file_name, 'Target_', ''), '.xlsx', ''))
	                                    , 'YYYYMM'
	                                  )
	                        order by cast(replace(replace(file_name, 'Target_', ''), '.xlsx', '') as date) desc
	                )                                                                                               as dedup
	         , cast(replace(replace(file_name, 'Target_', ''), '.xlsx', '') as date)                                as dedup_date_value
	         , month(cast(replace(replace(file_name, 'Target_', ''), '.xlsx', '') as date))                         as dedup_month_value
	         , dense_rank()
	                over(partition by company_code
	                                , material
	                         order by month(cast(replace(replace(file_name, 'Target_', ''), '.xlsx', '') as date)) desc
	                )                                                                                               as dedup_month
	         , 'SEDA'                                                                                               as subsidiary
	         , material
	         , QTY01
	         , QTY02
	         , QTY03
	         , QTY04
	         , QTY05
	         , QTY06
	         , QTY07
	         , QTY08
	         , QTY09
	         , QTY10
	         , QTY11
	         , QTY12 
	         , AMT01
	         , AMT02
	         , AMT03
	         , AMT04
	         , AMT05
	         , AMT06
	         , AMT07
	         , AMT08
	         , AMT09
	         , AMT10
	         , AMT11
	         , AMT12         
	      from "OW_SEDA_S".ODS_NERP_ZRCOS43400_DISPLAY_SELL_OUT_PLAN
	     where company_code = 'C820'
	       --and material in ('AR09ASHABWKNAZ', 'AR12BSEAAMGNAZ', 'SM-R177NLVPZTO')
	 );
	 
	 create column table OW_LAO.TF_NERP_ZRCOS43400_DISPLAY_SELL_OUT_PLAN_SALES_PROGRESS_KPI_DEDUP as
	(
	 
		 select *
		      , 2023            as year
		   from OW_LAO.TMP_NERP_ZRCOS43400_DISPLAY_SELL_OUT_PLAN_SALES_PROGRESS_KPI
		  where dedup = 1
	);
	
	    
	 create column table OW_LAO.TF_NERP_ZRCOS43400_DISPLAY_SELL_OUT_PLAN_SALES_PROGRESS_KPI_FINAL as
	(    
	    select subsidiary
	         , material
	         , year
	         , QTY01
	         , QTY02
	         , QTY03
	         , QTY04
	         , QTY05
	         , QTY06
	         , QTY07
	         , QTY08
	         , QTY09
	         , QTY10
	         , QTY11
	         , QTY12  
	         , AMT01
	         , AMT02
	         , AMT03
	         , AMT04
	         , AMT05
	         , AMT06
	         , AMT07
	         , AMT08
	         , AMT09
	         , AMT10
	         , AMT11
	         , AMT12 
	      from OW_LAO.TF_NERP_ZRCOS43400_DISPLAY_SELL_OUT_PLAN_SALES_PROGRESS_KPI_DEDUP
	     where dedup_month = 1
	);
	
	
	    delete 
	      from OW_LAO.TF_NERP_ZRCOS43400_DISPLAY_SELL_OUT_PLAN_SALES_PROGRESS_KPI_DEDUP
	     where dedup_month = 1;
	
		
			BEGIN
			    DECLARE dedup_month       INT        = 0;
			    DECLARE dedup_month_max   INT        = 0; 
	            DECLARE dedup_month_exec  varchar(2) = '00';  
	            DECLARE dedup_month_value int        = 0;  
	            declare sql_exec          varchar(1000); 
			    
			    select max(dedup_month), min(dedup_month) into dedup_month_max, dedup_month
			      from OW_LAO.TF_NERP_ZRCOS43400_DISPLAY_SELL_OUT_PLAN_SALES_PROGRESS_KPI_DEDUP; 
			    
			    WHILE :dedup_month <= :dedup_month_max 
			       DO
			       
			        select max(case
			                    when length(dedup_month_value) = 1
			                    then concat('0', dedup_month_value)
			                    else cast(dedup_month_value as varchar(2))
			                end )
			             , max(dedup_month_value)                           into dedup_month_exec, dedup_month_value
	                  from OW_LAO.TF_NERP_ZRCOS43400_DISPLAY_SELL_OUT_PLAN_SALES_PROGRESS_KPI_DEDUP
	                 where dedup_month = :dedup_month;
			        
				    sql_exec =
				    concat(
				    concat(
				    concat(
				    concat(
				    concat(
				    concat(
				    concat( 
				    concat(
				    concat('update OW_LAO.TF_NERP_ZRCOS43400_DISPLAY_SELL_OUT_PLAN_SALES_PROGRESS_KPI_FINAL a
	                   set QTY', :dedup_month_exec)
	                     , ' = b.QTY')
	                     , :dedup_month_exec)
	                     , '
	                  from OW_LAO.TF_NERP_ZRCOS43400_DISPLAY_SELL_OUT_PLAN_SALES_PROGRESS_KPI_FINAL a
	                  join OW_LAO.TF_NERP_ZRCOS43400_DISPLAY_SELL_OUT_PLAN_SALES_PROGRESS_KPI_DEDUP b on b.year       = a.year
	                                                                                                 and b.material   = a.material
	                                                                                                 and b.subsidiary = a.subsidiary
	                 where b.dedup_month_value = ')
	                     , :dedup_month_value)
	                     , ' and b.QTY')
	                     , :dedup_month_exec)
	                     , ' > 0')
	                     , ';'
	                );
				    			    
				    EXECUTE IMMEDIATE :sql_exec;
				    
				    select replace(:sql_exec, 'QTY', 'AMT') into sql_exec
				      from dummy;
				      
				    EXECUTE IMMEDIATE :sql_exec;
	            
	                dedup_month = :dedup_month + 1;
			        
			    END WHILE;
			END;
	
	
	 create column table OW_LAO.TF_NERP_ZRCOS43400_DISPLAY_SELL_OUT_PLAN_SALES_PROGRESS_KPI_UNPIVOT as
	(
	     select subsidiary
	          , material     
	          , year  
	          , MAP(element_number,
	                1, 1,
	                2, 2,
	                3, 3,
	                4, 4,
	                5, 5,
	                6, 6,
	                7, 7,
	                8, 8,
	                9, 9,
	               10, 10,
	               11, 11,
	               12, 12
	            )                                       AS month
	          , MAP(element_number ,
	                1, QTY01,
	                2, QTY02,
	                3, QTY03,
	                4, QTY04,
	                5, QTY05,
	                6, QTY06,
	                7, QTY07,
	                8, QTY08,
	                9, QTY09,
	               10, QTY10,
	               11, QTY11,
	               12, QTY12
	            )                                       AS target_qty
	          , MAP(element_number ,
	                1, AMT01,
	                2, AMT02,
	                3, AMT03,
	                4, AMT04,
	                5, AMT05,
	                6, AMT06,
	                7, AMT07,
	                8, AMT08,
	                9, AMT09,
	               10, AMT10,
	               11, AMT11,
	               12, AMT12
	            )                                       AS target_amount
	       FROM OW_LAO.TF_NERP_ZRCOS43400_DISPLAY_SELL_OUT_PLAN_SALES_PROGRESS_KPI_FINAL
	          , SERIES_GENERATE_INTEGER(1, 1, 13)
	   order by subsidiary
	          , material    
	          , year  
	          , element_number
	);
	
	create column table OW_LAO.TF_NERP_ZRCOS43400_DISPLAY_SELL_OUT_PLAN_SALES_PROGRESS_KPI_UNPIVOT_AGG_DIVISION_GROUP as
	(
	    select year
	         , month
	         , division             as dimprod_division
	         , product_group_1      as dimprod_product_group
	         , sum(target_qty)      as target_qty
	         , sum(target_amount)   as target_amount
	      from OW_LAO.TF_NERP_ZRCOS43400_DISPLAY_SELL_OUT_PLAN_SALES_PROGRESS_KPI_UNPIVOT a
	 left join OW_MD.DIM_PRODUCT                                                          z on z.sku            = a.material
	  group by year
	         , month
	         , division
	         , product_group_1
	);
end