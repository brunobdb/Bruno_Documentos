CREATE procedure ow_lao.proc_ods_sela_custom_orders_items_validation
 as
 begin
with sela_sales_custom_validation
  as (                
        select top 1
               2     as monitoring_execution_result_status
             , 'OK'  as value
          from ow_lao.ods_sela_custom_orders_items
         where cast(inserted_timestamp as date) >= add_days(current_date, -1)
         
         union
         
        select top 1
               3     as monitoring_execution_result_status
             , 'NOT OK'  as value
          from dummy          
         where not exists(
                    select 1
                      from ow_lao.ods_sela_custom_orders_items
                     where cast(inserted_timestamp as date) >= add_days(current_date, -1)
               ) 
   )
   
   select top 1 *
     from sela_sales_custom_validation;  
     
     end