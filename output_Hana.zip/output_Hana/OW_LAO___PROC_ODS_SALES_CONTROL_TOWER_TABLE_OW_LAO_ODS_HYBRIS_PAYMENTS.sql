CREATE PROCEDURE OW_LAO.proc_ods_sales_control_tower_table_ow_lao_ods_hybris_payments
 LANGUAGE SQLSCRIPT AS
 BEGIN
      drop table ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_payments;
    
    create column table ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_payments
        as (   
               
		      select a.id                     as id
		           , c.po_id                  as po_orderid      
		           , c.payment_gateway        as po_payment_gateway
		           , cast(c.file_generated_at 
		                      as timestamp)   as po_source_payment_last_update_date
		        from ow_lao.ods_sales_control_tower_table a
		        join ow_lao.ods_hybris_sales              b on b.order_code     = a.po_orderid
		                                                   and b.product_code   = a.po_sku
		        join ow_lao.ods_hybris_payments           c on c.po_id          = b.order_code
		                                                   and c.store_id       = b.site
		                                                   and c.transaction_id = b.payment_transaction_code
		       where not exists(                        
                        select 1
                          from ow_lao.ods_sales_control_tower_table aa
                         where aa.po_orderid                          = a.po_orderid
                           and aa.po_sku                              = a.po_sku
                           and aa.country                             = a.country
                           and aa.po_source_payment_last_update_date >= cast(c.file_generated_at as timestamp)
                     )     
		    group by a.id
		           , c.po_id
		           , c.payment_gateway
		           , c.file_generated_at
        ); 
        
        
        update ow_lao.ods_sales_control_tower_table                                      a
           set a.po_payment_gateway                 = b.po_payment_gateway
             , a.po_source_payment_last_update_date = b.po_source_payment_last_update_date
          from ow_lao.ods_sales_control_tower_table                                      a
          join ow_lao.tmp_ecommerce_sales_control_tower_table_ow_lao_ods_hybris_payments b on b.id = a.id;             
                                                                                          
                                                                                          
                                                                                          
        end