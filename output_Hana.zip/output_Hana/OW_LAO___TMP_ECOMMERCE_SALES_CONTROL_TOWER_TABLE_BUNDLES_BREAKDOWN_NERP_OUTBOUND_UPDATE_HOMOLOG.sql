CREATE PROCEDURE OW_LAO.tmp_ecommerce_sales_control_tower_table_bundles_breakdown_nerp_outbound_update_homolog
 LANGUAGE SQLSCRIPT AS
 BEGIN
        update ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown  a
           set a.delivery_no                    = b.delivery_no
             , a.city                           = b.city
             , a.region                         = b.region
             , a.district                       = b.district
             , a.date_toretrive                 = b.planned_gi
             , a.date_retrived                  = b."1ST_GI_DATE"
             , a.volume                         = b.volume
             , a.weight                         = b.weight
             , a.shipping_type                  = b.shipping_type
             , a.date_delivered                 = b.rdd
             , a.storage_location               = b.storage_location
             , a.final_eta_date                 = b.final_eta
             , a.delivey_date                   = b.epod_date
             , a.serial_number_code             = b.ean
             , a.delivery_extimeted_date        = b.delivery_date
             , a.delivery_carrier               = b.transporter_name
             , a.nerp_outbound_last_update_date = b.load_date
             , a.updated_datetime               = current_timestamp
          from ow_lao.tmp_ecommerce_sales_control_tower_table_bundles_breakdown  a
          join ow_lao.ods_nerp_zllej50090_outbound_tracking                      b on b.delivery_no = a.nerp_deliverycode
                                                                                  and b.material    = nerp_sku
         where a.nerp_outbound_last_update_date < b.load_date
            or a.nerp_outbound_last_update_date is null;
            
    end