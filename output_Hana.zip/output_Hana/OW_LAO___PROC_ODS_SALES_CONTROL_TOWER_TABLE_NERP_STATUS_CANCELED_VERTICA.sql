CREATE OR REPLACE PROCEDURE OW_LAO.proc_ods_sales_control_tower_table_nerp_status_canceled()
LANGUAGE PLvSQL AS $$
BEGIN
  -- Criação da tabela temporária (Vertica: LOCAL TEMP é session, não precisa ON COMMIT)
  PERFORM DROP TABLE IF EXISTS tmp_division_nerp_control_tower_status;
  PERFORM CREATE LOCAL TEMP TABLE tmp_division_nerp_control_tower_status AS
    SELECT po_orderid, division, po_status, po_internal_status, so_date
    FROM ow_lao.ods_sales_control_tower_table
    WHERE 1=0;

  -- 1) payment rejected para Cancelled
  PERFORM TRUNCATE TABLE tmp_division_nerp_control_tower_status;
  PERFORM INSERT INTO tmp_division_nerp_control_tower_status (po_orderid, division, po_status, po_internal_status, so_date)
  SELECT DISTINCT
         po_orderid,
         division,
         po_status,
         CASE WHEN po_status = 'Cancelled' THEN 'payment rejected' ELSE po_internal_status END AS po_internal_status,
         so_date
  FROM ow_lao.ods_sales_control_tower_table
  WHERE po_status = 'Cancelled'
    AND client_subsidiary_id = 6
    AND CAST(po_date AS DATE) BETWEEN CAST(TIMESTAMPADD(DAY, -180, CURRENT_TIMESTAMP) AS DATE)
                                  AND CAST(CURRENT_TIMESTAMP AS DATE);

  PERFORM UPDATE ow_lao.ods_sales_control_tower_table a
    SET po_internal_status = b.po_internal_status
  FROM tmp_division_nerp_control_tower_status b
  WHERE b.po_orderid = a.po_orderid
    AND a.client_subsidiary_id = 6;

  -- 2) so_date localizado + Cancelled, excluindo divisões
  PERFORM TRUNCATE TABLE tmp_division_nerp_control_tower_status;
  PERFORM INSERT INTO tmp_division_nerp_control_tower_status (po_orderid, division, po_status, po_internal_status, so_date)
  SELECT DISTINCT
         po_orderid,
         division,
         po_status,
         CASE WHEN po_status = 'Cancelled' THEN 'canceled' ELSE po_internal_status END AS po_internal_status,
         so_date
  FROM ow_lao.ods_sales_control_tower_table
  WHERE so_date IS NOT NULL
    AND po_status = 'Cancelled'
    AND client_subsidiary_id = 6
    AND po_orderid NOT IN (
          SELECT DISTINCT a.po_orderid
          FROM ow_lao.ods_sales_control_tower_table a
          WHERE a.division IN ('Bundle','SC+','SERVICE')
        )
    AND CAST(po_date AS DATE) BETWEEN CAST(TIMESTAMPADD(DAY, -180, CURRENT_TIMESTAMP) AS DATE)
                                  AND CAST(CURRENT_TIMESTAMP AS DATE);

  PERFORM UPDATE ow_lao.ods_sales_control_tower_table a
    SET po_internal_status = b.po_internal_status
  FROM tmp_division_nerp_control_tower_status b
  WHERE b.po_orderid = a.po_orderid
    AND a.client_subsidiary_id = 6;

  -- 3) Divisões Bundle, SC+, SERVICE
  PERFORM TRUNCATE TABLE tmp_division_nerp_control_tower_status;
  PERFORM INSERT INTO tmp_division_nerp_control_tower_status (po_orderid, division, po_status, po_internal_status, so_date)
  SELECT DISTINCT
         po_orderid,
         division,
         po_status,
         CASE
           WHEN po_internal_status = 'payment rejected' THEN 'canceled'
           WHEN po_internal_status = 'canceled' THEN 'canceled'
           ELSE po_internal_status
         END AS po_internal_status,
         so_date
  FROM ow_lao.ods_sales_control_tower_table
  WHERE division IN ('Bundle','SC+','SERVICE')
    AND po_status = 'Cancelled'
    AND client_subsidiary_id = 6
    AND CAST(po_date AS DATE) BETWEEN CAST(TIMESTAMPADD(DAY, -180, CURRENT_TIMESTAMP) AS DATE)
                                  AND CAST(CURRENT_TIMESTAMP AS DATE);

  PERFORM UPDATE ow_lao.ods_sales_control_tower_table a
    SET po_internal_status = b.po_internal_status
  FROM tmp_division_nerp_control_tower_status b
  WHERE b.po_orderid = a.po_orderid
    AND a.client_subsidiary_id = 6;

END
$$;