create procedure ow_lao.proc_ods_sales_control_tower_vtex_ssg_mirgor_cancel_orders
    as
     begin
         drop table #stg_vtex_order_seasa_mirgor_cancel_filter;
       create local temporary table #stg_vtex_order_seasa_mirgor_cancel_filter
          as (
		           select a.id
		                , a.po_orderid
		                , a.po_sku
		                , a.po_status
		             from ow_lao.ods_sales_control_tower_table          a
		             join u_prj_ecom.stg_vtex_order_seasa_mirgor_cancel b on b.ref_id_cut = a.po_sku
		                                                                 and b.order_id   = case 
		                                                                                        when locate(a.po_orderid, '-') = 4
		                                                                                        then substring(a.po_orderid, 5, length(a.po_orderid) -7)
		                                                                                        when locate(a.po_orderid, '-') > 4
		                                                                                        then substring(a.po_orderid, 1, length(a.po_orderid) -3)
		                                                                                        else a.po_orderid
		                                                                                    end
		            where a.po_status != 'Cancelled'
                      and lower(a.po_seller_id) like '%mirgor%'
                      and a.client_subsidiary_id    = 1
                      and a.po_plataform_datasource in ('u_prj_ecom.raw_vtex_ssg_ar_sales_order', 'u_prj_ecom.ft_ecom_order')
			);	    
			
			
			
			insert into #stg_vtex_order_seasa_mirgor_cancel_filter
			select distinct
			       a.id
                 , a.po_orderid
                 , a.po_sku
                 , a.po_status
			  from ow_lao.ods_sales_control_tower_table          a
              join u_prj_ecom.stg_vtex_order_seasa_mirgor_cancel b on b.order_id   = case 
                                                                                         when locate(a.po_orderid, '-') = 4
                                                                                         then substring(a.po_orderid, 5, length(a.po_orderid) -7)
                                                                                         when locate(a.po_orderid, '-') > 4
                                                                                         then substring(a.po_orderid, 1, length(a.po_orderid) -3)
                                                                                         else a.po_orderid
                                                                                      end
            where a.po_status               != 'Cancelled'
              and lower(a.po_seller_id)     like '%mirgor%'
              and a.client_subsidiary_id    = 1
              and a.po_plataform_datasource in ('u_prj_ecom.raw_vtex_ssg_ar_sales_order', 'u_prj_ecom.ft_ecom_order')
              and not exists(
                        select 1
                          from #stg_vtex_order_seasa_mirgor_cancel_filter aa
                         where aa.po_orderid = a.po_orderid
                  )
              and exists (
              
                        select po_orderid
                          from ow_lao.ods_sales_control_tower_table bb
                         where bb.po_orderid = a.po_orderid
                      group by po_orderid
                        having count(1) = 1
                          
                  );     
                  
                  
            update ow_lao.ods_sales_control_tower_table       a
               set po_status = 'Cancelled'
                 , updated_datetime = current_timestamp
              from ow_lao.ods_sales_control_tower_table       a
              join #stg_vtex_order_seasa_mirgor_cancel_filter b on b.id = a.id;          
                        
    end