CREATE PROCEDURE OW_LAO.proc_ods_sales_control_tower_table_empty_dimensions_alert
 LANGUAGE SQLSCRIPT as
     begin 
          
         create local temporary table #ods_sales_control_tower_table_dimensions 
        as (
                select distinct  
                       country
                     , po_devicetype
                     , po_storename
                     , audience_type
                     , biz_type
                  from ow_lao.ods_sales_control_tower_table
                 where po_date >= add_days(current_date, -10)
                   and po_devicetype is not null 
                   and po_storename is not null
        );
            
    select a.country
         , a.po_devicetype
         , a.po_storename
         , a.audience_type
         , a.biz_type
         , count(b.id)         quantity
      from #ods_sales_control_tower_table_dimensions a
 left join ow_lao.ods_sales_control_tower_table      b on b.country       = a.country      
                                                      and b.po_devicetype = a.po_devicetype 
                                                      and b.po_storename  = a.po_storename 
                                                      and b.audience_type = a.audience_type
                                                      and b.biz_type      = a.biz_type   
                                                      and b.po_date      >= add_days(current_date, -5)
  group by a.country
         , a.po_devicetype
         , a.po_storename
         , a.audience_type
         , a.biz_type
    having count(b.id) = 0;
    
  end;