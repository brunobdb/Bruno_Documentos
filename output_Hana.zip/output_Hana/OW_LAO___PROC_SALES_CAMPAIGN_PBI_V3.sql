
CREATE PROCEDURE OW_LAO.PROC_SALES_CAMPAIGN_PBI_V3(
	IN CONSULTA NVARCHAR(40),
	IN DT_START TIMESTAMP
) LANGUAGE SQLSCRIPT AS
BEGIN
	/*-------------------------------------------------------------------------------------------------*/
	--	
	IF :CONSULTA = 'CAMPAIGN_SALES' THEN		
	BEGIN
		TRUNCATE TABLE OW_LAO.TMP_CAMPAIGN_CUT;
		INSERT INTO OW_LAO.TMP_CAMPAIGN_CUT 
		SELECT 
			A.CAMPAIGN_TAG,
			A.SUBSIDIARY,
			MIN(A.CAMPAIGN_DAY) 	AS CAMPAIGN_TAG_START, 
			MAX(A.CAMPAIGN_DAY) 	AS CAMPAIGN_TAG_END
		FROM 
			OW_LAO.ODS_SALES_CAMPAIGN  A
		WHERE 
			(A.PO_STATUS = 'Approved' OR (A.SUBSIDIARY = 'SELA' AND A.PO_STATUS = 'Pending')) 
			AND A.PREVIOUS_YEAR = FALSE  
			AND CAST(A.PO_DATE AS DATE) >= :DT_START
		GROUP BY 
			A.CAMPAIGN_TAG,
			A.SUBSIDIARY;
		/*-------------------------------------------------------------------------------------------------*/
		--Retorna os dados do período anterior
		SELECT 
			*
		FROM 
			OW_LAO.ODS_SALES_CAMPAIGN  A
		WHERE 
			(A.PO_STATUS = 'Approved' OR (A.SUBSIDIARY = 'SELA' AND A.PO_STATUS = 'Pending')) 
			AND A.PREVIOUS_YEAR = TRUE 
			AND EXISTS (
				SELECT 
					1 
				FROM 
					OW_LAO.TMP_CAMPAIGN_CUT B
				WHERE 
					A.CAMPAIGN_TAG 		= B.CAMPAIGN_TAG 
					AND A.SUBSIDIARY	= B.SUBSIDIARY 
					AND A.CAMPAIGN_DAY BETWEEN B.CAMPAIGN_TAG_START AND B.CAMPAIGN_TAG_END
			)
		UNION ALL
		/*-------------------------------------------------------------------------------------------------*/
		--Retorna os dados do período atual 
		SELECT 
			* 
		FROM 
		  	OW_LAO.ODS_SALES_CAMPAIGN  
		WHERE  
		  	(PO_STATUS = 'Approved' OR (SUBSIDIARY = 'SELA' AND PO_STATUS = 'Pending')) 
		  	AND PREVIOUS_YEAR = FALSE  
		  	AND CAST(PO_DATE AS DATE) >= :DT_START;				
	END;
	ELSEIF :CONSULTA = 'DIM_CAMPAIGN_NAME_REGISTER' THEN		
	BEGIN
		WITH campaign_cte AS (
		    SELECT
		        CAMPAIGN_TAG,
		        SUBSIDIARY AS Samsung_Sub,
		        CASE
		            WHEN BIZ_TYPE IS NULL OR BIZ_TYPE = '' THEN 'all'
		            ELSE UPPER(BIZ_TYPE)
		        END AS business,
		        CASE
		            WHEN PO_DEVICETYPE IS NULL OR PO_DEVICETYPE = '' THEN 'all'
		            ELSE LOWER(PO_DEVICETYPE)
		        END AS device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM
		        OW_LAO.DIM_CAMPAIGN_NAME AS campaign
		),
		-- Expansão para business 'SMB', 'B2C', 'EPP' e device 'app', 'web'
		expanded_campaign AS (
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        'SMB' AS business,
		        'app' AS device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business = 'all' AND device = 'all'
		   
		    UNION ALL
		   
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        'SMB' AS business,
		        'web' AS device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business = 'all' AND device = 'all'
		
		    UNION ALL
		
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        'B2C' AS business,
		        'app' AS device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business = 'all' AND device = 'all'
		   
		    UNION ALL
		   
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        'B2C' AS business,
		        'web' AS device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business = 'all' AND device = 'all'
		   
		    UNION ALL
		
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        'EPP' AS business,
		        'app' AS device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business = 'all' AND device = 'all'
		   
		    UNION ALL
		   
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        'EPP' AS business,
		        'web' AS device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business = 'all' AND device = 'all'
		),
		-- Expansão para cases onde apenas business é 'all'
		business_only_expansion AS (
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        'SMB' AS business,
		        device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business = 'all' AND device != 'all'
		
		    UNION ALL
		
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        'B2C' AS business,
		        device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business = 'all' AND device != 'all'
		   
		    UNION ALL
		   
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        'EPP' AS business,
		        device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business = 'all' AND device != 'all'
		),
		-- Expansão para cases onde apenas device é 'all'
		device_only_expansion AS (
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        business,
		        'app' AS device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business != 'all' AND device = 'all'
		
		    UNION ALL
		
		    SELECT
		        CAMPAIGN_TAG,
		        Samsung_Sub,
		        business,
		        'web' AS device,
		        division,
		        INITIAL_DATE,
		        FINAL_DATE,
		        product,
		        product_group,
		        po_sku,
		        id_campaign,
		        audience_type
		    FROM campaign_cte
		    WHERE business != 'all' AND device = 'all'
		),
		-- Combinação final dos dados expandidos
		final_expansion AS (
		    SELECT * FROM campaign_cte WHERE business != 'all' AND device != 'all'
		    UNION ALL
		    SELECT * FROM expanded_campaign
		    UNION ALL
		    SELECT * FROM business_only_expansion
		    UNION ALL
		    SELECT * FROM device_only_expansion
		)
		-- Expansão de datas com o join na tabela de calendário
		SELECT
		    fe.*,
		    cal.yyyymmdd AS campaign_date
		FROM final_expansion fe
		JOIN ow_md.dim_calendar cal
		    ON cal.yyyymmdd BETWEEN fe.INITIAL_DATE AND fe.FINAL_DATE;		
		
	END;
	ELSE
		SELECT 'Procedimento não declaro' AS CONSULTA FROM DUMMY;		
	END IF;
END
