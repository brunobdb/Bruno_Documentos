CREATE PROCEDURE PROC_CRAWLING_AP1_REF_SITE_MAPPING_MERGE_AUTOMATIC
LANGUAGE SQLSCRIPT as
BEGIN
--===================================================================
--Input do Arquivo
MERGE INTO OW_LAO.INPUT_CRAWLING_AP1_REF_SITE_MAPPING AS Destino
USING 
(SELECT MIN(MODEL_MAPPING) AS MODEL_MAPPING ,
	MIN(AP2) AS AP2,
	MIN(COUNTRY) AS COUNTRY,
	MIN(COMPANY_NAME) AS COMPANY_NAME,
	MIN(BRAND_NM) AS BRAND_NM,
	MIN(DESCRIPTION) AS DESCRIPTION ,
	MIN(MODEL_REF_1) AS MODEL_REF_1,
	MIN(MODEL_REF_2) AS MODEL_REF_2,
	MIN(MODEL_REF_3) AS MODEL_REF_3,
	MIN(MODEL_REF_4) AS MODEL_REF_4,
	SITE_URL ,
	MIN(LOWER_POSITION) AS LOWER_POSITION,
	MIN(CRAWLING_QTY) AS CRAWLING_QTY,
	MIN(FILE_NAME) AS FILE_NAME,
	MIN(LOAD_DATE) AS LOAD_DATE FROM OW_LAO.INPUT_CRAWLING_AP1_REF_SITE_MAPPING_TMP WHERE SITE_URL IN (
SELECT DISTINCT PROD_HREF FROM ODS_CRAWLING_AP1_REF_PRODUCT_DETAIL
) GROUP BY SITE_URL) AS Origem
--Condição: O produto existe nas 2 tabelas e o cliente também
ON (Destino.SITE_URL = Origem.SITE_URL)
--Se a condição for obedecida, ou seja, existem registros nas duas tabelas
WHEN MATCHED THEN
    UPDATE SET Destino.MODEL_MAPPING = Origem.MODEL_MAPPING ,
	Destino.AP2 = Origem.AP2,
	Destino.COUNTRY = Origem.COUNTRY,
	Destino.COMPANY_NAME = Origem.COMPANY_NAME,
	Destino.BRAND_NM = Origem.BRAND_NM,
	Destino.DESCRIPTION = Origem.DESCRIPTION,
	Destino.MODEL_REF_1 = Origem.MODEL_REF_1,
	Destino.MODEL_REF_2 = Origem.MODEL_REF_2,
	Destino.MODEL_REF_3 = Origem.MODEL_REF_3,
	Destino.MODEL_REF_4 = Origem.MODEL_REF_4,
	Destino.LOWER_POSITION = Origem.LOWER_POSITION,
	Destino.CRAWLING_QTY = Origem.CRAWLING_QTY,
	Destino.FILE_NAME = Origem.FILE_NAME,
	Destino.LOAD_DATE = Origem.LOAD_DATE,	
	Destino.MAPPING_TYPE = 'MANUAL',
	Destino.CREATED_DATE = Destino.CREATED_DATE,
	Destino.UPDATED_DATE = CURRENT_DATE
--Se a condição não foi obedecida porque o registro não existe na tabela de destino
WHEN NOT MATCHED THEN
   INSERT VALUES (Origem.MODEL_MAPPING ,
	Origem.AP2,
	Origem.COUNTRY,
	Origem.COMPANY_NAME,
	Origem.BRAND_NM,
	Origem.DESCRIPTION,
	Origem.MODEL_REF_1,
	Origem.MODEL_REF_2,
	Origem.MODEL_REF_3,
	Origem.MODEL_REF_4,
	Origem.SITE_URL,
	Origem.LOWER_POSITION,
	Origem.CRAWLING_QTY,
	Origem.FILE_NAME,
	Origem.LOAD_DATE,
	'MANUAL',
	CURRENT_DATE,
	CURRENT_DATE
	);
	
--========================================================================
--========================================================================
--Input Automatico
--======== URL COM MODEL_MAPPING ENCONTRADO
MERGE INTO OW_LAO.INPUT_CRAWLING_AP1_REF_SITE_MAPPING AS Destino
    /*Marcos
      Data de Criação 28/06/2021 - Remover duplicidades de SITE_URL --erro rowid duplicated
	  Row_num criado para contar as URLs e filtrar apenas a primeira caso haja duplicidades
	  Seleciona todas as colunas menos o row_num
	*/
 USING (SELECT
	 "MAPPING_ORIGEM",
	"MODEL_MAPPING",
	 "SITE_URL",
	 "MODEL_REF_1",
	 "MODEL_REF_2",
	"MODEL_REF_3",
	"MODEL_REF_4",
	"SUB",
	"COUNTRY",
	 "COMPANY_NAME",
	"BRAND_NM",
	"DESCRIPTION",
	"LOWER_POSITION",
	"CRAWLING_QTY" 
	FROM ( SELECT
	 A.*,
	 ROW_NUMBER() OVER (PARTITION BY A.SITE_URL 
			ORDER BY A.SITE_URL DESC) AS row_num 
		FROM OW_LAO.VW_CRAWLING_AP1_REF_SITE_SPEC_MAPPING_AUTOMATIC A) 
	WHERE row_num = 1) AS Origem
--Condição: O produto existe nas 2 tabelas e o cliente também
ON (Destino.SITE_URL = Origem.SITE_URL AND ORIGEM.MODEL_MAPPING IS NOT NULL)
--Se a condição for obedecida, ou seja, existem registros nas duas tabelas
-- UPDATE DOS REGISTROS ENCONTRADOS NA INPUT COM MODEL_MAPPING NULO OU MAPPING_TYPE <> MANUAL
WHEN MATCHED THEN
    UPDATE SET 
    Destino.MODEL_MAPPING = Origem.MODEL_MAPPING ,
	Destino.AP2 = Origem.SUB,
	Destino.COUNTRY = Origem.COUNTRY,
	Destino.COMPANY_NAME = Origem.COMPANY_NAME,
	Destino.BRAND_NM = Origem.BRAND_NM,
	Destino.DESCRIPTION = Origem.DESCRIPTION,
	Destino.MODEL_REF_1 = Origem.MODEL_REF_1,
	Destino.MODEL_REF_2 = Origem.MODEL_REF_2,
	Destino.MODEL_REF_3 = Origem.MODEL_REF_3,
	Destino.MODEL_REF_4 = Origem.MODEL_REF_4,
	Destino.LOWER_POSITION = Origem.LOWER_POSITION,
	Destino.CRAWLING_QTY = Origem.CRAWLING_QTY,
	Destino.FILE_NAME = Destino.FILE_NAME,
	Destino.LOAD_DATE = Destino.LOAD_DATE,
	Destino.MAPPING_TYPE = Origem.MAPPING_ORIGEM,
	Destino.CREATED_DATE = Destino.CREATED_DATE,
	Destino.UPDATED_DATE = CURRENT_DATE;
--======== URL SEM MODEL_MAPPING ENCONTRADO ATUALIZANDO SOMENTE DADOS
MERGE INTO OW_LAO.INPUT_CRAWLING_AP1_REF_SITE_MAPPING AS Destino
   /*Marcos
      Data de Criação 28/06/2021 - Remover duplicidades de SITE_URL --erro rowid duplicated
	  Row_num criado para contar as URLs e filtrar apenas a primeira caso haja duplicidades
	  Seleciona todas as colunas menos o row_num
	*/
 USING (SELECT
	 "MAPPING_ORIGEM",
	"MODEL_MAPPING",
	 "SITE_URL",
	 "MODEL_REF_1",
	 "MODEL_REF_2",
	"MODEL_REF_3",
	"MODEL_REF_4",
	"SUB",
	"COUNTRY",
	 "COMPANY_NAME",
	"BRAND_NM",
	"DESCRIPTION",
	"LOWER_POSITION",
	"CRAWLING_QTY" 
	FROM ( SELECT
	 A.*,
	 ROW_NUMBER() OVER (PARTITION BY A.SITE_URL 
			ORDER BY A.SITE_URL DESC) AS row_num 
		FROM OW_LAO.VW_CRAWLING_AP1_REF_SITE_SPEC_MAPPING_AUTOMATIC A) 
	WHERE row_num = 1) AS Origem
--Condição: O produto existe nas 2 tabelas e o cliente também
ON (Destino.SITE_URL = Origem.SITE_URL AND ORIGEM.MODEL_MAPPING IS NULL)
--Se a condição for obedecida, ou seja, existem registros nas duas tabelas
-- UPDATE DOS REGISTROS ENCONTRADOS NA INPUT COM MODEL_MAPPING NULO OU MAPPING_TYPE <> MANUAL
WHEN MATCHED THEN
    UPDATE SET 
	Destino.AP2 = Origem.SUB,
	Destino.COUNTRY = Origem.COUNTRY,
	Destino.COMPANY_NAME = Origem.COMPANY_NAME,
	Destino.BRAND_NM = Origem.BRAND_NM,
	Destino.DESCRIPTION = Origem.DESCRIPTION,
	Destino.LOWER_POSITION = Origem.LOWER_POSITION,
	Destino.CRAWLING_QTY = Origem.CRAWLING_QTY,
	Destino.UPDATED_DATE = CURRENT_DATE;
	
--======== NOVA URL ENCONTRADA NO RPA SENDO INSERIDA NA INPUT
MERGE INTO OW_LAO.INPUT_CRAWLING_AP1_REF_SITE_MAPPING AS Destino
   /*Marcos
      Data de Criação 28/06/2021 - Remover duplicidades de SITE_URL --erro rowid duplicated
	  Row_num criado para contar as URLs e filtrar apenas a primeira caso haja duplicidades
	  Seleciona todas as colunas menos o row_num
	*/
 USING (SELECT
	 "MAPPING_ORIGEM",
	"MODEL_MAPPING",
	 "SITE_URL",
	 "MODEL_REF_1",
	 "MODEL_REF_2",
	"MODEL_REF_3",
	"MODEL_REF_4",
	"SUB",
	"COUNTRY",
	 "COMPANY_NAME",
	"BRAND_NM",
	"DESCRIPTION",
	"LOWER_POSITION",
	"CRAWLING_QTY" 
	FROM ( SELECT
	 A.*,
	 ROW_NUMBER() OVER (PARTITION BY A.SITE_URL 
			ORDER BY A.SITE_URL DESC) AS row_num 
		FROM OW_LAO.VW_CRAWLING_AP1_REF_SITE_SPEC_MAPPING_AUTOMATIC A) 
	WHERE row_num = 1) AS Origem
--Condição: O produto existe nas 2 tabelas e o cliente também
ON (Destino.SITE_URL = Origem.SITE_URL)
--Se a condição não foi obedecida porque o registro não existe na tabela de destino
--
WHEN NOT MATCHED THEN
   INSERT VALUES (Origem.MODEL_MAPPING , 
	Origem.SUB,
	Origem.COUNTRY,
	Origem.COMPANY_NAME,
	Origem.BRAND_NM, 
	Origem.DESCRIPTION,
	Origem.MODEL_REF_1,
	Origem.MODEL_REF_2,
	Origem.MODEL_REF_3,
	Origem.MODEL_REF_4,
	Origem.SITE_URL,
	Origem.LOWER_POSITION,
	Origem.CRAWLING_QTY,
	NULL,
	NULL,
	Origem.MAPPING_ORIGEM,
	CURRENT_DATE,
	CURRENT_DATE);
	
--=======================================================================
--=======================================================================
--TRUNCAR TABELA MP
TRUNCATE TABLE "OW_LAO"."MP_CRAWLING_AP1_REF_SITE_SPEC_MAPPING";
--POPULAR TABELA MP
INSERT INTO "OW_LAO"."MP_CRAWLING_AP1_REF_SITE_SPEC_MAPPING" ( "MAPPING_ORIGEM",
	 "MODEL_MAPPING",
	 "SITE_URL",
	 "MKTSEGMENT",
	 "PRODUCT",
	 "GFK_CONSTRUCTION",
	 "GFK_DEPTH_IN_CM",
	 "GFK_FIRSTACTIVITY",
	 "GFK_FREEZ_POSITION",
	 "GFK_FREEZER_STARS",
	 "GFK_FRONT_DECORAT",
	 "GFK_HEIGHT_IN_CM",
	 "GFK_MAIN_TYPES",
	 "GFK_MOUNTING_SYSTEM",
	 "GFK_NET_LTRS",
	 "GFK_NOFROST_SYSTEM",
	 "GFK_WIDTH_IN_CM",
	 "BRAND_GROUP",
	 "TYPE",
	 "TECHNOLOGY",
	 "SSG_PIN2PIN",
	 "LOAD_DATE" )
SELECT
	 "I"."MAPPING_TYPE" MAPPING_ORIGEM ,
	 "I"."MODEL_MAPPING" ,
	 "I"."SITE_URL" ,
	 "S"."MKTSEGMENT" ,
	 "S"."PRODUCT" ,
	 "S"."GFK_CONSTRUCTION",
	 "S"."GFK_DEPTH_IN_CM",
	 "S"."GFK_FIRSTACTIVITY",
	 "S"."GFK_FREEZ_POSITION",
	 "S"."GFK_FREEZER_STARS",
	 "S"."GFK_FRONT_DECORAT",
	 "S"."GFK_HEIGHT_IN_CM",
	 "S"."GFK_MAIN_TYPES",
	 "S"."GFK_MOUNTING_SYSTEM",
	 "S"."GFK_NET_LTRS",
	 "S"."GFK_NOFROST_SYSTEM",
	 "S"."GFK_WIDTH_IN_CM",
	 "S"."BRAND_GROUP" ,
	 "S"."TYPE" ,
	 "S"."TECHNOLOGY" ,
	 "S"."SSG_PIN2PIN" ,
	 "S"."LOAD_DATE" 
FROM --tabela de input 
 INPUT_CRAWLING_AP1_REF_SITE_MAPPING AS I 
LEFT JOIN ( SELECT
	 B.* 
	FROM (SELECT
	 MODEL_CODE,
	 MAX(ROW_NUM) as ROW_NUM 
		FROM ( SELECT
	 S.MODEL_CODE,
	 ROW_NUMBER() OVER ( PARTITION BY S.MODEL_CODE) AS ROW_NUM 
			FROM INPUT_CRAWLING_AP1_REF_SPEC_MAPPING AS S ) 
		GROUP BY MODEL_CODE) AS A 
	INNER JOIN (SELECT
	 S.MODEL_CODE,
	 S.MKTSEGMENT,
	 S.PRODUCT,
	 S.GFK_CONSTRUCTION,
	 S.GFK_DEPTH_IN_CM,
	 S.GFK_FIRSTACTIVITY,
	 S.GFK_FREEZ_POSITION,
	 S.GFK_FREEZER_STARS,
	 S.GFK_FRONT_DECORAT,
	 S.GFK_HEIGHT_IN_CM,
	 S.GFK_MAIN_TYPES,
	 S.GFK_MOUNTING_SYSTEM,
	 S.GFK_NET_LTRS,
	 S.GFK_NOFROST_SYSTEM,
	 S.GFK_WIDTH_IN_CM,
	 S.BRAND_GROUP,
	 S.TYPE,
	 S.TECHNOLOGY,
	 S.SSG_PIN2PIN,
	 S.LOAD_DATE,
	 ROW_NUMBER() OVER ( PARTITION BY S.MODEL_CODE) AS ROW_NUM 
		from INPUT_CRAWLING_AP1_REF_SPEC_MAPPING as S) as B on TRIM(UPPER(A.MODEL_CODE)) = TRIM(UPPER(B.MODEL_CODE)) 
	and A.ROW_NUM=B.ROW_NUM) AS S ON TRIM(UPPER(I.MODEL_MAPPING)) = TRIM(UPPER(S.MODEL_CODE));
--=======================================================================
END;