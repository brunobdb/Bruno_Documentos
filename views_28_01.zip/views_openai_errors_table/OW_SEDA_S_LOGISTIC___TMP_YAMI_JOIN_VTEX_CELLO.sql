-- MISSING RELATION: OW_SEDA_S_LOGISTIC.TMP_VW_YAMI_UNION
-- ERROR: Error executing query: Severity: ERROR, Message: Relation "OW_SEDA_S_LOGISTIC.TMP_VW_YAMI_UNION" does not exist, Sqlstate: 42V01, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Miner/server/vertica/Catalog/CatalogLookup.cpp, Line: 4362, Error Code: 4568, SQL: 'CREATE OR REPLACE VIEW "OW_SEDA_S_LOGISTIC"."TMP_YAMI_JOIN_VTEX_CELLO" (   "Customer PO",   "DO No.",   "Material Code",   "Order Status ",   "IOD Date",   "ORDER_ID_VTEX",   "SEQUENCE_VTEX",   "STATUS_DESCRIPTION",   "PO",   "SEQ",   "SKU" ) AS SELECT   "C"."Customer PO",   "C"."DO No.",   "C"."Material Code",   "C"."Order Status ",   "C"."IOD Date",   "Y"."ORDER_ID_VTEX",   "Y"."SEQUENCE_VTEX",   "Y"."STATUS_DESCRIPTION",   "Y"."PO",   "Y"."SEQ",   "Y"."SKU" FROM OW_SEDA_S_LOGISTIC.TMP_VW_YAMI_UNION AS y LEFT JOIN OW_SEDA_S_LOGISTIC.TMP_CELLO_UNION_PO_DO_SKU_STATUS AS c   ON (     CASE       WHEN y.ORDER_ID_VTEX = c."Customer PO"       THEN 1       WHEN y.PO = c."Customer PO"       THEN 1       WHEN REPLACE(y.PO, \'-01\', \'\') = REGEXP_REPLACE((REPLACE(c."Customer PO", \'-01\', \'\'))::VARCHAR, \'[^0-9]\', \'\')       THEN 1       ELSE 0     END   ) = 1   AND Y.SKU = c."Material Code"'

CREATE OR REPLACE VIEW "OW_SEDA_S_LOGISTIC"."TMP_YAMI_JOIN_VTEX_CELLO" (
  "Customer PO",
  "DO No.",
  "Material Code",
  "Order Status ",
  "IOD Date",
  "ORDER_ID_VTEX",
  "SEQUENCE_VTEX",
  "STATUS_DESCRIPTION",
  "PO",
  "SEQ",
  "SKU"
) AS
SELECT
  "C"."Customer PO",
  "C"."DO No.",
  "C"."Material Code",
  "C"."Order Status ",
  "C"."IOD Date",
  "Y"."ORDER_ID_VTEX",
  "Y"."SEQUENCE_VTEX",
  "Y"."STATUS_DESCRIPTION",
  "Y"."PO",
  "Y"."SEQ",
  "Y"."SKU"
FROM OW_SEDA_S_LOGISTIC.TMP_VW_YAMI_UNION AS y
LEFT JOIN OW_SEDA_S_LOGISTIC.TMP_CELLO_UNION_PO_DO_SKU_STATUS AS c
  ON (
    CASE
      WHEN y.ORDER_ID_VTEX = c."Customer PO"
      THEN 1
      WHEN y.PO = c."Customer PO"
      THEN 1
      WHEN REPLACE(y.PO, '-01', '') = REGEXP_REPLACE((REPLACE(c."Customer PO", '-01', ''))::VARCHAR, '[^0-9]', '')
      THEN 1
      ELSE 0
    END
  ) = 1
  AND Y.SKU = c."Material Code"