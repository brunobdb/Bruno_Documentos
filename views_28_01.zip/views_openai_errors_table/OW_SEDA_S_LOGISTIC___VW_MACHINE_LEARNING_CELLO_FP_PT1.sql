-- MISSING RELATION: OW_SEDA_S_LOGISTIC.ST_MACHINE_LEARNING_CELLO_TRK_PT1
-- ERROR: Error executing query: Severity: ERROR, Message: Relation "OW_SEDA_S_LOGISTIC.ST_MACHINE_LEARNING_CELLO_TRK_PT1" does not exist, Sqlstate: 42V01, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Miner/server/vertica/Catalog/CatalogLookup.cpp, Line: 4362, Error Code: 4568, SQL: 'CREATE OR REPLACE VIEW "OW_SEDA_S_LOGISTIC"."VW_MACHINE_LEARNING_CELLO_FP_PT1" (   "DELIVERY_NO",   "TRK_CODE",   "PARTNER_ID",   "EVENT_DESC",   "TRK_DATE" ) AS SELECT   cfp.DELIVERY_NO,   cfp.TRK_CODE,   CT.PARTNER_ID,   cfp.TRK_NM AS EVENT_DESC,   cfp.TRK_DATE FROM OW_SEDA_S.CELLO_FUTHER_PROCESSING AS cfp LEFT JOIN (   SELECT     DELIVERY_NO,     TRK_CODE,     PARTNER_ID,     TRK_DATE   FROM OW_SEDA_S_LOGISTIC.ST_MACHINE_LEARNING_CELLO_TRK_PT1 AS CT   WHERE     TRK_CODE = \'TOD50_1\' ) AS CT   ON cfp.DELIVERY_NO = CT.DELIVERY_NO WHERE   cfp.TRK_DATE > CT.TRK_DATE   AND cfp.TRK_NM IN (     \'(D2C) Address not found\',     \'(D2C) Closed business\',     \'(D2C) Customer absence\',     \'(D2C) Customer absence (E-Store)\',     \'(D2C) Customer changed address\',     \'(D2C) Blocked road\',     \'(D2C) Natural disaster\',     \'(D2C) Delivery location restrictions\',     \'(D2C) Local holidays\',     \'(D2C) Strike\',     \'(D2C) Cancel requested by OST/CS teams\',     \'(D2C) Purchase canceled by customers\',     \'(D2C) Refused by customer\'   )'

CREATE VIEW "OW_SEDA_S_LOGISTIC"."VW_MACHINE_LEARNING_CELLO_FP_PT1" (
  "DELIVERY_NO",
  "TRK_CODE",
  "PARTNER_ID",
  "EVENT_DESC",
  "TRK_DATE"
) AS
SELECT
  cfp.DELIVERY_NO,
  cfp.TRK_CODE,
  CT.PARTNER_ID,
  cfp.TRK_NM AS EVENT_DESC,
  cfp.TRK_DATE
FROM OW_SEDA_S.CELLO_FUTHER_PROCESSING AS cfp
LEFT JOIN (
  SELECT
    DELIVERY_NO,
    TRK_CODE,
    PARTNER_ID,
    TRK_DATE
  FROM OW_SEDA_S_LOGISTIC.ST_MACHINE_LEARNING_CELLO_TRK_PT1 AS CT
  WHERE
    TRK_CODE = 'TOD50_1'
) AS CT
  ON cfp.DELIVERY_NO = CT.DELIVERY_NO
WHERE
  cfp.TRK_DATE > CT.TRK_DATE
  AND cfp.TRK_NM IN (
    '(D2C) Address not found',
    '(D2C) Closed business',
    '(D2C) Customer absence',
    '(D2C) Customer absence (E-Store)',
    '(D2C) Customer changed address',
    '(D2C) Blocked road',
    '(D2C) Natural disaster',
    '(D2C) Delivery location restrictions',
    '(D2C) Local holidays',
    '(D2C) Strike',
    '(D2C) Cancel requested by OST/CS teams',
    '(D2C) Purchase canceled by customers',
    '(D2C) Refused by customer'
  )