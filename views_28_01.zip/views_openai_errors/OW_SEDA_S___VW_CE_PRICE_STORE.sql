-- ERROR: Error executing query: Severity: ERROR, Message: Insufficient resources to execute plan on pool general [Request Too Large:Memory(KB) Exceeded: Requested = 66730935, Free = 54733130 (Limit = 54733130, Used = 0)], Sqlstate: 53000, Routine: Exec_compilePlan, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Miner/server/vertica/Dist/PlanExecCoordinator.cpp, Line: 3031, Error Code: 3587, SQL: 'SELECT * FROM "OW_SEDA_S"."VW_CE_PRICE_STORE" LIMIT 10;'

CREATE VIEW "OW_SEDA_S"."VW_CE_PRICE_STORE" (
  "EXECUTION DATE",
  "EXECUTION TIME",
  "SITE ID",
  "CATEGORY",
  "ITEM",
  "SPOT PRICE",
  "INSTALLMENT PRICE",
  "BRAND",
  "TYPE",
  "TECHNOLOGY",
  "CURVED",
  "INCH",
  "WATTS",
  "WEEKNUM",
  "STATUS",
  "MANAGER_NAME",
  "OBSERVATION",
  "CYCLE_GROUP",
  "FLOORSHARE",
  "FLOORSHARE_CHECK",
  "LOCATION",
  "FOTO_AMPLA",
  "EXPOSTO_NA_ENTRADA_DA_LOJA",
  "SYSTEM_PRICE_MODE",
  "MODE_COUNT"
) AS
SELECT
  "FPS"."EXECUTION DATE",
  "FPS"."EXECUTION TIME",
  "FPS"."SITE ID",
  "FPS"."CATEGORY",
  "FPS"."ITEM",
  "FPS"."SPOT PRICE",
  "FPS"."INSTALLMENT PRICE",
  "FPS"."BRAND",
  "FPS"."TYPE",
  "FPS"."TECHNOLOGY",
  "FPS"."CURVED",
  "FPS"."INCH",
  "FPS"."WATTS",
  "FPS"."WEEKNUM",
  "TMP"."STATUS",
  "TMP"."MANAGER_NAME",
  "TMP"."OBSERVATION",
  cy.CYCLE_GROUP,
  fs.floorshare,
  fs.floorshare_check,
  "FPS".LOCATION,
  "FPS".FOTO_AMPLA,
  FPS.EXPOSTO_NA_ENTRADA_DA_LOJA,
  vtsp.PRICE AS SYSTEM_PRICE_MODE,
  vtsp.mode_count
FROM OW_SEDA_S.FT_CE_PRICE_STORE AS fps
LEFT JOIN (
  SELECT DISTINCT
    CODE,
    LEFT((RIGHT("CYCLE", 5))::VARCHAR, 4) || RIGHT(LEFT(("CYCLE")::VARCHAR, 3), 2) AS WEEKNUM,
    STATUS,
    MANAGER_NAME,
    OBSERVATION
  FROM OW_SEDA_S.ODS_TT_VISITS
) AS tmp
  ON 1 = 1 AND fps."SITE ID" = tmp.code AND fps.WEEKNUM = tmp.WEEKNUM
LEFT JOIN (
  SELECT DISTINCT
    CYCLE AS CYCLE_GROUP,
    CASE
      WHEN RIGHT(LEFT(("CYCLE")::VARCHAR, 6), 1) = '-'
      THEN LEFT(("CYCLE")::VARCHAR, 4) || '0' || RIGHT(LEFT(("CYCLE")::VARCHAR, 5), 1)
      ELSE LEFT(("CYCLE")::VARCHAR, 6)
    END AS weeknum_init,
    CASE
      WHEN LEFT((RIGHT("CYCLE", 2))::VARCHAR, 1) = '-'
      THEN LEFT(("CYCLE")::VARCHAR, 4) || '0' || RIGHT("CYCLE", 1)
      ELSE LEFT(("CYCLE")::VARCHAR, 4) || RIGHT("CYCLE", 2)
    END AS weeknum_final
  FROM OW_SEDA_S.ODS_TT_PERFECT_STORE_V3
  WHERE
    NOT CYCLE IS NULL
  UNION ALL
  SELECT
    '202329-30',
    '202329',
    '202330'
  FROM dual AS d
  WHERE
    NOT EXISTS(
      SELECT
        1
      FROM OW_SEDA_S.ODS_TT_PERFECT_STORE_V3 AS p
      WHERE
        '202329-30' = p."CYCLE"
    )
  UNION ALL
  SELECT
    '202331-32',
    '202331',
    '202332'
  FROM dual AS d
  WHERE
    NOT EXISTS(
      SELECT
        1
      FROM OW_SEDA_S.ODS_TT_PERFECT_STORE_V3 AS p
      WHERE
        '202331-32' = p."CYCLE"
    )
  UNION ALL
  SELECT
    '202333-34',
    '202333',
    '202334'
  FROM dual AS d
  WHERE
    NOT EXISTS(
      SELECT
        1
      FROM OW_SEDA_S.ODS_TT_PERFECT_STORE_V3 AS p
      WHERE
        '202333-34' = p."CYCLE"
    )
  UNION ALL
  SELECT
    '202335-36',
    '202335',
    '202336'
  FROM dual AS d
  WHERE
    NOT EXISTS(
      SELECT
        1
      FROM OW_SEDA_S.ODS_TT_PERFECT_STORE_V3 AS p
      WHERE
        '202335-36' = p."CYCLE"
    )
  UNION ALL
  SELECT
    '202337-38',
    '202337',
    '202338'
  FROM dual AS d
  WHERE
    NOT EXISTS(
      SELECT
        1
      FROM OW_SEDA_S.ODS_TT_PERFECT_STORE_V3 AS p
      WHERE
        '202337-38' = p."CYCLE"
    )
  UNION ALL
  SELECT
    '202339-40',
    '202339',
    '202340'
  FROM dual AS d
  WHERE
    NOT EXISTS(
      SELECT
        1
      FROM OW_SEDA_S.ODS_TT_PERFECT_STORE_V3 AS p
      WHERE
        '202339-40' = p."CYCLE"
    )
  UNION ALL
  SELECT
    '202341-42',
    '202341',
    '202342'
  FROM dual AS d
  WHERE
    NOT EXISTS(
      SELECT
        1
      FROM OW_SEDA_S.ODS_TT_PERFECT_STORE_V3 AS p
      WHERE
        '202341-42' = p."CYCLE"
    )
  UNION ALL
  SELECT
    '202343-44',
    '202343',
    '202344'
  FROM dual AS d
  WHERE
    NOT EXISTS(
      SELECT
        1
      FROM OW_SEDA_S.ODS_TT_PERFECT_STORE_V3 AS p
      WHERE
        '202343-44' = p."CYCLE"
    )
  UNION ALL
  SELECT
    '202345-46',
    '202345',
    '202346'
  FROM dual AS d
  WHERE
    NOT EXISTS(
      SELECT
        1
      FROM OW_SEDA_S.ODS_TT_PERFECT_STORE_V3 AS p
      WHERE
        '202345-46' = p."CYCLE"
    )
  UNION ALL
  SELECT
    '202347-48',
    '202347',
    '202348'
  FROM dual AS d
  WHERE
    NOT EXISTS(
      SELECT
        1
      FROM OW_SEDA_S.ODS_TT_PERFECT_STORE_V3 AS p
      WHERE
        '202347-48' = p."CYCLE"
    )
  UNION ALL
  SELECT
    '202349-50',
    '202349',
    '202350'
  FROM dual AS d
  WHERE
    NOT EXISTS(
      SELECT
        1
      FROM OW_SEDA_S.ODS_TT_PERFECT_STORE_V3 AS p
      WHERE
        '202349-50' = p."CYCLE"
    )
  UNION ALL
  SELECT
    '202351-52',
    '202351',
    '202352'
  FROM dual AS d
  WHERE
    NOT EXISTS(
      SELECT
        1
      FROM OW_SEDA_S.ODS_TT_PERFECT_STORE_V3 AS p
      WHERE
        '202351-52' = p."CYCLE"
    )
) AS cy
  ON 1 = 1 AND fps.WEEKNUM >= cy.weeknum_init AND fps.WEEKNUM <= cy.weeknum_final
LEFT JOIN (
  SELECT
    WEEKNUM,
    "SITE ID",
    COUNT(CASE WHEN BRAND = 'SAMSUNG' THEN ITEM END) / COUNT(ITEM) AS floorshare,
    CASE
      WHEN COUNT(CASE WHEN BRAND = 'SAMSUNG' THEN ITEM END) / COUNT(ITEM) >= 0.8
      THEN 1
      ELSE 0
    END AS floorshare_check
  FROM OW_SEDA_S.FT_CE_PRICE_STORE AS fps
  GROUP BY
    WEEKNUM,
    "SITE ID"
) AS fs
  ON 1 = 1 AND fps."SITE ID" = fs."SITE ID" AND fps.WEEKNUM = fs.weeknum
LEFT JOIN OW_SEDA_S.MAP_CE_STORES AS mcs
  ON mcs.SITE_ID = fps."SITE ID"
LEFT JOIN OW_SEDA_S.VW_TT_SYSTEM_PRICES_MODE AS vtsp
  ON 1 = 1
  AND vtsp.WEEKNUM = fps.WEEKNUM
  AND vtsp.ITEM = fps.ITEM
  AND vtsp.ACCOUNT = CASE
    WHEN mcs.ACCOUNT_2022 LIKE 'REGIONAL%'
    THEN mcs.CHANNEL
    ELSE mcs.ACCOUNT_2022
  END