-- MISSING RELATION: OW_SEDA_S.ods_sb_coop_share
-- ERROR: Error executing query: Severity: ERROR, Message: Relation "OW_SEDA_S.ods_sb_coop_share" does not exist, Sqlstate: 42V01, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Miner/server/vertica/Catalog/CatalogLookup.cpp, Line: 4362, Error Code: 4568, SQL: 'CREATE OR REPLACE VIEW "OW_SEDA_S"."VW_CE_ACCOUNT_MANAGEMENT_COMPLETE" (   "DIVISION_DESCRIPTION",   "YEAR",   "CENSO",   "ITEM",   "NET_SALES_QTY",   "NET_SALES_BRL",   "CP_OPERATIONAL_USD",   "DEALER_DISCOUNT",   "SALES_DEDUCTION_TOTAL",   "S_RRP",   "GROSS_SALES_BRL",   "DEALER_DISCOUNT_PERC",   "SALES_DEDUCTION_TOTAL_PERC",   "TIM_PERC",   "NET_SALES_QTY_LAST_YEAR",   "NET_SALES_BRL_LAST_YEAR",   "CP_OPERATIONAL_USD_LAST_YEAR",   "DEALER_DISCOUNT_LAST_YEAR",   "SALES_DEDUCTION_TOTAL_LAST_YEAR",   "S_RRP_LAST_YEAR",   "GROSS_SALES_BRL_LAST_YEAR",   "DEALER_DISCOUNT_LAST_YEAR_PERC",   "SALES_DEDUCTION_TOTAL_LAST_YEAR_PERC",   "TIM_LAST_YEAR_PERC",   "NET_SALES_QTY_GROWTH",   "NET_SALES_BRL_GROWTH",   "CP_OPERATIONAL_USD_GROWTH",   "TIM_PERC_GROWTH",   "NET_SALES_QTY_GROWTH_AVG_SEDA",   "NET_SALES_BRL_GROWTH_AVG_SEDA",   "CP_OPERATIONAL_USD_GROWTH_AVG_SEDA",   "TIM_PERC_GROWTH_AVG_SEDA",   "NET_SALES_QTY_PORTION",   "NET_SALES_BRL_PORTION",   "CP_OPERATIONAL_USD_PORTION",   "NET_SALES_QTY_LAST_YEAR_PORTION",   "NET_SALES_BRL_LAST_YEAR_PORTION",   "CP_OPERATIONAL_USD_LAST_YEAR_PORTION",   "NET_SALES_QTY_PORTION_AVG_SEDA",   "NET_SALES_BRL_PORTION_AVG_SEDA",   "CP_OPERATIONAL_USD_PORTION_AVG_SEDA",   "NET_SALES_QTY_LAST_YEAR_PORTION_AVG_SEDA",   "NET_SALES_BRL_LAST_YEAR_PORTION_AVG_SEDA",   "CP_OPERATIONAL_USD_LAST_YEAR_PORTION_AVG_SEDA",   "NET_SALES_BRL_SEDA",   "NET_SALES_BRL_LAST_YEAR_SEDA",   "NET_SALES_BRL_TOTAL",   "NET_SALES_BRL_LAST_YEAR_TOTAL",   "CP_OPERATIONAL_USD_SEDA",   "CP_OPERATIONAL_USD_LAST_YEAR_SEDA",   "NET_SALES_BRL_SEDA_GROWTH",   "NET_SALES_PORTION_SEDA_GROWTH",   "CP_OPERATIONAL_USD_SEDA_GROWTH",   "CP_OPERATIONAL_PORTION_SEDA_GROWTH",   "SEDA_TIM_PERC",   "SEDA_TIM_PERC_LAST_YEAR",   "SEDA_TIM_PERC_DIFF",   "MAX_FLOORING",   "MAX_YEARWEEK",   "AVG_FLOORING",   "SELL_OUT",   "RUN_RATE",   "FLOORING_TARGET",   "SELL_OUT_TARGET",   "RUN_RATE_TARGET",   "FLOORSHARE_TOTAL",   "FLOORSHARE_SOUNDBAR",   "FLOORSHARE_55_AND_ABOVE",   "FLOORSHARE_75_AND_ABOVE",   "Q80+_vs_OLED",   "COOP_SHARE_TOTAL",   "COOP_SHARE_50+",   "COOP_SHARE_65+",   "SELL_OUT_QTY",   "IN_HOUSE_SHARE",   "SELL_OUT_AMT",   "WEEKNUM_IN_HOUSE_SHARE",   "Y0_REF",   "Y_1_REF" ) AS SELECT   "TB1"."DIVISION_DESCRIPTION",   "TB1"."YEAR",   "TB1"."CENSO",   "TB1"."ITEM",   "TB1"."NET_SALES_QTY",   "TB1"."NET_SALES_BRL",   "TB1"."CP_OPERATIONAL_USD",   "TB1"."DEALER_DISCOUNT",   "TB1"."SALES_DEDUCTION_TOTAL",   "TB1"."S_RRP",   "TB1"."GROSS_SALES_BRL",   "TB1"."DEALER_DISCOUNT_PERC",   "TB1"."SALES_DEDUCTION_TOTAL_PERC",   "TB1"."TIM_PERC",   "TB1"."NET_SALES_QTY_LAST_YEAR",   "TB1"."NET_SALES_BRL_LAST_YEAR",   "TB1"."CP_OPERATIONAL_USD_LAST_YEAR",   "TB1"."DEALER_DISCOUNT_LAST_YEAR",   "TB1"."SALES_DEDUCTION_TOTAL_LAST_YEAR",   "TB1"."S_RRP_LAST_YEAR",   "TB1"."GROSS_SALES_BRL_LAST_YEAR",   "TB1"."DEALER_DISCOUNT_LAST_YEAR_PERC",   "TB1"."SALES_DEDUCTION_TOTAL_LAST_YEAR_PERC",   "TB1"."TIM_LAST_YEAR_PERC",   "TB1"."NET_SALES_QTY_GROWTH",   "TB1"."NET_SALES_BRL_GROWTH",   "TB1"."CP_OPERATIONAL_USD_GROWTH",   "TB1"."TIM_PERC_GROWTH",   "TB1"."NET_SALES_QTY_GROWTH_AVG_SEDA",   "TB1"."NET_SALES_BRL_GROWTH_AVG_SEDA",   "TB1"."CP_OPERATIONAL_USD_GROWTH_AVG_SEDA",   "TB1"."TIM_PERC_GROWTH_AVG_SEDA",   "TB1"."NET_SALES_QTY_PORTION",   "TB1"."NET_SALES_BRL_PORTION",   "TB1"."CP_OPERATIONAL_USD_PORTION",   "TB1"."NET_SALES_QTY_LAST_YEAR_PORTION",   "TB1"."NET_SALES_BRL_LAST_YEAR_PORTION",   "TB1"."CP_OPERATIONAL_USD_LAST_YEAR_PORTION",   "TB1"."NET_SALES_QTY_PORTION_AVG_SEDA",   "TB1"."NET_SALES_BRL_PORTION_AVG_SEDA",   "TB1"."CP_OPERATIONAL_USD_PORTION_AVG_SEDA",   "TB1"."NET_SALES_QTY_LAST_YEAR_PORTION_AVG_SEDA",   "TB1"."NET_SALES_BRL_LAST_YEAR_PORTION_AVG_SEDA",   "TB1"."CP_OPERATIONAL_USD_LAST_YEAR_PORTION_AVG_SEDA",   "TB1"."NET_SALES_BRL_SEDA",   "TB1"."NET_SALES_BRL_LAST_YEAR_SEDA",   "TB1"."NET_SALES_BRL_TOTAL",   "TB1"."NET_SALES_BRL_LAST_YEAR_TOTAL",   "TB1"."CP_OPERATIONAL_USD_SEDA",   "TB1"."CP_OPERATIONAL_USD_LAST_YEAR_SEDA",   "TB1"."NET_SALES_BRL_SEDA_GROWTH",   "TB1"."NET_SALES_PORTION_SEDA_GROWTH",   "TB1"."CP_OPERATIONAL_USD_SEDA_GROWTH",   "TB1"."CP_OPERATIONAL_PORTION_SEDA_GROWTH",   TB1.seda_tim_perc,   TB1.seda_tim_perc_last_year,   TB1.seda_tim_perc_diff,   "TB1"."MAX_FLOORING",   "TB1"."MAX_YEARWEEK",   "TB1"."AVG_FLOORING",   "TB1"."SELL_OUT",   "TB1"."RUN_RATE",   "TB1"."FLOORING_TARGET",   "TB1"."SELL_OUT_TARGET",   "TB1"."RUN_RATE_TARGET",   "TB1"."FLOORSHARE_TOTAL",   "TB1"."FLOORSHARE_SOUNDBAR",   "TB1"."FLOORSHARE_55_AND_ABOVE",   "TB1"."FLOORSHARE_75_AND_ABOVE",   "TB1"."Q80+_vs_OLED",   "TB1"."COOP_SHARE_TOTAL",   "TB1"."COOP_SHARE_50+",   "TB1"."COOP_SHARE_65+",   "TB1"."SELL_OUT_QTY",   "TB1"."IN_HOUSE_SHARE",   "TB1"."SELL_OUT_AMT",   "TB1"."WEEKNUM_IN_HOUSE_SHARE",   "TB2"."Y0_REF",   "TB2"."Y_1_REF" FROM (   SELECT DISTINCT     \'AV\' AS division_description,     COALESCE(tb1.year, tb2.year) AS year,     COALESCE(tb1.censo, tb2.censo) AS censo,     COALESCE(tb1.item, tb2.item) AS item,     net_sales_qty,     net_sales_brl,     cp_operational_usd,     dealer_discount,     sales_deduction_total,     s_rrp,     gross_sales_brl,     dealer_discount_perc,     sales_deduction_total_perc,     tim_perc,     net_sales_qty_last_year,     net_sales_brl_last_year,     cp_operational_usd_last_year,     dealer_discount_last_year,     sales_deduction_total_last_year,     s_rrp_last_year,     gross_sales_brl_last_year,     dealer_discount_last_year_perc,     sales_deduction_total_last_year_perc,     tim_last_year_perc,     net_sales_qty_growth,     net_sales_brl_growth,     CASE       WHEN CASE         WHEN cp_operational_usd_last_year <> 0         THEN cp_operational_usd / cp_operational_usd_last_year       END < 0       THEN 0       ELSE cp_operational_usd_growth     END AS cp_operational_usd_growth,     tim_perc_growth,     net_sales_qty_growth_avg_seda,     net_sales_brl_growth_avg_seda,     cp_operational_usd_growth_avg_seda,     tim_perc_growth_avg_seda,     NET_SALES_QTY_PORTION,     NET_SALES_BRL_PORTION,     CASE WHEN net_sales_brl <> 0 THEN cp_operational_usd / net_sales_usd END AS cp_operational_usd_portion,     NET_SALES_QTY_LAST_YEAR_PORTION,     NET_SALES_BRL_LAST_YEAR_PORTION,     CASE       WHEN net_sales_brl_last_year <> 0       THEN cp_operational_usd_last_year / net_sales_usd_last_year     END AS cp_operational_usd_last_year_portion,     NET_SALES_QTY_PORTION_AVG_SEDA,     NET_SALES_BRL_PORTION_AVG_SEDA,     cp_operational_usd_portion_AVG_SEDA,     NET_SALES_QTY_LAST_YEAR_PORTION_AVG_SEDA,     NET_SALES_BRL_LAST_YEAR_PORTION_AVG_SEDA,     cp_operational_usd_last_year_portion_AVG_SEDA,     net_sales_brl_seda,     net_sales_brl_last_year_seda,     net_sales_brl_total,     net_sales_brl_last_year_total,     cp_operational_usd_seda,     cp_operational_usd_last_year_seda,     net_sales_brl_seda_growth,     net_sales_portion_seda_growth,     cp_operational_usd_seda_growth,     cp_operational_portion_seda_growth,     seda_tim_perc,     seda_tim_perc_last_year,     seda_tim_perc_diff,     MAX_FLOORING,     max_yearweek,     AVG_FLOORING,     SELL_OUT,     RUN_RATE,     FLOORING_TARGET,     SELL_OUT_TARGET,     RUN_RATE_TARGET,     0 AS floorshare_total,     0 AS floorshare_soundbar,     0 AS floorshare_55_and_above,     0 AS floorshare_75_and_above,     0 AS "Q80+_vs_OLED",     0 AS COOP_SHARE_TOTAL,     0 AS "COOP_SHARE_50+",     0 AS "COOP_SHARE_65+",     0 AS sell_out_qty,     0 AS in_house_share,     0 AS sell_out_amt,     0 AS weeknum_in_house_share   FROM OW_SEDA_S.vw_ce_account_management AS tb1   FULL JOIN (     SELECT       *     FROM OW_SEDA_S.vw_ce_account_management_flooring     WHERE       NOT censo IS NULL   ) AS tb2     ON 1 = 1 AND tb1.censo = tb2.censo AND tb1.item = tb2.item AND tb1.year = tb2.year   UNION ALL   SELECT     \'AV\',     2022,     CENSO,     \'Floorshare\',     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     floorshare_total,     floorshare_soundbar,     floorshare_55_and_above,     floorshare_75_and_above,     "Q80+_vs_OLED",     NULL AS COOP_SHARE_TOTAL,     NULL AS "COOP_SHARE_50+",     NULL AS "COOP_SHARE_65+",     0 AS sell_out_qty,     0 AS in_house_share,     0 AS sell_out_amt,     0 AS weeknum_in_house_share   FROM OW_SEDA_S.account_management_floorshre_tt   UNION ALL   SELECT     \'AV\' AS division_description,     2022 AS year,     censo,     \'COOP SHARE\' AS item,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     COALESCE(QTY / SUM(QTY) OVER (), 0) AS COOP_SHARE_TOTAL,     COALESCE(QTY_50 / SUM(QTY_50) OVER (), 0) AS "COOP_SHARE_50+",     COALESCE(QTY_65 / SUM(QTY_65) OVER (), 0) AS "COOP_SHARE_65+",     0 AS sell_out_qty,     0 AS in_house_share,     0 AS sell_out_amt,     0 AS weeknum_in_house_share   FROM (     SELECT       CASE         WHEN LOJA = \'ANGELONI\'         THEN \'Angeloni\'         WHEN LOJA = \'SHOPTIME.COM\'         THEN \'B2W\'         WHEN LOJA = \'BIG\'         THEN \'Wal Mart\'         WHEN LOJA = \'BIG BOMPRECO\'         THEN \'Wal Mart\'         WHEN LOJA = \'CARREFOUR\'         THEN \'Carrefour\'         WHEN LOJA = \'EXTRA HIPER\'         THEN \'CBD\'         WHEN LOJA = \'ELETRO MATEUS\'         THEN \'Armazem Mateus\'         WHEN LOJA = \'FAST SHOP\'         THEN \'Fast\'         WHEN LOJA = \'FORMOSA MIX\'         THEN \'Formosa\'         WHEN LOJA = \'FUJIOKA\'         THEN \'Fujioka\'         WHEN LOJA = \'G BARBOSA\'         THEN \'G Barbosa\'         WHEN LOJA = \'GAZIN\'         THEN \'Gazin\'         WHEN LOJA = \'HAVAN\'         THEN \'Havan\'         WHEN LOJA = \'IMPERIO MOVEIS\'         THEN \'Imperio dos Eletros\'         WHEN LOJA = \'KOERICH\'         THEN \'Koerich\'         WHEN LOJA = \'AMERICANAS\'         THEN \'LASA\'         WHEN LOJA = \'LASER ELETRO\'         THEN \'Laser Eletro\'         WHEN LOJA = \'LILIANI\'         THEN \'Liliani\'         WHEN LOJA = \'LOJAS CEM\'         THEN \'Lojas Cem\'         WHEN LOJA = \'LOJAS COLOMBO\'         THEN \'Lojas Colombo\'         WHEN LOJA = \'LOJAS LEBES\'         THEN \'Lebes\'         WHEN LOJA = \'MAGAZINE LUIZA\'         THEN \'Magazine Luiza\'         WHEN LOJA = \'NAGEM\'         THEN \'Nagem\'         WHEN LOJA = \'NOVO MUNDO\'         THEN \'Novo Mundo\'         WHEN LOJA = \'TAQI\'         THEN \'TAQI\'         WHEN LOJA = \'CASAS BAHIA\'         THEN \'Via Varejo\'         WHEN LOJA = \'PONTO\'         THEN \'Via Varejo\'         WHEN LOJA = \'MILLENA MOVEIS\'         THEN \'Millena Moveis\'       END AS censo,       SUM(QTY) AS QTY,       SUM(CASE WHEN INCH IN (\'46-54\', \'55"\', \'58-60\', \'65-70\', \'75"\') THEN QTY END) AS QTY_50,       SUM(CASE WHEN INCH IN (\'65-70\', \'75"\') THEN QTY END) AS QTY_65     FROM OW_SEDA_S.ods_sb_coop_share     WHERE       1 = 1 AND sheetname = \'Dados_TV_Shop Brasil_2022\'     GROUP BY       CASE         WHEN LOJA = \'ANGELONI\'         THEN \'Angeloni\'         WHEN LOJA = \'SHOPTIME.COM\'         THEN \'B2W\'         WHEN LOJA = \'BIG\'         THEN \'Wal Mart\'         WHEN LOJA = \'BIG BOMPRECO\'         THEN \'Wal Mart\'         WHEN LOJA = \'CARREFOUR\'         THEN \'Carrefour\'         WHEN LOJA = \'EXTRA HIPER\'         THEN \'CBD\'         WHEN LOJA = \'ELETRO MATEUS\'         THEN \'Armazem Mateus\'         WHEN LOJA = \'FAST SHOP\'         THEN \'Fast\'         WHEN LOJA = \'FORMOSA MIX\'         THEN \'Formosa\'         WHEN LOJA = \'FUJIOKA\'         THEN \'Fujioka\'         WHEN LOJA = \'G BARBOSA\'         THEN \'G Barbosa\'         WHEN LOJA = \'GAZIN\'         THEN \'Gazin\'         WHEN LOJA = \'HAVAN\'         THEN \'Havan\'         WHEN LOJA = \'IMPERIO MOVEIS\'         THEN \'Imperio dos Eletros\'         WHEN LOJA = \'KOERICH\'         THEN \'Koerich\'         WHEN LOJA = \'AMERICANAS\'         THEN \'LASA\'         WHEN LOJA = \'LASER ELETRO\'         THEN \'Laser Eletro\'         WHEN LOJA = \'LILIANI\'         THEN \'Liliani\'         WHEN LOJA = \'LOJAS CEM\'         THEN \'Lojas Cem\'         WHEN LOJA = \'LOJAS COLOMBO\'         THEN \'Lojas Colombo\'         WHEN LOJA = \'LOJAS LEBES\'         THEN \'Lebes\'         WHEN LOJA = \'MAGAZINE LUIZA\'         THEN \'Magazine Luiza\'         WHEN LOJA = \'NAGEM\'         THEN \'Nagem\'         WHEN LOJA = \'NOVO MUNDO\'         THEN \'Novo Mundo\'         WHEN LOJA = \'TAQI\'         THEN \'TAQI\'         WHEN LOJA = \'CASAS BAHIA\'         THEN \'Via Varejo\'         WHEN LOJA = \'PONTO\'         THEN \'Via Varejo\'         WHEN LOJA = \'MILLENA MOVEIS\'         THEN \'Millena Moveis\'       END   ) AS subq_7056   UNION ALL   SELECT     \'AV\' AS division_description,     YEAR(LEFT((weeknum)::VARCHAR, 4)) AS YEAR,     CASE WHEN account = \'Fast Shop\' THEN \'Fast\' ELSE account END AS censo,     \'In House Share - \' || store_type || \' - \' || category AS item,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     NULL,     sell_out_qty,     in_house_share,     sell_out_amt,     weeknum AS weeknum_in_house_share   FROM OW_SEDA_S.ODS_CE_KAM_IN_HOUSE_SHARE AS okihs   WHERE     EXISTS(       SELECT         1       FROM (         SELECT           account,           MAX(weeknum) AS mw         FROM OW_SEDA_S.ODS_CE_KAM_IN_HOUSE_SHARE         GROUP BY           ACCOUNT       ) AS t       WHERE         okihs.account = t.account AND okihs.weeknum = t.mw     ) ) AS tb1 LEFT JOIN (   SELECT     LEFT((spmon)::VARCHAR, 4) AS year,     MIN(spmon) || \' - \' || MAX(spmon) AS y0_ref,     LEFT((spmon)::VARCHAR, 4) - 1 || RIGHT(MIN(spmon), 4) || \' - \' || LEFT((spmon)::VARCHAR, 4) - 1 || RIGHT(MAX(spmon), 4) AS y_1_ref   FROM u_d_takeshi.vw_ce_informacoes_gerenciais   GROUP BY     LEFT((spmon)::VARCHAR, 4) ) AS tb2   ON tb1.year = tb2.YEAR'

CREATE VIEW "OW_SEDA_S"."VW_CE_ACCOUNT_MANAGEMENT_COMPLETE" (
  "DIVISION_DESCRIPTION",
  "YEAR",
  "CENSO",
  "ITEM",
  "NET_SALES_QTY",
  "NET_SALES_BRL",
  "CP_OPERATIONAL_USD",
  "DEALER_DISCOUNT",
  "SALES_DEDUCTION_TOTAL",
  "S_RRP",
  "GROSS_SALES_BRL",
  "DEALER_DISCOUNT_PERC",
  "SALES_DEDUCTION_TOTAL_PERC",
  "TIM_PERC",
  "NET_SALES_QTY_LAST_YEAR",
  "NET_SALES_BRL_LAST_YEAR",
  "CP_OPERATIONAL_USD_LAST_YEAR",
  "DEALER_DISCOUNT_LAST_YEAR",
  "SALES_DEDUCTION_TOTAL_LAST_YEAR",
  "S_RRP_LAST_YEAR",
  "GROSS_SALES_BRL_LAST_YEAR",
  "DEALER_DISCOUNT_LAST_YEAR_PERC",
  "SALES_DEDUCTION_TOTAL_LAST_YEAR_PERC",
  "TIM_LAST_YEAR_PERC",
  "NET_SALES_QTY_GROWTH",
  "NET_SALES_BRL_GROWTH",
  "CP_OPERATIONAL_USD_GROWTH",
  "TIM_PERC_GROWTH",
  "NET_SALES_QTY_GROWTH_AVG_SEDA",
  "NET_SALES_BRL_GROWTH_AVG_SEDA",
  "CP_OPERATIONAL_USD_GROWTH_AVG_SEDA",
  "TIM_PERC_GROWTH_AVG_SEDA",
  "NET_SALES_QTY_PORTION",
  "NET_SALES_BRL_PORTION",
  "CP_OPERATIONAL_USD_PORTION",
  "NET_SALES_QTY_LAST_YEAR_PORTION",
  "NET_SALES_BRL_LAST_YEAR_PORTION",
  "CP_OPERATIONAL_USD_LAST_YEAR_PORTION",
  "NET_SALES_QTY_PORTION_AVG_SEDA",
  "NET_SALES_BRL_PORTION_AVG_SEDA",
  "CP_OPERATIONAL_USD_PORTION_AVG_SEDA",
  "NET_SALES_QTY_LAST_YEAR_PORTION_AVG_SEDA",
  "NET_SALES_BRL_LAST_YEAR_PORTION_AVG_SEDA",
  "CP_OPERATIONAL_USD_LAST_YEAR_PORTION_AVG_SEDA",
  "NET_SALES_BRL_SEDA",
  "NET_SALES_BRL_LAST_YEAR_SEDA",
  "NET_SALES_BRL_TOTAL",
  "NET_SALES_BRL_LAST_YEAR_TOTAL",
  "CP_OPERATIONAL_USD_SEDA",
  "CP_OPERATIONAL_USD_LAST_YEAR_SEDA",
  "NET_SALES_BRL_SEDA_GROWTH",
  "NET_SALES_PORTION_SEDA_GROWTH",
  "CP_OPERATIONAL_USD_SEDA_GROWTH",
  "CP_OPERATIONAL_PORTION_SEDA_GROWTH",
  "SEDA_TIM_PERC",
  "SEDA_TIM_PERC_LAST_YEAR",
  "SEDA_TIM_PERC_DIFF",
  "MAX_FLOORING",
  "MAX_YEARWEEK",
  "AVG_FLOORING",
  "SELL_OUT",
  "RUN_RATE",
  "FLOORING_TARGET",
  "SELL_OUT_TARGET",
  "RUN_RATE_TARGET",
  "FLOORSHARE_TOTAL",
  "FLOORSHARE_SOUNDBAR",
  "FLOORSHARE_55_AND_ABOVE",
  "FLOORSHARE_75_AND_ABOVE",
  "Q80+_vs_OLED",
  "COOP_SHARE_TOTAL",
  "COOP_SHARE_50+",
  "COOP_SHARE_65+",
  "SELL_OUT_QTY",
  "IN_HOUSE_SHARE",
  "SELL_OUT_AMT",
  "WEEKNUM_IN_HOUSE_SHARE",
  "Y0_REF",
  "Y_1_REF"
) AS
SELECT
  "TB1"."DIVISION_DESCRIPTION",
  "TB1"."YEAR",
  "TB1"."CENSO",
  "TB1"."ITEM",
  "TB1"."NET_SALES_QTY",
  "TB1"."NET_SALES_BRL",
  "TB1"."CP_OPERATIONAL_USD",
  "TB1"."DEALER_DISCOUNT",
  "TB1"."SALES_DEDUCTION_TOTAL",
  "TB1"."S_RRP",
  "TB1"."GROSS_SALES_BRL",
  "TB1"."DEALER_DISCOUNT_PERC",
  "TB1"."SALES_DEDUCTION_TOTAL_PERC",
  "TB1"."TIM_PERC",
  "TB1"."NET_SALES_QTY_LAST_YEAR",
  "TB1"."NET_SALES_BRL_LAST_YEAR",
  "TB1"."CP_OPERATIONAL_USD_LAST_YEAR",
  "TB1"."DEALER_DISCOUNT_LAST_YEAR",
  "TB1"."SALES_DEDUCTION_TOTAL_LAST_YEAR",
  "TB1"."S_RRP_LAST_YEAR",
  "TB1"."GROSS_SALES_BRL_LAST_YEAR",
  "TB1"."DEALER_DISCOUNT_LAST_YEAR_PERC",
  "TB1"."SALES_DEDUCTION_TOTAL_LAST_YEAR_PERC",
  "TB1"."TIM_LAST_YEAR_PERC",
  "TB1"."NET_SALES_QTY_GROWTH",
  "TB1"."NET_SALES_BRL_GROWTH",
  "TB1"."CP_OPERATIONAL_USD_GROWTH",
  "TB1"."TIM_PERC_GROWTH",
  "TB1"."NET_SALES_QTY_GROWTH_AVG_SEDA",
  "TB1"."NET_SALES_BRL_GROWTH_AVG_SEDA",
  "TB1"."CP_OPERATIONAL_USD_GROWTH_AVG_SEDA",
  "TB1"."TIM_PERC_GROWTH_AVG_SEDA",
  "TB1"."NET_SALES_QTY_PORTION",
  "TB1"."NET_SALES_BRL_PORTION",
  "TB1"."CP_OPERATIONAL_USD_PORTION",
  "TB1"."NET_SALES_QTY_LAST_YEAR_PORTION",
  "TB1"."NET_SALES_BRL_LAST_YEAR_PORTION",
  "TB1"."CP_OPERATIONAL_USD_LAST_YEAR_PORTION",
  "TB1"."NET_SALES_QTY_PORTION_AVG_SEDA",
  "TB1"."NET_SALES_BRL_PORTION_AVG_SEDA",
  "TB1"."CP_OPERATIONAL_USD_PORTION_AVG_SEDA",
  "TB1"."NET_SALES_QTY_LAST_YEAR_PORTION_AVG_SEDA",
  "TB1"."NET_SALES_BRL_LAST_YEAR_PORTION_AVG_SEDA",
  "TB1"."CP_OPERATIONAL_USD_LAST_YEAR_PORTION_AVG_SEDA",
  "TB1"."NET_SALES_BRL_SEDA",
  "TB1"."NET_SALES_BRL_LAST_YEAR_SEDA",
  "TB1"."NET_SALES_BRL_TOTAL",
  "TB1"."NET_SALES_BRL_LAST_YEAR_TOTAL",
  "TB1"."CP_OPERATIONAL_USD_SEDA",
  "TB1"."CP_OPERATIONAL_USD_LAST_YEAR_SEDA",
  "TB1"."NET_SALES_BRL_SEDA_GROWTH",
  "TB1"."NET_SALES_PORTION_SEDA_GROWTH",
  "TB1"."CP_OPERATIONAL_USD_SEDA_GROWTH",
  "TB1"."CP_OPERATIONAL_PORTION_SEDA_GROWTH",
  TB1.seda_tim_perc,
  TB1.seda_tim_perc_last_year,
  TB1.seda_tim_perc_diff,
  "TB1"."MAX_FLOORING",
  "TB1"."MAX_YEARWEEK",
  "TB1"."AVG_FLOORING",
  "TB1"."SELL_OUT",
  "TB1"."RUN_RATE",
  "TB1"."FLOORING_TARGET",
  "TB1"."SELL_OUT_TARGET",
  "TB1"."RUN_RATE_TARGET",
  "TB1"."FLOORSHARE_TOTAL",
  "TB1"."FLOORSHARE_SOUNDBAR",
  "TB1"."FLOORSHARE_55_AND_ABOVE",
  "TB1"."FLOORSHARE_75_AND_ABOVE",
  "TB1"."Q80+_vs_OLED",
  "TB1"."COOP_SHARE_TOTAL",
  "TB1"."COOP_SHARE_50+",
  "TB1"."COOP_SHARE_65+",
  "TB1"."SELL_OUT_QTY",
  "TB1"."IN_HOUSE_SHARE",
  "TB1"."SELL_OUT_AMT",
  "TB1"."WEEKNUM_IN_HOUSE_SHARE",
  "TB2"."Y0_REF",
  "TB2"."Y_1_REF"
FROM (
  SELECT DISTINCT
    'AV' AS division_description,
    COALESCE(tb1.year, tb2.year) AS year,
    COALESCE(tb1.censo, tb2.censo) AS censo,
    COALESCE(tb1.item, tb2.item) AS item,
    net_sales_qty,
    net_sales_brl,
    cp_operational_usd,
    dealer_discount,
    sales_deduction_total,
    s_rrp,
    gross_sales_brl,
    dealer_discount_perc,
    sales_deduction_total_perc,
    tim_perc,
    net_sales_qty_last_year,
    net_sales_brl_last_year,
    cp_operational_usd_last_year,
    dealer_discount_last_year,
    sales_deduction_total_last_year,
    s_rrp_last_year,
    gross_sales_brl_last_year,
    dealer_discount_last_year_perc,
    sales_deduction_total_last_year_perc,
    tim_last_year_perc,
    net_sales_qty_growth,
    net_sales_brl_growth,
    CASE
      WHEN CASE
        WHEN cp_operational_usd_last_year <> 0
        THEN cp_operational_usd / cp_operational_usd_last_year
      END < 0
      THEN 0
      ELSE cp_operational_usd_growth
    END AS cp_operational_usd_growth,
    tim_perc_growth,
    net_sales_qty_growth_avg_seda,
    net_sales_brl_growth_avg_seda,
    cp_operational_usd_growth_avg_seda,
    tim_perc_growth_avg_seda,
    NET_SALES_QTY_PORTION,
    NET_SALES_BRL_PORTION,
    CASE WHEN net_sales_brl <> 0 THEN cp_operational_usd / net_sales_usd END AS cp_operational_usd_portion,
    NET_SALES_QTY_LAST_YEAR_PORTION,
    NET_SALES_BRL_LAST_YEAR_PORTION,
    CASE
      WHEN net_sales_brl_last_year <> 0
      THEN cp_operational_usd_last_year / net_sales_usd_last_year
    END AS cp_operational_usd_last_year_portion,
    NET_SALES_QTY_PORTION_AVG_SEDA,
    NET_SALES_BRL_PORTION_AVG_SEDA,
    cp_operational_usd_portion_AVG_SEDA,
    NET_SALES_QTY_LAST_YEAR_PORTION_AVG_SEDA,
    NET_SALES_BRL_LAST_YEAR_PORTION_AVG_SEDA,
    cp_operational_usd_last_year_portion_AVG_SEDA,
    net_sales_brl_seda,
    net_sales_brl_last_year_seda,
    net_sales_brl_total,
    net_sales_brl_last_year_total,
    cp_operational_usd_seda,
    cp_operational_usd_last_year_seda,
    net_sales_brl_seda_growth,
    net_sales_portion_seda_growth,
    cp_operational_usd_seda_growth,
    cp_operational_portion_seda_growth,
    seda_tim_perc,
    seda_tim_perc_last_year,
    seda_tim_perc_diff,
    MAX_FLOORING,
    max_yearweek,
    AVG_FLOORING,
    SELL_OUT,
    RUN_RATE,
    FLOORING_TARGET,
    SELL_OUT_TARGET,
    RUN_RATE_TARGET,
    0 AS floorshare_total,
    0 AS floorshare_soundbar,
    0 AS floorshare_55_and_above,
    0 AS floorshare_75_and_above,
    0 AS "Q80+_vs_OLED",
    0 AS COOP_SHARE_TOTAL,
    0 AS "COOP_SHARE_50+",
    0 AS "COOP_SHARE_65+",
    0 AS sell_out_qty,
    0 AS in_house_share,
    0 AS sell_out_amt,
    0 AS weeknum_in_house_share
  FROM OW_SEDA_S.vw_ce_account_management AS tb1
  FULL JOIN (
    SELECT
      *
    FROM OW_SEDA_S.vw_ce_account_management_flooring
    WHERE
      NOT censo IS NULL
  ) AS tb2
    ON 1 = 1 AND tb1.censo = tb2.censo AND tb1.item = tb2.item AND tb1.year = tb2.year
  UNION ALL
  SELECT
    'AV',
    2022,
    CENSO,
    'Floorshare',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    floorshare_total,
    floorshare_soundbar,
    floorshare_55_and_above,
    floorshare_75_and_above,
    "Q80+_vs_OLED",
    NULL AS COOP_SHARE_TOTAL,
    NULL AS "COOP_SHARE_50+",
    NULL AS "COOP_SHARE_65+",
    0 AS sell_out_qty,
    0 AS in_house_share,
    0 AS sell_out_amt,
    0 AS weeknum_in_house_share
  FROM OW_SEDA_S.account_management_floorshre_tt
  UNION ALL
  SELECT
    'AV' AS division_description,
    2022 AS year,
    censo,
    'COOP SHARE' AS item,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    COALESCE(QTY / SUM(QTY) OVER (), 0) AS COOP_SHARE_TOTAL,
    COALESCE(QTY_50 / SUM(QTY_50) OVER (), 0) AS "COOP_SHARE_50+",
    COALESCE(QTY_65 / SUM(QTY_65) OVER (), 0) AS "COOP_SHARE_65+",
    0 AS sell_out_qty,
    0 AS in_house_share,
    0 AS sell_out_amt,
    0 AS weeknum_in_house_share
  FROM (
    SELECT
      CASE
        WHEN LOJA = 'ANGELONI'
        THEN 'Angeloni'
        WHEN LOJA = 'SHOPTIME.COM'
        THEN 'B2W'
        WHEN LOJA = 'BIG'
        THEN 'Wal Mart'
        WHEN LOJA = 'BIG BOMPRECO'
        THEN 'Wal Mart'
        WHEN LOJA = 'CARREFOUR'
        THEN 'Carrefour'
        WHEN LOJA = 'EXTRA HIPER'
        THEN 'CBD'
        WHEN LOJA = 'ELETRO MATEUS'
        THEN 'Armazem Mateus'
        WHEN LOJA = 'FAST SHOP'
        THEN 'Fast'
        WHEN LOJA = 'FORMOSA MIX'
        THEN 'Formosa'
        WHEN LOJA = 'FUJIOKA'
        THEN 'Fujioka'
        WHEN LOJA = 'G BARBOSA'
        THEN 'G Barbosa'
        WHEN LOJA = 'GAZIN'
        THEN 'Gazin'
        WHEN LOJA = 'HAVAN'
        THEN 'Havan'
        WHEN LOJA = 'IMPERIO MOVEIS'
        THEN 'Imperio dos Eletros'
        WHEN LOJA = 'KOERICH'
        THEN 'Koerich'
        WHEN LOJA = 'AMERICANAS'
        THEN 'LASA'
        WHEN LOJA = 'LASER ELETRO'
        THEN 'Laser Eletro'
        WHEN LOJA = 'LILIANI'
        THEN 'Liliani'
        WHEN LOJA = 'LOJAS CEM'
        THEN 'Lojas Cem'
        WHEN LOJA = 'LOJAS COLOMBO'
        THEN 'Lojas Colombo'
        WHEN LOJA = 'LOJAS LEBES'
        THEN 'Lebes'
        WHEN LOJA = 'MAGAZINE LUIZA'
        THEN 'Magazine Luiza'
        WHEN LOJA = 'NAGEM'
        THEN 'Nagem'
        WHEN LOJA = 'NOVO MUNDO'
        THEN 'Novo Mundo'
        WHEN LOJA = 'TAQI'
        THEN 'TAQI'
        WHEN LOJA = 'CASAS BAHIA'
        THEN 'Via Varejo'
        WHEN LOJA = 'PONTO'
        THEN 'Via Varejo'
        WHEN LOJA = 'MILLENA MOVEIS'
        THEN 'Millena Moveis'
      END AS censo,
      SUM(QTY) AS QTY,
      SUM(CASE WHEN INCH IN ('46-54', '55"', '58-60', '65-70', '75"') THEN QTY END) AS QTY_50,
      SUM(CASE WHEN INCH IN ('65-70', '75"') THEN QTY END) AS QTY_65
    FROM OW_SEDA_S.ods_sb_coop_share
    WHERE
      1 = 1 AND sheetname = 'Dados_TV_Shop Brasil_2022'
    GROUP BY
      CASE
        WHEN LOJA = 'ANGELONI'
        THEN 'Angeloni'
        WHEN LOJA = 'SHOPTIME.COM'
        THEN 'B2W'
        WHEN LOJA = 'BIG'
        THEN 'Wal Mart'
        WHEN LOJA = 'BIG BOMPRECO'
        THEN 'Wal Mart'
        WHEN LOJA = 'CARREFOUR'
        THEN 'Carrefour'
        WHEN LOJA = 'EXTRA HIPER'
        THEN 'CBD'
        WHEN LOJA = 'ELETRO MATEUS'
        THEN 'Armazem Mateus'
        WHEN LOJA = 'FAST SHOP'
        THEN 'Fast'
        WHEN LOJA = 'FORMOSA MIX'
        THEN 'Formosa'
        WHEN LOJA = 'FUJIOKA'
        THEN 'Fujioka'
        WHEN LOJA = 'G BARBOSA'
        THEN 'G Barbosa'
        WHEN LOJA = 'GAZIN'
        THEN 'Gazin'
        WHEN LOJA = 'HAVAN'
        THEN 'Havan'
        WHEN LOJA = 'IMPERIO MOVEIS'
        THEN 'Imperio dos Eletros'
        WHEN LOJA = 'KOERICH'
        THEN 'Koerich'
        WHEN LOJA = 'AMERICANAS'
        THEN 'LASA'
        WHEN LOJA = 'LASER ELETRO'
        THEN 'Laser Eletro'
        WHEN LOJA = 'LILIANI'
        THEN 'Liliani'
        WHEN LOJA = 'LOJAS CEM'
        THEN 'Lojas Cem'
        WHEN LOJA = 'LOJAS COLOMBO'
        THEN 'Lojas Colombo'
        WHEN LOJA = 'LOJAS LEBES'
        THEN 'Lebes'
        WHEN LOJA = 'MAGAZINE LUIZA'
        THEN 'Magazine Luiza'
        WHEN LOJA = 'NAGEM'
        THEN 'Nagem'
        WHEN LOJA = 'NOVO MUNDO'
        THEN 'Novo Mundo'
        WHEN LOJA = 'TAQI'
        THEN 'TAQI'
        WHEN LOJA = 'CASAS BAHIA'
        THEN 'Via Varejo'
        WHEN LOJA = 'PONTO'
        THEN 'Via Varejo'
        WHEN LOJA = 'MILLENA MOVEIS'
        THEN 'Millena Moveis'
      END
  ) AS subq_7056
  UNION ALL
  SELECT
    'AV' AS division_description,
    YEAR(LEFT((weeknum)::VARCHAR, 4)) AS YEAR,
    CASE WHEN account = 'Fast Shop' THEN 'Fast' ELSE account END AS censo,
    'In House Share - ' || store_type || ' - ' || category AS item,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    sell_out_qty,
    in_house_share,
    sell_out_amt,
    weeknum AS weeknum_in_house_share
  FROM OW_SEDA_S.ODS_CE_KAM_IN_HOUSE_SHARE AS okihs
  WHERE
    EXISTS(
      SELECT
        1
      FROM (
        SELECT
          account,
          MAX(weeknum) AS mw
        FROM OW_SEDA_S.ODS_CE_KAM_IN_HOUSE_SHARE
        GROUP BY
          ACCOUNT
      ) AS t
      WHERE
        okihs.account = t.account AND okihs.weeknum = t.mw
    )
) AS tb1
LEFT JOIN (
  SELECT
    LEFT((spmon)::VARCHAR, 4) AS year,
    MIN(spmon) || ' - ' || MAX(spmon) AS y0_ref,
    LEFT((spmon)::VARCHAR, 4) - 1 || RIGHT(MIN(spmon), 4) || ' - ' || LEFT((spmon)::VARCHAR, 4) - 1 || RIGHT(MAX(spmon), 4) AS y_1_ref
  FROM u_d_takeshi.vw_ce_informacoes_gerenciais
  GROUP BY
    LEFT((spmon)::VARCHAR, 4)
) AS tb2
  ON tb1.year = tb2.YEAR