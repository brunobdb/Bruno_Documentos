-- MISSING RELATION: OW_SEDA_S_LOGISTIC.FT_CT_CELLO
-- ERROR: Error executing query: Severity: ERROR, Message: Relation "OW_SEDA_S_LOGISTIC.FT_CT_CELLO" does not exist, Sqlstate: 42V01, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Miner/server/vertica/Catalog/CatalogLookup.cpp, Line: 4362, Error Code: 4568, SQL: 'CREATE OR REPLACE VIEW "OW_SEDA_S_LOGISTIC"."VW_CT_CANCELED_WITH_IOD" (   "CHANNEL",   "ORIGINAL_ORDER_ID",   "ORDER_ID",   "SEQUENCE",   "DO_NO",   "STATUS_MARKETPLACE",   "STATUS_VTEX",   "STATUS_CELLO",   "TRACKING_NUMBER",   "INVOICE_NUMBER",   "DELIVERED_DATE",   "FINISHED",   "CREATION_DATE",   "GI_DATE",   "IOD_DATE",   "TRACKING_URL" ) AS (   (     (       (         (           (             (               SELECT                 p.CHANNEL,                 \'|\' || CAST(p.ORIGINAL_ORDER_ID AS VARCHAR) AS ORIGINAL_ORDER_ID,                 v.ORDER_ID,                 v."SEQUENCE",                 c.DO_NO,                 p.STATUS AS STATUS_MARKETPLACE,                 v.STATUS AS STATUS_VTEX,                 c.ORDER_STATUS AS STATUS_CELLO,                 pk.TRACKING_NUMBER,                 pk.INVOICE_NUMBER,                 pk.DELIVERED_DATE,                 pk.FINISHED,                 TO_DATE((v.CREATION_TIMESTAMP)::VARCHAR, \'YYYY-MM-DD\') AS CREATION_DATE,                 (c.GI_DATE)::TIMESTAMP AS GI_DATE,                 (c.IOD_DATE)::TIMESTAMP AS IOD_DATE,                 pk.TRACKING_URL               FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p               LEFT JOIN (                 SELECT DISTINCT                   ORDER_ID,                   MARKETPLACE_ORDER_ID,                   "SEQUENCE",                   STATUS,                   CREATION_TIMESTAMP                 FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER               ) AS v                 ON SUBSTRING((p.ORIGINAL_ORDER_ID)::VARCHAR, 1, 99) = v.MARKETPLACE_ORDER_ID               LEFT JOIN (                 SELECT DISTINCT                   DO_NO,                   CUSTOMER_PO,                   ORDER_STATUS,                   GI_DATE,                   IOD_DATE                 FROM OW_SEDA_S_LOGISTIC.FT_CT_CELLO               ) AS c                 ON (                   CASE                     WHEN v.ORDER_ID = c.CUSTOMER_PO                     THEN 1                     WHEN v."SEQUENCE" = c.CUSTOMER_PO                     THEN 1                     WHEN SUBSTRING((c.CUSTOMER_PO)::VARCHAR, 1, 50) = v.ORDER_ID                     THEN 1                     ELSE 0                   END                 ) = 1               LEFT JOIN (                 SELECT DISTINCT                   ORDER_ID,                   TRACKING_NUMBER,                   TRACKING_URL,                   INVOICE_NUMBER,                   FINISHED,                   DELIVERED_DATE                 FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER_PACKAGE               ) AS pk                 ON v.ORDER_ID = pk.ORDER_ID               WHERE                 CHANNEL = \'Cnova\' AND p.STATUS IN (\'canceled\') AND NOT c.IOD_DATE IS NULL             )             UNION             (               SELECT                 p.CHANNEL,                 \'|\' || CAST(p.ORIGINAL_ORDER_ID AS VARCHAR) AS ORIGINAL_ORDER_ID,                 v.ORDER_ID,                 v."SEQUENCE",                 c.DO_NO,                 p.STATUS AS STATUS_MARKETPLACE,                 v.STATUS AS STATUS_VTEX,                 c.ORDER_STATUS AS STATUS_CELLO,                 pk.TRACKING_NUMBER,                 pk.INVOICE_NUMBER,                 pk.DELIVERED_DATE,                 pk.FINISHED,                 TO_DATE((v.CREATION_TIMESTAMP)::VARCHAR, \'YYYY-MM-DD\') AS CREATION_DATE,                 (c.GI_DATE)::TIMESTAMP AS GI_DATE,                 (c.IOD_DATE)::TIMESTAMP AS IOD_DATE,                 pk.TRACKING_URL               FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p               LEFT JOIN (                 SELECT DISTINCT                   ORDER_ID,                   MARKETPLACE_ORDER_ID,                   "SEQUENCE",                   STATUS,                   CREATION_TIMESTAMP                 FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER               ) AS v                 ON p.ORIGINAL_ORDER_ID = v.MARKETPLACE_ORDER_ID               LEFT JOIN (                 SELECT DISTINCT                   DO_NO,                   CUSTOMER_PO,                   ORDER_STATUS,                   GI_DATE,                   IOD_DATE                 FROM OW_SEDA_S_LOGISTIC.FT_CT_CELLO               ) AS c                 ON (                   CASE                     WHEN v.ORDER_ID = c.CUSTOMER_PO                     THEN 1                     WHEN v."SEQUENCE" = c.CUSTOMER_PO                     THEN 1                     WHEN SUBSTRING((c.CUSTOMER_PO)::VARCHAR, 1, 50) = v.ORDER_ID                     THEN 1                     ELSE 0                   END                 ) = 1               LEFT JOIN (                 SELECT DISTINCT                   ORDER_ID,                   TRACKING_NUMBER,                   TRACKING_URL,                   INVOICE_NUMBER,                   FINISHED,                   DELIVERED_DATE                 FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER_PACKAGE               ) AS pk                 ON v.ORDER_ID = pk.ORDER_ID               WHERE                 CHANNEL = \'b2w\' AND p.STATUS IN (\'canceled\') AND NOT c.IOD_DATE IS NULL             )           )           UNION           (             SELECT               p.CHANNEL,               \'|\' || CAST(p.ORIGINAL_ORDER_ID AS VARCHAR) AS ORIGINAL_ORDER_ID,               v.ORDER_ID,               v."SEQUENCE",               c.DO_NO,               p.STATUS AS STATUS_MARKETPLACE,               v.STATUS AS STATUS_VTEX,               c.ORDER_STATUS AS STATUS_CELLO,               pk.TRACKING_NUMBER,               pk.INVOICE_NUMBER,               pk.DELIVERED_DATE,               pk.FINISHED,               TO_DATE((v.CREATION_TIMESTAMP)::VARCHAR, \'YYYY-MM-DD\') AS CREATION_DATE,               (c.GI_DATE)::TIMESTAMP AS GI_DATE,               (c.IOD_DATE)::TIMESTAMP AS IOD_DATE,               pk.TRACKING_URL             FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p             LEFT JOIN (               SELECT DISTINCT                 ORDER_ID,                 MARKETPLACE_ORDER_ID,                 "SEQUENCE",                 STATUS,                 CREATION_TIMESTAMP               FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER             ) AS v               ON p.ORIGINAL_ORDER_ID = v.MARKETPLACE_ORDER_ID             LEFT JOIN (               SELECT DISTINCT                 DO_NO,                 CUSTOMER_PO,                 ORDER_STATUS,                 GI_DATE,                 IOD_DATE               FROM OW_SEDA_S_LOGISTIC.FT_CT_CELLO             ) AS c               ON (                 CASE                   WHEN v.ORDER_ID = c.CUSTOMER_PO                   THEN 1                   WHEN v."SEQUENCE" = c.CUSTOMER_PO                   THEN 1                   WHEN SUBSTRING((c.CUSTOMER_PO)::VARCHAR, 1, 50) = v.ORDER_ID                   THEN 1                   ELSE 0                 END               ) = 1             LEFT JOIN (               SELECT DISTINCT                 ORDER_ID,                 TRACKING_NUMBER,                 TRACKING_URL,                 INVOICE_NUMBER,                 FINISHED,                 DELIVERED_DATE               FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER_PACKAGE             ) AS pk               ON v.ORDER_ID = pk.ORDER_ID             WHERE               CHANNEL = \'Carrefour\' AND p.STATUS IN (\'canceled\') AND NOT c.IOD_DATE IS NULL           )         )         UNION         (           SELECT             p.CHANNEL,             \'|\' || CAST(p.ORIGINAL_ORDER_ID AS VARCHAR) AS ORIGINAL_ORDER_ID,             v.ORDER_ID,             v."SEQUENCE",             c.DO_NO,             p.STATUS AS STATUS_MARKETPLACE,             v.STATUS AS STATUS_VTEX,             c.ORDER_STATUS AS STATUS_CELLO,             pk.TRACKING_NUMBER,             pk.INVOICE_NUMBER,             pk.DELIVERED_DATE,             pk.FINISHED,             TO_DATE((v.CREATION_TIMESTAMP)::VARCHAR, \'YYYY-MM-DD\') AS CREATION_DATE,             (c.GI_DATE)::TIMESTAMP AS GI_DATE,             (c.IOD_DATE)::TIMESTAMP AS IOD_DATE,             pk.TRACKING_URL           FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p           LEFT JOIN (             SELECT DISTINCT               ORDER_ID,               MARKETPLACE_ORDER_ID,               "SEQUENCE",               STATUS,               CREATION_TIMESTAMP             FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER           ) AS v             ON p.ORIGINAL_ORDER_ID = v.MARKETPLACE_ORDER_ID           LEFT JOIN (             SELECT DISTINCT               DO_NO,               CUSTOMER_PO,               ORDER_STATUS,               GI_DATE,               IOD_DATE             FROM OW_SEDA_S_LOGISTIC.FT_CT_CELLO           ) AS c             ON (               CASE                 WHEN v.ORDER_ID = c.CUSTOMER_PO                 THEN 1                 WHEN v."SEQUENCE" = c.CUSTOMER_PO                 THEN 1                 WHEN SUBSTRING((c.CUSTOMER_PO)::VARCHAR, 1, 50) = v.ORDER_ID                 THEN 1                 ELSE 0               END             ) = 1           LEFT JOIN (             SELECT DISTINCT               ORDER_ID,               TRACKING_NUMBER,               TRACKING_URL,               INVOICE_NUMBER,               FINISHED,               DELIVERED_DATE             FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER_PACKAGE           ) AS pk             ON v.ORDER_ID = pk.ORDER_ID           WHERE             CHANNEL = \'LeroyMerlin\' AND p.STATUS IN (\'canceled\') AND NOT c.IOD_DATE IS NULL         )       )       UNION       (         SELECT           p.CHANNEL,           \'|\' || CAST(p.ORIGINAL_ORDER_ID AS VARCHAR) AS ORIGINAL_ORDER_ID,           v.ORDER_ID,           v."SEQUENCE",           c.DO_NO,           p.STATUS AS STATUS_MARKETPLACE,           v.STATUS AS STATUS_VTEX,           c.ORDER_STATUS AS STATUS_CELLO,           pk.TRACKING_NUMBER,           pk.INVOICE_NUMBER,           pk.DELIVERED_DATE,           pk.FINISHED,           TO_DATE((v.CREATION_TIMESTAMP)::VARCHAR, \'YYYY-MM-DD\') AS CREATION_DATE,           (c.GI_DATE)::TIMESTAMP AS GI_DATE,           (c.IOD_DATE)::TIMESTAMP AS IOD_DATE,           pk.TRACKING_URL         FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p         LEFT JOIN (           SELECT DISTINCT             ORDER_ID,             MARKETPLACE_ORDER_ID,             "SEQUENCE",             STATUS,             CREATION_TIMESTAMP           FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER         ) AS v           ON SUBSTRING((p.ORIGINAL_ORDER_ID)::VARCHAR, 1, LENGTH(p.ORIGINAL_ORDER_ID) - 4) = v.MARKETPLACE_ORDER_ID         LEFT JOIN (           SELECT DISTINCT             DO_NO,             CUSTOMER_PO,             ORDER_STATUS,             GI_DATE,             IOD_DATE           FROM OW_SEDA_S_LOGISTIC.FT_CT_CELLO         ) AS c           ON (             CASE               WHEN v.ORDER_ID = c.CUSTOMER_PO               THEN 1               WHEN v."SEQUENCE" = c.CUSTOMER_PO               THEN 1               WHEN SUBSTRING((c.CUSTOMER_PO)::VARCHAR, 1, 50) = v.ORDER_ID               THEN 1               ELSE 0             END           ) = 1         LEFT JOIN (           SELECT DISTINCT             ORDER_ID,             TRACKING_NUMBER,             TRACKING_URL,             INVOICE_NUMBER,             FINISHED,             DELIVERED_DATE           FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER_PACKAGE         ) AS pk           ON v.ORDER_ID = pk.ORDER_ID         WHERE           CHANNEL = \'MagazineLuiza\' AND p.STATUS IN (\'canceled\') AND NOT c.IOD_DATE IS NULL       )     )     UNION     (       SELECT         p.CHANNEL,         \'|\' || CAST(p.ORIGINAL_ORDER_ID AS VARCHAR) AS ORIGINAL_ORDER_ID,         v.ORDER_ID,         v."SEQUENCE",         c.DO_NO,         p.STATUS AS STATUS_MARKETPLACE,         v.STATUS AS STATUS_VTEX,         c.ORDER_STATUS AS STATUS_CELLO,         pk.TRACKING_NUMBER,         pk.INVOICE_NUMBER,         pk.DELIVERED_DATE,         pk.FINISHED,         TO_DATE((v.CREATION_TIMESTAMP)::VARCHAR, \'YYYY-MM-DD\') AS CREATION_DATE,         (c.GI_DATE)::TIMESTAMP AS GI_DATE,         (c.IOD_DATE)::TIMESTAMP AS IOD_DATE,         pk.TRACKING_URL       FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p       LEFT JOIN (         SELECT           CAST(SUBSTRING((b.FIRST_MESSAGE)::VARCHAR, 1, 16) AS VARCHAR) AS ORDER_MELI,           FIRST_MESSAGE,           v.*         FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER AS v         LEFT JOIN U_PRJ_ECOM.ODS_VTEX_BRIDGE AS b           ON v.MARKETPLACE_ORDER_ID = b.ID         WHERE           AFFILIATE_ID IN (\'MMC\', \'MMP\')       ) AS v         ON p.ORIGINAL_ORDER_ID = v.ORDER_MELI       LEFT JOIN (         SELECT DISTINCT           DO_NO,           CUSTOMER_PO,           ORDER_STATUS,           GI_DATE,           IOD_DATE         FROM OW_SEDA_S_LOGISTIC.FT_CT_CELLO       ) AS c         ON (           CASE             WHEN v.ORDER_ID = c.CUSTOMER_PO             THEN 1             WHEN v."SEQUENCE" = c.CUSTOMER_PO             THEN 1             WHEN SUBSTRING((c.CUSTOMER_PO)::VARCHAR, 1, 50) = v.ORDER_ID             THEN 1             ELSE 0           END         ) = 1       LEFT JOIN (         SELECT DISTINCT           ORDER_ID,           TRACKING_NUMBER,           TRACKING_URL,           INVOICE_NUMBER,           FINISHED,           DELIVERED_DATE         FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER_PACKAGE       ) AS pk         ON v.ORDER_ID = pk.ORDER_ID       WHERE         CHANNEL = \'MercadoLivre\' AND p.STATUS IN (\'canceled\') AND NOT c.IOD_DATE IS NULL     )   )   UNION   (     SELECT       p.CHANNEL,       \'|\' || CAST(p.ORIGINAL_ORDER_ID AS VARCHAR) AS ORIGINAL_ORDER_ID,       v.ORDER_ID,       v."SEQUENCE",       c.DO_NO,       p.STATUS AS STATUS_MARKETPLACE,       v.STATUS AS STATUS_VTEX,       c.ORDER_STATUS AS STATUS_CELLO,       pk.TRACKING_NUMBER,       pk.INVOICE_NUMBER,       pk.DELIVERED_DATE,       pk.FINISHED,       TO_DATE((v.CREATION_TIMESTAMP)::VARCHAR, \'YYYY-MM-DD\') AS CREATION_DATE,       (c.GI_DATE)::TIMESTAMP AS GI_DATE,       (c.IOD_DATE)::TIMESTAMP AS IOD_DATE,       pk.TRACKING_URL     FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p     LEFT JOIN (       SELECT DISTINCT         ORDER_ID,         MARKETPLACE_ORDER_ID,         "SEQUENCE",         STATUS,         CREATION_TIMESTAMP       FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER     ) AS v       ON p.ORIGINAL_ORDER_ID = v.MARKETPLACE_ORDER_ID     LEFT JOIN (       SELECT DISTINCT         DO_NO,         CUSTOMER_PO,         ORDER_STATUS,         GI_DATE,         IOD_DATE       FROM OW_SEDA_S_LOGISTIC.FT_CT_CELLO     ) AS c       ON (         CASE           WHEN v.ORDER_ID = c.CUSTOMER_PO           THEN 1           WHEN v."SEQUENCE" = c.CUSTOMER_PO           THEN 1           ELSE 0         END       ) = 1     LEFT JOIN (       SELECT DISTINCT         ORDER_ID,         TRACKING_NUMBER,         TRACKING_URL,         INVOICE_NUMBER,         FINISHED,         DELIVERED_DATE       FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER_PACKAGE     ) AS pk       ON v.ORDER_ID = pk.ORDER_ID     WHERE       CHANNEL = \'Amazon.com.br\' AND p.STATUS IN (\'canceled\') AND NOT c.IOD_DATE IS NULL   ) )'

CREATE OR REPLACE VIEW "OW_SEDA_S_LOGISTIC"."VW_CT_CANCELED_WITH_IOD" (
  "CHANNEL",
  "ORIGINAL_ORDER_ID",
  "ORDER_ID",
  "SEQUENCE",
  "DO_NO",
  "STATUS_MARKETPLACE",
  "STATUS_VTEX",
  "STATUS_CELLO",
  "TRACKING_NUMBER",
  "INVOICE_NUMBER",
  "DELIVERED_DATE",
  "FINISHED",
  "CREATION_DATE",
  "GI_DATE",
  "IOD_DATE",
  "TRACKING_URL"
) AS
(
  (
    (
      (
        (
          (
            (
              SELECT
                p.CHANNEL,
                '|' || CAST(p.ORIGINAL_ORDER_ID AS VARCHAR) AS ORIGINAL_ORDER_ID,
                v.ORDER_ID,
                v."SEQUENCE",
                c.DO_NO,
                p.STATUS AS STATUS_MARKETPLACE,
                v.STATUS AS STATUS_VTEX,
                c.ORDER_STATUS AS STATUS_CELLO,
                pk.TRACKING_NUMBER,
                pk.INVOICE_NUMBER,
                pk.DELIVERED_DATE,
                pk.FINISHED,
                TO_DATE((v.CREATION_TIMESTAMP)::VARCHAR, 'YYYY-MM-DD') AS CREATION_DATE,
                (c.GI_DATE)::TIMESTAMP AS GI_DATE,
                (c.IOD_DATE)::TIMESTAMP AS IOD_DATE,
                pk.TRACKING_URL
              FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p
              LEFT JOIN (
                SELECT DISTINCT
                  ORDER_ID,
                  MARKETPLACE_ORDER_ID,
                  "SEQUENCE",
                  STATUS,
                  CREATION_TIMESTAMP
                FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER
              ) AS v
                ON SUBSTRING((p.ORIGINAL_ORDER_ID)::VARCHAR, 1, 99) = v.MARKETPLACE_ORDER_ID
              LEFT JOIN (
                SELECT DISTINCT
                  DO_NO,
                  CUSTOMER_PO,
                  ORDER_STATUS,
                  GI_DATE,
                  IOD_DATE
                FROM OW_SEDA_S_LOGISTIC.FT_CT_CELLO
              ) AS c
                ON (
                  CASE
                    WHEN v.ORDER_ID = c.CUSTOMER_PO
                    THEN 1
                    WHEN v."SEQUENCE" = c.CUSTOMER_PO
                    THEN 1
                    WHEN SUBSTRING((c.CUSTOMER_PO)::VARCHAR, 1, 50) = v.ORDER_ID
                    THEN 1
                    ELSE 0
                  END
                ) = 1
              LEFT JOIN (
                SELECT DISTINCT
                  ORDER_ID,
                  TRACKING_NUMBER,
                  TRACKING_URL,
                  INVOICE_NUMBER,
                  FINISHED,
                  DELIVERED_DATE
                FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER_PACKAGE
              ) AS pk
                ON v.ORDER_ID = pk.ORDER_ID
              WHERE
                CHANNEL = 'Cnova' AND p.STATUS IN ('canceled') AND NOT c.IOD_DATE IS NULL
            )
            UNION
            (
              SELECT
                p.CHANNEL,
                '|' || CAST(p.ORIGINAL_ORDER_ID AS VARCHAR) AS ORIGINAL_ORDER_ID,
                v.ORDER_ID,
                v."SEQUENCE",
                c.DO_NO,
                p.STATUS AS STATUS_MARKETPLACE,
                v.STATUS AS STATUS_VTEX,
                c.ORDER_STATUS AS STATUS_CELLO,
                pk.TRACKING_NUMBER,
                pk.INVOICE_NUMBER,
                pk.DELIVERED_DATE,
                pk.FINISHED,
                TO_DATE((v.CREATION_TIMESTAMP)::VARCHAR, 'YYYY-MM-DD') AS CREATION_DATE,
                (c.GI_DATE)::TIMESTAMP AS GI_DATE,
                (c.IOD_DATE)::TIMESTAMP AS IOD_DATE,
                pk.TRACKING_URL
              FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p
              LEFT JOIN (
                SELECT DISTINCT
                  ORDER_ID,
                  MARKETPLACE_ORDER_ID,
                  "SEQUENCE",
                  STATUS,
                  CREATION_TIMESTAMP
                FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER
              ) AS v
                ON p.ORIGINAL_ORDER_ID = v.MARKETPLACE_ORDER_ID
              LEFT JOIN (
                SELECT DISTINCT
                  DO_NO,
                  CUSTOMER_PO,
                  ORDER_STATUS,
                  GI_DATE,
                  IOD_DATE
                FROM OW_SEDA_S_LOGISTIC.FT_CT_CELLO
              ) AS c
                ON (
                  CASE
                    WHEN v.ORDER_ID = c.CUSTOMER_PO
                    THEN 1
                    WHEN v."SEQUENCE" = c.CUSTOMER_PO
                    THEN 1
                    WHEN SUBSTRING((c.CUSTOMER_PO)::VARCHAR, 1, 50) = v.ORDER_ID
                    THEN 1
                    ELSE 0
                  END
                ) = 1
              LEFT JOIN (
                SELECT DISTINCT
                  ORDER_ID,
                  TRACKING_NUMBER,
                  TRACKING_URL,
                  INVOICE_NUMBER,
                  FINISHED,
                  DELIVERED_DATE
                FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER_PACKAGE
              ) AS pk
                ON v.ORDER_ID = pk.ORDER_ID
              WHERE
                CHANNEL = 'b2w' AND p.STATUS IN ('canceled') AND NOT c.IOD_DATE IS NULL
            )
          )
          UNION
          (
            SELECT
              p.CHANNEL,
              '|' || CAST(p.ORIGINAL_ORDER_ID AS VARCHAR) AS ORIGINAL_ORDER_ID,
              v.ORDER_ID,
              v."SEQUENCE",
              c.DO_NO,
              p.STATUS AS STATUS_MARKETPLACE,
              v.STATUS AS STATUS_VTEX,
              c.ORDER_STATUS AS STATUS_CELLO,
              pk.TRACKING_NUMBER,
              pk.INVOICE_NUMBER,
              pk.DELIVERED_DATE,
              pk.FINISHED,
              TO_DATE((v.CREATION_TIMESTAMP)::VARCHAR, 'YYYY-MM-DD') AS CREATION_DATE,
              (c.GI_DATE)::TIMESTAMP AS GI_DATE,
              (c.IOD_DATE)::TIMESTAMP AS IOD_DATE,
              pk.TRACKING_URL
            FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p
            LEFT JOIN (
              SELECT DISTINCT
                ORDER_ID,
                MARKETPLACE_ORDER_ID,
                "SEQUENCE",
                STATUS,
                CREATION_TIMESTAMP
              FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER
            ) AS v
              ON p.ORIGINAL_ORDER_ID = v.MARKETPLACE_ORDER_ID
            LEFT JOIN (
              SELECT DISTINCT
                DO_NO,
                CUSTOMER_PO,
                ORDER_STATUS,
                GI_DATE,
                IOD_DATE
              FROM OW_SEDA_S_LOGISTIC.FT_CT_CELLO
            ) AS c
              ON (
                CASE
                  WHEN v.ORDER_ID = c.CUSTOMER_PO
                  THEN 1
                  WHEN v."SEQUENCE" = c.CUSTOMER_PO
                  THEN 1
                  WHEN SUBSTRING((c.CUSTOMER_PO)::VARCHAR, 1, 50) = v.ORDER_ID
                  THEN 1
                  ELSE 0
                END
              ) = 1
            LEFT JOIN (
              SELECT DISTINCT
                ORDER_ID,
                TRACKING_NUMBER,
                TRACKING_URL,
                INVOICE_NUMBER,
                FINISHED,
                DELIVERED_DATE
              FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER_PACKAGE
            ) AS pk
              ON v.ORDER_ID = pk.ORDER_ID
            WHERE
              CHANNEL = 'Carrefour' AND p.STATUS IN ('canceled') AND NOT c.IOD_DATE IS NULL
          )
        )
        UNION
        (
          SELECT
            p.CHANNEL,
            '|' || CAST(p.ORIGINAL_ORDER_ID AS VARCHAR) AS ORIGINAL_ORDER_ID,
            v.ORDER_ID,
            v."SEQUENCE",
            c.DO_NO,
            p.STATUS AS STATUS_MARKETPLACE,
            v.STATUS AS STATUS_VTEX,
            c.ORDER_STATUS AS STATUS_CELLO,
            pk.TRACKING_NUMBER,
            pk.INVOICE_NUMBER,
            pk.DELIVERED_DATE,
            pk.FINISHED,
            TO_DATE((v.CREATION_TIMESTAMP)::VARCHAR, 'YYYY-MM-DD') AS CREATION_DATE,
            (c.GI_DATE)::TIMESTAMP AS GI_DATE,
            (c.IOD_DATE)::TIMESTAMP AS IOD_DATE,
            pk.TRACKING_URL
          FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p
          LEFT JOIN (
            SELECT DISTINCT
              ORDER_ID,
              MARKETPLACE_ORDER_ID,
              "SEQUENCE",
              STATUS,
              CREATION_TIMESTAMP
            FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER
          ) AS v
            ON p.ORIGINAL_ORDER_ID = v.MARKETPLACE_ORDER_ID
          LEFT JOIN (
            SELECT DISTINCT
              DO_NO,
              CUSTOMER_PO,
              ORDER_STATUS,
              GI_DATE,
              IOD_DATE
            FROM OW_SEDA_S_LOGISTIC.FT_CT_CELLO
          ) AS c
            ON (
              CASE
                WHEN v.ORDER_ID = c.CUSTOMER_PO
                THEN 1
                WHEN v."SEQUENCE" = c.CUSTOMER_PO
                THEN 1
                WHEN SUBSTRING((c.CUSTOMER_PO)::VARCHAR, 1, 50) = v.ORDER_ID
                THEN 1
                ELSE 0
              END
            ) = 1
          LEFT JOIN (
            SELECT DISTINCT
              ORDER_ID,
              TRACKING_NUMBER,
              TRACKING_URL,
              INVOICE_NUMBER,
              FINISHED,
              DELIVERED_DATE
            FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER_PACKAGE
          ) AS pk
            ON v.ORDER_ID = pk.ORDER_ID
          WHERE
            CHANNEL = 'LeroyMerlin' AND p.STATUS IN ('canceled') AND NOT c.IOD_DATE IS NULL
        )
      )
      UNION
      (
        SELECT
          p.CHANNEL,
          '|' || CAST(p.ORIGINAL_ORDER_ID AS VARCHAR) AS ORIGINAL_ORDER_ID,
          v.ORDER_ID,
          v."SEQUENCE",
          c.DO_NO,
          p.STATUS AS STATUS_MARKETPLACE,
          v.STATUS AS STATUS_VTEX,
          c.ORDER_STATUS AS STATUS_CELLO,
          pk.TRACKING_NUMBER,
          pk.INVOICE_NUMBER,
          pk.DELIVERED_DATE,
          pk.FINISHED,
          TO_DATE((v.CREATION_TIMESTAMP)::VARCHAR, 'YYYY-MM-DD') AS CREATION_DATE,
          (c.GI_DATE)::TIMESTAMP AS GI_DATE,
          (c.IOD_DATE)::TIMESTAMP AS IOD_DATE,
          pk.TRACKING_URL
        FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p
        LEFT JOIN (
          SELECT DISTINCT
            ORDER_ID,
            MARKETPLACE_ORDER_ID,
            "SEQUENCE",
            STATUS,
            CREATION_TIMESTAMP
          FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER
        ) AS v
          ON SUBSTRING((p.ORIGINAL_ORDER_ID)::VARCHAR, 1, LENGTH(p.ORIGINAL_ORDER_ID) - 4) = v.MARKETPLACE_ORDER_ID
        LEFT JOIN (
          SELECT DISTINCT
            DO_NO,
            CUSTOMER_PO,
            ORDER_STATUS,
            GI_DATE,
            IOD_DATE
          FROM OW_SEDA_S_LOGISTIC.FT_CT_CELLO
        ) AS c
          ON (
            CASE
              WHEN v.ORDER_ID = c.CUSTOMER_PO
              THEN 1
              WHEN v."SEQUENCE" = c.CUSTOMER_PO
              THEN 1
              WHEN SUBSTRING((c.CUSTOMER_PO)::VARCHAR, 1, 50) = v.ORDER_ID
              THEN 1
              ELSE 0
            END
          ) = 1
        LEFT JOIN (
          SELECT DISTINCT
            ORDER_ID,
            TRACKING_NUMBER,
            TRACKING_URL,
            INVOICE_NUMBER,
            FINISHED,
            DELIVERED_DATE
          FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER_PACKAGE
        ) AS pk
          ON v.ORDER_ID = pk.ORDER_ID
        WHERE
          CHANNEL = 'MagazineLuiza' AND p.STATUS IN ('canceled') AND NOT c.IOD_DATE IS NULL
      )
    )
    UNION
    (
      SELECT
        p.CHANNEL,
        '|' || CAST(p.ORIGINAL_ORDER_ID AS VARCHAR) AS ORIGINAL_ORDER_ID,
        v.ORDER_ID,
        v."SEQUENCE",
        c.DO_NO,
        p.STATUS AS STATUS_MARKETPLACE,
        v.STATUS AS STATUS_VTEX,
        c.ORDER_STATUS AS STATUS_CELLO,
        pk.TRACKING_NUMBER,
        pk.INVOICE_NUMBER,
        pk.DELIVERED_DATE,
        pk.FINISHED,
        TO_DATE((v.CREATION_TIMESTAMP)::VARCHAR, 'YYYY-MM-DD') AS CREATION_DATE,
        (c.GI_DATE)::TIMESTAMP AS GI_DATE,
        (c.IOD_DATE)::TIMESTAMP AS IOD_DATE,
        pk.TRACKING_URL
      FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p
      LEFT JOIN (
        SELECT
          CAST(SUBSTRING((b.FIRST_MESSAGE)::VARCHAR, 1, 16) AS VARCHAR) AS ORDER_MELI,
          FIRST_MESSAGE,
          v.*
        FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER AS v
        LEFT JOIN U_PRJ_ECOM.ODS_VTEX_BRIDGE AS b
          ON v.MARKETPLACE_ORDER_ID = b.ID
        WHERE
          AFFILIATE_ID IN ('MMC', 'MMP')
      ) AS v
        ON p.ORIGINAL_ORDER_ID = v.ORDER_MELI
      LEFT JOIN (
        SELECT DISTINCT
          DO_NO,
          CUSTOMER_PO,
          ORDER_STATUS,
          GI_DATE,
          IOD_DATE
        FROM OW_SEDA_S_LOGISTIC.FT_CT_CELLO
      ) AS c
        ON (
          CASE
            WHEN v.ORDER_ID = c.CUSTOMER_PO
            THEN 1
            WHEN v."SEQUENCE" = c.CUSTOMER_PO
            THEN 1
            WHEN SUBSTRING((c.CUSTOMER_PO)::VARCHAR, 1, 50) = v.ORDER_ID
            THEN 1
            ELSE 0
          END
        ) = 1
      LEFT JOIN (
        SELECT DISTINCT
          ORDER_ID,
          TRACKING_NUMBER,
          TRACKING_URL,
          INVOICE_NUMBER,
          FINISHED,
          DELIVERED_DATE
        FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER_PACKAGE
      ) AS pk
        ON v.ORDER_ID = pk.ORDER_ID
      WHERE
        CHANNEL = 'MercadoLivre' AND p.STATUS IN ('canceled') AND NOT c.IOD_DATE IS NULL
    )
  )
  UNION
  (
    SELECT
      p.CHANNEL,
      '|' || CAST(p.ORIGINAL_ORDER_ID AS VARCHAR) AS ORIGINAL_ORDER_ID,
      v.ORDER_ID,
      v."SEQUENCE",
      c.DO_NO,
      p.STATUS AS STATUS_MARKETPLACE,
      v.STATUS AS STATUS_VTEX,
      c.ORDER_STATUS AS STATUS_CELLO,
      pk.TRACKING_NUMBER,
      pk.INVOICE_NUMBER,
      pk.DELIVERED_DATE,
      pk.FINISHED,
      TO_DATE((v.CREATION_TIMESTAMP)::VARCHAR, 'YYYY-MM-DD') AS CREATION_DATE,
      (c.GI_DATE)::TIMESTAMP AS GI_DATE,
      (c.IOD_DATE)::TIMESTAMP AS IOD_DATE,
      pk.TRACKING_URL
    FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p
    LEFT JOIN (
      SELECT DISTINCT
        ORDER_ID,
        MARKETPLACE_ORDER_ID,
        "SEQUENCE",
        STATUS,
        CREATION_TIMESTAMP
      FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER
    ) AS v
      ON p.ORIGINAL_ORDER_ID = v.MARKETPLACE_ORDER_ID
    LEFT JOIN (
      SELECT DISTINCT
        DO_NO,
        CUSTOMER_PO,
        ORDER_STATUS,
        GI_DATE,
        IOD_DATE
      FROM OW_SEDA_S_LOGISTIC.FT_CT_CELLO
    ) AS c
      ON (
        CASE
          WHEN v.ORDER_ID = c.CUSTOMER_PO
          THEN 1
          WHEN v."SEQUENCE" = c.CUSTOMER_PO
          THEN 1
          ELSE 0
        END
      ) = 1
    LEFT JOIN (
      SELECT DISTINCT
        ORDER_ID,
        TRACKING_NUMBER,
        TRACKING_URL,
        INVOICE_NUMBER,
        FINISHED,
        DELIVERED_DATE
      FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER_PACKAGE
    ) AS pk
      ON v.ORDER_ID = pk.ORDER_ID
    WHERE
      CHANNEL = 'Amazon.com.br' AND p.STATUS IN ('canceled') AND NOT c.IOD_DATE IS NULL
  )
)