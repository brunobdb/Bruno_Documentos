-- MISSING RELATION: _SYS_BIC
-- ERROR: Error executing query: Severity: ERROR, Message: Schema "_SYS_BIC" does not exist, Sqlstate: 3F000, Routine: RangeVarGetObjid, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Miner/server/vertica/Catalog/NamespaceLookup.cpp, Line: 317, Error Code: 4650, SQL: 'CREATE OR REPLACE VIEW "U_PRJ_ECOM"."VIEW_ECOM_HQ_ORDERS_PRODUCTS_PAYMENT_TST_BKP01112023" (   "COD_SALES_CHANNEL",   "COUNTRY_CD",   "SITE",   "SALES_APPLICATION",   "PRODUCT_CODE",   "ORDER_CODE",   "ORDER_STATUS",   "ORDER_TYPE",   "ORDER_CREATION_DATE",   "PLATFORM",   "VOUCHER_CODE",   "ITEM_TAX_AMOUNT",   "IS_TRADED_IN",   "IS_TRADE_IN_ELIGIBLE",   "IS_FINANCED_ORDER",   "IS_FINANCING_ELIGIBLE",   "IS_UPGRADE",   "IS_UPGRADE_ELIGIBLE",   "IS_SAMSUNG_CARE_ORDER",   "IS_SAMSUNG_CARE_ELIGIBLE",   "PAYMENT_METHOD_NAME",   "PAYMENT_GATEWAY",   "LAST_UPDATE",   "REMARKS",   "ORDER_ENTRY_TOTAL_PRICE",   "ORDER_ENTRY_QUANTITY",   "UNIT_LIST_PRICE",   "UNIT_SALES_PRICE",   "SALES_PRICE",   "DISCOUNT_AMOUNT" ) AS SELECT   O.COD_SALES_CHANNEL,   CASE     WHEN O."Subsidiary_Id" = 7 AND O."Country" IS NULL     THEN \'PAN\'     WHEN O."Subsidiary_Id" = 17     THEN \'FLA\'     WHEN O."Subsidiary_Id" = 16     THEN \'CAR\'     ELSE O."Country"   END AS "COUNTRY_CD",   CASE     WHEN (       O."Subsidiary_Id" = 1 AND O."ADDRESS_TYPE" = \'pickup\'     )     THEN \'O2O\'     WHEN (       O."Subsidiary_Id" = 6     )     THEN \'Samsung B2C\'     WHEN (       O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 6) = \'MKM-70\'     )     THEN \'ICBC\'     WHEN (       O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 6) = \'MKM-80\'     )     THEN \'BBVA\'     WHEN (       O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 6) = \'MKM-90\'     )     THEN \'Tienda Clic\'     WHEN (       O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 6) = \'MKM-40\'     )     THEN \'Itau\'     WHEN (       O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 6) = \'MKM-50\'     )     THEN \'Columbia\'     WHEN (       O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 6) = \'MKM-60\'     )     THEN \'Amex\'     WHEN (       O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 3) = \'MKB\'     )     THEN \'BaPro\'     WHEN (       O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 3) = \'MKM\'     )     THEN \'Mercado Libre\'     WHEN (       S."STORE_NAME" IS NULL     )     THEN \'B2C\'     ELSE S."STORE_NAME"   END AS "SITE",   CASE     WHEN (       O."Subsidiary_Id" = 3       AND O."Hostname" = \'samsungco\'       AND O."COD_SALES_CHANNEL" = \'3\'     )     THEN \'3PD\'     WHEN (       O."Subsidiary_Id" = 5       AND O."Hostname" = \'samsungpe\'       AND O."COD_SALES_CHANNEL" = \'4\'     )     THEN \'3PD\'     WHEN (       O."Subsidiary_Id" = 5       AND O."Hostname" = \'samsungpe\'       AND O."COD_SALES_CHANNEL" = \'6\'     )     THEN \'3PD\'     WHEN (       O."Subsidiary_Id" = 4       AND O."Hostname" = \'samsungmx\'       AND O."COD_SALES_CHANNEL" = \'5\'     )     THEN \'3PD\'     ELSE \'ESTORE\'   END AS "SALES_APPLICATION",   O."Reference_Code" AS "PRODUCT_CODE",   O."Order_Id" AS "ORDER_CODE",   O."Status" AS "ORDER_STATUS",   CASE     WHEN O."Channel" = \'B2E\'     THEN \'B2E\'     WHEN (       O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 3) = \'MKM\'     )     THEN \'3PD\'     WHEN (       O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 3) = \'MKB\'     )     THEN \'3PD\'     WHEN (       O."Subsidiary_Id" = 1 AND O."ADDRESS_TYPE" = \'pickup\'     )     THEN \'B2C\'     WHEN (       O."Subsidiary_Id" = 1 AND O."COD_SALES_CHANNEL" = \'8\'     )     THEN \'EPP\'     WHEN (       O."Subsidiary_Id" = 1 AND O."Hostname" = \'samsungarsmb\'     )     THEN \'SMB\'     WHEN (       O."Subsidiary_Id" = 1 AND O."Hostname" = \'samsungarestudiantes\'     )     THEN \'EPP\'     WHEN (       S."STORE_NAME" = \'ecuador_benefits_ce\'     )     THEN \'EPP\'     WHEN (       S."STORE_NAME" = \'guatemala_benefits\'     )     THEN \'EPP\'     WHEN (       S."STORE_NAME" = \'offers\'     )     THEN \'EPP\'     WHEN (       S."STORE_NAME" = \'employees\'     )     THEN \'EPP\'     ELSE \'B2C\'   END AS "ORDER_TYPE",   CAST(O."Creation_Datetime" AS VARCHAR) AS "ORDER_CREATION_DATE",   CASE     WHEN (       O."Channel" = \'SAMSUNG\'     ) OR (       O."Subsidiary_Id" = 3     )     THEN \'ESTORE\'     ELSE \'MARKETPLACE\'   END AS "PLATFORM",   \'\' AS "VOUCHER_CODE",   \'\' AS "ITEM_TAX_AMOUNT",   CASE O."IS_TRADE_IN" WHEN 1 THEN \'TRUE\' ELSE \'FALSE\' END AS "IS_TRADED_IN",   \'FALSE\' AS "IS_TRADE_IN_ELIGIBLE",   P."IS_FINANCED_ORDER" AS "IS_FINANCED_ORDER",   P."IS_FINANCED_ORDER" AS "IS_FINANCING_ELIGIBLE",   \'FALSE\' AS "IS_UPGRADE",   \'FALSE\' AS "IS_UPGRADE_ELIGIBLE",   CASE O."IS_SAMSUNG_CARE" WHEN 1 THEN \'TRUE\' ELSE \'FALSE\' END AS "IS_SAMSUNG_CARE_ORDER",   CASE WHEN (     UPPER(O."Product_Group") = \'SSG CARE\'   ) THEN \'TRUE\' ELSE \'FALSE\' END AS "IS_SAMSUNG_CARE_ELIGIBLE",   COALESCE(P."PAYMENT_METHOD", \'Undefined\') AS "PAYMENT_METHOD_NAME",   COALESCE(P."PAYMENT_METHOD", \'Undefined\') AS "PAYMENT_GATEWAY",   COALESCE(O."Last_Update_Date", O."Insert_Date") AS "LAST_UPDATE",   O."Acquirer_Message" AS "REMARKS",   SUM(O."Total_Item") AS "ORDER_ENTRY_TOTAL_PRICE",   SUM(O."Units") AS "ORDER_ENTRY_QUANTITY",   SUM(O."Price") AS "UNIT_LIST_PRICE",   SUM(O."Price") AS "UNIT_SALES_PRICE",   SUM(O."Price") AS "SALES_PRICE",   SUM(O."Item_Discount") AS "DISCOUNT_AMOUNT" FROM "_SYS_BIC"."SDSLA_ECOM/CV_ECOM_ORDERS_CUSTOMERS_PRODUCTS_O2O" AS O LEFT JOIN "U_PRJ_ECOM"."VIEW_ECOM_HQ_ORDERS_PAYMENT" AS P   ON O."ID" = P."ORDER_ID" LEFT JOIN "U_PRJ_ECOM"."DIM_ECOM_STORE" AS S   ON 1 = 1   AND COALESCE(O."Hostname", \'s3m\') = COALESCE(S."ACCOUNT", \'s3m\')   AND O."SELLER_INSTANCE_ID" = S."SELLER_INSTANCE_ID"   AND O."Subsidiary_Id" = S."SUBSIDIARY_ID"   AND NOT O."COD_SALES_CHANNEL" IS NULL   AND O."COD_SALES_CHANNEL" = S."COD_SALES_CHANNEL"   AND O."SELLER_INSTANCE_ID" = S."SELLER_INSTANCE_ID"   AND O."Subsidiary_Id" = S."SUBSIDIARY_ID" GROUP BY   O.COD_SALES_CHANNEL,   CASE     WHEN O."Subsidiary_Id" = 7 AND O."Country" IS NULL     THEN \'PAN\'     WHEN O."Subsidiary_Id" = 17     THEN \'FLA\'     WHEN O."Subsidiary_Id" = 16     THEN \'CAR\'     ELSE O."Country"   END,   CASE     WHEN (       O."Subsidiary_Id" = 1 AND O."ADDRESS_TYPE" = \'pickup\'     )     THEN \'O2O\'     WHEN (       O."Subsidiary_Id" = 6     )     THEN \'Samsung B2C\'     WHEN (       O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 6) = \'MKM-70\'     )     THEN \'ICBC\'     WHEN (       O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 6) = \'MKM-80\'     )     THEN \'BBVA\'     WHEN (       O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 6) = \'MKM-90\'     )     THEN \'Tienda Clic\'     WHEN (       O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 6) = \'MKM-40\'     )     THEN \'Itau\'     WHEN (       O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 6) = \'MKM-50\'     )     THEN \'Columbia\'     WHEN (       O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 6) = \'MKM-60\'     )     THEN \'Amex\'     WHEN (       O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 3) = \'MKB\'     )     THEN \'BaPro\'     WHEN (       O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 3) = \'MKM\'     )     THEN \'Mercado Libre\'     WHEN (       S."STORE_NAME" IS NULL     )     THEN \'B2C\'     ELSE S."STORE_NAME"   END,   CASE     WHEN (       O."Subsidiary_Id" = 3       AND O."Hostname" = \'samsungco\'       AND O."COD_SALES_CHANNEL" = \'3\'     )     THEN \'3PD\'     WHEN (       O."Subsidiary_Id" = 5       AND O."Hostname" = \'samsungpe\'       AND O."COD_SALES_CHANNEL" = \'4\'     )     THEN \'3PD\'     WHEN (       O."Subsidiary_Id" = 5       AND O."Hostname" = \'samsungpe\'       AND O."COD_SALES_CHANNEL" = \'6\'     )     THEN \'3PD\'     WHEN (       O."Subsidiary_Id" = 4       AND O."Hostname" = \'samsungmx\'       AND O."COD_SALES_CHANNEL" = \'5\'     )     THEN \'3PD\'     ELSE \'ESTORE\'   END,   O."Reference_Code",   O."Order_Id",   O."Status",   CASE     WHEN O."Channel" = \'B2E\'     THEN \'B2E\'     WHEN (       O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 3) = \'MKM\'     )     THEN \'3PD\'     WHEN (       O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 3) = \'MKB\'     )     THEN \'3PD\'     WHEN (       O."Subsidiary_Id" = 1 AND O."ADDRESS_TYPE" = \'pickup\'     )     THEN \'B2C\'     WHEN (       O."Subsidiary_Id" = 1 AND O."COD_SALES_CHANNEL" = \'8\'     )     THEN \'EPP\'     WHEN (       O."Subsidiary_Id" = 1 AND O."Hostname" = \'samsungarsmb\'     )     THEN \'SMB\'     WHEN (       O."Subsidiary_Id" = 1 AND O."Hostname" = \'samsungarestudiantes\'     )     THEN \'EPP\'     WHEN (       S."STORE_NAME" = \'ecuador_benefits_ce\'     )     THEN \'EPP\'     WHEN (       S."STORE_NAME" = \'guatemala_benefits\'     )     THEN \'EPP\'     WHEN (       S."STORE_NAME" = \'offers\'     )     THEN \'EPP\'     WHEN (       S."STORE_NAME" = \'employees\'     )     THEN \'EPP\'     ELSE \'B2C\'   END,   CAST(O."Creation_Datetime" AS VARCHAR),   CASE     WHEN (       O."Channel" = \'SAMSUNG\'     ) OR (       O."Subsidiary_Id" = 3     )     THEN \'ESTORE\'     ELSE \'MARKETPLACE\'   END,   \'\',   \'\',   CASE O."IS_TRADE_IN" WHEN 1 THEN \'TRUE\' ELSE \'FALSE\' END,   \'FALSE\',   P."IS_FINANCED_ORDER",   P."IS_FINANCED_ORDER",   \'FALSE\',   \'FALSE\',   CASE O."IS_SAMSUNG_CARE" WHEN 1 THEN \'TRUE\' ELSE \'FALSE\' END,   CASE WHEN (     UPPER(O."Product_Group") = \'SSG CARE\'   ) THEN \'TRUE\' ELSE \'FALSE\' END,   COALESCE(P."PAYMENT_METHOD", \'Undefined\'),   COALESCE(P."PAYMENT_METHOD", \'Undefined\'),   COALESCE(O."Last_Update_Date", O."Insert_Date"),   O."Acquirer_Message"'

CREATE VIEW "U_PRJ_ECOM"."VIEW_ECOM_HQ_ORDERS_PRODUCTS_PAYMENT_TST_BKP01112023" (
  "COD_SALES_CHANNEL",
  "COUNTRY_CD",
  "SITE",
  "SALES_APPLICATION",
  "PRODUCT_CODE",
  "ORDER_CODE",
  "ORDER_STATUS",
  "ORDER_TYPE",
  "ORDER_CREATION_DATE",
  "PLATFORM",
  "VOUCHER_CODE",
  "ITEM_TAX_AMOUNT",
  "IS_TRADED_IN",
  "IS_TRADE_IN_ELIGIBLE",
  "IS_FINANCED_ORDER",
  "IS_FINANCING_ELIGIBLE",
  "IS_UPGRADE",
  "IS_UPGRADE_ELIGIBLE",
  "IS_SAMSUNG_CARE_ORDER",
  "IS_SAMSUNG_CARE_ELIGIBLE",
  "PAYMENT_METHOD_NAME",
  "PAYMENT_GATEWAY",
  "LAST_UPDATE",
  "REMARKS",
  "ORDER_ENTRY_TOTAL_PRICE",
  "ORDER_ENTRY_QUANTITY",
  "UNIT_LIST_PRICE",
  "UNIT_SALES_PRICE",
  "SALES_PRICE",
  "DISCOUNT_AMOUNT"
) AS
SELECT
  O.COD_SALES_CHANNEL,
  CASE
    WHEN O."Subsidiary_Id" = 7 AND O."Country" IS NULL
    THEN 'PAN'
    WHEN O."Subsidiary_Id" = 17
    THEN 'FLA'
    WHEN O."Subsidiary_Id" = 16
    THEN 'CAR'
    ELSE O."Country"
  END AS "COUNTRY_CD",
  CASE
    WHEN (
      O."Subsidiary_Id" = 1 AND O."ADDRESS_TYPE" = 'pickup'
    )
    THEN 'O2O'
    WHEN (
      O."Subsidiary_Id" = 6
    )
    THEN 'Samsung B2C'
    WHEN (
      O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 6) = 'MKM-70'
    )
    THEN 'ICBC'
    WHEN (
      O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 6) = 'MKM-80'
    )
    THEN 'BBVA'
    WHEN (
      O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 6) = 'MKM-90'
    )
    THEN 'Tienda Clic'
    WHEN (
      O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 6) = 'MKM-40'
    )
    THEN 'Itau'
    WHEN (
      O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 6) = 'MKM-50'
    )
    THEN 'Columbia'
    WHEN (
      O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 6) = 'MKM-60'
    )
    THEN 'Amex'
    WHEN (
      O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 3) = 'MKB'
    )
    THEN 'BaPro'
    WHEN (
      O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 3) = 'MKM'
    )
    THEN 'Mercado Libre'
    WHEN (
      S."STORE_NAME" IS NULL
    )
    THEN 'B2C'
    ELSE S."STORE_NAME"
  END AS "SITE",
  CASE
    WHEN (
      O."Subsidiary_Id" = 3
      AND O."Hostname" = 'samsungco'
      AND O."COD_SALES_CHANNEL" = '3'
    )
    THEN '3PD'
    WHEN (
      O."Subsidiary_Id" = 5
      AND O."Hostname" = 'samsungpe'
      AND O."COD_SALES_CHANNEL" = '4'
    )
    THEN '3PD'
    WHEN (
      O."Subsidiary_Id" = 5
      AND O."Hostname" = 'samsungpe'
      AND O."COD_SALES_CHANNEL" = '6'
    )
    THEN '3PD'
    WHEN (
      O."Subsidiary_Id" = 4
      AND O."Hostname" = 'samsungmx'
      AND O."COD_SALES_CHANNEL" = '5'
    )
    THEN '3PD'
    ELSE 'ESTORE'
  END AS "SALES_APPLICATION",
  O."Reference_Code" AS "PRODUCT_CODE",
  O."Order_Id" AS "ORDER_CODE",
  O."Status" AS "ORDER_STATUS",
  CASE
    WHEN O."Channel" = 'B2E'
    THEN 'B2E'
    WHEN (
      O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 3) = 'MKM'
    )
    THEN '3PD'
    WHEN (
      O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 3) = 'MKB'
    )
    THEN '3PD'
    WHEN (
      O."Subsidiary_Id" = 1 AND O."ADDRESS_TYPE" = 'pickup'
    )
    THEN 'B2C'
    WHEN (
      O."Subsidiary_Id" = 1 AND O."COD_SALES_CHANNEL" = '8'
    )
    THEN 'EPP'
    WHEN (
      O."Subsidiary_Id" = 1 AND O."Hostname" = 'samsungarsmb'
    )
    THEN 'SMB'
    WHEN (
      O."Subsidiary_Id" = 1 AND O."Hostname" = 'samsungarestudiantes'
    )
    THEN 'EPP'
    WHEN (
      S."STORE_NAME" = 'ecuador_benefits_ce'
    )
    THEN 'EPP'
    WHEN (
      S."STORE_NAME" = 'guatemala_benefits'
    )
    THEN 'EPP'
    WHEN (
      S."STORE_NAME" = 'offers'
    )
    THEN 'EPP'
    WHEN (
      S."STORE_NAME" = 'employees'
    )
    THEN 'EPP'
    ELSE 'B2C'
  END AS "ORDER_TYPE",
  CAST(O."Creation_Datetime" AS VARCHAR) AS "ORDER_CREATION_DATE",
  CASE
    WHEN (
      O."Channel" = 'SAMSUNG'
    ) OR (
      O."Subsidiary_Id" = 3
    )
    THEN 'ESTORE'
    ELSE 'MARKETPLACE'
  END AS "PLATFORM",
  '' AS "VOUCHER_CODE",
  '' AS "ITEM_TAX_AMOUNT",
  CASE O."IS_TRADE_IN" WHEN 1 THEN 'TRUE' ELSE 'FALSE' END AS "IS_TRADED_IN",
  'FALSE' AS "IS_TRADE_IN_ELIGIBLE",
  P."IS_FINANCED_ORDER" AS "IS_FINANCED_ORDER",
  P."IS_FINANCED_ORDER" AS "IS_FINANCING_ELIGIBLE",
  'FALSE' AS "IS_UPGRADE",
  'FALSE' AS "IS_UPGRADE_ELIGIBLE",
  CASE O."IS_SAMSUNG_CARE" WHEN 1 THEN 'TRUE' ELSE 'FALSE' END AS "IS_SAMSUNG_CARE_ORDER",
  CASE WHEN (
    UPPER(O."Product_Group") = 'SSG CARE'
  ) THEN 'TRUE' ELSE 'FALSE' END AS "IS_SAMSUNG_CARE_ELIGIBLE",
  COALESCE(P."PAYMENT_METHOD", 'Undefined') AS "PAYMENT_METHOD_NAME",
  COALESCE(P."PAYMENT_METHOD", 'Undefined') AS "PAYMENT_GATEWAY",
  COALESCE(O."Last_Update_Date", O."Insert_Date") AS "LAST_UPDATE",
  O."Acquirer_Message" AS "REMARKS",
  SUM(O."Total_Item") AS "ORDER_ENTRY_TOTAL_PRICE",
  SUM(O."Units") AS "ORDER_ENTRY_QUANTITY",
  SUM(O."Price") AS "UNIT_LIST_PRICE",
  SUM(O."Price") AS "UNIT_SALES_PRICE",
  SUM(O."Price") AS "SALES_PRICE",
  SUM(O."Item_Discount") AS "DISCOUNT_AMOUNT"
FROM "_SYS_BIC"."SDSLA_ECOM/CV_ECOM_ORDERS_CUSTOMERS_PRODUCTS_O2O" AS O
LEFT JOIN "U_PRJ_ECOM"."VIEW_ECOM_HQ_ORDERS_PAYMENT" AS P
  ON O."ID" = P."ORDER_ID"
LEFT JOIN "U_PRJ_ECOM"."DIM_ECOM_STORE" AS S
  ON 1 = 1
  AND COALESCE(O."Hostname", 's3m') = COALESCE(S."ACCOUNT", 's3m')
  AND O."SELLER_INSTANCE_ID" = S."SELLER_INSTANCE_ID"
  AND O."Subsidiary_Id" = S."SUBSIDIARY_ID"
  AND NOT O."COD_SALES_CHANNEL" IS NULL
  AND O."COD_SALES_CHANNEL" = S."COD_SALES_CHANNEL"
  AND O."SELLER_INSTANCE_ID" = S."SELLER_INSTANCE_ID"
  AND O."Subsidiary_Id" = S."SUBSIDIARY_ID"
GROUP BY
  O.COD_SALES_CHANNEL,
  CASE
    WHEN O."Subsidiary_Id" = 7 AND O."Country" IS NULL
    THEN 'PAN'
    WHEN O."Subsidiary_Id" = 17
    THEN 'FLA'
    WHEN O."Subsidiary_Id" = 16
    THEN 'CAR'
    ELSE O."Country"
  END,
  CASE
    WHEN (
      O."Subsidiary_Id" = 1 AND O."ADDRESS_TYPE" = 'pickup'
    )
    THEN 'O2O'
    WHEN (
      O."Subsidiary_Id" = 6
    )
    THEN 'Samsung B2C'
    WHEN (
      O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 6) = 'MKM-70'
    )
    THEN 'ICBC'
    WHEN (
      O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 6) = 'MKM-80'
    )
    THEN 'BBVA'
    WHEN (
      O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 6) = 'MKM-90'
    )
    THEN 'Tienda Clic'
    WHEN (
      O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 6) = 'MKM-40'
    )
    THEN 'Itau'
    WHEN (
      O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 6) = 'MKM-50'
    )
    THEN 'Columbia'
    WHEN (
      O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 6) = 'MKM-60'
    )
    THEN 'Amex'
    WHEN (
      O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 3) = 'MKB'
    )
    THEN 'BaPro'
    WHEN (
      O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 3) = 'MKM'
    )
    THEN 'Mercado Libre'
    WHEN (
      S."STORE_NAME" IS NULL
    )
    THEN 'B2C'
    ELSE S."STORE_NAME"
  END,
  CASE
    WHEN (
      O."Subsidiary_Id" = 3
      AND O."Hostname" = 'samsungco'
      AND O."COD_SALES_CHANNEL" = '3'
    )
    THEN '3PD'
    WHEN (
      O."Subsidiary_Id" = 5
      AND O."Hostname" = 'samsungpe'
      AND O."COD_SALES_CHANNEL" = '4'
    )
    THEN '3PD'
    WHEN (
      O."Subsidiary_Id" = 5
      AND O."Hostname" = 'samsungpe'
      AND O."COD_SALES_CHANNEL" = '6'
    )
    THEN '3PD'
    WHEN (
      O."Subsidiary_Id" = 4
      AND O."Hostname" = 'samsungmx'
      AND O."COD_SALES_CHANNEL" = '5'
    )
    THEN '3PD'
    ELSE 'ESTORE'
  END,
  O."Reference_Code",
  O."Order_Id",
  O."Status",
  CASE
    WHEN O."Channel" = 'B2E'
    THEN 'B2E'
    WHEN (
      O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 3) = 'MKM'
    )
    THEN '3PD'
    WHEN (
      O."Subsidiary_Id" = 1 AND LEFT((O."Order_Id")::VARCHAR, 3) = 'MKB'
    )
    THEN '3PD'
    WHEN (
      O."Subsidiary_Id" = 1 AND O."ADDRESS_TYPE" = 'pickup'
    )
    THEN 'B2C'
    WHEN (
      O."Subsidiary_Id" = 1 AND O."COD_SALES_CHANNEL" = '8'
    )
    THEN 'EPP'
    WHEN (
      O."Subsidiary_Id" = 1 AND O."Hostname" = 'samsungarsmb'
    )
    THEN 'SMB'
    WHEN (
      O."Subsidiary_Id" = 1 AND O."Hostname" = 'samsungarestudiantes'
    )
    THEN 'EPP'
    WHEN (
      S."STORE_NAME" = 'ecuador_benefits_ce'
    )
    THEN 'EPP'
    WHEN (
      S."STORE_NAME" = 'guatemala_benefits'
    )
    THEN 'EPP'
    WHEN (
      S."STORE_NAME" = 'offers'
    )
    THEN 'EPP'
    WHEN (
      S."STORE_NAME" = 'employees'
    )
    THEN 'EPP'
    ELSE 'B2C'
  END,
  CAST(O."Creation_Datetime" AS VARCHAR),
  CASE
    WHEN (
      O."Channel" = 'SAMSUNG'
    ) OR (
      O."Subsidiary_Id" = 3
    )
    THEN 'ESTORE'
    ELSE 'MARKETPLACE'
  END,
  '',
  '',
  CASE O."IS_TRADE_IN" WHEN 1 THEN 'TRUE' ELSE 'FALSE' END,
  'FALSE',
  P."IS_FINANCED_ORDER",
  P."IS_FINANCED_ORDER",
  'FALSE',
  'FALSE',
  CASE O."IS_SAMSUNG_CARE" WHEN 1 THEN 'TRUE' ELSE 'FALSE' END,
  CASE WHEN (
    UPPER(O."Product_Group") = 'SSG CARE'
  ) THEN 'TRUE' ELSE 'FALSE' END,
  COALESCE(P."PAYMENT_METHOD", 'Undefined'),
  COALESCE(P."PAYMENT_METHOD", 'Undefined'),
  COALESCE(O."Last_Update_Date", O."Insert_Date"),
  O."Acquirer_Message"