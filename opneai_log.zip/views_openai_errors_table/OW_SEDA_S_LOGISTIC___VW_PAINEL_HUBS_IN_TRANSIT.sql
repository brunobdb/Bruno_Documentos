-- MISSING RELATION: OW_SEDA_S_LOGISTIC.ST_D2C_MASTER
-- ERROR: Error executing query: Severity: ERROR, Message: Relation "OW_SEDA_S_LOGISTIC.ST_D2C_MASTER" does not exist, Sqlstate: 42V01, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Miner/server/vertica/Catalog/CatalogLookup.cpp, Line: 4362, Error Code: 4568, SQL: 'CREATE OR REPLACE VIEW "OW_SEDA_S_LOGISTIC"."VW_PAINEL_HUBS_IN_TRANSIT" (   "DELIVERY_NO",   "GI_DATE_TIME",   "FIRST_BOOKING",   "LAST_BOOKING",   "ORIGIN",   "CARRIER_NAME",   "UF",   "PROVINCE",   "HUB_DESC",   "CLUSTER",   "TRK_TYPE",   "DIVISION",   "NEW_ETA",   "TRK_CODE",   "TRK_DATE",   "LT_ACTUAL_TRK",   "TRACKING_STATUS" ) AS WITH "DB1" AS (   SELECT     CD.DELIVERY_NO,     LEFT((CD.SHIPTO_ZIPCODE)::VARCHAR, 5) AS ZIP_TOP,     CD.GI_DATE_TIME,     CD.FIRST_BOOKING,     CD.LAST_BOOKING,     CD.ORIGIN,     CD.CARRIER_NAME,     CD.UF,     CD.PROVINCE,     TRIM(       REPLACE(         REPLACE(           CASE             WHEN CT.TRK_CODE <> \'TR4010-10\' AND CT.PARTNER_ID = \'DZ42\'             THEN CASE               WHEN STRPOS((CT.EVENT_DESC)::VARCHAR, \'-\') = 0               THEN NULL               ELSE SUBSTRING((CT.EVENT_DESC)::VARCHAR, 1)             END             WHEN CT.TRK_CODE <> \'TR4010-10\' AND CT.PARTNER_ID IN (\'EAJL\', \'H0326\')             THEN CASE               WHEN STRPOS((LOWER(CT.EVENT_DESC))::VARCHAR, \' \') > 0               THEN CASE                 WHEN LENGTH(CT.EVENT_DESC) - LENGTH(REPLACE(CT.EVENT_DESC, \' \', \'\')) = 1                 THEN CT.EVENT_DESC                 WHEN STRPOS((LOWER(CT.EVENT_DESC))::VARCHAR, \'chegada no hub\') = 0                 THEN NULL                 ELSE SUBSTRING((CT.EVENT_DESC)::VARCHAR, 1)               END               WHEN STRPOS((LOWER(CT.EVENT_DESC))::VARCHAR, \'chegada no hub\') = 0               THEN CT.EVENT_DESC               ELSE NULL             END             WHEN CT.TRK_CODE <> \'TR4010-10\' AND CT.PARTNER_ID IN (\'G7284\', \'G7186\', \'G8955\')             THEN CASE               WHEN STRPOS((LOWER(CT.EVENT_DESC))::VARCHAR, \'filial\') = 0               THEN NULL               ELSE SUBSTRING((CT.EVENT_DESC)::VARCHAR, 1)             END             WHEN CT.TRK_CODE <> \'TR4010-10\'             AND CT.PARTNER_ID IN (               \'H3889\',               \'ECTM\',               \'ECBH\',               \'EBES\',               \'G8914\',               \'H0002\',               \'EBXF\',               \'EBZA\',               \'EC01\',               \'G1344\',               \'ECT5\',               \'ECDA\',               \'H3888\',               \'EC0P\'             )             THEN CASE               WHEN STRPOS((CT.EVENT_DESC)::VARCHAR, \'unidade\') = 0               THEN NULL               ELSE SUBSTRING((CT.EVENT_DESC)::VARCHAR, 1, STRPOS((CT.EVENT_DESC)::VARCHAR, \'em\') - (                 STRPOS((CT.EVENT_DESC)::VARCHAR, \'unidade\') + LENGTH(\'unidade\') + 1               ))             END             ELSE NULL           END,           \' \',           \' \'         ),         \' \',         \' \'       )     ) AS HUB_DESC,     CASE       WHEN CT.TRK_CODE = \'GI\'       THEN \'Waiting collect\'       WHEN CT.TRK_CODE = \'TOD10\'       THEN \'Collect by carrier\'       WHEN CT.TRK_CODE = \'TOD20\'       THEN \'Arrival at hub\'       WHEN CT.TRK_CODE = \'TOD30\'       THEN \'Departure from hub\'       WHEN CT.TRK_CODE = \'TOD40\'       THEN \'Arrival at final hub\'       WHEN CT.TRK_CODE = \'TOD50_1\'       THEN \'1st Departure for customer\'       WHEN CT.TRK_CODE = \'OCC_1\'       THEN \'1st Occurrence\'       WHEN CT.TRK_CODE = \'TOD50_2\'       THEN \'2nd Departure for customer\'       WHEN CT.TRK_CODE = \'OCC_2\'       THEN \'2nd Occurrence\'       WHEN CT.TRK_CODE = \'TOD50_3\'       THEN \'3rd Departure for customer\'       WHEN CT.TRK_CODE = \'OCC_3\'       THEN \'3rd Occurrence\'       WHEN CT.TRK_CODE = \'TR4010-10\'       THEN \'IOD\'       ELSE NULL     END AS TRK_TYPE,     CD.DIVISION,     CD.NEW_ETA,     CT.TRK_CODE,     CT.TRK_DATE,     CASE       WHEN SECONDS_BETWEEN(CT.TRK_DATE, CURRENT_TIMESTAMP) / 3600 / 24 > (         SELECT           COUNT(*)         FROM OW_SEDA_S_LOGISTIC.ST_CALENDARIO         WHERE           DIA BETWEEN TO_DATE((CT.TRK_DATE)::VARCHAR, \'YYYY-MM-DD\') AND TO_DATE((CURRENT_TIMESTAMP)::VARCHAR, \'YYYY-MM-DD\')           AND DIA_UTIL = 0       )       THEN (         SECONDS_BETWEEN(CT.TRK_DATE, CURRENT_TIMESTAMP) / 3600 / 24       ) - (         SELECT           COUNT(*)         FROM OW_SEDA_S_LOGISTIC.ST_CALENDARIO         WHERE           DIA BETWEEN TO_DATE((CT.TRK_DATE)::VARCHAR, \'YYYY-MM-DD\') AND TO_DATE((CURRENT_TIMESTAMP)::VARCHAR, \'YYYY-MM-DD\')           AND DIA_UTIL = 0       )       ELSE SECONDS_BETWEEN(CT.TRK_DATE, CURRENT_TIMESTAMP) / 3600 / 24     END AS LT_ACTUAL_TRK,     CD.TRACKING_STATUS   FROM OW_SEDA_S_LOGISTIC.ST_D2C_MASTER AS CD   LEFT JOIN (     SELECT       DELIVERY_NO,       TRK_CODE,       PARTNER_ID,       EVENT_DESC,       (TRK_DATE)::TIMESTAMP AS TRK_DATE,       ROW_NUMBER() OVER (PARTITION BY DELIVERY_NO ORDER BY TRK_DATE DESC) AS rn     FROM OW_SEDA_S_LOGISTIC.ST_CELLO_TK_HUBS_TRATADA   ) AS CT     ON CD.DELIVERY_NO = CT.DELIVERY_NO AND CT.rn = 1   WHERE     CD.TRACKING_STATUS = \'Transit\' ) SELECT   DM.DELIVERY_NO,   DM.GI_DATE_TIME,   DM.FIRST_BOOKING,   DM.LAST_BOOKING,   DM.ORIGIN,   DM.CARRIER_NAME,   DM.UF,   DM.PROVINCE,   CASE     WHEN DM.TRK_CODE IN (\'TOD40\', \'TOD50_1\', \'TOD50_2\', \'TOD50_3\', \'OCC_1\', \'OCC_2\', \'OCC_3\')     AND DM.HUB_DESC IS NULL     THEN RC.INTERMEDIARIA_CLUSTER     WHEN DM.TRK_CODE IN (\'GI\', \'TOD10\')     THEN DM.ORIGIN     ELSE DM.HUB_DESC   END AS HUB_DESC,   RC.INTERMEDIARIA_CLUSTER AS CLUSTER,   DM.TRK_TYPE,   DM.DIVISION,   DM.NEW_ETA,   DM.TRK_CODE,   DM.TRK_DATE,   DM.LT_ACTUAL_TRK,   DM.TRACKING_STATUS FROM DB1 AS DM LEFT JOIN OW_SEDA_S_LOGISTIC.ST_REGION_CLUSTER AS RC   ON DM.ZIP_TOP = RC.ZIP_TOP'

CREATE VIEW "OW_SEDA_S_LOGISTIC"."VW_PAINEL_HUBS_IN_TRANSIT" (
  "DELIVERY_NO",
  "GI_DATE_TIME",
  "FIRST_BOOKING",
  "LAST_BOOKING",
  "ORIGIN",
  "CARRIER_NAME",
  "UF",
  "PROVINCE",
  "HUB_DESC",
  "CLUSTER",
  "TRK_TYPE",
  "DIVISION",
  "NEW_ETA",
  "TRK_CODE",
  "TRK_DATE",
  "LT_ACTUAL_TRK",
  "TRACKING_STATUS"
) AS
WITH "DB1" AS (
  SELECT
    CD.DELIVERY_NO,
    LEFT((CD.SHIPTO_ZIPCODE)::VARCHAR, 5) AS ZIP_TOP,
    CD.GI_DATE_TIME,
    CD.FIRST_BOOKING,
    CD.LAST_BOOKING,
    CD.ORIGIN,
    CD.CARRIER_NAME,
    CD.UF,
    CD.PROVINCE,
    TRIM(
      REPLACE(
        REPLACE(
          CASE
            WHEN CT.TRK_CODE <> 'TR4010-10' AND CT.PARTNER_ID = 'DZ42'
            THEN CASE
              WHEN STRPOS((CT.EVENT_DESC)::VARCHAR, '-') = 0
              THEN NULL
              ELSE SUBSTRING((CT.EVENT_DESC)::VARCHAR, 1)
            END
            WHEN CT.TRK_CODE <> 'TR4010-10' AND CT.PARTNER_ID IN ('EAJL', 'H0326')
            THEN CASE
              WHEN STRPOS((LOWER(CT.EVENT_DESC))::VARCHAR, ' ') > 0
              THEN CASE
                WHEN LENGTH(CT.EVENT_DESC) - LENGTH(REPLACE(CT.EVENT_DESC, ' ', '')) = 1
                THEN CT.EVENT_DESC
                WHEN STRPOS((LOWER(CT.EVENT_DESC))::VARCHAR, 'chegada no hub') = 0
                THEN NULL
                ELSE SUBSTRING((CT.EVENT_DESC)::VARCHAR, 1)
              END
              WHEN STRPOS((LOWER(CT.EVENT_DESC))::VARCHAR, 'chegada no hub') = 0
              THEN CT.EVENT_DESC
              ELSE NULL
            END
            WHEN CT.TRK_CODE <> 'TR4010-10' AND CT.PARTNER_ID IN ('G7284', 'G7186', 'G8955')
            THEN CASE
              WHEN STRPOS((LOWER(CT.EVENT_DESC))::VARCHAR, 'filial') = 0
              THEN NULL
              ELSE SUBSTRING((CT.EVENT_DESC)::VARCHAR, 1)
            END
            WHEN CT.TRK_CODE <> 'TR4010-10'
            AND CT.PARTNER_ID IN (
              'H3889',
              'ECTM',
              'ECBH',
              'EBES',
              'G8914',
              'H0002',
              'EBXF',
              'EBZA',
              'EC01',
              'G1344',
              'ECT5',
              'ECDA',
              'H3888',
              'EC0P'
            )
            THEN CASE
              WHEN STRPOS((CT.EVENT_DESC)::VARCHAR, 'unidade') = 0
              THEN NULL
              ELSE SUBSTRING((CT.EVENT_DESC)::VARCHAR, 1, STRPOS((CT.EVENT_DESC)::VARCHAR, 'em') - (
                STRPOS((CT.EVENT_DESC)::VARCHAR, 'unidade') + LENGTH('unidade') + 1
              ))
            END
            ELSE NULL
          END,
          ' ',
          ' '
        ),
        ' ',
        ' '
      )
    ) AS HUB_DESC,
    CASE
      WHEN CT.TRK_CODE = 'GI'
      THEN 'Waiting collect'
      WHEN CT.TRK_CODE = 'TOD10'
      THEN 'Collect by carrier'
      WHEN CT.TRK_CODE = 'TOD20'
      THEN 'Arrival at hub'
      WHEN CT.TRK_CODE = 'TOD30'
      THEN 'Departure from hub'
      WHEN CT.TRK_CODE = 'TOD40'
      THEN 'Arrival at final hub'
      WHEN CT.TRK_CODE = 'TOD50_1'
      THEN '1st Departure for customer'
      WHEN CT.TRK_CODE = 'OCC_1'
      THEN '1st Occurrence'
      WHEN CT.TRK_CODE = 'TOD50_2'
      THEN '2nd Departure for customer'
      WHEN CT.TRK_CODE = 'OCC_2'
      THEN '2nd Occurrence'
      WHEN CT.TRK_CODE = 'TOD50_3'
      THEN '3rd Departure for customer'
      WHEN CT.TRK_CODE = 'OCC_3'
      THEN '3rd Occurrence'
      WHEN CT.TRK_CODE = 'TR4010-10'
      THEN 'IOD'
      ELSE NULL
    END AS TRK_TYPE,
    CD.DIVISION,
    CD.NEW_ETA,
    CT.TRK_CODE,
    CT.TRK_DATE,
    CASE
      WHEN SECONDS_BETWEEN(CT.TRK_DATE, CURRENT_TIMESTAMP) / 3600 / 24 > (
        SELECT
          COUNT(*)
        FROM OW_SEDA_S_LOGISTIC.ST_CALENDARIO
        WHERE
          DIA BETWEEN TO_DATE((CT.TRK_DATE)::VARCHAR, 'YYYY-MM-DD') AND TO_DATE((CURRENT_TIMESTAMP)::VARCHAR, 'YYYY-MM-DD')
          AND DIA_UTIL = 0
      )
      THEN (
        SECONDS_BETWEEN(CT.TRK_DATE, CURRENT_TIMESTAMP) / 3600 / 24
      ) - (
        SELECT
          COUNT(*)
        FROM OW_SEDA_S_LOGISTIC.ST_CALENDARIO
        WHERE
          DIA BETWEEN TO_DATE((CT.TRK_DATE)::VARCHAR, 'YYYY-MM-DD') AND TO_DATE((CURRENT_TIMESTAMP)::VARCHAR, 'YYYY-MM-DD')
          AND DIA_UTIL = 0
      )
      ELSE SECONDS_BETWEEN(CT.TRK_DATE, CURRENT_TIMESTAMP) / 3600 / 24
    END AS LT_ACTUAL_TRK,
    CD.TRACKING_STATUS
  FROM OW_SEDA_S_LOGISTIC.ST_D2C_MASTER AS CD
  LEFT JOIN (
    SELECT
      DELIVERY_NO,
      TRK_CODE,
      PARTNER_ID,
      EVENT_DESC,
      (TRK_DATE)::TIMESTAMP AS TRK_DATE,
      ROW_NUMBER() OVER (PARTITION BY DELIVERY_NO ORDER BY TRK_DATE DESC) AS rn
    FROM OW_SEDA_S_LOGISTIC.ST_CELLO_TK_HUBS_TRATADA
  ) AS CT
    ON CD.DELIVERY_NO = CT.DELIVERY_NO AND CT.rn = 1
  WHERE
    CD.TRACKING_STATUS = 'Transit'
)
SELECT
  DM.DELIVERY_NO,
  DM.GI_DATE_TIME,
  DM.FIRST_BOOKING,
  DM.LAST_BOOKING,
  DM.ORIGIN,
  DM.CARRIER_NAME,
  DM.UF,
  DM.PROVINCE,
  CASE
    WHEN DM.TRK_CODE IN ('TOD40', 'TOD50_1', 'TOD50_2', 'TOD50_3', 'OCC_1', 'OCC_2', 'OCC_3')
    AND DM.HUB_DESC IS NULL
    THEN RC.INTERMEDIARIA_CLUSTER
    WHEN DM.TRK_CODE IN ('GI', 'TOD10')
    THEN DM.ORIGIN
    ELSE DM.HUB_DESC
  END AS HUB_DESC,
  RC.INTERMEDIARIA_CLUSTER AS CLUSTER,
  DM.TRK_TYPE,
  DM.DIVISION,
  DM.NEW_ETA,
  DM.TRK_CODE,
  DM.TRK_DATE,
  DM.LT_ACTUAL_TRK,
  DM.TRACKING_STATUS
FROM DB1 AS DM
LEFT JOIN OW_SEDA_S_LOGISTIC.ST_REGION_CLUSTER AS RC
  ON DM.ZIP_TOP = RC.ZIP_TOP