-- MISSING RELATION: OW_SEDA_S_LOGISTIC.ST_PAINEL_HUBS_IN_TRANSIT
-- ERROR: Error executing query: Severity: ERROR, Message: Relation "OW_SEDA_S_LOGISTIC.ST_PAINEL_HUBS_IN_TRANSIT" does not exist, Sqlstate: 42V01, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Miner/server/vertica/Catalog/CatalogLookup.cpp, Line: 4362, Error Code: 4568, SQL: 'CREATE OR REPLACE VIEW "OW_SEDA_S_LOGISTIC"."VW_PAINEL_HUBS_IN_TRANSIT_ALL_TRK" (   "DELIVERY_NO",   "PARTNER_ID",   "TRK_CODE",   "FIRST_BOOKING",   "TRK_DATE",   "EVENT_DESC",   "DELTA_T_LEAD",   "DELTA_T_LEAD_ACUM",   "ORIGIN",   "UF",   "PROVINCE",   "TRK_TYPE",   "CARRIER_NAME",   "DIVISION",   "NEW_ETA",   "LT_ACTUAL_TRK",   "HUB_DESC",   "FIRST_OCC",   "NEXT_ACTION_NM",   "LAST_EVENT",   "RESPONSIBLE",   "RESPONSIBLE_2",   "FAILURE_REASON",   "ISSUE",   "AGROUP" ) AS WITH "DB2" AS (   WITH "CT_DELTA" AS (     SELECT       PF.DELIVERY_NO,       LEFT((MQ.SHIPTO_ZIPCODE)::VARCHAR, 5) AS ZIP_TOP,       PF.GI_DATE_TIME,       PF.FIRST_BOOKING,       PF.ORIGIN,       PF.CARRIER_NAME,       PF.UF,       PF.PROVINCE,       PF.DIVISION,       PF.NEW_ETA,       PF.LT_ACTUAL_TRK,       PF.TRACKING_STATUS,       CT.TRK_CODE,       CT.PARTNER_ID,       CT.EVENT_DESC,       (CT.TRK_DATE)::TIMESTAMP AS TRK_DATE,       CASE         WHEN CT.TRK_CODE = \'TR4010-10\'         THEN NULL         ELSE SECONDS_BETWEEN(           CT.TRK_DATE,           LEAD(CT.TRK_DATE) OVER (PARTITION BY CT.DELIVERY_NO ORDER BY CT.TRK_DATE ASC)         ) / 3600 / 24       END AS DELTA_T_LEAD,       CASE         WHEN CT.TRK_CODE = \'GI\'         THEN \'Waiting collect\'         WHEN CT.TRK_CODE = \'TOD10\'         THEN \'Collect by carrier\'         WHEN CT.TRK_CODE = \'TOD20\'         THEN \'Arrival at hub\'         WHEN CT.TRK_CODE = \'TOD30\'         THEN \'Departure from hub\'         WHEN CT.TRK_CODE = \'TOD40\'         THEN \'Arrival at final hub\'         WHEN CT.TRK_CODE = \'TOD50_1\'         THEN \'1st Departure for customer\'         WHEN CT.TRK_CODE = \'OCC_1\'         THEN \'1st Occurrence\'         WHEN CT.TRK_CODE = \'TOD50_2\'         THEN \'2nd Departure for customer\'         WHEN CT.TRK_CODE = \'OCC_2\'         THEN \'2nd Occurrence\'         WHEN CT.TRK_CODE = \'TOD50_3\'         THEN \'3rd Departure for customer\'         WHEN CT.TRK_CODE = \'OCC_3\'         THEN \'3rd Occurrence\'         WHEN CT.TRK_CODE = \'TR4010-10\'         THEN \'IOD\'         ELSE NULL       END AS TRK_TYPE,       CASE         WHEN CT.TRK_CODE <> \'TR4010-10\' AND CT.PARTNER_ID = \'DZ42\'         THEN CASE           WHEN STRPOS((CT.EVENT_DESC)::VARCHAR, \'-\') = 0           THEN NULL           ELSE SUBSTRING((CT.EVENT_DESC)::VARCHAR, 1)         END         WHEN CT.TRK_CODE <> \'TR4010-10\' AND PARTNER_ID IN (\'EAJL\', \'H0326\')         THEN CASE           WHEN STRPOS((LOWER(CT.EVENT_DESC))::VARCHAR, \' \') > 0           THEN CASE             WHEN LENGTH(CT.EVENT_DESC) - LENGTH(REPLACE(CT.EVENT_DESC, \' \', \'\')) = 1             THEN CT.EVENT_DESC             WHEN STRPOS((LOWER(CT.EVENT_DESC))::VARCHAR, \'chegada no hub\') = 0             THEN NULL             ELSE SUBSTRING((CT.EVENT_DESC)::VARCHAR, 1)           END           WHEN STRPOS((LOWER(CT.EVENT_DESC))::VARCHAR, \'chegada no hub\') = 0           THEN CT.EVENT_DESC           ELSE NULL         END         WHEN CT.TRK_CODE <> \'TR4010-10\' AND CT.PARTNER_ID IN (\'G7284\', \'G7186\', \'G8955\')         THEN CASE           WHEN STRPOS((LOWER(CT.EVENT_DESC))::VARCHAR, \'filial\') = 0           THEN NULL           ELSE SUBSTRING((CT.EVENT_DESC)::VARCHAR, 1)         END         WHEN CT.TRK_CODE <> \'TR4010-10\'         AND CT.PARTNER_ID IN (           \'H3889\',           \'ECTM\',           \'ECBH\',           \'EBES\',           \'G8914\',           \'H0002\',           \'EBXF\',           \'EBZA\',           \'EC01\',           \'G1344\',           \'ECT5\',           \'ECDA\',           \'H3888\',           \'EC0P\'         )         THEN CASE           WHEN STRPOS((CT.EVENT_DESC)::VARCHAR, \'unidade\') = 0           THEN NULL           ELSE SUBSTRING((CT.EVENT_DESC)::VARCHAR, 1, STRPOS((CT.EVENT_DESC)::VARCHAR, \'em\') - (             STRPOS((CT.EVENT_DESC)::VARCHAR, \'unidade\') + LENGTH(\'unidade\') + 1           ))         END         ELSE NULL       END AS HUB_DESC,       MQ.FIRST_OCC,       MQ.NEXT_ACTION_NM,       MQ.LAST_EVENT,       FR.RESPONSIBLE,       FR.RESPONSIBLE_2,       FR.FAILURE_REASON,       FR.ISSUE     FROM OW_SEDA_S_LOGISTIC.ST_PAINEL_HUBS_IN_TRANSIT AS PF     LEFT JOIN OW_SEDA_S_LOGISTIC.ST_CELLO_TK_HUBS_TRATADA AS CT       ON PF.DELIVERY_NO = CT.DELIVERY_NO     LEFT JOIN (       SELECT         DELIVERY_NO,         SHIPTO_ZIPCODE,         FIRST_OCC,         NEXT_ACTION_NM,         LAST_EVENT       FROM OW_SEDA_S_LOGISTIC.ST_D2C_MASTER AS MQ     ) AS MQ       ON CT.DELIVERY_NO = MQ.DELIVERY_NO     LEFT JOIN OW_SEDA_S_LOGISTIC.ST_DELIVERY_FAILURE_REASON AS FR       ON REPLACE(LOWER(MQ.FIRST_OCC), \'\'\'\', \'\') = LOWER(FR.FIRST_OCCR)   )   SELECT DISTINCT     DM.DELIVERY_NO,     DM.PARTNER_ID,     DM.TRK_CODE,     DM.FIRST_BOOKING,     DM.TRK_DATE,     DM.EVENT_DESC,     DM.DELTA_T_LEAD,     FLOOR(       SUM(DM.DELTA_T_LEAD) OVER (         PARTITION BY DM.DELIVERY_NO         ORDER BY DM.TRK_DATE         ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING       )     ) AS DELTA_T_LEAD_ACUM,     DM.ORIGIN,     DM.UF,     DM.PROVINCE,     DM.TRK_TYPE,     DM.CARRIER_NAME,     DM.DIVISION,     DM.NEW_ETA,     DM.LT_ACTUAL_TRK,     TRIM(       REPLACE(         REPLACE(           CASE             WHEN DM.TRK_CODE IN (\'TOD40\', \'TOD50_1\', \'TOD50_2\', \'TOD50_3\', \'OCC_1\', \'OCC_2\', \'OCC_3\')             AND DM.HUB_DESC IS NULL             THEN RC.INTERMEDIARIA_CLUSTER             WHEN DM.TRK_CODE IN (\'GI\', \'TOD10\')             THEN DM.ORIGIN             ELSE DM.HUB_DESC           END,           \' \',           \' \'         ),         \' \',         \' \'       )     ) AS HUB_DESC,     DM.FIRST_OCC,     DM.NEXT_ACTION_NM,     DM.LAST_EVENT,     DM.RESPONSIBLE,     DM.RESPONSIBLE_2,     DM.FAILURE_REASON,     DM.ISSUE   FROM CT_DELTA AS DM   LEFT JOIN OW_SEDA_S_LOGISTIC.ST_REGION_CLUSTER AS RC     ON DM.ZIP_TOP = RC.ZIP_TOP ) SELECT   "DB2"."DELIVERY_NO",   "DB2"."PARTNER_ID",   "DB2"."TRK_CODE",   "DB2"."FIRST_BOOKING",   "DB2"."TRK_DATE",   "DB2"."EVENT_DESC",   "DB2"."DELTA_T_LEAD",   "DB2"."DELTA_T_LEAD_ACUM",   "DB2"."ORIGIN",   "DB2"."UF",   "DB2"."PROVINCE",   "DB2"."TRK_TYPE",   "DB2"."CARRIER_NAME",   "DB2"."DIVISION",   "DB2"."NEW_ETA",   "DB2"."LT_ACTUAL_TRK",   "DB2"."HUB_DESC",   "DB2"."FIRST_OCC",   "DB2"."NEXT_ACTION_NM",   "DB2"."LAST_EVENT",   "DB2"."RESPONSIBLE",   "DB2"."RESPONSIBLE_2",   "DB2"."FAILURE_REASON",   "DB2"."ISSUE",   CASE     WHEN PROVINCE IS NULL AND HUB_DESC IS NULL     THEN ORIGIN || CARRIER_NAME || TRK_TYPE     WHEN PROVINCE IS NULL AND NOT HUB_DESC IS NULL     THEN ORIGIN || CARRIER_NAME || HUB_DESC || TRK_TYPE     WHEN NOT PROVINCE IS NULL AND HUB_DESC IS NULL     THEN ORIGIN || CARRIER_NAME || UF || PROVINCE || TRK_TYPE     ELSE ORIGIN || CARRIER_NAME || UF || PROVINCE || HUB_DESC || TRK_TYPE   END AS AGROUP FROM DB2'

CREATE VIEW "OW_SEDA_S_LOGISTIC"."VW_PAINEL_HUBS_IN_TRANSIT_ALL_TRK" (
  "DELIVERY_NO",
  "PARTNER_ID",
  "TRK_CODE",
  "FIRST_BOOKING",
  "TRK_DATE",
  "EVENT_DESC",
  "DELTA_T_LEAD",
  "DELTA_T_LEAD_ACUM",
  "ORIGIN",
  "UF",
  "PROVINCE",
  "TRK_TYPE",
  "CARRIER_NAME",
  "DIVISION",
  "NEW_ETA",
  "LT_ACTUAL_TRK",
  "HUB_DESC",
  "FIRST_OCC",
  "NEXT_ACTION_NM",
  "LAST_EVENT",
  "RESPONSIBLE",
  "RESPONSIBLE_2",
  "FAILURE_REASON",
  "ISSUE",
  "AGROUP"
) AS
WITH "DB2" AS (
  WITH "CT_DELTA" AS (
    SELECT
      PF.DELIVERY_NO,
      LEFT((MQ.SHIPTO_ZIPCODE)::VARCHAR, 5) AS ZIP_TOP,
      PF.GI_DATE_TIME,
      PF.FIRST_BOOKING,
      PF.ORIGIN,
      PF.CARRIER_NAME,
      PF.UF,
      PF.PROVINCE,
      PF.DIVISION,
      PF.NEW_ETA,
      PF.LT_ACTUAL_TRK,
      PF.TRACKING_STATUS,
      CT.TRK_CODE,
      CT.PARTNER_ID,
      CT.EVENT_DESC,
      (CT.TRK_DATE)::TIMESTAMP AS TRK_DATE,
      CASE
        WHEN CT.TRK_CODE = 'TR4010-10'
        THEN NULL
        ELSE SECONDS_BETWEEN(
          CT.TRK_DATE,
          LEAD(CT.TRK_DATE) OVER (PARTITION BY CT.DELIVERY_NO ORDER BY CT.TRK_DATE ASC)
        ) / 3600 / 24
      END AS DELTA_T_LEAD,
      CASE
        WHEN CT.TRK_CODE = 'GI'
        THEN 'Waiting collect'
        WHEN CT.TRK_CODE = 'TOD10'
        THEN 'Collect by carrier'
        WHEN CT.TRK_CODE = 'TOD20'
        THEN 'Arrival at hub'
        WHEN CT.TRK_CODE = 'TOD30'
        THEN 'Departure from hub'
        WHEN CT.TRK_CODE = 'TOD40'
        THEN 'Arrival at final hub'
        WHEN CT.TRK_CODE = 'TOD50_1'
        THEN '1st Departure for customer'
        WHEN CT.TRK_CODE = 'OCC_1'
        THEN '1st Occurrence'
        WHEN CT.TRK_CODE = 'TOD50_2'
        THEN '2nd Departure for customer'
        WHEN CT.TRK_CODE = 'OCC_2'
        THEN '2nd Occurrence'
        WHEN CT.TRK_CODE = 'TOD50_3'
        THEN '3rd Departure for customer'
        WHEN CT.TRK_CODE = 'OCC_3'
        THEN '3rd Occurrence'
        WHEN CT.TRK_CODE = 'TR4010-10'
        THEN 'IOD'
        ELSE NULL
      END AS TRK_TYPE,
      CASE
        WHEN CT.TRK_CODE <> 'TR4010-10' AND CT.PARTNER_ID = 'DZ42'
        THEN CASE
          WHEN STRPOS((CT.EVENT_DESC)::VARCHAR, '-') = 0
          THEN NULL
          ELSE SUBSTRING((CT.EVENT_DESC)::VARCHAR, 1)
        END
        WHEN CT.TRK_CODE <> 'TR4010-10' AND PARTNER_ID IN ('EAJL', 'H0326')
        THEN CASE
          WHEN STRPOS((LOWER(CT.EVENT_DESC))::VARCHAR, ' ') > 0
          THEN CASE
            WHEN LENGTH(CT.EVENT_DESC) - LENGTH(REPLACE(CT.EVENT_DESC, ' ', '')) = 1
            THEN CT.EVENT_DESC
            WHEN STRPOS((LOWER(CT.EVENT_DESC))::VARCHAR, 'chegada no hub') = 0
            THEN NULL
            ELSE SUBSTRING((CT.EVENT_DESC)::VARCHAR, 1)
          END
          WHEN STRPOS((LOWER(CT.EVENT_DESC))::VARCHAR, 'chegada no hub') = 0
          THEN CT.EVENT_DESC
          ELSE NULL
        END
        WHEN CT.TRK_CODE <> 'TR4010-10' AND CT.PARTNER_ID IN ('G7284', 'G7186', 'G8955')
        THEN CASE
          WHEN STRPOS((LOWER(CT.EVENT_DESC))::VARCHAR, 'filial') = 0
          THEN NULL
          ELSE SUBSTRING((CT.EVENT_DESC)::VARCHAR, 1)
        END
        WHEN CT.TRK_CODE <> 'TR4010-10'
        AND CT.PARTNER_ID IN (
          'H3889',
          'ECTM',
          'ECBH',
          'EBES',
          'G8914',
          'H0002',
          'EBXF',
          'EBZA',
          'EC01',
          'G1344',
          'ECT5',
          'ECDA',
          'H3888',
          'EC0P'
        )
        THEN CASE
          WHEN STRPOS((CT.EVENT_DESC)::VARCHAR, 'unidade') = 0
          THEN NULL
          ELSE SUBSTRING((CT.EVENT_DESC)::VARCHAR, 1, STRPOS((CT.EVENT_DESC)::VARCHAR, 'em') - (
            STRPOS((CT.EVENT_DESC)::VARCHAR, 'unidade') + LENGTH('unidade') + 1
          ))
        END
        ELSE NULL
      END AS HUB_DESC,
      MQ.FIRST_OCC,
      MQ.NEXT_ACTION_NM,
      MQ.LAST_EVENT,
      FR.RESPONSIBLE,
      FR.RESPONSIBLE_2,
      FR.FAILURE_REASON,
      FR.ISSUE
    FROM OW_SEDA_S_LOGISTIC.ST_PAINEL_HUBS_IN_TRANSIT AS PF
    LEFT JOIN OW_SEDA_S_LOGISTIC.ST_CELLO_TK_HUBS_TRATADA AS CT
      ON PF.DELIVERY_NO = CT.DELIVERY_NO
    LEFT JOIN (
      SELECT
        DELIVERY_NO,
        SHIPTO_ZIPCODE,
        FIRST_OCC,
        NEXT_ACTION_NM,
        LAST_EVENT
      FROM OW_SEDA_S_LOGISTIC.ST_D2C_MASTER AS MQ
    ) AS MQ
      ON CT.DELIVERY_NO = MQ.DELIVERY_NO
    LEFT JOIN OW_SEDA_S_LOGISTIC.ST_DELIVERY_FAILURE_REASON AS FR
      ON REPLACE(LOWER(MQ.FIRST_OCC), '''', '') = LOWER(FR.FIRST_OCCR)
  )
  SELECT DISTINCT
    DM.DELIVERY_NO,
    DM.PARTNER_ID,
    DM.TRK_CODE,
    DM.FIRST_BOOKING,
    DM.TRK_DATE,
    DM.EVENT_DESC,
    DM.DELTA_T_LEAD,
    FLOOR(
      SUM(DM.DELTA_T_LEAD) OVER (
        PARTITION BY DM.DELIVERY_NO
        ORDER BY DM.TRK_DATE
        ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING
      )
    ) AS DELTA_T_LEAD_ACUM,
    DM.ORIGIN,
    DM.UF,
    DM.PROVINCE,
    DM.TRK_TYPE,
    DM.CARRIER_NAME,
    DM.DIVISION,
    DM.NEW_ETA,
    DM.LT_ACTUAL_TRK,
    TRIM(
      REPLACE(
        REPLACE(
          CASE
            WHEN DM.TRK_CODE IN ('TOD40', 'TOD50_1', 'TOD50_2', 'TOD50_3', 'OCC_1', 'OCC_2', 'OCC_3')
            AND DM.HUB_DESC IS NULL
            THEN RC.INTERMEDIARIA_CLUSTER
            WHEN DM.TRK_CODE IN ('GI', 'TOD10')
            THEN DM.ORIGIN
            ELSE DM.HUB_DESC
          END,
          ' ',
          ' '
        ),
        ' ',
        ' '
      )
    ) AS HUB_DESC,
    DM.FIRST_OCC,
    DM.NEXT_ACTION_NM,
    DM.LAST_EVENT,
    DM.RESPONSIBLE,
    DM.RESPONSIBLE_2,
    DM.FAILURE_REASON,
    DM.ISSUE
  FROM CT_DELTA AS DM
  LEFT JOIN OW_SEDA_S_LOGISTIC.ST_REGION_CLUSTER AS RC
    ON DM.ZIP_TOP = RC.ZIP_TOP
)
SELECT
  "DB2"."DELIVERY_NO",
  "DB2"."PARTNER_ID",
  "DB2"."TRK_CODE",
  "DB2"."FIRST_BOOKING",
  "DB2"."TRK_DATE",
  "DB2"."EVENT_DESC",
  "DB2"."DELTA_T_LEAD",
  "DB2"."DELTA_T_LEAD_ACUM",
  "DB2"."ORIGIN",
  "DB2"."UF",
  "DB2"."PROVINCE",
  "DB2"."TRK_TYPE",
  "DB2"."CARRIER_NAME",
  "DB2"."DIVISION",
  "DB2"."NEW_ETA",
  "DB2"."LT_ACTUAL_TRK",
  "DB2"."HUB_DESC",
  "DB2"."FIRST_OCC",
  "DB2"."NEXT_ACTION_NM",
  "DB2"."LAST_EVENT",
  "DB2"."RESPONSIBLE",
  "DB2"."RESPONSIBLE_2",
  "DB2"."FAILURE_REASON",
  "DB2"."ISSUE",
  CASE
    WHEN PROVINCE IS NULL AND HUB_DESC IS NULL
    THEN ORIGIN || CARRIER_NAME || TRK_TYPE
    WHEN PROVINCE IS NULL AND NOT HUB_DESC IS NULL
    THEN ORIGIN || CARRIER_NAME || HUB_DESC || TRK_TYPE
    WHEN NOT PROVINCE IS NULL AND HUB_DESC IS NULL
    THEN ORIGIN || CARRIER_NAME || UF || PROVINCE || TRK_TYPE
    ELSE ORIGIN || CARRIER_NAME || UF || PROVINCE || HUB_DESC || TRK_TYPE
  END AS AGROUP
FROM DB2