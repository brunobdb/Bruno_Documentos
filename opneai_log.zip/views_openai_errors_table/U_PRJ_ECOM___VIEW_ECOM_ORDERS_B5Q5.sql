-- MISSING RELATION: _SYS_BIC
-- ERROR: Error executing query: Severity: ERROR, Message: Schema "_SYS_BIC" does not exist, Sqlstate: 3F000, Routine: RangeVarGetObjid, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Miner/server/vertica/Catalog/NamespaceLookup.cpp, Line: 317, Error Code: 4650, SQL: 'CREATE OR REPLACE VIEW "U_PRJ_ECOM"."VIEW_ECOM_ORDERS_B5Q5" (   "Acquirer_Message",   "CODIGO_PARCERIA",   "AFFILIATE_ID",   "ADDRESS_TYPE",   "Cancellation_Reason",   "Category",   "Channel",   "COD_SALES_CHANNEL",   "Country",   "Creation_Date",   "IS_TRADE_IN",   "IS_SAMSUNG_CARE",   "Last_Update_Date",   "CUSTOMER_ID",   "Division",   "Hostname",   "Internal_Status",   "Status",   "Invoice_Number",   "Mkt_Campaign_Tags",   "Mkt_Utm_Campaign",   "Mkt_Utm_Coupon",   "Mkt_Utm_Medium",   "Mkt_Utm_Src",   "Mkt_Utmi_Campaign",   "ORDER_SEQUENCE",   "Payment_Type",   "Brand",   "INSTALLMENT",   "Product_Name",   "Reference_Code",   "Seller_Id",   "SELLER_INSTANCE_ID",   "Seller_Name",   "Seller_Order_Id",   "Order_Id",   "Shipping_Cost_Item",   "Subsidiary",   "Subsidiary_Id",   "Trade_Policy",   "Vendor",   "Tax_Converter",   "Units",   "Price",   "Item_Discount",   "Total_Item",   "Total_Item_USD",   "Creation_Datetime",   "AUDIENCE_TYPE",   "CAMELAGEM",   "BASE" ) AS (   (     SELECT DISTINCT       a."Acquirer_Message",       d.codigoParceria AS codigo_parceria,       a.Affiliate_Id,       a.ADDRESS_TYPE AS Address_Type,       a."Cancellation_Reason",       a."Category",       a."Channel",       a.COD_SALES_CHANNEL AS Cod_Sales_Channel,       a."Country",       a."Creation_Date",       a.IS_TRADE_IN,       a.IS_SAMSUNG_CARE,       a."Last_Update_Date",       a.CUSTOMER_ID AS Customer_Id,       a."Division",       a."Hostname",       a."Internal_Status",       a."Status",       a."Invoice_Number",       a."Mkt_Campaign_Tags",       a."Mkt_Utm_Campaign",       a."Mkt_Utm_Coupon",       a."Mkt_Utm_Medium",       a."Mkt_Utm_Src",       a."Mkt_Utmi_Campaign",       a.ORDER_SEQUENCE AS Order_Sequence,       FT.Payment_Type AS "Payment_Type",       FT.Brand AS "Brand",       FT.INSTALLMENT AS Installment,       a."Product_Name",       a."Reference_Code",       a."Seller_Id",       a.SELLER_INSTANCE_ID AS Seller_Instance_Id,       a."Seller_Name",       a."Seller_Order_Id",       a."Order_Id",       a."Shipping_Cost_Item",       a."Subsidiary",       a."Subsidiary_Id",       a."Trade_Policy",       a."Vendor",       a."Tax_Converter",       a."Units",       a."Price",       a."Item_Discount",       a."Total_Item",       a."Total_Item_USD",       a."Creation_Datetime",       ST."AUDIENCE_TYPE",       CAST(CASE WHEN NOT a."Order_Id" IS NULL THEN \'YES\' END AS VARCHAR) AS CAMELAGEM,       CAST(CASE WHEN NOT a."Order_Id" IS NULL THEN 1 END AS VARCHAR) AS BASE     FROM "_SYS_BIC"."SDSLA_ECOM/CV_PAYMENT_RAW_DATA_SAMSUNG_ORDERS" AS a     JOIN "U_PRJ_ECOM"."FT_ECOM_ORDER" AS b       ON b.id = a.id     JOIN "U_PRJ_ECOM"."DIM_CUSTOMER" AS c       ON c.id = b.customer_id     LEFT JOIN "U_PRJ_ECOM"."ODS_VTEX_MASTER_DATA_CL" AS d       ON d.userId = c.external_id       AND d.subsidiary_id = b.subsidiary_id       AND d.hostname = b.hostname     LEFT JOIN (       SELECT DISTINCT         A.EXTERNAL_ORDER_ID,         A.ID,         LISTAGG(B.INSTALLMENT USING PARAMETERS separator=\', \') AS Installment,         LISTAGG(B.BRAND USING PARAMETERS separator=\', \') AS Brand,         LISTAGG(B.PAYMENT_TYPE USING PARAMETERS separator=\', \') AS Payment_Type       FROM U_PRJ_ECOM.FT_ECOM_ORDER AS A       LEFT JOIN U_PRJ_ECOM.FT_ECOM_ORDER_PAYMENT AS B         ON A.ID = B.ORDER_ID       GROUP BY         A.EXTERNAL_ORDER_ID,         A.ID     ) AS FT       ON a."Order_Id" = FT.EXTERNAL_ORDER_ID     LEFT JOIN (       SELECT         A.SITE,         A.ORDER_CODE,         B.COD_SALES_CHANNEL,         B.SELLER_INSTANCE_ID,         B.SUBSIDIARY_ID,         C."AUDIENCE_TYPE"       FROM "_SYS_BIC"."SDSLA_ECOM/CV_HQ_INTEGRATION_TST" AS A       LEFT JOIN U_PRJ_ECOM.FT_ECOM_ORDER AS B         ON A.ORDER_CODE = B.EXTERNAL_ORDER_ID       LEFT JOIN "U_PRJ_ECOM"."DIM_ECOM_STORE" AS C         ON C.SUBSIDIARY_ID = B.SUBSIDIARY_ID         AND C.COD_SALES_CHANNEL = B.COD_SALES_CHANNEL         AND C.SELLER_INSTANCE_ID = B.SELLER_INSTANCE_ID         AND C.STORE_NAME = A.SITE     ) AS ST       ON ST.ORDER_CODE = a."Order_Id"     WHERE       CAST("Creation_Datetime" AS DATE) >= \'2023-01-01\' AND NOT "Subsidiary_Id" IN (6)   )   UNION ALL   (     SELECT DISTINCT       a."Acquirer_Message",       NULL AS codigo_parceria,       a."Affiliate_Id",       a.ADDRESS_TYPE AS Address_Type,       a."Cancellation_Reason",       a."Category",       a."Channel",       a.COD_SALES_CHANNEL AS Cod_Sales_Channel,       a."Country",       a."Creation_Date",       a.IS_TRADE_IN,       a.IS_SAMSUNG_CARE,       a."Last_Update_Date",       a.CUSTOMER_ID AS Customer_Id,       a."Division",       a."Hostname",       a."Internal_Status",       a."Status",       a."Invoice_Number",       a."Mkt_Campaign_Tags",       a."Mkt_Utm_Campaign",       a."Mkt_Utm_Coupon",       a."Mkt_Utm_Medium",       a."Mkt_Utm_Src",       a."Mkt_Utmi_Campaign",       a.ORDER_SEQUENCE AS Order_Sequence,       FT.Payment_Type AS "Payment_Type",       FT.Brand AS "Brand",       FT.INSTALLMENT AS Installment,       a."Product_Name",       a."Reference_Code",       a."Seller_Id",       a.SELLER_INSTANCE_ID AS Seller_Instance_Id,       a."Seller_Name",       a."Seller_Order_Id",       a."Order_Id",       a."Shipping_Cost_Item",       a."Subsidiary",       a."Subsidiary_Id",       a."Trade_Policy",       a."Vendor",       a."Tax_Converter",       a."Units",       a."Price",       a."Item_Discount",       a."Total_Item",       a."Total_Item_USD",       a."Creation_Datetime",       ST."AUDIENCE_TYPE",       CAST(CASE WHEN IS_SAMSUNG_CARE = 1 THEN \'NO\' ELSE \'YES\' END AS VARCHAR) AS CAMELAGEM,       CAST(CASE WHEN NOT "Order_Id" IS NULL THEN 3 END AS VARCHAR) AS BASE     FROM "_SYS_BIC"."SDSLA_ECOM/CV_PAYMENT_RAW_DATA_SYNAPCON_SAMSUNG_ORDERS" AS a     LEFT JOIN (       SELECT DISTINCT         A.EXTERNAL_ORDER_ID,         A.ID,         LISTAGG(B.INSTALLMENT USING PARAMETERS separator=\', \') AS Installment,         LISTAGG(B.BRAND USING PARAMETERS separator=\', \') AS Brand,         LISTAGG(B.PAYMENT_TYPE USING PARAMETERS separator=\', \') AS Payment_Type       FROM U_PRJ_ECOM_SYNAPCOM.FT_ECOM_ORDER AS A       LEFT JOIN U_PRJ_ECOM_SYNAPCOM.FT_ECOM_ORDER_PAYMENT AS B         ON A.ID = B.ORDER_ID       GROUP BY         A.EXTERNAL_ORDER_ID,         A.ID     ) AS FT       ON a."Order_Id" = FT.EXTERNAL_ORDER_ID     LEFT JOIN (       SELECT         A.SITE,         A.ORDER_CODE,         B.COD_SALES_CHANNEL,         B.SELLER_INSTANCE_ID,         B.SUBSIDIARY_ID,         C."AUDIENCE_TYPE"       FROM "_SYS_BIC"."SDSLA_ECOM/CV_HQ_INTEGRATION_TST" AS A       LEFT JOIN U_PRJ_ECOM_SYNAPCOM.FT_ECOM_ORDER AS B         ON A.ORDER_CODE = B.EXTERNAL_ORDER_ID       LEFT JOIN "U_PRJ_ECOM"."DIM_ECOM_STORE" AS C         ON C.SUBSIDIARY_ID = B.SUBSIDIARY_ID         AND C.COD_SALES_CHANNEL = B.COD_SALES_CHANNEL         AND C.SELLER_INSTANCE_ID = B.SELLER_INSTANCE_ID         AND C.STORE_NAME = A.SITE     ) AS ST       ON ST.ORDER_CODE = a."Order_Id"     WHERE       CAST(a."Creation_Datetime" AS DATE) >= \'2023-01-01\'   ) )'

CREATE VIEW "U_PRJ_ECOM"."VIEW_ECOM_ORDERS_B5Q5" (
  "Acquirer_Message",
  "CODIGO_PARCERIA",
  "AFFILIATE_ID",
  "ADDRESS_TYPE",
  "Cancellation_Reason",
  "Category",
  "Channel",
  "COD_SALES_CHANNEL",
  "Country",
  "Creation_Date",
  "IS_TRADE_IN",
  "IS_SAMSUNG_CARE",
  "Last_Update_Date",
  "CUSTOMER_ID",
  "Division",
  "Hostname",
  "Internal_Status",
  "Status",
  "Invoice_Number",
  "Mkt_Campaign_Tags",
  "Mkt_Utm_Campaign",
  "Mkt_Utm_Coupon",
  "Mkt_Utm_Medium",
  "Mkt_Utm_Src",
  "Mkt_Utmi_Campaign",
  "ORDER_SEQUENCE",
  "Payment_Type",
  "Brand",
  "INSTALLMENT",
  "Product_Name",
  "Reference_Code",
  "Seller_Id",
  "SELLER_INSTANCE_ID",
  "Seller_Name",
  "Seller_Order_Id",
  "Order_Id",
  "Shipping_Cost_Item",
  "Subsidiary",
  "Subsidiary_Id",
  "Trade_Policy",
  "Vendor",
  "Tax_Converter",
  "Units",
  "Price",
  "Item_Discount",
  "Total_Item",
  "Total_Item_USD",
  "Creation_Datetime",
  "AUDIENCE_TYPE",
  "CAMELAGEM",
  "BASE"
) AS
(
  (
    SELECT DISTINCT
      a."Acquirer_Message",
      d.codigoParceria AS codigo_parceria,
      a.Affiliate_Id,
      a.ADDRESS_TYPE AS Address_Type,
      a."Cancellation_Reason",
      a."Category",
      a."Channel",
      a.COD_SALES_CHANNEL AS Cod_Sales_Channel,
      a."Country",
      a."Creation_Date",
      a.IS_TRADE_IN,
      a.IS_SAMSUNG_CARE,
      a."Last_Update_Date",
      a.CUSTOMER_ID AS Customer_Id,
      a."Division",
      a."Hostname",
      a."Internal_Status",
      a."Status",
      a."Invoice_Number",
      a."Mkt_Campaign_Tags",
      a."Mkt_Utm_Campaign",
      a."Mkt_Utm_Coupon",
      a."Mkt_Utm_Medium",
      a."Mkt_Utm_Src",
      a."Mkt_Utmi_Campaign",
      a.ORDER_SEQUENCE AS Order_Sequence,
      FT.Payment_Type AS "Payment_Type",
      FT.Brand AS "Brand",
      FT.INSTALLMENT AS Installment,
      a."Product_Name",
      a."Reference_Code",
      a."Seller_Id",
      a.SELLER_INSTANCE_ID AS Seller_Instance_Id,
      a."Seller_Name",
      a."Seller_Order_Id",
      a."Order_Id",
      a."Shipping_Cost_Item",
      a."Subsidiary",
      a."Subsidiary_Id",
      a."Trade_Policy",
      a."Vendor",
      a."Tax_Converter",
      a."Units",
      a."Price",
      a."Item_Discount",
      a."Total_Item",
      a."Total_Item_USD",
      a."Creation_Datetime",
      ST."AUDIENCE_TYPE",
      CAST(CASE WHEN NOT a."Order_Id" IS NULL THEN 'YES' END AS VARCHAR) AS CAMELAGEM,
      CAST(CASE WHEN NOT a."Order_Id" IS NULL THEN 1 END AS VARCHAR) AS BASE
    FROM "_SYS_BIC"."SDSLA_ECOM/CV_PAYMENT_RAW_DATA_SAMSUNG_ORDERS" AS a
    JOIN "U_PRJ_ECOM"."FT_ECOM_ORDER" AS b
      ON b.id = a.id
    JOIN "U_PRJ_ECOM"."DIM_CUSTOMER" AS c
      ON c.id = b.customer_id
    LEFT JOIN "U_PRJ_ECOM"."ODS_VTEX_MASTER_DATA_CL" AS d
      ON d.userId = c.external_id
      AND d.subsidiary_id = b.subsidiary_id
      AND d.hostname = b.hostname
    LEFT JOIN (
      SELECT DISTINCT
        A.EXTERNAL_ORDER_ID,
        A.ID,
        LISTAGG(B.INSTALLMENT USING PARAMETERS separator=', ') AS Installment,
        LISTAGG(B.BRAND USING PARAMETERS separator=', ') AS Brand,
        LISTAGG(B.PAYMENT_TYPE USING PARAMETERS separator=', ') AS Payment_Type
      FROM U_PRJ_ECOM.FT_ECOM_ORDER AS A
      LEFT JOIN U_PRJ_ECOM.FT_ECOM_ORDER_PAYMENT AS B
        ON A.ID = B.ORDER_ID
      GROUP BY
        A.EXTERNAL_ORDER_ID,
        A.ID
    ) AS FT
      ON a."Order_Id" = FT.EXTERNAL_ORDER_ID
    LEFT JOIN (
      SELECT
        A.SITE,
        A.ORDER_CODE,
        B.COD_SALES_CHANNEL,
        B.SELLER_INSTANCE_ID,
        B.SUBSIDIARY_ID,
        C."AUDIENCE_TYPE"
      FROM "_SYS_BIC"."SDSLA_ECOM/CV_HQ_INTEGRATION_TST" AS A
      LEFT JOIN U_PRJ_ECOM.FT_ECOM_ORDER AS B
        ON A.ORDER_CODE = B.EXTERNAL_ORDER_ID
      LEFT JOIN "U_PRJ_ECOM"."DIM_ECOM_STORE" AS C
        ON C.SUBSIDIARY_ID = B.SUBSIDIARY_ID
        AND C.COD_SALES_CHANNEL = B.COD_SALES_CHANNEL
        AND C.SELLER_INSTANCE_ID = B.SELLER_INSTANCE_ID
        AND C.STORE_NAME = A.SITE
    ) AS ST
      ON ST.ORDER_CODE = a."Order_Id"
    WHERE
      CAST("Creation_Datetime" AS DATE) >= '2023-01-01' AND NOT "Subsidiary_Id" IN (6)
  )
  UNION ALL
  (
    SELECT DISTINCT
      a."Acquirer_Message",
      NULL AS codigo_parceria,
      a."Affiliate_Id",
      a.ADDRESS_TYPE AS Address_Type,
      a."Cancellation_Reason",
      a."Category",
      a."Channel",
      a.COD_SALES_CHANNEL AS Cod_Sales_Channel,
      a."Country",
      a."Creation_Date",
      a.IS_TRADE_IN,
      a.IS_SAMSUNG_CARE,
      a."Last_Update_Date",
      a.CUSTOMER_ID AS Customer_Id,
      a."Division",
      a."Hostname",
      a."Internal_Status",
      a."Status",
      a."Invoice_Number",
      a."Mkt_Campaign_Tags",
      a."Mkt_Utm_Campaign",
      a."Mkt_Utm_Coupon",
      a."Mkt_Utm_Medium",
      a."Mkt_Utm_Src",
      a."Mkt_Utmi_Campaign",
      a.ORDER_SEQUENCE AS Order_Sequence,
      FT.Payment_Type AS "Payment_Type",
      FT.Brand AS "Brand",
      FT.INSTALLMENT AS Installment,
      a."Product_Name",
      a."Reference_Code",
      a."Seller_Id",
      a.SELLER_INSTANCE_ID AS Seller_Instance_Id,
      a."Seller_Name",
      a."Seller_Order_Id",
      a."Order_Id",
      a."Shipping_Cost_Item",
      a."Subsidiary",
      a."Subsidiary_Id",
      a."Trade_Policy",
      a."Vendor",
      a."Tax_Converter",
      a."Units",
      a."Price",
      a."Item_Discount",
      a."Total_Item",
      a."Total_Item_USD",
      a."Creation_Datetime",
      ST."AUDIENCE_TYPE",
      CAST(CASE WHEN IS_SAMSUNG_CARE = 1 THEN 'NO' ELSE 'YES' END AS VARCHAR) AS CAMELAGEM,
      CAST(CASE WHEN NOT "Order_Id" IS NULL THEN 3 END AS VARCHAR) AS BASE
    FROM "_SYS_BIC"."SDSLA_ECOM/CV_PAYMENT_RAW_DATA_SYNAPCON_SAMSUNG_ORDERS" AS a
    LEFT JOIN (
      SELECT DISTINCT
        A.EXTERNAL_ORDER_ID,
        A.ID,
        LISTAGG(B.INSTALLMENT USING PARAMETERS separator=', ') AS Installment,
        LISTAGG(B.BRAND USING PARAMETERS separator=', ') AS Brand,
        LISTAGG(B.PAYMENT_TYPE USING PARAMETERS separator=', ') AS Payment_Type
      FROM U_PRJ_ECOM_SYNAPCOM.FT_ECOM_ORDER AS A
      LEFT JOIN U_PRJ_ECOM_SYNAPCOM.FT_ECOM_ORDER_PAYMENT AS B
        ON A.ID = B.ORDER_ID
      GROUP BY
        A.EXTERNAL_ORDER_ID,
        A.ID
    ) AS FT
      ON a."Order_Id" = FT.EXTERNAL_ORDER_ID
    LEFT JOIN (
      SELECT
        A.SITE,
        A.ORDER_CODE,
        B.COD_SALES_CHANNEL,
        B.SELLER_INSTANCE_ID,
        B.SUBSIDIARY_ID,
        C."AUDIENCE_TYPE"
      FROM "_SYS_BIC"."SDSLA_ECOM/CV_HQ_INTEGRATION_TST" AS A
      LEFT JOIN U_PRJ_ECOM_SYNAPCOM.FT_ECOM_ORDER AS B
        ON A.ORDER_CODE = B.EXTERNAL_ORDER_ID
      LEFT JOIN "U_PRJ_ECOM"."DIM_ECOM_STORE" AS C
        ON C.SUBSIDIARY_ID = B.SUBSIDIARY_ID
        AND C.COD_SALES_CHANNEL = B.COD_SALES_CHANNEL
        AND C.SELLER_INSTANCE_ID = B.SELLER_INSTANCE_ID
        AND C.STORE_NAME = A.SITE
    ) AS ST
      ON ST.ORDER_CODE = a."Order_Id"
    WHERE
      CAST(a."Creation_Datetime" AS DATE) >= '2023-01-01'
  )
)