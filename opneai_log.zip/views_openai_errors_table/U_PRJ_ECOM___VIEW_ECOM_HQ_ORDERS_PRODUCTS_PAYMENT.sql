-- MISSING RELATION: _SYS_BIC
-- ERROR: Error executing query: Severity: ERROR, Message: Schema "_SYS_BIC" does not exist, Sqlstate: 3F000, Routine: RangeVarGetObjid, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Miner/server/vertica/Catalog/NamespaceLookup.cpp, Line: 317, Error Code: 4650, SQL: 'CREATE OR REPLACE VIEW "U_PRJ_ECOM"."VIEW_ECOM_HQ_ORDERS_PRODUCTS_PAYMENT" (   "COUNTRY_CD",   "SITE",   "SALES_APPLICATION",   "PRODUCT_CODE",   "ORDER_CODE",   "ORDER_STATUS",   "ORDER_TYPE",   "ORDER_CREATION_DATE",   "PLATFORM",   "VOUCHER_CODE",   "ITEM_TAX_AMOUNT",   "IS_TRADED_IN",   "IS_TRADE_IN_ELIGIBLE",   "IS_FINANCED_ORDER",   "IS_FINANCING_ELIGIBLE",   "IS_UPGRADE",   "IS_UPGRADE_ELIGIBLE",   "IS_SAMSUNG_CARE_ORDER",   "IS_SAMSUNG_CARE_ELIGIBLE",   "PAYMENT_METHOD_NAME",   "PAYMENT_GATEWAY",   "LAST_UPDATE",   "REMARKS",   "ORDER_ENTRY_TOTAL_PRICE",   "ORDER_ENTRY_QUANTITY",   "UNIT_LIST_PRICE",   "UNIT_SALES_PRICE",   "SALES_PRICE",   "DISCOUNT_AMOUNT" ) AS SELECT   CASE     WHEN O."Subsidiary_Id" = 7 AND O."Country" IS NULL     THEN \'PAN\'     ELSE O."Country"   END AS "COUNTRY_CD",   CASE     WHEN O."Subsidiary_Id" = 1     AND O."Hostname" = \'samsungar\'     AND O."COD_SALES_CHANNEL" IN (\'1\', \'5\', \'7\')     THEN \'B2C\'     WHEN O."Subsidiary_Id" = 1     AND O."Hostname" = \'samsungarb2b2c\'     AND O."COD_SALES_CHANNEL" IN (\'2\', \'3\', \'4\', \'5\', \'6\', \'7\', \'9\', \'10\', \'11\')     THEN \'B2C\'     WHEN O."Subsidiary_Id" = 1     AND O."Hostname" = \'samsungar\'     AND O."COD_SALES_CHANNEL" IN (\'8\')     THEN \'EPP\'     WHEN O."Subsidiary_Id" = 1     AND O."Hostname" = \'samsungarepp\'     AND O."COD_SALES_CHANNEL" IN (\'8\')     THEN \'EPP\'     WHEN O."Subsidiary_Id" = 2     AND O."Hostname" = \'clubsmart\'     AND O."COD_SALES_CHANNEL" IN (\'1\')     THEN \'B2C\'     WHEN O."Subsidiary_Id" = 2     AND O."Hostname" = \'clubsmart\'     AND O."COD_SALES_CHANNEL" IN (\'8\')     THEN \'Especialistas\'     WHEN O."Subsidiary_Id" = 2     AND O."Hostname" = \'clubsmart\'     AND O."COD_SALES_CHANNEL" IN (\'5\')     THEN \'Externo\'     WHEN O."Subsidiary_Id" = 2     AND O."Hostname" = \'clubsmart\'     AND O."COD_SALES_CHANNEL" IN (\'6\')     THEN \'inmobiliaria\'     WHEN O."Subsidiary_Id" = 2     AND O."Hostname" = \'clubsmart\'     AND O."COD_SALES_CHANNEL" IN (\'4\')     THEN \'Interno\'     WHEN O."Subsidiary_Id" = 2     AND O."Hostname" = \'clubsmart\'     AND O."COD_SALES_CHANNEL" IN (\'7\')     THEN \'Mayorista\'     WHEN O."Subsidiary_Id" = 2     AND O."Hostname" = \'clubsmart\'     AND O."COD_SALES_CHANNEL" IN (\'9\')     THEN \'Partners\'     WHEN O."Subsidiary_Id" = 2     AND O."Hostname" = \'samsungclepp\'     AND O."COD_SALES_CHANNEL" IN (\'2\')     THEN \'Outlet\'     WHEN O."Subsidiary_Id" = 3     AND O."Hostname" = \'qasamsungco\'     AND O."COD_SALES_CHANNEL" IN (\'2\')     THEN \'B2C\'     WHEN O."Subsidiary_Id" = 3     AND O."Hostname" = \'samsungco\'     AND O."COD_SALES_CHANNEL" IN (\'2\', \'3\')     THEN \'B2C\'     WHEN O."Subsidiary_Id" = 3     AND O."Hostname" = \'samsungempresarial\'     AND O."COD_SALES_CHANNEL" IN (\'1\')     THEN \'Empresarial\'     WHEN O."Subsidiary_Id" = 4     AND O."Hostname" = \'samsungmx\'     AND O."COD_SALES_CHANNEL" IN (\'1\')     THEN \'B2C\'     WHEN O."Subsidiary_Id" = 4     AND O."Hostname" = \'samsungmxb2b\'     AND O."COD_SALES_CHANNEL" IN (\'1\')     THEN \'B2C\'     WHEN O."Subsidiary_Id" = 4     AND O."Hostname" = \'samsungmxio\'     AND O."COD_SALES_CHANNEL" IN (\'1\')     THEN \'B2C\'     WHEN O."Subsidiary_Id" = 4     AND O."Hostname" = \'samsungmxepp\'     AND O."COD_SALES_CHANNEL" IN (\'4\')     THEN \'B2B\'     WHEN O."Subsidiary_Id" = 4     AND O."Hostname" = \'samsungmxempleados\'     AND O."COD_SALES_CHANNEL" IN (\'3\')     THEN \'Empleados\'     WHEN O."Subsidiary_Id" = 4     AND O."Hostname" = \'samsungmxcms\'     AND O."COD_SALES_CHANNEL" IN (\'1\')     THEN \'Students\'     WHEN O."Subsidiary_Id" = 5     AND O."Hostname" = \'samsungpe\'     AND O."COD_SALES_CHANNEL" IN (\'1\', \'4\', \'6\')     THEN \'B2C\'     WHEN O."Subsidiary_Id" = 5     AND O."Hostname" = \'samsungpeepp\'     AND O."COD_SALES_CHANNEL" IN (\'2\')     THEN \'B2B1\'     WHEN O."Subsidiary_Id" = 5     AND O."Hostname" = \'samsungpeepp2\'     AND O."COD_SALES_CHANNEL" IN (\'3\')     THEN \'Funcionario\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbr\'     AND O."COD_SALES_CHANNEL" IN (\'1\')     THEN \'B2C\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbrshop\'     AND O."COD_SALES_CHANNEL" IN (       \'1\',       \'4\',       \'5\',       \'6\',       \'7\',       \'8\',       \'9\',       \'10\',       \'12\',       \'13\',       \'14\',       \'16\',       \'19\',       \'21\',       \'23\',       \'25\',       \'30\',       \'32\',       \'34\',       \'35\',       \'36\',       \'37\',       \'38\',       \'39\'     )     THEN \'B2C\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbrshop\'     AND O."COD_SALES_CHANNEL" IN (\'17\')     THEN \'B2B2C\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbrshop\'     AND O."COD_SALES_CHANNEL" IN (\'26\')     THEN \'Bestoff\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbrshop\'     AND O."COD_SALES_CHANNEL" IN (\'11\')     THEN \'Creditas\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbrshop\'     AND O."COD_SALES_CHANNEL" IN (\'3\')     THEN \'Funcionario\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbrshop\'     AND O."COD_SALES_CHANNEL" IN (\'18\')     THEN \'homeautomation\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbrshop\'     AND O."COD_SALES_CHANNEL" IN (\'31\')     THEN \'Hometogo\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbrshop\'     AND O."COD_SALES_CHANNEL" IN (\'20\')     THEN \'Inter\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbrshop\'     AND O."COD_SALES_CHANNEL" IN (\'22\')     THEN \'portoseguro\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbrshop\'     AND O."COD_SALES_CHANNEL" IN (\'40\')     THEN \'Shopfacil\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbrshop\'     AND O."COD_SALES_CHANNEL" IN (\'42\')     THEN \'SSGitaucard\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbraepp\'     AND O."COD_SALES_CHANNEL" IN (\'8\')     THEN \'B2B2C\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbraepp\'     AND O."COD_SALES_CHANNEL" IN (\'16\')     THEN \'EPP\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbraepp\'     AND O."COD_SALES_CHANNEL" IN (\'5\')     THEN \'Funcionario\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbraepp\'     AND O."COD_SALES_CHANNEL" IN (\'9\')     THEN \'homeautomation\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbraepp\'     AND O."COD_SALES_CHANNEL" IN (\'17\')     THEN \'SSGitaucard\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'portosegurossg\'     AND O."COD_SALES_CHANNEL" IN (\'12\')     THEN \'portoseguro\'     WHEN O."Subsidiary_Id" = 7     AND O."COD_SALES_CHANNEL" IN (\'Online Store\', \'others\', \'online store\')     THEN \'B2C\'     WHEN O."Subsidiary_Id" = 7 AND O."COD_SALES_CHANNEL" IN (\'epp/b2b\')     THEN \'B2B\'     WHEN O."Subsidiary_Id" = 7 AND O."COD_SALES_CHANNEL" IN (\'students/specials/etc\')     THEN \'Students\'     WHEN O."Subsidiary_Id" = 8     AND O."Hostname" = \'samsungpy\'     AND O."COD_SALES_CHANNEL" IN (\'1\')     THEN \'B2C\'     WHEN O."Subsidiary_Id" = 8     AND O."Hostname" = \'samsungpyepp\'     AND O."COD_SALES_CHANNEL" IN (\'1\')     THEN \'Corporate\'     WHEN O."Subsidiary_Id" = 9     AND O."Hostname" = \'samsunguy\'     AND O."COD_SALES_CHANNEL" IN (\'1\')     THEN \'B2C\'     ELSE \'B2C\'   END AS "SITE",   CASE     WHEN (       O."Channel" = \'SAMSUNG\'     ) OR (       O."Subsidiary_Id" = 3     )     THEN \'ESTORE\'     ELSE \'MARKETPLACE\'   END AS "SALES_APPLICATION",   O."Reference_Code" AS "PRODUCT_CODE",   O."Order_Id" AS "ORDER_CODE",   O."Status" AS "ORDER_STATUS",   CASE WHEN O."Channel" = \'B2E\' THEN \'B2E\' ELSE \'B2C\' END AS "ORDER_TYPE",   CAST(O."Creation_Datetime" AS VARCHAR) AS "ORDER_CREATION_DATE",   CASE     WHEN (       O."Channel" = \'SAMSUNG\'     ) OR (       O."Subsidiary_Id" = 3     )     THEN \'ESTORE\'     ELSE \'MARKETPLACE\'   END AS "PLATFORM",   \'\' AS "VOUCHER_CODE",   \'\' AS "ITEM_TAX_AMOUNT",   CASE WHEN (     UPPER(O."Product_Group") = \'TRADE IN\'   ) THEN \'TRUE\' ELSE \'FALSE\' END AS "IS_TRADED_IN",   \'FALSE\' AS "IS_TRADE_IN_ELIGIBLE",   P."IS_FINANCED_ORDER" AS "IS_FINANCED_ORDER",   P."IS_FINANCED_ORDER" AS "IS_FINANCING_ELIGIBLE",   \'FALSE\' AS "IS_UPGRADE",   \'FALSE\' AS "IS_UPGRADE_ELIGIBLE",   CASE WHEN (     UPPER(O."Product_Group") = \'SSG CARE\'   ) THEN \'TRUE\' ELSE \'FALSE\' END AS "IS_SAMSUNG_CARE_ORDER",   CASE WHEN (     UPPER(O."Product_Group") = \'SSG CARE\'   ) THEN \'TRUE\' ELSE \'FALSE\' END AS "IS_SAMSUNG_CARE_ELIGIBLE",   COALESCE(P."PAYMENT_METHOD", \'Undefined\') AS "PAYMENT_METHOD_NAME",   COALESCE(P."PAYMENT_METHOD", \'Undefined\') AS "PAYMENT_GATEWAY",   COALESCE(O."Last_Update_Date", O."Insert_Date") AS "LAST_UPDATE",   O."Acquirer_Message" AS "REMARKS",   SUM(O."Total_Item") AS "ORDER_ENTRY_TOTAL_PRICE",   SUM(O."Units") AS "ORDER_ENTRY_QUANTITY",   SUM(O."Price") AS "UNIT_LIST_PRICE",   SUM(O."Price") AS "UNIT_SALES_PRICE",   SUM(O."Price") AS "SALES_PRICE",   SUM(O."Item_Discount") AS "DISCOUNT_AMOUNT" FROM "_SYS_BIC"."SDSLA_ECOM/CV_ECOM_ORDERS_CUSTOMERS_PRODUCTS" AS O LEFT JOIN "U_PRJ_ECOM"."VIEW_ECOM_HQ_ORDERS_PAYMENT" AS P   ON O."ID" = P."ORDER_ID" GROUP BY   CASE     WHEN O."Subsidiary_Id" = 7 AND O."Country" IS NULL     THEN \'PAN\'     ELSE O."Country"   END,   CASE     WHEN O."Subsidiary_Id" = 1     AND O."Hostname" = \'samsungar\'     AND O."COD_SALES_CHANNEL" IN (\'1\', \'5\', \'7\')     THEN \'B2C\'     WHEN O."Subsidiary_Id" = 1     AND O."Hostname" = \'samsungarb2b2c\'     AND O."COD_SALES_CHANNEL" IN (\'2\', \'3\', \'4\', \'5\', \'6\', \'7\', \'9\', \'10\', \'11\')     THEN \'B2C\'     WHEN O."Subsidiary_Id" = 1     AND O."Hostname" = \'samsungar\'     AND O."COD_SALES_CHANNEL" IN (\'8\')     THEN \'EPP\'     WHEN O."Subsidiary_Id" = 1     AND O."Hostname" = \'samsungarepp\'     AND O."COD_SALES_CHANNEL" IN (\'8\')     THEN \'EPP\'     WHEN O."Subsidiary_Id" = 2     AND O."Hostname" = \'clubsmart\'     AND O."COD_SALES_CHANNEL" IN (\'1\')     THEN \'B2C\'     WHEN O."Subsidiary_Id" = 2     AND O."Hostname" = \'clubsmart\'     AND O."COD_SALES_CHANNEL" IN (\'8\')     THEN \'Especialistas\'     WHEN O."Subsidiary_Id" = 2     AND O."Hostname" = \'clubsmart\'     AND O."COD_SALES_CHANNEL" IN (\'5\')     THEN \'Externo\'     WHEN O."Subsidiary_Id" = 2     AND O."Hostname" = \'clubsmart\'     AND O."COD_SALES_CHANNEL" IN (\'6\')     THEN \'inmobiliaria\'     WHEN O."Subsidiary_Id" = 2     AND O."Hostname" = \'clubsmart\'     AND O."COD_SALES_CHANNEL" IN (\'4\')     THEN \'Interno\'     WHEN O."Subsidiary_Id" = 2     AND O."Hostname" = \'clubsmart\'     AND O."COD_SALES_CHANNEL" IN (\'7\')     THEN \'Mayorista\'     WHEN O."Subsidiary_Id" = 2     AND O."Hostname" = \'clubsmart\'     AND O."COD_SALES_CHANNEL" IN (\'9\')     THEN \'Partners\'     WHEN O."Subsidiary_Id" = 2     AND O."Hostname" = \'samsungclepp\'     AND O."COD_SALES_CHANNEL" IN (\'2\')     THEN \'Outlet\'     WHEN O."Subsidiary_Id" = 3     AND O."Hostname" = \'qasamsungco\'     AND O."COD_SALES_CHANNEL" IN (\'2\')     THEN \'B2C\'     WHEN O."Subsidiary_Id" = 3     AND O."Hostname" = \'samsungco\'     AND O."COD_SALES_CHANNEL" IN (\'2\', \'3\')     THEN \'B2C\'     WHEN O."Subsidiary_Id" = 3     AND O."Hostname" = \'samsungempresarial\'     AND O."COD_SALES_CHANNEL" IN (\'1\')     THEN \'Empresarial\'     WHEN O."Subsidiary_Id" = 4     AND O."Hostname" = \'samsungmx\'     AND O."COD_SALES_CHANNEL" IN (\'1\')     THEN \'B2C\'     WHEN O."Subsidiary_Id" = 4     AND O."Hostname" = \'samsungmxb2b\'     AND O."COD_SALES_CHANNEL" IN (\'1\')     THEN \'B2C\'     WHEN O."Subsidiary_Id" = 4     AND O."Hostname" = \'samsungmxio\'     AND O."COD_SALES_CHANNEL" IN (\'1\')     THEN \'B2C\'     WHEN O."Subsidiary_Id" = 4     AND O."Hostname" = \'samsungmxepp\'     AND O."COD_SALES_CHANNEL" IN (\'4\')     THEN \'B2B\'     WHEN O."Subsidiary_Id" = 4     AND O."Hostname" = \'samsungmxempleados\'     AND O."COD_SALES_CHANNEL" IN (\'3\')     THEN \'Empleados\'     WHEN O."Subsidiary_Id" = 4     AND O."Hostname" = \'samsungmxcms\'     AND O."COD_SALES_CHANNEL" IN (\'1\')     THEN \'Students\'     WHEN O."Subsidiary_Id" = 5     AND O."Hostname" = \'samsungpe\'     AND O."COD_SALES_CHANNEL" IN (\'1\', \'4\', \'6\')     THEN \'B2C\'     WHEN O."Subsidiary_Id" = 5     AND O."Hostname" = \'samsungpeepp\'     AND O."COD_SALES_CHANNEL" IN (\'2\')     THEN \'B2B1\'     WHEN O."Subsidiary_Id" = 5     AND O."Hostname" = \'samsungpeepp2\'     AND O."COD_SALES_CHANNEL" IN (\'3\')     THEN \'Funcionario\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbr\'     AND O."COD_SALES_CHANNEL" IN (\'1\')     THEN \'B2C\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbrshop\'     AND O."COD_SALES_CHANNEL" IN (       \'1\',       \'4\',       \'5\',       \'6\',       \'7\',       \'8\',       \'9\',       \'10\',       \'12\',       \'13\',       \'14\',       \'16\',       \'19\',       \'21\',       \'23\',       \'25\',       \'30\',       \'32\',       \'34\',       \'35\',       \'36\',       \'37\',       \'38\',       \'39\'     )     THEN \'B2C\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbrshop\'     AND O."COD_SALES_CHANNEL" IN (\'17\')     THEN \'B2B2C\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbrshop\'     AND O."COD_SALES_CHANNEL" IN (\'26\')     THEN \'Bestoff\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbrshop\'     AND O."COD_SALES_CHANNEL" IN (\'11\')     THEN \'Creditas\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbrshop\'     AND O."COD_SALES_CHANNEL" IN (\'3\')     THEN \'Funcionario\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbrshop\'     AND O."COD_SALES_CHANNEL" IN (\'18\')     THEN \'homeautomation\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbrshop\'     AND O."COD_SALES_CHANNEL" IN (\'31\')     THEN \'Hometogo\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbrshop\'     AND O."COD_SALES_CHANNEL" IN (\'20\')     THEN \'Inter\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbrshop\'     AND O."COD_SALES_CHANNEL" IN (\'22\')     THEN \'portoseguro\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbrshop\'     AND O."COD_SALES_CHANNEL" IN (\'40\')     THEN \'Shopfacil\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbrshop\'     AND O."COD_SALES_CHANNEL" IN (\'42\')     THEN \'SSGitaucard\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbraepp\'     AND O."COD_SALES_CHANNEL" IN (\'8\')     THEN \'B2B2C\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbraepp\'     AND O."COD_SALES_CHANNEL" IN (\'16\')     THEN \'EPP\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbraepp\'     AND O."COD_SALES_CHANNEL" IN (\'5\')     THEN \'Funcionario\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbraepp\'     AND O."COD_SALES_CHANNEL" IN (\'9\')     THEN \'homeautomation\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'samsungbraepp\'     AND O."COD_SALES_CHANNEL" IN (\'17\')     THEN \'SSGitaucard\'     WHEN O."Subsidiary_Id" = 6     AND O."Hostname" = \'portosegurossg\'     AND O."COD_SALES_CHANNEL" IN (\'12\')     THEN \'portoseguro\'     WHEN O."Subsidiary_Id" = 7     AND O."COD_SALES_CHANNEL" IN (\'Online Store\', \'others\', \'online store\')     THEN \'B2C\'     WHEN O."Subsidiary_Id" = 7 AND O."COD_SALES_CHANNEL" IN (\'epp/b2b\')     THEN \'B2B\'     WHEN O."Subsidiary_Id" = 7 AND O."COD_SALES_CHANNEL" IN (\'students/specials/etc\')     THEN \'Students\'     WHEN O."Subsidiary_Id" = 8     AND O."Hostname" = \'samsungpy\'     AND O."COD_SALES_CHANNEL" IN (\'1\')     THEN \'B2C\'     WHEN O."Subsidiary_Id" = 8     AND O."Hostname" = \'samsungpyepp\'     AND O."COD_SALES_CHANNEL" IN (\'1\')     THEN \'Corporate\'     WHEN O."Subsidiary_Id" = 9     AND O."Hostname" = \'samsunguy\'     AND O."COD_SALES_CHANNEL" IN (\'1\')     THEN \'B2C\'     ELSE \'B2C\'   END,   CASE     WHEN (       O."Channel" = \'SAMSUNG\'     ) OR (       O."Subsidiary_Id" = 3     )     THEN \'ESTORE\'     ELSE \'MARKETPLACE\'   END,   O."Reference_Code",   O."Order_Id",   O."Status",   CASE WHEN O."Channel" = \'B2E\' THEN \'B2E\' ELSE \'B2C\' END,   CAST(O."Creation_Datetime" AS VARCHAR),   CASE     WHEN (       O."Channel" = \'SAMSUNG\'     ) OR (       O."Subsidiary_Id" = 3     )     THEN \'ESTORE\'     ELSE \'MARKETPLACE\'   END,   \'\',   \'\',   CASE WHEN (     UPPER(O."Product_Group") = \'TRADE IN\'   ) THEN \'TRUE\' ELSE \'FALSE\' END,   \'FALSE\',   P."IS_FINANCED_ORDER",   P."IS_FINANCED_ORDER",   \'FALSE\',   \'FALSE\',   CASE WHEN (     UPPER(O."Product_Group") = \'SSG CARE\'   ) THEN \'TRUE\' ELSE \'FALSE\' END,   CASE WHEN (     UPPER(O."Product_Group") = \'SSG CARE\'   ) THEN \'TRUE\' ELSE \'FALSE\' END,   COALESCE(P."PAYMENT_METHOD", \'Undefined\'),   COALESCE(P."PAYMENT_METHOD", \'Undefined\'),   COALESCE(O."Last_Update_Date", O."Insert_Date"),   O."Acquirer_Message"'

CREATE VIEW "U_PRJ_ECOM"."VIEW_ECOM_HQ_ORDERS_PRODUCTS_PAYMENT" (
  "COUNTRY_CD",
  "SITE",
  "SALES_APPLICATION",
  "PRODUCT_CODE",
  "ORDER_CODE",
  "ORDER_STATUS",
  "ORDER_TYPE",
  "ORDER_CREATION_DATE",
  "PLATFORM",
  "VOUCHER_CODE",
  "ITEM_TAX_AMOUNT",
  "IS_TRADED_IN",
  "IS_TRADE_IN_ELIGIBLE",
  "IS_FINANCED_ORDER",
  "IS_FINANCING_ELIGIBLE",
  "IS_UPGRADE",
  "IS_UPGRADE_ELIGIBLE",
  "IS_SAMSUNG_CARE_ORDER",
  "IS_SAMSUNG_CARE_ELIGIBLE",
  "PAYMENT_METHOD_NAME",
  "PAYMENT_GATEWAY",
  "LAST_UPDATE",
  "REMARKS",
  "ORDER_ENTRY_TOTAL_PRICE",
  "ORDER_ENTRY_QUANTITY",
  "UNIT_LIST_PRICE",
  "UNIT_SALES_PRICE",
  "SALES_PRICE",
  "DISCOUNT_AMOUNT"
) AS
SELECT
  CASE
    WHEN O."Subsidiary_Id" = 7 AND O."Country" IS NULL
    THEN 'PAN'
    ELSE O."Country"
  END AS "COUNTRY_CD",
  CASE
    WHEN O."Subsidiary_Id" = 1
    AND O."Hostname" = 'samsungar'
    AND O."COD_SALES_CHANNEL" IN ('1', '5', '7')
    THEN 'B2C'
    WHEN O."Subsidiary_Id" = 1
    AND O."Hostname" = 'samsungarb2b2c'
    AND O."COD_SALES_CHANNEL" IN ('2', '3', '4', '5', '6', '7', '9', '10', '11')
    THEN 'B2C'
    WHEN O."Subsidiary_Id" = 1
    AND O."Hostname" = 'samsungar'
    AND O."COD_SALES_CHANNEL" IN ('8')
    THEN 'EPP'
    WHEN O."Subsidiary_Id" = 1
    AND O."Hostname" = 'samsungarepp'
    AND O."COD_SALES_CHANNEL" IN ('8')
    THEN 'EPP'
    WHEN O."Subsidiary_Id" = 2
    AND O."Hostname" = 'clubsmart'
    AND O."COD_SALES_CHANNEL" IN ('1')
    THEN 'B2C'
    WHEN O."Subsidiary_Id" = 2
    AND O."Hostname" = 'clubsmart'
    AND O."COD_SALES_CHANNEL" IN ('8')
    THEN 'Especialistas'
    WHEN O."Subsidiary_Id" = 2
    AND O."Hostname" = 'clubsmart'
    AND O."COD_SALES_CHANNEL" IN ('5')
    THEN 'Externo'
    WHEN O."Subsidiary_Id" = 2
    AND O."Hostname" = 'clubsmart'
    AND O."COD_SALES_CHANNEL" IN ('6')
    THEN 'inmobiliaria'
    WHEN O."Subsidiary_Id" = 2
    AND O."Hostname" = 'clubsmart'
    AND O."COD_SALES_CHANNEL" IN ('4')
    THEN 'Interno'
    WHEN O."Subsidiary_Id" = 2
    AND O."Hostname" = 'clubsmart'
    AND O."COD_SALES_CHANNEL" IN ('7')
    THEN 'Mayorista'
    WHEN O."Subsidiary_Id" = 2
    AND O."Hostname" = 'clubsmart'
    AND O."COD_SALES_CHANNEL" IN ('9')
    THEN 'Partners'
    WHEN O."Subsidiary_Id" = 2
    AND O."Hostname" = 'samsungclepp'
    AND O."COD_SALES_CHANNEL" IN ('2')
    THEN 'Outlet'
    WHEN O."Subsidiary_Id" = 3
    AND O."Hostname" = 'qasamsungco'
    AND O."COD_SALES_CHANNEL" IN ('2')
    THEN 'B2C'
    WHEN O."Subsidiary_Id" = 3
    AND O."Hostname" = 'samsungco'
    AND O."COD_SALES_CHANNEL" IN ('2', '3')
    THEN 'B2C'
    WHEN O."Subsidiary_Id" = 3
    AND O."Hostname" = 'samsungempresarial'
    AND O."COD_SALES_CHANNEL" IN ('1')
    THEN 'Empresarial'
    WHEN O."Subsidiary_Id" = 4
    AND O."Hostname" = 'samsungmx'
    AND O."COD_SALES_CHANNEL" IN ('1')
    THEN 'B2C'
    WHEN O."Subsidiary_Id" = 4
    AND O."Hostname" = 'samsungmxb2b'
    AND O."COD_SALES_CHANNEL" IN ('1')
    THEN 'B2C'
    WHEN O."Subsidiary_Id" = 4
    AND O."Hostname" = 'samsungmxio'
    AND O."COD_SALES_CHANNEL" IN ('1')
    THEN 'B2C'
    WHEN O."Subsidiary_Id" = 4
    AND O."Hostname" = 'samsungmxepp'
    AND O."COD_SALES_CHANNEL" IN ('4')
    THEN 'B2B'
    WHEN O."Subsidiary_Id" = 4
    AND O."Hostname" = 'samsungmxempleados'
    AND O."COD_SALES_CHANNEL" IN ('3')
    THEN 'Empleados'
    WHEN O."Subsidiary_Id" = 4
    AND O."Hostname" = 'samsungmxcms'
    AND O."COD_SALES_CHANNEL" IN ('1')
    THEN 'Students'
    WHEN O."Subsidiary_Id" = 5
    AND O."Hostname" = 'samsungpe'
    AND O."COD_SALES_CHANNEL" IN ('1', '4', '6')
    THEN 'B2C'
    WHEN O."Subsidiary_Id" = 5
    AND O."Hostname" = 'samsungpeepp'
    AND O."COD_SALES_CHANNEL" IN ('2')
    THEN 'B2B1'
    WHEN O."Subsidiary_Id" = 5
    AND O."Hostname" = 'samsungpeepp2'
    AND O."COD_SALES_CHANNEL" IN ('3')
    THEN 'Funcionario'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbr'
    AND O."COD_SALES_CHANNEL" IN ('1')
    THEN 'B2C'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbrshop'
    AND O."COD_SALES_CHANNEL" IN (
      '1',
      '4',
      '5',
      '6',
      '7',
      '8',
      '9',
      '10',
      '12',
      '13',
      '14',
      '16',
      '19',
      '21',
      '23',
      '25',
      '30',
      '32',
      '34',
      '35',
      '36',
      '37',
      '38',
      '39'
    )
    THEN 'B2C'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbrshop'
    AND O."COD_SALES_CHANNEL" IN ('17')
    THEN 'B2B2C'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbrshop'
    AND O."COD_SALES_CHANNEL" IN ('26')
    THEN 'Bestoff'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbrshop'
    AND O."COD_SALES_CHANNEL" IN ('11')
    THEN 'Creditas'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbrshop'
    AND O."COD_SALES_CHANNEL" IN ('3')
    THEN 'Funcionario'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbrshop'
    AND O."COD_SALES_CHANNEL" IN ('18')
    THEN 'homeautomation'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbrshop'
    AND O."COD_SALES_CHANNEL" IN ('31')
    THEN 'Hometogo'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbrshop'
    AND O."COD_SALES_CHANNEL" IN ('20')
    THEN 'Inter'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbrshop'
    AND O."COD_SALES_CHANNEL" IN ('22')
    THEN 'portoseguro'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbrshop'
    AND O."COD_SALES_CHANNEL" IN ('40')
    THEN 'Shopfacil'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbrshop'
    AND O."COD_SALES_CHANNEL" IN ('42')
    THEN 'SSGitaucard'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbraepp'
    AND O."COD_SALES_CHANNEL" IN ('8')
    THEN 'B2B2C'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbraepp'
    AND O."COD_SALES_CHANNEL" IN ('16')
    THEN 'EPP'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbraepp'
    AND O."COD_SALES_CHANNEL" IN ('5')
    THEN 'Funcionario'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbraepp'
    AND O."COD_SALES_CHANNEL" IN ('9')
    THEN 'homeautomation'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbraepp'
    AND O."COD_SALES_CHANNEL" IN ('17')
    THEN 'SSGitaucard'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'portosegurossg'
    AND O."COD_SALES_CHANNEL" IN ('12')
    THEN 'portoseguro'
    WHEN O."Subsidiary_Id" = 7
    AND O."COD_SALES_CHANNEL" IN ('Online Store', 'others', 'online store')
    THEN 'B2C'
    WHEN O."Subsidiary_Id" = 7 AND O."COD_SALES_CHANNEL" IN ('epp/b2b')
    THEN 'B2B'
    WHEN O."Subsidiary_Id" = 7 AND O."COD_SALES_CHANNEL" IN ('students/specials/etc')
    THEN 'Students'
    WHEN O."Subsidiary_Id" = 8
    AND O."Hostname" = 'samsungpy'
    AND O."COD_SALES_CHANNEL" IN ('1')
    THEN 'B2C'
    WHEN O."Subsidiary_Id" = 8
    AND O."Hostname" = 'samsungpyepp'
    AND O."COD_SALES_CHANNEL" IN ('1')
    THEN 'Corporate'
    WHEN O."Subsidiary_Id" = 9
    AND O."Hostname" = 'samsunguy'
    AND O."COD_SALES_CHANNEL" IN ('1')
    THEN 'B2C'
    ELSE 'B2C'
  END AS "SITE",
  CASE
    WHEN (
      O."Channel" = 'SAMSUNG'
    ) OR (
      O."Subsidiary_Id" = 3
    )
    THEN 'ESTORE'
    ELSE 'MARKETPLACE'
  END AS "SALES_APPLICATION",
  O."Reference_Code" AS "PRODUCT_CODE",
  O."Order_Id" AS "ORDER_CODE",
  O."Status" AS "ORDER_STATUS",
  CASE WHEN O."Channel" = 'B2E' THEN 'B2E' ELSE 'B2C' END AS "ORDER_TYPE",
  CAST(O."Creation_Datetime" AS VARCHAR) AS "ORDER_CREATION_DATE",
  CASE
    WHEN (
      O."Channel" = 'SAMSUNG'
    ) OR (
      O."Subsidiary_Id" = 3
    )
    THEN 'ESTORE'
    ELSE 'MARKETPLACE'
  END AS "PLATFORM",
  '' AS "VOUCHER_CODE",
  '' AS "ITEM_TAX_AMOUNT",
  CASE WHEN (
    UPPER(O."Product_Group") = 'TRADE IN'
  ) THEN 'TRUE' ELSE 'FALSE' END AS "IS_TRADED_IN",
  'FALSE' AS "IS_TRADE_IN_ELIGIBLE",
  P."IS_FINANCED_ORDER" AS "IS_FINANCED_ORDER",
  P."IS_FINANCED_ORDER" AS "IS_FINANCING_ELIGIBLE",
  'FALSE' AS "IS_UPGRADE",
  'FALSE' AS "IS_UPGRADE_ELIGIBLE",
  CASE WHEN (
    UPPER(O."Product_Group") = 'SSG CARE'
  ) THEN 'TRUE' ELSE 'FALSE' END AS "IS_SAMSUNG_CARE_ORDER",
  CASE WHEN (
    UPPER(O."Product_Group") = 'SSG CARE'
  ) THEN 'TRUE' ELSE 'FALSE' END AS "IS_SAMSUNG_CARE_ELIGIBLE",
  COALESCE(P."PAYMENT_METHOD", 'Undefined') AS "PAYMENT_METHOD_NAME",
  COALESCE(P."PAYMENT_METHOD", 'Undefined') AS "PAYMENT_GATEWAY",
  COALESCE(O."Last_Update_Date", O."Insert_Date") AS "LAST_UPDATE",
  O."Acquirer_Message" AS "REMARKS",
  SUM(O."Total_Item") AS "ORDER_ENTRY_TOTAL_PRICE",
  SUM(O."Units") AS "ORDER_ENTRY_QUANTITY",
  SUM(O."Price") AS "UNIT_LIST_PRICE",
  SUM(O."Price") AS "UNIT_SALES_PRICE",
  SUM(O."Price") AS "SALES_PRICE",
  SUM(O."Item_Discount") AS "DISCOUNT_AMOUNT"
FROM "_SYS_BIC"."SDSLA_ECOM/CV_ECOM_ORDERS_CUSTOMERS_PRODUCTS" AS O
LEFT JOIN "U_PRJ_ECOM"."VIEW_ECOM_HQ_ORDERS_PAYMENT" AS P
  ON O."ID" = P."ORDER_ID"
GROUP BY
  CASE
    WHEN O."Subsidiary_Id" = 7 AND O."Country" IS NULL
    THEN 'PAN'
    ELSE O."Country"
  END,
  CASE
    WHEN O."Subsidiary_Id" = 1
    AND O."Hostname" = 'samsungar'
    AND O."COD_SALES_CHANNEL" IN ('1', '5', '7')
    THEN 'B2C'
    WHEN O."Subsidiary_Id" = 1
    AND O."Hostname" = 'samsungarb2b2c'
    AND O."COD_SALES_CHANNEL" IN ('2', '3', '4', '5', '6', '7', '9', '10', '11')
    THEN 'B2C'
    WHEN O."Subsidiary_Id" = 1
    AND O."Hostname" = 'samsungar'
    AND O."COD_SALES_CHANNEL" IN ('8')
    THEN 'EPP'
    WHEN O."Subsidiary_Id" = 1
    AND O."Hostname" = 'samsungarepp'
    AND O."COD_SALES_CHANNEL" IN ('8')
    THEN 'EPP'
    WHEN O."Subsidiary_Id" = 2
    AND O."Hostname" = 'clubsmart'
    AND O."COD_SALES_CHANNEL" IN ('1')
    THEN 'B2C'
    WHEN O."Subsidiary_Id" = 2
    AND O."Hostname" = 'clubsmart'
    AND O."COD_SALES_CHANNEL" IN ('8')
    THEN 'Especialistas'
    WHEN O."Subsidiary_Id" = 2
    AND O."Hostname" = 'clubsmart'
    AND O."COD_SALES_CHANNEL" IN ('5')
    THEN 'Externo'
    WHEN O."Subsidiary_Id" = 2
    AND O."Hostname" = 'clubsmart'
    AND O."COD_SALES_CHANNEL" IN ('6')
    THEN 'inmobiliaria'
    WHEN O."Subsidiary_Id" = 2
    AND O."Hostname" = 'clubsmart'
    AND O."COD_SALES_CHANNEL" IN ('4')
    THEN 'Interno'
    WHEN O."Subsidiary_Id" = 2
    AND O."Hostname" = 'clubsmart'
    AND O."COD_SALES_CHANNEL" IN ('7')
    THEN 'Mayorista'
    WHEN O."Subsidiary_Id" = 2
    AND O."Hostname" = 'clubsmart'
    AND O."COD_SALES_CHANNEL" IN ('9')
    THEN 'Partners'
    WHEN O."Subsidiary_Id" = 2
    AND O."Hostname" = 'samsungclepp'
    AND O."COD_SALES_CHANNEL" IN ('2')
    THEN 'Outlet'
    WHEN O."Subsidiary_Id" = 3
    AND O."Hostname" = 'qasamsungco'
    AND O."COD_SALES_CHANNEL" IN ('2')
    THEN 'B2C'
    WHEN O."Subsidiary_Id" = 3
    AND O."Hostname" = 'samsungco'
    AND O."COD_SALES_CHANNEL" IN ('2', '3')
    THEN 'B2C'
    WHEN O."Subsidiary_Id" = 3
    AND O."Hostname" = 'samsungempresarial'
    AND O."COD_SALES_CHANNEL" IN ('1')
    THEN 'Empresarial'
    WHEN O."Subsidiary_Id" = 4
    AND O."Hostname" = 'samsungmx'
    AND O."COD_SALES_CHANNEL" IN ('1')
    THEN 'B2C'
    WHEN O."Subsidiary_Id" = 4
    AND O."Hostname" = 'samsungmxb2b'
    AND O."COD_SALES_CHANNEL" IN ('1')
    THEN 'B2C'
    WHEN O."Subsidiary_Id" = 4
    AND O."Hostname" = 'samsungmxio'
    AND O."COD_SALES_CHANNEL" IN ('1')
    THEN 'B2C'
    WHEN O."Subsidiary_Id" = 4
    AND O."Hostname" = 'samsungmxepp'
    AND O."COD_SALES_CHANNEL" IN ('4')
    THEN 'B2B'
    WHEN O."Subsidiary_Id" = 4
    AND O."Hostname" = 'samsungmxempleados'
    AND O."COD_SALES_CHANNEL" IN ('3')
    THEN 'Empleados'
    WHEN O."Subsidiary_Id" = 4
    AND O."Hostname" = 'samsungmxcms'
    AND O."COD_SALES_CHANNEL" IN ('1')
    THEN 'Students'
    WHEN O."Subsidiary_Id" = 5
    AND O."Hostname" = 'samsungpe'
    AND O."COD_SALES_CHANNEL" IN ('1', '4', '6')
    THEN 'B2C'
    WHEN O."Subsidiary_Id" = 5
    AND O."Hostname" = 'samsungpeepp'
    AND O."COD_SALES_CHANNEL" IN ('2')
    THEN 'B2B1'
    WHEN O."Subsidiary_Id" = 5
    AND O."Hostname" = 'samsungpeepp2'
    AND O."COD_SALES_CHANNEL" IN ('3')
    THEN 'Funcionario'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbr'
    AND O."COD_SALES_CHANNEL" IN ('1')
    THEN 'B2C'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbrshop'
    AND O."COD_SALES_CHANNEL" IN (
      '1',
      '4',
      '5',
      '6',
      '7',
      '8',
      '9',
      '10',
      '12',
      '13',
      '14',
      '16',
      '19',
      '21',
      '23',
      '25',
      '30',
      '32',
      '34',
      '35',
      '36',
      '37',
      '38',
      '39'
    )
    THEN 'B2C'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbrshop'
    AND O."COD_SALES_CHANNEL" IN ('17')
    THEN 'B2B2C'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbrshop'
    AND O."COD_SALES_CHANNEL" IN ('26')
    THEN 'Bestoff'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbrshop'
    AND O."COD_SALES_CHANNEL" IN ('11')
    THEN 'Creditas'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbrshop'
    AND O."COD_SALES_CHANNEL" IN ('3')
    THEN 'Funcionario'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbrshop'
    AND O."COD_SALES_CHANNEL" IN ('18')
    THEN 'homeautomation'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbrshop'
    AND O."COD_SALES_CHANNEL" IN ('31')
    THEN 'Hometogo'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbrshop'
    AND O."COD_SALES_CHANNEL" IN ('20')
    THEN 'Inter'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbrshop'
    AND O."COD_SALES_CHANNEL" IN ('22')
    THEN 'portoseguro'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbrshop'
    AND O."COD_SALES_CHANNEL" IN ('40')
    THEN 'Shopfacil'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbrshop'
    AND O."COD_SALES_CHANNEL" IN ('42')
    THEN 'SSGitaucard'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbraepp'
    AND O."COD_SALES_CHANNEL" IN ('8')
    THEN 'B2B2C'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbraepp'
    AND O."COD_SALES_CHANNEL" IN ('16')
    THEN 'EPP'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbraepp'
    AND O."COD_SALES_CHANNEL" IN ('5')
    THEN 'Funcionario'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbraepp'
    AND O."COD_SALES_CHANNEL" IN ('9')
    THEN 'homeautomation'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'samsungbraepp'
    AND O."COD_SALES_CHANNEL" IN ('17')
    THEN 'SSGitaucard'
    WHEN O."Subsidiary_Id" = 6
    AND O."Hostname" = 'portosegurossg'
    AND O."COD_SALES_CHANNEL" IN ('12')
    THEN 'portoseguro'
    WHEN O."Subsidiary_Id" = 7
    AND O."COD_SALES_CHANNEL" IN ('Online Store', 'others', 'online store')
    THEN 'B2C'
    WHEN O."Subsidiary_Id" = 7 AND O."COD_SALES_CHANNEL" IN ('epp/b2b')
    THEN 'B2B'
    WHEN O."Subsidiary_Id" = 7 AND O."COD_SALES_CHANNEL" IN ('students/specials/etc')
    THEN 'Students'
    WHEN O."Subsidiary_Id" = 8
    AND O."Hostname" = 'samsungpy'
    AND O."COD_SALES_CHANNEL" IN ('1')
    THEN 'B2C'
    WHEN O."Subsidiary_Id" = 8
    AND O."Hostname" = 'samsungpyepp'
    AND O."COD_SALES_CHANNEL" IN ('1')
    THEN 'Corporate'
    WHEN O."Subsidiary_Id" = 9
    AND O."Hostname" = 'samsunguy'
    AND O."COD_SALES_CHANNEL" IN ('1')
    THEN 'B2C'
    ELSE 'B2C'
  END,
  CASE
    WHEN (
      O."Channel" = 'SAMSUNG'
    ) OR (
      O."Subsidiary_Id" = 3
    )
    THEN 'ESTORE'
    ELSE 'MARKETPLACE'
  END,
  O."Reference_Code",
  O."Order_Id",
  O."Status",
  CASE WHEN O."Channel" = 'B2E' THEN 'B2E' ELSE 'B2C' END,
  CAST(O."Creation_Datetime" AS VARCHAR),
  CASE
    WHEN (
      O."Channel" = 'SAMSUNG'
    ) OR (
      O."Subsidiary_Id" = 3
    )
    THEN 'ESTORE'
    ELSE 'MARKETPLACE'
  END,
  '',
  '',
  CASE WHEN (
    UPPER(O."Product_Group") = 'TRADE IN'
  ) THEN 'TRUE' ELSE 'FALSE' END,
  'FALSE',
  P."IS_FINANCED_ORDER",
  P."IS_FINANCED_ORDER",
  'FALSE',
  'FALSE',
  CASE WHEN (
    UPPER(O."Product_Group") = 'SSG CARE'
  ) THEN 'TRUE' ELSE 'FALSE' END,
  CASE WHEN (
    UPPER(O."Product_Group") = 'SSG CARE'
  ) THEN 'TRUE' ELSE 'FALSE' END,
  COALESCE(P."PAYMENT_METHOD", 'Undefined'),
  COALESCE(P."PAYMENT_METHOD", 'Undefined'),
  COALESCE(O."Last_Update_Date", O."Insert_Date"),
  O."Acquirer_Message"