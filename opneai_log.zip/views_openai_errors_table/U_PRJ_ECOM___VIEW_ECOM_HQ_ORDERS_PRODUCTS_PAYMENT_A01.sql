-- MISSING RELATION: _SYS_BIC
-- ERROR: Error executing query: Severity: ERROR, Message: Schema "_SYS_BIC" does not exist, Sqlstate: 3F000, Routine: RangeVarGetObjid, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Miner/server/vertica/Catalog/NamespaceLookup.cpp, Line: 317, Error Code: 4650, SQL: 'CREATE OR REPLACE VIEW "U_PRJ_ECOM"."VIEW_ECOM_HQ_ORDERS_PRODUCTS_PAYMENT_A01" (   "COUNTRY_CD",   "SITE",   "SALES_APPLICATION",   "PRODUCT_CODE",   "ORDER_CODE",   "ORDER_STATUS",   "ORDER_TYPE",   "ORDER_CREATION_DATE",   "PLATFORM",   "VOUCHER_CODE",   "ITEM_TAX_AMOUNT",   "IS_TRADED_IN",   "IS_TRADE_IN_ELIGIBLE",   "IS_FINANCED_ORDER",   "IS_FINANCING_ELIGIBLE",   "IS_UPGRADE",   "IS_UPGRADE_ELIGIBLE",   "IS_SAMSUNG_CARE_ORDER",   "IS_SAMSUNG_CARE_ELIGIBLE",   "PAYMENT_METHOD_NAME",   "PAYMENT_GATEWAY",   "LAST_UPDATE",   "REMARKS",   "ORDER_ENTRY_TOTAL_PRICE",   "ORDER_ENTRY_QUANTITY",   "UNIT_LIST_PRICE",   "UNIT_SALES_PRICE",   "SALES_PRICE",   "DISCOUNT_AMOUNT" ) AS SELECT   CASE     WHEN O."Subsidiary_Id" = 1 AND O."Country" IS NULL     THEN \'ARG\'     ELSE O."Country"   END AS "COUNTRY_CD",   CASE WHEN O."Channel" = \'B2C\' THEN \'B2E\' ELSE \'EPP\' END AS "SITE",   CASE     WHEN (       O."Channel" = \'SAMSUNG\'     ) OR (       O."Subsidiary_Id" = 1     )     THEN \'ESTORE\'     ELSE \'MARKETPLACE\'   END AS "SALES_APPLICATION",   O."Reference_Code" AS "PRODUCT_CODE",   O."Order_Id" AS "ORDER_CODE",   O."Status" AS "ORDER_STATUS",   CASE WHEN O."Channel" = \'B2C\' THEN \'B2E\' ELSE \'EPP\' END AS "ORDER_TYPE",   CAST(O."Creation_Datetime" AS VARCHAR) AS "ORDER_CREATION_DATE",   CASE     WHEN (       O."Channel" = \'SAMSUNG\'     ) OR (       O."Subsidiary_Id" = 1     )     THEN \'ESTORE\'     ELSE \'MARKETPLACE\'   END AS "PLATFORM",   \'\' AS "VOUCHER_CODE",   \'\' AS "ITEM_TAX_AMOUNT",   CASE WHEN (     UPPER(O."Product_Group") = \'TRADE IN\'   ) THEN \'TRUE\' ELSE \'FALSE\' END AS "IS_TRADED_IN",   \'FALSE\' AS "IS_TRADE_IN_ELIGIBLE",   P."IS_FINANCED_ORDER" AS "IS_FINANCED_ORDER",   P."IS_FINANCED_ORDER" AS "IS_FINANCING_ELIGIBLE",   \'FALSE\' AS "IS_UPGRADE",   \'FALSE\' AS "IS_UPGRADE_ELIGIBLE",   CASE WHEN (     UPPER(O."Product_Group") = \'SSG CARE\'   ) THEN \'TRUE\' ELSE \'FALSE\' END AS "IS_SAMSUNG_CARE_ORDER",   CASE WHEN (     UPPER(O."Product_Group") = \'SSG CARE\'   ) THEN \'TRUE\' ELSE \'FALSE\' END AS "IS_SAMSUNG_CARE_ELIGIBLE",   COALESCE(P."PAYMENT_METHOD", \'Undefined\') AS "PAYMENT_METHOD_NAME",   COALESCE(P."PAYMENT_METHOD", \'Undefined\') AS "PAYMENT_GATEWAY",   COALESCE(O."Last_Update_Date", O."Insert_Date") AS "LAST_UPDATE",   O."Acquirer_Message" AS "REMARKS",   SUM(O."Total_Item") AS "ORDER_ENTRY_TOTAL_PRICE",   SUM(O."Units") AS "ORDER_ENTRY_QUANTITY",   SUM(O."Price") AS "UNIT_LIST_PRICE",   SUM(O."Price") AS "UNIT_SALES_PRICE",   SUM(O."Price") AS "SALES_PRICE",   SUM(O."Item_Discount") AS "DISCOUNT_AMOUNT" FROM "_SYS_BIC"."SDSLA_ECOM/CV_ECOM_ORDERS_CUSTOMERS_PRODUCTS" AS O LEFT JOIN "U_PRJ_ECOM"."VIEW_ECOM_HQ_ORDERS_PAYMENT" AS P   ON O."ID" = P."ORDER_ID" GROUP BY   CASE     WHEN O."Subsidiary_Id" = 1 AND O."Country" IS NULL     THEN \'ARG\'     ELSE O."Country"   END,   CASE WHEN O."Channel" = \'B2C\' THEN \'B2E\' ELSE \'EPP\' END,   CASE     WHEN (       O."Channel" = \'SAMSUNG\'     ) OR (       O."Subsidiary_Id" = 1     )     THEN \'ESTORE\'     ELSE \'MARKETPLACE\'   END,   O."Reference_Code",   O."Order_Id",   O."Status",   CASE WHEN O."Channel" = \'B2C\' THEN \'B2E\' ELSE \'EPP\' END,   CAST(O."Creation_Datetime" AS VARCHAR),   CASE     WHEN (       O."Channel" = \'SAMSUNG\'     ) OR (       O."Subsidiary_Id" = 1     )     THEN \'ESTORE\'     ELSE \'MARKETPLACE\'   END,   \'\',   \'\',   CASE WHEN (     UPPER(O."Product_Group") = \'TRADE IN\'   ) THEN \'TRUE\' ELSE \'FALSE\' END,   \'FALSE\',   P."IS_FINANCED_ORDER",   P."IS_FINANCED_ORDER",   \'FALSE\',   \'FALSE\',   CASE WHEN (     UPPER(O."Product_Group") = \'SSG CARE\'   ) THEN \'TRUE\' ELSE \'FALSE\' END,   CASE WHEN (     UPPER(O."Product_Group") = \'SSG CARE\'   ) THEN \'TRUE\' ELSE \'FALSE\' END,   COALESCE(P."PAYMENT_METHOD", \'Undefined\'),   COALESCE(P."PAYMENT_METHOD", \'Undefined\'),   COALESCE(O."Last_Update_Date", O."Insert_Date"),   O."Acquirer_Message"'

CREATE VIEW "U_PRJ_ECOM"."VIEW_ECOM_HQ_ORDERS_PRODUCTS_PAYMENT_A01" (
  "COUNTRY_CD",
  "SITE",
  "SALES_APPLICATION",
  "PRODUCT_CODE",
  "ORDER_CODE",
  "ORDER_STATUS",
  "ORDER_TYPE",
  "ORDER_CREATION_DATE",
  "PLATFORM",
  "VOUCHER_CODE",
  "ITEM_TAX_AMOUNT",
  "IS_TRADED_IN",
  "IS_TRADE_IN_ELIGIBLE",
  "IS_FINANCED_ORDER",
  "IS_FINANCING_ELIGIBLE",
  "IS_UPGRADE",
  "IS_UPGRADE_ELIGIBLE",
  "IS_SAMSUNG_CARE_ORDER",
  "IS_SAMSUNG_CARE_ELIGIBLE",
  "PAYMENT_METHOD_NAME",
  "PAYMENT_GATEWAY",
  "LAST_UPDATE",
  "REMARKS",
  "ORDER_ENTRY_TOTAL_PRICE",
  "ORDER_ENTRY_QUANTITY",
  "UNIT_LIST_PRICE",
  "UNIT_SALES_PRICE",
  "SALES_PRICE",
  "DISCOUNT_AMOUNT"
) AS
SELECT
  CASE
    WHEN O."Subsidiary_Id" = 1 AND O."Country" IS NULL
    THEN 'ARG'
    ELSE O."Country"
  END AS "COUNTRY_CD",
  CASE WHEN O."Channel" = 'B2C' THEN 'B2E' ELSE 'EPP' END AS "SITE",
  CASE
    WHEN (
      O."Channel" = 'SAMSUNG'
    ) OR (
      O."Subsidiary_Id" = 1
    )
    THEN 'ESTORE'
    ELSE 'MARKETPLACE'
  END AS "SALES_APPLICATION",
  O."Reference_Code" AS "PRODUCT_CODE",
  O."Order_Id" AS "ORDER_CODE",
  O."Status" AS "ORDER_STATUS",
  CASE WHEN O."Channel" = 'B2C' THEN 'B2E' ELSE 'EPP' END AS "ORDER_TYPE",
  CAST(O."Creation_Datetime" AS VARCHAR) AS "ORDER_CREATION_DATE",
  CASE
    WHEN (
      O."Channel" = 'SAMSUNG'
    ) OR (
      O."Subsidiary_Id" = 1
    )
    THEN 'ESTORE'
    ELSE 'MARKETPLACE'
  END AS "PLATFORM",
  '' AS "VOUCHER_CODE",
  '' AS "ITEM_TAX_AMOUNT",
  CASE WHEN (
    UPPER(O."Product_Group") = 'TRADE IN'
  ) THEN 'TRUE' ELSE 'FALSE' END AS "IS_TRADED_IN",
  'FALSE' AS "IS_TRADE_IN_ELIGIBLE",
  P."IS_FINANCED_ORDER" AS "IS_FINANCED_ORDER",
  P."IS_FINANCED_ORDER" AS "IS_FINANCING_ELIGIBLE",
  'FALSE' AS "IS_UPGRADE",
  'FALSE' AS "IS_UPGRADE_ELIGIBLE",
  CASE WHEN (
    UPPER(O."Product_Group") = 'SSG CARE'
  ) THEN 'TRUE' ELSE 'FALSE' END AS "IS_SAMSUNG_CARE_ORDER",
  CASE WHEN (
    UPPER(O."Product_Group") = 'SSG CARE'
  ) THEN 'TRUE' ELSE 'FALSE' END AS "IS_SAMSUNG_CARE_ELIGIBLE",
  COALESCE(P."PAYMENT_METHOD", 'Undefined') AS "PAYMENT_METHOD_NAME",
  COALESCE(P."PAYMENT_METHOD", 'Undefined') AS "PAYMENT_GATEWAY",
  COALESCE(O."Last_Update_Date", O."Insert_Date") AS "LAST_UPDATE",
  O."Acquirer_Message" AS "REMARKS",
  SUM(O."Total_Item") AS "ORDER_ENTRY_TOTAL_PRICE",
  SUM(O."Units") AS "ORDER_ENTRY_QUANTITY",
  SUM(O."Price") AS "UNIT_LIST_PRICE",
  SUM(O."Price") AS "UNIT_SALES_PRICE",
  SUM(O."Price") AS "SALES_PRICE",
  SUM(O."Item_Discount") AS "DISCOUNT_AMOUNT"
FROM "_SYS_BIC"."SDSLA_ECOM/CV_ECOM_ORDERS_CUSTOMERS_PRODUCTS" AS O
LEFT JOIN "U_PRJ_ECOM"."VIEW_ECOM_HQ_ORDERS_PAYMENT" AS P
  ON O."ID" = P."ORDER_ID"
GROUP BY
  CASE
    WHEN O."Subsidiary_Id" = 1 AND O."Country" IS NULL
    THEN 'ARG'
    ELSE O."Country"
  END,
  CASE WHEN O."Channel" = 'B2C' THEN 'B2E' ELSE 'EPP' END,
  CASE
    WHEN (
      O."Channel" = 'SAMSUNG'
    ) OR (
      O."Subsidiary_Id" = 1
    )
    THEN 'ESTORE'
    ELSE 'MARKETPLACE'
  END,
  O."Reference_Code",
  O."Order_Id",
  O."Status",
  CASE WHEN O."Channel" = 'B2C' THEN 'B2E' ELSE 'EPP' END,
  CAST(O."Creation_Datetime" AS VARCHAR),
  CASE
    WHEN (
      O."Channel" = 'SAMSUNG'
    ) OR (
      O."Subsidiary_Id" = 1
    )
    THEN 'ESTORE'
    ELSE 'MARKETPLACE'
  END,
  '',
  '',
  CASE WHEN (
    UPPER(O."Product_Group") = 'TRADE IN'
  ) THEN 'TRUE' ELSE 'FALSE' END,
  'FALSE',
  P."IS_FINANCED_ORDER",
  P."IS_FINANCED_ORDER",
  'FALSE',
  'FALSE',
  CASE WHEN (
    UPPER(O."Product_Group") = 'SSG CARE'
  ) THEN 'TRUE' ELSE 'FALSE' END,
  CASE WHEN (
    UPPER(O."Product_Group") = 'SSG CARE'
  ) THEN 'TRUE' ELSE 'FALSE' END,
  COALESCE(P."PAYMENT_METHOD", 'Undefined'),
  COALESCE(P."PAYMENT_METHOD", 'Undefined'),
  COALESCE(O."Last_Update_Date", O."Insert_Date"),
  O."Acquirer_Message"