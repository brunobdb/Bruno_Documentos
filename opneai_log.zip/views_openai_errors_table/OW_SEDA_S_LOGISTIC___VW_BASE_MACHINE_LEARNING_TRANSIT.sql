-- MISSING RELATION: OW_SEDA_S_LOGISTIC.ST_BASE_MACHINE_LEARNING_PREVIEW_TRANSIT_2
-- ERROR: Error executing query: Severity: ERROR, Message: Relation "OW_SEDA_S_LOGISTIC.ST_BASE_MACHINE_LEARNING_PREVIEW_TRANSIT_2" does not exist, Sqlstate: 42V01, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Miner/server/vertica/Catalog/CatalogLookup.cpp, Line: 4362, Error Code: 4568, SQL: 'CREATE OR REPLACE VIEW "OW_SEDA_S_LOGISTIC"."VW_BASE_MACHINE_LEARNING_TRANSIT" (   "DELIVERY_NO",   "IOD_TRK_DATE",   "LT_CELLO",   "SHIPTO_ZIPCODE",   "ZIP_RANGE",   "SOLDTO_NM",   "ORIGIN",   "REGION",   "UF",   "AREA",   "PROVINCE",   "CARRIER_NAME",   "DIVISION",   "SALDO_DELTA_T_LEAD",   "FR_CARRIER",   "FR_CUSTOMER",   "FR_TAX",   "FR_NAT",   "FR_OTHER",   "CAPACIDADE_HISTORICA",   "DO_QTY_ACTUAL",   "OCCUP_ACTUAL",   "AVG_COUNT_HUB",   "COUNT_HUB_ACUM",   "DEFICT_COUNT_HUBS",   "IOD_STATUS",   "DO_QTY_ZIP",   "DO_QTY_ZIP_DELAYED",   "DO_QTY_PROVINCE",   "DO_QTY_PROVINCE_DELAYED",   "HISTORIC_DELAY_ZIP",   "HISTORIC_DELAY_PROVINCE" ) AS WITH "ML3" AS (   WITH "ML2" AS (     WITH "ML1" AS (       WITH "ML0" AS (         WITH "DB_ML_2" AS (           SELECT             ML.DELIVERY_NO,             ML.IOD_TRK_DATE,             ML.LT_CELLO,             ML.SHIPTO_ZIPCODE,             ML.ZIP_RANGE,             ML.SOLDTO_NM,             ML.ORIGIN,             ML.REGION,             ML.UF,             ML.AREA,             ML.PROVINCE,             ML.CARRIER_NAME,             ML.HUB_DESC,             ML.TRK_TYPE,             ML.DIVISION,             ML.SALDO_DELTA_T_LEAD,             ML.COUNT_HUB_ACUM,             ML.TRACKING_STATUS_CLASSIF,             ML.FIRST_BOOKING_DATE,             FP.TRK_NM,             FR.RESPONSIBLE_2 AS OCC_RESPONSIBLE           FROM OW_SEDA_S_LOGISTIC.ST_BASE_MACHINE_LEARNING_PREVIEW_TRANSIT_2 AS ML           LEFT JOIN (             SELECT               DELIVERY_NO,               TRK_NM,               TRK_DATE             FROM OW_SEDA_S.CELLO_FUTHER_PROCESSING AS FP           ) AS FP             ON ML.DELIVERY_NO = FP.DELIVERY_NO AND FP.TRK_DATE <= ML.TRK_DATE           LEFT JOIN (             SELECT               FIRST_OCCR,               RESPONSIBLE_2             FROM OW_SEDA_S_LOGISTIC.ST_DELIVERY_FAILURE_REASON AS FR           ) AS FR             ON REPLACE(LOWER(FP.TRK_NM), \'\'\'\', \'\') = LOWER(FR.FIRST_OCCR)           WHERE             NOT LAST_TRK IS NULL         )         SELECT           DELIVERY_NO,           IOD_TRK_DATE,           LT_CELLO,           SHIPTO_ZIPCODE,           ZIP_RANGE,           SOLDTO_NM,           ORIGIN,           REGION,           UF,           AREA,           PROVINCE,           CARRIER_NAME,           HUB_DESC,           TRK_TYPE,           DIVISION,           SALDO_DELTA_T_LEAD,           COUNT_HUB_ACUM,           TRACKING_STATUS_CLASSIF,           FIRST_BOOKING_DATE,           COUNT(CASE WHEN LOWER(OCC_RESPONSIBLE) = \'carrier failure\' THEN 1 ELSE NULL END) AS FR_CARRIER,           COUNT(CASE WHEN LOWER(OCC_RESPONSIBLE) = \'consumer reason\' THEN 1 ELSE NULL END) AS FR_CUSTOMER,           COUNT(CASE WHEN LOWER(OCC_RESPONSIBLE) = \'tax block\' THEN 1 ELSE NULL END) AS FR_TAX,           COUNT(CASE WHEN LOWER(OCC_RESPONSIBLE) = \'natural causes\' THEN 1 ELSE NULL END) AS FR_NAT,           COUNT(CASE WHEN LOWER(OCC_RESPONSIBLE) = \'others\' THEN 1 ELSE NULL END) AS FR_OTHER         FROM DB_ML_2         GROUP BY           DELIVERY_NO,           IOD_TRK_DATE,           LT_CELLO,           SHIPTO_ZIPCODE,           ZIP_RANGE,           SOLDTO_NM,           ORIGIN,           REGION,           UF,           AREA,           PROVINCE,           CARRIER_NAME,           HUB_DESC,           TRK_TYPE,           DIVISION,           SALDO_DELTA_T_LEAD,           COUNT_HUB_ACUM,           TRACKING_STATUS_CLASSIF,           FIRST_BOOKING_DATE       )       SELECT         "MLP2"."DELIVERY_NO",         "MLP2"."IOD_TRK_DATE",         "MLP2"."LT_CELLO",         "MLP2"."SHIPTO_ZIPCODE",         "MLP2"."ZIP_RANGE",         "MLP2"."SOLDTO_NM",         "MLP2"."ORIGIN",         "MLP2"."REGION",         "MLP2"."UF",         "MLP2"."AREA",         "MLP2"."PROVINCE",         "MLP2"."CARRIER_NAME",         "MLP2"."HUB_DESC",         "MLP2"."TRK_TYPE",         "MLP2"."DIVISION",         "MLP2"."SALDO_DELTA_T_LEAD",         "MLP2"."COUNT_HUB_ACUM",         "MLP2"."TRACKING_STATUS_CLASSIF",         "MLP2"."FIRST_BOOKING_DATE",         "MLP2"."FR_CARRIER",         "MLP2"."FR_CUSTOMER",         "MLP2"."FR_TAX",         "MLP2"."FR_NAT",         "MLP2"."FR_OTHER",         "MLP1"."CAPACIDADE_HISTORICA",         "MLP3"."AVG_COUNT_HUB"       FROM ML0 AS MLP2       LEFT JOIN (         SELECT           CARRIER_NAME || UF AS CAPACITY_AGROUP,           CARRIER_NAME,           UF,           COUNT(DISTINCT (             IOD_TRK_DATE           )) AS DAYS_QTY,           COUNT(DISTINCT (             DELIVERY_NO           )) AS DO_QTY,           CASE             WHEN COUNT(DISTINCT (               IOD_TRK_DATE             )) = 0             THEN 0             ELSE ROUND(COUNT(DISTINCT (               DELIVERY_NO             )) / COUNT(DISTINCT (               IOD_TRK_DATE             )), 0)           END AS CAPACIDADE_HISTORICA         FROM ML0         GROUP BY           CARRIER_NAME,           UF       ) AS MLP1         ON MLP2.CARRIER_NAME || MLP2.UF = MLP1.CAPACITY_AGROUP       LEFT JOIN ML0 AS MLP1_2         ON MLP2.DELIVERY_NO = MLP1_2.DELIVERY_NO       LEFT JOIN (         SELECT           ORIGIN || CARRIER_NAME || UF || PROVINCE AS COUNT_HUB_AGROUP,           ORIGIN,           CARRIER_NAME,           UF,           PROVINCE,           ROUND(AVG(COUNT_HUB_ACUM), 0) AS AVG_COUNT_HUB         FROM ML0         GROUP BY           ORIGIN,           CARRIER_NAME,           UF,           PROVINCE       ) AS MLP3         ON MLP2.ORIGIN || MLP2.CARRIER_NAME || MLP2.UF || MLP2.PROVINCE = MLP3.COUNT_HUB_AGROUP     )     SELECT       DELIVERY_NO,       TO_DATE((IOD_TRK_DATE)::VARCHAR, \'YYYY-MM-DD\') AS IOD_TRK_DATE,       LT_CELLO,       SHIPTO_ZIPCODE,       ZIP_RANGE,       SOLDTO_NM,       ORIGIN,       REGION,       UF,       AREA,       PROVINCE,       CARRIER_NAME,       DIVISION,       SALDO_DELTA_T_LEAD,       FR_CARRIER,       FR_CUSTOMER,       FR_TAX,       FR_NAT,       FR_OTHER,       CAPACIDADE_HISTORICA,       COUNT(DISTINCT (         DELIVERY_NO       )) OVER (PARTITION BY CARRIER_NAME, UF, IOD_TRK_DATE) AS DO_QTY_ACTUAL,       CASE         WHEN CAPACIDADE_HISTORICA = 0         THEN 0         ELSE ROUND(           (             COUNT(DISTINCT (               DELIVERY_NO             )) OVER (PARTITION BY CARRIER_NAME, UF, IOD_TRK_DATE) / CAPACIDADE_HISTORICA           ) * 100,           2         )       END AS OCCUP_ACTUAL,       AVG_COUNT_HUB,       COUNT_HUB_ACUM,       COUNT_HUB_ACUM - AVG_COUNT_HUB AS DEFICT_COUNT_HUBS,       CASE WHEN IOD_TRK_DATE > FIRST_BOOKING_DATE THEN \'Delayed\' ELSE \'On time\' END AS IOD_STATUS     FROM ML1   )   SELECT     "ML2"."DELIVERY_NO",     "ML2"."IOD_TRK_DATE",     "ML2"."LT_CELLO",     "ML2"."SHIPTO_ZIPCODE",     "ML2"."ZIP_RANGE",     "ML2"."SOLDTO_NM",     "ML2"."ORIGIN",     "ML2"."REGION",     "ML2"."UF",     "ML2"."AREA",     "ML2"."PROVINCE",     "ML2"."CARRIER_NAME",     "ML2"."DIVISION",     "ML2"."SALDO_DELTA_T_LEAD",     "ML2"."FR_CARRIER",     "ML2"."FR_CUSTOMER",     "ML2"."FR_TAX",     "ML2"."FR_NAT",     "ML2"."FR_OTHER",     "ML2"."CAPACIDADE_HISTORICA",     "ML2"."DO_QTY_ACTUAL",     "ML2"."OCCUP_ACTUAL",     "ML2"."AVG_COUNT_HUB",     "ML2"."COUNT_HUB_ACUM",     "ML2"."DEFICT_COUNT_HUBS",     "ML2"."IOD_STATUS",     COUNT(DISTINCT (       DELIVERY_NO     )) OVER (PARTITION BY ORIGIN, CARRIER_NAME, UF, PROVINCE, SHIPTO_ZIPCODE) AS DO_QTY_ZIP,     COUNT(DISTINCT CASE WHEN IOD_STATUS = \'Delayed\' THEN DELIVERY_NO END) OVER (PARTITION BY ORIGIN, CARRIER_NAME, UF, PROVINCE, SHIPTO_ZIPCODE) AS DO_QTY_ZIP_DELAYED,     COUNT(DISTINCT (       DELIVERY_NO     )) OVER (PARTITION BY ORIGIN, CARRIER_NAME, UF, PROVINCE) AS DO_QTY_PROVINCE,     COUNT(DISTINCT CASE WHEN IOD_STATUS = \'Delayed\' THEN DELIVERY_NO END) OVER (PARTITION BY ORIGIN, CARRIER_NAME, UF, PROVINCE) AS DO_QTY_PROVINCE_DELAYED   FROM ML2 ) SELECT   "ML3"."DELIVERY_NO",   "ML3"."IOD_TRK_DATE",   "ML3"."LT_CELLO",   "ML3"."SHIPTO_ZIPCODE",   "ML3"."ZIP_RANGE",   "ML3"."SOLDTO_NM",   "ML3"."ORIGIN",   "ML3"."REGION",   "ML3"."UF",   "ML3"."AREA",   "ML3"."PROVINCE",   "ML3"."CARRIER_NAME",   "ML3"."DIVISION",   "ML3"."SALDO_DELTA_T_LEAD",   "ML3"."FR_CARRIER",   "ML3"."FR_CUSTOMER",   "ML3"."FR_TAX",   "ML3"."FR_NAT",   "ML3"."FR_OTHER",   "ML3"."CAPACIDADE_HISTORICA",   "ML3"."DO_QTY_ACTUAL",   "ML3"."OCCUP_ACTUAL",   "ML3"."AVG_COUNT_HUB",   "ML3"."COUNT_HUB_ACUM",   "ML3"."DEFICT_COUNT_HUBS",   "ML3"."IOD_STATUS",   "ML3"."DO_QTY_ZIP",   "ML3"."DO_QTY_ZIP_DELAYED",   "ML3"."DO_QTY_PROVINCE",   "ML3"."DO_QTY_PROVINCE_DELAYED",   ROUND((     DO_QTY_ZIP_DELAYED / DO_QTY_ZIP   ) * 100, 2) AS HISTORIC_DELAY_ZIP,   ROUND((     DO_QTY_PROVINCE_DELAYED / DO_QTY_PROVINCE   ) * 100, 2) AS HISTORIC_DELAY_PROVINCE FROM ML3'

CREATE VIEW "OW_SEDA_S_LOGISTIC"."VW_BASE_MACHINE_LEARNING_TRANSIT" (
  "DELIVERY_NO",
  "IOD_TRK_DATE",
  "LT_CELLO",
  "SHIPTO_ZIPCODE",
  "ZIP_RANGE",
  "SOLDTO_NM",
  "ORIGIN",
  "REGION",
  "UF",
  "AREA",
  "PROVINCE",
  "CARRIER_NAME",
  "DIVISION",
  "SALDO_DELTA_T_LEAD",
  "FR_CARRIER",
  "FR_CUSTOMER",
  "FR_TAX",
  "FR_NAT",
  "FR_OTHER",
  "CAPACIDADE_HISTORICA",
  "DO_QTY_ACTUAL",
  "OCCUP_ACTUAL",
  "AVG_COUNT_HUB",
  "COUNT_HUB_ACUM",
  "DEFICT_COUNT_HUBS",
  "IOD_STATUS",
  "DO_QTY_ZIP",
  "DO_QTY_ZIP_DELAYED",
  "DO_QTY_PROVINCE",
  "DO_QTY_PROVINCE_DELAYED",
  "HISTORIC_DELAY_ZIP",
  "HISTORIC_DELAY_PROVINCE"
) AS
WITH "ML3" AS (
  WITH "ML2" AS (
    WITH "ML1" AS (
      WITH "ML0" AS (
        WITH "DB_ML_2" AS (
          SELECT
            ML.DELIVERY_NO,
            ML.IOD_TRK_DATE,
            ML.LT_CELLO,
            ML.SHIPTO_ZIPCODE,
            ML.ZIP_RANGE,
            ML.SOLDTO_NM,
            ML.ORIGIN,
            ML.REGION,
            ML.UF,
            ML.AREA,
            ML.PROVINCE,
            ML.CARRIER_NAME,
            ML.HUB_DESC,
            ML.TRK_TYPE,
            ML.DIVISION,
            ML.SALDO_DELTA_T_LEAD,
            ML.COUNT_HUB_ACUM,
            ML.TRACKING_STATUS_CLASSIF,
            ML.FIRST_BOOKING_DATE,
            FP.TRK_NM,
            FR.RESPONSIBLE_2 AS OCC_RESPONSIBLE
          FROM OW_SEDA_S_LOGISTIC.ST_BASE_MACHINE_LEARNING_PREVIEW_TRANSIT_2 AS ML
          LEFT JOIN (
            SELECT
              DELIVERY_NO,
              TRK_NM,
              TRK_DATE
            FROM OW_SEDA_S.CELLO_FUTHER_PROCESSING AS FP
          ) AS FP
            ON ML.DELIVERY_NO = FP.DELIVERY_NO AND FP.TRK_DATE <= ML.TRK_DATE
          LEFT JOIN (
            SELECT
              FIRST_OCCR,
              RESPONSIBLE_2
            FROM OW_SEDA_S_LOGISTIC.ST_DELIVERY_FAILURE_REASON AS FR
          ) AS FR
            ON REPLACE(LOWER(FP.TRK_NM), '''', '') = LOWER(FR.FIRST_OCCR)
          WHERE
            NOT LAST_TRK IS NULL
        )
        SELECT
          DELIVERY_NO,
          IOD_TRK_DATE,
          LT_CELLO,
          SHIPTO_ZIPCODE,
          ZIP_RANGE,
          SOLDTO_NM,
          ORIGIN,
          REGION,
          UF,
          AREA,
          PROVINCE,
          CARRIER_NAME,
          HUB_DESC,
          TRK_TYPE,
          DIVISION,
          SALDO_DELTA_T_LEAD,
          COUNT_HUB_ACUM,
          TRACKING_STATUS_CLASSIF,
          FIRST_BOOKING_DATE,
          COUNT(CASE WHEN LOWER(OCC_RESPONSIBLE) = 'carrier failure' THEN 1 ELSE NULL END) AS FR_CARRIER,
          COUNT(CASE WHEN LOWER(OCC_RESPONSIBLE) = 'consumer reason' THEN 1 ELSE NULL END) AS FR_CUSTOMER,
          COUNT(CASE WHEN LOWER(OCC_RESPONSIBLE) = 'tax block' THEN 1 ELSE NULL END) AS FR_TAX,
          COUNT(CASE WHEN LOWER(OCC_RESPONSIBLE) = 'natural causes' THEN 1 ELSE NULL END) AS FR_NAT,
          COUNT(CASE WHEN LOWER(OCC_RESPONSIBLE) = 'others' THEN 1 ELSE NULL END) AS FR_OTHER
        FROM DB_ML_2
        GROUP BY
          DELIVERY_NO,
          IOD_TRK_DATE,
          LT_CELLO,
          SHIPTO_ZIPCODE,
          ZIP_RANGE,
          SOLDTO_NM,
          ORIGIN,
          REGION,
          UF,
          AREA,
          PROVINCE,
          CARRIER_NAME,
          HUB_DESC,
          TRK_TYPE,
          DIVISION,
          SALDO_DELTA_T_LEAD,
          COUNT_HUB_ACUM,
          TRACKING_STATUS_CLASSIF,
          FIRST_BOOKING_DATE
      )
      SELECT
        "MLP2"."DELIVERY_NO",
        "MLP2"."IOD_TRK_DATE",
        "MLP2"."LT_CELLO",
        "MLP2"."SHIPTO_ZIPCODE",
        "MLP2"."ZIP_RANGE",
        "MLP2"."SOLDTO_NM",
        "MLP2"."ORIGIN",
        "MLP2"."REGION",
        "MLP2"."UF",
        "MLP2"."AREA",
        "MLP2"."PROVINCE",
        "MLP2"."CARRIER_NAME",
        "MLP2"."HUB_DESC",
        "MLP2"."TRK_TYPE",
        "MLP2"."DIVISION",
        "MLP2"."SALDO_DELTA_T_LEAD",
        "MLP2"."COUNT_HUB_ACUM",
        "MLP2"."TRACKING_STATUS_CLASSIF",
        "MLP2"."FIRST_BOOKING_DATE",
        "MLP2"."FR_CARRIER",
        "MLP2"."FR_CUSTOMER",
        "MLP2"."FR_TAX",
        "MLP2"."FR_NAT",
        "MLP2"."FR_OTHER",
        "MLP1"."CAPACIDADE_HISTORICA",
        "MLP3"."AVG_COUNT_HUB"
      FROM ML0 AS MLP2
      LEFT JOIN (
        SELECT
          CARRIER_NAME || UF AS CAPACITY_AGROUP,
          CARRIER_NAME,
          UF,
          COUNT(DISTINCT (
            IOD_TRK_DATE
          )) AS DAYS_QTY,
          COUNT(DISTINCT (
            DELIVERY_NO
          )) AS DO_QTY,
          CASE
            WHEN COUNT(DISTINCT (
              IOD_TRK_DATE
            )) = 0
            THEN 0
            ELSE ROUND(COUNT(DISTINCT (
              DELIVERY_NO
            )) / COUNT(DISTINCT (
              IOD_TRK_DATE
            )), 0)
          END AS CAPACIDADE_HISTORICA
        FROM ML0
        GROUP BY
          CARRIER_NAME,
          UF
      ) AS MLP1
        ON MLP2.CARRIER_NAME || MLP2.UF = MLP1.CAPACITY_AGROUP
      LEFT JOIN ML0 AS MLP1_2
        ON MLP2.DELIVERY_NO = MLP1_2.DELIVERY_NO
      LEFT JOIN (
        SELECT
          ORIGIN || CARRIER_NAME || UF || PROVINCE AS COUNT_HUB_AGROUP,
          ORIGIN,
          CARRIER_NAME,
          UF,
          PROVINCE,
          ROUND(AVG(COUNT_HUB_ACUM), 0) AS AVG_COUNT_HUB
        FROM ML0
        GROUP BY
          ORIGIN,
          CARRIER_NAME,
          UF,
          PROVINCE
      ) AS MLP3
        ON MLP2.ORIGIN || MLP2.CARRIER_NAME || MLP2.UF || MLP2.PROVINCE = MLP3.COUNT_HUB_AGROUP
    )
    SELECT
      DELIVERY_NO,
      TO_DATE((IOD_TRK_DATE)::VARCHAR, 'YYYY-MM-DD') AS IOD_TRK_DATE,
      LT_CELLO,
      SHIPTO_ZIPCODE,
      ZIP_RANGE,
      SOLDTO_NM,
      ORIGIN,
      REGION,
      UF,
      AREA,
      PROVINCE,
      CARRIER_NAME,
      DIVISION,
      SALDO_DELTA_T_LEAD,
      FR_CARRIER,
      FR_CUSTOMER,
      FR_TAX,
      FR_NAT,
      FR_OTHER,
      CAPACIDADE_HISTORICA,
      COUNT(DISTINCT (
        DELIVERY_NO
      )) OVER (PARTITION BY CARRIER_NAME, UF, IOD_TRK_DATE) AS DO_QTY_ACTUAL,
      CASE
        WHEN CAPACIDADE_HISTORICA = 0
        THEN 0
        ELSE ROUND(
          (
            COUNT(DISTINCT (
              DELIVERY_NO
            )) OVER (PARTITION BY CARRIER_NAME, UF, IOD_TRK_DATE) / CAPACIDADE_HISTORICA
          ) * 100,
          2
        )
      END AS OCCUP_ACTUAL,
      AVG_COUNT_HUB,
      COUNT_HUB_ACUM,
      COUNT_HUB_ACUM - AVG_COUNT_HUB AS DEFICT_COUNT_HUBS,
      CASE WHEN IOD_TRK_DATE > FIRST_BOOKING_DATE THEN 'Delayed' ELSE 'On time' END AS IOD_STATUS
    FROM ML1
  )
  SELECT
    "ML2"."DELIVERY_NO",
    "ML2"."IOD_TRK_DATE",
    "ML2"."LT_CELLO",
    "ML2"."SHIPTO_ZIPCODE",
    "ML2"."ZIP_RANGE",
    "ML2"."SOLDTO_NM",
    "ML2"."ORIGIN",
    "ML2"."REGION",
    "ML2"."UF",
    "ML2"."AREA",
    "ML2"."PROVINCE",
    "ML2"."CARRIER_NAME",
    "ML2"."DIVISION",
    "ML2"."SALDO_DELTA_T_LEAD",
    "ML2"."FR_CARRIER",
    "ML2"."FR_CUSTOMER",
    "ML2"."FR_TAX",
    "ML2"."FR_NAT",
    "ML2"."FR_OTHER",
    "ML2"."CAPACIDADE_HISTORICA",
    "ML2"."DO_QTY_ACTUAL",
    "ML2"."OCCUP_ACTUAL",
    "ML2"."AVG_COUNT_HUB",
    "ML2"."COUNT_HUB_ACUM",
    "ML2"."DEFICT_COUNT_HUBS",
    "ML2"."IOD_STATUS",
    COUNT(DISTINCT (
      DELIVERY_NO
    )) OVER (PARTITION BY ORIGIN, CARRIER_NAME, UF, PROVINCE, SHIPTO_ZIPCODE) AS DO_QTY_ZIP,
    COUNT(DISTINCT CASE WHEN IOD_STATUS = 'Delayed' THEN DELIVERY_NO END) OVER (PARTITION BY ORIGIN, CARRIER_NAME, UF, PROVINCE, SHIPTO_ZIPCODE) AS DO_QTY_ZIP_DELAYED,
    COUNT(DISTINCT (
      DELIVERY_NO
    )) OVER (PARTITION BY ORIGIN, CARRIER_NAME, UF, PROVINCE) AS DO_QTY_PROVINCE,
    COUNT(DISTINCT CASE WHEN IOD_STATUS = 'Delayed' THEN DELIVERY_NO END) OVER (PARTITION BY ORIGIN, CARRIER_NAME, UF, PROVINCE) AS DO_QTY_PROVINCE_DELAYED
  FROM ML2
)
SELECT
  "ML3"."DELIVERY_NO",
  "ML3"."IOD_TRK_DATE",
  "ML3"."LT_CELLO",
  "ML3"."SHIPTO_ZIPCODE",
  "ML3"."ZIP_RANGE",
  "ML3"."SOLDTO_NM",
  "ML3"."ORIGIN",
  "ML3"."REGION",
  "ML3"."UF",
  "ML3"."AREA",
  "ML3"."PROVINCE",
  "ML3"."CARRIER_NAME",
  "ML3"."DIVISION",
  "ML3"."SALDO_DELTA_T_LEAD",
  "ML3"."FR_CARRIER",
  "ML3"."FR_CUSTOMER",
  "ML3"."FR_TAX",
  "ML3"."FR_NAT",
  "ML3"."FR_OTHER",
  "ML3"."CAPACIDADE_HISTORICA",
  "ML3"."DO_QTY_ACTUAL",
  "ML3"."OCCUP_ACTUAL",
  "ML3"."AVG_COUNT_HUB",
  "ML3"."COUNT_HUB_ACUM",
  "ML3"."DEFICT_COUNT_HUBS",
  "ML3"."IOD_STATUS",
  "ML3"."DO_QTY_ZIP",
  "ML3"."DO_QTY_ZIP_DELAYED",
  "ML3"."DO_QTY_PROVINCE",
  "ML3"."DO_QTY_PROVINCE_DELAYED",
  ROUND((
    DO_QTY_ZIP_DELAYED / DO_QTY_ZIP
  ) * 100, 2) AS HISTORIC_DELAY_ZIP,
  ROUND((
    DO_QTY_PROVINCE_DELAYED / DO_QTY_PROVINCE
  ) * 100, 2) AS HISTORIC_DELAY_PROVINCE
FROM ML3