-- MISSING RELATION: _SYS_BIC
-- ERROR: Error executing query: Severity: ERROR, Message: Schema "_SYS_BIC" does not exist, Sqlstate: 3F000, Routine: RangeVarGetObjid, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Miner/server/vertica/Catalog/NamespaceLookup.cpp, Line: 317, Error Code: 4650, SQL: 'CREATE OR REPLACE VIEW "U_PRJ_ECOM"."VIEW_ECOM_ORDERS_CUBO" (   "Acquirer_Message",   "CODIGO_PARCERIA",   "AFFILIATE_ID",   "ADDRESS_TYPE",   "Cancellation_Reason",   "Category",   "Channel",   "COD_SALES_CHANNEL",   "Country",   "Creation_Date",   "Month",   "Year",   "Day",   "IS_TRADE_IN",   "IS_SAMSUNG_CARE",   "Last_Update_Date",   "CUSTOMER_ID",   "Division",   "Hostname",   "Internal_Status",   "Status",   "Invoice_Number",   "Mkt_Campaign_Tags",   "Mkt_Utm_Campaign",   "Mkt_Utm_Coupon",   "Mkt_Utm_Medium",   "Mkt_Utm_Src",   "Mkt_Utmi_Campaign",   "ORDER_SEQUENCE",   "Payment_Type",   "Brand",   "INSTALLMENT",   "Product_Name",   "Reference_Code",   "Seller_Id",   "SELLER_INSTANCE_ID",   "Seller_Name",   "Seller_Order_Id",   "Order_Id",   "Shipping_Cost_Item",   "Subsidiary",   "Subsidiary_Id",   "Trade_Policy",   "Vendor",   "Tax_Converter",   "Units",   "Price",   "Item_Discount",   "Total_Item",   "Total_Item_USD",   "CAMELAGEM",   "BASE" ) AS (   (     (       SELECT DISTINCT         a."Acquirer_Message",         d.codigoParceria AS codigo_parceria,         a.Affiliate_Id,         a.ADDRESS_TYPE AS Address_Type,         a."Cancellation_Reason",         a."Category",         a."Channel",         a.COD_SALES_CHANNEL AS Cod_Sales_Channel,         a."Country",         a."Creation_Date",         MONTH(a."Creation_Date") AS "Month",         YEAR(a."Creation_Date") AS "Year",         EXTRACT(DAY FROM a."Creation_Date") AS "Day",         a.IS_TRADE_IN,         a.IS_SAMSUNG_CARE,         a."Last_Update_Date",         a.CUSTOMER_ID AS Customer_Id,         a."Division",         a."Hostname",         a."Internal_Status",         a."Status",         a."Invoice_Number",         a."Mkt_Campaign_Tags",         a."Mkt_Utm_Campaign",         a."Mkt_Utm_Coupon",         a."Mkt_Utm_Medium",         a."Mkt_Utm_Src",         a."Mkt_Utmi_Campaign",         a.ORDER_SEQUENCE AS Order_Sequence,         a."Payment_Type",         a."Brand",         a.INSTALLMENT AS Installment,         a."Product_Name",         a."Reference_Code",         a."Seller_Id",         a.SELLER_INSTANCE_ID AS Seller_Instance_Id,         a."Seller_Name",         a."Seller_Order_Id",         a."Order_Id",         a."Shipping_Cost_Item",         a."Subsidiary",         a."Subsidiary_Id",         a."Trade_Policy",         a."Vendor",         a."Tax_Converter",         a."Units",         a."Price",         a."Item_Discount",         a."Total_Item",         a."Total_Item_USD",         CAST(CASE WHEN NOT a."Order_Id" IS NULL THEN \'YES\' END AS VARCHAR) AS CAMELAGEM,         CAST(CASE WHEN NOT a."Order_Id" IS NULL THEN 1 END AS VARCHAR) AS BASE       FROM "_SYS_BIC"."SDSLA_ECOM/CV_PAYMENT_RAW_DATA_SAMSUNGBR_V2" AS a       JOIN "U_PRJ_ECOM"."FT_ECOM_ORDER" AS b         ON b.id = a.id       JOIN "U_PRJ_ECOM"."DIM_CUSTOMER" AS c         ON c.id = b.customer_id       LEFT JOIN "U_PRJ_ECOM"."ODS_VTEX_MASTER_DATA_CL" AS d         ON d.userId = c.external_id         AND d.subsidiary_id = b.subsidiary_id         AND d.hostname = b.hostname       WHERE         CAST(a."Creation_Date" AS DATE) BETWEEN CAST(TIMESTAMPADD(DAY, -365, (NOW())::TIMESTAMP) AS DATE) AND CAST(TIMESTAMPADD(DAY, 0, (NOW())::TIMESTAMP) AS DATE)         AND NOT "Subsidiary_Id" IN (6)     )     UNION ALL     (       SELECT DISTINCT         b."Acquirer_Message",         NULL AS codigo_parceria,         b.Affiliate_Id,         b.ADDRESS_TYPE AS Address_Type,         b."Cancellation_Reason",         b."Category",         b."Channel",         b.COD_SALES_CHANNEL AS Cod_Sales_Channel,         b."Country",         b."Creation_Date",         MONTH(b."Creation_Date") AS "Month",         YEAR(b."Creation_Date") AS "Year",         EXTRACT(DAY FROM b."Creation_Date") AS "Day",         b.IS_TRADE_IN,         b.IS_SAMSUNG_CARE,         b."Last_Update_Date",         b.CUSTOMER_ID AS Customer_Id,         b."Division",         b."Hostname",         b."Internal_Status",         b."Status",         b."Invoice_Number",         b."Mkt_Campaign_Tags",         b."Mkt_Utm_Campaign",         b."Mkt_Utm_Coupon",         b."Mkt_Utm_Medium",         b."Mkt_Utm_Src",         b."Mkt_Utmi_Campaign",         b.ORDER_SEQUENCE AS Order_Sequence,         b."Payment_Type",         b."Brand",         b.INSTALLMENT AS Installment,         b."Product_Name",         b."Reference_Code",         b."Seller_Id",         b.SELLER_INSTANCE_ID AS Seller_Instance_Id,         b."Seller_Name",         b."Seller_Order_Id",         b."Order_Id",         b."Shipping_Cost_Item",         b."Subsidiary",         b."Subsidiary_Id",         b."Trade_Policy",         b."Vendor",         b."Tax_Converter",         b."Units",         b."Price",         b."Item_Discount",         b."Total_Item",         b."Total_Item_USD",         CAST(CASE           WHEN IS_TRADE_IN = 1           THEN \'YES\'           WHEN IS_SAMSUNG_CARE = 1           THEN \'YES\'           ELSE \'NOTHING\'         END AS VARCHAR) AS CAMELAGEM,         CAST(CASE WHEN NOT "Order_Id" IS NULL THEN 2 END AS VARCHAR) AS BASE       FROM "_SYS_BIC"."SDSLA_ECOM/CV_PAYMENT_RAW_DATA_SAMSUNGBR_V2" AS b       WHERE         CAST(b."Creation_Date" AS DATE) BETWEEN CAST(TIMESTAMPADD(DAY, -365, (NOW())::TIMESTAMP) AS DATE) AND CAST(TIMESTAMPADD(DAY, 0, (NOW())::TIMESTAMP) AS DATE)         AND b."Subsidiary_Id" = 6     )   )   UNION ALL   (     SELECT DISTINCT       a."Acquirer_Message",       NULL AS codigo_parceria,       a."Affiliate_Id",       a.ADDRESS_TYPE AS Address_Type,       a."Cancellation_Reason",       a."Category",       a."Channel",       a.COD_SALES_CHANNEL AS Cod_Sales_Channel,       a."Country",       a."Creation_Date",       MONTH(a."Creation_Date") AS "Month",       YEAR(a."Creation_Date") AS "Year",       EXTRACT(DAY FROM a."Creation_Date") AS "Day",       a.IS_TRADE_IN,       a.IS_SAMSUNG_CARE,       a."Last_Update_Date",       a.CUSTOMER_ID AS Customer_Id,       a."Division",       a."Hostname",       a."Internal_Status",       a."Status",       a."Invoice_Number",       a."Mkt_Campaign_Tags",       a."Mkt_Utm_Campaign",       a."Mkt_Utm_Coupon",       a."Mkt_Utm_Medium",       a."Mkt_Utm_Src",       a."Mkt_Utmi_Campaign",       a.ORDER_SEQUENCE AS Order_Sequence,       a."Payment_Type",       a."Brand",       a.INSTALLMENT AS Installment,       a."Product_Name",       a."Reference_Code",       a."Seller_Id",       a.SELLER_INSTANCE_ID AS Seller_Instance_Id,       a."Seller_Name",       a."Seller_Order_Id",       a."Order_Id",       a."Shipping_Cost_Item",       a."Subsidiary",       a."Subsidiary_Id",       a."Trade_Policy",       a."Vendor",       a."Tax_Converter",       a."Units",       a."Price",       a."Item_Discount",       a."Total_Item",       a."Total_Item_USD",       CAST(CASE WHEN IS_SAMSUNG_CARE = 1 THEN \'NO\' ELSE \'YES\' END AS VARCHAR) AS CAMELAGEM,       CAST(CASE WHEN NOT "Order_Id" IS NULL THEN 3 END AS VARCHAR) AS BASE     FROM "_SYS_BIC"."SDSLA_ECOM/CV_PAYMENT_RAW_DATA_SYNAPCON_BRSHOP_V2" AS a     WHERE       NOT EXISTS(         SELECT           b."Seller_Order_Id"         FROM "_SYS_BIC"."SDSLA_ECOM/CV_PAYMENT_RAW_DATA_SAMSUNGBR_V2" AS b         WHERE           b."Seller_Order_Id" = a."Order_Id"       )       AND CAST(a."Creation_Date" AS DATE) BETWEEN CAST(TIMESTAMPADD(DAY, -365, (NOW())::TIMESTAMP) AS DATE) AND CAST(TIMESTAMPADD(DAY, 0, (NOW())::TIMESTAMP) AS DATE)   ) )'

CREATE VIEW "U_PRJ_ECOM"."VIEW_ECOM_ORDERS_CUBO" (
  "Acquirer_Message",
  "CODIGO_PARCERIA",
  "AFFILIATE_ID",
  "ADDRESS_TYPE",
  "Cancellation_Reason",
  "Category",
  "Channel",
  "COD_SALES_CHANNEL",
  "Country",
  "Creation_Date",
  "Month",
  "Year",
  "Day",
  "IS_TRADE_IN",
  "IS_SAMSUNG_CARE",
  "Last_Update_Date",
  "CUSTOMER_ID",
  "Division",
  "Hostname",
  "Internal_Status",
  "Status",
  "Invoice_Number",
  "Mkt_Campaign_Tags",
  "Mkt_Utm_Campaign",
  "Mkt_Utm_Coupon",
  "Mkt_Utm_Medium",
  "Mkt_Utm_Src",
  "Mkt_Utmi_Campaign",
  "ORDER_SEQUENCE",
  "Payment_Type",
  "Brand",
  "INSTALLMENT",
  "Product_Name",
  "Reference_Code",
  "Seller_Id",
  "SELLER_INSTANCE_ID",
  "Seller_Name",
  "Seller_Order_Id",
  "Order_Id",
  "Shipping_Cost_Item",
  "Subsidiary",
  "Subsidiary_Id",
  "Trade_Policy",
  "Vendor",
  "Tax_Converter",
  "Units",
  "Price",
  "Item_Discount",
  "Total_Item",
  "Total_Item_USD",
  "CAMELAGEM",
  "BASE"
) AS
(
  (
    (
      SELECT DISTINCT
        a."Acquirer_Message",
        d.codigoParceria AS codigo_parceria,
        a.Affiliate_Id,
        a.ADDRESS_TYPE AS Address_Type,
        a."Cancellation_Reason",
        a."Category",
        a."Channel",
        a.COD_SALES_CHANNEL AS Cod_Sales_Channel,
        a."Country",
        a."Creation_Date",
        MONTH(a."Creation_Date") AS "Month",
        YEAR(a."Creation_Date") AS "Year",
        EXTRACT(DAY FROM a."Creation_Date") AS "Day",
        a.IS_TRADE_IN,
        a.IS_SAMSUNG_CARE,
        a."Last_Update_Date",
        a.CUSTOMER_ID AS Customer_Id,
        a."Division",
        a."Hostname",
        a."Internal_Status",
        a."Status",
        a."Invoice_Number",
        a."Mkt_Campaign_Tags",
        a."Mkt_Utm_Campaign",
        a."Mkt_Utm_Coupon",
        a."Mkt_Utm_Medium",
        a."Mkt_Utm_Src",
        a."Mkt_Utmi_Campaign",
        a.ORDER_SEQUENCE AS Order_Sequence,
        a."Payment_Type",
        a."Brand",
        a.INSTALLMENT AS Installment,
        a."Product_Name",
        a."Reference_Code",
        a."Seller_Id",
        a.SELLER_INSTANCE_ID AS Seller_Instance_Id,
        a."Seller_Name",
        a."Seller_Order_Id",
        a."Order_Id",
        a."Shipping_Cost_Item",
        a."Subsidiary",
        a."Subsidiary_Id",
        a."Trade_Policy",
        a."Vendor",
        a."Tax_Converter",
        a."Units",
        a."Price",
        a."Item_Discount",
        a."Total_Item",
        a."Total_Item_USD",
        CAST(CASE WHEN NOT a."Order_Id" IS NULL THEN 'YES' END AS VARCHAR) AS CAMELAGEM,
        CAST(CASE WHEN NOT a."Order_Id" IS NULL THEN 1 END AS VARCHAR) AS BASE
      FROM "_SYS_BIC"."SDSLA_ECOM/CV_PAYMENT_RAW_DATA_SAMSUNGBR_V2" AS a
      JOIN "U_PRJ_ECOM"."FT_ECOM_ORDER" AS b
        ON b.id = a.id
      JOIN "U_PRJ_ECOM"."DIM_CUSTOMER" AS c
        ON c.id = b.customer_id
      LEFT JOIN "U_PRJ_ECOM"."ODS_VTEX_MASTER_DATA_CL" AS d
        ON d.userId = c.external_id
        AND d.subsidiary_id = b.subsidiary_id
        AND d.hostname = b.hostname
      WHERE
        CAST(a."Creation_Date" AS DATE) BETWEEN CAST(TIMESTAMPADD(DAY, -365, (NOW())::TIMESTAMP) AS DATE) AND CAST(TIMESTAMPADD(DAY, 0, (NOW())::TIMESTAMP) AS DATE)
        AND NOT "Subsidiary_Id" IN (6)
    )
    UNION ALL
    (
      SELECT DISTINCT
        b."Acquirer_Message",
        NULL AS codigo_parceria,
        b.Affiliate_Id,
        b.ADDRESS_TYPE AS Address_Type,
        b."Cancellation_Reason",
        b."Category",
        b."Channel",
        b.COD_SALES_CHANNEL AS Cod_Sales_Channel,
        b."Country",
        b."Creation_Date",
        MONTH(b."Creation_Date") AS "Month",
        YEAR(b."Creation_Date") AS "Year",
        EXTRACT(DAY FROM b."Creation_Date") AS "Day",
        b.IS_TRADE_IN,
        b.IS_SAMSUNG_CARE,
        b."Last_Update_Date",
        b.CUSTOMER_ID AS Customer_Id,
        b."Division",
        b."Hostname",
        b."Internal_Status",
        b."Status",
        b."Invoice_Number",
        b."Mkt_Campaign_Tags",
        b."Mkt_Utm_Campaign",
        b."Mkt_Utm_Coupon",
        b."Mkt_Utm_Medium",
        b."Mkt_Utm_Src",
        b."Mkt_Utmi_Campaign",
        b.ORDER_SEQUENCE AS Order_Sequence,
        b."Payment_Type",
        b."Brand",
        b.INSTALLMENT AS Installment,
        b."Product_Name",
        b."Reference_Code",
        b."Seller_Id",
        b.SELLER_INSTANCE_ID AS Seller_Instance_Id,
        b."Seller_Name",
        b."Seller_Order_Id",
        b."Order_Id",
        b."Shipping_Cost_Item",
        b."Subsidiary",
        b."Subsidiary_Id",
        b."Trade_Policy",
        b."Vendor",
        b."Tax_Converter",
        b."Units",
        b."Price",
        b."Item_Discount",
        b."Total_Item",
        b."Total_Item_USD",
        CAST(CASE
          WHEN IS_TRADE_IN = 1
          THEN 'YES'
          WHEN IS_SAMSUNG_CARE = 1
          THEN 'YES'
          ELSE 'NOTHING'
        END AS VARCHAR) AS CAMELAGEM,
        CAST(CASE WHEN NOT "Order_Id" IS NULL THEN 2 END AS VARCHAR) AS BASE
      FROM "_SYS_BIC"."SDSLA_ECOM/CV_PAYMENT_RAW_DATA_SAMSUNGBR_V2" AS b
      WHERE
        CAST(b."Creation_Date" AS DATE) BETWEEN CAST(TIMESTAMPADD(DAY, -365, (NOW())::TIMESTAMP) AS DATE) AND CAST(TIMESTAMPADD(DAY, 0, (NOW())::TIMESTAMP) AS DATE)
        AND b."Subsidiary_Id" = 6
    )
  )
  UNION ALL
  (
    SELECT DISTINCT
      a."Acquirer_Message",
      NULL AS codigo_parceria,
      a."Affiliate_Id",
      a.ADDRESS_TYPE AS Address_Type,
      a."Cancellation_Reason",
      a."Category",
      a."Channel",
      a.COD_SALES_CHANNEL AS Cod_Sales_Channel,
      a."Country",
      a."Creation_Date",
      MONTH(a."Creation_Date") AS "Month",
      YEAR(a."Creation_Date") AS "Year",
      EXTRACT(DAY FROM a."Creation_Date") AS "Day",
      a.IS_TRADE_IN,
      a.IS_SAMSUNG_CARE,
      a."Last_Update_Date",
      a.CUSTOMER_ID AS Customer_Id,
      a."Division",
      a."Hostname",
      a."Internal_Status",
      a."Status",
      a."Invoice_Number",
      a."Mkt_Campaign_Tags",
      a."Mkt_Utm_Campaign",
      a."Mkt_Utm_Coupon",
      a."Mkt_Utm_Medium",
      a."Mkt_Utm_Src",
      a."Mkt_Utmi_Campaign",
      a.ORDER_SEQUENCE AS Order_Sequence,
      a."Payment_Type",
      a."Brand",
      a.INSTALLMENT AS Installment,
      a."Product_Name",
      a."Reference_Code",
      a."Seller_Id",
      a.SELLER_INSTANCE_ID AS Seller_Instance_Id,
      a."Seller_Name",
      a."Seller_Order_Id",
      a."Order_Id",
      a."Shipping_Cost_Item",
      a."Subsidiary",
      a."Subsidiary_Id",
      a."Trade_Policy",
      a."Vendor",
      a."Tax_Converter",
      a."Units",
      a."Price",
      a."Item_Discount",
      a."Total_Item",
      a."Total_Item_USD",
      CAST(CASE WHEN IS_SAMSUNG_CARE = 1 THEN 'NO' ELSE 'YES' END AS VARCHAR) AS CAMELAGEM,
      CAST(CASE WHEN NOT "Order_Id" IS NULL THEN 3 END AS VARCHAR) AS BASE
    FROM "_SYS_BIC"."SDSLA_ECOM/CV_PAYMENT_RAW_DATA_SYNAPCON_BRSHOP_V2" AS a
    WHERE
      NOT EXISTS(
        SELECT
          b."Seller_Order_Id"
        FROM "_SYS_BIC"."SDSLA_ECOM/CV_PAYMENT_RAW_DATA_SAMSUNGBR_V2" AS b
        WHERE
          b."Seller_Order_Id" = a."Order_Id"
      )
      AND CAST(a."Creation_Date" AS DATE) BETWEEN CAST(TIMESTAMPADD(DAY, -365, (NOW())::TIMESTAMP) AS DATE) AND CAST(TIMESTAMPADD(DAY, 0, (NOW())::TIMESTAMP) AS DATE)
  )
)