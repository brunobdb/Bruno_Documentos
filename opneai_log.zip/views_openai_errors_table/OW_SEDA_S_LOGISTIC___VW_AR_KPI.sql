-- MISSING RELATION: OW_SEDA_S_LOGISTIC.VW_AR_KPI_OPEN
-- ERROR: Error executing query: Severity: ERROR, Message: Relation "OW_SEDA_S_LOGISTIC.VW_AR_KPI_OPEN" does not exist, Sqlstate: 42V01, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Miner/server/vertica/Catalog/CatalogLookup.cpp, Line: 4362, Error Code: 4568, SQL: 'CREATE OR REPLACE VIEW "OW_SEDA_S_LOGISTIC"."VW_AR_KPI" (   "TYPE",   "IN_OVER",   "DATE",   "AGING_CLOSING",   "CNT",   "AMT",   "AMT_NEG",   "AMT_POS" ) AS SELECT   TYPE,   IN_OVER,   EXTRACTION_DATE AS DATE,   AGING_CLOSING,   CNT,   AMT,   AMT_NEG,   AMT_POS FROM (   SELECT     *   FROM OW_SEDA_S_LOGISTIC.VW_AR_KPI_OPEN ) AS subq_2976'

CREATE OR REPLACE VIEW "OW_SEDA_S_LOGISTIC"."VW_AR_KPI" (
  "TYPE",
  "IN_OVER",
  "DATE",
  "AGING_CLOSING",
  "CNT",
  "AMT",
  "AMT_NEG",
  "AMT_POS"
) AS
SELECT
  TYPE,
  IN_OVER,
  EXTRACTION_DATE AS DATE,
  AGING_CLOSING,
  CNT,
  AMT,
  AMT_NEG,
  AMT_POS
FROM (
  SELECT
    *
  FROM OW_SEDA_S_LOGISTIC.VW_AR_KPI_OPEN
) AS subq_2976