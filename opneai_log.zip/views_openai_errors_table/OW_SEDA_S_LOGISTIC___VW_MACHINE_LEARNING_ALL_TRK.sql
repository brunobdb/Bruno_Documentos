-- MISSING RELATION: OW_SEDA_S_LOGISTIC.ST_MACHINE_LEARNING_CELLO_TRK
-- ERROR: Error executing query: Severity: ERROR, Message: Relation "OW_SEDA_S_LOGISTIC.ST_MACHINE_LEARNING_CELLO_TRK" does not exist, Sqlstate: 42V01, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Miner/server/vertica/Catalog/CatalogLookup.cpp, Line: 4362, Error Code: 4568, SQL: 'CREATE OR REPLACE VIEW "OW_SEDA_S_LOGISTIC"."VW_MACHINE_LEARNING_ALL_TRK" (   "DELIVERY_NO",   "TRK_CODE",   "PARTNER_ID",   "EVENT_DESC",   "TRK_DATE" ) AS WITH "DB2" AS (   WITH "DB1" AS (     (       (         (           (             SELECT               "DELIVERY_NO",               "TRK_CODE",               "PARTNER_ID",               "EVENT_DESC",               "TRK_DATE"             FROM OW_SEDA_S_LOGISTIC.ST_MACHINE_LEARNING_CELLO_TRK             WHERE               NOT TRK_CODE LIKE \'%TOD50%\'           )           UNION ALL           (             SELECT               "DELIVERY_NO",               "TRK_CODE",               "PARTNER_ID",               "EVENT_DESC",               "TRK_DATE"             FROM OW_SEDA_S_LOGISTIC.ST_MACHINE_LEARNING_CELLO_TRK_TOD50           )         )         UNION ALL         (           SELECT             "DELIVERY_NO",             "TRK_CODE",             "PARTNER_ID",             "EVENT_DESC",             "TRK_DATE"           FROM OW_SEDA_S_LOGISTIC.ST_MACHINE_LEARNING_CELLO_FP         )       )       UNION ALL       (         SELECT           "DELIVERY_NO",           "TRK_CODE",           "PARTNER_ID",           "EVENT_DESC",           "TRK_DATE"         FROM OW_SEDA_S_LOGISTIC.ST_MACHINE_LEARNING_CELLO_GI       )     )   )   SELECT     DELIVERY_NO,     CASE       WHEN TRK_CODE = \'TOD50_3\'       AND LAG(TRK_CODE) OVER (PARTITION BY DELIVERY_NO ORDER BY TRK_DATE ASC) = \'TOD50_1\'       THEN \'TOD50_2\'       WHEN TRK_CODE LIKE \'OC%\'       AND LAG(TRK_CODE) OVER (PARTITION BY DELIVERY_NO ORDER BY TRK_DATE ASC) = \'TOD50_1\'       THEN \'OCC_1\'       WHEN TRK_CODE LIKE \'OC%\'       AND LAG(TRK_CODE) OVER (PARTITION BY DELIVERY_NO ORDER BY TRK_DATE ASC) = \'TOD50_2\'       THEN \'OCC_2\'       WHEN TRK_CODE LIKE \'OC%\'       AND LAG(TRK_CODE) OVER (PARTITION BY DELIVERY_NO ORDER BY TRK_DATE ASC) = \'TOD50_3\'       THEN \'OCC_3\'       ELSE TRK_CODE     END AS TRK_CODE,     PARTNER_ID,     EVENT_DESC,     TRK_DATE   FROM DB1 ) SELECT   "DB2"."DELIVERY_NO",   "DB2"."TRK_CODE",   "DB2"."PARTNER_ID",   "DB2"."EVENT_DESC",   "DB2"."TRK_DATE" FROM DB2 WHERE   TRK_CODE IN (     \'GI\',     \'OCC_1\',     \'OCC_2\',     \'OCC_3\',     \'TOD10\',     \'TOD20\',     \'TOD30\',     \'TOD40\',     \'TOD50_1\',     \'TOD50_2\',     \'TOD50_3\',     \'TR4010-10\'   )'

CREATE VIEW "OW_SEDA_S_LOGISTIC"."VW_MACHINE_LEARNING_ALL_TRK" (
  "DELIVERY_NO",
  "TRK_CODE",
  "PARTNER_ID",
  "EVENT_DESC",
  "TRK_DATE"
) AS
WITH "DB2" AS (
  WITH "DB1" AS (
    (
      (
        (
          (
            SELECT
              "DELIVERY_NO",
              "TRK_CODE",
              "PARTNER_ID",
              "EVENT_DESC",
              "TRK_DATE"
            FROM OW_SEDA_S_LOGISTIC.ST_MACHINE_LEARNING_CELLO_TRK
            WHERE
              NOT TRK_CODE LIKE '%TOD50%'
          )
          UNION ALL
          (
            SELECT
              "DELIVERY_NO",
              "TRK_CODE",
              "PARTNER_ID",
              "EVENT_DESC",
              "TRK_DATE"
            FROM OW_SEDA_S_LOGISTIC.ST_MACHINE_LEARNING_CELLO_TRK_TOD50
          )
        )
        UNION ALL
        (
          SELECT
            "DELIVERY_NO",
            "TRK_CODE",
            "PARTNER_ID",
            "EVENT_DESC",
            "TRK_DATE"
          FROM OW_SEDA_S_LOGISTIC.ST_MACHINE_LEARNING_CELLO_FP
        )
      )
      UNION ALL
      (
        SELECT
          "DELIVERY_NO",
          "TRK_CODE",
          "PARTNER_ID",
          "EVENT_DESC",
          "TRK_DATE"
        FROM OW_SEDA_S_LOGISTIC.ST_MACHINE_LEARNING_CELLO_GI
      )
    )
  )
  SELECT
    DELIVERY_NO,
    CASE
      WHEN TRK_CODE = 'TOD50_3'
      AND LAG(TRK_CODE) OVER (PARTITION BY DELIVERY_NO ORDER BY TRK_DATE ASC) = 'TOD50_1'
      THEN 'TOD50_2'
      WHEN TRK_CODE LIKE 'OC%'
      AND LAG(TRK_CODE) OVER (PARTITION BY DELIVERY_NO ORDER BY TRK_DATE ASC) = 'TOD50_1'
      THEN 'OCC_1'
      WHEN TRK_CODE LIKE 'OC%'
      AND LAG(TRK_CODE) OVER (PARTITION BY DELIVERY_NO ORDER BY TRK_DATE ASC) = 'TOD50_2'
      THEN 'OCC_2'
      WHEN TRK_CODE LIKE 'OC%'
      AND LAG(TRK_CODE) OVER (PARTITION BY DELIVERY_NO ORDER BY TRK_DATE ASC) = 'TOD50_3'
      THEN 'OCC_3'
      ELSE TRK_CODE
    END AS TRK_CODE,
    PARTNER_ID,
    EVENT_DESC,
    TRK_DATE
  FROM DB1
)
SELECT
  "DB2"."DELIVERY_NO",
  "DB2"."TRK_CODE",
  "DB2"."PARTNER_ID",
  "DB2"."EVENT_DESC",
  "DB2"."TRK_DATE"
FROM DB2
WHERE
  TRK_CODE IN (
    'GI',
    'OCC_1',
    'OCC_2',
    'OCC_3',
    'TOD10',
    'TOD20',
    'TOD30',
    'TOD40',
    'TOD50_1',
    'TOD50_2',
    'TOD50_3',
    'TR4010-10'
  )