-- MISSING RELATION: OW_SEDA_S_LOGISTIC.FT_CT_CELLO
-- ERROR: Error executing query: Severity: ERROR, Message: Relation "OW_SEDA_S_LOGISTIC.FT_CT_CELLO" does not exist, Sqlstate: 42V01, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Miner/server/vertica/Catalog/CatalogLookup.cpp, Line: 4362, Error Code: 4568, SQL: 'CREATE OR REPLACE VIEW "OW_SEDA_S_LOGISTIC"."VW_MARKETPLACE_COMPARISON_IOD" (   "ANALYSIS",   "CHANNEL",   "ORIGINAL_ORDER_ID",   "ORDER_ID",   "SEQUENCE",   "STATUS_MARKETPLACE",   "STATUS_VTEX",   "STATUS_CELLO",   "CREATION_DATE",   "IOD_DATE" ) AS SELECT   "ANALYSIS",   "CHANNEL",   "ORIGINAL_ORDER_ID",   "ORDER_ID",   "SEQUENCE",   "STATUS_MARKETPLACE",   "STATUS_VTEX",   "STATUS_CELLO",   "CREATION_DATE",   "IOD_DATE" FROM (   SELECT     \'cello = IOD, marketplace != delivered\' AS analysis,     p.CHANNEL,     \'|\' || CAST(p.ORIGINAL_ORDER_ID AS VARCHAR) AS ORIGINAL_ORDER_ID,     v.ORDER_ID,     v."SEQUENCE",     p.STATUS AS STATUS_MARKETPLACE,     NULL AS STATUS_VTEX,     c.ORDER_STATUS AS STATUS_CELLO,     v.CREATION_DATE,     c.IOD_DATE   FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p   LEFT JOIN U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER AS v     ON SUBSTRING((p.ORIGINAL_ORDER_ID)::VARCHAR, 1, 99) = v.MARKETPLACE_ORDER_ID   LEFT JOIN OW_SEDA_S_LOGISTIC.FT_CT_CELLO AS c     ON (       CASE         WHEN v.ORDER_ID = c.CUSTOMER_PO         THEN 1         WHEN v."SEQUENCE" = c.CUSTOMER_PO         THEN 1         ELSE 0       END     ) = 1   WHERE     CHANNEL = \'Cnova\'     AND (       CASE         WHEN c.ORDER_STATUS = \'IOD\' AND p.STATUS <> \'delivered\'         THEN 1         WHEN c.ORDER_STATUS <> \'IOD\' AND p.STATUS = \'delivered\'         THEN 1         ELSE 0       END     ) = 1   UNION   SELECT     \'cello = IOD, marketplace != delivered\' AS analysis,     p.CHANNEL,     \'|\' || p.ORIGINAL_ORDER_ID,     v.ORDER_ID,     v."SEQUENCE",     p.STATUS AS STATUS_MARKETPLACE,     NULL AS STATUS_VTEX,     c.ORDER_STATUS AS STATUS_CELLO,     v.CREATION_DATE,     c.IOD_DATE   FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p   LEFT JOIN U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER AS v     ON p.ORIGINAL_ORDER_ID = v.MARKETPLACE_ORDER_ID   LEFT JOIN OW_SEDA_S_LOGISTIC.FT_CT_CELLO AS c     ON (       CASE         WHEN v.ORDER_ID = c.CUSTOMER_PO         THEN 1         WHEN v."SEQUENCE" = c.CUSTOMER_PO         THEN 1         ELSE 0       END     ) = 1   WHERE     CHANNEL = \'b2w\'     AND (       CASE         WHEN c.ORDER_STATUS = \'IOD\' AND p.STATUS <> \'delivered\'         THEN 1         WHEN c.ORDER_STATUS <> \'IOD\' AND p.STATUS = \'delivered\'         THEN 1         ELSE 0       END     ) = 1   UNION   SELECT     \'cello = IOD, marketplace != delivered\' AS analysis,     p.CHANNEL,     \'|\' || p.ORIGINAL_ORDER_ID,     v.ORDER_ID,     v."SEQUENCE",     p.STATUS AS STATUS_MARKETPLACE,     NULL AS STATUS_VTEX,     c.ORDER_STATUS AS STATUS_CELLO,     v.CREATION_DATE,     c.IOD_DATE   FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p   LEFT JOIN U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER AS v     ON p.ORIGINAL_ORDER_ID = v.MARKETPLACE_ORDER_ID   LEFT JOIN (     SELECT DISTINCT       CUSTOMER_PO,       ORDER_STATUS,       IOD_DATE     FROM OW_SEDA_S_LOGISTIC.FT_CT_CELLO   ) AS c     ON (       CASE         WHEN v.ORDER_ID = c.CUSTOMER_PO         THEN 1         WHEN v."SEQUENCE" = c.CUSTOMER_PO         THEN 1         ELSE 0       END     ) = 1   WHERE     CHANNEL = \'Carrefour\'     AND (       CASE         WHEN c.ORDER_STATUS = \'IOD\' AND p.STATUS <> \'delivered\'         THEN 1         WHEN c.ORDER_STATUS <> \'IOD\' AND p.STATUS = \'delivered\'         THEN 1         ELSE 0       END     ) = 1   UNION   SELECT     \'cello = IOD, marketplace != delivered\' AS analysis,     p.CHANNEL,     \'|\' || p.ORIGINAL_ORDER_ID,     v.ORDER_ID,     v."SEQUENCE",     p.STATUS AS STATUS_MARKETPLACE,     NULL AS STATUS_VTEX,     c.ORDER_STATUS AS STATUS_CELLO,     v.CREATION_DATE,     c.IOD_DATE   FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p   LEFT JOIN U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER AS v     ON p.ORIGINAL_ORDER_ID = v.MARKETPLACE_ORDER_ID   LEFT JOIN (     SELECT DISTINCT       CUSTOMER_PO,       ORDER_STATUS,       IOD_DATE     FROM OW_SEDA_S_LOGISTIC.FT_CT_CELLO   ) AS c     ON (       CASE         WHEN v.ORDER_ID = c.CUSTOMER_PO         THEN 1         WHEN v."SEQUENCE" = c.CUSTOMER_PO         THEN 1         ELSE 0       END     ) = 1   WHERE     CHANNEL = \'LeroyMerlin\'     AND (       CASE         WHEN c.ORDER_STATUS = \'IOD\' AND p.STATUS <> \'delivered\'         THEN 1         WHEN c.ORDER_STATUS <> \'IOD\' AND p.STATUS = \'delivered\'         THEN 1         ELSE 0       END     ) = 1   UNION   SELECT     \'cello = IOD, marketplace != delivered\' AS analysis,     p.CHANNEL,     \'|\' || p.ORIGINAL_ORDER_ID,     v.ORDER_ID,     v."SEQUENCE",     p.STATUS AS STATUS_MARKETPLACE,     NULL AS STATUS_VTEX,     c.ORDER_STATUS AS STATUS_CELLO,     v.CREATION_DATE,     c.IOD_DATE   FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p   LEFT JOIN U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER AS v     ON SUBSTRING((p.ORIGINAL_ORDER_ID)::VARCHAR, 1, LENGTH(p.ORIGINAL_ORDER_ID) - 4) = v.MARKETPLACE_ORDER_ID   LEFT JOIN (     SELECT DISTINCT       CUSTOMER_PO,       ORDER_STATUS,       IOD_DATE     FROM OW_SEDA_S_LOGISTIC.FT_CT_CELLO   ) AS c     ON (       CASE         WHEN v.ORDER_ID = c.CUSTOMER_PO         THEN 1         WHEN v."SEQUENCE" = c.CUSTOMER_PO         THEN 1         ELSE 0       END     ) = 1   WHERE     CHANNEL = \'MagazineLuiza\'     AND (       CASE         WHEN c.ORDER_STATUS = \'IOD\' AND p.STATUS <> \'delivered\'         THEN 1         WHEN c.ORDER_STATUS <> \'IOD\' AND p.STATUS = \'delivered\'         THEN 1         ELSE 0       END     ) = 1   UNION   SELECT     \'cello = IOD, marketplace != delivered\' AS analysis,     p.CHANNEL,     \'|\' || p.ORIGINAL_ORDER_ID,     v.ORDER_ID,     v."SEQUENCE",     p.STATUS AS STATUS_MARKETPLACE,     NULL AS STATUS_VTEX,     c.ORDER_STATUS AS STATUS_CELLO,     v.CREATION_DATE,     c.IOD_DATE   FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p   LEFT JOIN (     SELECT       CAST(SUBSTRING((b.FIRST_MESSAGE)::VARCHAR, 1, 16) AS VARCHAR) AS ORDER_MELI,       FIRST_MESSAGE,       v.*     FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER AS v     LEFT JOIN U_PRJ_ECOM.ODS_VTEX_BRIDGE AS b       ON v.MARKETPLACE_ORDER_ID = b.ID     WHERE       AFFILIATE_ID IN (\'MMC\', \'MMP\')   ) AS v     ON p.ORIGINAL_ORDER_ID = v.ORDER_MELI   LEFT JOIN (     SELECT DISTINCT       CUSTOMER_PO,       ORDER_STATUS,       IOD_DATE     FROM OW_SEDA_S_LOGISTIC.FT_CT_CELLO   ) AS c     ON (       CASE         WHEN v.ORDER_ID = c.CUSTOMER_PO         THEN 1         WHEN v."SEQUENCE" = c.CUSTOMER_PO         THEN 1         ELSE 0       END     ) = 1   WHERE     CHANNEL = \'MercadoLivre\'     AND (       CASE         WHEN c.ORDER_STATUS = \'IOD\' AND p.STATUS <> \'delivered\'         THEN 1         WHEN c.ORDER_STATUS <> \'IOD\' AND p.STATUS = \'delivered\'         THEN 1         ELSE 0       END     ) = 1   UNION   SELECT     \'marketplace = delivered, cello != IOD\' AS analysis,     p.CHANNEL,     \'|\' || p.ORIGINAL_ORDER_ID,     v.ORDER_ID,     v."SEQUENCE",     p.STATUS AS STATUS_MARKETPLACE,     NULL AS STATUS_VTEX,     c.ORDER_STATUS AS STATUS_CELLO,     v.CREATION_DATE,     c.IOD_DATE   FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p   LEFT JOIN U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER AS v     ON SUBSTRING((p.ORIGINAL_ORDER_ID)::VARCHAR, 1, 99) = v.MARKETPLACE_ORDER_ID   LEFT JOIN OW_SEDA_S_LOGISTIC.FT_CT_CELLO AS c     ON (       CASE         WHEN v.ORDER_ID = c.CUSTOMER_PO         THEN 1         WHEN v."SEQUENCE" = c.CUSTOMER_PO         THEN 1         ELSE 0       END     ) = 1   WHERE     CHANNEL = \'Cnova\'     AND (       CASE         WHEN c.ORDER_STATUS = \'IOD\' AND p.STATUS <> \'delivered\'         THEN 1         WHEN c.ORDER_STATUS <> \'IOD\' AND p.STATUS = \'delivered\'         THEN 1         ELSE 0       END     ) = 1   UNION   SELECT     \'marketplace = delivered, cello != IOD\' AS analysis,     p.CHANNEL,     \'|\' || p.ORIGINAL_ORDER_ID,     v.ORDER_ID,     v."SEQUENCE",     p.STATUS AS STATUS_MARKETPLACE,     NULL AS STATUS_VTEX,     c.ORDER_STATUS AS STATUS_CELLO,     v.CREATION_DATE,     c.IOD_DATE   FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p   LEFT JOIN U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER AS v     ON p.ORIGINAL_ORDER_ID = v.MARKETPLACE_ORDER_ID   LEFT JOIN OW_SEDA_S_LOGISTIC.FT_CT_CELLO AS c     ON (       CASE         WHEN v.ORDER_ID = c.CUSTOMER_PO         THEN 1         WHEN v."SEQUENCE" = c.CUSTOMER_PO         THEN 1         ELSE 0       END     ) = 1   WHERE     CHANNEL = \'b2w\'     AND (       CASE         WHEN c.ORDER_STATUS = \'IOD\' AND p.STATUS <> \'delivered\'         THEN 1         WHEN c.ORDER_STATUS <> \'IOD\' AND p.STATUS = \'delivered\'         THEN 1         ELSE 0       END     ) = 1   UNION   SELECT     \'marketplace = delivered, cello != IOD\' AS analysis,     p.CHANNEL,     \'|\' || p.ORIGINAL_ORDER_ID,     v.ORDER_ID,     v."SEQUENCE",     p.STATUS AS STATUS_MARKETPLACE,     NULL AS STATUS_VTEX,     c.ORDER_STATUS AS STATUS_CELLO,     v.CREATION_DATE,     c.IOD_DATE   FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p   LEFT JOIN U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER AS v     ON p.ORIGINAL_ORDER_ID = v.MARKETPLACE_ORDER_ID   LEFT JOIN (     SELECT DISTINCT       CUSTOMER_PO,       ORDER_STATUS,       IOD_DATE     FROM OW_SEDA_S_LOGISTIC.FT_CT_CELLO   ) AS c     ON (       CASE         WHEN v.ORDER_ID = c.CUSTOMER_PO         THEN 1         WHEN v."SEQUENCE" = c.CUSTOMER_PO         THEN 1         ELSE 0       END     ) = 1   WHERE     CHANNEL = \'Carrefour\'     AND (       CASE         WHEN c.ORDER_STATUS = \'IOD\' AND p.STATUS <> \'delivered\'         THEN 1         WHEN c.ORDER_STATUS <> \'IOD\' AND p.STATUS = \'delivered\'         THEN 1         ELSE 0       END     ) = 1   UNION   SELECT     \'marketplace = delivered, cello != IOD\' AS analysis,     p.CHANNEL,     \'|\' || p.ORIGINAL_ORDER_ID,     v.ORDER_ID,     v."SEQUENCE",     p.STATUS AS STATUS_MARKETPLACE,     NULL AS STATUS_VTEX,     c.ORDER_STATUS AS STATUS_CELLO,     v.CREATION_DATE,     c.IOD_DATE   FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p   LEFT JOIN U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER AS v     ON p.ORIGINAL_ORDER_ID = v.MARKETPLACE_ORDER_ID   LEFT JOIN (     SELECT DISTINCT       CUSTOMER_PO,       ORDER_STATUS,       IOD_DATE     FROM OW_SEDA_S_LOGISTIC.FT_CT_CELLO   ) AS c     ON (       CASE         WHEN v.ORDER_ID = c.CUSTOMER_PO         THEN 1         WHEN v."SEQUENCE" = c.CUSTOMER_PO         THEN 1         ELSE 0       END     ) = 1   WHERE     CHANNEL = \'LeroyMerlin\'     AND (       CASE         WHEN c.ORDER_STATUS = \'IOD\' AND p.STATUS <> \'delivered\'         THEN 1         WHEN c.ORDER_STATUS <> \'IOD\' AND p.STATUS = \'delivered\'         THEN 1         ELSE 0       END     ) = 1   UNION   SELECT     \'marketplace = delivered, cello != IOD\' AS analysis,     p.CHANNEL,     \'|\' || p.ORIGINAL_ORDER_ID,     v.ORDER_ID,     v."SEQUENCE",     p.STATUS AS STATUS_MARKETPLACE,     NULL AS STATUS_VTEX,     c.ORDER_STATUS AS STATUS_CELLO,     v.CREATION_DATE,     c.IOD_DATE   FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p   LEFT JOIN U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER AS v     ON SUBSTRING((p.ORIGINAL_ORDER_ID)::VARCHAR, 1, LENGTH(p.ORIGINAL_ORDER_ID) - 4) = v.MARKETPLACE_ORDER_ID   LEFT JOIN (     SELECT DISTINCT       CUSTOMER_PO,       ORDER_STATUS,       IOD_DATE     FROM OW_SEDA_S_LOGISTIC.FT_CT_CELLO   ) AS c     ON (       CASE         WHEN v.ORDER_ID = c.CUSTOMER_PO         THEN 1         WHEN v."SEQUENCE" = c.CUSTOMER_PO         THEN 1         ELSE 0       END     ) = 1   WHERE     CHANNEL = \'MagazineLuiza\'     AND (       CASE         WHEN c.ORDER_STATUS = \'IOD\' AND p.STATUS <> \'delivered\'         THEN 1         WHEN c.ORDER_STATUS <> \'IOD\' AND p.STATUS = \'delivered\'         THEN 1         ELSE 0       END     ) = 1   UNION   SELECT     \'marketplace = delivered, cello != IOD\' AS analysis,     p.CHANNEL,     \'|\' || p.ORIGINAL_ORDER_ID,     v.ORDER_ID,     v."SEQUENCE",     p.STATUS AS STATUS_MARKETPLACE,     NULL AS STATUS_VTEX,     c.ORDER_STATUS AS STATUS_CELLO,     v.CREATION_DATE,     c.IOD_DATE   FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p   LEFT JOIN (     SELECT       CAST(SUBSTRING((b.FIRST_MESSAGE)::VARCHAR, 1, 16) AS VARCHAR) AS ORDER_MELI,       FIRST_MESSAGE,       v.*     FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER AS v     LEFT JOIN U_PRJ_ECOM.ODS_VTEX_BRIDGE AS b       ON v.MARKETPLACE_ORDER_ID = b.ID     WHERE       AFFILIATE_ID IN (\'MMC\', \'MMP\')   ) AS v     ON p.ORIGINAL_ORDER_ID = v.ORDER_MELI   LEFT JOIN (     SELECT DISTINCT       CUSTOMER_PO,       ORDER_STATUS,       IOD_DATE     FROM OW_SEDA_S_LOGISTIC.FT_CT_CELLO   ) AS c     ON (       CASE         WHEN v.ORDER_ID = c.CUSTOMER_PO         THEN 1         WHEN v."SEQUENCE" = c.CUSTOMER_PO         THEN 1         ELSE 0       END     ) = 1   WHERE     CHANNEL = \'MercadoLivre\'     AND (       CASE         WHEN c.ORDER_STATUS = \'IOD\' AND p.STATUS <> \'delivered\'         THEN 1         WHEN c.ORDER_STATUS <> \'IOD\' AND p.STATUS = \'delivered\'         THEN 1         ELSE 0       END     ) = 1 ) AS subq_3856'

CREATE OR REPLACE VIEW "OW_SEDA_S_LOGISTIC"."VW_MARKETPLACE_COMPARISON_IOD" (
  "ANALYSIS",
  "CHANNEL",
  "ORIGINAL_ORDER_ID",
  "ORDER_ID",
  "SEQUENCE",
  "STATUS_MARKETPLACE",
  "STATUS_VTEX",
  "STATUS_CELLO",
  "CREATION_DATE",
  "IOD_DATE"
) AS
SELECT
  "ANALYSIS",
  "CHANNEL",
  "ORIGINAL_ORDER_ID",
  "ORDER_ID",
  "SEQUENCE",
  "STATUS_MARKETPLACE",
  "STATUS_VTEX",
  "STATUS_CELLO",
  "CREATION_DATE",
  "IOD_DATE"
FROM (
  SELECT
    'cello = IOD, marketplace != delivered' AS analysis,
    p.CHANNEL,
    '|' || CAST(p.ORIGINAL_ORDER_ID AS VARCHAR) AS ORIGINAL_ORDER_ID,
    v.ORDER_ID,
    v."SEQUENCE",
    p.STATUS AS STATUS_MARKETPLACE,
    NULL AS STATUS_VTEX,
    c.ORDER_STATUS AS STATUS_CELLO,
    v.CREATION_DATE,
    c.IOD_DATE
  FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p
  LEFT JOIN U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER AS v
    ON SUBSTRING((p.ORIGINAL_ORDER_ID)::VARCHAR, 1, 99) = v.MARKETPLACE_ORDER_ID
  LEFT JOIN OW_SEDA_S_LOGISTIC.FT_CT_CELLO AS c
    ON (
      CASE
        WHEN v.ORDER_ID = c.CUSTOMER_PO
        THEN 1
        WHEN v."SEQUENCE" = c.CUSTOMER_PO
        THEN 1
        ELSE 0
      END
    ) = 1
  WHERE
    CHANNEL = 'Cnova'
    AND (
      CASE
        WHEN c.ORDER_STATUS = 'IOD' AND p.STATUS <> 'delivered'
        THEN 1
        WHEN c.ORDER_STATUS <> 'IOD' AND p.STATUS = 'delivered'
        THEN 1
        ELSE 0
      END
    ) = 1
  UNION
  SELECT
    'cello = IOD, marketplace != delivered' AS analysis,
    p.CHANNEL,
    '|' || p.ORIGINAL_ORDER_ID,
    v.ORDER_ID,
    v."SEQUENCE",
    p.STATUS AS STATUS_MARKETPLACE,
    NULL AS STATUS_VTEX,
    c.ORDER_STATUS AS STATUS_CELLO,
    v.CREATION_DATE,
    c.IOD_DATE
  FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p
  LEFT JOIN U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER AS v
    ON p.ORIGINAL_ORDER_ID = v.MARKETPLACE_ORDER_ID
  LEFT JOIN OW_SEDA_S_LOGISTIC.FT_CT_CELLO AS c
    ON (
      CASE
        WHEN v.ORDER_ID = c.CUSTOMER_PO
        THEN 1
        WHEN v."SEQUENCE" = c.CUSTOMER_PO
        THEN 1
        ELSE 0
      END
    ) = 1
  WHERE
    CHANNEL = 'b2w'
    AND (
      CASE
        WHEN c.ORDER_STATUS = 'IOD' AND p.STATUS <> 'delivered'
        THEN 1
        WHEN c.ORDER_STATUS <> 'IOD' AND p.STATUS = 'delivered'
        THEN 1
        ELSE 0
      END
    ) = 1
  UNION
  SELECT
    'cello = IOD, marketplace != delivered' AS analysis,
    p.CHANNEL,
    '|' || p.ORIGINAL_ORDER_ID,
    v.ORDER_ID,
    v."SEQUENCE",
    p.STATUS AS STATUS_MARKETPLACE,
    NULL AS STATUS_VTEX,
    c.ORDER_STATUS AS STATUS_CELLO,
    v.CREATION_DATE,
    c.IOD_DATE
  FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p
  LEFT JOIN U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER AS v
    ON p.ORIGINAL_ORDER_ID = v.MARKETPLACE_ORDER_ID
  LEFT JOIN (
    SELECT DISTINCT
      CUSTOMER_PO,
      ORDER_STATUS,
      IOD_DATE
    FROM OW_SEDA_S_LOGISTIC.FT_CT_CELLO
  ) AS c
    ON (
      CASE
        WHEN v.ORDER_ID = c.CUSTOMER_PO
        THEN 1
        WHEN v."SEQUENCE" = c.CUSTOMER_PO
        THEN 1
        ELSE 0
      END
    ) = 1
  WHERE
    CHANNEL = 'Carrefour'
    AND (
      CASE
        WHEN c.ORDER_STATUS = 'IOD' AND p.STATUS <> 'delivered'
        THEN 1
        WHEN c.ORDER_STATUS <> 'IOD' AND p.STATUS = 'delivered'
        THEN 1
        ELSE 0
      END
    ) = 1
  UNION
  SELECT
    'cello = IOD, marketplace != delivered' AS analysis,
    p.CHANNEL,
    '|' || p.ORIGINAL_ORDER_ID,
    v.ORDER_ID,
    v."SEQUENCE",
    p.STATUS AS STATUS_MARKETPLACE,
    NULL AS STATUS_VTEX,
    c.ORDER_STATUS AS STATUS_CELLO,
    v.CREATION_DATE,
    c.IOD_DATE
  FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p
  LEFT JOIN U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER AS v
    ON p.ORIGINAL_ORDER_ID = v.MARKETPLACE_ORDER_ID
  LEFT JOIN (
    SELECT DISTINCT
      CUSTOMER_PO,
      ORDER_STATUS,
      IOD_DATE
    FROM OW_SEDA_S_LOGISTIC.FT_CT_CELLO
  ) AS c
    ON (
      CASE
        WHEN v.ORDER_ID = c.CUSTOMER_PO
        THEN 1
        WHEN v."SEQUENCE" = c.CUSTOMER_PO
        THEN 1
        ELSE 0
      END
    ) = 1
  WHERE
    CHANNEL = 'LeroyMerlin'
    AND (
      CASE
        WHEN c.ORDER_STATUS = 'IOD' AND p.STATUS <> 'delivered'
        THEN 1
        WHEN c.ORDER_STATUS <> 'IOD' AND p.STATUS = 'delivered'
        THEN 1
        ELSE 0
      END
    ) = 1
  UNION
  SELECT
    'cello = IOD, marketplace != delivered' AS analysis,
    p.CHANNEL,
    '|' || p.ORIGINAL_ORDER_ID,
    v.ORDER_ID,
    v."SEQUENCE",
    p.STATUS AS STATUS_MARKETPLACE,
    NULL AS STATUS_VTEX,
    c.ORDER_STATUS AS STATUS_CELLO,
    v.CREATION_DATE,
    c.IOD_DATE
  FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p
  LEFT JOIN U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER AS v
    ON SUBSTRING((p.ORIGINAL_ORDER_ID)::VARCHAR, 1, LENGTH(p.ORIGINAL_ORDER_ID) - 4) = v.MARKETPLACE_ORDER_ID
  LEFT JOIN (
    SELECT DISTINCT
      CUSTOMER_PO,
      ORDER_STATUS,
      IOD_DATE
    FROM OW_SEDA_S_LOGISTIC.FT_CT_CELLO
  ) AS c
    ON (
      CASE
        WHEN v.ORDER_ID = c.CUSTOMER_PO
        THEN 1
        WHEN v."SEQUENCE" = c.CUSTOMER_PO
        THEN 1
        ELSE 0
      END
    ) = 1
  WHERE
    CHANNEL = 'MagazineLuiza'
    AND (
      CASE
        WHEN c.ORDER_STATUS = 'IOD' AND p.STATUS <> 'delivered'
        THEN 1
        WHEN c.ORDER_STATUS <> 'IOD' AND p.STATUS = 'delivered'
        THEN 1
        ELSE 0
      END
    ) = 1
  UNION
  SELECT
    'cello = IOD, marketplace != delivered' AS analysis,
    p.CHANNEL,
    '|' || p.ORIGINAL_ORDER_ID,
    v.ORDER_ID,
    v."SEQUENCE",
    p.STATUS AS STATUS_MARKETPLACE,
    NULL AS STATUS_VTEX,
    c.ORDER_STATUS AS STATUS_CELLO,
    v.CREATION_DATE,
    c.IOD_DATE
  FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p
  LEFT JOIN (
    SELECT
      CAST(SUBSTRING((b.FIRST_MESSAGE)::VARCHAR, 1, 16) AS VARCHAR) AS ORDER_MELI,
      FIRST_MESSAGE,
      v.*
    FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER AS v
    LEFT JOIN U_PRJ_ECOM.ODS_VTEX_BRIDGE AS b
      ON v.MARKETPLACE_ORDER_ID = b.ID
    WHERE
      AFFILIATE_ID IN ('MMC', 'MMP')
  ) AS v
    ON p.ORIGINAL_ORDER_ID = v.ORDER_MELI
  LEFT JOIN (
    SELECT DISTINCT
      CUSTOMER_PO,
      ORDER_STATUS,
      IOD_DATE
    FROM OW_SEDA_S_LOGISTIC.FT_CT_CELLO
  ) AS c
    ON (
      CASE
        WHEN v.ORDER_ID = c.CUSTOMER_PO
        THEN 1
        WHEN v."SEQUENCE" = c.CUSTOMER_PO
        THEN 1
        ELSE 0
      END
    ) = 1
  WHERE
    CHANNEL = 'MercadoLivre'
    AND (
      CASE
        WHEN c.ORDER_STATUS = 'IOD' AND p.STATUS <> 'delivered'
        THEN 1
        WHEN c.ORDER_STATUS <> 'IOD' AND p.STATUS = 'delivered'
        THEN 1
        ELSE 0
      END
    ) = 1
  UNION
  SELECT
    'marketplace = delivered, cello != IOD' AS analysis,
    p.CHANNEL,
    '|' || p.ORIGINAL_ORDER_ID,
    v.ORDER_ID,
    v."SEQUENCE",
    p.STATUS AS STATUS_MARKETPLACE,
    NULL AS STATUS_VTEX,
    c.ORDER_STATUS AS STATUS_CELLO,
    v.CREATION_DATE,
    c.IOD_DATE
  FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p
  LEFT JOIN U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER AS v
    ON SUBSTRING((p.ORIGINAL_ORDER_ID)::VARCHAR, 1, 99) = v.MARKETPLACE_ORDER_ID
  LEFT JOIN OW_SEDA_S_LOGISTIC.FT_CT_CELLO AS c
    ON (
      CASE
        WHEN v.ORDER_ID = c.CUSTOMER_PO
        THEN 1
        WHEN v."SEQUENCE" = c.CUSTOMER_PO
        THEN 1
        ELSE 0
      END
    ) = 1
  WHERE
    CHANNEL = 'Cnova'
    AND (
      CASE
        WHEN c.ORDER_STATUS = 'IOD' AND p.STATUS <> 'delivered'
        THEN 1
        WHEN c.ORDER_STATUS <> 'IOD' AND p.STATUS = 'delivered'
        THEN 1
        ELSE 0
      END
    ) = 1
  UNION
  SELECT
    'marketplace = delivered, cello != IOD' AS analysis,
    p.CHANNEL,
    '|' || p.ORIGINAL_ORDER_ID,
    v.ORDER_ID,
    v."SEQUENCE",
    p.STATUS AS STATUS_MARKETPLACE,
    NULL AS STATUS_VTEX,
    c.ORDER_STATUS AS STATUS_CELLO,
    v.CREATION_DATE,
    c.IOD_DATE
  FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p
  LEFT JOIN U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER AS v
    ON p.ORIGINAL_ORDER_ID = v.MARKETPLACE_ORDER_ID
  LEFT JOIN OW_SEDA_S_LOGISTIC.FT_CT_CELLO AS c
    ON (
      CASE
        WHEN v.ORDER_ID = c.CUSTOMER_PO
        THEN 1
        WHEN v."SEQUENCE" = c.CUSTOMER_PO
        THEN 1
        ELSE 0
      END
    ) = 1
  WHERE
    CHANNEL = 'b2w'
    AND (
      CASE
        WHEN c.ORDER_STATUS = 'IOD' AND p.STATUS <> 'delivered'
        THEN 1
        WHEN c.ORDER_STATUS <> 'IOD' AND p.STATUS = 'delivered'
        THEN 1
        ELSE 0
      END
    ) = 1
  UNION
  SELECT
    'marketplace = delivered, cello != IOD' AS analysis,
    p.CHANNEL,
    '|' || p.ORIGINAL_ORDER_ID,
    v.ORDER_ID,
    v."SEQUENCE",
    p.STATUS AS STATUS_MARKETPLACE,
    NULL AS STATUS_VTEX,
    c.ORDER_STATUS AS STATUS_CELLO,
    v.CREATION_DATE,
    c.IOD_DATE
  FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p
  LEFT JOIN U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER AS v
    ON p.ORIGINAL_ORDER_ID = v.MARKETPLACE_ORDER_ID
  LEFT JOIN (
    SELECT DISTINCT
      CUSTOMER_PO,
      ORDER_STATUS,
      IOD_DATE
    FROM OW_SEDA_S_LOGISTIC.FT_CT_CELLO
  ) AS c
    ON (
      CASE
        WHEN v.ORDER_ID = c.CUSTOMER_PO
        THEN 1
        WHEN v."SEQUENCE" = c.CUSTOMER_PO
        THEN 1
        ELSE 0
      END
    ) = 1
  WHERE
    CHANNEL = 'Carrefour'
    AND (
      CASE
        WHEN c.ORDER_STATUS = 'IOD' AND p.STATUS <> 'delivered'
        THEN 1
        WHEN c.ORDER_STATUS <> 'IOD' AND p.STATUS = 'delivered'
        THEN 1
        ELSE 0
      END
    ) = 1
  UNION
  SELECT
    'marketplace = delivered, cello != IOD' AS analysis,
    p.CHANNEL,
    '|' || p.ORIGINAL_ORDER_ID,
    v.ORDER_ID,
    v."SEQUENCE",
    p.STATUS AS STATUS_MARKETPLACE,
    NULL AS STATUS_VTEX,
    c.ORDER_STATUS AS STATUS_CELLO,
    v.CREATION_DATE,
    c.IOD_DATE
  FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p
  LEFT JOIN U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER AS v
    ON p.ORIGINAL_ORDER_ID = v.MARKETPLACE_ORDER_ID
  LEFT JOIN (
    SELECT DISTINCT
      CUSTOMER_PO,
      ORDER_STATUS,
      IOD_DATE
    FROM OW_SEDA_S_LOGISTIC.FT_CT_CELLO
  ) AS c
    ON (
      CASE
        WHEN v.ORDER_ID = c.CUSTOMER_PO
        THEN 1
        WHEN v."SEQUENCE" = c.CUSTOMER_PO
        THEN 1
        ELSE 0
      END
    ) = 1
  WHERE
    CHANNEL = 'LeroyMerlin'
    AND (
      CASE
        WHEN c.ORDER_STATUS = 'IOD' AND p.STATUS <> 'delivered'
        THEN 1
        WHEN c.ORDER_STATUS <> 'IOD' AND p.STATUS = 'delivered'
        THEN 1
        ELSE 0
      END
    ) = 1
  UNION
  SELECT
    'marketplace = delivered, cello != IOD' AS analysis,
    p.CHANNEL,
    '|' || p.ORIGINAL_ORDER_ID,
    v.ORDER_ID,
    v."SEQUENCE",
    p.STATUS AS STATUS_MARKETPLACE,
    NULL AS STATUS_VTEX,
    c.ORDER_STATUS AS STATUS_CELLO,
    v.CREATION_DATE,
    c.IOD_DATE
  FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p
  LEFT JOIN U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER AS v
    ON SUBSTRING((p.ORIGINAL_ORDER_ID)::VARCHAR, 1, LENGTH(p.ORIGINAL_ORDER_ID) - 4) = v.MARKETPLACE_ORDER_ID
  LEFT JOIN (
    SELECT DISTINCT
      CUSTOMER_PO,
      ORDER_STATUS,
      IOD_DATE
    FROM OW_SEDA_S_LOGISTIC.FT_CT_CELLO
  ) AS c
    ON (
      CASE
        WHEN v.ORDER_ID = c.CUSTOMER_PO
        THEN 1
        WHEN v."SEQUENCE" = c.CUSTOMER_PO
        THEN 1
        ELSE 0
      END
    ) = 1
  WHERE
    CHANNEL = 'MagazineLuiza'
    AND (
      CASE
        WHEN c.ORDER_STATUS = 'IOD' AND p.STATUS <> 'delivered'
        THEN 1
        WHEN c.ORDER_STATUS <> 'IOD' AND p.STATUS = 'delivered'
        THEN 1
        ELSE 0
      END
    ) = 1
  UNION
  SELECT
    'marketplace = delivered, cello != IOD' AS analysis,
    p.CHANNEL,
    '|' || p.ORIGINAL_ORDER_ID,
    v.ORDER_ID,
    v."SEQUENCE",
    p.STATUS AS STATUS_MARKETPLACE,
    NULL AS STATUS_VTEX,
    c.ORDER_STATUS AS STATUS_CELLO,
    v.CREATION_DATE,
    c.IOD_DATE
  FROM OW_SEDA_S.ODS_PLUGG_MARKETPLACE_ORDER AS p
  LEFT JOIN (
    SELECT
      CAST(SUBSTRING((b.FIRST_MESSAGE)::VARCHAR, 1, 16) AS VARCHAR) AS ORDER_MELI,
      FIRST_MESSAGE,
      v.*
    FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER AS v
    LEFT JOIN U_PRJ_ECOM.ODS_VTEX_BRIDGE AS b
      ON v.MARKETPLACE_ORDER_ID = b.ID
    WHERE
      AFFILIATE_ID IN ('MMC', 'MMP')
  ) AS v
    ON p.ORIGINAL_ORDER_ID = v.ORDER_MELI
  LEFT JOIN (
    SELECT DISTINCT
      CUSTOMER_PO,
      ORDER_STATUS,
      IOD_DATE
    FROM OW_SEDA_S_LOGISTIC.FT_CT_CELLO
  ) AS c
    ON (
      CASE
        WHEN v.ORDER_ID = c.CUSTOMER_PO
        THEN 1
        WHEN v."SEQUENCE" = c.CUSTOMER_PO
        THEN 1
        ELSE 0
      END
    ) = 1
  WHERE
    CHANNEL = 'MercadoLivre'
    AND (
      CASE
        WHEN c.ORDER_STATUS = 'IOD' AND p.STATUS <> 'delivered'
        THEN 1
        WHEN c.ORDER_STATUS <> 'IOD' AND p.STATUS = 'delivered'
        THEN 1
        ELSE 0
      END
    ) = 1
) AS subq_3856