-- MISSING RELATION: OW_SEDA_S_LOGISTIC.ST_D2C_MASTER
-- ERROR: Error executing query: Severity: ERROR, Message: Relation "OW_SEDA_S_LOGISTIC.ST_D2C_MASTER" does not exist, Sqlstate: 42V01, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Miner/server/vertica/Catalog/CatalogLookup.cpp, Line: 4362, Error Code: 4568, SQL: 'CREATE OR REPLACE VIEW "OW_SEDA_S_LOGISTIC"."VW_TRK_TEAM_OCC_OTD" (   "No.",   "DO No.",   "Occurrence Code",   "Occurrence Name",   "Occurrence Date",   "Next Step",   "Next Step Action",   "Responsible",   "Validated By",   "Validated On",   "Process Date",   "Occurrence Create Date",   "REMARKS" ) AS WITH "DB1" AS (   (     (       SELECT         "DELIVERY_NO",         "DELIVERY_CREATION_DATE",         "PO_NUMBER",         "SPI",         "FIRST_BOOKING",         "LAST_BOOKING",         "NEW_ETA",         "FINAL_BOOKING",         "FINAL_IOD",         "SHIPPING_TYPE",         "GI_DATE_TIME",         "IOD_DATE_TIME",         "IOD_REGISTRATION_DT",         "IOD_LOCKER_DATE_TIME",         "IOD_LOCKER_REGISTRATION_DT",         "LT_REALIZADO",         "LAST_TRK_CODE",         "LAST_HUB",         "SOLDTO_NM",         "FIRST_OCC",         "LAST_EVENT",         "LAST_EVENT_DATE",         "FIRST_OCC_DATE",         "RESPONSIBLE_NM",         "ORDER_TYPE",         "CATEGORY",         "SHIPMENT_NO",         "ORIGIN",         "SHIPPING_CONDITION_NM",         "SHIPTO_ZIPCODE",         "ZIP_RANGE",         "REGION",         "UF",         "AREA",         "LT_CELLO",         "LT_NERP",         "SO_NUMBER",         "MTL_GROUP",         "PROVINCE",         "ENTREGA_ESPECIAL",         "SPV",         "CARRIER_NAME",         "DIVISION",         "LAST_TRACKING_STATUS_NM",         "LAST_SUB_ORDER_STATUS_NM",         "NEXT_ACTION_NM",         "NEXT_STEP_NM",         "LAST_OCC_DATE",         "LAST_OCC",         "TRACKING_STATUS",         "RETURN_CLIENT",         "RETURN_SEDA",         "CARRIER_VTEX",         "TRANSIT_TIME_VTEX",         "RDD_VTEX",         "TRACKING_STATUS_CLASSIF",         "RESPONSIBLE_2",         "LOAD_DATE"       FROM OW_SEDA_S_LOGISTIC.ST_D2C_MASTER     )     UNION ALL     (       SELECT         "DELIVERY_NO",         "DELIVERY_CREATION_DATE",         "PO_NUMBER",         "SPI",         "FIRST_BOOKING",         "LAST_BOOKING",         "NEW_ETA",         "FINAL_BOOKING",         "FINAL_IOD",         "SHIPPING_TYPE",         "GI_DATE_TIME",         "IOD_DATE_TIME",         "IOD_REGISTRATION_DT",         "IOD_LOCKER_DATE_TIME",         "IOD_LOCKER_REGISTRATION_DT",         "LT_REALIZADO",         "LAST_TRK_CODE",         "LAST_HUB",         "SOLDTO_NM",         "FIRST_OCC",         "LAST_EVENT",         "LAST_EVENT_DATE",         "FIRST_OCC_DATE",         "RESPONSIBLE_NM",         "ORDER_TYPE",         "CATEGORY",         "SHIPMENT_NO",         "ORIGIN",         "SHIPPING_CONDITION_NM",         "SHIPTO_ZIPCODE",         "ZIP_RANGE",         "REGION",         "UF",         "AREA",         "LT_CELLO",         "LT_NERP",         "SO_NUMBER",         "MTL_GROUP",         "PROVINCE",         "ENTREGA_ESPECIAL",         "SPV",         "CARRIER_NAME",         "DIVISION",         "LAST_TRACKING_STATUS_NM",         "LAST_SUB_ORDER_STATUS_NM",         "NEXT_ACTION_NM",         "NEXT_STEP_NM",         "LAST_OCC_DATE",         "LAST_OCC",         "TRACKING_STATUS",         "RETURN_CLIENT",         "RETURN_SEDA",         "CARRIER_VTEX",         "TRANSIT_TIME_VTEX",         "RDD_VTEX",         "TRACKING_STATUS_CLASSIF",         "RESPONSIBLE_2",         "LOAD_DATE"       FROM OW_SEDA_S_LOGISTIC.D2C_MASTER_JAN_2024_FEV_2025     )   ) ) SELECT   ROW_NUMBER() OVER (ORDER BY FP.DELIVERY_NO, FP.OCCURRENCE_CREATE_DATE) AS "No.",   FP.DELIVERY_NO AS "DO No.",   FP.TRK_CODE AS "Occurrence Code",   FP.TRK_NM AS "Occurrence Name",   (FP.TRK_DATE)::TIMESTAMP AS "Occurrence Date",   FP.NEXT_STEP_NM AS "Next Step",   FP.NEXT_ACTION_NM AS "Next Step Action",   FP.RESPONSIBLE_NM AS "Responsible",   FP.VALIDATION_NM AS "Validated By",   FP.VALIDATION_DATE AS "Validated On",   FP.PROCESS_DATE AS "Process Date",   (FP.OCCURRENCE_CREATE_DATE)::TIMESTAMP AS "Occurrence Create Date",   CT.REMARKS FROM DB1 AS MQ LEFT JOIN (   SELECT     DELIVERY_NO,     TRK_CODE,     (TRK_DATE)::TIMESTAMP AS TRK_DATE,     TRK_NM,     NEXT_STEP_NM,     RESPONSIBLE_NM,     NEXT_ACTION_NM,     VALIDATION_NM,     VALIDATION_DATE,     PROCESS_DATE,     OCCURRENCE_CREATE_DATE   FROM OW_SEDA_S.CELLO_FUTHER_PROCESSING   WHERE     TO_DATE((TRK_DATE)::VARCHAR, \'YYYY-MM-DD\') >= \'2024-01-01\' ) AS FP   ON MQ.DELIVERY_NO = FP.DELIVERY_NO LEFT JOIN (   SELECT     DELIVERY_NO,     TRK_CODE,     REMARKS   FROM OW_SEDA_S.CELLO_TRACKING AS CT   WHERE     TO_DATE((TRK_DATE)::VARCHAR, \'YYYY-MM-DD\') >= \'2024-01-01\'     AND NOT REMARKS IS NULL ) AS CT   ON MQ.DELIVERY_NO = CT.DELIVERY_NO AND FP.TRK_CODE = CT.TRK_CODE WHERE   NOT FP.DELIVERY_NO IS NULL ORDER BY   FP.DELIVERY_NO,   FP.OCCURRENCE_CREATE_DATE'

CREATE VIEW "OW_SEDA_S_LOGISTIC"."VW_TRK_TEAM_OCC_OTD" (
  "No.",
  "DO No.",
  "Occurrence Code",
  "Occurrence Name",
  "Occurrence Date",
  "Next Step",
  "Next Step Action",
  "Responsible",
  "Validated By",
  "Validated On",
  "Process Date",
  "Occurrence Create Date",
  "REMARKS"
) AS
WITH "DB1" AS (
  (
    (
      SELECT
        "DELIVERY_NO",
        "DELIVERY_CREATION_DATE",
        "PO_NUMBER",
        "SPI",
        "FIRST_BOOKING",
        "LAST_BOOKING",
        "NEW_ETA",
        "FINAL_BOOKING",
        "FINAL_IOD",
        "SHIPPING_TYPE",
        "GI_DATE_TIME",
        "IOD_DATE_TIME",
        "IOD_REGISTRATION_DT",
        "IOD_LOCKER_DATE_TIME",
        "IOD_LOCKER_REGISTRATION_DT",
        "LT_REALIZADO",
        "LAST_TRK_CODE",
        "LAST_HUB",
        "SOLDTO_NM",
        "FIRST_OCC",
        "LAST_EVENT",
        "LAST_EVENT_DATE",
        "FIRST_OCC_DATE",
        "RESPONSIBLE_NM",
        "ORDER_TYPE",
        "CATEGORY",
        "SHIPMENT_NO",
        "ORIGIN",
        "SHIPPING_CONDITION_NM",
        "SHIPTO_ZIPCODE",
        "ZIP_RANGE",
        "REGION",
        "UF",
        "AREA",
        "LT_CELLO",
        "LT_NERP",
        "SO_NUMBER",
        "MTL_GROUP",
        "PROVINCE",
        "ENTREGA_ESPECIAL",
        "SPV",
        "CARRIER_NAME",
        "DIVISION",
        "LAST_TRACKING_STATUS_NM",
        "LAST_SUB_ORDER_STATUS_NM",
        "NEXT_ACTION_NM",
        "NEXT_STEP_NM",
        "LAST_OCC_DATE",
        "LAST_OCC",
        "TRACKING_STATUS",
        "RETURN_CLIENT",
        "RETURN_SEDA",
        "CARRIER_VTEX",
        "TRANSIT_TIME_VTEX",
        "RDD_VTEX",
        "TRACKING_STATUS_CLASSIF",
        "RESPONSIBLE_2",
        "LOAD_DATE"
      FROM OW_SEDA_S_LOGISTIC.ST_D2C_MASTER
    )
    UNION ALL
    (
      SELECT
        "DELIVERY_NO",
        "DELIVERY_CREATION_DATE",
        "PO_NUMBER",
        "SPI",
        "FIRST_BOOKING",
        "LAST_BOOKING",
        "NEW_ETA",
        "FINAL_BOOKING",
        "FINAL_IOD",
        "SHIPPING_TYPE",
        "GI_DATE_TIME",
        "IOD_DATE_TIME",
        "IOD_REGISTRATION_DT",
        "IOD_LOCKER_DATE_TIME",
        "IOD_LOCKER_REGISTRATION_DT",
        "LT_REALIZADO",
        "LAST_TRK_CODE",
        "LAST_HUB",
        "SOLDTO_NM",
        "FIRST_OCC",
        "LAST_EVENT",
        "LAST_EVENT_DATE",
        "FIRST_OCC_DATE",
        "RESPONSIBLE_NM",
        "ORDER_TYPE",
        "CATEGORY",
        "SHIPMENT_NO",
        "ORIGIN",
        "SHIPPING_CONDITION_NM",
        "SHIPTO_ZIPCODE",
        "ZIP_RANGE",
        "REGION",
        "UF",
        "AREA",
        "LT_CELLO",
        "LT_NERP",
        "SO_NUMBER",
        "MTL_GROUP",
        "PROVINCE",
        "ENTREGA_ESPECIAL",
        "SPV",
        "CARRIER_NAME",
        "DIVISION",
        "LAST_TRACKING_STATUS_NM",
        "LAST_SUB_ORDER_STATUS_NM",
        "NEXT_ACTION_NM",
        "NEXT_STEP_NM",
        "LAST_OCC_DATE",
        "LAST_OCC",
        "TRACKING_STATUS",
        "RETURN_CLIENT",
        "RETURN_SEDA",
        "CARRIER_VTEX",
        "TRANSIT_TIME_VTEX",
        "RDD_VTEX",
        "TRACKING_STATUS_CLASSIF",
        "RESPONSIBLE_2",
        "LOAD_DATE"
      FROM OW_SEDA_S_LOGISTIC.D2C_MASTER_JAN_2024_FEV_2025
    )
  )
)
SELECT
  ROW_NUMBER() OVER (ORDER BY FP.DELIVERY_NO, FP.OCCURRENCE_CREATE_DATE) AS "No.",
  FP.DELIVERY_NO AS "DO No.",
  FP.TRK_CODE AS "Occurrence Code",
  FP.TRK_NM AS "Occurrence Name",
  (FP.TRK_DATE)::TIMESTAMP AS "Occurrence Date",
  FP.NEXT_STEP_NM AS "Next Step",
  FP.NEXT_ACTION_NM AS "Next Step Action",
  FP.RESPONSIBLE_NM AS "Responsible",
  FP.VALIDATION_NM AS "Validated By",
  FP.VALIDATION_DATE AS "Validated On",
  FP.PROCESS_DATE AS "Process Date",
  (FP.OCCURRENCE_CREATE_DATE)::TIMESTAMP AS "Occurrence Create Date",
  CT.REMARKS
FROM DB1 AS MQ
LEFT JOIN (
  SELECT
    DELIVERY_NO,
    TRK_CODE,
    (TRK_DATE)::TIMESTAMP AS TRK_DATE,
    TRK_NM,
    NEXT_STEP_NM,
    RESPONSIBLE_NM,
    NEXT_ACTION_NM,
    VALIDATION_NM,
    VALIDATION_DATE,
    PROCESS_DATE,
    OCCURRENCE_CREATE_DATE
  FROM OW_SEDA_S.CELLO_FUTHER_PROCESSING
  WHERE
    TO_DATE((TRK_DATE)::VARCHAR, 'YYYY-MM-DD') >= '2024-01-01'
) AS FP
  ON MQ.DELIVERY_NO = FP.DELIVERY_NO
LEFT JOIN (
  SELECT
    DELIVERY_NO,
    TRK_CODE,
    REMARKS
  FROM OW_SEDA_S.CELLO_TRACKING AS CT
  WHERE
    TO_DATE((TRK_DATE)::VARCHAR, 'YYYY-MM-DD') >= '2024-01-01'
    AND NOT REMARKS IS NULL
) AS CT
  ON MQ.DELIVERY_NO = CT.DELIVERY_NO AND FP.TRK_CODE = CT.TRK_CODE
WHERE
  NOT FP.DELIVERY_NO IS NULL
ORDER BY
  FP.DELIVERY_NO,
  FP.OCCURRENCE_CREATE_DATE