-- MISSING RELATION: OW_SEDA_S_LOGISTIC.FT_CT_AR_ENTRIES_REAL_TIME
-- ERROR: Error executing query: Severity: ERROR, Message: Relation "OW_SEDA_S_LOGISTIC.FT_CT_AR_ENTRIES_REAL_TIME" does not exist, Sqlstate: 42V01, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Miner/server/vertica/Catalog/CatalogLookup.cpp, Line: 4362, Error Code: 4568, SQL: 'CREATE OR REPLACE VIEW "OW_SEDA_S_LOGISTIC"."VW_CT_AR_BALANCE_REAL_TIME" (   "ROWSQL",   "ORDER_ID",   "SEQUENCE",   "CUSTOMER_CHANNEL",   "CRED_EST",   "DEB_EST",   "CRED_INF",   "DEB_INF",   "CRED_MKP",   "DEB_MKP",   "BALANCE",   "ANALYSIS" ) AS SELECT   ROW_NUMBER() OVER (ORDER BY SEQUENCE) AS ROWSQL,   ORDER_ID,   SEQUENCE,   CUSTOMER_CHANNEL,   SUM(CRED_EST) AS CRED_EST,   SUM(DEB_EST) AS DEB_EST,   SUM(CRED_INF) AS CRED_INF,   SUM(DEB_INF) AS DEB_INF,   SUM(CRED_MKP) AS CRED_MKP,   SUM(DEB_MKP) AS DEB_MKP FROM (   SELECT     ORDER_ID,     SEQUENCE,     CUSTOMER_CHANNEL,     NULL AS HAS_CLEAR_DOC,     SUM(D001_EST * (       SIGN(D001_EST) + 1     ) / 2) + SUM(D002_EST * (       SIGN(D002_EST) + 1     ) / 2) + SUM(D009_EST * (       SIGN(D009_EST) + 1     ) / 2) + SUM(D011_EST * (       SIGN(D011_EST) + 1     ) / 2) + SUM(D012_EST * (       SIGN(D012_EST) + 1     ) / 2) + SUM(D019_EST * (       SIGN(D019_EST) + 1     ) / 2) + SUM(DA06_EST * (       SIGN(DA06_EST) + 1     ) / 2) + SUM(DA08_EST * (       SIGN(DA08_EST) + 1     ) / 2) + SUM(DA09_EST * (       SIGN(DA09_EST) + 1     ) / 2) + SUM(DA15_EST * (       SIGN(DA15_EST) + 1     ) / 2) + SUM(DA16_EST * (       SIGN(DA16_EST) + 1     ) / 2) + SUM(DA19_EST * (       SIGN(DA19_EST) + 1     ) / 2) + SUM(DK19_EST * (       SIGN(DK19_EST) + 1     ) / 2) + SUM(DO05_EST * (       SIGN(DO05_EST) + 1     ) / 2) + SUM(DO08_EST * (       SIGN(DO08_EST) + 1     ) / 2) + SUM(DO09_EST * (       SIGN(DO09_EST) + 1     ) / 2) + SUM(DO15_EST * (       SIGN(DO15_EST) + 1     ) / 2) + SUM(DO18_EST * (       SIGN(DO18_EST) + 1     ) / 2) + SUM(DO19_EST * (       SIGN(DO19_EST) + 1     ) / 2) + SUM(RV01_EST * (       SIGN(RV01_EST) + 1     ) / 2) + SUM(RV11_EST * (       SIGN(RV11_EST) + 1     ) / 2) + SUM(VR06_EST * (       SIGN(VR06_EST) + 1     ) / 2) + SUM(VR08_EST * (       SIGN(VR08_EST) + 1     ) / 2) + SUM(VR09_EST * (       SIGN(VR09_EST) + 1     ) / 2) + SUM(VR16_EST * (       SIGN(VR16_EST) + 1     ) / 2) + SUM(VR18_EST * (       SIGN(VR18_EST) + 1     ) / 2) + SUM(VR19_EST * (       SIGN(VR19_EST) + 1     ) / 2) + SUM(VV01_EST * (       SIGN(VV01_EST) + 1     ) / 2) + SUM(VV04_EST * (       SIGN(VV04_EST) + 1     ) / 2) + SUM(VV06_EST * (       SIGN(VV06_EST) + 1     ) / 2) + SUM(VV09_EST * (       SIGN(VV09_EST) + 1     ) / 2) + SUM(VV11_EST * (       SIGN(VV11_EST) + 1     ) / 2) + SUM(VV14_EST * (       SIGN(VV14_EST) + 1     ) / 2) + SUM(VV16_EST * (       SIGN(VV16_EST) + 1     ) / 2) + SUM(VV19_EST * (       SIGN(VV19_EST) + 1     ) / 2) + SUM(YU01_EST * (       SIGN(YU01_EST) + 1     ) / 2) AS DEB_EST,     -1 * SUM(D001_EST * (       SIGN(D001_EST) - 1     ) / 2) + -1 * SUM(D002_EST * (       SIGN(D002_EST) - 1     ) / 2) + -1 * SUM(D009_EST * (       SIGN(D009_EST) - 1     ) / 2) + -1 * SUM(D011_EST * (       SIGN(D011_EST) - 1     ) / 2) + -1 * SUM(D012_EST * (       SIGN(D012_EST) - 1     ) / 2) + -1 * SUM(D019_EST * (       SIGN(D019_EST) - 1     ) / 2) + -1 * SUM(DA06_EST * (       SIGN(DA06_EST) - 1     ) / 2) + -1 * SUM(DA08_EST * (       SIGN(DA08_EST) - 1     ) / 2) + -1 * SUM(DA09_EST * (       SIGN(DA09_EST) - 1     ) / 2) + -1 * SUM(DA15_EST * (       SIGN(DA15_EST) - 1     ) / 2) + -1 * SUM(DA16_EST * (       SIGN(DA16_EST) - 1     ) / 2) + -1 * SUM(DA19_EST * (       SIGN(DA19_EST) - 1     ) / 2) + -1 * SUM(DK19_EST * (       SIGN(DK19_EST) - 1     ) / 2) + -1 * SUM(DO05_EST * (       SIGN(DO05_EST) - 1     ) / 2) + -1 * SUM(DO08_EST * (       SIGN(DO08_EST) - 1     ) / 2) + -1 * SUM(DO09_EST * (       SIGN(DO09_EST) - 1     ) / 2) + -1 * SUM(DO15_EST * (       SIGN(DO15_EST) - 1     ) / 2) + -1 * SUM(DO18_EST * (       SIGN(DO18_EST) - 1     ) / 2) + -1 * SUM(DO19_EST * (       SIGN(DO19_EST) - 1     ) / 2) + -1 * SUM(RV01_EST * (       SIGN(RV01_EST) - 1     ) / 2) + -1 * SUM(RV11_EST * (       SIGN(RV11_EST) - 1     ) / 2) + -1 * SUM(VR06_EST * (       SIGN(VR06_EST) - 1     ) / 2) + -1 * SUM(VR08_EST * (       SIGN(VR08_EST) - 1     ) / 2) + -1 * SUM(VR09_EST * (       SIGN(VR09_EST) - 1     ) / 2) + -1 * SUM(VR16_EST * (       SIGN(VR16_EST) - 1     ) / 2) + -1 * SUM(VR18_EST * (       SIGN(VR18_EST) - 1     ) / 2) + -1 * SUM(VR19_EST * (       SIGN(VR19_EST) - 1     ) / 2) + -1 * SUM(VV01_EST * (       SIGN(VV01_EST) - 1     ) / 2) + -1 * SUM(VV04_EST * (       SIGN(VV04_EST) - 1     ) / 2) + -1 * SUM(VV06_EST * (       SIGN(VV06_EST) - 1     ) / 2) + -1 * SUM(VV09_EST * (       SIGN(VV09_EST) - 1     ) / 2) + -1 * SUM(VV11_EST * (       SIGN(VV11_EST) - 1     ) / 2) + -1 * SUM(VV14_EST * (       SIGN(VV14_EST) - 1     ) / 2) + -1 * SUM(VV16_EST * (       SIGN(VV16_EST) - 1     ) / 2) + -1 * SUM(VV19_EST * (       SIGN(VV19_EST) - 1     ) / 2) + -1 * SUM(YU01_EST * (       SIGN(YU01_EST) - 1     ) / 2) AS CRED_EST,     SUM(D001_INF * (       SIGN(D001_INF) + 1     ) / 2) + SUM(D002_INF * (       SIGN(D002_INF) + 1     ) / 2) + SUM(D009_INF * (       SIGN(D009_INF) + 1     ) / 2) + SUM(D011_INF * (       SIGN(D011_INF) + 1     ) / 2) + SUM(D012_INF * (       SIGN(D012_INF) + 1     ) / 2) + SUM(D019_INF * (       SIGN(D019_INF) + 1     ) / 2) + SUM(DA06_INF * (       SIGN(DA06_INF) + 1     ) / 2) + SUM(DA08_INF * (       SIGN(DA08_INF) + 1     ) / 2) + SUM(DA09_INF * (       SIGN(DA09_INF) + 1     ) / 2) + SUM(DA15_INF * (       SIGN(DA15_INF) + 1     ) / 2) + SUM(DA16_INF * (       SIGN(DA16_INF) + 1     ) / 2) + SUM(DA19_INF * (       SIGN(DA19_INF) + 1     ) / 2) + SUM(DK19_INF * (       SIGN(DK19_INF) + 1     ) / 2) + SUM(DO05_INF * (       SIGN(DO05_INF) + 1     ) / 2) + SUM(DO08_INF * (       SIGN(DO08_INF) + 1     ) / 2) + SUM(DO09_INF * (       SIGN(DO09_INF) + 1     ) / 2) + SUM(DO15_INF * (       SIGN(DO15_INF) + 1     ) / 2) + SUM(DO18_INF * (       SIGN(DO18_INF) + 1     ) / 2) + SUM(DO19_INF * (       SIGN(DO19_INF) + 1     ) / 2) + SUM(RV01_INF * (       SIGN(RV01_INF) + 1     ) / 2) + SUM(RV11_INF * (       SIGN(RV11_INF) + 1     ) / 2) + SUM(VR06_INF * (       SIGN(VR06_INF) + 1     ) / 2) + SUM(VR08_INF * (       SIGN(VR08_INF) + 1     ) / 2) + SUM(VR09_INF * (       SIGN(VR09_INF) + 1     ) / 2) + SUM(VR16_INF * (       SIGN(VR16_INF) + 1     ) / 2) + SUM(VR18_INF * (       SIGN(VR18_INF) + 1     ) / 2) + SUM(VR19_INF * (       SIGN(VR19_INF) + 1     ) / 2) + SUM(VV01_INF * (       SIGN(VV01_INF) + 1     ) / 2) + SUM(VV04_INF * (       SIGN(VV04_INF) + 1     ) / 2) + SUM(VV06_INF * (       SIGN(VV06_INF) + 1     ) / 2) + SUM(VV09_INF * (       SIGN(VV09_INF) + 1     ) / 2) + SUM(VV11_INF * (       SIGN(VV11_INF) + 1     ) / 2) + SUM(VV14_INF * (       SIGN(VV14_INF) + 1     ) / 2) + SUM(VV16_INF * (       SIGN(VV16_INF) + 1     ) / 2) + SUM(VV19_INF * (       SIGN(VV19_INF) + 1     ) / 2) + SUM(YU01_INF * (       SIGN(YU01_INF) + 1     ) / 2) AS DEB_INF,     -1 * SUM(D001_INF * (       SIGN(D001_INF) - 1     ) / 2) + -1 * SUM(D002_INF * (       SIGN(D002_INF) - 1     ) / 2) + -1 * SUM(D009_INF * (       SIGN(D009_INF) - 1     ) / 2) + -1 * SUM(D011_INF * (       SIGN(D011_INF) - 1     ) / 2) + -1 * SUM(D012_INF * (       SIGN(D012_INF) - 1     ) / 2) + -1 * SUM(D019_INF * (       SIGN(D019_INF) - 1     ) / 2) + -1 * SUM(DA06_INF * (       SIGN(DA06_INF) - 1     ) / 2) + -1 * SUM(DA08_INF * (       SIGN(DA08_INF) - 1     ) / 2) + -1 * SUM(DA09_INF * (       SIGN(DA09_INF) - 1     ) / 2) + -1 * SUM(DA15_INF * (       SIGN(DA15_INF) - 1     ) / 2) + -1 * SUM(DA16_INF * (       SIGN(DA16_INF) - 1     ) / 2) + -1 * SUM(DA19_INF * (       SIGN(DA19_INF) - 1     ) / 2) + -1 * SUM(DK19_INF * (       SIGN(DK19_INF) - 1     ) / 2) + -1 * SUM(DO05_INF * (       SIGN(DO05_INF) - 1     ) / 2) + -1 * SUM(DO08_INF * (       SIGN(DO08_INF) - 1     ) / 2) + -1 * SUM(DO09_INF * (       SIGN(DO09_INF) - 1     ) / 2) + -1 * SUM(DO15_INF * (       SIGN(DO15_INF) - 1     ) / 2) + -1 * SUM(DO18_INF * (       SIGN(DO18_INF) - 1     ) / 2) + -1 * SUM(DO19_INF * (       SIGN(DO19_INF) - 1     ) / 2) + -1 * SUM(RV01_INF * (       SIGN(RV01_INF) - 1     ) / 2) + -1 * SUM(RV11_INF * (       SIGN(RV11_INF) - 1     ) / 2) + -1 * SUM(VR06_INF * (       SIGN(VR06_INF) - 1     ) / 2) + -1 * SUM(VR08_INF * (       SIGN(VR08_INF) - 1     ) / 2) + -1 * SUM(VR09_INF * (       SIGN(VR09_INF) - 1     ) / 2) + -1 * SUM(VR16_INF * (       SIGN(VR16_INF) - 1     ) / 2) + -1 * SUM(VR18_INF * (       SIGN(VR18_INF) - 1     ) / 2) + -1 * SUM(VR19_INF * (       SIGN(VR19_INF) - 1     ) / 2) + -1 * SUM(VV01_INF * (       SIGN(VV01_INF) - 1     ) / 2) + -1 * SUM(VV04_INF * (       SIGN(VV04_INF) - 1     ) / 2) + -1 * SUM(VV06_INF * (       SIGN(VV06_INF) - 1     ) / 2) + -1 * SUM(VV09_INF * (       SIGN(VV09_INF) - 1     ) / 2) + -1 * SUM(VV11_INF * (       SIGN(VV11_INF) - 1     ) / 2) + -1 * SUM(VV14_INF * (       SIGN(VV14_INF) - 1     ) / 2) + -1 * SUM(VV16_INF * (       SIGN(VV16_INF) - 1     ) / 2) + -1 * SUM(VV19_INF * (       SIGN(VV19_INF) - 1     ) / 2) + -1 * SUM(YU01_INF * (       SIGN(YU01_INF) - 1     ) / 2) AS CRED_INF,     SUM(D001_MKP * (       SIGN(D001_MKP) + 1     ) / 2) + SUM(D002_MKP * (       SIGN(D002_MKP) + 1     ) / 2) + SUM(D009_MKP * (       SIGN(D009_MKP) + 1     ) / 2) + SUM(D011_MKP * (       SIGN(D011_MKP) + 1     ) / 2) + SUM(D012_MKP * (       SIGN(D012_MKP) + 1     ) / 2) + SUM(D019_MKP * (       SIGN(D019_MKP) + 1     ) / 2) + SUM(DA06_MKP * (       SIGN(DA06_MKP) + 1     ) / 2) + SUM(DA08_MKP * (       SIGN(DA08_MKP) + 1     ) / 2) + SUM(DA09_MKP * (       SIGN(DA09_MKP) + 1     ) / 2) + SUM(DA15_MKP * (       SIGN(DA15_MKP) + 1     ) / 2) + SUM(DA16_MKP * (       SIGN(DA16_MKP) + 1     ) / 2) + SUM(DA19_MKP * (       SIGN(DA19_MKP) + 1     ) / 2) + SUM(DK19_MKP * (       SIGN(DK19_MKP) + 1     ) / 2) + SUM(DO05_MKP * (       SIGN(DO05_MKP) + 1     ) / 2) + SUM(DO08_MKP * (       SIGN(DO08_MKP) + 1     ) / 2) + SUM(DO09_MKP * (       SIGN(DO09_MKP) + 1     ) / 2) + SUM(DO15_MKP * (       SIGN(DO15_MKP) + 1     ) / 2) + SUM(DO18_MKP * (       SIGN(DO18_MKP) + 1     ) / 2) + SUM(DO19_MKP * (       SIGN(DO19_MKP) + 1     ) / 2) + SUM(RV01_MKP * (       SIGN(RV01_MKP) + 1     ) / 2) + SUM(RV11_MKP * (       SIGN(RV11_MKP) + 1     ) / 2) + SUM(VR06_MKP * (       SIGN(VR06_MKP) + 1     ) / 2) + SUM(VR08_MKP * (       SIGN(VR08_MKP) + 1     ) / 2) + SUM(VR09_MKP * (       SIGN(VR09_MKP) + 1     ) / 2) + SUM(VR16_MKP * (       SIGN(VR16_MKP) + 1     ) / 2) + SUM(VR18_MKP * (       SIGN(VR18_MKP) + 1     ) / 2) + SUM(VR19_MKP * (       SIGN(VR19_MKP) + 1     ) / 2) + SUM(VV01_MKP * (       SIGN(VV01_MKP) + 1     ) / 2) + SUM(VV04_MKP * (       SIGN(VV04_MKP) + 1     ) / 2) + SUM(VV06_MKP * (       SIGN(VV06_MKP) + 1     ) / 2) + SUM(VV09_MKP * (       SIGN(VV09_MKP) + 1     ) / 2) + SUM(VV11_MKP * (       SIGN(VV11_MKP) + 1     ) / 2) + SUM(VV14_MKP * (       SIGN(VV14_MKP) + 1     ) / 2) + SUM(VV16_MKP * (       SIGN(VV16_MKP) + 1     ) / 2) + SUM(VV19_MKP * (       SIGN(VV19_MKP) + 1     ) / 2) + SUM(YU01_MKP * (       SIGN(YU01_MKP) + 1     ) / 2) AS DEB_MKP,     -1 * SUM(D001_MKP * (       SIGN(D001_MKP) - 1     ) / 2) + -1 * SUM(D002_MKP * (       SIGN(D002_MKP) - 1     ) / 2) + -1 * SUM(D009_MKP * (       SIGN(D009_MKP) - 1     ) / 2) + -1 * SUM(D011_MKP * (       SIGN(D011_MKP) - 1     ) / 2) + -1 * SUM(D012_MKP * (       SIGN(D012_MKP) - 1     ) / 2) + -1 * SUM(D019_MKP * (       SIGN(D019_MKP) - 1     ) / 2) + -1 * SUM(DA06_MKP * (       SIGN(DA06_MKP) - 1     ) / 2) + -1 * SUM(DA08_MKP * (       SIGN(DA08_MKP) - 1     ) / 2) + -1 * SUM(DA09_MKP * (       SIGN(DA09_MKP) - 1     ) / 2) + -1 * SUM(DA15_MKP * (       SIGN(DA15_MKP) - 1     ) / 2) + -1 * SUM(DA16_MKP * (       SIGN(DA16_MKP) - 1     ) / 2) + -1 * SUM(DA19_MKP * (       SIGN(DA19_MKP) - 1     ) / 2) + -1 * SUM(DK19_MKP * (       SIGN(DK19_MKP) - 1     ) / 2) + -1 * SUM(DO05_MKP * (       SIGN(DO05_MKP) - 1     ) / 2) + -1 * SUM(DO08_MKP * (       SIGN(DO08_MKP) - 1     ) / 2) + -1 * SUM(DO09_MKP * (       SIGN(DO09_MKP) - 1     ) / 2) + -1 * SUM(DO15_MKP * (       SIGN(DO15_MKP) - 1     ) / 2) + -1 * SUM(DO18_MKP * (       SIGN(DO18_MKP) - 1     ) / 2) + -1 * SUM(DO19_MKP * (       SIGN(DO19_MKP) - 1     ) / 2) + -1 * SUM(RV01_MKP * (       SIGN(RV01_MKP) - 1     ) / 2) + -1 * SUM(RV11_MKP * (       SIGN(RV11_MKP) - 1     ) / 2) + -1 * SUM(VR06_MKP * (       SIGN(VR06_MKP) - 1     ) / 2) + -1 * SUM(VR08_MKP * (       SIGN(VR08_MKP) - 1     ) / 2) + -1 * SUM(VR09_MKP * (       SIGN(VR09_MKP) - 1     ) / 2) + -1 * SUM(VR16_MKP * (       SIGN(VR16_MKP) - 1     ) / 2) + -1 * SUM(VR18_MKP * (       SIGN(VR18_MKP) - 1     ) / 2) + -1 * SUM(VR19_MKP * (       SIGN(VR19_MKP) - 1     ) / 2) + -1 * SUM(VV01_MKP * (       SIGN(VV01_MKP) - 1     ) / 2) + -1 * SUM(VV04_MKP * (       SIGN(VV04_MKP) - 1     ) / 2) + -1 * SUM(VV06_MKP * (       SIGN(VV06_MKP) - 1     ) / 2) + -1 * SUM(VV09_MKP * (       SIGN(VV09_MKP) - 1     ) / 2) + -1 * SUM(VV11_MKP * (       SIGN(VV11_MKP) - 1     ) / 2) + -1 * SUM(VV14_MKP * (       SIGN(VV14_MKP) - 1     ) / 2) + -1 * SUM(VV16_MKP * (       SIGN(VV16_MKP) - 1     ) / 2) + -1 * SUM(VV19_MKP * (       SIGN(VV19_MKP) - 1     ) / 2) + -1 * SUM(YU01_MKP * (       SIGN(YU01_MKP) - 1     ) / 2) AS CRED_MKP   FROM OW_SEDA_S_LOGISTIC.FT_CT_AR_ENTRIES_REAL_TIME   GROUP BY     ORDER_ID,     SEQUENCE,     CUSTOMER_CHANNEL,     HAS_CLEAR_DOC ) AS subq_3936 GROUP BY   ORDER_ID,   SEQUENCE,   CUSTOMER_CHANNEL,   HAS_CLEAR_DOC'

CREATE OR REPLACE VIEW "OW_SEDA_S_LOGISTIC"."VW_CT_AR_BALANCE_REAL_TIME" (
  "ROWSQL",
  "ORDER_ID",
  "SEQUENCE",
  "CUSTOMER_CHANNEL",
  "CRED_EST",
  "DEB_EST",
  "CRED_INF",
  "DEB_INF",
  "CRED_MKP",
  "DEB_MKP",
  "BALANCE",
  "ANALYSIS"
) AS
SELECT
  ROW_NUMBER() OVER (ORDER BY SEQUENCE) AS ROWSQL,
  ORDER_ID,
  SEQUENCE,
  CUSTOMER_CHANNEL,
  SUM(CRED_EST) AS CRED_EST,
  SUM(DEB_EST) AS DEB_EST,
  SUM(CRED_INF) AS CRED_INF,
  SUM(DEB_INF) AS DEB_INF,
  SUM(CRED_MKP) AS CRED_MKP,
  SUM(DEB_MKP) AS DEB_MKP
FROM (
  SELECT
    ORDER_ID,
    SEQUENCE,
    CUSTOMER_CHANNEL,
    NULL AS HAS_CLEAR_DOC,
    SUM(D001_EST * (
      SIGN(D001_EST) + 1
    ) / 2) + SUM(D002_EST * (
      SIGN(D002_EST) + 1
    ) / 2) + SUM(D009_EST * (
      SIGN(D009_EST) + 1
    ) / 2) + SUM(D011_EST * (
      SIGN(D011_EST) + 1
    ) / 2) + SUM(D012_EST * (
      SIGN(D012_EST) + 1
    ) / 2) + SUM(D019_EST * (
      SIGN(D019_EST) + 1
    ) / 2) + SUM(DA06_EST * (
      SIGN(DA06_EST) + 1
    ) / 2) + SUM(DA08_EST * (
      SIGN(DA08_EST) + 1
    ) / 2) + SUM(DA09_EST * (
      SIGN(DA09_EST) + 1
    ) / 2) + SUM(DA15_EST * (
      SIGN(DA15_EST) + 1
    ) / 2) + SUM(DA16_EST * (
      SIGN(DA16_EST) + 1
    ) / 2) + SUM(DA19_EST * (
      SIGN(DA19_EST) + 1
    ) / 2) + SUM(DK19_EST * (
      SIGN(DK19_EST) + 1
    ) / 2) + SUM(DO05_EST * (
      SIGN(DO05_EST) + 1
    ) / 2) + SUM(DO08_EST * (
      SIGN(DO08_EST) + 1
    ) / 2) + SUM(DO09_EST * (
      SIGN(DO09_EST) + 1
    ) / 2) + SUM(DO15_EST * (
      SIGN(DO15_EST) + 1
    ) / 2) + SUM(DO18_EST * (
      SIGN(DO18_EST) + 1
    ) / 2) + SUM(DO19_EST * (
      SIGN(DO19_EST) + 1
    ) / 2) + SUM(RV01_EST * (
      SIGN(RV01_EST) + 1
    ) / 2) + SUM(RV11_EST * (
      SIGN(RV11_EST) + 1
    ) / 2) + SUM(VR06_EST * (
      SIGN(VR06_EST) + 1
    ) / 2) + SUM(VR08_EST * (
      SIGN(VR08_EST) + 1
    ) / 2) + SUM(VR09_EST * (
      SIGN(VR09_EST) + 1
    ) / 2) + SUM(VR16_EST * (
      SIGN(VR16_EST) + 1
    ) / 2) + SUM(VR18_EST * (
      SIGN(VR18_EST) + 1
    ) / 2) + SUM(VR19_EST * (
      SIGN(VR19_EST) + 1
    ) / 2) + SUM(VV01_EST * (
      SIGN(VV01_EST) + 1
    ) / 2) + SUM(VV04_EST * (
      SIGN(VV04_EST) + 1
    ) / 2) + SUM(VV06_EST * (
      SIGN(VV06_EST) + 1
    ) / 2) + SUM(VV09_EST * (
      SIGN(VV09_EST) + 1
    ) / 2) + SUM(VV11_EST * (
      SIGN(VV11_EST) + 1
    ) / 2) + SUM(VV14_EST * (
      SIGN(VV14_EST) + 1
    ) / 2) + SUM(VV16_EST * (
      SIGN(VV16_EST) + 1
    ) / 2) + SUM(VV19_EST * (
      SIGN(VV19_EST) + 1
    ) / 2) + SUM(YU01_EST * (
      SIGN(YU01_EST) + 1
    ) / 2) AS DEB_EST,
    -1 * SUM(D001_EST * (
      SIGN(D001_EST) - 1
    ) / 2) + -1 * SUM(D002_EST * (
      SIGN(D002_EST) - 1
    ) / 2) + -1 * SUM(D009_EST * (
      SIGN(D009_EST) - 1
    ) / 2) + -1 * SUM(D011_EST * (
      SIGN(D011_EST) - 1
    ) / 2) + -1 * SUM(D012_EST * (
      SIGN(D012_EST) - 1
    ) / 2) + -1 * SUM(D019_EST * (
      SIGN(D019_EST) - 1
    ) / 2) + -1 * SUM(DA06_EST * (
      SIGN(DA06_EST) - 1
    ) / 2) + -1 * SUM(DA08_EST * (
      SIGN(DA08_EST) - 1
    ) / 2) + -1 * SUM(DA09_EST * (
      SIGN(DA09_EST) - 1
    ) / 2) + -1 * SUM(DA15_EST * (
      SIGN(DA15_EST) - 1
    ) / 2) + -1 * SUM(DA16_EST * (
      SIGN(DA16_EST) - 1
    ) / 2) + -1 * SUM(DA19_EST * (
      SIGN(DA19_EST) - 1
    ) / 2) + -1 * SUM(DK19_EST * (
      SIGN(DK19_EST) - 1
    ) / 2) + -1 * SUM(DO05_EST * (
      SIGN(DO05_EST) - 1
    ) / 2) + -1 * SUM(DO08_EST * (
      SIGN(DO08_EST) - 1
    ) / 2) + -1 * SUM(DO09_EST * (
      SIGN(DO09_EST) - 1
    ) / 2) + -1 * SUM(DO15_EST * (
      SIGN(DO15_EST) - 1
    ) / 2) + -1 * SUM(DO18_EST * (
      SIGN(DO18_EST) - 1
    ) / 2) + -1 * SUM(DO19_EST * (
      SIGN(DO19_EST) - 1
    ) / 2) + -1 * SUM(RV01_EST * (
      SIGN(RV01_EST) - 1
    ) / 2) + -1 * SUM(RV11_EST * (
      SIGN(RV11_EST) - 1
    ) / 2) + -1 * SUM(VR06_EST * (
      SIGN(VR06_EST) - 1
    ) / 2) + -1 * SUM(VR08_EST * (
      SIGN(VR08_EST) - 1
    ) / 2) + -1 * SUM(VR09_EST * (
      SIGN(VR09_EST) - 1
    ) / 2) + -1 * SUM(VR16_EST * (
      SIGN(VR16_EST) - 1
    ) / 2) + -1 * SUM(VR18_EST * (
      SIGN(VR18_EST) - 1
    ) / 2) + -1 * SUM(VR19_EST * (
      SIGN(VR19_EST) - 1
    ) / 2) + -1 * SUM(VV01_EST * (
      SIGN(VV01_EST) - 1
    ) / 2) + -1 * SUM(VV04_EST * (
      SIGN(VV04_EST) - 1
    ) / 2) + -1 * SUM(VV06_EST * (
      SIGN(VV06_EST) - 1
    ) / 2) + -1 * SUM(VV09_EST * (
      SIGN(VV09_EST) - 1
    ) / 2) + -1 * SUM(VV11_EST * (
      SIGN(VV11_EST) - 1
    ) / 2) + -1 * SUM(VV14_EST * (
      SIGN(VV14_EST) - 1
    ) / 2) + -1 * SUM(VV16_EST * (
      SIGN(VV16_EST) - 1
    ) / 2) + -1 * SUM(VV19_EST * (
      SIGN(VV19_EST) - 1
    ) / 2) + -1 * SUM(YU01_EST * (
      SIGN(YU01_EST) - 1
    ) / 2) AS CRED_EST,
    SUM(D001_INF * (
      SIGN(D001_INF) + 1
    ) / 2) + SUM(D002_INF * (
      SIGN(D002_INF) + 1
    ) / 2) + SUM(D009_INF * (
      SIGN(D009_INF) + 1
    ) / 2) + SUM(D011_INF * (
      SIGN(D011_INF) + 1
    ) / 2) + SUM(D012_INF * (
      SIGN(D012_INF) + 1
    ) / 2) + SUM(D019_INF * (
      SIGN(D019_INF) + 1
    ) / 2) + SUM(DA06_INF * (
      SIGN(DA06_INF) + 1
    ) / 2) + SUM(DA08_INF * (
      SIGN(DA08_INF) + 1
    ) / 2) + SUM(DA09_INF * (
      SIGN(DA09_INF) + 1
    ) / 2) + SUM(DA15_INF * (
      SIGN(DA15_INF) + 1
    ) / 2) + SUM(DA16_INF * (
      SIGN(DA16_INF) + 1
    ) / 2) + SUM(DA19_INF * (
      SIGN(DA19_INF) + 1
    ) / 2) + SUM(DK19_INF * (
      SIGN(DK19_INF) + 1
    ) / 2) + SUM(DO05_INF * (
      SIGN(DO05_INF) + 1
    ) / 2) + SUM(DO08_INF * (
      SIGN(DO08_INF) + 1
    ) / 2) + SUM(DO09_INF * (
      SIGN(DO09_INF) + 1
    ) / 2) + SUM(DO15_INF * (
      SIGN(DO15_INF) + 1
    ) / 2) + SUM(DO18_INF * (
      SIGN(DO18_INF) + 1
    ) / 2) + SUM(DO19_INF * (
      SIGN(DO19_INF) + 1
    ) / 2) + SUM(RV01_INF * (
      SIGN(RV01_INF) + 1
    ) / 2) + SUM(RV11_INF * (
      SIGN(RV11_INF) + 1
    ) / 2) + SUM(VR06_INF * (
      SIGN(VR06_INF) + 1
    ) / 2) + SUM(VR08_INF * (
      SIGN(VR08_INF) + 1
    ) / 2) + SUM(VR09_INF * (
      SIGN(VR09_INF) + 1
    ) / 2) + SUM(VR16_INF * (
      SIGN(VR16_INF) + 1
    ) / 2) + SUM(VR18_INF * (
      SIGN(VR18_INF) + 1
    ) / 2) + SUM(VR19_INF * (
      SIGN(VR19_INF) + 1
    ) / 2) + SUM(VV01_INF * (
      SIGN(VV01_INF) + 1
    ) / 2) + SUM(VV04_INF * (
      SIGN(VV04_INF) + 1
    ) / 2) + SUM(VV06_INF * (
      SIGN(VV06_INF) + 1
    ) / 2) + SUM(VV09_INF * (
      SIGN(VV09_INF) + 1
    ) / 2) + SUM(VV11_INF * (
      SIGN(VV11_INF) + 1
    ) / 2) + SUM(VV14_INF * (
      SIGN(VV14_INF) + 1
    ) / 2) + SUM(VV16_INF * (
      SIGN(VV16_INF) + 1
    ) / 2) + SUM(VV19_INF * (
      SIGN(VV19_INF) + 1
    ) / 2) + SUM(YU01_INF * (
      SIGN(YU01_INF) + 1
    ) / 2) AS DEB_INF,
    -1 * SUM(D001_INF * (
      SIGN(D001_INF) - 1
    ) / 2) + -1 * SUM(D002_INF * (
      SIGN(D002_INF) - 1
    ) / 2) + -1 * SUM(D009_INF * (
      SIGN(D009_INF) - 1
    ) / 2) + -1 * SUM(D011_INF * (
      SIGN(D011_INF) - 1
    ) / 2) + -1 * SUM(D012_INF * (
      SIGN(D012_INF) - 1
    ) / 2) + -1 * SUM(D019_INF * (
      SIGN(D019_INF) - 1
    ) / 2) + -1 * SUM(DA06_INF * (
      SIGN(DA06_INF) - 1
    ) / 2) + -1 * SUM(DA08_INF * (
      SIGN(DA08_INF) - 1
    ) / 2) + -1 * SUM(DA09_INF * (
      SIGN(DA09_INF) - 1
    ) / 2) + -1 * SUM(DA15_INF * (
      SIGN(DA15_INF) - 1
    ) / 2) + -1 * SUM(DA16_INF * (
      SIGN(DA16_INF) - 1
    ) / 2) + -1 * SUM(DA19_INF * (
      SIGN(DA19_INF) - 1
    ) / 2) + -1 * SUM(DK19_INF * (
      SIGN(DK19_INF) - 1
    ) / 2) + -1 * SUM(DO05_INF * (
      SIGN(DO05_INF) - 1
    ) / 2) + -1 * SUM(DO08_INF * (
      SIGN(DO08_INF) - 1
    ) / 2) + -1 * SUM(DO09_INF * (
      SIGN(DO09_INF) - 1
    ) / 2) + -1 * SUM(DO15_INF * (
      SIGN(DO15_INF) - 1
    ) / 2) + -1 * SUM(DO18_INF * (
      SIGN(DO18_INF) - 1
    ) / 2) + -1 * SUM(DO19_INF * (
      SIGN(DO19_INF) - 1
    ) / 2) + -1 * SUM(RV01_INF * (
      SIGN(RV01_INF) - 1
    ) / 2) + -1 * SUM(RV11_INF * (
      SIGN(RV11_INF) - 1
    ) / 2) + -1 * SUM(VR06_INF * (
      SIGN(VR06_INF) - 1
    ) / 2) + -1 * SUM(VR08_INF * (
      SIGN(VR08_INF) - 1
    ) / 2) + -1 * SUM(VR09_INF * (
      SIGN(VR09_INF) - 1
    ) / 2) + -1 * SUM(VR16_INF * (
      SIGN(VR16_INF) - 1
    ) / 2) + -1 * SUM(VR18_INF * (
      SIGN(VR18_INF) - 1
    ) / 2) + -1 * SUM(VR19_INF * (
      SIGN(VR19_INF) - 1
    ) / 2) + -1 * SUM(VV01_INF * (
      SIGN(VV01_INF) - 1
    ) / 2) + -1 * SUM(VV04_INF * (
      SIGN(VV04_INF) - 1
    ) / 2) + -1 * SUM(VV06_INF * (
      SIGN(VV06_INF) - 1
    ) / 2) + -1 * SUM(VV09_INF * (
      SIGN(VV09_INF) - 1
    ) / 2) + -1 * SUM(VV11_INF * (
      SIGN(VV11_INF) - 1
    ) / 2) + -1 * SUM(VV14_INF * (
      SIGN(VV14_INF) - 1
    ) / 2) + -1 * SUM(VV16_INF * (
      SIGN(VV16_INF) - 1
    ) / 2) + -1 * SUM(VV19_INF * (
      SIGN(VV19_INF) - 1
    ) / 2) + -1 * SUM(YU01_INF * (
      SIGN(YU01_INF) - 1
    ) / 2) AS CRED_INF,
    SUM(D001_MKP * (
      SIGN(D001_MKP) + 1
    ) / 2) + SUM(D002_MKP * (
      SIGN(D002_MKP) + 1
    ) / 2) + SUM(D009_MKP * (
      SIGN(D009_MKP) + 1
    ) / 2) + SUM(D011_MKP * (
      SIGN(D011_MKP) + 1
    ) / 2) + SUM(D012_MKP * (
      SIGN(D012_MKP) + 1
    ) / 2) + SUM(D019_MKP * (
      SIGN(D019_MKP) + 1
    ) / 2) + SUM(DA06_MKP * (
      SIGN(DA06_MKP) + 1
    ) / 2) + SUM(DA08_MKP * (
      SIGN(DA08_MKP) + 1
    ) / 2) + SUM(DA09_MKP * (
      SIGN(DA09_MKP) + 1
    ) / 2) + SUM(DA15_MKP * (
      SIGN(DA15_MKP) + 1
    ) / 2) + SUM(DA16_MKP * (
      SIGN(DA16_MKP) + 1
    ) / 2) + SUM(DA19_MKP * (
      SIGN(DA19_MKP) + 1
    ) / 2) + SUM(DK19_MKP * (
      SIGN(DK19_MKP) + 1
    ) / 2) + SUM(DO05_MKP * (
      SIGN(DO05_MKP) + 1
    ) / 2) + SUM(DO08_MKP * (
      SIGN(DO08_MKP) + 1
    ) / 2) + SUM(DO09_MKP * (
      SIGN(DO09_MKP) + 1
    ) / 2) + SUM(DO15_MKP * (
      SIGN(DO15_MKP) + 1
    ) / 2) + SUM(DO18_MKP * (
      SIGN(DO18_MKP) + 1
    ) / 2) + SUM(DO19_MKP * (
      SIGN(DO19_MKP) + 1
    ) / 2) + SUM(RV01_MKP * (
      SIGN(RV01_MKP) + 1
    ) / 2) + SUM(RV11_MKP * (
      SIGN(RV11_MKP) + 1
    ) / 2) + SUM(VR06_MKP * (
      SIGN(VR06_MKP) + 1
    ) / 2) + SUM(VR08_MKP * (
      SIGN(VR08_MKP) + 1
    ) / 2) + SUM(VR09_MKP * (
      SIGN(VR09_MKP) + 1
    ) / 2) + SUM(VR16_MKP * (
      SIGN(VR16_MKP) + 1
    ) / 2) + SUM(VR18_MKP * (
      SIGN(VR18_MKP) + 1
    ) / 2) + SUM(VR19_MKP * (
      SIGN(VR19_MKP) + 1
    ) / 2) + SUM(VV01_MKP * (
      SIGN(VV01_MKP) + 1
    ) / 2) + SUM(VV04_MKP * (
      SIGN(VV04_MKP) + 1
    ) / 2) + SUM(VV06_MKP * (
      SIGN(VV06_MKP) + 1
    ) / 2) + SUM(VV09_MKP * (
      SIGN(VV09_MKP) + 1
    ) / 2) + SUM(VV11_MKP * (
      SIGN(VV11_MKP) + 1
    ) / 2) + SUM(VV14_MKP * (
      SIGN(VV14_MKP) + 1
    ) / 2) + SUM(VV16_MKP * (
      SIGN(VV16_MKP) + 1
    ) / 2) + SUM(VV19_MKP * (
      SIGN(VV19_MKP) + 1
    ) / 2) + SUM(YU01_MKP * (
      SIGN(YU01_MKP) + 1
    ) / 2) AS DEB_MKP,
    -1 * SUM(D001_MKP * (
      SIGN(D001_MKP) - 1
    ) / 2) + -1 * SUM(D002_MKP * (
      SIGN(D002_MKP) - 1
    ) / 2) + -1 * SUM(D009_MKP * (
      SIGN(D009_MKP) - 1
    ) / 2) + -1 * SUM(D011_MKP * (
      SIGN(D011_MKP) - 1
    ) / 2) + -1 * SUM(D012_MKP * (
      SIGN(D012_MKP) - 1
    ) / 2) + -1 * SUM(D019_MKP * (
      SIGN(D019_MKP) - 1
    ) / 2) + -1 * SUM(DA06_MKP * (
      SIGN(DA06_MKP) - 1
    ) / 2) + -1 * SUM(DA08_MKP * (
      SIGN(DA08_MKP) - 1
    ) / 2) + -1 * SUM(DA09_MKP * (
      SIGN(DA09_MKP) - 1
    ) / 2) + -1 * SUM(DA15_MKP * (
      SIGN(DA15_MKP) - 1
    ) / 2) + -1 * SUM(DA16_MKP * (
      SIGN(DA16_MKP) - 1
    ) / 2) + -1 * SUM(DA19_MKP * (
      SIGN(DA19_MKP) - 1
    ) / 2) + -1 * SUM(DK19_MKP * (
      SIGN(DK19_MKP) - 1
    ) / 2) + -1 * SUM(DO05_MKP * (
      SIGN(DO05_MKP) - 1
    ) / 2) + -1 * SUM(DO08_MKP * (
      SIGN(DO08_MKP) - 1
    ) / 2) + -1 * SUM(DO09_MKP * (
      SIGN(DO09_MKP) - 1
    ) / 2) + -1 * SUM(DO15_MKP * (
      SIGN(DO15_MKP) - 1
    ) / 2) + -1 * SUM(DO18_MKP * (
      SIGN(DO18_MKP) - 1
    ) / 2) + -1 * SUM(DO19_MKP * (
      SIGN(DO19_MKP) - 1
    ) / 2) + -1 * SUM(RV01_MKP * (
      SIGN(RV01_MKP) - 1
    ) / 2) + -1 * SUM(RV11_MKP * (
      SIGN(RV11_MKP) - 1
    ) / 2) + -1 * SUM(VR06_MKP * (
      SIGN(VR06_MKP) - 1
    ) / 2) + -1 * SUM(VR08_MKP * (
      SIGN(VR08_MKP) - 1
    ) / 2) + -1 * SUM(VR09_MKP * (
      SIGN(VR09_MKP) - 1
    ) / 2) + -1 * SUM(VR16_MKP * (
      SIGN(VR16_MKP) - 1
    ) / 2) + -1 * SUM(VR18_MKP * (
      SIGN(VR18_MKP) - 1
    ) / 2) + -1 * SUM(VR19_MKP * (
      SIGN(VR19_MKP) - 1
    ) / 2) + -1 * SUM(VV01_MKP * (
      SIGN(VV01_MKP) - 1
    ) / 2) + -1 * SUM(VV04_MKP * (
      SIGN(VV04_MKP) - 1
    ) / 2) + -1 * SUM(VV06_MKP * (
      SIGN(VV06_MKP) - 1
    ) / 2) + -1 * SUM(VV09_MKP * (
      SIGN(VV09_MKP) - 1
    ) / 2) + -1 * SUM(VV11_MKP * (
      SIGN(VV11_MKP) - 1
    ) / 2) + -1 * SUM(VV14_MKP * (
      SIGN(VV14_MKP) - 1
    ) / 2) + -1 * SUM(VV16_MKP * (
      SIGN(VV16_MKP) - 1
    ) / 2) + -1 * SUM(VV19_MKP * (
      SIGN(VV19_MKP) - 1
    ) / 2) + -1 * SUM(YU01_MKP * (
      SIGN(YU01_MKP) - 1
    ) / 2) AS CRED_MKP
  FROM OW_SEDA_S_LOGISTIC.FT_CT_AR_ENTRIES_REAL_TIME
  GROUP BY
    ORDER_ID,
    SEQUENCE,
    CUSTOMER_CHANNEL,
    HAS_CLEAR_DOC
) AS subq_3936
GROUP BY
  ORDER_ID,
  SEQUENCE,
  CUSTOMER_CHANNEL,
  HAS_CLEAR_DOC