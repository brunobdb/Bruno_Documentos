-- MISSING RELATION: OW_SEDA_S_LOGISTIC.ST_D2C_LOGCOST_HIGHEST_CWGT_CATEGORY
-- ERROR: Error executing query: Severity: ERROR, Message: Relation "OW_SEDA_S_LOGISTIC.ST_D2C_LOGCOST_HIGHEST_CWGT_CATEGORY" does not exist, Sqlstate: 42V01, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Miner/server/vertica/Catalog/CatalogLookup.cpp, Line: 4362, Error Code: 4568, SQL: 'CREATE OR REPLACE VIEW "OW_SEDA_S_LOGISTIC"."VW_ALERTA_IOD_PER_HOUR" (   "RECEIVED_DATE",   "DIVISION",   "CATEGORY",   "HORA",   "MONTH",   "MONTH_DAY",   "WEEK_DAY_NAME",   "TIPO_DIA",   "DO_QTY",   "DO_QTY_EXPECTED",   "GAP",   "NET_VALUE",   "NET_VALUE_EXPECTED",   "GAP_NET_VALUE" ) AS WITH "HORAS_DO_DIA" AS (   (     (       (         (           (             (               (                 (                   (                     (                       (                         (                           (                             (                               (                                 (                                   (                                     (                                       (                                         (                                           (                                             (                                               (                                                 (                                                   SELECT                                                     \'00\' AS HORA                                                   FROM dual                                                 )                                                 UNION ALL                                                 (                                                   SELECT                                                     \'01\'                                                   FROM dual                                                 )                                               )                                               UNION ALL                                               (                                                 SELECT                                                   \'02\'                                                 FROM dual                                               )                                             )                                             UNION ALL                                             (                                               SELECT                                                 \'03\'                                               FROM dual                                             )                                           )                                           UNION ALL                                           (                                             SELECT                                               \'04\'                                             FROM dual                                           )                                         )                                         UNION ALL                                         (                                           SELECT                                             \'05\'                                           FROM dual                                         )                                       )                                       UNION ALL                                       (                                         SELECT                                           \'06\'                                         FROM dual                                       )                                     )                                     UNION ALL                                     (                                       SELECT                                         \'07\'                                       FROM dual                                     )                                   )                                   UNION ALL                                   (                                     SELECT                                       \'08\'                                     FROM dual                                   )                                 )                                 UNION ALL                                 (                                   SELECT                                     \'09\'                                   FROM dual                                 )                               )                               UNION ALL                               (                                 SELECT                                   \'10\'                                 FROM dual                               )                             )                             UNION ALL                             (                               SELECT                                 \'11\'                               FROM dual                             )                           )                           UNION ALL                           (                             SELECT                               \'12\'                             FROM dual                           )                         )                         UNION ALL                         (                           SELECT                             \'13\'                           FROM dual                         )                       )                       UNION ALL                       (                         SELECT                           \'14\'                         FROM dual                       )                     )                     UNION ALL                     (                       SELECT                         \'15\'                       FROM dual                     )                   )                   UNION ALL                   (                     SELECT                       \'16\'                     FROM dual                   )                 )                 UNION ALL                 (                   SELECT                     \'17\'                   FROM dual                 )               )               UNION ALL               (                 SELECT                   \'18\'                 FROM dual               )             )             UNION ALL             (               SELECT                 \'19\'               FROM dual             )           )           UNION ALL           (             SELECT               \'20\'             FROM dual           )         )         UNION ALL         (           SELECT             \'21\'           FROM dual         )       )       UNION ALL       (         SELECT           \'22\'         FROM dual       )     )     UNION ALL     (       SELECT         \'23\'       FROM dual     )   ) ), "DB1" AS (   WITH "DATA_BASE" AS (     SELECT       TO_DATE((CT1.RECEIVED_DATE)::VARCHAR, \'YYYY-MM-DD\') AS RECEIVED_DATE,       CD.DELIVERY_NO,       CASE         WHEN CD.ORDER_TYPE LIKE \'%IM%\'         THEN \'MX\'         WHEN CD.ORDER_TYPE LIKE \'%MAO%\'         THEN \'MX\'         ELSE \'CE\'       END AS DIVISION,       CAT.CATEGORY,       SUM(NP.NET_VALUE) AS NET_VALUE,       (CT1.RECEIVED_DATE)::TIMESTAMP AS IOD_DATE_TIME     FROM OW_SEDA_S.CELLO_DELIVERY AS CD     LEFT JOIN (       SELECT         DELIVERY_NO,         TRK_DATE,         RECEIVED_DATE       FROM OW_SEDA_S.CELLO_TRACKING AS CT1       WHERE         TRK_CODE = \'TR4010-10\'     ) AS CT1       ON CD.DELIVERY_NO = CT1.DELIVERY_NO     LEFT JOIN OW_SEDA_S.ODS_NERP_ZLLEJ50090_OUTBOUND_TRACKING_SCM AS NP       ON CD.DELIVERY_NO = NP.DELIVERY_NO     LEFT JOIN (       SELECT         DELIVERY_NO,         CATEGORY,         ROW_NUMBER() OVER (PARTITION BY DELIVERY_NO ORDER BY C_WEIGHT DESC) AS RN       FROM OW_SEDA_S_LOGISTIC.ST_D2C_LOGCOST_HIGHEST_CWGT_CATEGORY AS CAT     ) AS CAT       ON CD.DELIVERY_NO = CAT.DELIVERY_NO AND RN = 1     WHERE       TO_DATE((CT1.RECEIVED_DATE)::VARCHAR, \'YYYY-MM-DD\') = CURRENT_DATE()       AND CD.SOLDTO_NM LIKE \'%SEDA%\'     GROUP BY       TO_DATE((CT1.RECEIVED_DATE)::VARCHAR, \'YYYY-MM-DD\'),       CD.DELIVERY_NO,       CASE         WHEN CD.ORDER_TYPE LIKE \'%IM%\'         THEN \'MX\'         WHEN CD.ORDER_TYPE LIKE \'%MAO%\'         THEN \'MX\'         ELSE \'CE\'       END,       CAT.CATEGORY,       (CT1.RECEIVED_DATE)::TIMESTAMP   )   SELECT     DM.RECEIVED_DATE,     DM.DIVISION,     DM.CATEGORY,     LPAD(CAST(DM.IOD_DATE_TIME AS VARCHAR), 2, \'0\') AS HORA,     MONTH(DM.IOD_DATE_TIME) AS MONTH,     LPAD(EXTRACT(DAY FROM DM.IOD_DATE_TIME), 2, \'0\') AS MONTH_DAY,     TO_CHAR(DM.IOD_DATE_TIME, \'Day\') AS WEEK_DAY_NAME,     CASE       WHEN NOT CAL.DESC_FERIADO IS NULL       THEN \'FERIADO\'       WHEN TO_CHAR(DM.IOD_DATE_TIME, \'Day\') = \'SATURDAY\'       THEN \'SABADO\'       WHEN TO_CHAR(DM.IOD_DATE_TIME, \'Day\') = \'SUNDAY\'       THEN \'DOMNGO\'       ELSE \'DIA DE SEMANA\'     END AS TIPO_DIA,     COUNT(DM.DELIVERY_NO) AS DO_QTY,     SUM(DM.NET_VALUE) AS NET_VALUE   FROM DATA_BASE AS DM   LEFT JOIN OW_SEDA_S_LOGISTIC.ST_CALENDARIO AS CAL     ON TO_DATE((DM.IOD_DATE_TIME)::VARCHAR, \'YYYY-MM-DD\') = CAL.DIA   GROUP BY     DM.RECEIVED_DATE,     DM.DIVISION,     DM.CATEGORY,     LPAD(CAST(DM.IOD_DATE_TIME AS VARCHAR), 2, \'0\'),     MONTH(DM.IOD_DATE_TIME),     LPAD(EXTRACT(DAY FROM DM.IOD_DATE_TIME), 2, \'0\'),     TO_CHAR(DM.IOD_DATE_TIME, \'Day\'),     CASE       WHEN NOT CAL.DESC_FERIADO IS NULL       THEN \'FERIADO\'       WHEN TO_CHAR(DM.IOD_DATE_TIME, \'Day\') = \'SATURDAY\'       THEN \'SABADO\'       WHEN TO_CHAR(DM.IOD_DATE_TIME, \'Day\') = \'SUNDAY\'       THEN \'DOMNGO\'       ELSE \'DIA DE SEMANA\'     END ) SELECT   CURRENT_DATE() AS RECEIVED_DATE,   DB1.DIVISION,   DB1.CATEGORY,   H.HORA,   COALESCE(DB1.MONTH, MONTH(CURRENT_DATE())) AS MONTH,   COALESCE(DB1.MONTH_DAY, LPAD(EXTRACT(DAY FROM CURRENT_DATE()), 2, \'0\')) AS MONTH_DAY,   COALESCE(DB1.WEEK_DAY_NAME, TO_CHAR(CURRENT_DATE(), \'Day\')) AS WEEK_DAY_NAME,   COALESCE(DB1.TIPO_DIA, \'DIA DE SEMANA\') AS TIPO_DIA,   COALESCE(DB1.DO_QTY, 0) AS DO_QTY,   COALESCE(APH.AVG_DO_QTY, 0) AS DO_QTY_EXPECTED,   COALESCE(DB1.DO_QTY, 0) - COALESCE(APH.AVG_DO_QTY, 0) AS GAP,   COALESCE(DB1.NET_VALUE, 0) AS NET_VALUE,   COALESCE(APH.AVG_NET_VALUE, 0) AS NET_VALUE_EXPECTED,   COALESCE(DB1.NET_VALUE, 0) - COALESCE(APH.AVG_NET_VALUE, 0) AS GAP_NET_VALUE FROM HORAS_DO_DIA AS H LEFT JOIN DB1   ON H.HORA = DB1.HORA LEFT JOIN OW_SEDA_S_LOGISTIC.VW_AVG_IOD_PER_HOUR AS APH   ON DB1.DIVISION || DB1.CATEGORY || H.HORA = APH.DIVISION || APH.CATEGORY || APH.HORA   AND COALESCE(DB1.MONTH_DAY, LPAD(EXTRACT(DAY FROM CURRENT_DATE()), 2, \'0\')) = APH.MONTH_DAY   AND COALESCE(DB1.TIPO_DIA, \'DIA DE SEMANA\') = APH.TIPO_DIA WHERE   CAST(H.HORA AS INT) <= EXTRACT(HOUR FROM CURRENT_TIMESTAMP) ORDER BY   H.HORA'

CREATE VIEW "OW_SEDA_S_LOGISTIC"."VW_ALERTA_IOD_PER_HOUR" (
  "RECEIVED_DATE",
  "DIVISION",
  "CATEGORY",
  "HORA",
  "MONTH",
  "MONTH_DAY",
  "WEEK_DAY_NAME",
  "TIPO_DIA",
  "DO_QTY",
  "DO_QTY_EXPECTED",
  "GAP",
  "NET_VALUE",
  "NET_VALUE_EXPECTED",
  "GAP_NET_VALUE"
) AS
WITH "HORAS_DO_DIA" AS (
  (
    (
      (
        (
          (
            (
              (
                (
                  (
                    (
                      (
                        (
                          (
                            (
                              (
                                (
                                  (
                                    (
                                      (
                                        (
                                          (
                                            (
                                              (
                                                (
                                                  SELECT
                                                    '00' AS HORA
                                                  FROM dual
                                                )
                                                UNION ALL
                                                (
                                                  SELECT
                                                    '01'
                                                  FROM dual
                                                )
                                              )
                                              UNION ALL
                                              (
                                                SELECT
                                                  '02'
                                                FROM dual
                                              )
                                            )
                                            UNION ALL
                                            (
                                              SELECT
                                                '03'
                                              FROM dual
                                            )
                                          )
                                          UNION ALL
                                          (
                                            SELECT
                                              '04'
                                            FROM dual
                                          )
                                        )
                                        UNION ALL
                                        (
                                          SELECT
                                            '05'
                                          FROM dual
                                        )
                                      )
                                      UNION ALL
                                      (
                                        SELECT
                                          '06'
                                        FROM dual
                                      )
                                    )
                                    UNION ALL
                                    (
                                      SELECT
                                        '07'
                                      FROM dual
                                    )
                                  )
                                  UNION ALL
                                  (
                                    SELECT
                                      '08'
                                    FROM dual
                                  )
                                )
                                UNION ALL
                                (
                                  SELECT
                                    '09'
                                  FROM dual
                                )
                              )
                              UNION ALL
                              (
                                SELECT
                                  '10'
                                FROM dual
                              )
                            )
                            UNION ALL
                            (
                              SELECT
                                '11'
                              FROM dual
                            )
                          )
                          UNION ALL
                          (
                            SELECT
                              '12'
                            FROM dual
                          )
                        )
                        UNION ALL
                        (
                          SELECT
                            '13'
                          FROM dual
                        )
                      )
                      UNION ALL
                      (
                        SELECT
                          '14'
                        FROM dual
                      )
                    )
                    UNION ALL
                    (
                      SELECT
                        '15'
                      FROM dual
                    )
                  )
                  UNION ALL
                  (
                    SELECT
                      '16'
                    FROM dual
                  )
                )
                UNION ALL
                (
                  SELECT
                    '17'
                  FROM dual
                )
              )
              UNION ALL
              (
                SELECT
                  '18'
                FROM dual
              )
            )
            UNION ALL
            (
              SELECT
                '19'
              FROM dual
            )
          )
          UNION ALL
          (
            SELECT
              '20'
            FROM dual
          )
        )
        UNION ALL
        (
          SELECT
            '21'
          FROM dual
        )
      )
      UNION ALL
      (
        SELECT
          '22'
        FROM dual
      )
    )
    UNION ALL
    (
      SELECT
        '23'
      FROM dual
    )
  )
), "DB1" AS (
  WITH "DATA_BASE" AS (
    SELECT
      TO_DATE((CT1.RECEIVED_DATE)::VARCHAR, 'YYYY-MM-DD') AS RECEIVED_DATE,
      CD.DELIVERY_NO,
      CASE
        WHEN CD.ORDER_TYPE LIKE '%IM%'
        THEN 'MX'
        WHEN CD.ORDER_TYPE LIKE '%MAO%'
        THEN 'MX'
        ELSE 'CE'
      END AS DIVISION,
      CAT.CATEGORY,
      SUM(NP.NET_VALUE) AS NET_VALUE,
      (CT1.RECEIVED_DATE)::TIMESTAMP AS IOD_DATE_TIME
    FROM OW_SEDA_S.CELLO_DELIVERY AS CD
    LEFT JOIN (
      SELECT
        DELIVERY_NO,
        TRK_DATE,
        RECEIVED_DATE
      FROM OW_SEDA_S.CELLO_TRACKING AS CT1
      WHERE
        TRK_CODE = 'TR4010-10'
    ) AS CT1
      ON CD.DELIVERY_NO = CT1.DELIVERY_NO
    LEFT JOIN OW_SEDA_S.ODS_NERP_ZLLEJ50090_OUTBOUND_TRACKING_SCM AS NP
      ON CD.DELIVERY_NO = NP.DELIVERY_NO
    LEFT JOIN (
      SELECT
        DELIVERY_NO,
        CATEGORY,
        ROW_NUMBER() OVER (PARTITION BY DELIVERY_NO ORDER BY C_WEIGHT DESC) AS RN
      FROM OW_SEDA_S_LOGISTIC.ST_D2C_LOGCOST_HIGHEST_CWGT_CATEGORY AS CAT
    ) AS CAT
      ON CD.DELIVERY_NO = CAT.DELIVERY_NO AND RN = 1
    WHERE
      TO_DATE((CT1.RECEIVED_DATE)::VARCHAR, 'YYYY-MM-DD') = CURRENT_DATE()
      AND CD.SOLDTO_NM LIKE '%SEDA%'
    GROUP BY
      TO_DATE((CT1.RECEIVED_DATE)::VARCHAR, 'YYYY-MM-DD'),
      CD.DELIVERY_NO,
      CASE
        WHEN CD.ORDER_TYPE LIKE '%IM%'
        THEN 'MX'
        WHEN CD.ORDER_TYPE LIKE '%MAO%'
        THEN 'MX'
        ELSE 'CE'
      END,
      CAT.CATEGORY,
      (CT1.RECEIVED_DATE)::TIMESTAMP
  )
  SELECT
    DM.RECEIVED_DATE,
    DM.DIVISION,
    DM.CATEGORY,
    LPAD(CAST(DM.IOD_DATE_TIME AS VARCHAR), 2, '0') AS HORA,
    MONTH(DM.IOD_DATE_TIME) AS MONTH,
    LPAD(EXTRACT(DAY FROM DM.IOD_DATE_TIME), 2, '0') AS MONTH_DAY,
    TO_CHAR(DM.IOD_DATE_TIME, 'Day') AS WEEK_DAY_NAME,
    CASE
      WHEN NOT CAL.DESC_FERIADO IS NULL
      THEN 'FERIADO'
      WHEN TO_CHAR(DM.IOD_DATE_TIME, 'Day') = 'SATURDAY'
      THEN 'SABADO'
      WHEN TO_CHAR(DM.IOD_DATE_TIME, 'Day') = 'SUNDAY'
      THEN 'DOMNGO'
      ELSE 'DIA DE SEMANA'
    END AS TIPO_DIA,
    COUNT(DM.DELIVERY_NO) AS DO_QTY,
    SUM(DM.NET_VALUE) AS NET_VALUE
  FROM DATA_BASE AS DM
  LEFT JOIN OW_SEDA_S_LOGISTIC.ST_CALENDARIO AS CAL
    ON TO_DATE((DM.IOD_DATE_TIME)::VARCHAR, 'YYYY-MM-DD') = CAL.DIA
  GROUP BY
    DM.RECEIVED_DATE,
    DM.DIVISION,
    DM.CATEGORY,
    LPAD(CAST(DM.IOD_DATE_TIME AS VARCHAR), 2, '0'),
    MONTH(DM.IOD_DATE_TIME),
    LPAD(EXTRACT(DAY FROM DM.IOD_DATE_TIME), 2, '0'),
    TO_CHAR(DM.IOD_DATE_TIME, 'Day'),
    CASE
      WHEN NOT CAL.DESC_FERIADO IS NULL
      THEN 'FERIADO'
      WHEN TO_CHAR(DM.IOD_DATE_TIME, 'Day') = 'SATURDAY'
      THEN 'SABADO'
      WHEN TO_CHAR(DM.IOD_DATE_TIME, 'Day') = 'SUNDAY'
      THEN 'DOMNGO'
      ELSE 'DIA DE SEMANA'
    END
)
SELECT
  CURRENT_DATE() AS RECEIVED_DATE,
  DB1.DIVISION,
  DB1.CATEGORY,
  H.HORA,
  COALESCE(DB1.MONTH, MONTH(CURRENT_DATE())) AS MONTH,
  COALESCE(DB1.MONTH_DAY, LPAD(EXTRACT(DAY FROM CURRENT_DATE()), 2, '0')) AS MONTH_DAY,
  COALESCE(DB1.WEEK_DAY_NAME, TO_CHAR(CURRENT_DATE(), 'Day')) AS WEEK_DAY_NAME,
  COALESCE(DB1.TIPO_DIA, 'DIA DE SEMANA') AS TIPO_DIA,
  COALESCE(DB1.DO_QTY, 0) AS DO_QTY,
  COALESCE(APH.AVG_DO_QTY, 0) AS DO_QTY_EXPECTED,
  COALESCE(DB1.DO_QTY, 0) - COALESCE(APH.AVG_DO_QTY, 0) AS GAP,
  COALESCE(DB1.NET_VALUE, 0) AS NET_VALUE,
  COALESCE(APH.AVG_NET_VALUE, 0) AS NET_VALUE_EXPECTED,
  COALESCE(DB1.NET_VALUE, 0) - COALESCE(APH.AVG_NET_VALUE, 0) AS GAP_NET_VALUE
FROM HORAS_DO_DIA AS H
LEFT JOIN DB1
  ON H.HORA = DB1.HORA
LEFT JOIN OW_SEDA_S_LOGISTIC.VW_AVG_IOD_PER_HOUR AS APH
  ON DB1.DIVISION || DB1.CATEGORY || H.HORA = APH.DIVISION || APH.CATEGORY || APH.HORA
  AND COALESCE(DB1.MONTH_DAY, LPAD(EXTRACT(DAY FROM CURRENT_DATE()), 2, '0')) = APH.MONTH_DAY
  AND COALESCE(DB1.TIPO_DIA, 'DIA DE SEMANA') = APH.TIPO_DIA
WHERE
  CAST(H.HORA AS INT) <= EXTRACT(HOUR FROM CURRENT_TIMESTAMP)
ORDER BY
  H.HORA