-- MISSING RELATION: OW_SEDA_S_LOGISTIC.ST_D2C_MASTER_ML
-- ERROR: Error executing query: Severity: ERROR, Message: Relation "OW_SEDA_S_LOGISTIC.ST_D2C_MASTER_ML" does not exist, Sqlstate: 42V01, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Miner/server/vertica/Catalog/CatalogLookup.cpp, Line: 4362, Error Code: 4568, SQL: 'CREATE OR REPLACE VIEW "OW_SEDA_S_LOGISTIC"."VW_D2C_CATEGORY_TRANSIT_ML" (   "ROWNUM",   "DELIVERY_NO",   "MATERIAL",   "MTL_GROUP",   "DIVISION",   "DIVISION_CODE",   "DIVISION_GROUP",   "CATEGORY",   "FCST_CATEGORY",   "C_WEIGHT" ) AS WITH "DB1" AS (   SELECT DISTINCT     NP.DELIVERY_NO,     NP.MATERIAL,     NP.MTL_GROUP,     CASE       WHEN CD.ORDER_TYPE LIKE \'%IM%\'       THEN \'MX\'       WHEN CD.ORDER_TYPE LIKE \'%MAO%\'       THEN \'MX\'       ELSE \'CE\'     END AS DIVISION,     NP.MTL_DIVISION AS DIVISION_CODE,     CASE       WHEN NP.MTL_GROUP IN (\'AAH0A\', \'AAJ0D\', \'AAJ0E\', \'AAJ0F\', \'AAJ1A\', \'AAL0A\', \'AAV0A\', \'AAVAA\', \'AAVCA\')       THEN \'A/C\'       WHEN NP.MTL_GROUP IN (         \'KRA0A\',         \'KRC0A\',         \'EBAAA\',         \'EBABA\',         \'EBE1A\',         \'EBE2A\',         \'EBE4A\',         \'EBE6A\',         \'EBF4A\',         \'EBH1A\',         \'EBH2A\',         \'EBK0A\',         \'EBO2A\',         \'EBO3A\',         \'EBO4A\',         \'EBOAA\',         \'PDB0A\',         \'PDB7A\',         \'44AA\',         \'81AB\',         \'81AR\',         \'81DZ\',         \'82AA\',         \'82AE\',         \'82AG\',         \'82AK\',         \'82AN\',         \'82AS\',         \'NN96DN\',         \'NN96NA\',         \'NN98BH\',         \'NN98BT\',         \'59DG\',         \'NN96NM\',         \'HH98CU\',         \'NN97MA\',         \'02BM\',         \'DDC0A\',         \'DDCAA\',         \'DDCAL\'       )       THEN \'MX\'       WHEN NP.MTL_GROUP IN (         \'BCN2A\',         \'BCT0A\',         \'BCT1A\',         \'BCTAA\',         \'CAAAA\',         \'CABAA\',         \'CABCA\',         \'CACAA\',         \'CAJ0A\',         \'CAJ1A\',         \'CAR0A\',         \'CAV0A\',         \'CAW0A\',         \'CAX0A\',         \'PJS0A\',         \'PJSAA\',         \'PJT0A\',         \'PJT5A\',         \'PJS9A\',         \'BCTBA\'       )       THEN \'VD\'       WHEN NP.MTL_GROUP IN (         \'ACG1A\',         \'ACH0A\',         \'ACHAA\',         \'ACHBA\',         \'ACO0A\',         \'ABG0A\',         \'ABG1A\',         \'ABGAA\',         \'AEP0A\',         \'AEPBA\',         \'AEX0A\',         \'AEX1A\',         \'AEE1A\',         \'AEH0A\',         \'AEHAA\',         \'AER0A\'       )       THEN \'WG\'       ELSE NULL     END AS DIVISION_GROUP,     CASE       WHEN NP.MTL_GROUP IN (\'AAH0A\', \'AAJ0D\', \'AAJ0E\', \'AAJ0F\', \'AAJ1A\', \'AAL0A\', \'AAV0A\', \'AAVAA\', \'AAVCA\')       THEN \'A/C\'       WHEN NP.MTL_GROUP IN (\'BCN2A\', \'BCT0A\', \'BCT1A\', \'BCTAA\', \'BCTBA\')       THEN \'AUD\'       WHEN NP.MTL_GROUP IN (         \'CAAAA\',         \'CABAA\',         \'CABCA\',         \'CACAA\',         \'CAJ0A\',         \'CAJ1A\',         \'CAR0A\',         \'CAV0A\',         \'CAW0A\',         \'CAX0A\'       )       THEN \'CTV\'       WHEN NP.MTL_GROUP IN (\'KRA0A\', \'KRC0A\')       THEN \'MEMORY\'       WHEN NP.MTL_GROUP IN (         \'EBAAA\',         \'EBABA\',         \'EBE1A\',         \'EBE2A\',         \'EBE4A\',         \'EBE6A\',         \'EBF4A\',         \'EBH1A\',         \'EBH2A\',         \'EBK0A\',         \'EBO2A\',         \'EBO3A\',         \'EBO4A\',         \'EBOAA\'       )       THEN \'MOBILE\'       WHEN NP.MTL_GROUP IN (\'PJS0A\', \'PJSAA\', \'PJT0A\', \'PJT5A\', \'PJS9A\')       THEN \'MON\'       WHEN NP.MTL_GROUP IN (\'ACG1A\', \'ACH0A\', \'ACHAA\', \'ACHBA\', \'ACO0A\')       THEN \'MWO\'       WHEN NP.MTL_GROUP IN (\'PDB0A\', \'PDB7A\')       THEN \'NPC\'       WHEN NP.MTL_GROUP IN (\'ABG0A\', \'ABG1A\', \'ABGAA\')       THEN \'REF\'       WHEN NP.MTL_GROUP IN (         \'44AA\',         \'81AB\',         \'81AR\',         \'81DZ\',         \'82AA\',         \'82AE\',         \'82AG\',         \'82AK\',         \'82AN\',         \'82AS\',         \'NN96DN\',         \'NN96NA\',         \'NN98BH\',         \'NN98BT\',         \'NN96NM\',         \'NN97MA\',         \'02BM\'       )       THEN \'REPAIR KIT\'       WHEN NP.MTL_GROUP IN (\'AEP0A\', \'AEPBA\', \'AEX0A\', \'AEX1A\')       THEN \'VC\'       WHEN NP.MTL_GROUP IN (\'AEE1A\', \'AEH0A\', \'AEHAA\', \'AER0A\')       THEN \'WM\'       WHEN NP.MTL_GROUP IN (\'59DG\', \'HH98CU\')       THEN \'ZC\'       WHEN NP.MTL_GROUP IN (\'DDC0A\', \'DDCAA\', \'DDCAL\')       THEN \'US\'       ELSE NULL     END AS CATEGORY,     CASE       WHEN NP.MTL_DIVISION = \'E1\' AND MATERIAL LIKE \'AR%\'       THEN \'A/C_RAC\'       WHEN NP.MTL_DIVISION = \'E1\' AND NOT MATERIAL LIKE \'AR%\'       THEN \'A/C_SAC\'       WHEN NP.MTL_DIVISION = \'A6\'       THEN \'AV\'       WHEN NP.MTL_DIVISION = \'A1\'       THEN \'TV\'       WHEN NP.MTL_DIVISION = \'C1\'       THEN \'MONITOR\'       WHEN NP.MTL_DIVISION = \'E5\'       THEN \'COOKING\'       WHEN NP.MTL_DIVISION = \'E2\'       THEN \'REF\'       WHEN NP.MTL_DIVISION = \'E4\'       THEN \'VC\'       WHEN NP.MTL_DIVISION = \'E3\' AND MATERIAL LIKE \'DW%\'       THEN \'DW\'       WHEN NP.MTL_DIVISION = \'E3\' AND NOT MATERIAL LIKE \'DW%\'       THEN \'LAUNDRY\'       WHEN NP.MTL_DIVISION IN (\'G1\', \'H1\', \'ZC\', \'ZQ\')       AND NOT NP.MTL_GROUP IN (\'EBH1A\', \'EBH2A\', \'EBO3A\', \'EBE2A\', \'EBE4A\', \'EBO4A\')       THEN \'MOBILE\'       WHEN NP.MTL_DIVISION = \'G1\' AND NP.MTL_GROUP IN (\'EBH1A\', \'EBH2A\', \'EBO3A\')       THEN \'TABLET\'       WHEN NP.MTL_DIVISION = \'G1\' AND NP.MTL_GROUP IN (\'EBE2A\', \'EBE4A\', \'EBO4A\')       THEN \'WRB\'       WHEN NP.MTL_DIVISION = \'C3\'       THEN \'NPC\'       WHEN NP.MTL_DIVISION = \'K2\'       THEN \'ULTRASOUND\'       ELSE NULL     END AS FCST_CATEGORY,     CASE       WHEN CASE         WHEN CD.ORDER_TYPE LIKE \'%IM%\'         THEN \'MX\'         WHEN CD.ORDER_TYPE LIKE \'%MAO%\'         THEN \'MX\'         ELSE \'CE\'       END = \'CE\'       AND CDI.ITEM_TOTAL_VOLUME * 300 > NP.WEIGHT       THEN CDI.ITEM_TOTAL_VOLUME * 300       ELSE NP.WEIGHT     END AS C_WEIGHT,     CD.TRACKING_STATUS_CLASSIF   FROM OW_SEDA_S.ODS_NERP_ZLLEJ50090_OUTBOUND_TRACKING_SCM AS NP   LEFT JOIN (     SELECT       DELIVERY_NO,       ORDER_TYPE,       SOLDTO_NM,       TRACKING_STATUS_CLASSIF     FROM OW_SEDA_S_LOGISTIC.ST_D2C_MASTER_ML AS CD   ) AS CD     ON NP.DELIVERY_NO = CD.DELIVERY_NO   LEFT JOIN (     SELECT       DELIVERY_NO,       ITEM_TOTAL_VOLUME,       ITEM_CD     FROM OW_SEDA_S.CELLO_DELIVERY_ITEM AS CDI   ) AS CDI     ON NP.DELIVERY_NO = CDI.DELIVERY_NO AND NP.MATERIAL = CDI.ITEM_CD   WHERE     CD.SOLDTO_NM LIKE \'%SEDA%\' AND CD.TRACKING_STATUS_CLASSIF = \'Transit\' ) SELECT   ROW_NUMBER() OVER (PARTITION BY DELIVERY_NO) AS ROWNUM,   "DB1"."DELIVERY_NO",   "DB1"."MATERIAL",   "DB1"."MTL_GROUP",   "DB1"."DIVISION",   "DB1"."DIVISION_CODE",   "DB1"."DIVISION_GROUP",   "DB1"."CATEGORY",   "DB1"."FCST_CATEGORY",   "DB1"."C_WEIGHT" FROM DB1 ORDER BY   "DB1"."DELIVERY_NO",   "DB1"."C_WEIGHT" DESC'

CREATE VIEW "OW_SEDA_S_LOGISTIC"."VW_D2C_CATEGORY_TRANSIT_ML" (
  "ROWNUM",
  "DELIVERY_NO",
  "MATERIAL",
  "MTL_GROUP",
  "DIVISION",
  "DIVISION_CODE",
  "DIVISION_GROUP",
  "CATEGORY",
  "FCST_CATEGORY",
  "C_WEIGHT"
) AS
WITH "DB1" AS (
  SELECT DISTINCT
    NP.DELIVERY_NO,
    NP.MATERIAL,
    NP.MTL_GROUP,
    CASE
      WHEN CD.ORDER_TYPE LIKE '%IM%'
      THEN 'MX'
      WHEN CD.ORDER_TYPE LIKE '%MAO%'
      THEN 'MX'
      ELSE 'CE'
    END AS DIVISION,
    NP.MTL_DIVISION AS DIVISION_CODE,
    CASE
      WHEN NP.MTL_GROUP IN ('AAH0A', 'AAJ0D', 'AAJ0E', 'AAJ0F', 'AAJ1A', 'AAL0A', 'AAV0A', 'AAVAA', 'AAVCA')
      THEN 'A/C'
      WHEN NP.MTL_GROUP IN (
        'KRA0A',
        'KRC0A',
        'EBAAA',
        'EBABA',
        'EBE1A',
        'EBE2A',
        'EBE4A',
        'EBE6A',
        'EBF4A',
        'EBH1A',
        'EBH2A',
        'EBK0A',
        'EBO2A',
        'EBO3A',
        'EBO4A',
        'EBOAA',
        'PDB0A',
        'PDB7A',
        '44AA',
        '81AB',
        '81AR',
        '81DZ',
        '82AA',
        '82AE',
        '82AG',
        '82AK',
        '82AN',
        '82AS',
        'NN96DN',
        'NN96NA',
        'NN98BH',
        'NN98BT',
        '59DG',
        'NN96NM',
        'HH98CU',
        'NN97MA',
        '02BM',
        'DDC0A',
        'DDCAA',
        'DDCAL'
      )
      THEN 'MX'
      WHEN NP.MTL_GROUP IN (
        'BCN2A',
        'BCT0A',
        'BCT1A',
        'BCTAA',
        'CAAAA',
        'CABAA',
        'CABCA',
        'CACAA',
        'CAJ0A',
        'CAJ1A',
        'CAR0A',
        'CAV0A',
        'CAW0A',
        'CAX0A',
        'PJS0A',
        'PJSAA',
        'PJT0A',
        'PJT5A',
        'PJS9A',
        'BCTBA'
      )
      THEN 'VD'
      WHEN NP.MTL_GROUP IN (
        'ACG1A',
        'ACH0A',
        'ACHAA',
        'ACHBA',
        'ACO0A',
        'ABG0A',
        'ABG1A',
        'ABGAA',
        'AEP0A',
        'AEPBA',
        'AEX0A',
        'AEX1A',
        'AEE1A',
        'AEH0A',
        'AEHAA',
        'AER0A'
      )
      THEN 'WG'
      ELSE NULL
    END AS DIVISION_GROUP,
    CASE
      WHEN NP.MTL_GROUP IN ('AAH0A', 'AAJ0D', 'AAJ0E', 'AAJ0F', 'AAJ1A', 'AAL0A', 'AAV0A', 'AAVAA', 'AAVCA')
      THEN 'A/C'
      WHEN NP.MTL_GROUP IN ('BCN2A', 'BCT0A', 'BCT1A', 'BCTAA', 'BCTBA')
      THEN 'AUD'
      WHEN NP.MTL_GROUP IN (
        'CAAAA',
        'CABAA',
        'CABCA',
        'CACAA',
        'CAJ0A',
        'CAJ1A',
        'CAR0A',
        'CAV0A',
        'CAW0A',
        'CAX0A'
      )
      THEN 'CTV'
      WHEN NP.MTL_GROUP IN ('KRA0A', 'KRC0A')
      THEN 'MEMORY'
      WHEN NP.MTL_GROUP IN (
        'EBAAA',
        'EBABA',
        'EBE1A',
        'EBE2A',
        'EBE4A',
        'EBE6A',
        'EBF4A',
        'EBH1A',
        'EBH2A',
        'EBK0A',
        'EBO2A',
        'EBO3A',
        'EBO4A',
        'EBOAA'
      )
      THEN 'MOBILE'
      WHEN NP.MTL_GROUP IN ('PJS0A', 'PJSAA', 'PJT0A', 'PJT5A', 'PJS9A')
      THEN 'MON'
      WHEN NP.MTL_GROUP IN ('ACG1A', 'ACH0A', 'ACHAA', 'ACHBA', 'ACO0A')
      THEN 'MWO'
      WHEN NP.MTL_GROUP IN ('PDB0A', 'PDB7A')
      THEN 'NPC'
      WHEN NP.MTL_GROUP IN ('ABG0A', 'ABG1A', 'ABGAA')
      THEN 'REF'
      WHEN NP.MTL_GROUP IN (
        '44AA',
        '81AB',
        '81AR',
        '81DZ',
        '82AA',
        '82AE',
        '82AG',
        '82AK',
        '82AN',
        '82AS',
        'NN96DN',
        'NN96NA',
        'NN98BH',
        'NN98BT',
        'NN96NM',
        'NN97MA',
        '02BM'
      )
      THEN 'REPAIR KIT'
      WHEN NP.MTL_GROUP IN ('AEP0A', 'AEPBA', 'AEX0A', 'AEX1A')
      THEN 'VC'
      WHEN NP.MTL_GROUP IN ('AEE1A', 'AEH0A', 'AEHAA', 'AER0A')
      THEN 'WM'
      WHEN NP.MTL_GROUP IN ('59DG', 'HH98CU')
      THEN 'ZC'
      WHEN NP.MTL_GROUP IN ('DDC0A', 'DDCAA', 'DDCAL')
      THEN 'US'
      ELSE NULL
    END AS CATEGORY,
    CASE
      WHEN NP.MTL_DIVISION = 'E1' AND MATERIAL LIKE 'AR%'
      THEN 'A/C_RAC'
      WHEN NP.MTL_DIVISION = 'E1' AND NOT MATERIAL LIKE 'AR%'
      THEN 'A/C_SAC'
      WHEN NP.MTL_DIVISION = 'A6'
      THEN 'AV'
      WHEN NP.MTL_DIVISION = 'A1'
      THEN 'TV'
      WHEN NP.MTL_DIVISION = 'C1'
      THEN 'MONITOR'
      WHEN NP.MTL_DIVISION = 'E5'
      THEN 'COOKING'
      WHEN NP.MTL_DIVISION = 'E2'
      THEN 'REF'
      WHEN NP.MTL_DIVISION = 'E4'
      THEN 'VC'
      WHEN NP.MTL_DIVISION = 'E3' AND MATERIAL LIKE 'DW%'
      THEN 'DW'
      WHEN NP.MTL_DIVISION = 'E3' AND NOT MATERIAL LIKE 'DW%'
      THEN 'LAUNDRY'
      WHEN NP.MTL_DIVISION IN ('G1', 'H1', 'ZC', 'ZQ')
      AND NOT NP.MTL_GROUP IN ('EBH1A', 'EBH2A', 'EBO3A', 'EBE2A', 'EBE4A', 'EBO4A')
      THEN 'MOBILE'
      WHEN NP.MTL_DIVISION = 'G1' AND NP.MTL_GROUP IN ('EBH1A', 'EBH2A', 'EBO3A')
      THEN 'TABLET'
      WHEN NP.MTL_DIVISION = 'G1' AND NP.MTL_GROUP IN ('EBE2A', 'EBE4A', 'EBO4A')
      THEN 'WRB'
      WHEN NP.MTL_DIVISION = 'C3'
      THEN 'NPC'
      WHEN NP.MTL_DIVISION = 'K2'
      THEN 'ULTRASOUND'
      ELSE NULL
    END AS FCST_CATEGORY,
    CASE
      WHEN CASE
        WHEN CD.ORDER_TYPE LIKE '%IM%'
        THEN 'MX'
        WHEN CD.ORDER_TYPE LIKE '%MAO%'
        THEN 'MX'
        ELSE 'CE'
      END = 'CE'
      AND CDI.ITEM_TOTAL_VOLUME * 300 > NP.WEIGHT
      THEN CDI.ITEM_TOTAL_VOLUME * 300
      ELSE NP.WEIGHT
    END AS C_WEIGHT,
    CD.TRACKING_STATUS_CLASSIF
  FROM OW_SEDA_S.ODS_NERP_ZLLEJ50090_OUTBOUND_TRACKING_SCM AS NP
  LEFT JOIN (
    SELECT
      DELIVERY_NO,
      ORDER_TYPE,
      SOLDTO_NM,
      TRACKING_STATUS_CLASSIF
    FROM OW_SEDA_S_LOGISTIC.ST_D2C_MASTER_ML AS CD
  ) AS CD
    ON NP.DELIVERY_NO = CD.DELIVERY_NO
  LEFT JOIN (
    SELECT
      DELIVERY_NO,
      ITEM_TOTAL_VOLUME,
      ITEM_CD
    FROM OW_SEDA_S.CELLO_DELIVERY_ITEM AS CDI
  ) AS CDI
    ON NP.DELIVERY_NO = CDI.DELIVERY_NO AND NP.MATERIAL = CDI.ITEM_CD
  WHERE
    CD.SOLDTO_NM LIKE '%SEDA%' AND CD.TRACKING_STATUS_CLASSIF = 'Transit'
)
SELECT
  ROW_NUMBER() OVER (PARTITION BY DELIVERY_NO) AS ROWNUM,
  "DB1"."DELIVERY_NO",
  "DB1"."MATERIAL",
  "DB1"."MTL_GROUP",
  "DB1"."DIVISION",
  "DB1"."DIVISION_CODE",
  "DB1"."DIVISION_GROUP",
  "DB1"."CATEGORY",
  "DB1"."FCST_CATEGORY",
  "DB1"."C_WEIGHT"
FROM DB1
ORDER BY
  "DB1"."DELIVERY_NO",
  "DB1"."C_WEIGHT" DESC