-- MISSING RELATION: _SYS_BIC
-- ERROR: Error executing query: Severity: ERROR, Message: Schema "_SYS_BIC" does not exist, Sqlstate: 3F000, Routine: RangeVarGetObjid, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Miner/server/vertica/Catalog/NamespaceLookup.cpp, Line: 317, Error Code: 4650, SQL: 'CREATE OR REPLACE VIEW "OW_LAO"."VIEW_ECOM_PRODUCT_VTEX" (   "Order_Id",   "Reference_Code",   "Units" ) AS (   (     SELECT       "Order_Id",       "Reference_Code",       "Units"     FROM "_SYS_BIC"."SDSLA_ECOM/CV_ECOM_ORDERS_CUSTOMERS_PRODUCTS_SYNAPCOM" AS O     WHERE       "Creation_Date" >= \'2023-07-01\'   )   UNION ALL   (     SELECT       "Order_Id",       "Reference_Code",       "Units"     FROM "_SYS_BIC"."SDSLA_ECOM/CV_ECOM_ORDERS_CUSTOMERS_PRODUCTS_O2O" AS O     WHERE       "Creation_Date" >= \'2023-07-01\'   ) )'

CREATE VIEW "OW_LAO"."VIEW_ECOM_PRODUCT_VTEX" (
  "Order_Id",
  "Reference_Code",
  "Units"
) AS
(
  (
    SELECT
      "Order_Id",
      "Reference_Code",
      "Units"
    FROM "_SYS_BIC"."SDSLA_ECOM/CV_ECOM_ORDERS_CUSTOMERS_PRODUCTS_SYNAPCOM" AS O
    WHERE
      "Creation_Date" >= '2023-07-01'
  )
  UNION ALL
  (
    SELECT
      "Order_Id",
      "Reference_Code",
      "Units"
    FROM "_SYS_BIC"."SDSLA_ECOM/CV_ECOM_ORDERS_CUSTOMERS_PRODUCTS_O2O" AS O
    WHERE
      "Creation_Date" >= '2023-07-01'
  )
)