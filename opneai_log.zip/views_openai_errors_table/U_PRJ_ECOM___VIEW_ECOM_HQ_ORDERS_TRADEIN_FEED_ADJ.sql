-- MISSING RELATION: _SYS_BIC
-- ERROR: Error executing query: Severity: ERROR, Message: Schema "_SYS_BIC" does not exist, Sqlstate: 3F000, Routine: RangeVarGetObjid, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Miner/server/vertica/Catalog/NamespaceLookup.cpp, Line: 317, Error Code: 4650, SQL: 'CREATE OR REPLACE VIEW "U_PRJ_ECOM"."VIEW_ECOM_HQ_ORDERS_TRADEIN_FEED_ADJ" (   "country_cd",   "order_id",   "line_item_id",   "discount_amount",   "exchange_brand",   "exchange_category",   "exchange_device_name",   "exchange_grade",   "exchange_id",   "exchange_type",   "is_accessory",   "is_financed_order",   "is_financing",   "is_financing_eligible",   "is_samsung_care_order",   "is_traded_in",   "is_under_extended_warranty",   "order_date",   "order_time_utc",   "po_id",   "po_status",   "sku",   "tradein_ext_memory",   "tradein_ext_product_family_name",   "tradein_ext_product_identifier",   "upgrade_id",   "upgrade_loan_number",   "upgrade_root_order_date",   "upgrade_status",   "ex_est_exch_discount_amount",   "ex_est_exch_value_amount",   "ex_est_total_amount",   "ex_identity_id",   "ex_sku",   "ex_status",   "is_upgrade",   "is_tariff_order" ) AS (   (     SELECT DISTINCT       a."Country" AS "country_cd",       a."Order_Id" AS "order_id",       a."Reference_Code" AS "line_item_id",       b.TRADE_IN_DISCOUNT AS "discount_amount",       b.BRAND AS "exchange_brand",       b.CATEGORY_NAME AS "exchange_category",       b.MODEL AS "exchange_device_name",       \'\' AS "exchange_grade",       \'\' AS "exchange_id",       \'\' AS "exchange_type",       \'\' AS "is_accessory",       \'\' AS "is_financed_order",       c."IS_FINANCED_ORDER" AS "is_financing",       \'\' AS "is_financing_eligible",       CASE WHEN a."IS_SAMSUNG_CARE" = 1 THEN \'TRUE\' ELSE \'FALSE\' END AS "is_samsung_care_order",       \'TRUE\' AS "is_traded_in",       \'\' AS "is_under_extended_warranty",       A."Creation_Date" AS "order_date",       CAST(A."Creation_Datetime" AS TIMESTAMP) AS "order_time_utc",       a."Order_Id" AS "po_id",       a."Status" AS "po_status",       a."Reference_Code" AS "sku",       \'\' AS "tradein_ext_memory",       \'\' AS "tradein_ext_product_family_name",       \'\' AS "tradein_ext_product_identifier",       \'\' AS "upgrade_id",       \'\' AS "upgrade_loan_number",       \'\' AS "upgrade_root_order_date",       \'\' AS "upgrade_status",       \'\' AS "ex_est_exch_discount_amount",       \'\' AS "ex_est_exch_value_amount",       \'\' AS "ex_est_total_amount",       \'\' AS "ex_identity_id",       \'\' AS "ex_sku",       \'\' AS "ex_status",       \'FALSE\' AS "is_upgrade",       \'FALSE\' AS "is_tariff_order"     FROM "_SYS_BIC"."SDSLA_ECOM/CV_ECOM_ORDERS_CUSTOMERS_PRODUCTS_SYNAPCOM_TRADE_IN" AS a     JOIN U_PRJ_ECOM.VIEW_ECOM_HQ_ORDERS_PRODUCTS_TRADEIN_TST_ADJ AS b       ON a."Order_Id" = b."Order_Id" AND a."Reference_Code" = b."Reference_Code"     JOIN "U_PRJ_ECOM"."VIEW_ECOM_HQ_ORDERS_PAYMENT_SYNAPCOM" AS c       ON a."ID" = c."ORDER_ID"     WHERE       a."Subsidiary_Id" = 6 AND CAST("Creation_Datetime" AS DATE) >= \'2022-12-20\'   )   UNION ALL   (     SELECT DISTINCT       a."Country" AS "country_cd",       a."Order_Id" AS "order_id",       a."Reference_Code" AS "line_item_id",       b."TRADE_IN_DISCOUNT_DEVICE" AS "discount_amount",       b."BRAND_DEVICE" AS "exchange_brand",       \'\' AS "exchange_category",       b.MODEL_DEVICE AS "exchange_device_name",       \'\' AS "exchange_grade",       \'\' AS "exchange_id",       \'\' AS "exchange_type",       \'\' AS "is_accessory",       \'\' AS "is_financed_order",       c."IS_FINANCED_ORDER" AS "is_financing",       \'\' AS "is_financing_eligible",       CASE WHEN a."IS_SAMSUNG_CARE" = 1 THEN \'TRUE\' ELSE \'FALSE\' END AS "is_samsung_care_order",       \'TRUE\' AS "is_traded_in",       \'\' AS "is_under_extended_warranty",       A."Creation_Date" AS "order_date",       CAST(A."Creation_Datetime" AS TIMESTAMP) AS "order_time_utc",       a."Order_Id" AS "po_id",       a."Status" AS "po_status",       a."Reference_Code" AS "sku",       \'\' AS "tradein_ext_memory",       \'\' AS "tradein_ext_product_family_name",       \'\' AS "tradein_ext_product_identifier",       \'\' AS "upgrade_id",       \'\' AS "upgrade_loan_number",       \'\' AS "upgrade_root_order_date",       \'\' AS "upgrade_status",       \'\' AS "ex_est_exch_discount_amount",       \'\' AS "ex_est_exch_value_amount",       \'\' AS "ex_est_total_amount",       \'\' AS "ex_identity_id",       \'\' AS "ex_sku",       \'\' AS "ex_status",       \'FALSE\' AS "is_upgrade",       \'FALSE\' AS "is_tariff_order"     FROM "_SYS_BIC"."SDSLA_ECOM/CV_ECOM_ORDERS_CUSTOMERS_PRODUCTS_TRADEIN" AS a     JOIN U_PRJ_ECOM.RAW_VTEX_SEASA_TRADEIN_FEED AS b       ON a."Order_Id" = b.ORDER_ID AND a.SKU_ID = b.SKUID     JOIN "U_PRJ_ECOM"."VIEW_ECOM_HQ_ORDERS_PAYMENT" AS c       ON a."ID" = c."ORDER_ID"     WHERE       a."Subsidiary_Id" = 1 AND CAST("Creation_Datetime" AS DATE) >= \'2022-04-13\'   ) )'

CREATE VIEW "U_PRJ_ECOM"."VIEW_ECOM_HQ_ORDERS_TRADEIN_FEED_ADJ" (
  "country_cd",
  "order_id",
  "line_item_id",
  "discount_amount",
  "exchange_brand",
  "exchange_category",
  "exchange_device_name",
  "exchange_grade",
  "exchange_id",
  "exchange_type",
  "is_accessory",
  "is_financed_order",
  "is_financing",
  "is_financing_eligible",
  "is_samsung_care_order",
  "is_traded_in",
  "is_under_extended_warranty",
  "order_date",
  "order_time_utc",
  "po_id",
  "po_status",
  "sku",
  "tradein_ext_memory",
  "tradein_ext_product_family_name",
  "tradein_ext_product_identifier",
  "upgrade_id",
  "upgrade_loan_number",
  "upgrade_root_order_date",
  "upgrade_status",
  "ex_est_exch_discount_amount",
  "ex_est_exch_value_amount",
  "ex_est_total_amount",
  "ex_identity_id",
  "ex_sku",
  "ex_status",
  "is_upgrade",
  "is_tariff_order"
) AS
(
  (
    SELECT DISTINCT
      a."Country" AS "country_cd",
      a."Order_Id" AS "order_id",
      a."Reference_Code" AS "line_item_id",
      b.TRADE_IN_DISCOUNT AS "discount_amount",
      b.BRAND AS "exchange_brand",
      b.CATEGORY_NAME AS "exchange_category",
      b.MODEL AS "exchange_device_name",
      '' AS "exchange_grade",
      '' AS "exchange_id",
      '' AS "exchange_type",
      '' AS "is_accessory",
      '' AS "is_financed_order",
      c."IS_FINANCED_ORDER" AS "is_financing",
      '' AS "is_financing_eligible",
      CASE WHEN a."IS_SAMSUNG_CARE" = 1 THEN 'TRUE' ELSE 'FALSE' END AS "is_samsung_care_order",
      'TRUE' AS "is_traded_in",
      '' AS "is_under_extended_warranty",
      A."Creation_Date" AS "order_date",
      CAST(A."Creation_Datetime" AS TIMESTAMP) AS "order_time_utc",
      a."Order_Id" AS "po_id",
      a."Status" AS "po_status",
      a."Reference_Code" AS "sku",
      '' AS "tradein_ext_memory",
      '' AS "tradein_ext_product_family_name",
      '' AS "tradein_ext_product_identifier",
      '' AS "upgrade_id",
      '' AS "upgrade_loan_number",
      '' AS "upgrade_root_order_date",
      '' AS "upgrade_status",
      '' AS "ex_est_exch_discount_amount",
      '' AS "ex_est_exch_value_amount",
      '' AS "ex_est_total_amount",
      '' AS "ex_identity_id",
      '' AS "ex_sku",
      '' AS "ex_status",
      'FALSE' AS "is_upgrade",
      'FALSE' AS "is_tariff_order"
    FROM "_SYS_BIC"."SDSLA_ECOM/CV_ECOM_ORDERS_CUSTOMERS_PRODUCTS_SYNAPCOM_TRADE_IN" AS a
    JOIN U_PRJ_ECOM.VIEW_ECOM_HQ_ORDERS_PRODUCTS_TRADEIN_TST_ADJ AS b
      ON a."Order_Id" = b."Order_Id" AND a."Reference_Code" = b."Reference_Code"
    JOIN "U_PRJ_ECOM"."VIEW_ECOM_HQ_ORDERS_PAYMENT_SYNAPCOM" AS c
      ON a."ID" = c."ORDER_ID"
    WHERE
      a."Subsidiary_Id" = 6 AND CAST("Creation_Datetime" AS DATE) >= '2022-12-20'
  )
  UNION ALL
  (
    SELECT DISTINCT
      a."Country" AS "country_cd",
      a."Order_Id" AS "order_id",
      a."Reference_Code" AS "line_item_id",
      b."TRADE_IN_DISCOUNT_DEVICE" AS "discount_amount",
      b."BRAND_DEVICE" AS "exchange_brand",
      '' AS "exchange_category",
      b.MODEL_DEVICE AS "exchange_device_name",
      '' AS "exchange_grade",
      '' AS "exchange_id",
      '' AS "exchange_type",
      '' AS "is_accessory",
      '' AS "is_financed_order",
      c."IS_FINANCED_ORDER" AS "is_financing",
      '' AS "is_financing_eligible",
      CASE WHEN a."IS_SAMSUNG_CARE" = 1 THEN 'TRUE' ELSE 'FALSE' END AS "is_samsung_care_order",
      'TRUE' AS "is_traded_in",
      '' AS "is_under_extended_warranty",
      A."Creation_Date" AS "order_date",
      CAST(A."Creation_Datetime" AS TIMESTAMP) AS "order_time_utc",
      a."Order_Id" AS "po_id",
      a."Status" AS "po_status",
      a."Reference_Code" AS "sku",
      '' AS "tradein_ext_memory",
      '' AS "tradein_ext_product_family_name",
      '' AS "tradein_ext_product_identifier",
      '' AS "upgrade_id",
      '' AS "upgrade_loan_number",
      '' AS "upgrade_root_order_date",
      '' AS "upgrade_status",
      '' AS "ex_est_exch_discount_amount",
      '' AS "ex_est_exch_value_amount",
      '' AS "ex_est_total_amount",
      '' AS "ex_identity_id",
      '' AS "ex_sku",
      '' AS "ex_status",
      'FALSE' AS "is_upgrade",
      'FALSE' AS "is_tariff_order"
    FROM "_SYS_BIC"."SDSLA_ECOM/CV_ECOM_ORDERS_CUSTOMERS_PRODUCTS_TRADEIN" AS a
    JOIN U_PRJ_ECOM.RAW_VTEX_SEASA_TRADEIN_FEED AS b
      ON a."Order_Id" = b.ORDER_ID AND a.SKU_ID = b.SKUID
    JOIN "U_PRJ_ECOM"."VIEW_ECOM_HQ_ORDERS_PAYMENT" AS c
      ON a."ID" = c."ORDER_ID"
    WHERE
      a."Subsidiary_Id" = 1 AND CAST("Creation_Datetime" AS DATE) >= '2022-04-13'
  )
)