-- MISSING RELATION: _SYS_BIC
-- ERROR: Error executing query: Severity: ERROR, Message: Schema "_SYS_BIC" does not exist, Sqlstate: 3F000, Routine: RangeVarGetObjid, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Miner/server/vertica/Catalog/NamespaceLookup.cpp, Line: 317, Error Code: 4650, SQL: 'CREATE OR REPLACE VIEW "U_PRJ_ECOM"."VIEW_ECOM_HQ_ORDERS_PRODUCTS_PAYMENT_SYNAPCOM_TST_BKP20230707" (   "COUNTRY_CD",   "SITE",   "SALES_APPLICATION",   "PRODUCT_CODE",   "ORDER_CODE",   "ORDER_STATUS",   "ORDER_TYPE",   "ORDER_CREATION_DATE",   "PLATFORM",   "VOUCHER_CODE",   "ITEM_TAX_AMOUNT",   "IS_TRADED_IN",   "IS_TRADE_IN_ELIGIBLE",   "IS_FINANCED_ORDER",   "IS_FINANCING_ELIGIBLE",   "IS_UPGRADE",   "IS_UPGRADE_ELIGIBLE",   "IS_SAMSUNG_CARE_ORDER",   "IS_SAMSUNG_CARE_ELIGIBLE",   "PAYMENT_METHOD_NAME",   "PAYMENT_GATEWAY",   "LAST_UPDATE",   "REMARKS",   "ORDER_ENTRY_TOTAL_PRICE",   "ORDER_ENTRY_QUANTITY",   "UNIT_LIST_PRICE",   "UNIT_SALES_PRICE",   "SALES_PRICE",   "DISCOUNT_AMOUNT" ) AS SELECT   O."Country" AS "COUNTRY_CD",   CASE     WHEN NOT EA."order_id" IS NULL     THEN \'Ominichannel\'     ELSE COALESCE(COALESCE(S."STORE_NAME", g.store_name), \'Samsung B2C\')   END AS "SITE",   CASE     WHEN O."Affiliate_Id" IN (       \'VVT\',       \'BWW\',       \'VVJ\',       \'DDV\',       \'ZMM\',       \'SMS\',       \'KBM\',       \'NTS\',       \'CLR\',       \'RDT\',       \'MGZ\',       \'LRM\',       \'GCM\',       \'NNT\',       \'NVM\',       \'CRF\',       \'SHP\',       \'ZMN\',       \'SFB\',       \'MRC\',       \'MCL\',       \'CSL\',       \'SPM\',       \'RCH\',       \'FSH\',       \'MZN\',       \'B2W\',       \'SMS\',       \'NVM\',       \'BWW\',       \'VVJ\',       \'SPM\',       \'RDT\',       \'LBS\',       \'MGZ\',       \'RCH\',       \'CSL\',       \'MRC\',       \'BBW\',       \'MGT\',       \'MMC\',       \'MMP\',       \'NMD\',       \'VVR\',       \'CMD\',       \'KLD\',       \'SNF\'     )     THEN \'3PD\'     WHEN O."COD_SALES_CHANNEL" IN (\'10\', \'12\')     THEN \'3PD\'     ELSE \'ESTORE\'   END AS "SALES_APPLICATION",   O."Reference_Code" AS "PRODUCT_CODE",   O."Order_Id" AS "ORDER_CODE",   COALESCE(OO.INTERNAL_STATUS, O."Status") AS "ORDER_STATUS",   CASE     WHEN O."Affiliate_Id" IN (       \'SNG\',       \'SPP\',       \'PSG\',       \'BLP\',       \'BNT\',       \'BST\',       \'CDR\',       \'LTM\',       \'NXT\',       \'PCR\',       \'SFF\',       \'SGP\',       \'SHM\',       \'SHN\',       \'SPC\',       \'SSC\',       \'STD\',       \'TLC\',       \'TLD\',       \'TLF\',       \'ZPT\',       \'SMG\',       \'BPS\',       \'MBS\',       \'TLB\',       \'DSC\',       \'BBC\',       \'HTG\'     )     THEN \'EPP\'     WHEN O."COD_SALES_CHANNEL" IN (\'22\')     THEN \'EPP\'     WHEN O."Affiliate_Id" IN (\'SBB\')     THEN \'SMB\'     ELSE \'B2C\'   END AS "ORDER_TYPE",   CAST(O."Creation_Datetime" AS VARCHAR) AS "ORDER_CREATION_DATE",   CASE WHEN O."COD_SALES_CHANNEL" = \'45\' THEN \'MobileApp\' ELSE \'Web\' END AS "PLATFORM",   \'\' AS "VOUCHER_CODE",   \'\' AS "ITEM_TAX_AMOUNT",   CASE O."IS_TRADE_IN" WHEN 1 THEN \'TRUE\' ELSE \'FALSE\' END AS "IS_TRADED_IN",   \'FALSE\' AS "IS_TRADE_IN_ELIGIBLE",   P."IS_FINANCED_ORDER" AS "IS_FINANCED_ORDER",   P."IS_FINANCED_ORDER" AS "IS_FINANCING_ELIGIBLE",   \'FALSE\' AS "IS_UPGRADE",   \'FALSE\' AS "IS_UPGRADE_ELIGIBLE",   CASE O."IS_SAMSUNG_CARE" WHEN 1 THEN \'TRUE\' ELSE \'FALSE\' END AS "IS_SAMSUNG_CARE_ORDER",   CASE WHEN (     UPPER(O."Product_Group") = \'SSG CARE\'   ) THEN \'TRUE\' ELSE \'FALSE\' END AS "IS_SAMSUNG_CARE_ELIGIBLE",   COALESCE(P."PAYMENT_METHOD", \'Undefined\') AS "PAYMENT_METHOD_NAME",   COALESCE(P."PAYMENT_METHOD", \'Undefined\') AS "PAYMENT_GATEWAY",   COALESCE(O."Last_Update_Date", O."Insert_Date") AS "LAST_UPDATE",   O."Acquirer_Message" AS "REMARKS",   SUM(O."Total_Item") AS "ORDER_ENTRY_TOTAL_PRICE",   SUM(O."Units") AS "ORDER_ENTRY_QUANTITY",   SUM(O."Price") AS "UNIT_LIST_PRICE",   SUM(O."Price") AS "UNIT_SALES_PRICE",   SUM(O."Price") AS "SALES_PRICE",   SUM(O."Item_Discount") AS "DISCOUNT_AMOUNT" FROM "_SYS_BIC"."SDSLA_ECOM/CV_ECOM_ORDERS_CUSTOMERS_PRODUCTS_SYNAPCOM" AS O LEFT JOIN "U_PRJ_ECOM"."VIEW_ECOM_HQ_ORDERS_PAYMENT_SYNAPCOM" AS P   ON O."ID" = P."ORDER_ID" LEFT JOIN "U_PRJ_ECOM"."DIM_ECOM_STORE" AS S   ON NOT O."Hostname" IS NULL   AND O."SELLER_INSTANCE_ID" = S."SELLER_INSTANCE_ID"   AND O."Subsidiary_Id" = S."SUBSIDIARY_ID"   AND NOT O."COD_SALES_CHANNEL" IS NULL   AND O."COD_SALES_CHANNEL" = S."COD_SALES_CHANNEL"   AND NOT O."COD_SALES_CHANNEL" IN (     \'17\',     \'9\',     \'3\',     \'16\',     \'31\',     \'43\',     \'7\',     \'13\',     \'18\',     \'26\',     \'21\',     \'4\',     \'6\',     \'27\',     \'36\',     \'30\',     \'44\',     \'56\'   ) LEFT JOIN "U_PRJ_ECOM"."DIM_ECOM_STORE" AS G   ON NOT O."Hostname" IS NULL   AND O."SELLER_INSTANCE_ID" = g."SELLER_INSTANCE_ID"   AND O."Subsidiary_Id" = g."SUBSIDIARY_ID"   AND NOT O."COD_SALES_CHANNEL" IS NULL   AND O."COD_SALES_CHANNEL" = g."COD_SALES_CHANNEL"   AND O."COD_SALES_CHANNEL" IN (     \'17\',     \'9\',     \'3\',     \'16\',     \'31\',     \'43\',     \'7\',     \'13\',     \'18\',     \'26\',     \'21\',     \'4\',     \'6\',     \'27\',     \'36\',     \'30\',     \'44\',     \'56\'   )   AND o."Affiliate_Id" = g.affiliate_id LEFT JOIN (   SELECT     EXTERNAL_ORDER_ID,     INTERNAL_STATUS,     SELLER_ORDER_ID   FROM U_PRJ_ECOM.FT_ECOM_ORDER   WHERE     SUBSIDIARY_ID = 6 ) AS OO   ON (     (       NOT OO.SELLER_ORDER_ID IS NULL AND O."Order_Id" = OO.SELLER_ORDER_ID     )     OR (       NOT O."MKTPLACE_ORDER_ID" IS NULL       AND O."MKTPLACE_ORDER_ID" = OO.EXTERNAL_ORDER_ID     )   ) LEFT JOIN (   SELECT DISTINCT     "order_id",     "environment"   FROM "U_PRJ_ECOM"."VIEW_ECOM_ENDLESS_AISLE_REPORT" ) AS EA   ON EA."order_id" = O."Order_Id"   AND EA."environment" = O."Hostname"   AND O."Creation_Datetime" >= \'2023-06-27 20:00\' GROUP BY   O."Country",   COALESCE(COALESCE(S."STORE_NAME", g.store_name), \'Samsung B2C\'),   CASE     WHEN O."Affiliate_Id" IN (       \'SNG\',       \'SPP\',       \'PSG\',       \'BLP\',       \'BNT\',       \'BST\',       \'CDR\',       \'LTM\',       \'NXT\',       \'PCR\',       \'SFF\',       \'SGP\',       \'SHM\',       \'SHN\',       \'SPC\',       \'SSC\',       \'STD\',       \'TLC\',       \'TLD\',       \'TLF\',       \'ZPT\',       \'SMG\',       \'BPS\',       \'MBS\',       \'TLB\',       \'DSC\',       \'BBC\',       \'HTG\'     )     THEN \'EPP\'     WHEN O."COD_SALES_CHANNEL" IN (\'22\')     THEN \'EPP\'     WHEN O."Affiliate_Id" IN (\'SBB\')     THEN \'SMB\'     ELSE \'B2C\'   END,   CASE     WHEN O."Affiliate_Id" IN (       \'VVT\',       \'BWW\',       \'VVJ\',       \'DDV\',       \'ZMM\',       \'SMS\',       \'KBM\',       \'NTS\',       \'CLR\',       \'RDT\',       \'MGZ\',       \'LRM\',       \'GCM\',       \'NNT\',       \'NVM\',       \'CRF\',       \'SHP\',       \'ZMN\',       \'SFB\',       \'MRC\',       \'MCL\',       \'CSL\',       \'SPM\',       \'RCH\',       \'FSH\',       \'MZN\',       \'B2W\',       \'SMS\',       \'NVM\',       \'BWW\',       \'VVJ\',       \'SPM\',       \'RDT\',       \'LBS\',       \'MGZ\',       \'RCH\',       \'CSL\',       \'MRC\',       \'BBW\',       \'MGT\',       \'MMC\',       \'MMP\',       \'NMD\',       \'VVR\',       \'CMD\',       \'KLD\',       \'SNF\'     )     THEN \'3PD\'     WHEN O."COD_SALES_CHANNEL" IN (\'10\', \'12\')     THEN \'3PD\'     ELSE \'ESTORE\'   END,   O."Reference_Code",   O."Order_Id",   COALESCE(OO.INTERNAL_STATUS, O."Status"),   CASE     WHEN NOT EA."order_id" IS NULL     THEN \'Ominichannel\'     ELSE COALESCE(COALESCE(S."STORE_NAME", g.store_name), \'Samsung B2C\')   END,   CAST(O."Creation_Datetime" AS VARCHAR),   CASE WHEN O."COD_SALES_CHANNEL" = \'45\' THEN \'MobileApp\' ELSE \'Web\' END,   \'\',   \'\',   CASE O."IS_TRADE_IN" WHEN 1 THEN \'TRUE\' ELSE \'FALSE\' END,   \'FALSE\',   P."IS_FINANCED_ORDER",   P."IS_FINANCED_ORDER",   \'FALSE\',   \'FALSE\',   CASE O."IS_SAMSUNG_CARE" WHEN 1 THEN \'TRUE\' ELSE \'FALSE\' END,   CASE WHEN (     UPPER(O."Product_Group") = \'SSG CARE\'   ) THEN \'TRUE\' ELSE \'FALSE\' END,   COALESCE(P."PAYMENT_METHOD", \'Undefined\'),   COALESCE(P."PAYMENT_METHOD", \'Undefined\'),   COALESCE(O."Last_Update_Date", O."Insert_Date"),   O."Acquirer_Message"'

CREATE VIEW "U_PRJ_ECOM"."VIEW_ECOM_HQ_ORDERS_PRODUCTS_PAYMENT_SYNAPCOM_TST_BKP20230707" (
  "COUNTRY_CD",
  "SITE",
  "SALES_APPLICATION",
  "PRODUCT_CODE",
  "ORDER_CODE",
  "ORDER_STATUS",
  "ORDER_TYPE",
  "ORDER_CREATION_DATE",
  "PLATFORM",
  "VOUCHER_CODE",
  "ITEM_TAX_AMOUNT",
  "IS_TRADED_IN",
  "IS_TRADE_IN_ELIGIBLE",
  "IS_FINANCED_ORDER",
  "IS_FINANCING_ELIGIBLE",
  "IS_UPGRADE",
  "IS_UPGRADE_ELIGIBLE",
  "IS_SAMSUNG_CARE_ORDER",
  "IS_SAMSUNG_CARE_ELIGIBLE",
  "PAYMENT_METHOD_NAME",
  "PAYMENT_GATEWAY",
  "LAST_UPDATE",
  "REMARKS",
  "ORDER_ENTRY_TOTAL_PRICE",
  "ORDER_ENTRY_QUANTITY",
  "UNIT_LIST_PRICE",
  "UNIT_SALES_PRICE",
  "SALES_PRICE",
  "DISCOUNT_AMOUNT"
) AS
SELECT
  O."Country" AS "COUNTRY_CD",
  CASE
    WHEN NOT EA."order_id" IS NULL
    THEN 'Ominichannel'
    ELSE COALESCE(COALESCE(S."STORE_NAME", g.store_name), 'Samsung B2C')
  END AS "SITE",
  CASE
    WHEN O."Affiliate_Id" IN (
      'VVT',
      'BWW',
      'VVJ',
      'DDV',
      'ZMM',
      'SMS',
      'KBM',
      'NTS',
      'CLR',
      'RDT',
      'MGZ',
      'LRM',
      'GCM',
      'NNT',
      'NVM',
      'CRF',
      'SHP',
      'ZMN',
      'SFB',
      'MRC',
      'MCL',
      'CSL',
      'SPM',
      'RCH',
      'FSH',
      'MZN',
      'B2W',
      'SMS',
      'NVM',
      'BWW',
      'VVJ',
      'SPM',
      'RDT',
      'LBS',
      'MGZ',
      'RCH',
      'CSL',
      'MRC',
      'BBW',
      'MGT',
      'MMC',
      'MMP',
      'NMD',
      'VVR',
      'CMD',
      'KLD',
      'SNF'
    )
    THEN '3PD'
    WHEN O."COD_SALES_CHANNEL" IN ('10', '12')
    THEN '3PD'
    ELSE 'ESTORE'
  END AS "SALES_APPLICATION",
  O."Reference_Code" AS "PRODUCT_CODE",
  O."Order_Id" AS "ORDER_CODE",
  COALESCE(OO.INTERNAL_STATUS, O."Status") AS "ORDER_STATUS",
  CASE
    WHEN O."Affiliate_Id" IN (
      'SNG',
      'SPP',
      'PSG',
      'BLP',
      'BNT',
      'BST',
      'CDR',
      'LTM',
      'NXT',
      'PCR',
      'SFF',
      'SGP',
      'SHM',
      'SHN',
      'SPC',
      'SSC',
      'STD',
      'TLC',
      'TLD',
      'TLF',
      'ZPT',
      'SMG',
      'BPS',
      'MBS',
      'TLB',
      'DSC',
      'BBC',
      'HTG'
    )
    THEN 'EPP'
    WHEN O."COD_SALES_CHANNEL" IN ('22')
    THEN 'EPP'
    WHEN O."Affiliate_Id" IN ('SBB')
    THEN 'SMB'
    ELSE 'B2C'
  END AS "ORDER_TYPE",
  CAST(O."Creation_Datetime" AS VARCHAR) AS "ORDER_CREATION_DATE",
  CASE WHEN O."COD_SALES_CHANNEL" = '45' THEN 'MobileApp' ELSE 'Web' END AS "PLATFORM",
  '' AS "VOUCHER_CODE",
  '' AS "ITEM_TAX_AMOUNT",
  CASE O."IS_TRADE_IN" WHEN 1 THEN 'TRUE' ELSE 'FALSE' END AS "IS_TRADED_IN",
  'FALSE' AS "IS_TRADE_IN_ELIGIBLE",
  P."IS_FINANCED_ORDER" AS "IS_FINANCED_ORDER",
  P."IS_FINANCED_ORDER" AS "IS_FINANCING_ELIGIBLE",
  'FALSE' AS "IS_UPGRADE",
  'FALSE' AS "IS_UPGRADE_ELIGIBLE",
  CASE O."IS_SAMSUNG_CARE" WHEN 1 THEN 'TRUE' ELSE 'FALSE' END AS "IS_SAMSUNG_CARE_ORDER",
  CASE WHEN (
    UPPER(O."Product_Group") = 'SSG CARE'
  ) THEN 'TRUE' ELSE 'FALSE' END AS "IS_SAMSUNG_CARE_ELIGIBLE",
  COALESCE(P."PAYMENT_METHOD", 'Undefined') AS "PAYMENT_METHOD_NAME",
  COALESCE(P."PAYMENT_METHOD", 'Undefined') AS "PAYMENT_GATEWAY",
  COALESCE(O."Last_Update_Date", O."Insert_Date") AS "LAST_UPDATE",
  O."Acquirer_Message" AS "REMARKS",
  SUM(O."Total_Item") AS "ORDER_ENTRY_TOTAL_PRICE",
  SUM(O."Units") AS "ORDER_ENTRY_QUANTITY",
  SUM(O."Price") AS "UNIT_LIST_PRICE",
  SUM(O."Price") AS "UNIT_SALES_PRICE",
  SUM(O."Price") AS "SALES_PRICE",
  SUM(O."Item_Discount") AS "DISCOUNT_AMOUNT"
FROM "_SYS_BIC"."SDSLA_ECOM/CV_ECOM_ORDERS_CUSTOMERS_PRODUCTS_SYNAPCOM" AS O
LEFT JOIN "U_PRJ_ECOM"."VIEW_ECOM_HQ_ORDERS_PAYMENT_SYNAPCOM" AS P
  ON O."ID" = P."ORDER_ID"
LEFT JOIN "U_PRJ_ECOM"."DIM_ECOM_STORE" AS S
  ON NOT O."Hostname" IS NULL
  AND O."SELLER_INSTANCE_ID" = S."SELLER_INSTANCE_ID"
  AND O."Subsidiary_Id" = S."SUBSIDIARY_ID"
  AND NOT O."COD_SALES_CHANNEL" IS NULL
  AND O."COD_SALES_CHANNEL" = S."COD_SALES_CHANNEL"
  AND NOT O."COD_SALES_CHANNEL" IN (
    '17',
    '9',
    '3',
    '16',
    '31',
    '43',
    '7',
    '13',
    '18',
    '26',
    '21',
    '4',
    '6',
    '27',
    '36',
    '30',
    '44',
    '56'
  )
LEFT JOIN "U_PRJ_ECOM"."DIM_ECOM_STORE" AS G
  ON NOT O."Hostname" IS NULL
  AND O."SELLER_INSTANCE_ID" = g."SELLER_INSTANCE_ID"
  AND O."Subsidiary_Id" = g."SUBSIDIARY_ID"
  AND NOT O."COD_SALES_CHANNEL" IS NULL
  AND O."COD_SALES_CHANNEL" = g."COD_SALES_CHANNEL"
  AND O."COD_SALES_CHANNEL" IN (
    '17',
    '9',
    '3',
    '16',
    '31',
    '43',
    '7',
    '13',
    '18',
    '26',
    '21',
    '4',
    '6',
    '27',
    '36',
    '30',
    '44',
    '56'
  )
  AND o."Affiliate_Id" = g.affiliate_id
LEFT JOIN (
  SELECT
    EXTERNAL_ORDER_ID,
    INTERNAL_STATUS,
    SELLER_ORDER_ID
  FROM U_PRJ_ECOM.FT_ECOM_ORDER
  WHERE
    SUBSIDIARY_ID = 6
) AS OO
  ON (
    (
      NOT OO.SELLER_ORDER_ID IS NULL AND O."Order_Id" = OO.SELLER_ORDER_ID
    )
    OR (
      NOT O."MKTPLACE_ORDER_ID" IS NULL
      AND O."MKTPLACE_ORDER_ID" = OO.EXTERNAL_ORDER_ID
    )
  )
LEFT JOIN (
  SELECT DISTINCT
    "order_id",
    "environment"
  FROM "U_PRJ_ECOM"."VIEW_ECOM_ENDLESS_AISLE_REPORT"
) AS EA
  ON EA."order_id" = O."Order_Id"
  AND EA."environment" = O."Hostname"
  AND O."Creation_Datetime" >= '2023-06-27 20:00'
GROUP BY
  O."Country",
  COALESCE(COALESCE(S."STORE_NAME", g.store_name), 'Samsung B2C'),
  CASE
    WHEN O."Affiliate_Id" IN (
      'SNG',
      'SPP',
      'PSG',
      'BLP',
      'BNT',
      'BST',
      'CDR',
      'LTM',
      'NXT',
      'PCR',
      'SFF',
      'SGP',
      'SHM',
      'SHN',
      'SPC',
      'SSC',
      'STD',
      'TLC',
      'TLD',
      'TLF',
      'ZPT',
      'SMG',
      'BPS',
      'MBS',
      'TLB',
      'DSC',
      'BBC',
      'HTG'
    )
    THEN 'EPP'
    WHEN O."COD_SALES_CHANNEL" IN ('22')
    THEN 'EPP'
    WHEN O."Affiliate_Id" IN ('SBB')
    THEN 'SMB'
    ELSE 'B2C'
  END,
  CASE
    WHEN O."Affiliate_Id" IN (
      'VVT',
      'BWW',
      'VVJ',
      'DDV',
      'ZMM',
      'SMS',
      'KBM',
      'NTS',
      'CLR',
      'RDT',
      'MGZ',
      'LRM',
      'GCM',
      'NNT',
      'NVM',
      'CRF',
      'SHP',
      'ZMN',
      'SFB',
      'MRC',
      'MCL',
      'CSL',
      'SPM',
      'RCH',
      'FSH',
      'MZN',
      'B2W',
      'SMS',
      'NVM',
      'BWW',
      'VVJ',
      'SPM',
      'RDT',
      'LBS',
      'MGZ',
      'RCH',
      'CSL',
      'MRC',
      'BBW',
      'MGT',
      'MMC',
      'MMP',
      'NMD',
      'VVR',
      'CMD',
      'KLD',
      'SNF'
    )
    THEN '3PD'
    WHEN O."COD_SALES_CHANNEL" IN ('10', '12')
    THEN '3PD'
    ELSE 'ESTORE'
  END,
  O."Reference_Code",
  O."Order_Id",
  COALESCE(OO.INTERNAL_STATUS, O."Status"),
  CASE
    WHEN NOT EA."order_id" IS NULL
    THEN 'Ominichannel'
    ELSE COALESCE(COALESCE(S."STORE_NAME", g.store_name), 'Samsung B2C')
  END,
  CAST(O."Creation_Datetime" AS VARCHAR),
  CASE WHEN O."COD_SALES_CHANNEL" = '45' THEN 'MobileApp' ELSE 'Web' END,
  '',
  '',
  CASE O."IS_TRADE_IN" WHEN 1 THEN 'TRUE' ELSE 'FALSE' END,
  'FALSE',
  P."IS_FINANCED_ORDER",
  P."IS_FINANCED_ORDER",
  'FALSE',
  'FALSE',
  CASE O."IS_SAMSUNG_CARE" WHEN 1 THEN 'TRUE' ELSE 'FALSE' END,
  CASE WHEN (
    UPPER(O."Product_Group") = 'SSG CARE'
  ) THEN 'TRUE' ELSE 'FALSE' END,
  COALESCE(P."PAYMENT_METHOD", 'Undefined'),
  COALESCE(P."PAYMENT_METHOD", 'Undefined'),
  COALESCE(O."Last_Update_Date", O."Insert_Date"),
  O."Acquirer_Message"