-- ERROR: Error executing query: Severity: ERROR, Message: Insufficient resources to execute plan on pool general [Request Too Large:Memory(KB) Exceeded: Requested = 199070897, Free = 54733165 (Limit = 54733165, Used = 0)], Sqlstate: 53000, Routine: Exec_compilePlan, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Miner/server/vertica/Dist/PlanExecCoordinator.cpp, Line: 3031, Error Code: 3587, SQL: 'SELECT * FROM "OW_SEDA_S"."VW_TT_OFF_COLLECTED_PRICE" LIMIT 10;'

CREATE VIEW "OW_SEDA_S"."VW_TT_OFF_COLLECTED_PRICE" (
  "FLAG",
  "Moda",
  "SKU",
  "PIN TO PIN",
  "STORE",
  "CREATED_AT",
  "# Moda",
  "Average Price"
) AS
SELECT
  mode.FLAG,
  mode.PRICE AS "Moda",
  mode.SKU,
  mcp.PIN_TO_PIN_BF_2021 AS "PIN TO PIN",
  cnt.STORE,
  mode.CREATED_AT,
  mode.CONTAGEM AS "# Moda",
  mode.average_price AS "Average Price"
FROM (
  SELECT
    m.*,
    SUM(m.contagem * m.price) OVER (PARTITION BY m.FLAG, m.CREATED_AT, m.SKU ORDER BY m.FLAG, m.CREATED_AT, m.SKU) / SUM(m.contagem) OVER (PARTITION BY m.FLAG, m.CREATED_AT, m.SKU ORDER BY m.FLAG, m.CREATED_AT, m.SKU) AS average_price,
    ROW_NUMBER() OVER (
      PARTITION BY m.FLAG, m.CREATED_AT, m.SKU
      ORDER BY m.FLAG, m.CREATED_AT, m.SKU, m.CONTAGEM DESC
    ) AS ROW_NUM
  FROM (
    SELECT
      CASE
        WHEN FLAG_NAME IN ('CASAS BAHIA', 'PONTO FRIO')
        THEN 'VIA VAREJO'
        WHEN FLAG_NAME LIKE '%NAGEM%'
        THEN 'NAGEM'
        WHEN FLAG_NAME LIKE '%COLOMBO%'
        THEN 'COLOMBO'
        WHEN FLAG_NAME LIKE '%G%BARBOSA%'
        THEN 'GBARBOSA'
        WHEN FLAG_NAME LIKE '%EXTRA%'
        THEN 'CBD'
        ELSE FLAG_NAME
      END AS FLAG,
      CREATED_AT,
      PRODUCT__NAME AS SKU,
      PRICE,
      COUNT(DISTINCT CODE) AS contagem
    FROM OW_SEDA_S.VW_TT_COLLECTED_PRICE_URL
    WHERE
      1 = 1 AND PRICE <> 0
    GROUP BY
      CASE
        WHEN FLAG_NAME IN ('CASAS BAHIA', 'PONTO FRIO')
        THEN 'VIA VAREJO'
        WHEN FLAG_NAME LIKE '%NAGEM%'
        THEN 'NAGEM'
        WHEN FLAG_NAME LIKE '%COLOMBO%'
        THEN 'COLOMBO'
        WHEN FLAG_NAME LIKE '%G%BARBOSA%'
        THEN 'GBARBOSA'
        WHEN FLAG_NAME LIKE '%EXTRA%'
        THEN 'CBD'
        ELSE FLAG_NAME
      END,
      CREATED_AT,
      PRODUCT__NAME,
      PRICE
  ) AS m
  INNER JOIN (
    SELECT
      FLAG,
      CREATED_AT,
      SKU,
      PRICE * 0.7 AS MIN_RANGE,
      PRICE * 1.3 AS MAX_RANGE
    FROM (
      SELECT
        *,
        ROW_NUMBER() OVER (PARTITION BY FLAG, CREATED_AT, SKU ORDER BY FLAG, CREATED_AT, SKU, CONTAGEM DESC) AS ROW_NUM
      FROM (
        SELECT
          CASE
            WHEN FLAG_NAME IN ('CASAS BAHIA', 'PONTO FRIO')
            THEN 'VIA VAREJO'
            WHEN FLAG_NAME LIKE '%NAGEM%'
            THEN 'NAGEM'
            WHEN FLAG_NAME LIKE '%COLOMBO%'
            THEN 'COLOMBO'
            WHEN FLAG_NAME LIKE '%G%BARBOSA%'
            THEN 'GBARBOSA'
            WHEN FLAG_NAME LIKE '%EXTRA%'
            THEN 'CBD'
            ELSE FLAG_NAME
          END AS FLAG,
          CREATED_AT,
          PRODUCT__NAME AS SKU,
          PRICE,
          COUNT(*) AS contagem
        FROM OW_SEDA_S.VW_TT_COLLECTED_PRICE_URL
        WHERE
          1 = 1 AND PRICE <> 0
        GROUP BY
          CASE
            WHEN FLAG_NAME IN ('CASAS BAHIA', 'PONTO FRIO')
            THEN 'VIA VAREJO'
            WHEN FLAG_NAME LIKE '%NAGEM%'
            THEN 'NAGEM'
            WHEN FLAG_NAME LIKE '%COLOMBO%'
            THEN 'COLOMBO'
            WHEN FLAG_NAME LIKE '%G%BARBOSA%'
            THEN 'GBARBOSA'
            WHEN FLAG_NAME LIKE '%EXTRA%'
            THEN 'CBD'
            ELSE FLAG_NAME
          END,
          CREATED_AT,
          PRODUCT__NAME,
          PRICE
      ) AS subq_2672
    ) AS subq_7936
    WHERE
      ROW_NUM = 1
  ) AS a
    ON 1 = 1
    AND m.FLAG = a.FLAG
    AND m.CREATED_AT = a.CREATED_AT
    AND m.SKU = a.SKU
    AND m.PRICE BETWEEN a.MIN_RANGE AND a.MAX_RANGE
) AS mode
INNER JOIN OW_SEDA_S.MAP_CE_PRODUCTS AS mcp
  ON mcp.ITEM = mode.SKU
INNER JOIN (
  SELECT
    CASE
      WHEN FLAG_NAME IN ('CASAS BAHIA', 'PONTO FRIO')
      THEN 'VIA VAREJO'
      WHEN FLAG_NAME LIKE '%NAGEM%'
      THEN 'NAGEM'
      WHEN FLAG_NAME LIKE '%COLOMBO%'
      THEN 'COLOMBO'
      WHEN FLAG_NAME LIKE '%G%BARBOSA%'
      THEN 'GBARBOSA'
      WHEN FLAG_NAME LIKE '%EXTRA%'
      THEN 'CBD'
      ELSE FLAG_NAME
    END AS FLAG,
    CREATED_AT,
    PRODUCT__NAME,
    COUNT(DISTINCT CODE) AS STORE
  FROM OW_SEDA_S.VW_TT_COLLECTED_PRICE_URL
  GROUP BY
    CASE
      WHEN FLAG_NAME IN ('CASAS BAHIA', 'PONTO FRIO')
      THEN 'VIA VAREJO'
      WHEN FLAG_NAME LIKE '%NAGEM%'
      THEN 'NAGEM'
      WHEN FLAG_NAME LIKE '%COLOMBO%'
      THEN 'COLOMBO'
      WHEN FLAG_NAME LIKE '%G%BARBOSA%'
      THEN 'GBARBOSA'
      WHEN FLAG_NAME LIKE '%EXTRA%'
      THEN 'CBD'
      ELSE FLAG_NAME
    END,
    CREATED_AT,
    PRODUCT__NAME
) AS cnt
  ON 1 = 1
  AND cnt.FLAG = mode.FLAG
  AND cnt.CREATED_AT = mode.CREATED_AT
  AND cnt.PRODUCT__NAME = mode.SKU
WHERE
  ROW_NUM = 1