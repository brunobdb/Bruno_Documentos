-- CREATE OR REPLACE VIEW "OW_SEDA_S_LOGISTIC"."TRACKING_VW_ITT_CALENDAR" ( "DATE", "WORKDAY_HOLIDAY" ) AS
-- SELECT "DATE", "WORKDAY_HOLIDAY"
-- FROM "OW_SEDA_S_LOGISTIC"."DIM_TP_WORKDAYS_CALENDAR"
-- WHERE "DATE" BETWEEN DATEADD('day', -40, CURRENT_DATE) AND CURRENT_DATE;
-- ERROR: Severity: ERROR, Message: Relation "OW_SEDA_S_LOGISTIC.DIM_TP_WORKDAYS_CALENDAR" does not exist, Sqlstate: 42V01, Routine: throwRelationDoesNotExist, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Miner/server/vertica/Catalog/CatalogLookup.cpp, Line: 4362, Error Code: 4568, 
SELECT table_schema, table_name FROM v_catalog.tables WHERE table_schema = 'OW_SEDA_S_LOGISTIC' AND table_name = 'DIM_TP_WORKDAYS_CALENDAR';
-- table_schema | table_name
-- -------------+-----------

SELECT schema_name FROM v_catalog.schemata WHERE schema_name = 'OW_SEDA_S_LOGISTIC';
-- schema_name
-- -----------
-- OW_SEDA_S_LOGISTIC

CREATE TABLE IF NOT EXISTS "OW_SEDA_S_LOGISTIC"."DIM_TP_WORKDAYS_CALENDAR" (
  "DATE" DATE,
  "WORKDAY_HOLIDAY" VARCHAR(50)
);

INSERT INTO "OW_SEDA_S_LOGISTIC"."DIM_TP_WORKDAYS_CALENDAR" ("DATE","WORKDAY_HOLIDAY") VALUES (CURRENT_DATE - 10, 'WORKDAY');
-- OUTPUT
-- ------
-- 1

INSERT INTO "OW_SEDA_S_LOGISTIC"."DIM_TP_WORKDAYS_CALENDAR" ("DATE","WORKDAY_HOLIDAY") VALUES (CURRENT_DATE - 5, 'HOLIDAY');
-- OUTPUT
-- ------
-- 1

-- CREATE OR REPLACE VIEW "OW_SEDA_S_LOGISTIC"."TRACKING_VW_ITT_CALENDAR" ("DATE", "WORKDAY_HOLIDAY") AS
-- SELECT "DATE", "WORKDAY_HOLIDAY"
-- FROM "OW_SEDA_S_LOGISTIC"."DIM_TP_WORKDAYS_CALENDAR"
-- WHERE "DATE" BETWEEN DATEADD('day', -40, CURRENT_DATE) AND CURRENT_DATE
-- ORDER BY "DATE" ASC;
-- ERROR: Severity: ERROR, Message: Function DATEADD(unknown, int, date) does not exist, or permission is denied for DATEADD(unknown, int, date), Sqlstate: 42883, Hint: No function matches the given name and argument types. You may need to add explicit type casts, Routine: throwErrorFunctionDoesNotMatch, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Miner/server/vertica/Parser/ParseFunc.cpp, Line: 4547, Error Code: 3457, 
CREATE OR REPLACE VIEW "OW_SEDA_S_LOGISTIC"."TRACKING_VW_ITT_CALENDAR" ("DATE", "WORKDAY_HOLIDAY") AS
SELECT "DATE", "WORKDAY_HOLIDAY"
FROM "OW_SEDA_S_LOGISTIC"."DIM_TP_WORKDAYS_CALENDAR"
WHERE "DATE" BETWEEN CURRENT_DATE - INTERVAL '40 days' AND CURRENT_DATE;

SELECT * FROM "OW_SEDA_S_LOGISTIC"."TRACKING_VW_ITT_CALENDAR" LIMIT 10;
-- DATE | WORKDAY_HOLIDAY
-- -----+----------------

