-- CREATE OR REPLACE VIEW "OW_SEDA_S_LOGISTIC"."VW_XL_VTEX_ITEM_PROMO" ( "ORDER_ID", "ITEM_INDEX", "ID_1", "ID_2", "ID_3", "ID_4", "ID_5", "ID_6" ) AS
-- SELECT
--   ORDER_ID,
--   ITEM_INDEX,
--   STRTOK(identifier, ',', 1) AS ID_1,
--   STRTOK(identifier, ',', 2) AS ID_2,
--   STRTOK(identifier, ',', 3) AS ID_3,
--   STRTOK(identifier, ',', 4) AS ID_4,
--   STRTOK(identifier, ',', 5) AS ID_5,
--   STRTOK(identifier, ',', 6) AS ID_6
-- FROM (
--   SELECT
--     ORDER_ID,
--     REPLACE_REGEXPR('["\[\]]' IN JSON_QUERY(PRICE_TAGS,'$.identifier' WITH WRAPPER) WITH '') AS identifier,
--     ITEM_INDEX
--   FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER_ITEM
--   WHERE ORDER_ID IN ('1379851518395-01','SSG-1118401487153-01','SNG-1080131292606-01','1375851078094-01','1326779014277-01')
-- ) t;
-- ERROR: Severity: ERROR, Message: Syntax error at or near "JSON_QUERY", Sqlstate: 42601, Position: 468, Routine: base_yyerror, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Miner/server/vertica/Parser/scan.l, Line: 1056, Error Code: 4856, 
-- CREATE OR REPLACE VIEW "OW_SEDA_S_LOGISTIC"."VW_XL_VTEX_ITEM_PROMO" AS
-- SELECT ORDER_ID, ITEM_INDEX, STRTOK(identifier, ',', 1) AS ID_1, STRTOK(identifier, ',', 2) AS ID_2, STRTOK(identifier, ',', 3) AS ID_3, STRTOK(identifier, ',', 4) AS ID_4, STRTOK(identifier, ',', 5) AS ID_5, STRTOK(identifier, ',', 6) AS ID_6 FROM (SELECT ORDER_ID, REGEXP_REPLACE('["\[\]]', JSON_VALUE(PRICE_TAGS, 'identifier'), '') AS identifier, ITEM_INDEX FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER_ITEM WHERE ORDER_ID IN ('1379851518395-01', 'SSG-1118401487153-01', 'SNG-1080131292606-01', '1375851078094-01', '1326779014277-01')) AS t;
-- ERROR: Severity: ERROR, Message: Function STRTOK(varchar, unknown, int) does not exist, or permission is denied for STRTOK(varchar, unknown, int), Sqlstate: 42883, Hint: No function matches the given name and argument types. You may need to add explicit type casts, Routine: throwErrorFunctionDoesNotMatch, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Miner/server/vertica/Parser/ParseFunc.cpp, Line: 4547, Error Code: 3457, 
CREATE OR REPLACE VIEW "OW_SEDA_S_LOGISTIC"."VW_XL_VTEX_ITEM_PROMO" ( "ORDER_ID", "ITEM_INDEX", "ID_1", "ID_2", "ID_3", "ID_4", "ID_5", "ID_6" ) AS
SELECT
  ORDER_ID,
  ITEM_INDEX,
  NULLIF(SPLIT_PART(identifier, ',', 1), '') AS ID_1,
  NULLIF(SPLIT_PART(identifier, ',', 2), '') AS ID_2,
  NULLIF(SPLIT_PART(identifier, ',', 3), '') AS ID_3,
  NULLIF(SPLIT_PART(identifier, ',', 4), '') AS ID_4,
  NULLIF(SPLIT_PART(identifier, ',', 5), '') AS ID_5,
  NULLIF(SPLIT_PART(identifier, ',', 6), '') AS ID_6
FROM (
  SELECT
    ORDER_ID,
    REGEXP_REPLACE(
       REGEXP_SUBSTR(PRICE_TAGS, '\"identifier\"\\s*:\\s*\\[[^\\]]*\\]'),
       '\"identifier\"\\s*:\\s*\\[|\\]|\"',
       ''
    ) AS identifier,
    ITEM_INDEX
  FROM U_PRJ_ECOM.RAW_VTEX_SSG_BR_SHOP_SALES_ORDER_ITEM
  WHERE ORDER_ID IN ('1379851518395-01','SSG-1118401487153-01','SNG-1080131292606-01','1375851078094-01','1326779014277-01')
) s;

SELECT * FROM "OW_SEDA_S_LOGISTIC"."VW_XL_VTEX_ITEM_PROMO" LIMIT 10;
-- ORDER_ID | ITEM_INDEX | ID_1 | ID_2 | ID_3 | ID_4 | ID_5 | ID_6
-- ---------+------------+------+------+------+------+------+-----

