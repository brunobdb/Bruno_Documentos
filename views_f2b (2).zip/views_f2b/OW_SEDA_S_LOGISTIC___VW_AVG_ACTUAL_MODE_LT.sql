-- CREATE OR REPLACE VIEW TGT_SEDA_S.VW_AVG_ACTUAL_MODE_LT (
--   ORIGIN_CARRIER_UF_PROVINCE,
--   ORIGIN,
--   CARRIER_NAME,
--   UF,
--   PROVINCE,
--   DELIVERY_COUNT,
--   AVG_ACTUAL_LT,
--   DESVP_LT,
--   MODE_ACTUAL_LT
-- ) AS
-- WITH FREQUENCYTABLE AS (
--   SELECT ORIGIN, CARRIER_NAME, UF, PROVINCE, ACTUAL_LT, COUNT(*) AS Frequency
--   FROM TGT_SEDA_S.VW_ACTUAL_LT
--   WHERE TRACKING_STATUS = 'Delivered'
--     AND SHIPPING_TYPE = 'P4'
--     AND ACTUAL_LT IS NOT NULL
--   GROUP BY ORIGIN, CARRIER_NAME, UF, PROVINCE, ACTUAL_LT
-- ), MODETABLE AS (
--   SELECT ORIGIN, CARRIER_NAME, UF, PROVINCE, ACTUAL_LT AS MODE_ACTUAL_LT,
--     RANK() OVER (PARTITION BY ORIGIN, CARRIER_NAME, UF, PROVINCE ORDER BY Frequency DESC) AS Rank
--   FROM FREQUENCYTABLE
-- )
-- SELECT
--   main.ORIGIN || main.CARRIER_NAME || main.UF || main.PROVINCE AS ORIGIN_CARRIER_UF_PROVINCE,
--   main.ORIGIN,
--   main.CARRIER_NAME,
--   main.UF,
--   main.PROVINCE,
--   COUNT(main.DELIVERY_NO) AS DELIVERY_COUNT,
--   AVG(main.ACTUAL_LT) AS AVG_ACTUAL_LT,
--   STDDEV(main.ACTUAL_LT) AS DESVP_LT,
--   MAX(MT.MODE_ACTUAL_LT) AS MODE_ACTUAL_LT
-- FROM TGT_SEDA_S.VW_ACTUAL_LT main
-- LEFT JOIN MODETABLE MT
--   ON main.ORIGIN = MT.ORIGIN
--   AND main.CARRIER_NAME = MT.CARRIER_NAME
--   AND main.UF = MT.UF
--   AND main.PROVINCE = MT.PROVINCE
--   AND MT.Rank = 1
-- WHERE main.TRACKING_STATUS = 'Delivered'
--   AND main.SHIPPING_TYPE = 'P4'
-- GROUP BY main.ORIGIN, main.CARRIER_NAME, main.UF, main.PROVINCE;
-- ERROR: Severity: ERROR, Message: Schema "TGT_SEDA_S" does not exist, Sqlstate: 3F000, Routine: RangeVarGetObjid, File: /data/jenkins/workspace/RE-ReleaseBuilds/RE-Miner/server/vertica/Catalog/NamespaceLookup.cpp, Line: 317, Error Code: 4650, 
SELECT table_schema, table_name FROM v_catalog.tables WHERE table_schema = 'TGT_SEDA_S' AND table_name = 'VW_ACTUAL_LT';
-- table_schema | table_name
-- -------------+-----------

SELECT table_schema, table_name FROM v_catalog.tables WHERE table_name = 'VW_ACTUAL_LT' OR table_name = 'VW_AVG_ACTUAL_MODE_LT';
-- table_schema | table_name
-- -------------+-----------

SELECT schema_name FROM v_catalog.schemata WHERE schema_name = 'TGT_SEDA_S';
-- schema_name
-- -----------

